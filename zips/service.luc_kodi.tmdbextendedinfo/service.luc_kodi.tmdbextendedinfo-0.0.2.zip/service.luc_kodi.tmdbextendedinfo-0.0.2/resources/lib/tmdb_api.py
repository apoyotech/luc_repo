# -*- coding: utf-8 -*-
from __future__ import annotations
import json
import requests
from resources.lib.config import BASE_URL, API_KEY

def tmdb_get(endpoint: str, params: dict | None = None):
    params = params or {}
    params['api_key'] = API_KEY
    url = BASE_URL.rstrip('/') + '/' + endpoint.lstrip('/')
    r = requests.get(url, params=params, timeout=15)
    r.raise_for_status()
    return r.json()

def tmdb_get_videos(media_type: str, tmdb_id: str):
    if not tmdb_id:
        return []
    if media_type not in ('movie', 'tv'):
        media_type = 'movie'
    data = tmdb_get(f'{media_type}/{tmdb_id}/videos', params={'language': 'en-US'})
    return data.get('results') or []
