# -*- coding: utf-8 -*-
"""Trakt watched-status helpers (stub).

This addon is meant to provide TMDb Extended Info dialogs for luc_kodi.
If you later want watched-status integration, replace these stubs with
real Trakt/Kodi library lookups.
"""

def is_movie_watched(tmdb_id):
    return False

def is_episode_watched(tv_tmdb_id, season, episode):
    return False

def get_episode_watched_count(tv_tmdb_id, season=None):
    return 0
