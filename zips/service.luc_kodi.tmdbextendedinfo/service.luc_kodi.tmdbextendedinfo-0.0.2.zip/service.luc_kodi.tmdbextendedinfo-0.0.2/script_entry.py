# -*- coding: utf-8 -*-
import sys
import xbmcaddon
import xbmcgui

from resources.lib.luc_keys import (
    copy_from_luc_kodi_into_service,
    trakt_authorize_pin_flow,
)

def _get_arg(name, default=''):
    for a in sys.argv[1:]:
        if a.startswith(name + '='):
            return a.split('=', 1)[1]
    return default

def run():
    action = _get_arg('action', '')
    if action == 'copy_from_luc_kodi':
        ok, msg = copy_from_luc_kodi_into_service()
        xbmcgui.Dialog().ok('TMDb Extended Info', msg)
        return
    if action == 'auth_trakt':
        ok, msg = trakt_authorize_pin_flow()
        xbmcgui.Dialog().ok('TMDb Extended Info', msg)
        return

    xbmcgui.Dialog().ok('TMDb Extended Info', 'No action specified.')

if __name__ == '__main__':
    run()
