# -*- coding: utf-8 -*-
"""
	luc_kodi Add-on
	Rotación de pósters (TMDb)

	Alterna entre los pósters alternativos que TMDb tiene para cada contenido,
	usando ventanas de tiempo deterministas (3 / 6 / 12 / 24 horas).

	Diseño:
	- 'posters_all' lo rellena el indexer de TMDb (indexers/tmdb.py) a partir de
	  la misma petición de metadatos (append_to_response=images), así que NO hay
	  peticiones HTTP extra: la rotación es solo aritmética local.
	- La selección es determinista: índice = (tmdb_id + ventana_de_tiempo +
	  offset_de_arranque) % N. Con esto todos los widgets/listas/ventanas Bingie
	  muestran el MISMO póster para el mismo título durante toda la ventana, y al
	  expirar la ventana cada título avanza una posición (cambio garantizado si N>=2).
	- Además del tiempo, los pósters cambian al INICIAR Kodi: el servicio fija un
	  offset de arranque pseudoaleatorio (set_boot_offset) que se mezcla en la
	  semilla, así que reiniciar también refresca la parrilla.
	- El offset por tmdb_id evita que todos los títulos "arranquen" en el mismo
	  índice; la parrilla se ve variada desde el primer momento.
	- Si la opción está desactivada, no hay lista o algo falla, se devuelve el
	  póster original sin tocar: la función es 100% inocua.
"""

import time
from resources.lib.modules import control

getSetting = control.setting

_INTERVALS = (3, 6, 12, 24) # horas; índice = setting 'poster.rotation.interval'

# Caché de configuración con TTL corto: control.setting() parsea el JSON completo
# de settings (window property) en CADA llamada. Un directorio de 200 ítems haría
# 400+ parseos. Con este TTL de 5s todo el directorio se resuelve con UNA lectura,
# y un cambio de ajustes se refleja como mucho 5 segundos después (con
# reuseLanguageInvoker el módulo persiste, así que el TTL es imprescindible:
# una caché sin caducidad congelaría el ajuste hasta reiniciar Kodi).
_conf_cache = {'ts': 0.0, 'enabled': False, 'hours': 24}
_CONF_TTL = 5.0

def _conf():
	now = time.time()
	if now - _conf_cache['ts'] > _CONF_TTL:
		try: _conf_cache['enabled'] = getSetting('poster.rotation') == 'true'
		except: _conf_cache['enabled'] = False
		try: _conf_cache['hours'] = _INTERVALS[int(getSetting('poster.rotation.interval') or '3')]
		except: _conf_cache['hours'] = 24
		_conf_cache['ts'] = now
	return _conf_cache


def enabled():
	return _conf()['enabled']


def interval_hours():
	return _conf()['hours']


# Offset de arranque: además de las ventanas de tiempo, queremos que los pósters
# cambien cada vez que se inicia Kodi. Guardamos un valor por sesión en una
# propiedad de la ventana home (homeWindow) y lo mezclamos en la semilla. El
# servicio (service.py) lo fija una vez al arrancar; aquí solo se lee. Si por lo
# que sea no está fijado, se cae a 0 y la rotación sigue funcionando por tiempo.
_BOOT_PROP = 'luc_kodi.poster_boot_offset'


def set_boot_offset():
	"""Llamado UNA vez por el servicio al iniciar Kodi. Avanza la rotación una
	cantidad pseudoaleatoria, así que al abrir el plugin tras reiniciar se ven
	pósters distintos aunque no haya cambiado la ventana de tiempo."""
	try:
		import random
		control.homeWindow.setProperty(_BOOT_PROP, str(random.randint(1, 999999)))
	except: pass


def _boot_offset():
	try: return int(control.homeWindow.getProperty(_BOOT_PROP) or 0)
	except: return 0


def rotate(meta, poster):
	"""Devuelve el póster que corresponde a la ventana de tiempo actual + arranque.
	`meta`: dict con (opcionalmente) 'posters_all' y 'tmdb'.
	`poster`: el póster ya elegido por la lógica normal (fallback)."""
	try:
		if not enabled(): return poster
		plist = meta.get('posters_all')
		if not plist or len(plist) < 2: return poster
		bucket = int(time.time() // (interval_hours() * 3600))
		try: seed = int(meta.get('tmdb') or 0)
		except: seed = 0
		return plist[(seed + bucket + _boot_offset()) % len(plist)] or poster
	except: return poster


# ──────────────────────── limpieza semanal de texturas ────────────────────────
# Cada póster rotado es una URL distinta y Kodi lo cachea como una textura nueva
# (Textures13.db + carpeta Thumbnails). Para que el almacenamiento no crezca sin
# límite, una vez por semana se purgan las texturas de image.tmdb.org que lleven
# más de CLEAN_AFTER_DAYS sin usarse. Las texturas en uso (la "generación" actual
# de la rotación, y cualquier póster que el usuario siga viendo) refrescan su
# 'lastused' continuamente, así que NUNCA se borran: solo cae la generación vieja.
# Al volver a mostrarse un título purgado, Kodi simplemente re-descarga el póster.
# Todo vía JSON-RPC (Textures.GetTextures / Textures.RemoveTexture): sin tocar la
# base de datos a mano, compatible con Android/Shield y cualquier plataforma.

CLEAN_AFTER_DAYS = 7
_LASTCLEAN_SETTING = 'poster.rotation.lastclean'

# ─────────────────────────────────────────────────────────────────────────────
#  v1.0.82 — cuando corre la limpieza, y por que ahi
#
#  Hasta la 1.0.81 se comprobaba NADA MAS arrancar el servicio y luego cada
#  hora, con un plazo fijo de 7 dias. Eso tenia dos problemas. El primero es de
#  reloj: si el septimo dia caia en un arranque, la limpieza se ponia a borrar
#  justo encima del precache del catalogo. El segundo es de calibrado: 7 dias
#  sin usarse es generoso para quien guarda arte grande, y no habia forma de
#  ajustarlo.
#
#  Ahora la primera pasada espera MEDIA HORA desde el arranque —para entonces
#  los dos niveles del catalogo llevan una eternidad terminados, tardan
#  segundos— y a partir de ahi se repite cada 24 horas mientras Kodi siga
#  abierto. El umbral de dias lo elige el usuario entre 1, 3 y 7.
#
#  Lo que NO cambia, y conviene tener claro: se borra por fecha de ULTIMO USO,
#  no por fecha de descarga. El arte de los widgets de inicio y de las listas
#  que se abren a diario refresca su 'lastused' en cada arranque, asi que nunca
#  entra. Borrarlo solo serviria para volver a bajarlo. Lo que se va es la cola
#  de lo que se miro una vez al hojear y no se volvio a abrir.
# ─────────────────────────────────────────────────────────────────────────────
CLEAN_BOOT_DELAY_SECONDS = 1800   # media hora desde el arranque
CLEAN_EVERY_SECONDS = 86400       # y a partir de ahi, una vez al dia
_CLEAN_DAYS_SETTING = 'poster.rotation.cleanup.days'
_CLEAN_DAYS_CHOICES = (1, 3, 7)
# Tope de borrados por pasada. Una cola enorme se reparte entre pasadas en vez
# de convertir una en un maraton de JSON-RPC mientras el usuario navega.
CLEAN_MAX_PER_PASS = 1500
# Cada cuantos borrados se cede un instante, para no monopolizar el hilo de
# JSON-RPC de Kodi mientras se esta dibujando una rejilla.
_CLEAN_YIELD_EVERY = 50


def cleanup_enabled():
	try: return getSetting('poster.rotation.cleanup') != 'false' # activada por defecto
	except: return True


def cleanup_days():
	"""Umbral de dias sin usarse. Un ajuste vacio o raro cae a 7, que es lo que
	hacia el addon antes de que esto fuera elegible."""
	# Igual que en tmdb.py: el enum puede guardar el literal ('7') o el indice
	# ('2') segun la plataforma. El literal manda porque es inequivoco; solo si
	# no es un dia valido se interpreta como indice.
	raw = (getSetting(_CLEAN_DAYS_SETTING) or '').strip()
	try:
		n = int(raw)
	except Exception:
		return CLEAN_AFTER_DAYS
	if n in _CLEAN_DAYS_CHOICES: return n
	if 0 <= n < len(_CLEAN_DAYS_CHOICES): return _CLEAN_DAYS_CHOICES[n]
	return CLEAN_AFTER_DAYS


# v1.0.74 — proveedores cuyas texturas limpia el janitor. Antes solo miraba
# image.tmdb.org y las de fanart.tv se quedaban para siempre, aunque el
# contador de espacio en disco si las cuenta. Se limpian las mismas que se
# cuentan, o el informe y la limpieza dicen cosas distintas.
_JANITOR_HOSTS = ('image.tmdb.org/t/p/', 'fanart.tv/')


def clean_texture_cache(days=CLEAN_AFTER_DAYS):
	"""Borra las texturas de image.tmdb.org sin usar desde hace `days` días.
	Devuelve el número de texturas eliminadas."""
	from json import dumps as jsdumps, loads as jsloads
	from datetime import datetime, timedelta
	import os
	removed = 0
	freed = 0
	phantom = 0
	# Raiz del Thumbnails de Kodi, para poder medir lo que se libera y para
	# detectar las filas sin fichero. Si no se puede resolver, se sigue
	# borrando igual: la medida es informativa, no condiciona nada.
	try:
		from resources.lib.modules.cache_footprint import _thumb_root
		thumb_root = _thumb_root()
	except Exception:
		thumb_root = None
	try:
		# Se pide sin filtro y se recorta en Python: un solo viaje por JSON-RPC
		# para los dos proveedores, y el 'contains' de Kodi deja de estar en la
		# ecuacion si algun dia tropieza con una URL rara.
		query = {'jsonrpc': '2.0', 'id': 1, 'method': 'Textures.GetTextures',
				'params': {'properties': ['url', 'lastused', 'cachedurl']}}
		response = jsloads(control.jsonrpc(jsdumps(query)))
		textures = response.get('result', {}).get('textures', []) or []
		textures = [t for t in textures
					if any(h in (t.get('url') or '') for h in _JANITOR_HOSTS)]
		if not textures: return 0
		cutoff = (datetime.now() - timedelta(days=days)).strftime('%Y-%m-%d %H:%M:%S')
		monitor = control.monitor
		import xbmc
		for texture in textures:
			if monitor.abortRequested(): break # no retrasar el apagado de Kodi
			if xbmc.Player().isPlayingVideo(): break # el usuario manda
			if removed >= CLEAN_MAX_PER_PASS: break
			try:
				lastused = texture.get('lastused') or ''
				if not lastused or lastused >= cutoff: continue # en uso o fecha desconocida: no tocar
				# Filas sin fichero en disco. Kodi apunta la URL de todo lo que
				# un widget menciona aunque nunca llegue a pintarse, asi que en
				# una pantalla de inicio cargada de widgets son MILES: medidas
				# en un aparato real, 4645 filas frente a 284 ficheros. No
				# ocupan disco, pero preguntar por cada una encarece la pasada
				# entera, asi que se saltan y se cuentan aparte.
				size = 0
				cached = texture.get('cachedurl') or ''
				if thumb_root and cached:
					try:
						size = os.path.getsize(os.path.join(thumb_root, cached.replace('/', os.sep)))
					except Exception:
						phantom += 1
						continue
				control.jsonrpc(jsdumps({'jsonrpc': '2.0', 'id': 1, 'method': 'Textures.RemoveTexture',
										'params': {'textureid': texture['textureid']}}))
				removed += 1
				freed += size
				if removed % _CLEAN_YIELD_EVERY == 0:
					control.sleep(50)
			except: pass
	except:
		from resources.lib.modules import log_utils
		log_utils.error()
	return removed, freed, phantom


def janitor_service():
	"""Bucle de servicio: comprueba cada hora si toca la limpieza semanal.
	No hace nada si la rotación o la limpieza están desactivadas. Nunca corre
	durante la reproducción de vídeo (mismo criterio que catalog_updater)."""
	import time as _time
	import xbmc
	from resources.lib.modules import log_utils
	monitor = control.monitor
	set_boot_offset() # al iniciar Kodi: avanzar la rotación para que se vean pósters nuevos
	boot_at = _time.time()
	did_boot_clean = False
	while not monitor.abortRequested():
		try:
			# v1.0.74 — la limpieza ya NO depende de que la rotacion de posters
			# este activada. Vivia dentro de este modulo y reutilizaba su
			# enabled(), asi que apagar la rotacion —que ademas viene apagada de
			# fabrica— paraba en silencio la UNICA limpieza automatica de
			# texturas que tiene el addon. Y la paraba justo para quien elige
			# Original, donde la mediana por imagen pasa de 66 KB a 224 y Kodi
			# no vacia esa carpeta jamas por su cuenta. Son dos cosas distintas
			# y ahora se preguntan por separado.
			# v1.0.82 — la primera pasada no se hace hasta pasada media hora del
			# arranque, para no pisar el precache del catalogo; luego una al dia.
			ready = (_time.time() - boot_at) >= CLEAN_BOOT_DELAY_SECONDS
			if cleanup_enabled() and ready:
				try: last = float(getSetting(_LASTCLEAN_SETTING) or 0)
				except: last = 0
				due = (_time.time() - last) >= CLEAN_EVERY_SECONDS
				if (due or not did_boot_clean) and not xbmc.Player().isPlayingVideo():
					days = cleanup_days()
					started = _time.time()
					removed, freed, phantom = clean_texture_cache(days)
					did_boot_clean = True
					control.setSetting(_LASTCLEAN_SETTING, str(int(_time.time())))
					log_utils.log(
						'[ plugin.video.luc_kodi ]  Poster janitor: %s texturas sin usar en %s dias eliminadas, '
						'%.1f MB liberados, %s filas sin fichero saltadas, %.1fs'
						% (removed, days, freed / 1048576.0, phantom, _time.time() - started),
						__name__, log_utils.LOGINFO)
		except: log_utils.error()
		# Mientras no toque la primera pasada se mira cada minuto, para que la
		# media hora se cumpla con precision y no con una hora de retraso.
		if monitor.waitForAbort(60 if not did_boot_clean else 3600): break
