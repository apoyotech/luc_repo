import requests


# Token de DMM: retirado en la v2.0.32. El 11-nov-2026 DMM cerro /api/challenge
# a todo lo que no sea su propia web (commits 88f6193e y cdebe2e3: Sec-Fetch-Site
# same-origin y Cloudflare Turnstile delante). El scraper usa desde entonces el
# Torznab de DMM con la clave de patrocinador (sourcesdir/torrents/dmm.py), y la
# comprobacion de cache de RD ya iba por la API de patrocinadores desde la 2.0.10.


class DMMCache:
	"""Cache de Real-Debrid que DMM ha visto — v2.0.10.

	El 15-oct-2026 DMM cerro /api/availability/check a todo lo que no sea su
	propia web (commit b49f6307, src/utils/ownPageRequest.ts): exige la cabecera
	Sec-Fetch-Site: same-origin que solo pone un navegador, y a cualquier otro
	cliente le responde 403 "This endpoint serves DMM pages only. Tools use the
	sponsor API". El commit cita expresamente python-requests, que es lo que
	usaba esto. No se falsea esa cabecera: es un cierre deliberado y DMM vende
	ese mismo dato en su API de patrocinadores.

	Desde entonces luc_kodi solo pregunta a DMM si el usuario enciende 'Check RD
	cached torrents' (apagado de fabrica desde la v2.0.11) y pone debajo SU clave
	de patrocinador (Accounts > Real-Debrid > DMM API key). Sin clave no se
	hace ninguna peticion y sources.py marca los torrents de RD como
	"unchecked": el propio resolve_magnet de Real-Debrid hace de comprobacion
	al reproducir (anade, mira si esta "ended" en 1,5 s y si no lo borra), y la
	reproduccion pasa a la siguiente fuente.

	check_cache devuelve un dict {hash: ficheros} cuando DMM contesto (vacio =
	no ha visto ninguno cacheado) y None cuando no se le pudo preguntar. Los dos
	casos son distintos y sources.py los trata distinto."""
	sponsor_link = 'https://debridmediamanager.com/api/sponsor/availability'
	timeout = 6.05
	_REFUSED_PROP = 'luc_kodi.dmm_key_refused'
	_MISSING_PROP = 'luc_kodi.dmm_key_missing'

	@staticmethod
	def api_key():
		try:
			from resources.lib.modules.control import setting as getSetting
			return (getSetting('dmm.api_key') or '').strip()
		except Exception:
			return ''

	def _key_refused(self, status, body):
		"""Clave mala o patrocinio caducado: log siempre, aviso al usuario una
		vez por sesion de Kodi para no repetirlo en cada episodio."""
		from resources.lib.modules import control, log_utils
		log_utils.log('DMM sponsor availability: la clave fue rechazada (HTTP %s) | body[:300]=%r' % (status, body), __name__, log_utils.LOGWARNING)
		try:
			if control.homeWindow.getProperty(self._REFUSED_PROP) != 'true':
				control.homeWindow.setProperty(self._REFUSED_PROP, 'true')
				control.notification(message=48148)
		except Exception:
			pass

	def key_missing(self):
		"""v2.0.11: 'Check RD cached torrents' encendido sin clave. No se pregunta a
		nadie (las fuentes salen unchecked) y se avisa una vez por sesion de Kodi
		de que el ajuste necesita la clave de patrocinador."""
		from resources.lib.modules import control, log_utils
		log_utils.log('DMM: Check RD cached torrents esta encendido sin clave de patrocinador; fuentes de RD unchecked', __name__, log_utils.LOGINFO)
		try:
			if control.homeWindow.getProperty(self._MISSING_PROP) != 'true':
				control.homeWindow.setProperty(self._MISSING_PROP, 'true')
				control.notification(message=48149)
		except Exception:
			pass

	def check_cache(self, unchecked_hashes_chunk, imdb): # Sponsor API: max 100 hashes per request, 25 calls/min per address.
		from resources.lib.modules import log_utils
		key = self.api_key()
		if not key: return None
		hashes = [i.lower() for i in unchecked_hashes_chunk if len(i) == 40]
		if not hashes: return {}
		data = {'service': 'rd', 'hashes': hashes}
		# imdbId es opcional en la API de patrocinadores y acota la respuesta a
		# ese titulo. Si no tiene la forma que exige (/^tt\d+$/) daria 400, asi
		# que entonces se pregunta solo por los hashes.
		if imdb and str(imdb).startswith('tt') and str(imdb)[2:].isdigit():
			data['imdbId'] = str(imdb)
		headers = {'x-api-key': key, 'Accept': 'application/json'}
		try: results = requests.post(self.sponsor_link, json=data, headers=headers, timeout=self.timeout)
		except requests.exceptions.RequestException as e:
			log_utils.log('DMM sponsor availability: fallo de red (%s: %s)' % (type(e).__name__, e), __name__, log_utils.LOGDEBUG)
			return None
		status = results.status_code
		body = (results.text or '')[:300].replace('\n', ' ').replace('\r', ' ')
		if status in (401, 403):
			self._key_refused(status, body)
			return None
		try: payload = results.json()
		except Exception: payload = None
		available_hashes = payload.get('available') if isinstance(payload, dict) else None
		if status != 200 or available_hashes is None:
			# 429 = mas de 25 llamadas por minuto desde esta IP; cualquier otra
			# cosa es una anomalia del servidor. En los dos casos el lote queda
			# "unchecked", no se pierde.
			level = log_utils.LOGDEBUG if status == 429 else log_utils.LOGWARNING
			log_utils.log('DMM sponsor availability: HTTP %s | Content-Type=%s | body[:300]=%r'
					% (status, results.headers.get('Content-Type', ''), body), __name__, level)
			return None
		try: return {file['hash'].lower(): file['files'] for file in available_hashes if 'hash' in file}
		except Exception:
			log_utils.log('DMM sponsor availability: respuesta con forma inesperada en "available"', __name__, log_utils.LOGWARNING)
			return None
