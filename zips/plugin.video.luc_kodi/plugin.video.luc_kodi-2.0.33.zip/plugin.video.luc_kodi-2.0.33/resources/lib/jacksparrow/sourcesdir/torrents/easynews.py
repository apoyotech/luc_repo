
"""
	jacksparrowscrapers Project - easynews (Easynews Global Search / HTTP)

	v1.0.52: Easynews como 5º proveedor premium.

	IMPORTANTE - Easynews NO es un debrid:
	  Es un proveedor de Usenet con buscador propio que devuelve enlaces HTTP
	  DIRECTOS a ficheros ya existentes en sus servidores. No hay magnet, no
	  hay hash de torrent, no hay espera de caché: el enlace es reproducible
	  al instante. Por eso los items salen con direct=True y saltan el
	  pipeline de comprobacion de caché de debrid en sources.py.

	IMPORTANTE - Easynews es de CUOTA MEDIDA:
	  Cada byte reproducido consume el cupo mensual HTTP del usuario
	  (Classic 20 GB, Plus 40 GB, Big Gig 150 GB). Por eso este scraper
	  aplica un tope de tamaño por fichero (easynews.max_size, GB) que por
	  defecto NO es 0. Sin ese tope, un remux 4K se come el plan entero.

	API (verificado contra la implementación de referencia de AIOStreams,
	builtins/easynews-search, julio 2026):
	  V2  GET https://members.easynews.com/2.0/search/solr-search/
	      hasta 250 resultados por página (pby). Endpoint veterano y estable.
	  V3  GET https://members.easynews.com/3.0/api/search
	      ignora pby/dni: siempre 100 por página. Mismos metadatos.
	  Auth: HTTP Basic (usuario:contraseña de Easynews) en cabecera.
	  Respuesta: {'data': [...], 'downURL':, 'dlFarm':, 'dlPort':, 'numPages':}
	  Campos por item: hash/'0', id (sufijo de 4 chars del hash en la URL de
	  descarga), fn/'10' (nombre sin extensión), '11' (extensión), rawSize,
	  '14' (duración), alangs/audio_tracks, slangs, acodec, vcodec,
	  xres, yres, bps, passwd, type, virus.

v2.0.13 -- el usuario de Fire TV Cube: Easynews activado y configurado, 0
resultados y NINGUNA linea en el log, ni de error ni de "0 resultados". Es
decir: Easynews contestaba con ficheros y el bucle los tiraba todos en
silencio. Lo que se leia era el formato de la 2.0 con claves numericas; la
implementacion de referencia (AIOStreams, que usa la 3.0 por defecto desde
julio de 2026) lee tambien:
  - la extension en 'extension' (la 3.0 no trae '11'), con o sin punto;
  - la duracion en 'runtime', en segundos;
  - el tamaño en 'rawSize', 'size' o '4' (este ultimo como texto, "1.4 GB");
  - items como LISTA en vez de diccionario (0 hash, 4 tamaño, 6 asunto,
    10 nombre, 11 extension, 14 duracion).
Ahora se normaliza cada item a un mismo dict antes de filtrar, y se escribe en
el log (debug) cuantos llegaron y por que se descartaron, como hace AIOStreams.
Una respuesta con el cuerpo vacio (Easynews corta asi las busquedas por encima
de dos a la vez en la 2.0) se reintenta una vez.

v2.0.19 -- pocos resultados frente a Umbrella (6.7.98, misma cuenta). Lo que
Umbrella hace distinto y aqui se adopta:
  - la 2.0 se pide en su ruta /advanced con st=adv y pby=1000 (una sola
    peticion trae hasta 1000 ficheros; la raiz con st=basic se quedaba en 250).
    Si /advanced no contesta con JSON se repite por la raiz, como antes;
  - las PELICULAS se buscan solo por el titulo, sin el año: Easynews exige
    cada palabra de 'gps' en el nombre, y un "Titulo 2026" tiraba todo lo
    publicado como 2025 o sin año. El año se comprueba despues con +-1 año;
  - el apostrofo se quita en vez de volverse un espacio: "Grey's Anatomy"
    buscaba las palabras "Grey" y "s" y no casaba con Greys.Anatomy;
  - el tope de 80 resultados (v1.0.54, por el SystemError del AST al releer
    repr() de rel_src) sobraba desde la v1.0.91 (rel_src es JSON+zlib): 200;
  - resolve() sigue la redireccion de Easynews hasta su servidor de descarga y
    entrega a Kodi esa URL final, que no necesita credenciales; si no se
    puede, la de siempre con la cabecera Basic pegada.
"""

import re
import time
import requests
from base64 import b64encode
from urllib.parse import quote, urlparse
from resources.lib.jacksparrow import source_utils
from resources.lib.jacksparrow.control import setting as getSetting

BASE_LINK = 'https://members.easynews.com'
SEARCH_V2 = '/2.0/search/solr-search/'
SEARCH_V2_ADV = '/2.0/search/solr-search/advanced'
SEARCH_V3 = '/3.0/api/search'
# v2.0.19: the request Umbrella makes (6.7.98), plus vv=1 for Easynews' own video metadata
ADV_PARAMS = {'st': 'adv', 'sb': 1, 'fex': 'm4v,3gp,mov,divx,xvid,wmv,avi,mpg,mpeg,mp4,mkv,avc,flv,webm',
			  'fty[]': 'VIDEO', 'spamf': 1, 'u': '1', 'gx': 1, 'pno': 1, 'sS': 3, 'vv': 1, 'pby': 1000,
			  's1': 'relevance', 's1d': '-', 's2': 'dsize', 's2d': '-', 's3': 'dtime', 's3d': '-'}


def easynews_query(text):
	"""v2.0.19: the words Easynews is asked for. Apostrophes go (Grey's -> Greys, as
	release names write them); any other sign becomes a space."""
	text = re.sub(r"['’`´]", '', text or '')
	return re.sub(r'\s+', ' ', re.sub(r'[^A-Za-z0-9\s\.\-]+', ' ', text)).strip()

# Extensiones de vídeo aceptadas. Easynews indexa de todo (rar, par2, nfo...).
VIDEO_EXT = (
	'.mkv', '.mp4', '.avi', '.m4v', '.mov', '.wmv', '.mpg', '.mpeg',
	'.divx', '.xvid', '.flv', '.webm', '.avc', '.3gp', '.m2ts', '.ts',
)


def easynews_bytes(size):
	"""v2.0.13: tamaño en bytes desde un numero o un texto como '1.4 GB'."""
	if isinstance(size, (int, float)): return int(size)
	m = re.match(r'\s*([\d.,]+)\s*([KMGT]?)i?B?\s*$', str(size or ''), re.IGNORECASE)
	if not m: return 0
	try: n = float(m.group(1).replace(',', '.'))
	except ValueError: return 0
	return int(n * 1024 ** ' KMGT'.index((m.group(2) or ' ').upper()))


class source:
	timeout = 20
	priority = 1
	pack_capable = False  # Easynews indexa ficheros sueltos, no packs
	hasMovies = True
	hasEpisodes = True

	# v1.0.54: tope de items devueltos. La API 2.0 da hasta 250 por pagina y
	# cada item lleva una URL larga; sin tope, el blob repr(sources) que se
	# guarda en rel_src era el mayor del addon con diferencia y disparaba el
	# SystemError del AST al releerlo. 80 sobra para el picker.
	# v2.0.19: rel_src es JSON+zlib desde la v1.0.91 (blobcodec), sin AST: 200.
	MAX_RESULTS = 200

	def __init__(self):
		self.user_agent = 'luc_kodi for Kodi'
		self.username = getSetting('easynews.username')
		self.password = getSetting('easynews.password')
		self.api_version = getSetting('easynews.api_version') or '2.0'
		self.moderation = 1 if getSetting('easynews.moderation') == 'true' else 0
		try:
			self.max_size = int(getSetting('easynews.max_size') or 20)
		except Exception:
			self.max_size = 20
		self.language = ['en']
		self.auth = self._basic_auth()

	def _basic_auth(self):
		if not self.username or not self.password:
			return None
		try:
			raw = ('%s:%s' % (self.username, self.password)).encode('utf-8')
			return 'Basic %s' % b64encode(raw).decode('utf-8')
		except Exception:
			return None

	def _search_params(self, query, page=1, v3=None):
		params = {
			'gps': query,          # consulta por palabras clave
			'pno': str(page),      # número de página
			'u': '1',              # dedupe de posts idénticos en servidor
			'safeO': str(self.moderation),
			's1': 'relevance',     # orden primario
			's1d': '-',            # descendente
			'fty[]': 'VIDEO',      # sólo vídeo
		}
		if v3 is None: v3 = self.api_version == '3.0'
		if not v3:
			# La 3.0 ignora todos los parámetros de tamaño de página.
			params.update({
				'pby': '250',      # tope real de la 2.0
				'fly': '2',        # respuesta JSON
				'sb': '1',
				'st': 'basic',
				'chxu': '1',
				'chxgx': '1',
				'vv': '1',         # metadatos de vídeo (codecs, resolución)
			})
		return params

	def _get_advanced(self, query, headers):
		"""v2.0.19: the 2.0 search on its /advanced path, up to 1000 files in one answer.
		-> the JSON dict, 'auth' on 401/403, or None (then the plain 2.0 path is asked)."""
		from resources.lib.jacksparrow import log_utils
		params = dict(ADV_PARAMS)
		params['gps'] = query
		params['safeO'] = self.moderation
		try:
			r = requests.get('%s%s' % (BASE_LINK, SEARCH_V2_ADV), params=params, headers=headers, timeout=self.timeout)
		except Exception as e:
			log_utils.log('EASYNEWS: advanced search failed (%s), trying the plain one' % e.__class__.__name__, level=log_utils.LOGDEBUG)
			return None
		if r.status_code in (401, 403): return 'auth'
		if r.status_code == 200 and (r.content or b'').strip():
			try:
				res = r.json()
				if isinstance(res, dict) and 'data' in res: return res
			except Exception:
				pass
		log_utils.log('EASYNEWS: advanced search gave HTTP %s without results data, trying the plain one' % r.status_code, level=log_utils.LOGDEBUG)
		return None

	def _get(self, query, force_v2=False):
		headers = {'User-Agent': self.user_agent, 'Authorization': self.auth,
				   'Accept': 'application/json, text/javascript, */*; q=0.9'}
		v3 = self.api_version == '3.0' and not force_v2
		if not v3:
			res = self._get_advanced(query, headers)
			if res == 'auth':
				from resources.lib.jacksparrow import log_utils
				log_utils.log('EASYNEWS: 401 - credenciales inválidas', level=log_utils.LOGWARNING)
				return None
			if res is not None: return res
		path = SEARCH_V3 if v3 else SEARCH_V2
		params = self._search_params(query, v3=v3)
		for attempt in (1, 2):
			r = requests.get('%s%s' % (BASE_LINK, path), params=params,
							 headers=headers, timeout=self.timeout)
			if r.status_code != 200 or (r.content or b'').strip(): break
			# v2.0.13: cuerpo vacio = Easynews corto la busqueda (tope de dos a la vez en la 2.0)
			if attempt == 1: time.sleep(0.5)
		if r.status_code == 200 and not (r.content or b'').strip():
			from resources.lib.jacksparrow import log_utils
			log_utils.log('EASYNEWS: empty answer for "%s" (API %s; the 2.0 API drops searches beyond two at once)'
						  % (query, self.api_version), level=log_utils.LOGWARNING)
			return None
		if r.status_code in (401, 403):
			from resources.lib.jacksparrow import log_utils
			log_utils.log('EASYNEWS: 401 - credenciales inválidas', level=log_utils.LOGWARNING)
			return None
		if r.status_code != 200:
			from resources.lib.jacksparrow import log_utils
			log_utils.log('EASYNEWS: HTTP %s -- %s' % (r.status_code, (r.text or '')[:200]),
						  level=log_utils.LOGWARNING)
			return None
		return r.json()

	@staticmethod
	def _normalize(raw):
		"""v2.0.13: un item de cualquier formato (lista, dict de la 2.0 con claves
		numericas, dict de la 3.0 con nombres) a un dict con las claves de la 2.0
		que lee el resto del scraper ('0', '10', '11' con punto, '14', rawSize)."""
		if isinstance(raw, (list, tuple)):
			if len(raw) < 12: return None
			item = {'0': raw[0], '10': raw[10], '11': raw[11]}
			if len(raw) > 4: item['4'] = raw[4]
			if len(raw) > 6: item['6'] = raw[6]
			if len(raw) > 14: item['14'] = raw[14]
			raw = item
		if not isinstance(raw, dict): return None
		item = dict(raw)
		ext = str(item.get('11') or item.get('extension') or item.get('ext') or '').strip()
		item['11'] = ('.' + ext.lstrip('.').lower()) if ext else ''
		item['10'] = item.get('10') or item.get('fn') or item.get('filename') or ''
		if item.get('14') is None and item.get('runtime') is not None: item['14'] = item.get('runtime')
		if not item.get('rawSize'):
			size = item.get('size') if item.get('size') is not None else item.get('4')
			item['rawSize'] = easynews_bytes(size)
		return item

	@staticmethod
	def _dl_url(item, down_url, dl_farm, dl_port):
		"""Reconstruye la URL de descarga directa.

		Formato: {downURL}/{dlFarm}/{dlPort}/{hash}{ext}/{filename}{ext}
		En el formato antiguo (array) item['0'] ya trae el hash completo con
		su sufijo. En el formato objeto, 'hash' viene pelado y 'id' aporta
		el sufijo de 4 caracteres; hay que concatenarlos.
		"""
		full_hash = item.get('0') or ''
		if not full_hash:
			base_hash = str(item.get('hash') or '')
			sig = item.get('id')
			full_hash = '%s%s' % (base_hash, str(sig) if sig is not None else '')
		if not full_hash:
			return None
		ext = item.get('11') or item.get('ext') or ''
		fn = item.get('10') or item.get('fn') or ''
		if not ext or not fn:
			return None
		return down_url + quote('/%s/%s/%s%s/%s%s' % (dl_farm, dl_port, full_hash, ext, fn, ext))

	@staticmethod
	def _duration_secs(raw):
		"""Segundos de una duracion de Easynews: numero (la 3.0, 'runtime'),
		'1h 52m', '52m 10s', '45s', '1:52:10' o '52:10'. None si no se entiende."""
		if raw is None or raw == '':
			return None
		if isinstance(raw, (int, float)):
			return float(raw)
		raw = str(raw).strip().lower()
		if re.match(r'^\d+(?:\.\d+)?$', raw):
			return float(raw)
		m = re.match(r'^(?:(\d+):)?(\d{1,2}):(\d{2})$', raw)
		if m:
			return int(m.group(1) or 0) * 3600 + int(m.group(2)) * 60 + int(m.group(3))
		parts = re.findall(r'(\d+(?:\.\d+)?)\s*([hms])', raw)
		if not parts:
			return None
		return sum(float(n) * {'h': 3600, 'm': 60, 's': 1}[u] for n, u in parts)

	# v2.0.32 (como Dex Hub, informe de 12-nov-2026): una pelicula de menos de
	# 20 min es un extra, un trailer o una muestra; un episodio, de menos de 5.
	# Antes era 6 min para todo y en las peliculas se colaban los extras.
	MIN_MOVIE_SECS = 1200
	MIN_EPISODE_SECS = 300

	@classmethod
	def _duration_ok(cls, raw, movie=False):
		"""Descarta muestras y extras por su duracion (sin duracion, se deja)."""
		secs = cls._duration_secs(raw)
		if secs is None or secs <= 0:
			return True
		return secs >= (cls.MIN_MOVIE_SECS if movie else cls.MIN_EPISODE_SECS)

	def sources(self, data, hostDict):
		sources = []
		if not data:
			return sources
		if not self.auth:
			return sources
		sources_append = sources.append
		from resources.lib.jacksparrow import log_utils
		try:
			title = data['tvshowtitle'] if 'tvshowtitle' in data else data['title']
			title = title.replace('&', 'and').replace('Special Victims Unit', 'SVU').replace('/', ' ')
			aliases = data['aliases']
			episode_title = data['title'] if 'tvshowtitle' in data else None
			year = data['year']
			if 'tvshowtitle' in data:
				variants = source_utils.episode_variants(data) # TheTVDB SxxEyy when it differs from TMDb; absolute number for anime
			else:
				# v2.0.19: movies by title only (as Umbrella); the year is checked
				# afterwards, one year either side (see years below)
				variants = [('', year, None)]
			years = None
			if 'tvshowtitle' not in data:
				try: years = [str(int(year) - 1), str(year), str(int(year) + 1)]
				except (TypeError, ValueError): years = None
			if 'timeout' in data:
				self.timeout = int(data['timeout'])

			tagged = []
			down_url, dl_farm, dl_port = None, None, None
			# v2.0.31: talk shows are posted under the presenter's name; when the
			# title finds nothing for the air date, the presenter is searched too
			host = source_utils.host_name(title) if data.get('air_date_search') else ''
			for suffix, hdlr, absolute in variants:
				query = easynews_query('%s %s' % (title, suffix))
				results = self._get(query)
				files = (results or {}).get('data') or []
				if not files and host and re.match(r'\d{4}\.\d{2}\.\d{2}$', hdlr or ''):
					log_utils.log('EASYNEWS: 0 resultados para "%s"' % query, level=log_utils.LOGDEBUG)
					query = easynews_query('%s %s' % (host, suffix))
					results = self._get(query)
					files = (results or {}).get('data') or []
					if files:
						aliases = list(source_utils.aliases_to_array(aliases) or []) + [host]
				if not files:
					log_utils.log('EASYNEWS: 0 resultados para "%s"' % query, level=log_utils.LOGDEBUG)
					continue
				if down_url is None: # download host details come with every search; the first answer is kept
					down_url = results.get('downURL') or ('%s/dl' % BASE_LINK)
					dl_farm = results.get('dlFarm') or 'auto'
					dl_port = results.get('dlPort') or 'auto'
				tagged.extend((item, hdlr, absolute) for item in files)
			if not tagged:
				return sources
			undesirables = source_utils.get_undesirables()
			check_foreign_audio = source_utils.check_foreign_audio()
		except Exception:
			source_utils.scraper_error('EASYNEWS')
			return sources

		seen = set()
		skipped = {}  # v2.0.13: por que se descarta cada item, para el log
		def skip(reason):
			skipped[reason] = skipped.get(reason, 0) + 1
		for raw_item, hdlr, absolute in tagged:
			try:
				item = self._normalize(raw_item)
				if item is None:
					skip('format'); continue
				# Descartes baratos primero.
				if item.get('type') and str(item.get('type')).upper() != 'VIDEO':
					skip('not video'); continue
				if item.get('virus'):
					skip('virus'); continue
				if item.get('passwd'):
					skip('password'); continue  # post protegido con contraseña, no reproducible
				ext = item.get('11') or ''
				if ext.lower() not in VIDEO_EXT:
					skip('extension %s' % (ext or '(none)')); continue
				if not self._duration_ok(item.get('14') or item.get('duration'), movie='tvshowtitle' not in data):
					skip('sample'); continue

				fn = item.get('10') or ''
				if not fn:
					skip('no name'); continue
				name = source_utils.clean_name(fn)
				if fn in seen:
					skip('duplicate'); continue
				if years:
					if not source_utils.check_title(title, aliases, name, hdlr, year, years):
						skip('other title'); continue
				elif not source_utils.check_episode(title, aliases, name, hdlr, year, absolute):
					skip('other title'); continue
				seen.add(fn)
				name_info = source_utils.info_from_name(name, title, year, hdlr, episode_title)
				if source_utils.remove_lang(name_info, check_foreign_audio):
					skip('language'); continue
				if undesirables and source_utils.remove_undesirables(name_info, undesirables):
					skip('undesirable'); continue

				url = self._dl_url(item, down_url, dl_farm, dl_port)
				if not url:
					skip('no link'); continue

				# Tamaño y tope de cuota.
				try:
					raw_size = int(item.get('rawSize') or 0)
				except Exception:
					raw_size = 0
				if self.max_size and raw_size and raw_size > (self.max_size * 1073741824):
					skip('over max size'); continue

				quality, info = source_utils.get_release_quality(name_info, url)
				# Easynews reporta la resolucion real: manda sobre el nombre.
				#
				# v1.0.56: SE MIDE POR ANCHO, no por alto. Una pelicula en
				# 2.39:1 se codifica como 1920x800 (1080p) o 3840x1600 (4K):
				# usando el alto, un 1080p cinematografico caia a "720p" y un
				# 4K a "1080p". El ancho es estable para cada escalon.
				# Solo se pisa el nombre si Easynews da una resolucion creible.
				try:
					xres = int(item.get('xres') or 0)
					yres = int(item.get('yres') or 0)
					if xres >= 3000 or yres >= 2000:
						quality = '4K'
					elif xres >= 1800 or yres >= 1000:
						quality = '1080p'
					elif xres >= 1200 or yres >= 700:
						quality = '720p'
					elif xres > 0 or yres > 0:
						quality = 'SD'
				except Exception:
					pass
				info += [t for t in source_utils.get_extra_tags(name) if t not in info]
				# Codecs reportados por el propio Easynews.
				vcodec = (item.get('vcodec') or '').upper()
				if vcodec in ('HEVC', 'H265', 'X265') and 'HEVC' not in info:
					info.append('HEVC')
				elif vcodec in ('AV1',) and 'AV1' not in info:
					info.append('AV1')
				acodec = (item.get('acodec') or '').upper()
				if acodec and acodec not in info and acodec in ('EAC3', 'AC3', 'AAC', 'DCA', 'TRUEHD', 'FLAC'):
					info.append(acodec.replace('DCA', 'DTS'))

				dsize = 0
				try:
					size = '%.2f GB' % (float(raw_size) / 1073741824)
					dsize, isize = source_utils._size(size)
					info.insert(0, isize)
				except Exception:
					pass
				info = ' | '.join(info)

				# Idioma de audio reportado por Easynews (alangs / audio_tracks).
				alangs = item.get('audio_tracks') or item.get('alangs') or item.get('alang') or ''
				if isinstance(alangs, list):
					alangs = ','.join([str(x) for x in alangs])

				# v1.0.53: la URL se guarda LIMPIA. La cabecera Basic se añade
				# en resolve(), en el momento de reproducir. Antes se pegaba
				# aquí y acababa en la caché rel_src (repr(sources)), en el log
				# de Kodi y en el menú contextual de descarga: la contraseña
				# del usuario, en base64 reversible, en tres sitios en disco.
				# v1.0.54: source='usenet', NO 'Easynews'. La skin dibuja DOS
				# etiquetas superpuestas cuando source no contiene USENET /
				# TORRENT / DIRECT / LOCAL / CLOUD (source_results.xml linea
				# 735 anade "HOSTER | SCORE" encima de la linea normal). Con
				# 'usenet' solo se pinta una, y ademas los items se agrupan
				# con el resto de usenet en sources.group.sort.
				sources_append({
					'provider': 'easynews', 'source': 'usenet', 'debrid': 'Easynews',
					'seeders': '', 'hash': '', 'name': name, 'name_info': name_info,
					'quality': quality, 'language': 'en', 'url': url, 'info': info,
					'direct': True, 'debridonly': True, 'size': dsize,
					'tracker': 'easynews', 'alangs': alangs,
				})
			except Exception:
				source_utils.scraper_error('EASYNEWS')
		log_utils.log('EASYNEWS: %d files from Easynews (API %s), %d kept; skipped: %s'
					  % (len(tagged), self.api_version, len(sources),
						 ', '.join('%s %d' % (k, v) for k, v in sorted(skipped.items())) or 'none'),
					  level=log_utils.LOGDEBUG)
		if len(sources) > self.MAX_RESULTS:
			# Los mejores primero: la API ya ordena por relevancia, y dentro
			# de eso preferimos el de mayor calidad/tamano util.
			_rank = {'4K': 0, '1080p': 1, '720p': 2, 'SD': 3}
			sources.sort(key=lambda k: (_rank.get(k['quality'], 4), -k.get('size', 0)))
			sources = sources[:self.MAX_RESULTS]
		return sources

	def sources_packs(self, data, hostDict, search_series=False, total_seasons=None, bypass_filter=False):
		return []

	def resolve(self, url):
		"""Adjunta la cabecera Basic justo antes de reproducir.

		Kodi acepta cabeceras HTTP pegadas a la URL con "|". Al hacerlo
		aquí y no en sources(), las credenciales nunca se escriben en la
		caché de fuentes, ni en el log, ni en el item de descarga.
		Idempotente: si la URL ya trae la cabecera, se devuelve tal cual.
		"""
		if not url:
			return None
		if '|Authorization=' in url:
			return url
		if not url.startswith(BASE_LINK):
			# No es un enlace de Easynews: no le pegamos credenciales.
			return url
		auth = self.auth or self._basic_auth()
		if not auth:
			return None
		final = self._final_url(url, auth)
		if final:
			return final
		return '%s|Authorization=%s' % (url, quote(auth))

	def _final_url(self, url, auth):
		"""v2.0.19: the link of Easynews' download server, the way Umbrella resolves it.
		members.easynews.com/dl/... answers with a redirect to the server that holds the
		file. requests drops the Authorization header when the redirect changes host, so
		an answer of 200/206 there proves the final URL plays WITHOUT credentials: Kodi
		gets that one, and the password no longer travels in the URL (nor in kodi.log).
		Only the first byte is asked for (Range), so the monthly quota is not touched.
		None (and the header URL as before) when there is no redirect to another host,
		or anything fails."""
		r = None
		try:
			r = requests.get(url, headers={'Authorization': auth, 'User-Agent': self.user_agent, 'Range': 'bytes=0-0'},
							 stream=True, allow_redirects=True, timeout=15)
			if r.status_code not in (200, 206): return None
			final = r.url or ''
			if not final.startswith('http'): return None
			if urlparse(final).netloc.lower() == urlparse(url).netloc.lower(): return None
			return final
		except Exception:
			from resources.lib.jacksparrow import log_utils
			log_utils.log('EASYNEWS: could not follow the download link, playing it with the header', level=log_utils.LOGDEBUG)
			return None
		finally:
			try:
				if r is not None: r.close()
			except Exception: pass
