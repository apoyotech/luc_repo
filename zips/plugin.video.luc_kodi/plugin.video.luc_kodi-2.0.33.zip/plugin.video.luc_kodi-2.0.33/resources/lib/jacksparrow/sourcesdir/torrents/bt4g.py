"""
	jacksparrowscrapers Project
"""

import re
from html import unescape
from urllib.parse import quote
from resources.lib.jacksparrow import cache
from resources.lib.jacksparrow import client
from resources.lib.jacksparrow import source_utils
from resources.lib.jacksparrow import workers


# v2.0.32 — BT4G, buscador de la red DHT (no es un tracker: recoge el nombre, el
# tamano y el magnet de los torrents que se ven en la DHT). Trae hashes que no
# estan en 1337x, TPB ni los agregadores, y muchos ya estan en la cache de los
# debrid porque otra persona los anadio.
#
# Se lee su RSS de busqueda, como el motor bt4g de SearXNG (searx/engines/
# bt4g.py): /search?q=...&category=movie&orderby=seeders&p=1&page=rss. Cada
# <item> trae el magnet en <link> y el tamano en <description> (sin seeders;
# para un debrid cuenta el hash). Ordenado por seeders: lo que tiene enjambre
# vivo es lo que mas suele estar cacheado.
#
# En la DHT hay nombres falsos y basura: ademas del filtro de titulo/ano/
# episodio de siempre, fuera lo que pesa menos de MIN_MB y lo que no parece
# video. Si Cloudflare corta el paso, el log lo dice y no se cachea esa
# direccion como buena.
_ITEM_RE = re.compile(r'<item>(.*?)</item>', re.S | re.I)
_TAG_RE = {t: re.compile(r'<%s>(.*?)</%s>' % (t, t), re.S | re.I) for t in ('title', 'link', 'description', 'guid')}
_HASH_RE = re.compile(r'btih:([a-fA-F0-9]{40})', re.I)
_SIZE_RE = re.compile(r'(\d+(?:[.,]\d+)?)\s*([KMGT]i?B)\b', re.I)
_CF_RE = re.compile(r'Just a moment|cf-chl|challenge-platform|Attention Required', re.I)
_NOT_VIDEO = re.compile(r'\.(?:exe|apk|zip|rar|iso|pdf|epub|mp3|flac)$', re.I)
MIN_MB = 150
MAX_GB = 150     # una pelicula o un episodio no pasan de aqui (un UHD remux ronda 50-100 GB); los packs no tienen tope


def _tag(block, name):
	m = _TAG_RE[name].search(block)
	if not m: return ''
	text = m.group(1).strip()
	if text.startswith('<![CDATA[') and text.endswith(']]>'):
		text = text[9:-3]
	return unescape(text).strip()


def _size_text(desc):
	"""'1.43 GB' desde la descripcion del RSS (o '')."""
	m = _SIZE_RE.search(re.sub(r'<[^>]+>', ' ', desc or ''))
	if not m: return ''
	try: num = float(m.group(1).replace(',', '.'))
	except ValueError: return ''
	# siempre en GB: source_utils._size solo entiende MB y GB
	gb = num * {'K': 1.0 / 1048576, 'M': 1.0 / 1024, 'G': 1.0, 'T': 1024.0}[m.group(2)[0].upper()]
	return '%.2f GB' % gb


def parse_rss(text):
	"""[(hash, nombre, tamano_texto)] de una respuesta RSS de BT4G."""
	out = []
	for block in _ITEM_RE.findall(text or ''):
		link = _tag(block, 'link') or _tag(block, 'guid')
		h = _HASH_RE.search(link) or _HASH_RE.search(block)
		name = _tag(block, 'title')
		if not h or not name: continue
		out.append((h.group(1).lower(), name, _size_text(_tag(block, 'description'))))
	return out


class source:
	priority = 4
	pack_capable = True
	hasMovies = True
	hasEpisodes = True
	def __init__(self):
		self.language = ['en']
		self.domains = ['bt4gprx.com', 'bt4g.org']
		self._base_link = None
		self.search_link = '/search?q={0}&category=movie&orderby=seeders&p=1&page=rss'
		self.min_seeders = 0

	@property
	def base_link(self):
		if not self._base_link:
			self._base_link = cache.get(self.__get_base_url, 120, 'https://%s' % self.domains[0])
		return self._base_link

	def __get_base_url(self, fallback):
		from resources.lib.jacksparrow import log_utils
		for domain in self.domains:
			try:
				url = 'https://%s' % domain
				result = client.request(url, limit=1, timeout=5) or ''
				if _CF_RE.search(result):
					log_utils.log('BT4G: %s answers with a Cloudflare challenge' % domain, level=log_utils.LOGDEBUG)
					continue
				try: title = re.search(r'<title>(.+?)</title>', result, re.I | re.S).group(1)
				except: title = ''
				if 'bt4g' in title.lower(): return url
			except:
				source_utils.scraper_error('BT4G')
		return fallback

	@staticmethod
	def _query(text):
		return quote(re.sub(r'\s+', ' ', re.sub(r'[^A-Za-z0-9\s\.-]+', ' ', text)).strip())

	def _rows(self, query):
		url = '%s%s' % (self.base_link, self.search_link.format(self._query(query)))
		text = client.request(url, timeout=7)
		if not text: return []
		if isinstance(text, bytes): text = text.decode('utf-8', 'replace')
		if '<rss' not in text[:500].lower() and '<item>' not in text:
			from resources.lib.jacksparrow import log_utils
			why = 'Cloudflare challenge' if _CF_RE.search(text) else 'not an RSS answer'
			log_utils.log('BT4G: %s for %s' % (why, url.split('?')[0]), level=log_utils.LOGDEBUG)
			return []
		return parse_rss(text)

	@staticmethod
	def _too_small(size):
		try: dsize, _ = source_utils._size(size)
		except: return False
		return 0 < dsize * 1024 < MIN_MB

	@staticmethod
	def _too_big(size):
		try: dsize, _ = source_utils._size(size)
		except: return False
		return dsize > MAX_GB

	def sources(self, data, hostDict):
		self._results = []
		if not data: return self._results
		self._results_append = self._results.append
		try:
			self.aliases = data['aliases']
			self.year = data['year']
			if 'tvshowtitle' in data:
				self.title = data['tvshowtitle'].replace('&', 'and').replace('Special Victims Unit', 'SVU').replace('/', ' ').replace('$', 's')
				self.episode_title = data['title']
				self.hdlr = 'S%02dE%02d' % (int(data['season']), int(data['episode']))
				variants = source_utils.episode_variants(data)
			else:
				self.title = data['title'].replace('&', 'and').replace('/', ' ').replace('$', 's')
				self.episode_title = None
				self.hdlr = self.year
				variants = [(self.hdlr, self.hdlr, None)]
			self._seen = set()
			queries = [('%s %s' % (self.title, suffix), hdlr, absolute) for suffix, hdlr, absolute in variants]
			if 'tvshowtitle' in data:
				for query, hdlr in source_utils.host_queries(data):
					queries.append((query, hdlr, None))
			self.undesirables = source_utils.get_undesirables()
			self.check_foreign_audio = source_utils.check_foreign_audio()
			threads = [workers.Thread(self.get_sources, q, hdlr, absolute) for q, hdlr, absolute in queries]
			[i.start() for i in threads]
			[i.join() for i in threads]
			return self._results
		except:
			source_utils.scraper_error('BT4G')
			return self._results

	def get_sources(self, query, hdlr=None, absolute=None):
		if hdlr is None and not absolute: hdlr = self.hdlr
		try: rows = self._rows(query)
		except:
			source_utils.scraper_error('BT4G')
			return
		for hash, title, size in rows:
			try:
				if _NOT_VIDEO.search(title) or self._too_small(size) or self._too_big(size): continue
				name = source_utils.clean_name(title)
				if hash in self._seen: continue
				if not source_utils.check_episode(self.title, self.aliases, name, hdlr, self.year, absolute): continue
				self._seen.add(hash)
				name_info = source_utils.info_from_name(name, self.title, self.year, hdlr, self.episode_title)
				if source_utils.remove_lang(name_info, self.check_foreign_audio): continue
				if self.undesirables and source_utils.remove_undesirables(name_info, self.undesirables): continue
				if not self.episode_title:
					ep_strings = [r'[.-]s\d{2}e\d{2}([.-]?)', r'[.-]s\d{2}([.-]?)', r'[.-]season[.-]?\d{1,2}[.-]?']
					if any(re.search(item, name.lower()) for item in ep_strings): continue

				url = 'magnet:?xt=urn:btih:%s&dn=%s' % (hash, name)
				quality, info = source_utils.get_release_quality(name_info, url)
				info += [t for t in source_utils.get_extra_tags(name) if t not in info]
				try:
					dsize, isize = source_utils._size(size)
					info.insert(0, isize)
				except: dsize = 0
				info = ' | '.join(info)
				self._results_append({'provider': 'bt4g', 'source': 'torrent', 'seeders': 0, 'hash': hash, 'name': name, 'name_info': name_info,
												'quality': quality, 'language': 'en', 'url': url, 'info': info, 'direct': False, 'debridonly': True, 'size': dsize})
			except:
				source_utils.scraper_error('BT4G')

	def sources_packs(self, data, hostDict, search_series=False, total_seasons=None, bypass_filter=False):
		self._results = []
		if not data: return self._results
		self._results_append = self._results.append
		try:
			self.search_series = search_series
			self.total_seasons = total_seasons
			self.bypass_filter = bypass_filter
			self.title = data['tvshowtitle'].replace('&', 'and').replace('Special Victims Unit', 'SVU').replace('/', ' ').replace('$', 's')
			self.aliases = data['aliases']
			self.imdb = data['imdb']
			self.year = data['year']
			self.season_x = data['season']
			self.season_xx = self.season_x.zfill(2)
			self.undesirables = source_utils.get_undesirables()
			self.check_foreign_audio = source_utils.check_foreign_audio()
			self._seen = set()
			if search_series: queries = ['%s Season' % self.title, '%s Complete' % self.title]
			else: queries = ['%s S%s' % (self.title, self.season_xx), '%s Season %s' % (self.title, self.season_x)]
			threads = [workers.Thread(self.get_sources_packs, q) for q in queries]
			[i.start() for i in threads]
			[i.join() for i in threads]
			return self._results
		except:
			source_utils.scraper_error('BT4G')
			return self._results

	def get_sources_packs(self, query):
		try: rows = self._rows(query)
		except:
			source_utils.scraper_error('BT4G')
			return
		for hash, title, size in rows:
			try:
				if _NOT_VIDEO.search(title) or self._too_small(size): continue
				name = source_utils.clean_name(title)
				if hash in self._seen: continue
				episode_start, episode_end = 0, 0
				if not self.search_series:
					if not self.bypass_filter:
						valid, episode_start, episode_end = source_utils.filter_season_pack(self.title, self.aliases, self.year, self.season_x, name)
						if not valid: continue
					package = 'season'
				else:
					if not self.bypass_filter:
						valid, last_season = source_utils.filter_show_pack(self.title, self.aliases, self.imdb, self.year, self.season_x, name, self.total_seasons)
						if not valid: continue
					else: last_season = self.total_seasons
					if not last_season: last_season = self.total_seasons
					package = 'show'
				self._seen.add(hash)
				name_info = source_utils.info_from_name(name, self.title, self.year, season=self.season_x, pack=package)
				if source_utils.remove_lang(name_info, self.check_foreign_audio): continue
				if self.undesirables and source_utils.remove_undesirables(name_info, self.undesirables): continue

				url = 'magnet:?xt=urn:btih:%s&dn=%s' % (hash, name)
				quality, info = source_utils.get_release_quality(name_info, url)
				info += [t for t in source_utils.get_extra_tags(name) if t not in info]
				try:
					dsize, isize = source_utils._size(size)
					info.insert(0, isize)
				except: dsize = 0
				info = ' | '.join(info)
				item = {'provider': 'bt4g', 'source': 'torrent', 'seeders': 0, 'hash': hash, 'name': name, 'name_info': name_info, 'quality': quality,
							'language': 'en', 'url': url, 'info': info, 'direct': False, 'debridonly': True, 'size': dsize, 'package': package}
				if self.search_series: item.update({'last_season': last_season})
				elif episode_start: item.update({'episode_start': episode_start, 'episode_end': episode_end})
				self._results_append(item)
			except:
				source_utils.scraper_error('BT4G')
