"""
	jacksparrowscrapers Project
"""

import re
from html import unescape
from urllib.parse import quote
from resources.lib.jacksparrow import cache
from resources.lib.jacksparrow import client
from resources.lib.jacksparrow import source_utils
from resources.lib.jacksparrow import workers


# v2.0.32 — LimeTorrents. No llega por ningun otro camino de la suite: Torrentio
# no lo tiene entre sus proveedores (addon/crates/addon/src/domain/filter.rs) y
# los agregadores Custom no lo anuncian.
#
# Se lee la pagina de busqueda, como hace Magnetio (scraper/providers/
# limetorrents.js): cada fila de <table class="table2"> trae el infohash en el
# enlace a itorrents.net/torrent/<HASH>.torrent, asi que no hace falta abrir la
# ficha de cada release. Columnas: 0 nombre, 1 fecha, 2 tamano, 3 seeds, 4 peers.
# Busqueda: /search/<movies|tv>/<consulta>/seeds/1/ (ordenada por seeds).
# Espejos de Magnetio; se valida por <title> antes de cachear el que conteste.
_HASH_RE = re.compile(r'/torrent/([a-fA-F0-9]{40})\.torrent', re.I)
_ROW_RE = re.compile(r'<tr[^>]*>(.*?)</tr>', re.S | re.I)
_TD_RE = re.compile(r'<td[^>]*>(.*?)</td>', re.S | re.I)
_NAME_RE = re.compile(r'<a[^>]+href="[^"]*-torrent-[^"]*"[^>]*>(.*?)</a>', re.S | re.I)


class source:
	priority = 3
	pack_capable = True
	hasMovies = True
	hasEpisodes = True
	def __init__(self):
		self.language = ['en']
		self.domains = ['www.limetorrents.fun', 'www.limetorrents.lol']
		self._base_link = None
		self.moviesearch = '/search/movies/{0}/seeds/1/'
		self.tvsearch = '/search/tv/{0}/seeds/1/'
		self.min_seeders = 0

	@property
	def base_link(self):
		if not self._base_link:
			self._base_link = cache.get(self.__get_base_url, 120, 'https://%s' % self.domains[0])
		return self._base_link

	def __get_base_url(self, fallback):
		for domain in self.domains:
			try:
				url = 'https://%s' % domain
				result = client.request(url, limit=1, timeout=5)
				try: result = re.search(r'<title>(.+?)</title>', result, re.I | re.S).group(1)
				except: result = None
				if result and 'limetorrents' in result.lower(): return url
			except:
				source_utils.scraper_error('LIMETORRENTS')
		return fallback

	@staticmethod
	def _query(text):
		return quote(re.sub(r'\s+', ' ', re.sub(r'[^A-Za-z0-9\s\.-]+', ' ', text)).strip())

	def _rows(self, url):
		"""[(hash, name, size_text, seeders)] de una pagina de resultados."""
		html = client.request(url, timeout=7)
		if not html: return []
		try: table = re.search(r'<table[^>]+class="table2"[^>]*>(.*?)</table>', html, re.S | re.I).group(1)
		except AttributeError: return []
		out = []
		for row in _ROW_RE.findall(table):
			cells = _TD_RE.findall(row)
			if len(cells) < 5: continue
			hash_m = _HASH_RE.search(cells[0])
			name_m = _NAME_RE.search(cells[0])
			if not hash_m or not name_m: continue
			# Texto HTML, no URL: unquote_plus convertiria el '+' de HDR10+ en espacio.
			name = unescape(re.sub(r'<[^>]+>', '', name_m.group(1))).strip()
			if not name: continue
			try: seeders = int(re.sub(r'[^\d]', '', cells[3]) or 0)
			except: seeders = 0
			out.append((hash_m.group(1).lower(), name, re.sub(r'<[^>]+>', '', cells[2]).strip(), seeders))
		return out

	def sources(self, data, hostDict):
		self._results = []
		if not data: return self._results
		self._results_append = self._results.append
		try:
			self.aliases = data['aliases']
			self.year = data['year']
			if 'tvshowtitle' in data:
				self.title = data['tvshowtitle'].replace('&', 'and').replace('Special Victims Unit', 'SVU').replace('/', ' ').replace('$', 's')
				self.episode_title = data['title']
				self.hdlr = 'S%02dE%02d' % (int(data['season']), int(data['episode']))
				search_link = self.tvsearch
				variants = source_utils.episode_variants(data) # TheTVDB SxxEyy when it differs from TMDb; absolute number for anime
			else:
				self.title = data['title'].replace('&', 'and').replace('/', ' ').replace('$', 's')
				self.episode_title = None
				self.hdlr = self.year
				search_link = self.moviesearch
				variants = [(self.hdlr, self.hdlr, None)]
			self._seen = set()
			urls = []
			for suffix, hdlr, absolute in variants:
				urls.append(('%s%s' % (self.base_link, search_link.format(self._query('%s %s' % (self.title, suffix)))), hdlr, absolute))
			if 'tvshowtitle' in data: # v2.0.31: talk shows under the presenter's name
				for query, hdlr in source_utils.host_queries(data):
					urls.append(('%s%s' % (self.base_link, search_link.format(self._query(query))), hdlr, None))
			self.undesirables = source_utils.get_undesirables()
			self.check_foreign_audio = source_utils.check_foreign_audio()
			threads = [workers.Thread(self.get_sources, url, hdlr, absolute) for url, hdlr, absolute in urls]
			[i.start() for i in threads]
			[i.join() for i in threads]
			return self._results
		except:
			source_utils.scraper_error('LIMETORRENTS')
			return self._results

	def get_sources(self, url, hdlr=None, absolute=None):
		if hdlr is None and not absolute: hdlr = self.hdlr
		try: rows = self._rows(url)
		except:
			source_utils.scraper_error('LIMETORRENTS')
			return
		for hash, title, size, seeders in rows:
			try:
				name = source_utils.clean_name(title)
				if hash in self._seen: continue
				if not source_utils.check_episode(self.title, self.aliases, name, hdlr, self.year, absolute): continue
				self._seen.add(hash)
				name_info = source_utils.info_from_name(name, self.title, self.year, hdlr, self.episode_title)
				if source_utils.remove_lang(name_info, self.check_foreign_audio): continue
				if self.undesirables and source_utils.remove_undesirables(name_info, self.undesirables): continue
				if not self.episode_title: # episodes returned for a movie query
					ep_strings = [r'[.-]s\d{2}e\d{2}([.-]?)', r'[.-]s\d{2}([.-]?)', r'[.-]season[.-]?\d{1,2}[.-]?']
					if any(re.search(item, name.lower()) for item in ep_strings): continue
				if self.min_seeders > seeders: continue

				url = 'magnet:?xt=urn:btih:%s&dn=%s' % (hash, name)
				quality, info = source_utils.get_release_quality(name_info, url)
				info += [t for t in source_utils.get_extra_tags(name) if t not in info]
				try:
					dsize, isize = source_utils._size(size)
					info.insert(0, isize)
				except: dsize = 0
				info = ' | '.join(info)
				self._results_append({'provider': 'limetorrents', 'source': 'torrent', 'seeders': seeders, 'hash': hash, 'name': name, 'name_info': name_info,
												'quality': quality, 'language': 'en', 'url': url, 'info': info, 'direct': False, 'debridonly': True, 'size': dsize})
			except:
				source_utils.scraper_error('LIMETORRENTS')

	def sources_packs(self, data, hostDict, search_series=False, total_seasons=None, bypass_filter=False):
		self._results = []
		if not data: return self._results
		self._results_append = self._results.append
		try:
			self.search_series = search_series
			self.total_seasons = total_seasons
			self.bypass_filter = bypass_filter
			self.title = data['tvshowtitle'].replace('&', 'and').replace('Special Victims Unit', 'SVU').replace('/', ' ').replace('$', 's')
			self.aliases = data['aliases']
			self.imdb = data['imdb']
			self.year = data['year']
			self.season_x = data['season']
			self.season_xx = self.season_x.zfill(2)
			self.undesirables = source_utils.get_undesirables()
			self.check_foreign_audio = source_utils.check_foreign_audio()
			self._seen = set()
			if search_series: queries = ['%s Season' % self.title, '%s Complete' % self.title]
			else: queries = ['%s S%s' % (self.title, self.season_xx), '%s Season %s' % (self.title, self.season_x)]
			threads = [workers.Thread(self.get_sources_packs, '%s%s' % (self.base_link, self.tvsearch.format(self._query(q)))) for q in queries]
			[i.start() for i in threads]
			[i.join() for i in threads]
			return self._results
		except:
			source_utils.scraper_error('LIMETORRENTS')
			return self._results

	def get_sources_packs(self, link):
		try: rows = self._rows(link)
		except:
			source_utils.scraper_error('LIMETORRENTS')
			return
		for hash, title, size, seeders in rows:
			try:
				name = source_utils.clean_name(title)
				if hash in self._seen: continue
				episode_start, episode_end = 0, 0
				if not self.search_series:
					if not self.bypass_filter:
						valid, episode_start, episode_end = source_utils.filter_season_pack(self.title, self.aliases, self.year, self.season_x, name)
						if not valid: continue
					package = 'season'
				else:
					if not self.bypass_filter:
						valid, last_season = source_utils.filter_show_pack(self.title, self.aliases, self.imdb, self.year, self.season_x, name, self.total_seasons)
						if not valid: continue
					else: last_season = self.total_seasons
					package = 'show'
				self._seen.add(hash)
				name_info = source_utils.info_from_name(name, self.title, self.year, season=self.season_x, pack=package)
				if source_utils.remove_lang(name_info, self.check_foreign_audio): continue
				if self.undesirables and source_utils.remove_undesirables(name_info, self.undesirables): continue
				if self.min_seeders > seeders: continue

				url = 'magnet:?xt=urn:btih:%s&dn=%s' % (hash, name)
				quality, info = source_utils.get_release_quality(name_info, url)
				info += [t for t in source_utils.get_extra_tags(name) if t not in info]
				try:
					dsize, isize = source_utils._size(size)
					info.insert(0, isize)
				except: dsize = 0
				info = ' | '.join(info)
				item = {'provider': 'limetorrents', 'source': 'torrent', 'seeders': seeders, 'hash': hash, 'name': name, 'name_info': name_info, 'quality': quality,
							'language': 'en', 'url': url, 'info': info, 'direct': False, 'debridonly': True, 'size': dsize, 'package': package}
				if self.search_series: item.update({'last_season': last_season})
				elif episode_start: item.update({'episode_start': episode_start, 'episode_end': episode_end}) # for partial season packs
				self._results_append(item)
			except:
				source_utils.scraper_error('LIMETORRENTS')
