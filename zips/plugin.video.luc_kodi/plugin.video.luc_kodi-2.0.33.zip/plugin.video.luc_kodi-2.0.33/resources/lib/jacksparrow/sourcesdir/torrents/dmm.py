"""
	jacksparrowscrapers Project
"""

import xml.etree.ElementTree as ET
import requests
from resources.lib.jacksparrow import client, source_utils
from resources.lib.jacksparrow.control import setting as getSetting


# v2.0.32 — DMM por su indexador Torznab, con la clave de patrocinador.
#
# El 11-nov-2026 DMM cerro /api/challenge, el que daba el token de las
# busquedas de /api/torrents, a todo lo que no sea su propia web:
#
#   88f6193e  fix: serve challenge tokens ... to DMM pages only
#             (exige Sec-Fetch-Site: same-origin, que solo pone un navegador)
#   cdebe2e3  feat: put Cloudflare Turnstile in front of the web app's
#             challenge token
#
# Desde entonces cualquier cliente que no sea un navegador recibe 403 al pedir
# el token y la busqueda no llega a salir: el panel de estado lo mostraba como
# "0 results". No se falsea esa cabecera ni se intenta pasar Turnstile: es un
# cierre deliberado y DMM remite a las herramientas a su API de patrocinadores.
#
# La via soportada para un addon es su Torznab (src/pages/api/torznab), el mismo
# que usan Prowlarr/Sonarr/Radarr: GET /api/torznab/api con la clave de DMM del
# patrocinador. Se manda en la cabecera x-api-key (el servidor la acepta igual
# que ?apikey=) para que la clave no viaje dentro de ninguna URL ni del log.
# Responde RSS con un <item> por release: title, size en bytes y el infohash en
# <torznab:attr name="infohash">. Solo sirve la tabla de confianza (ScrapedTrue)
# y rellena al vuelo desde Debridio un titulo que nadie ha scrapeado aun.
#
# Errores: Torznab responde 200 con <error code=... description=...>. 100 =
# clave incorrecta, 101 = patrocinio caducado, 429 = limite. Limites: 20
# busquedas por minuto por patrocinio y 20 cada 10 s por IP; una busqueda de
# luc_kodi gasta 1 peticion (pelicula) o 2 (episodio + packs de la temporada).
#
# Sin clave no se hace ninguna peticion: el test de estado lo marca como "not
# configured" (provider_test.TOKEN_SETTING) en vez de un 0 que parece un fallo.
# La clave es la misma de Accounts > Real-Debrid > DMM API key, que tambien usa
# la comprobacion de cache de RD (debrid/dmm.py).
_TORZNAB_LINK = 'https://debridmediamanager.com/api/torznab/api'
_PAGE = 100            # <limits max="100"> del caps de DMM
_TORZNAB_NS = '{http://torznab.com/schemas/2015/feed}'
_AUTH_ERRORS = {
	'100': 'DMM refused the DMM API key. Check it in Accounts > Real-Debrid.',
	'101': 'Your DMM sponsorship is no longer active.',
}


def api_key():
	return (getSetting('dmm.api_key') or '').strip()


class source:
	timeout = 7
	priority = 3
	pack_capable = False # packs parsed in sources function
	hasMovies = True
	hasEpisodes = True
	def __init__(self):
		self.language = ['en']
		self.base_link = "https://debridmediamanager.com"
		self.min_seeders = 0
		self.skip_reason = ''
		# Segunda pagina opcional (offset 100). Cuesta una peticion mas del
		# presupuesto de 20/min del patrocinio y por eso viene apagada.
		self.deep_search = getSetting('dmm.deep_search') == 'true'

	def sources(self, data, hostDict):
		self._results = []
		if not data: return self._results
		self._results_append = self._results.append
		self._seen = set()
		try:
			self.key = api_key()
			if not self.key: return self._results
			self.title = data['tvshowtitle'] if 'tvshowtitle' in data else data['title']
			self.title = self.title.replace('&', 'and').replace('Special Victims Unit', 'SVU').replace('/', ' ')
			self.aliases = data['aliases']
			self.episode_title = data['title'] if 'tvshowtitle' in data else None
			self.total_seasons = data.get('total_seasons') if 'tvshowtitle' in data else None
			self.year = data['year']
			self.imdb = data['imdb']
			self.season = data['season'] if 'tvshowtitle' in data else None
			self.hdlr = 'S%02dE%02d' % (int(data['season']), int(data['episode'])) if 'tvshowtitle' in data else self.year
			self.season_x = data['season'] if 'tvshowtitle' in data else None
			if 'timeout' in data: self.timeout = int(data['timeout'])
			self.undesirables = source_utils.get_undesirables()
			self.check_foreign_audio = source_utils.check_foreign_audio()
			if not self.imdb or not str(self.imdb).startswith('tt'): return self._results

			if self.season:
				# El filtro de episodio de DMM deja fuera los packs a proposito
				# (matchesTvEpisodeFilter), asi que se piden aparte: el episodio
				# exacto y la temporada entera, de la que solo se quedan los packs
				# que reconoce el filtro de packs de siempre.
				episode = {'t': 'tvsearch', 'imdbid': self.imdb, 'season': self.season, 'ep': data['episode']}
				if self.get_sources(episode) is None: return self._results
				if self.total_seasons is not None:
					self.get_sources({'t': 'tvsearch', 'imdbid': self.imdb, 'season': self.season}, packs_only=True)
			else:
				self.get_sources({'t': 'movie', 'imdbid': self.imdb})
			return self._results
		except:
			source_utils.scraper_error('DMM')
			return self._results

	def api_get(self, params):
		"""Una pagina del Torznab. Devuelve (items, total) o None si no hay nada
		que parsear (sin red, clave rechazada, limite, respuesta rara)."""
		from resources.lib.modules import log_utils
		params = dict(params, limit=_PAGE)
		headers = {'x-api-key': self.key, 'User-Agent': client.randomagent(), 'Accept': 'application/rss+xml, application/xml'}
		try: response = requests.get(_TORZNAB_LINK, params=params, headers=headers, timeout=self.timeout)
		except requests.exceptions.RequestException as e:
			log_utils.log('DMM: fallo de red (%s: %s)' % (type(e).__name__, e), __name__, log_utils.LOGDEBUG)
			return None
		status = response.status_code
		if status == 429:
			log_utils.log('DMM: 429, limite de busquedas de Torznab (20/min por patrocinio)', __name__, log_utils.LOGDEBUG)
			return None
		try: root = ET.fromstring(response.content)
		except Exception:
			body = (response.text or '')[:300].replace('\n', ' ').replace('\r', ' ')
			log_utils.log('DMM: HTTP %s sin XML | body[:300]=%r' % (status, body), __name__, log_utils.LOGWARNING)
			return None
		if root.tag == 'error':
			code, description = root.get('code') or '', root.get('description') or ''
			if code in _AUTH_ERRORS: self.skip_reason = _AUTH_ERRORS[code]
			log_utils.log('DMM: Torznab error %s (%s)' % (code, description), __name__, log_utils.LOGWARNING)
			return None
		channel = root.find('channel')
		if channel is None: return None
		total = 0
		resp = channel.find(_TORZNAB_NS + 'response')
		if resp is not None:
			try: total = int(resp.get('total') or 0)
			except Exception: total = 0
		return channel.findall('item'), total

	@staticmethod
	def _attrs(item):
		out = {}
		for a in item.findall(_TORZNAB_NS + 'attr'):
			out[a.get('name')] = a.get('value')
		return out

	def get_sources(self, params, packs_only=False):
		"""Parsea una o dos paginas. Devuelve cuantas filas crudas trajo el
		servidor, o None si la peticion fallo (para no gastar la segunda)."""
		try: page = self.api_get(params)
		except:
			source_utils.scraper_error('DMM')
			return None
		if page is None: return None
		items, total = page
		count = self._parse(items, packs_only)
		if self.deep_search and len(items) >= _PAGE and total > _PAGE:
			more = self.api_get(dict(params, offset=_PAGE))
			if more: count += self._parse(more[0], packs_only)
		return count

	def _parse(self, items, packs_only):
		for item in items:
			try:
				package, episode_start = None, 0
				attrs = self._attrs(item)
				hash = (attrs.get('infohash') or item.findtext('guid') or '').strip().lower()
				if len(hash) != 40 or hash in self._seen: continue
				title = item.findtext('title')
				if not title: continue
				name = source_utils.clean_name(title)

				if packs_only or not source_utils.check_title(self.title, self.aliases, name, self.hdlr, self.year):
					if self.total_seasons is None: continue
					valid, episode_start, episode_end = source_utils.filter_season_pack(self.title, self.aliases, self.year, self.season_x, name)
					if not valid:
						valid, last_season = source_utils.filter_show_pack(self.title, self.aliases, self.imdb, self.year, self.season_x, name, self.total_seasons)
						if not valid: continue
						else: package = 'show'
					else: package = 'season'
				name_info = source_utils.info_from_name(name, self.title, self.year, self.hdlr, self.episode_title)
				if source_utils.remove_lang(name_info, self.check_foreign_audio): continue
				if self.undesirables and source_utils.remove_undesirables(name_info, self.undesirables): continue

				url = 'magnet:?xt=urn:btih:%s&dn=%s' % (hash, name)

				quality, info = source_utils.get_release_quality(name_info, url)
				# El '+' de HDR10+ se pierde en info_from_name(): get_extra_tags()
				# recibe el nombre SIN limpiar (v1.0.83).
				info += [t for t in source_utils.get_extra_tags(name) if t not in info]
				try:
					size = f"{float(attrs.get('size') or item.findtext('size')) / 1073741824:.2f} GB"
					dsize, isize = source_utils._size(size)
					info.insert(0, isize)
				except: dsize = 0
				info = ' | '.join(info)

				row = {
					'source': 'torrent', 'language': 'en', 'direct': False, 'debridonly': True,
					'provider': 'dmm', 'hash': hash, 'url': url, 'name': name, 'name_info': name_info,
					'quality': quality, 'info': info, 'size': dsize, 'seeders': 0
				}
				if package: row['package'] = package
				if package == 'show': row.update({'last_season': last_season})
				if episode_start: row.update({'episode_start': episode_start, 'episode_end': episode_end}) # for partial season packs
				self._seen.add(hash)
				self._results_append(row)
			except:
				source_utils.scraper_error('DMM')
		return len(items)
