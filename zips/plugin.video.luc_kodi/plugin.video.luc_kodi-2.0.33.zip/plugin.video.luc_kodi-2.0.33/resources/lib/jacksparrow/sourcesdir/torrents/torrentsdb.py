
"""
	jacksparrowscrapers Project
"""

from json import loads as jsloads
import re
from resources.lib.jacksparrow import client
from resources.lib.jacksparrow import source_utils
from resources.lib.jacksparrow import pack_handoff


class source:
	timeout = 10
	priority = 1
	pack_capable = True
	hasMovies = True
	hasEpisodes = True
	def __init__(self):
		self.language = ['en']
		self.base_link = "https://torrentsdb.com"
		self.movieSearch_link = '/stream/movie/%s.json'
		self.tvSearch_link = '/stream/series/%s:%s:%s.json'
		self.min_seeders = 0

	# v2.0.20: TorrentsDB (fork de Torrentio) se usa hoy con su configuracion en
	# la ruta, un JSON en base64: es lo que genera su pagina /configure y lo que
	# manda AIOStreams (presets/torrentsDb.ts). '{}' (e30=) son los proveedores
	# por defecto y sin debrid, o sea los infohash, que es lo que el plugin
	# comprueba con tu debrid. Si esa ruta falla (el servicio va degradado:
	# 88% de disponibilidad en 30 dias y HTTP 502 intermitentes en oct-2026) se
	# prueba la ruta sin configuracion de siempre, y despues una vez mas.
	CONFIG_SEGMENTS = ('/e30=', '', '/e30=')

	# v2.0.32: un 429 (Too Many Requests) no se reintenta: cada reintento cuenta
	# para el limite. kodi.log del 12-nov-2026: desde las 23:55 cada busqueda
	# eran tres peticiones con 429 y ninguna fuente. TorrentsDB descansa
	# REST_SECS y luego se vuelve a preguntar.
	REST_SECS = 1200
	_REST_PROP = 'luc_kodi.torrentsdb.rest'

	def _resting(self):
		try:
			from resources.lib.jacksparrow.control import homeWindow
			import time
			return float(homeWindow.getProperty(self._REST_PROP) or 0) > time.time()
		except Exception:
			return False

	def _rest(self):
		try:
			from resources.lib.jacksparrow.control import homeWindow
			from resources.lib.jacksparrow import log_utils
			import time
			homeWindow.setProperty(self._REST_PROP, str(int(time.time() + self.REST_SECS)))
			log_utils.log('TORRENTSDB: too many requests (HTTP 429); it rests for %d min' % (self.REST_SECS // 60), level=log_utils.LOGINFO)
		except Exception:
			pass

	@staticmethod
	def _last_failure():
		try: return (getattr(client._failures, 'items', None) or [])[-1][1]
		except Exception: return ''

	def _fetch(self, path):
		import time
		if self._resting():
			return []
		for n, seg in enumerate(self.CONFIG_SEGMENTS):
			if n == 2: time.sleep(1.0)
			t0 = time.time()
			raw = client.request('%s%s%s' % (self.base_link, seg, path), timeout=self.timeout)
			if not raw:
				if self._last_failure() == 'http 429':
					self._rest()
					break
				# Un 502 llega al momento y merece otro intento; un tiempo agotado
				# no: tres esperas de 10 s retrasarian la busqueda entera.
				if time.time() - t0 > self.timeout * 0.8: break
				continue
			try: data = jsloads(raw)
			except Exception: continue
			if isinstance(data, dict) and isinstance(data.get('streams'), list):
				return data['streams']
		return []

	@staticmethod
	def _text(file):
		"""Stremio dejo 'title' por 'description'; TorrentsDB puede mandar
		cualquiera de las dos. Lineas del texto del stream."""
		return str(file.get('title') or file.get('description') or '').split('\n')

	@staticmethod
	def _info_line(lines, file):
		info = [x for x in lines if '💾' in x]
		if info: return info[0]
		return ' '.join(lines[1:]) if len(lines) > 1 else ''

	@staticmethod
	def _name(lines, file):
		hints = file.get('behaviorHints') or {}
		first = lines[0] if lines and lines[0].strip() else ''
		return first or hints.get('filename') or ''
# Currently supports YTS(+), EZTV(+), 1337x(+), TorrentCSV(+), 1lou(+), Nyaa(+), Sk-CzTorrent(+), 1TamilBlasters(+), LimeTorrent(+), 1TamilMV(+), Knaben(+), ThePirateBay(+), KickassTorrents(+), AnimeTosho(+), ExtremlymTorrents(+), YggTorrent(+), TokyoTosho(+), Rutor(+), Rutracker(+), Torrent9(+), ilCorSaRoNeRo(+), Manual(+). [RARBG: excluded, shut down May 2023]

	def sources(self, data, hostDict):
		sources = []
		if not data: return sources
		sources_append = sources.append
		try:
			title = data['tvshowtitle'] if 'tvshowtitle' in data else data['title']
			title = title.replace('&', 'and').replace('Special Victims Unit', 'SVU').replace('/', ' ')
			aliases = data['aliases']
			episode_title = data['title'] if 'tvshowtitle' in data else None
			year = data['year']
			imdb = data['imdb']
			if 'tvshowtitle' in data:
				season = data['season']
				episode = data['episode']
				hdlr = 'S%02dE%02d' % (int(season), int(episode))
				path = self.tvSearch_link % (imdb, season, episode)
				_h = pack_handoff.begin('torrentsdb', imdb, season, episode)
			else:
				hdlr = year
				_h = None
				path = self.movieSearch_link % imdb
			try:
				# v2.0.10: sin respuesta no es un error: lista vacia (ver _fetch).
				files = self._fetch(path)
			except:
				files = []
				raise
			finally:
				# v1.0.63: ver resources/lib/jacksparrow/pack_handoff.py — la cola
				# por instancia no cruzaba a sources_packs(), que corre en otra.
				pack_handoff.publish(_h, files)
			undesirables = source_utils.get_undesirables()
			check_foreign_audio = source_utils.check_foreign_audio()
		except:
			source_utils.scraper_error('TORRENTSDB')
			return sources

		for file in files:
			try:
				hash = file.get('infoHash') or ''
				if not hash: continue
				file_title = self._text(file)
				file_info = self._info_line(file_title, file)
				raw_name = self._name(file_title, file)
				if not raw_name: continue
				name = source_utils.clean_name(raw_name)

				if not source_utils.check_title(title, aliases, name.replace('.(Archie.Bunker', ''), hdlr, year): continue
				name_info = source_utils.info_from_name(name, title, year, hdlr, episode_title)
				if source_utils.remove_lang(name_info, check_foreign_audio): continue
				if undesirables and source_utils.remove_undesirables(name_info, undesirables): continue

				url = 'magnet:?xt=urn:btih:%s&dn=%s' % (hash, name)

				try:
					seeders = int(re.search(r'👤\s*(\d+)', file_info).group(1))
					if self.min_seeders > seeders: continue
				except: seeders = 0

				quality, info = source_utils.get_release_quality(name_info, url)
				info += [t for t in source_utils.get_extra_tags(name) if t not in info]
				try:
					size = re.search(r'((?:\d+\,\d+\.\d+|\d+\.\d+|\d+\,\d+|\d+)\s*(?:GB|GiB|Gb|MB|MiB|Mb))', file_info).group(0)
					dsize, isize = source_utils._size(size)
					info.insert(0, isize)
				except:
					dsize = 0
					try: # v2.0.20: sin linea 💾, el tamano en bytes de behaviorHints
						vs = int((file.get('behaviorHints') or {}).get('videoSize') or 0)
						if vs:
							dsize = float(vs) / 1073741824
							info.insert(0, '%.2f GB' % dsize)
					except Exception: pass
				info = ' | '.join(info)

				sources_append({
					'source': 'torrent', 'language': 'en', 'direct': False, 'debridonly': True,
					'provider': 'torrentsdb', 'hash': hash, 'url': url, 'name': name, 'name_info': name_info,
					'quality': quality, 'info': info, 'size': dsize, 'seeders': seeders
				})
			except:
				source_utils.scraper_error('TORRENTSDB')
		return sources

	def sources_packs(self, data, hostDict, search_series=False, total_seasons=None, bypass_filter=False):
		sources = []
		if not data: return sources
		sources_append = sources.append
		try:
			title = data['tvshowtitle'].replace('&', 'and').replace('Special Victims Unit', 'SVU').replace('/', ' ')
			aliases = data['aliases']
			imdb = data['imdb']
			year = data['year']
			season = data['season']
			files = pack_handoff.wait('torrentsdb', imdb, season, data.get('episode'), timeout=self.timeout)
			if files is None:
				files = self._fetch(self.tvSearch_link % (imdb, season, data['episode']))
			undesirables = source_utils.get_undesirables()
			check_foreign_audio = source_utils.check_foreign_audio()
		except:
			source_utils.scraper_error('TORRENTSDB')
			return sources

		for file in files:
			try:
				# v1.0.66: claves opcionales, no obligatorias. Este bloque no se habia
				# ejecutado nunca en la practica hasta que se arreglo el traspaso.
				hash = file.get('infoHash') or ''
				if not hash:
					continue
				file_title = self._text(file)
				file_info = self._info_line(file_title, file)
				raw_name = self._name(file_title, file)
				if not raw_name: continue
				name = source_utils.clean_name(raw_name)

				episode_start, episode_end = 0, 0
				if not search_series:
					if not bypass_filter:
						valid, episode_start, episode_end = source_utils.filter_season_pack(title, aliases, year, season, name.replace('.(Archie.Bunker', ''))
						if not valid: continue
					package = 'season'

				elif search_series:
					if not bypass_filter:
						valid, last_season = source_utils.filter_show_pack(title, aliases, imdb, year, season, name.replace('.(Archie.Bunker', ''), total_seasons)
						if not valid: continue
					else: last_season = total_seasons
					package = 'show'

				name_info = source_utils.info_from_name(name, title, year, season=season, pack=package)
				if source_utils.remove_lang(name_info, check_foreign_audio): continue
				if undesirables and source_utils.remove_undesirables(name_info, undesirables): continue

				url = 'magnet:?xt=urn:btih:%s&dn=%s' % (hash, name)
				try:
					seeders = int(re.search(r'👤\s*(\d+)', file_info).group(1))
					if self.min_seeders > seeders: continue
				except: seeders = 0

				quality, info = source_utils.get_release_quality(name_info, url)
				info += [t for t in source_utils.get_extra_tags(name) if t not in info]
				try:
					size = re.search(r'((?:\d+\,\d+\.\d+|\d+\.\d+|\d+\,\d+|\d+)\s*(?:GB|GiB|Gb|MB|MiB|Mb))', file_info).group(0)
					dsize, isize = source_utils._size(size)
					info.insert(0, isize)
				except:
					dsize = 0
					try: # v2.0.20: sin linea 💾, el tamano en bytes de behaviorHints
						vs = int((file.get('behaviorHints') or {}).get('videoSize') or 0)
						if vs:
							dsize = float(vs) / 1073741824
							info.insert(0, '%.2f GB' % dsize)
					except Exception: pass
				info = ' | '.join(info)

				item = {
					'source': 'torrent', 'language': 'en', 'direct': False, 'debridonly': True, 'true_size': True,
					'provider': 'torrentsdb', 'hash': hash, 'url': url, 'name': name, 'name_info': name_info,
					'quality': quality, 'info': info, 'size': dsize, 'seeders': seeders, 'package': package
				}
				if search_series: item.update({'last_season': last_season})
				elif episode_start: item.update({'episode_start': episode_start, 'episode_end': episode_end}) # for partial season packs
				sources_append(item)
			except:
				source_utils.scraper_error('TORRENTSDB')
		return sources
