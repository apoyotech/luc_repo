# -*- coding: utf-8 -*-
"""
	luc_kodi - motor de streaming Usenet (v2.0.24 test)

	Servidor HTTP local (127.0.0.1) que convierte un NZB en un fichero de
	video reproducible por Kodi SIN descargarlo entero y SIN debrid:

	  Kodi --GET Range--> 127.0.0.1:<puerto>/stream/<clave>/video.mkv
	        <-- bytes --- sesion: pide a Easynews (NNTP) solo los segmentos
	                      que cubren ese rango, los decodifica (yEnc) y los
	                      sirve en orden, con lectura anticipada.

	Vive en el SERVICIO de luc_kodi (service.py), no en la llamada del plugin:
	el plugin termina en cuanto entrega la URL a Kodi, y con
	reuseLanguageInvoker sus hilos no tienen una vida fiable. El servicio
	corre mientras Kodi este abierto. El puerto se publica en la propiedad de
	ventana 'luc_kodi.usenet.port' (Window 10000) para que el plugin lo lea.

	Rutas:
	  GET /ping                    -> 'luc_kodi-usenet'
	  GET /prepare/<clave>         -> JSON: abre la sesion, elige el video del
	                                  NZB, descarga el 1er segmento y comprueba
	                                  que se puede reproducir (MKV/MP4/AVI/TS).
	  GET|HEAD /stream/<clave>/<x> -> el video, con soporte de Range (seek).
	  GET /close/<clave>           -> cierra la sesion y sus conexiones.

	El NZB lo deja el plugin en <perfil>/usenet/nzb/<clave>.nzb (clave = md5
	del enlace del NZB, el mismo 'hash' que pone el scraper Newznab), asi que
	el apikey del indexer nunca viaja hasta aqui.

	Formatos: fichero directo (MKV/MP4/AVI/TS) y RAR 'store' (sin compresion,
	RAR4 y RAR5, en uno o cientos de volumenes, con nombres ofuscados o no).
	v2.0.28: tambien 7z 'store', en un volumen o partido (.7z.001...), como
	TMDb Movies.
	Limites (se dicen claro al plugin para que use el siguiente servicio
	activo, Premiumize o TorBox):
	  - 7z o RAR comprimidos, RAR cifrado, 7z partido con nombres ofuscados.
	  - sin reparacion PAR2: un articulo que falta se rellena con ceros
	    (un salto de imagen) y se anota en el log. Por eso la comprobacion
	    de salud del scraper descarta antes los NZB incompletos.
"""

import json
import os
import re
import socket
import threading
import time
from bisect import bisect_right
from collections import OrderedDict
from heapq import heappush, heappop, heapify
from http.server import BaseHTTPRequestHandler, HTTPServer
from socketserver import ThreadingMixIn

from resources.lib.modules import usenet_core as core

PORT_PROPERTY = 'luc_kodi.usenet.port'
PORT_RANGE = range(47321, 47331)
KEY_RE = re.compile(r'^[0-9a-f]{32}$')

# Ventanas en BYTES, no en segmentos: hay posts con segmentos de 3,84 MB
# (log del 1-nov-2026, Hocus Pocus / Mayday) y con 16/48 segmentos fijos eran
# 61 MB por delante y 184 MB de RAM por sesion.
# v2.0.32 (auditoria del 11-nov-2026, L2/P1): la lectura anticipada se calcula
# por release, ~25 s de video. 12 MB fijos eran ~1,2 s de un remux a 80 Mbit/s.
# Sin la duracion a mano, se estima con una de 90 min: un remux de 60 GB da el
# tope de 96 MB; un 1080p de 12 GB, ~55 MB; un episodio de 2 GB, el minimo.
PREFETCH_MIN = 24 * 1024 * 1024
PREFETCH_MAX = 96 * 1024 * 1024
PREFETCH_SECS = 25
# v2.0.32: perfil del motor (ajuste newznab.en_profile). Cuanto video se lee
# por delante, con que tope de memoria y con cuantas conexiones se arranca;
# a partir de ahi se abren mas SOLO si la lectura se queda atras, hasta el
# maximo de conexiones del ajuste.
#            segundos   minimo MB  maximo MB  conexiones al arrancar
# Sin perfil "Powerful" (decision de Lucian, 12-nov-2026; informe E2): 224 MB
# por reproduccion, 448 con dos, no caben en una caja o TV de 1-2 GB con skin
# y addons. Balanced ya da de sobra: 25 s por delante y conexiones que crecen.
PROFILES = {0: (15, 16, 48, 4),        # Efficient: aparatos con poca RAM, datos medidos
			1: (25, 24, 96, 6)}        # Balanced (de fabrica)
ACCOUNT_CONNS = 60     # Easynews deja 60 conexiones a la vez por cuenta (todas las cuentas)
HEALTH_RESERVE = 8     # las que necesita la comprobacion de salud (usenet_easynews.HEALTH_CONNECTIONS)
GROW_EVERY = 0.25      # s entre dos conexiones nuevas al crecer
RETIRE_EVERY = 5.0     # s entre dos conexiones de mas que se cierran al sobrar
ASSUMED_RUNTIME = 5400
CACHE_EXTRA = 32 * 1024 * 1024      # la cache = lo anticipado + 32 MB ya leidos
PREFETCH_BYTES = PREFETCH_MIN       # (compat: informes antiguos)
CACHE_BYTES = PREFETCH_MIN + CACHE_EXTRA
SESSION_IDLE_SECS = 600     # una sesion sin lecturas se cierra a los 10 min
CONN_IDLE_SECS = 45         # una conexion NNTP ociosa se cierra (sin nadie viendo)
# v2.0.32 (L5/P2): con alguien viendo (pausa incluida) las conexiones no se
# cierran: cada 30 s sin uso se manda DATE para que el servidor no las corte, y
# al reanudar no hay que volver a hacer el TLS.
KEEPALIVE_SECS = 30
# v2.0.32 (informe N4): el final del fichero se fija por BYTES, no por
# segmentos: 2 segmentos eran ~1,5 MB, y el indice de un MKV grande (Cues)
# y lo que Kodi relee al saltar ocupan mas. TMDb Movies fija 8 MB.
PIN_TAIL_BYTES = 8 * 1024 * 1024
RUNTIME_MIN, RUNTIME_MAX = 600, 14400   # duracion real creible (10 min - 4 h)
# v2.0.32 (L1/P1): articulos pedidos en tuberia por conexion.
PIPELINE = 2
GET_TIMEOUT = 45            # espera maxima por un segmento
# v2.0.31: segundos que espera el reproductor por un segmento EN VUELO antes de
# pedirlo tambien por otra conexion. kodi.log del 11-nov-2026 (The Dog Stars):
# una conexion de Easynews se quedo callada y el segmento 4 no se reintento
# hasta que salto el timeout del socket a los 21,5 s; la imagen se congelo
# ~10 s y ffmpeg dio el fichero por terminado. Un segmento normal llega en
# 0,1-0,5 s (se registra a partir de 2 s), asi que 3 s ya es una conexion
# atascada. Gana la primera copia que llegue; la otra se descarta.
HEDGE_SECS = 3
MAX_SESSIONS = 2
SCAN_MAX_FILES = 250       # tope de ficheros para reparar el orden de un RAR ofuscado
MAX_CONSECUTIVE_MISSING = 12
# Release incompleto: si de lo ya pedido falta el 3% o mas (con al menos 40
# segmentos de muestra) se corta. Log del 1-nov-2026: un remux de Coco paso
# la comprobacion de salud (15 muestras) y faltaba ~6%: 35 huecos en 605
# segmentos, la imagen rota cada pocos segundos.
INCOMPLETE_MIN_SEGMENTS = 40
INCOMPLETE_RATIO = 0.03

CONTENT_TYPES = {'mkv': 'video/x-matroska', 'mp4': 'video/mp4', 'avi': 'video/x-msvideo',
				 'ts': 'video/mp2t', 'm2ts': 'video/mp2t'}
STREAMABLE = ('mkv', 'mp4', 'avi', 'ts', 'm2ts')


def _noop_log(msg, level=None):
	pass


class SessionError(Exception):
	pass


def _vint_len(n):
	k = 1
	while n >= 0x80:
		n >>= 7
		k += 1
	return k


class Session(object):
	def __init__(self, key, nzb_path, cfg, log=_noop_log, on_incomplete=None, on_close=None, runtime=None, ram=None, budget=None):
		self.key = key
		self.on_close = on_close
		# v2.0.32 (informe N3): duracion real del video (s), si la sabe el plugin
		try: rt = int(float(runtime or 0))
		except (TypeError, ValueError): rt = 0
		self.runtime = rt if RUNTIME_MIN <= rt <= RUNTIME_MAX else None
		self.ram = ram                       # v2.0.32 (N5): RAM de todas las sesiones a la vez
		# v2.0.32 (informe L7, B1): proveedores de respaldo, por orden, solo
		# para lo que falta; cada uno con su grupo de conexiones compartido
		bks = (cfg or {}).get('backups')
		if bks is None:
			bk = (cfg or {}).get('backup')
			bks = [bk] if bk else []
		self.backups = [BackupPool(b, log) for b in bks if b and b.get('host')]
		self.backup = bool(self.backups)
		self.backup_hits = 0
		# v2.0.32: conexiones que crecen solo si hace falta
		self.budget = budget
		self.profile = PROFILES.get(int((cfg or {}).get('profile', 1) or 0), PROFILES[1])
		self.max_workers = max(1, int((cfg or {}).get('connections') or 4))
		self.idle_workers = 0
		self.grow_stop = False
		self.last_grow = 0.0
		# v2.0.32 (informe E1, 2.a parte): ultima vez que llego trabajo sin ningun
		# hilo libre. Si en CONN_IDLE_SECS siempre sobro alguno, sobra una conexion.
		self.last_short = time.time()
		self.last_retire = 0.0
		self.retiring = 0
		self.too_many_logged = False
		self.nzb_path = nzb_path
		self.cfg = dict(cfg)
		self.log = log
		self.lock = threading.RLock()
		self.cond = threading.Condition(self.lock)
		self.cache = OrderedDict()           # idx -> bytes
		self.inflight = set()
		self.queued = {}                     # idx -> mejor prioridad encolada
		self.failed = {}                     # idx -> motivo (error duro)
		self.missing = set()                 # idx rellenados con ceros (430)
		self.consecutive_missing = 0
		self.incomplete = None               # % que falta, si se corta
		self.on_incomplete = on_incomplete
		self.heap = []
		self.seq = 0
		self.readers = {}                    # id lector -> segmento actual
		self.closed = False
		self.last_use = time.time()
		self.workers = []
		self.ready = False
		self.info = {}
		self.stats = {'bytes': 0, 'segments': 0, 'started': time.time()}
		# v2.0.25: medidas para el informe de uso (Tools > Usenet report)
		self.conns = []                      # toda conexion abierta, para sumar sus bytes
		self.cpu = 0.0                       # s de CPU decodificando yEnc
		self.cache_peak = 0                  # bytes en RAM, maximo
		self.buckets = {}                    # tramo de 5 s -> bytes recibidos
		self.stalls = 0                      # esperas de mas de 2 s viendo de seguido
		self.stall_secs = 0.0
		self.seeks = 0
		self.last_idx = None
		self.reads = {}                      # lector -> segmentos leidos de seguido
		self.started_at = {}                 # idx en vuelo -> cuando se pidio al servidor
		self.hedged = set()                  # idx con copia de respaldo esperando hilo libre
		self.hedge_tried = set()             # idx a los que ya se pidio respaldo (una vez)
		self.copies = {}                     # idx en vuelo -> conexiones pidiendolo ahora
		self.hedges = 0
		self.reconnects = 0
		self.retries = 0
		self.lag_max = 0.0                   # mayor retraso del reloj de Python (diagnostico)
		self.is_rar = False
		self.nseg = 0
		self.spare = []                      # v2.0.32: la conexion de prepare(), para un hilo
		self.pinned = set()                  # v2.0.32: principio y final, nunca se expulsan

	# -- preparacion ---------------------------------------------------------
	def _fetch_first(self, conn, f):
		code, art = conn.body(f['segments'][0][2])
		if not art and code == core.NNTP_NO_ARTICLE and self.backup:
			code2, art = self._backup_body(f['segments'][0][2])
			if art:
				self.backup_hits += 1
				self.log('USENET: first article taken from a backup provider')
			else:
				code = code2 or code
		if not art:
			raise SessionError('first article not available (%s)' % code)
		return core.yenc_decode(art)

	# -- proveedores de respaldo (v2.0.32, informe L7 y B1) --------------------
	def _backup_body(self, msgid):
		"""(codigo, articulo o None) del primer proveedor de respaldo que lo tenga."""
		code = None
		for pool in self.backups:
			c, art = pool.body(msgid)
			if art:
				return c, art
			code = c or code
		return code, None

	@property
	def bk_conns(self):
		out = []
		for pool in self.backups:
			out.extend(pool.opened)
		return out

	def prepare(self):
		"""Abre el release: fichero directo (MKV/MP4/AVI/TS) o RAR 'store'
		(sin compresion) en uno o varios volumenes, con o sin nombres
		ofuscados. Lo que ve Kodi es el video de dentro.

		Modelo comun: una lista de volumenes, cada uno con sus segmentos y el
		trozo [data_off, data_off + data_size) que aporta al video. Un fichero
		directo es un unico 'volumen' con data_off 0. Los segmentos se numeran
		seguidos a traves de todos los volumenes (indice lineal), asi la cache,
		la lectura anticipada y el corte por incompleto no cambian.
		"""
		with open(self.nzb_path, 'rb') as f:
			files = core.parse_nzb(f.read())
		media, kind = core.pick_media(files)
		if not media:
			raise SessionError('no video file in NZB')
		if kind == '7z':
			return self._prepare_7z(files, core.seven_volumes(files), kind)
		vol_files = core.rar_volumes(files) if kind == 'rar' else [media]
		if not vol_files:
			raise SessionError('no RAR volumes found in NZB')
		second = tail = None
		conn = self._connect()
		try:
			first = self._fetch_first(conn, vol_files[0])
			container, detail = core.sniff(first['data'])
			if container not in STREAMABLE and container != 'rar' and kind == 'obfuscated':
				# El mayor fichero puede ser justo un ajeno del tamano de un
				# volumen: se prueban los primeros candidatos en su orden.
				for alt in core.rar_candidates(files)[:3]:
					if alt is media:
						continue
					try:
						cand = self._fetch_first(conn, alt)
					except SessionError:
						continue
					c2, d2 = core.sniff(cand['data'])
					if c2 == 'rar' or c2 in STREAMABLE:
						media, first, container, detail = alt, cand, c2, d2
						vol_files = [alt]
						break
			if container == '7z' and kind == 'obfuscated':
				# v2.0.28: un 7z de un solo volumen con nombre ofuscado
				conn.close(); conn = None
				return self._prepare_7z(files, [media], kind, first=first)
			if container == 'rar' and kind != 'rar':
				# ofuscado: el mayor fichero era un volumen; se ordenan todos
				vol_files = core.rar_volumes(files)
				if not vol_files:
					raise SessionError('RAR volumes not found (not streamable)')
				if vol_files[0] is not media:
					first = self._fetch_first(conn, vol_files[0])
			if container == 'rar':
				try:
					h1 = core.parse_rar(first['data'])
				except ValueError as e:
					raise SessionError('RAR: %s (not streamable)' % e)
				if h1['split_before']:
					# v2.0.32: el primer volumen "continua de otro". Antes se abandonaba
					# aqui (kodi.log del 11-nov-2026, Jimmy Fallon 2014 de CROOKS); la
					# reparacion por escaneo solo corria si fallaba un volumen
					# intermedio. Se mira el primer segmento de cada candidato y se
					# empieza por el que no continua de ninguno.
					cands = core.rar_volumes(files) if kind == 'rar' else core.rar_candidates(files)
					if len(cands) > SCAN_MAX_FILES:
						raise SessionError('RAR volumes out of order (not streamable)')
					try:
						vol_files = self._scan_rar(cands, h1['fmt'])
					except SessionError:
						raise SessionError('RAR first volume missing from the post (not streamable)')
					first = self._fetch_first(conn, vol_files[0])
					try:
						h1 = core.parse_rar(first['data'])
					except ValueError as e:
						raise SessionError('RAR: %s (not streamable)' % e)
					if h1['split_before']:
						raise SessionError('RAR first volume missing from the post (not streamable)')
					self.log('USENET: session %s: first RAR volume found by scanning %d files (%d volumes kept)'
							 % (self.key[:8], len(cands), len(vol_files)))
				if h1['encrypted']:
					raise SessionError('encrypted RAR (not streamable)')
				if not h1['store']:
					raise SessionError('compressed RAR (not streamable)')
				inner, idetail = core.sniff(first['data'][h1['data_off']:h1['data_off'] + 4096])
				if inner not in STREAMABLE:
					raise SessionError('RAR holds %s, not a playable video (not streamable)' % inner.upper())
				def _layout(vol_files):
					second = tail = None
					n = len(vol_files) if h1['split_after'] else 1
					if n < 2 and h1['split_after']:
						raise SessionError('RAR volumes missing from NZB (not streamable)')
					offs, sizes = [h1['data_off']], [h1['data_size']]
					if h1['split_after']:
						second = self._fetch_first(conn, vol_files[1])
						try:
							h2 = core.parse_rar(second['data'])
						except ValueError as e:
							raise SessionError('RAR volume 2: %s (not streamable)' % e)
						if not h2['split_before']:
							raise SessionError('RAR volume order mismatch (not streamable)')
						mid = h2['data_size']
						if mid <= 0:
							raise SessionError('RAR volume layout mismatch (not streamable)')
						# RAR5 guarda el numero de volumen como vint en la cabecera
						# principal: a partir del volumen 129 ocupa 2 bytes, la
						# cabecera crece 1 byte y el volumen lleva 1 byte menos de
						# datos (el tamano de volumen es fijo). RAR4 no lo guarda ahi.
						def _grow(k):
							if h1['fmt'] != 5: return 0
							return _vint_len(k) - _vint_len(1)
						# Cuantos volumenes hacen falta sale de las cabeceras, no de
						# cuantos ficheros trae el NZB: log del 1-nov-2026, Miami
						# Bici, un fichero de mas (par2 ofuscado) se tomo por el
						# ultimo volumen.
						rem = h1['unp_size'] - h1['data_size']
						k = 1
						while rem > 0:
							d = mid - _grow(k)
							if rem <= d:
								sizes.append(rem)
							else:
								sizes.append(d)
							rem -= d
							k += 1
							if k > 20000:
								raise SessionError('RAR volume layout mismatch (not streamable)')
						n = len(sizes)
						if n > len(vol_files):
							# Log del 1-nov-2026, Miami Bici de PlayWEB: el volumen 33 de 60
							# esta sustituido por otro fichero en el propio post. Sin
							# reparacion PAR2 no hay forma de reproducirlo.
							raise SessionError('damaged post: RAR volume missing on the server (%d of %d), needs PAR2 repair (not streamable)' % (len(vol_files), n))
						offs += [h2['data_off'] + _grow(k) for k in range(1, n)]
						last = sizes[-1]
						if n == 2:
							if h2['split_after'] or h2['data_size'] != last:
								raise SessionError('RAR last volume mismatch (not streamable)')
						else:
							# El ultimo volumen no sigue el patron: su cabecera no lleva
							# 'continua en el siguiente' y su tamano de datos ocupa menos
							# (RAR5 lo guarda como vint). Se lee su cabecera de verdad.
							tail = self._fetch_first(conn, vol_files[n - 1])
							try:
								ht = core.parse_rar(tail['data'])
							except ValueError as e:
								raise SessionError('RAR last volume: %s (not streamable)' % e)
							if ht['split_after'] or ht['data_size'] != last:
								raise SessionError('RAR last volume mismatch (not streamable)')
							offs[n - 1] = ht['data_off']
					elif h1['data_size'] != h1['unp_size']:
						raise SessionError('RAR volume missing from NZB (not streamable)')
					vol_files = vol_files[:n]
					return vol_files, offs, sizes, second, tail, n
				try:
					vol_files, offs, sizes, second, tail, n = _layout(vol_files)
				except SessionError as e:
					# Un fichero ajeno colado entre los volumenes (log del
					# 1-nov-2026, Miami Bici de PlayWEB: el 33 de 70 era otro
					# fichero del mismo tamano) descuadra todo el orden. Si el
					# release es ofuscado y no muy grande, se mira el primer
					# segmento de cada candidato, se quitan los que no son
					# volumenes RAR y se vuelve a intentar una vez.
					# Tambien con nombres: log del 1-nov-2026, Miami Bici de
					# PlayWEB traia los volumenes nombrados y el ajeno entre ellos.
					cands = core.rar_volumes(files) if kind == 'rar' else core.rar_candidates(files)
					if 'not streamable' not in str(e) or len(cands) > SCAN_MAX_FILES:
						raise
					vol_files = self._scan_rar(cands, h1['fmt'])
					self.log('USENET: session %s: RAR order repaired by scanning %d files (%d volumes kept)'
							 % (self.key[:8], len(cands), len(vol_files)))
					vol_files, offs, sizes, second, tail, n = _layout(vol_files)
				total = h1['unp_size']
				detail = 'RAR%d store, %d vol, %s' % (h1['fmt'], n, idetail)
				container = inner
				self.is_rar = True
			elif container in STREAMABLE:
				total = first['size']
				offs, sizes = [0], [total]
				self.is_rar = False
			else:
				raise SessionError('%s (%s) is not streamable yet' % (container.upper(), detail))
		except BaseException:
			if conn is not None: conn.close()
			raise
		# v2.0.32: la conexion de preparar se la queda el primer hilo de
		# descarga en vez de cerrarla y abrir otra (un TLS menos al arrancar).
		if conn is not None: self.spare.append(conn)
		return self._finish(media, kind, vol_files, offs, sizes, first, second, tail, total, container, detail)

	def _prepare_7z(self, files, vol_files, kind, first=None):
		"""v2.0.28: 7z 'store'. Volumen 1: el contenido empieza en el byte 32;
		los siguientes son el mismo archivo cortado a trozos, sin cabecera."""
		if not vol_files:
			raise SessionError('no 7z volumes found in NZB')
		tail = None
		conn = self._connect()
		try:
			if first is None:
				first = self._fetch_first(conn, vol_files[0])
			try:
				h = core.parse_7z(first['data'])
			except ValueError as e:
				raise SessionError('7z: %s (not streamable)' % e)
			inner, idetail = core.sniff(first['data'][h['data_off']:h['data_off'] + 4096])
			if inner not in STREAMABLE:
				raise SessionError('compressed 7z, or it holds %s and not a video (not streamable)' % inner.upper())
			vol_size = first['size']
			n = max(1, -(-h['archive'] // vol_size))
			if n > 1 and kind != '7z':
				raise SessionError('split 7z with hidden names (not streamable)')
			if n > len(vol_files):
				raise SessionError('damaged post: 7z volume missing on the server (%d of %d) (not streamable)' % (len(vol_files), n))
			vol_files = vol_files[:n]
			offs = [h['data_off']] + [0] * (n - 1)
			rem, sizes = h['packed'], []
			for k in range(n):
				room = vol_size - offs[k]
				sizes.append(min(rem, room))
				rem -= sizes[-1]
			if rem > 0:
				raise SessionError('7z volume layout mismatch (not streamable)')
			if n > 1:
				# los trozos de en medio miden lo mismo que el primero (mismos
				# articulos en el NZB); el ultimo, lo que falta del archivo: se
				# comprueba con su propio yEnc
				nfirst = len(vol_files[0]['segments'])
				if any(len(v['segments']) != nfirst for v in vol_files[1:n - 1]):
					raise SessionError('7z volumes of different sizes (not streamable)')
				tail = self._fetch_first(conn, vol_files[n - 1])
				if tail['size'] != h['archive'] - vol_size * (n - 1):
					raise SessionError('7z last volume mismatch (not streamable)')
				# el ultimo trozo puede llevar solo la cabecera final del 7z
				while n > 1 and sizes[-1] == 0:
					n -= 1; sizes.pop(); offs.pop(); vol_files = vol_files[:n]; tail = None
		finally:
			conn.close()
		detail = '7z store, %d vol, %s' % (n, idetail)
		return self._finish(vol_files[0], kind, vol_files, offs, sizes, first, None, tail, h['packed'], inner, detail)

	def _finish(self, media, kind, vol_files, offs, sizes, first, second, tail, total, container, detail):
		part = first['end'] - first['begin']
		if first['begin'] != 0 or part <= 0 or total <= 0:
			raise SessionError('unexpected yEnc layout')
		expected = (first['size'] + part - 1) // part
		if expected != len(vol_files[0]['segments']):
			raise SessionError('irregular segments (%d in NZB, %d expected)' % (len(vol_files[0]['segments']), expected))
		for extra, vf in ((second, vol_files[1] if len(vol_files) > 1 else None), (tail, vol_files[-1])):
			if extra is not None and len(vf['segments']) > 1 and extra['end'] - extra['begin'] != part:
				raise SessionError('RAR volumes posted with different segment sizes')
		self.vols = vol_files
		self.offs, self.sizes = offs, sizes
		self.base, self.starts = [], []
		nseg = vstart = 0
		for v, sz in zip(vol_files, sizes):
			self.base.append(nseg)
			self.starts.append(vstart)
			nseg += len(v['segments'])
			vstart += sz
		self.nseg = nseg
		self.verified = set([0, 1] if second is not None else [0])
		if tail is not None:
			self.verified.add(len(vol_files) - 1)
		self.layout_error = None
		self.name = media['name']
		self.part = part
		runtime = self.runtime or ASSUMED_RUNTIME
		secs, pmin, pmax = self.profile[0], self.profile[1] * 1048576, self.profile[2] * 1048576
		ahead = min(pmax, max(pmin, total * secs // runtime))
		self.prefetch = max(4, ahead // part)
		self.cache_max = max(8, (ahead + CACHE_EXTRA) // part)
		self.total = total
		self.container = container
		# Kodi relee el principio y el indice del MKV (al final) al saltar: esos
		# segmentos se quedan en la cache toda la sesion (auditoria L6).
		last = self._lin_for(total - 1)
		tail_from = self._lin_for(max(0, total - PIN_TAIL_BYTES))
		self.pinned = set(i for i in [0, 1] + list(range(tail_from, last + 1)) if 0 <= i < nseg)
		with self.lock:
			self.cache[0] = first['data']
			if second is not None:
				self.cache[self.base[1]] = second['data']
			if tail is not None:
				self.cache[self.base[-1]] = tail['data']
		self.info = {'ok': True, 'size': total, 'container': container, 'detail': detail,
					 'name': self.name if not kind == 'obfuscated' else '',
					 'segments': nseg, 'part': part, 'kind': kind, 'volumes': len(vol_files)}
		self.ready = True
		t = threading.Thread(target=self._watchdog, name='usenet-watchdog')
		t.daemon = True
		t.start()
		self.peak_workers = 0
		self._start_workers()
		self.peak_workers = len(self.workers)
		# el final del fichero lo pide Kodi casi siempre (indices del MKV)
		self.request(self._lin_for(total - 1), 5)
		self.log('USENET: session %s ready: %s %s, %.2f GB, %d segments of %d bytes; %d of up to %d connections; %d MB read ahead (%s), end %d MB kept%s'
				 % (self.key[:8], container, detail, total / 1073741824.0, nseg, part, len(self.workers), self.max_workers,
					self.prefetch * part // 1048576,
					'%d min long' % (self.runtime // 60) if self.runtime else 'length not known',
					(last - tail_from + 1) * part // 1048576,
					(', %d backup provider%s' % (len(self.backups), '' if len(self.backups) == 1 else 's')) if self.backup else ''))
		return self.info

	def _scan_rar(self, cands, fmt):
		"""Primer segmento de cada candidato (4 conexiones a la vez): se quedan
		los que son volumenes RAR del mismo formato, en orden, desde el que no
		continua de otro hasta el que no sigue en otro."""
		heads = [None] * len(cands)
		lock = threading.Lock()
		todo = list(range(len(cands)))

		def work():
			c = None
			try:
				c = self._connect()
				while True:
					with lock:
						if not todo: break
						i = todo.pop(0)
					try:
						code, art = c.body(cands[i]['segments'][0][2])
						if art:
							heads[i] = core.parse_rar(core.yenc_decode(art)['data'])
					except (ValueError, KeyError):
						heads[i] = None
			except Exception:
				pass
			finally:
				if c: c.close()
		th = [threading.Thread(target=work) for _ in range(4)]
		[t.start() for t in th]
		[t.join(120) for t in th]
		vols, started = [], False
		for f, h in zip(cands, heads):
			if not h or h.get('fmt') != fmt:
				continue
			if not started:
				if h['split_before']:
					continue
				started = True
			vols.append(f)
			if not h['split_after']:
				break
		if not vols:
			raise SessionError('RAR volumes not found after scan (not streamable)')
		return vols

	# -- mapa fichero virtual -> (volumen, segmento) --------------------------
	def _vol_of(self, pos):
		return bisect_right(self.starts, pos) - 1

	def _lin_for(self, pos):
		k = self._vol_of(pos)
		fo = self.offs[k] + (pos - self.starts[k])
		return self.base[k] + fo // self.part

	def _split(self, lin):
		k = bisect_right(self.base, lin) - 1
		return k, lin - self.base[k]

	def _check_volume(self, k, data):
		"""Cabecera real del volumen k frente a la supuesta (los intermedios
		iguales al 2). Si no cuadra se corta: mejor un error que video con
		trozos cruzados."""
		try:
			h = core.parse_rar(data)
		except ValueError as e:
			return 'volume %d: %s' % (k + 1, e)
		if h['data_off'] != self.offs[k] or h['data_size'] != self.sizes[k]:
			return ('volume %d layout differs (data at %d+%d, expected %d+%d)'
					% (k + 1, h['data_off'], h['data_size'], self.offs[k], self.sizes[k]))
		return None

	def _connect(self):
		c = self.cfg
		try:
			conn = core.NNTPConn(c['host'], c['port'], c['user'], c['password'],
								 timeout=c.get('timeout', 20), use_ssl=c.get('ssl', True))
		except core.NNTPTooMany as e:
			# Easynews no deja abrir mas: se crece hasta aqui y no mas
			with self.lock:
				self.grow_stop = True
				self.max_workers = max(1, min(self.max_workers, len(self.workers) - 1))
				first = not self.too_many_logged
				self.too_many_logged = True
			if first:
				self.log('USENET: Easynews allows no more connections right now (%s); staying at %d' % (e, self.max_workers))
			raise
		self.conns.append(conn)
		return conn

	# -- conexiones que crecen solo si hace falta (v2.0.32) ---------------------
	def _start_workers(self):
		start = min(self.max_workers, self.profile[3])
		for _ in range(start):
			if not self._spawn_worker():
				break

	def _spawn_worker(self):
		"""Con o sin self.lock: un hilo (y su conexion) mas, si el presupuesto de
		la cuenta lo permite. False si no se pudo."""
		if self.budget is not None and not self.budget.take():
			return False
		t = threading.Thread(target=self._worker_main, name='usenet-worker')
		t.daemon = True
		self.workers.append(t)
		t.start()
		return True

	def _maybe_grow(self):
		"""Con self.lock tomado: si hay trabajo en cola y ningun hilo libre, abre
		otra conexion (como mucho una cada GROW_EVERY s, hasta max_workers)."""
		if self.grow_stop or self.closed or not self.ready or self.idle_workers > 0 or not self.heap:
			return
		if len(self.workers) >= self.max_workers:
			return
		now = time.time()
		if now - self.last_grow < GROW_EVERY:
			return
		self.last_grow = now
		if self._spawn_worker():
			n = len(self.workers)
			if n > self.peak_workers: self.peak_workers = n

	def _worker_main(self):
		try:
			self._worker()
		except core.NNTPTooMany:
			pass
		except Exception as e:
			self.log('USENET: worker stopped: %s: %s' % (type(e).__name__, e))
		finally:
			with self.lock:
				try: self.workers.remove(threading.current_thread())
				except ValueError: pass
				if getattr(threading.current_thread(), 'retiring', False):
					self.retiring -= 1
				self.cond.notify_all()
			if self.budget is not None:
				self.budget.give()

	def wire_bytes(self):
		return sum(getattr(c, 'rx', 0) for c in list(self.conns))

	# -- cola de segmentos ---------------------------------------------------
	def request(self, idx, prio):
		if idx < 0 or idx >= self.nseg:
			return
		with self.lock:
			if idx in self.cache or idx in self.inflight:
				return
			old = self.queued.get(idx)
			if old is not None and old <= prio:
				return
			# v2.0.32: cada lectura vuelve a pedir toda la ventana con la distancia
			# como prioridad, y cada segmento entraba en la cola una vez por paso
			# (hasta ~125 veces en un remux). Ahora solo si la prioridad mejora a
			# la mitad o es urgente: unas 7 veces como mucho. Simulacion: la cola
			# llego a 494.712 entradas (~35 MB) leyendo un fichero de 200 MB.
			if old is not None and prio > 0 and prio > old // 2:
				return
			self.queued[idx] = prio
			self.seq += 1
			heappush(self.heap, (prio, self.seq, idx))
			if len(self.heap) > 4 * len(self.queued) + 256:
				self.heap = [(p_, sq, i) for (p_, sq, i) in self.heap if self.queued.get(i) == p_]
				heapify(self.heap)
			if len(self.heap) > self.idle_workers:
				self.last_short = time.time()   # mas trabajo que hilos libres
			self._maybe_grow()
			# v2.0.25: notify_all. Los lectores esperan en la misma condicion que los
			# hilos de descarga: notify() podia despertar a un lector en vez de a un
			# hilo libre, y el segmento esperaba al timeout del hilo (5 s). Log del
			# 2-nov-2026: una pausa de 4,7-4,9 s en cada reproduccion, siempre a los
			# 20-34 segmentos, con 78-228 Mb/s de linea.
			self.cond.notify_all()

	def _wanted(self, idx):
		for pos in self.readers.values():
			if pos - 1 <= idx <= pos + self.prefetch + 2:
				return True
		return idx == self.nseg - 1

	def _claim(self):
		"""Con self.lock tomado: el siguiente segmento de la cola que este hilo
		debe pedir, y si es la copia de respaldo de uno en vuelo. (None, False)
		si en la cola no queda nada util."""
		while self.heap:
			prio, _, idx = heappop(self.heap)
			if self.queued.get(idx) == prio:
				del self.queued[idx]
			if idx in self.cache:
				continue
			if idx in self.inflight:
				if idx not in self.hedged:
					continue
				self.hedged.discard(idx)   # copia de respaldo: una sola por segmento
				hedge = True
			else:
				if prio > 0 and not self._wanted(idx):
					continue           # prefetch viejo de antes de un seek
				self.inflight.add(idx)
				self.started_at[idx] = time.time()
				hedge = False
			self.copies[idx] = self.copies.get(idx, 0) + 1
			return idx, hedge
		return None, False

	def _release(self, idx):
		"""Con self.lock tomado: suelta un segmento tomado por un hilo que se va
		sin pedirlo (conexion rechazada) y lo devuelve a la cola, urgente."""
		left = self.copies.get(idx, 1) - 1
		if left > 0:
			self.copies[idx] = left
			return                       # otra copia sigue en camino
		self.copies.pop(idx, None)
		self.inflight.discard(idx)
		self.started_at.pop(idx, None)
		self.hedged.discard(idx)
		if idx in self.cache:
			return
		self.queued[idx] = 0
		self.seq += 1
		heappush(self.heap, (0, self.seq, idx))
		self.cond.notify_all()

	def _unclaim_hedge(self, idx):
		"""Con self.lock tomado: devuelve a la cola una copia de respaldo ya tomada."""
		left = self.copies.get(idx, 1) - 1
		if left > 0: self.copies[idx] = left
		else: self.copies.pop(idx, None)
		self.hedged.add(idx)
		self.seq += 1
		heappush(self.heap, (0, self.seq, idx))
		self.cond.notify_all()

	def _msgid(self, idx):
		vk, vi = self._split(idx)
		return self.vols[vk]['segments'][vi][2]

	def _decode(self, idx, code, art, tm=None):
		"""(datos, error, desplazamiento ajeno). Lanza NNTPError si el servidor
		contesto algo que no es el articulo ni un 430 (se reintenta).
		tm: (s hasta la respuesta, s en total) de ESTE articulo."""
		if art is None:
			if code == core.NNTP_NO_ARTICLE:
				if self.backup:
					c2, art = self._backup_body(self._msgid(idx))
					if art:
						self.backup_hits += 1
						if self.backup_hits <= 3:
							self.log('USENET: article %d/%d taken from a backup provider' % (idx + 1, self.nseg))
						return self._decode(idx, c2, art, None)
				return None, 'missing', None
			raise core.NNTPError('BODY %s' % code)
		tm = tm or (0, 0)
		if tm[1] > 2:
			self.log('USENET: segment %d took %.1fs from Easynews (answer after %.1fs, %d KB)'
					 % (idx + 1, tm[1], tm[0], len(art) // 1024))
		t_cpu = time.thread_time()
		dec = core.yenc_decode(art)
		self.cpu += time.thread_time() - t_cpu
		b5 = int(time.time() // 5)
		self.buckets[b5] = self.buckets.get(b5, 0) + len(art)
		vk, vi = self._split(idx)
		if dec['begin'] != vi * self.part:
			# v2.0.27. MEASURED (kodi.log 4-nov-2026, Esref Ruya 2x04
			# TURK265): the NZB pointed segments 24 and 39 at articles
			# from somewhere else (offsets 119238656 and 408252416, not
			# even on a segment boundary). Before, that was a hard
			# error: Kodi got a short read every 2 s and the episode
			# stopped after 30 s. It is treated as a missing article
			# now: zero-filled (a short glitch), counted towards the
			# 'release incomplete' limit like any other hole.
			return None, 'misplaced', dec['begin']
		if not dec['crc_ok']:
			self.log('USENET: crc mismatch on segment %d (kept)' % idx)
		return dec['data'], None, None

	def _fetch_one(self, conn, idx, fresh):
		"""Un segmento con hasta 3 intentos. (conexion, datos, error, ajeno)."""
		data, err, misplaced = None, None, None
		for attempt in range(3):
			if attempt and idx in self.cache:
				break                      # la copia de respaldo ya llego
			try:
				if conn is None:
					if attempt or not fresh: self.reconnects += 1
					conn = self._connect()
				code, art = conn.body(self._msgid(idx))
				data, err, misplaced = self._decode(idx, code, art, getattr(conn, 'timing', None))
				break
			except core.NNTPTooMany:
				if len(self.workers) > 1:
					with self.lock:
						self._release(idx)
					raise
				data, err = None, 'Easynews: too many connections'
				time.sleep(2)
			except Exception as e:
				data, err = None, '%s: %s' % (type(e).__name__, e)
				self.retries += 1
				if self.retries <= 5:
					self.log('USENET: segment %d, attempt %d failed (%.1fs in): %s'
							 % (idx + 1, attempt + 1, time.time() - self.stats['started'], err))
				try:
					if conn: conn.close()
				except Exception: pass
				conn = None
				time.sleep(0.5 * (attempt + 1))
		return conn, data, err, misplaced

	def _worker(self):
		with self.lock:
			conn = self.spare.pop() if self.spare else None
		fresh = True
		last_used = time.time()      # ultimo uso de la conexion (articulo o keep-alive)
		last_work = time.time()      # ultimo ARTICULO: lo que decide si sobra (informe E1)
		while True:
			batch, ping = [], False
			with self.lock:
				while not self.closed:
					idx, hedge = self._claim()
					if idx is not None:
						batch.append(idx)
						# v2.0.32: un segundo articulo en tuberia, si la cola tiene
						# otro (no detras de una copia de respaldo, que es urgente).
						if not hedge and PIPELINE > 1:
							idx2, hedge2 = self._claim()
							if idx2 is not None and hedge2:
								# v2.0.32 (informe N2): una copia de respaldo es urgente y
								# aqui iria detras de otro articulo: vuelve a la cola para
								# que la coja un hilo libre, sola.
								self._unclaim_hedge(idx2)
							elif idx2 is not None:
								batch.append(idx2)
						break
					idle = time.time() - last_used
					if conn is not None and idle > KEEPALIVE_SECS and self.readers:
						ping = True
						break
					if conn is not None and idle > CONN_IDLE_SECS and not self.readers:
						try: conn.close()
						except Exception: pass
						conn = None
					# v2.0.32 (informe E1): sin articulos desde hace CONN_IDLE_SECS,
					# aunque el keep-alive la siga usando cada 30 s
					# y viendo de seguido: el trabajo nuevo despierta a todos y se
					# reparte, asi que ninguno pasa 45 s parado aunque sobren. Si en
					# 45 s siempre hubo un hilo libre al llegar trabajo, se va uno
					# (como mucho uno cada RETIRE_EVERY s).
					now = time.time()
					spare = (now - self.last_short > CONN_IDLE_SECS and now - self.last_retire > RETIRE_EVERY)
					if len(self.workers) - self.retiring > self.profile[3] and (now - last_work > CONN_IDLE_SECS or spare):
						self.last_retire = now
						self.retiring += 1   # se descuenta al salir: nunca bajan de las de base
						threading.current_thread().retiring = True
						# una conexion de mas que ya no hace falta: se va (vuelve a
						# abrirse si la lectura se queda atras otra vez)
						if conn is not None:
							try: conn.close()
							except Exception: pass
						return
					self.idle_workers += 1
					try: self.cond.wait(1)
					finally: self.idle_workers -= 1
				if self.closed:
					break
			if ping:
				try:
					if not conn.ping(): raise core.NNTPError('DATE refused')
				except Exception:
					try: conn.close()
					except Exception: pass
					conn = None
				last_used = time.time()
				continue
			results = None
			if len(batch) > 1:
				try:
					if conn is None:
						if not fresh: self.reconnects += 1
						conn = self._connect()
					results = conn.body_many([self._msgid(i) for i in batch])
				except core.NNTPTooMany:
					with self.lock:
						for i in batch: self._release(i)
					raise
				except Exception as e:
					self.retries += 1
					if self.retries <= 5:
						self.log('USENET: pipelined segments %s failed (%.1fs in): %s: %s'
								 % ('+'.join(str(i + 1) for i in batch), time.time() - self.stats['started'], type(e).__name__, e))
					try:
						if conn: conn.close()
					except Exception: pass
					conn, results = None, None
			for n, idx in enumerate(batch):
				data = err = misplaced = None
				done = False
				if results is not None:
					try:
						tms = getattr(conn, 'timings', None) or []
						data, err, misplaced = self._decode(idx, results[n][0], results[n][1], tms[n] if n < len(tms) else None)
						done = True
					except Exception:
						done = False           # respuesta rara: se pide de nuevo solo
				if not done:
					conn, data, err, misplaced = self._fetch_one(conn, idx, fresh)
				fresh = False
				self._store(idx, data, err, misplaced)
			last_used = last_work = time.time()
		if conn:
			try: conn.close()
			except Exception: pass

	def _evict(self):
		"""Con self.lock tomado: expulsa lo mas antiguo hasta caber, salvo el
		principio y el final fijados y lo que algun lector tiene por delante."""
		tries = len(self.cache)
		while len(self.cache) > self.cache_max and tries > 0:
			tries -= 1
			k, v = self.cache.popitem(last=False)
			if k in self.pinned or any(pos <= k <= pos + self.prefetch for pos in self.readers.values()):
				self.cache[k] = v        # al final de la cola: se queda
		while len(self.cache) > self.cache_max + len(self.pinned):
			self.cache.popitem(last=False)   # tope duro, por si los lectores lo llenan todo

	def _store(self, idx, data, err, misplaced):
		vk, vi = self._split(idx)
		with self.lock:
			left_copies = self.copies.get(idx, 1) - 1
			if left_copies > 0:
				self.copies[idx] = left_copies
			else:
				self.copies.pop(idx, None)
				self.inflight.discard(idx)
				self.started_at.pop(idx, None)
				self.hedge_tried.discard(idx)
				self.hedged.discard(idx)
			if idx in self.cache or (err and err not in ('missing', 'misplaced') and left_copies > 0):
				# la otra copia ya llego, o sigue en camino y puede llegar bien:
				# esta no cuenta ni da el segmento por perdido
				self.cond.notify_all()
				return
			if err in ('missing', 'misplaced'):
				size = self._seg_len(idx)
				self.missing.add(idx)
				self.consecutive_missing += 1
				self.cache[idx] = b'\x00' * size
				if err == 'missing':
					self.log('USENET: article %d/%d missing on server, zero-filled' % (idx + 1, self.nseg))
				else:
					self.log('USENET: article %d/%d belongs elsewhere (yEnc offset %d, expected %d): wrong article in the NZB, zero-filled'
							 % (idx + 1, self.nseg, misplaced, vi * self.part))
			elif err:
				self.failed[idx] = err
				self.log('USENET: segment %d failed: %s' % (idx, err))
			else:
				self.consecutive_missing = 0
				self.cache[idx] = data
				if self.is_rar and vk not in self.verified and vi == 0:
					self.verified.add(vk)
					bad = self._check_volume(vk, data)
					if bad and not self.layout_error:
						self.layout_error = bad
						self.log('USENET: session %s stopped: RAR %s' % (self.key[:8], bad))
				self.stats['bytes'] += len(data)
				self.stats['segments'] += 1
			fetched = self.stats['segments'] + len(self.missing)
			if (self.incomplete is None and fetched >= INCOMPLETE_MIN_SEGMENTS
					and len(self.missing) >= INCOMPLETE_RATIO * fetched):
				self.incomplete = round(100.0 * len(self.missing) / fetched)
				self.log('USENET: session %s stopped: release incomplete on the server '
						 '(%d of %d articles missing, ~%d%%)' % (self.key[:8], len(self.missing), fetched, self.incomplete))
				if self.on_incomplete:
					try: self.on_incomplete(self.key, self.incomplete)
					except Exception: pass
			self._evict()
			held = len(self.cache) * self.part
			if held > self.cache_peak: self.cache_peak = held
			if self.ram is not None:
				self.ram.update(self.key, held)
			self.cond.notify_all()

	def _watchdog(self):
		"""Diagnostico: si Python entero se queda parado (otro addon ocupando el
		interprete, CPU al arrancar el video), este reloj lo nota."""
		while not self.closed:
			t = time.time()
			time.sleep(0.25)
			lag = time.time() - t - 0.25
			if lag > self.lag_max: self.lag_max = lag

	def _seg_len(self, idx):
		return self.part

	def get(self, idx, reader):
		self.last_use = time.time()
		with self.lock:
			prev = self.readers.get(reader)
			self.readers[reader] = idx
			# Kodi abre una peticion nueva en cada salto: cuenta como salto la que
			# empieza lejos de donde se iba leyendo (sin el final: indices del MKV)
			last = self.last_idx
			if prev is None and last is not None and abs(idx - last) > 2 and 2 < idx < self.nseg - 3:
				self.seeks += 1
			self.last_idx = idx
			# viendo de seguido (no un salto): esperar aqui es un parón en pantalla.
			# v2.0.25: sin contar el arranque ni lo justo despues de un salto (los
			# primeros segmentos de cada lectura los espera Kodi antes de pintar):
			# log del 2-nov-2026, una 'pausa' por reproduccion, siempre al empezar.
			n_read = self.reads.get(reader, 0) + 1 if prev is not None and idx == prev + 1 else 0
			self.reads[reader] = n_read
			watching = n_read > self.prefetch and idx not in self.cache
			if watching:   # para diagnosticar una pausa: como estaba el segmento al empezar a esperar
				w_state = ('in flight %.1fs' % (time.time() - self.started_at.get(idx, time.time()))) if idx in self.inflight else \
					(('queued, priority %s' % self.queued[idx]) if idx in self.queued else 'not requested')
				w_done, w_busy, w_heap = self.stats['segments'], len(self.inflight), len(self.heap)
				self.lag_max = 0.0
		t_wait = time.time()
		for k in range(idx + 1, min(idx + 1 + self.prefetch, self.nseg)):
			self.request(k, k - idx)
		# RAR: la cabecera de un volumen nuevo se comprueba en cuanto se entra
		if self.is_rar:
			vk, vi = self._split(idx)
			if vk not in self.verified and vi != 0:
				self.request(self.base[vk], 3)
		self.request(idx, 0)
		deadline = time.time() + GET_TIMEOUT
		with self.lock:
			while True:
				if self.incomplete is not None:
					raise SessionError('release incomplete on the server (~%d%% missing)' % self.incomplete)
				if self.layout_error:
					raise SessionError('RAR %s' % self.layout_error)
				if idx in self.cache:
					self.cache.move_to_end(idx)
					if watching:
						waited = time.time() - t_wait
						if waited > 2:
							self.stalls += 1
							self.stall_secs += waited
							self.log('USENET: pause of %.1fs while watching, segment %d/%d (%s; %d in flight, %d queued; '
									 '%d segments fetched meanwhile; Python held up to %.1fs; %d reconnects, %d retries so far)'
									 % (waited, idx + 1, self.nseg, w_state, w_busy, w_heap, self.stats['segments'] - w_done,
										self.lag_max, self.reconnects, self.retries))
					return self.cache[idx]
				if idx in self.failed:
					err = self.failed.pop(idx)
					raise SessionError('segment %d: %s' % (idx, err))
				if self.consecutive_missing >= MAX_CONSECUTIVE_MISSING:
					raise SessionError('too many missing articles in a row')
				if self.closed:
					raise SessionError('session closed')
				left = deadline - time.time()
				if left <= 0:
					raise SessionError('timeout waiting for segment %d' % idx)
				if idx not in self.inflight and self.queued.get(idx) is None:
					self.lock.release()
					try: self.request(idx, 0)
					finally: self.lock.acquire()
				elif (idx in self.inflight and idx not in self.hedge_tried
						and time.time() - self.started_at.get(idx, time.time()) > HEDGE_SECS):
					self.hedge_tried.add(idx)
					self.hedged.add(idx)
					self.hedges += 1
					self.seq += 1
					heappush(self.heap, (0, self.seq, idx))
					self.cond.notify_all()
					self.log('USENET: segment %d stuck %.1fs on one connection, asking another one too'
							 % (idx + 1, time.time() - self.started_at.get(idx, time.time())))
				self.cond.wait(min(left, 1))

	def iter_range(self, start, end, reader):
		"""Bytes [start, end] inclusive del fichero virtual, en trozos."""
		pos = start
		while pos <= end:
			k = self._vol_of(pos)
			fo = self.offs[k] + (pos - self.starts[k])
			vi = fo // self.part
			data = self.get(self.base[k] + vi, reader)
			off = fo - vi * self.part
			n = min(len(data) - off, end - pos + 1, self.starts[k] + self.sizes[k] - pos)
			if n <= 0:
				raise SessionError('empty chunk at %d' % pos)
			yield data[off:off + n]
			pos += n

	def drop_reader(self, reader):
		with self.lock:
			self.readers.pop(reader, None)
			self.reads.pop(reader, None)

	def close(self):
		with self.lock:
			if self.closed:
				return
			self.closed = True
			self.cond.notify_all()
		for pool in self.backups:
			pool.close()
		if self.ram is not None:
			self.ram.drop(self.key)
		if self.ready:
			self.log('USENET: session %s closed: %.1f MB in %d segments, %d missing, up to %d connections%s'
					 % (self.key[:8], self.stats['bytes'] / 1e6, self.stats['segments'], len(self.missing),
						getattr(self, 'peak_workers', 0),
						(', %d from the backup providers' % self.backup_hits) if self.backup_hits else ''))
		if self.on_close:
			try: self.on_close(self.summary())
			except Exception: pass

	def summary(self):
		"""Lo que costo esta sesion: para el informe de uso (Tools > Usenet report)."""
		busy = [b for b in self.buckets.values() if b > 0]
		mbps = lambda b: b * 8 / 5.0 / 1e6
		return {'key': self.key, 'ready': bool(self.ready), 'wire': self.wire_bytes(),
				'bytes': self.stats['bytes'], 'segments': self.stats['segments'],
				'missing': len(self.missing), 'size': getattr(self, 'total', 0),
				'secs': round(time.time() - self.stats['started'], 1), 'cpu': round(self.cpu, 2),
				'peak_mbps': round(max(mbps(b) for b in busy), 1) if busy else 0,
				'avg_mbps': round(sum(mbps(b) for b in busy) / len(busy), 1) if busy else 0,
				'cache_peak': self.cache_peak, 'cache_max': getattr(self, 'cache_max', 0) * getattr(self, 'part', 0),
				'stalls': self.stalls, 'stall_secs': round(self.stall_secs, 1), 'seeks': self.seeks,
				'incomplete': self.incomplete, 'rar': bool(self.is_rar),
				'volumes': len(getattr(self, 'vols', []) or []), 'conns': getattr(self, 'peak_workers', 0) or int(self.cfg.get('connections') or 4),
				'conns_max': self.max_workers,
				'runtime': self.runtime or 0, 'backup_hits': self.backup_hits,
				'ram_peak': self.ram.peak if self.ram is not None else self.cache_peak,
				'backup_wire': sum(getattr(c, 'rx', 0) for c in list(self.bk_conns))}


class BackupPool(object):
	"""v2.0.32 (informe L7, arreglo B1): un proveedor de respaldo con un grupo
	de N conexiones COMPARTIDO entre los hilos: nunca se abren mas de las del
	ajuste (antes cada hilo abria la suya y con 2 configuradas salian 5)."""
	def __init__(self, cfg, log=_noop_log):
		self.cfg = cfg
		self.log = log
		self.size = max(1, int(cfg.get('connections') or 2))
		self.name = cfg.get('name') or 'backup provider'
		self.cond = threading.Condition(threading.Lock())
		self.free = []          # conexiones abiertas y libres
		self.opened = []        # todas las que se abrieron (bytes para el informe)
		self.alive = 0          # abiertas ahora (libres + en uso)
		self.failed = False     # login rechazado: no se insiste en esta sesion

	def _open(self):
		b = self.cfg
		try:
			return core.NNTPConn(b['host'], int(b.get('port') or 563), b.get('user') or '', b.get('password') or '',
								 timeout=b.get('timeout', 20), use_ssl=b.get('ssl', True))
		except core.NNTPTooMany as e:
			self.log('USENET: %s allows no more connections (%s)' % (self.name, e))
		except core.NNTPAuthError as e:
			self.failed = True
			self.log('USENET: %s refused the login (%s)' % (self.name, e))
		except Exception as e:
			self.log('USENET: %s not reachable: %s: %s' % (self.name, type(e).__name__, e))
		return None

	def _get(self, wait=30):
		"""Una conexion del grupo (espera a que quede una libre), o None."""
		deadline = time.time() + wait
		with self.cond:
			while True:
				if self.failed:
					return None
				if self.free:
					return self.free.pop()
				if self.alive < self.size:
					self.alive += 1
					break
				left = deadline - time.time()
				if left <= 0:
					return None
				self.cond.wait(left)
		conn = self._open()           # fuera del lock: conectar tarda
		with self.cond:
			if conn is None:
				self.alive -= 1
				self.cond.notify()
			else:
				self.opened.append(conn)
		return conn

	def _put(self, conn, broken=False):
		with self.cond:
			if broken:
				self.alive -= 1
			else:
				self.free.append(conn)
			self.cond.notify()
		if broken:
			try: conn.close()
			except Exception: pass

	def body(self, msgid):
		if self.failed:
			return None, None
		for attempt in range(2):
			conn = self._get()
			if conn is None:
				return None, None
			try:
				r = conn.body(msgid)
			except Exception:
				self._put(conn, broken=True)
				continue
			self._put(conn)
			return r
		return None, None

	def stat_many(self, ids):
		conn = self._get()
		if conn is None:
			raise core.NNTPError('%s not available' % self.name)
		try:
			r = conn.stat_many(ids)
		except Exception:
			self._put(conn, broken=True)
			raise
		self._put(conn)
		return r

	def close(self):
		with self.cond:
			conns, self.free = list(self.free), []
		for c in conns:
			try: c.close()
			except Exception: pass


class ConnBudget(object):
	"""v2.0.32: conexiones de Easynews que pueden abrir todas las sesiones a
	la vez, para no pasar de las 60 de la cuenta (y dejar las de la salud)."""
	def __init__(self, total):
		self.total = max(1, total)
		self.used = 0
		self.lock = threading.Lock()

	def take(self):
		with self.lock:
			if self.used >= self.total:
				return False
			self.used += 1
			return True

	def give(self):
		with self.lock:
			self.used = max(0, self.used - 1)


class RamMeter(object):
	"""v2.0.32 (informe N5): bytes en RAM de todas las sesiones a la vez y su
	maximo, para el informe de uso (hasta MAX_SESSIONS a la vez)."""
	def __init__(self):
		self.lock = threading.Lock()
		self.held = {}
		self.peak = 0

	def update(self, key, nbytes):
		with self.lock:
			self.held[key] = nbytes
			total = sum(self.held.values())
			if total > self.peak: self.peak = total

	def drop(self, key):
		with self.lock:
			self.held.pop(key, None)


class Engine(object):
	"""Registro de sesiones + configuracion. Uno por servicio."""

	def __init__(self, nzb_dir, cfg_provider, log=_noop_log, on_incomplete=None, on_close=None):
		self.nzb_dir = nzb_dir
		self.on_close = on_close
		self.cfg_provider = cfg_provider
		self.log = log
		self.sessions = OrderedDict()
		self.on_incomplete = on_incomplete
		self.lock = threading.Lock()
		self.prep_locks = {}
		self.ram = RamMeter()
		self.budget = ConnBudget(ACCOUNT_CONNS - HEALTH_RESERVE)
		self.runtimes = {}                   # clave -> duracion pasada en /prepare

	def nzb_path(self, key):
		return os.path.join(self.nzb_dir, '%s.nzb' % key)

	def prepare(self, key, runtime=None):
		if not KEY_RE.match(key or ''):
			return {'ok': False, 'reason': 'bad key'}
		if runtime:
			self.runtimes[key] = runtime
			while len(self.runtimes) > 50: self.runtimes.pop(next(iter(self.runtimes)))
		runtime = self.runtimes.get(key)
		with self.lock:
			plock = self.prep_locks.setdefault(key, threading.Lock())
		with plock:
			with self.lock:
				s = self.sessions.get(key)
			if s and s.ready and not s.closed and s.incomplete is None:
				s.last_use = time.time()
				return s.info
			if s and s.incomplete is not None:
				return {'ok': False, 'reason': 'release incomplete on Easynews (~%d%% missing)' % s.incomplete}
			path = self.nzb_path(key)
			if not os.path.exists(path):
				return {'ok': False, 'reason': 'NZB not found'}
			cfg = self.cfg_provider()
			if not cfg or not cfg.get('user') or not cfg.get('password'):
				return {'ok': False, 'reason': 'Easynews credentials not set'}
			s = Session(key, path, cfg, self.log, self.on_incomplete, self.on_close, runtime=runtime, ram=self.ram, budget=self.budget)
			try:
				info = s.prepare()
			except core.NNTPAuthError as e:
				s.close()
				return {'ok': False, 'reason': 'Easynews login refused (%s)' % e}
			except Exception as e:
				s.close()
				self.log('USENET: prepare %s failed: %s: %s' % (key[:8], type(e).__name__, e))
				return {'ok': False, 'reason': str(e) or type(e).__name__}
			with self.lock:
				old = self.sessions.pop(key, None)
				self.sessions[key] = s
				extra = []
				while len(self.sessions) > MAX_SESSIONS:
					extra.append(self.sessions.popitem(last=False)[1])
			for o in ([old] if old else []) + extra:
				o.close()
			return info

	def get(self, key):
		with self.lock:
			s = self.sessions.get(key)
		if s and s.ready and not s.closed:
			return s
		return None

	def close(self, key=None):
		with self.lock:
			if key is None:
				items = list(self.sessions.values()); self.sessions.clear()
			else:
				s = self.sessions.pop(key, None); items = [s] if s else []
		for s in items:
			s.close()

	def reap(self):
		now = time.time()
		with self.lock:
			dead = [k for k, s in self.sessions.items()
					if now - s.last_use > SESSION_IDLE_SECS and not s.readers]
		for k in dead:
			self.close(k)


class _Server(ThreadingMixIn, HTTPServer):
	daemon_threads = True
	allow_reuse_address = True
	engine = None


class _Handler(BaseHTTPRequestHandler):
	protocol_version = 'HTTP/1.1'
	server_version = 'luc_kodi-usenet'

	def log_message(self, fmt, *args):
		pass

	def _send_plain(self, code, body, ctype='text/plain'):
		if isinstance(body, str):
			body = body.encode('utf-8')
		self.send_response(code)
		self.send_header('Content-Type', ctype)
		self.send_header('Content-Length', str(len(body)))
		self.send_header('Connection', 'close')
		self.end_headers()
		if self.command != 'HEAD':
			try: self.wfile.write(body)
			except Exception: pass
		self.close_connection = True

	def do_HEAD(self):
		self.do_GET()

	def do_GET(self):
		engine = self.server.engine
		parts = [p for p in self.path.split('?', 1)[0].split('/') if p]
		if not parts:
			return self._send_plain(404, 'not found')
		if parts[0] == 'ping':
			return self._send_plain(200, 'luc_kodi-usenet')
		if parts[0] == 'prepare' and len(parts) >= 2:
			rt = None
			if '?' in self.path:   # v2.0.32 (N3): ?rt=<segundos de video>
				from urllib.parse import parse_qs
				try: rt = int((parse_qs(self.path.split('?', 1)[1]).get('rt') or [0])[0])
				except (TypeError, ValueError): rt = None
			info = engine.prepare(parts[1], runtime=rt)
			return self._send_plain(200, json.dumps(info), 'application/json')
		if parts[0] == 'close' and len(parts) >= 2:
			engine.close(parts[1])
			return self._send_plain(200, 'closed')
		if parts[0] == 'stream' and len(parts) >= 2:
			return self._stream(engine, parts[1])
		return self._send_plain(404, 'not found')

	def _stream(self, engine, key):
		s = engine.get(key)
		if s is None:
			# Kodi puede volver a una URL tras cerrar la sesion por inactividad
			info = engine.prepare(key)
			s = engine.get(key) if info.get('ok') else None
			if s is None:
				return self._send_plain(404, info.get('reason') or 'no session')
		total = s.total
		start, end = 0, total - 1
		rng = self.headers.get('Range')
		partial = False
		if rng:
			m = re.match(r'bytes=(\d*)-(\d*)', rng.strip())
			if m:
				a, b = m.group(1), m.group(2)
				if a == '' and b:
					start = max(0, total - int(b))
				else:
					start = int(a or 0)
					if b: end = min(int(b), total - 1)
				partial = True
		if start >= total or start > end:
			self.send_response(416)
			self.send_header('Content-Range', 'bytes */%d' % total)
			self.send_header('Content-Length', '0')
			self.end_headers()
			return
		length = end - start + 1
		self.send_response(206 if partial else 200)
		self.send_header('Content-Type', CONTENT_TYPES.get(s.container, 'application/octet-stream'))
		self.send_header('Accept-Ranges', 'bytes')
		self.send_header('Content-Length', str(length))
		if partial:
			self.send_header('Content-Range', 'bytes %d-%d/%d' % (start, end, total))
		self.end_headers()
		if self.command == 'HEAD':
			return
		reader = '%s-%s' % (threading.get_ident(), time.time())
		try:
			for chunk in s.iter_range(start, end, reader):
				self.wfile.write(chunk)
		except (BrokenPipeError, ConnectionResetError, ConnectionAbortedError, socket.timeout):
			pass   # Kodi corta la conexion al hacer seek: es lo normal
		except SessionError as e:
			engine.log('USENET: stream %s stopped: %s' % (key[:8], e))
		except Exception as e:
			engine.log('USENET: stream %s error: %s: %s' % (key[:8], type(e).__name__, e))
		finally:
			s.drop_reader(reader)
			self.close_connection = True


class StreamServer(object):
	def __init__(self, nzb_dir, cfg_provider, log=_noop_log, ports=PORT_RANGE, on_incomplete=None, on_close=None):
		self.engine = Engine(nzb_dir, cfg_provider, log, on_incomplete, on_close)
		self.log = log
		self.ports = ports
		self.httpd = None
		self.port = None
		self._stop = threading.Event()

	def start(self):
		for p in self.ports:
			try:
				httpd = _Server(('127.0.0.1', p), _Handler)
			except OSError:
				continue
			httpd.engine = self.engine
			self.httpd, self.port = httpd, p
			t = threading.Thread(target=httpd.serve_forever, kwargs={'poll_interval': 0.5}, name='usenet-httpd')
			t.daemon = True
			t.start()
			r = threading.Thread(target=self._reaper, name='usenet-reaper')
			r.daemon = True
			r.start()
			self.log('USENET: stream server listening on 127.0.0.1:%d' % p)
			return p
		self.log('USENET: no free port for the stream server')
		return None

	def _reaper(self):
		while not self._stop.wait(30):
			try: self.engine.reap()
			except Exception: pass

	def stop(self):
		self._stop.set()
		try: self.engine.close()
		except Exception: pass
		if self.httpd:
			try:
				self.httpd.shutdown()
				self.httpd.server_close()
			except Exception: pass
