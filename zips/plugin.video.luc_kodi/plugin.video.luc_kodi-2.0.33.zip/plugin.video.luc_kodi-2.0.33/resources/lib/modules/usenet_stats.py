# -*- coding: utf-8 -*-
"""
	luc_kodi Add-on
	usenet_stats.py (v2.0.25) - what Easynews + Newznab cost, for Tools > Usenet report.

	A small event log on the device (usenet/usage.db in the profile). Nothing is sent
	anywhere and no credential is stored: an event carries a time, a kind, the NZB key
	(md5 of the indexer link, the same 'hash' the scraper uses), a title and a few
	numbers. The report is worked out from it only when the window is opened.

	  search   one call to the indexer API          {indexer, results}
	  limits   API and grab use, when the indexer   {apicurrent, apimax, grabcurrent, grabmax}
	           reports them (newznab:apilimits)
	  grab     NZB downloaded from the indexer      {bytes}
	  cached   NZB taken from the device instead    {}
	  health   availability check of one search     {checked, ok, partial, dead, secs, groups}
	  resolve  NZB handed to the Easynews engine    {size}
	title    what Kodi is playing for that NZB    {}
	  play     Easynews engine session closed       see usenet_stream.Session.summary()
	  web      Easynews web-search playback (HTTP)  {size, watched, duration, est}

	Every write is best effort: a failure here never touches a search or a playback.
"""

import json
import os
import sqlite3
import threading
import time

KEEP_DAYS = 120
_lock = threading.Lock()
_pruned = [0.0]


def _path():
	from resources.lib.modules import control
	d = os.path.join(control.dataPath, 'usenet')
	if not os.path.isdir(d):
		os.makedirs(d)
	return os.path.join(d, 'usage.db')


def _db():
	con = sqlite3.connect(_path(), timeout=5)
	con.execute('CREATE TABLE IF NOT EXISTS ev (ts REAL, kind TEXT, key TEXT, title TEXT, data TEXT)')
	con.execute('CREATE INDEX IF NOT EXISTS ev_ts ON ev (ts)')
	return con


def record(kind, key='', title='', **data):
	try:
		with _lock:
			con = _db()
			try:
				con.execute('INSERT INTO ev VALUES (?, ?, ?, ?, ?)',
							(time.time(), kind, key or '', (title or '')[:200], json.dumps(data, separators=(',', ':'))))
				now = time.time()
				if now - _pruned[0] > 86400:
					_pruned[0] = now
					con.execute('DELETE FROM ev WHERE ts < ?', (now - KEEP_DAYS * 86400,))
				con.commit()
			finally:
				con.close()
	except Exception:
		pass


def events(since=0, kinds=None):
	"""[(ts, kind, key, title, data)] from `since`, oldest first."""
	try:
		with _lock:
			con = _db()
			try:
				rows = con.execute('SELECT ts, kind, key, title, data FROM ev WHERE ts >= ? ORDER BY ts', (since,)).fetchall()
			finally:
				con.close()
	except Exception:
		return []
	out = []
	for ts, kind, key, title, data in rows:
		if kinds and kind not in kinds: continue
		try: d = json.loads(data or '{}')
		except ValueError: d = {}
		out.append((ts, kind, key, title, d))
	return out


def clear():
	try:
		with _lock:
			p = _path()
			if os.path.exists(p): os.remove(p)
		return True
	except Exception:
		return False


def db_size():
	try: return os.path.getsize(_path())
	except Exception: return 0


# ------------------------------------------------------------- indexer -------
def parse_limits(body):
	"""newznab:apilimits from a search answer, when the indexer sends it:
	<newznab:apilimits apicurrent="12" apimax="5000" grabcurrent="3" grabmax="100" .../>"""
	import re
	try:
		if isinstance(body, bytes): body = body[:4096].decode('utf-8', 'replace')
		m = re.search(r'<[\w:]*apilimits\b([^>]*)>', (body or '')[:4096], re.I)
		if not m: return None
		out = {}
		for k in ('apicurrent', 'apimax', 'grabcurrent', 'grabmax'):
			v = re.search(r'\b%s="(\d+)"' % k, m.group(1), re.I)
			if v: out[k] = int(v.group(1))
		return out or None
	except Exception:
		return None


def note_search(indexer, body, results):
	record('search', indexer=indexer or '', results=int(results or 0))
	lim = parse_limits(body)
	if lim: record('limits', indexer=indexer or '', **lim)


# --------------------------------------------------------------- report ------
def _gb(n):
	return (n or 0) / 1073741824.0


def report(days):
	"""Everything the window shows for the last `days` days (0 = today)."""
	now = time.time()
	if days <= 0:
		lt = time.localtime(now)
		since = time.mktime((lt.tm_year, lt.tm_mon, lt.tm_mday, 0, 0, 0, 0, 0, -1))
	else:
		since = now - days * 86400
	ev = events(since)
	titles = {}
	for _ts, kind, key, title, _d in events(since - 3 * 86400, ('resolve', 'title')):
		if key and title and (kind == 'title' or key not in titles): titles[key] = title
	r = {'since': since, 'days': days,
		 'nntp_bytes': 0, 'nntp_plays': 0, 'nntp_failed': 0, 'web_bytes': 0, 'web_plays': 0,
		 'searches': 0, 'results': 0, 'grabs': 0, 'grab_bytes': 0, 'cached': 0, 'limits': None,
		 'checked': 0, 'ok': 0, 'partial': 0, 'dead': 0, 'unplayable': 0, 'header_bytes': 0, 'check_secs': 0.0, 'checks': 0, 'groups': {},
		 'cpu': 0.0, 'cpu_bytes': 0, 'peak_mbps': 0.0, 'avg_mbps': [], 'cache_peak': 0, 'cache_max': 0,
		 'ram_peak': 0, 'backup_hits': 0, 'backup_bytes': 0, 'conns_peak': 0, 'conns_max': 0,
		 'stalls': 0, 'stall_secs': 0.0, 'missing': 0, 'incomplete': 0, 'history': []}
	for ts, kind, key, title, d in ev:
		if kind == 'search':
			r['searches'] += 1; r['results'] += d.get('results', 0)
		elif kind == 'limits':
			r['limits'] = dict(d, ts=ts)
		elif kind == 'grab':
			r['grabs'] += 1; r['grab_bytes'] += d.get('bytes', 0)
		elif kind == 'cached':
			r['cached'] += 1
		elif kind == 'health':
			r['checks'] += 1
			for k in ('checked', 'ok', 'partial', 'dead', 'unplayable'): r[k] += d.get(k, 0)
			r['check_secs'] += d.get('secs', 0)
			r['header_bytes'] += d.get('header_bytes', 0)
			for g, (c, x) in (d.get('groups') or {}).items():
				a = r['groups'].setdefault(g, [0, 0]); a[0] += c; a[1] += x
		elif kind == 'headers':   # v2.0.33: cabeceras leidas con la lista ya abierta
			r['header_bytes'] += d.get('header_bytes', 0)
		elif kind == 'play':
			wire = d.get('wire', 0)
			r['nntp_bytes'] += wire
			if not d.get('ready'):
				r['nntp_failed'] += 1
				continue
			r['nntp_plays'] += 1
			r['cpu'] += d.get('cpu', 0); r['cpu_bytes'] += d.get('bytes', 0)
			r['peak_mbps'] = max(r['peak_mbps'], d.get('peak_mbps', 0))
			if d.get('avg_mbps'): r['avg_mbps'].append(d['avg_mbps'])
			r['cache_peak'] = max(r['cache_peak'], d.get('cache_peak', 0))
			r['cache_max'] = max(r['cache_max'], d.get('cache_max', 0))
			r['ram_peak'] = max(r['ram_peak'], d.get('ram_peak', 0), d.get('cache_peak', 0))
			r['backup_hits'] += d.get('backup_hits', 0); r['backup_bytes'] += d.get('backup_wire', 0)
			r['conns_peak'] = max(r['conns_peak'], d.get('conns', 0) if 'conns_max' in d else 0)
			r['conns_max'] = max(r['conns_max'], d.get('conns_max', 0))
			r['stalls'] += d.get('stalls', 0); r['stall_secs'] += d.get('stall_secs', 0)
			r['missing'] += d.get('missing', 0)
			r['max_size'] = max(r.get('max_size', 0), d.get('size', 0))
			if d.get('incomplete') is not None: r['incomplete'] += 1
			r['history'].append({'ts': ts, 'title': titles.get(key) or title or key[:8], 'path': 'NNTP',
								 'bytes': wire, 'mbps': d.get('peak_mbps', 0), 'stalls': d.get('stalls', 0),
								 'cut': d.get('incomplete') is not None, 'missing': d.get('missing', 0)})
		elif kind == 'web':
			r['web_bytes'] += d.get('est', 0); r['web_plays'] += 1
			r['history'].append({'ts': ts, 'title': title or 'Easynews', 'path': 'Web', 'bytes': d.get('est', 0),
								 'mbps': 0, 'stalls': 0, 'cut': False, 'missing': 0, 'estimate': True})
	r['avg_mbps'] = round(sum(r['avg_mbps']) / len(r['avg_mbps']), 1) if r['avg_mbps'] else 0
	r['history'] = sorted(r['history'], key=lambda h: -h['ts'])[:20]
	# groups worth naming: seen at least 3 times, most often gone first
	g = [(name, c, x) for name, (c, x) in r['groups'].items() if c >= 3]
	r['groups'] = sorted(g, key=lambda t: (-t[2] / float(t[1]), -t[1]))[:5]
	return r
