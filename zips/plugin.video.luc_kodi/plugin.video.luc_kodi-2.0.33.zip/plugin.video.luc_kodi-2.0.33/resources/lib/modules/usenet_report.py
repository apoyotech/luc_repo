# -*- coding: utf-8 -*-
"""
	luc_kodi Add-on
	usenet_report.py (v2.0.25) - Tools > Usenet report: what Easynews + Newznab cost.

	The window (windows/usenet_report.py, skin usenet_report.xml) shows four sections
	worked out from the event log in modules/usenet_stats.py when it opens:

	  EASYNEWS     what is left of the plan (read from the Easynews account itself),
	               what the playback engine downloaded over NNTP (counted byte by byte)
	               and what web-search files played by Kodi used (estimated from their
	               size and the time watched; Kodi downloads those itself)
	  NEWZNAB      searches, NZBs downloaded from the indexer (grabs), grabs saved
	               because the NZB was already on the device, the indexer's own API and
	               grab counters when it sends them, and how many releases were gone
	  DEVICE       memory, speed, processor time, pauses while watching, missing pieces,
	               storage
	  PLAYBACKS    the last ones, newest first

	sections() is plain data (no Kodi objects), so it can be checked outside Kodi.
"""

import os
import time

from resources.lib.modules import control
from resources.lib.modules import log_utils
from resources.lib.modules import usenet_stats

GREEN, ORANGE, RED, GREY, BLUE, GOLD = 'FF00D488', 'FFFFAA44', 'FFFF6B6B', 'FF9A9AC4', 'FF00C8FF', 'FFFDB515'
PERIODS = (('today', 0, 'Today'), ('week', 7, 'Last 7 days'), ('month', 30, 'Last 30 days'))


def _size(n, approx=False):
	n = float(n or 0)
	if n >= 1073741824: s = '%.2f GB' % (n / 1073741824)
	elif n >= 1048576: s = '%.0f MB' % (n / 1048576)
	elif n > 0: s = '%.0f KB' % max(1, n / 1024)
	else: s = '0 MB'
	return ('~' + s) if approx and n else s


def _when(ts):
	lt = time.localtime(ts)
	if time.strftime('%Y%m%d', lt) == time.strftime('%Y%m%d'): return time.strftime('%H:%M', lt)
	return time.strftime('%d %b', lt)


def _dir_size(path):
	total = 0
	for d, _, files in os.walk(path):
		for f in files:
			try: total += os.path.getsize(os.path.join(d, f))
			except OSError: pass
	return total


def account():
	"""What the Easynews account pages say: {'left', 'used', 'plan'} or {} (network).
	Read the same way as Tools > Easynews: Account Info, by its labels."""
	try:
		from resources.lib.debrid.easynews import EasyNews
		en = EasyNews()
		if not getattr(en, 'auth', None): return {}
		account_info, usage_info = en.account()
		if account_info and usage_info:
			import re
			return {'plan': account_info[1], 'used': usage_info[0].replace('Gigs', 'GB'),
					'left': re.sub(r'[</].+?>', '', usage_info[1].replace('Gigs', 'GB')).strip(),
					'expires': (account_info[2] or '').strip()}
		p = getattr(en, '_pairs', {}) or {}
		out = {'plan': en._pick(p, 'plan', 'package', 'service'), 'used': en._pick(p, 'used', 'usage', 'download'),
			   'left': en._pick(p, 'remain', 'left', 'available'), 'expires': en._pick(p, 'expir', 'renew', 'next bill')}
		return {k: v.replace('Gigs', 'GB') for k, v in out.items() if v}
	except Exception:
		log_utils.error('usenet_report: account: ')
		return {}


def _row(label, note='', value='', dot=GREY, notecolor=None):
	return {'label': label, 'note': note, 'value': value, 'dot': dot, 'notecolor': notecolor}


def sections(days, acct=None):
	"""[(title, note, [row, ...])] for the period. acct: account() result, None while
	it is still being read, {} when it could not be read."""
	r = usenet_stats.report(days)
	try:
		from resources.lib.modules import usenet_easynews as ue
		en_on = ue.enabled()
		usenet_dir = ue._usenet_dir()
	except Exception:
		en_on, usenet_dir = False, ''
	out = []

	# EASYNEWS -----------------------------------------------------------------
	rows = []
	if acct is None:
		rows.append(_row('Plan left', 'reading your Easynews account...', '...', GREY))
	elif acct.get('left') or acct.get('used'):
		if acct.get('left'): rows.append(_row('Plan left', 'from your Easynews account', acct['left'], GREEN))
		if acct.get('used'): rows.append(_row('Used this period', 'billing period, every device', acct['used'], BLUE))
		if acct.get('expires'): rows.append(_row('Plan ends', 'renews or expires on', acct['expires'], GREY))
	else:
		rows.append(_row('Plan left', 'Easynews account not reachable now', '-', ORANGE))
	rows.append(_row('Streamed over Usenet', '%d playback%s, counted exactly' % (r['nntp_plays'], '' if r['nntp_plays'] == 1 else 's'),
					 _size(r['nntp_bytes']), GREEN if r['nntp_plays'] else GREY))
	rows.append(_row('Easynews web search', '%d playback%s, estimated' % (r['web_plays'], '' if r['web_plays'] == 1 else 's'),
					 _size(r['web_bytes'], approx=True), BLUE if r['web_plays'] else GREY))
	if r['nntp_failed']:
		rows.append(_row('Releases that did not open', '%d, only their first pieces' % r['nntp_failed'], '', ORANGE))
	hb = r.get('header_bytes') or 0
	rows.append(_row('Availability checks', '%d searches, no video downloaded (one piece of each archive%s)'
					 % (r['checks'], ': %s in all' % _size(hb) if hb else ''),
					 'free' if r['checks'] else '-',
					 GREEN if r['checks'] else GREY))
	total = r['nntp_bytes'] + r['web_bytes']
	out.append(('Easynews', 'luc_kodi used %s' % _size(total, approx=bool(r['web_bytes'])) if en_on or total else 'not set up', rows))

	# NEWZNAB ------------------------------------------------------------------
	rows = []
	rows.append(_row('Searches', '%d results' % r['results'], str(r['searches']), BLUE if r['searches'] else GREY))
	per = ('~%d per search · ' % round(r['grabs'] / float(r['searches']))) if r['searches'] and r['grabs'] else ''
	rows.append(_row('NZBs downloaded', 'grabs: %s%s' % (per, _size(r['grab_bytes'])), str(r['grabs']),
					 GOLD if r['grabs'] else GREY))
	rows.append(_row('Grabs saved', 'NZB already on this device', str(r['cached']), GREEN if r['cached'] else GREY))
	lim = r['limits']
	if lim:
		parts = []
		if 'apimax' in lim: parts.append('API %s of %s' % (lim.get('apicurrent', '?'), lim['apimax']))
		if 'grabmax' in lim: parts.append('grabs %s of %s' % (lim.get('grabcurrent', '?'), lim['grabmax']))
		left = (lim['grabmax'] - lim.get('grabcurrent', 0)) if 'grabmax' in lim else None
		dot = GREEN if left is None or left > lim['grabmax'] * 0.2 else (ORANGE if left > 0 else RED)
		rows.append(_row('Indexer counters', ', '.join(parts) + ' (%s)' % _when(lim['ts']),
						 ('%d left' % left) if left is not None else '', dot))
	else:
		rows.append(_row('Indexer counters', 'your indexer does not send them', '-', GREY))
	if r['checked']:
		gone = r['dead'] * 100 // r['checked']
		rows.append(_row('Releases gone (DMCA)', '%d of %d checked' % (r['dead'], r['checked']), '%d%%' % gone,
						 RED if gone >= 50 else (ORANGE if gone >= 20 else GREEN)))
		# only the groups that lost releases: the others say nothing
		for name, c, x in r['groups']:
			if x: rows.append(_row('Group %s' % name, 'gone %d of %d checked' % (x, c), '%d%%' % (x * 100 // c), RED if x * 2 >= c else ORANGE))
	if r.get('unplayable'):
		# v2.0.33: archivos que la salud vio comprimidos o cifrados antes de la lista
		rows.append(_row('Archives Easynews cannot stream', 'compressed or encrypted, found before the list',
						 str(r['unplayable']), ORANGE))
	out.append(('Newznab', '%d grabs' % r['grabs'], rows))

	# DEVICE -------------------------------------------------------------------
	rows = []
	if r['nntp_plays']:
		cap = r['cache_max'] or 36 * 1048576
		big = (', biggest file %s' % _size(r['max_size'])) if r.get('max_size') else ''
		# v2.0.32 (informe N5): lo que de verdad llego a ocupar, con todo lo que
		# se reproducia a la vez (hasta 2), no solo el tope de una reproduccion
		if r.get('conns_peak'):
			# v2.0.32: las conexiones se abren solo si la lectura se queda atras
			rows.append(_row('Connections, highest', 'of up to %d set; opened only when needed' % r['conns_max'],
							 str(r['conns_peak']), GREEN))
		peak = r.get('ram_peak') or r['cache_peak']
		rows.append(_row('Memory, highest', 'limit %s per playback%s' % (_size(cap), big), _size(peak or cap),
						 GREEN if peak <= 160 * 1048576 else ORANGE))
		mbps = r['peak_mbps']
		rows.append(_row('Download speed', 'average %s Mb/s' % r['avg_mbps'], '%d Mb/s' % mbps,
						 GREEN if mbps >= 80 else (ORANGE if mbps >= 30 else RED)))
		gb = r['cpu_bytes'] / 1073741824.0
		per_gb = (r['cpu'] / gb) if gb > 0.01 else 0
		rows.append(_row('Processor', 'decoding, seconds per GB', '%.0f s' % per_gb if per_gb else '-',
						 GREEN if per_gb < 60 else ORANGE))
		rows.append(_row('Pauses while watching', '%.0f s waiting in all' % r['stall_secs'] if r['stalls'] else 'none',
						 str(r['stalls']), GREEN if not r['stalls'] else (ORANGE if r['stalls'] < 5 else RED)))
		rows.append(_row('Missing pieces', '%d release%s stopped' % (r['incomplete'], '' if r['incomplete'] == 1 else 's')
						 if r['incomplete'] else 'shown as a short skip', str(r['missing']), GREEN if not r['missing'] else ORANGE))
	else:
		rows.append(_row('Nothing played over Usenet yet', 'in this period', '', GREY))
	try:
		from resources.lib.modules import usenet_easynews as _ue
		bk_on = bool(_ue.backup_configs())
	except Exception:
		bk_on = False
	if bk_on or r.get('backup_hits'):
		rows.append(_row('Backup providers', 'pieces Easynews no longer had' if r.get('backup_hits') else 'set up, not needed yet',
						 ('%d · %s' % (r['backup_hits'], _size(r.get('backup_bytes', 0)))) if r.get('backup_hits') else '0',
						 BLUE if r.get('backup_hits') else GREY))
	if usenet_dir:
		rows.append(_row('Storage', 'NZBs (kept 3 days) + report', _size(_dir_size(usenet_dir)), GREEN))
	out.append(('Your device', '', rows))

	# PLAYBACKS ----------------------------------------------------------------
	rows = []
	for h in r['history']:
		bits = [_when(h['ts']), 'Usenet' if h['path'] == 'NNTP' else 'web']
		if h.get('mbps'): bits.append('%d Mb/s' % h['mbps'])
		if h.get('stalls'): bits.append('%d pause%s' % (h['stalls'], '' if h['stalls'] == 1 else 's'))
		if h.get('cut'): bits.append('stopped: incomplete')
		dot = RED if h.get('cut') else (ORANGE if h.get('stalls') else (GREEN if h['path'] == 'NNTP' else BLUE))
		rows.append(_row(h['title'], ' · '.join(bits), _size(h['bytes'], approx=h.get('estimate')), dot))
	if not rows:
		rows.append(_row('No playbacks in this period', '', '', GREY))
	out.append(('Last playbacks', '%d' % len(r['history']) if r['history'] else '', rows))
	return out


def show():
	"""Router action tools_usenetReport."""
	try:
		from resources.lib.windows.usenet_report import UsenetReportXML
		window = UsenetReportXML('usenet_report.xml', control.addonPath(control.addonId()))
		window.run()
		del window
	except Exception:
		log_utils.error()
