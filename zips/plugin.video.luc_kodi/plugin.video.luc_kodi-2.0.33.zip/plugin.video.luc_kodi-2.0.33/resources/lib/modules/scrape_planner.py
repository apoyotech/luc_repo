# -*- coding: utf-8 -*-
"""
	luc_kodi Add-on — scrape_planner.py (v2.0.29)

	Busqueda inteligente: un mismo modelo para cualquier combinacion de
	scrapers, debrid y Usenet que tenga activada el usuario.

	El problema que resuelve (medido en la 2.0.25):
	  getSources_dialog() lanza un hilo por proveedor y espera a que TERMINEN
	  TODOS o a que venza scrapers.timeout (25 s). El tiempo de una busqueda
	  lo marca siempre el proveedor mas lento, aunque los rapidos ya hayan
	  traido de sobra lo que se va a reproducir. Y la comprobacion de cache del
	  debrid empieza solo DESPUES, con todo junto. De ahi los 3 / 7 / 12 / 20 s
	  segun lo que tenga cada uno activado.

	Lo que hace, tomado de lo que funciona fuera de Kodi:
	  1. DETECTA el montaje (profile()): que proveedores corren, que debrid
	     tienen comprobacion de cache (Premiumize, TorBox, Offcloud) y cuales
	     ensenan los torrents sin comprobar (Real-Debrid sin clave de DMM,
	     AllDebrid), y si Usenet va por Easynews.
	  2. APRENDE de cada busqueda, por proveedor y por tipo (pelicula, episodio,
	     pack de temporada, pack de serie): cuanto tarda (EWMA con su
	     desviacion), cuantos resultados trae, cuantos acaban siendo
	     reproducibles y cuantos de esos SOLO los trae el (exclusivos).
	  3. CORTA LA ESPERA cuando ya hay bastante (should_stop()), como la
	     "dynamic addon fetching" de AIOStreams: con N fuentes listas para
	     reproducir en las dos mejores calidades permitidas, se da un margen
	     corto a los que faltan (mas largo a los que suelen traer exclusivos) y
	     se cierra. Sin quorum NO se corta nada: se espera como siempre.
	  4. COMPRUEBA EL DEBRID MIENTRAS SE BUSCA (prefetch()), como Nuvio, que
	     anota la cache por grupo segun llega: los hashes nuevos se preguntan
	     cada 1,5 s y la comprobacion final apenas tiene nada que hacer.
	  5. RECUERDA LA CACHE POR HASH (check()), como Fen Light y Comet: antes se
	     guardaba la respuesta del CONJUNTO entero de hashes y bastaba un hash
	     distinto para no acertar nunca. Ahora cada hash vale 6 h si estaba
	     cacheado y 1 h si no.

	Un proveedor que se corta NO se pierde: su hilo sigue, guarda lo que traiga
	en rel_src como siempre y la siguiente apertura lo sirve al momento. La
	lista recortada se guarda solo 20 minutos en vez de 48 horas.

	Todo vive en scrape_speed.db. Borrarlo solo hace que vuelva a aprender.

	v2.0.29 -- menos CPU mientras se espera. sources.py pregunta al planificador
	40 veces por segundo y antes cada vuelta recorria la lista ENTERA: ready()
	normalizaba todos los hashes y prefetch() los repasaba aunque no hubiera
	llegado nada. Ahora prefetch() sigue un cursor (solo mira lo nuevo; la cola
	de fuentes solo crece durante la busqueda) y ready() guarda su cuenta y solo
	la rehace cuando llegan fuentes o el debrid confirma hashes. Las decisiones
	son las mismas; lo que se ahorra es GIL para los scrapers que parsean.
	Ademas: el esquema de la base se crea una vez por proceso (el invocador se
	reutiliza), la purga de hashes caducados va con indice y como mucho una vez
	cada 10 min, y norm_hash se resuelve una sola vez.
"""

import os
import re
import threading
from itertools import islice
from json import dumps as jsdumps, loads as jsloads
from sqlite3 import dbapi2 as database
from time import time

from resources.lib.modules import control
from resources.lib.modules import log_utils

getSetting = control.setting

DB_NAME = 'scrape_speed.db'
MIN_WAIT = 1.0          # nunca se corta antes: los rapidos contestan en ~1 s
# v2.0.33 (kodi.log del 13-nov-2026, The Super Mario Galaxy Movie): Newznab espera
# hasta 3 s a la salud de Easynews y acaba a los 3,3-4,7 s; la busqueda rapida lo
# cortaba a los 4,2 s porque Easynews web ya traia bastante, y sus 117 releases
# solo salian al repetir la busqueda. A Newznab no se le corta antes de esto.
USENET_FLOOR = 6.0
BASE_GRACE = 2.0        # margen tras el quorum para los que faltan
EXCL_GRACE = 2.0        # margen extra maximo para quien suele traer exclusivos
MIN_GRACE = 0.5         # v2.0.26: margen minimo cuando ya sobran fuentes
PLENTY = 3.0            # v2.0.26: con 3x el objetivo en las mejores calidades no se espera a exclusivos
ALPHA = 0.3             # peso de la medida nueva en las medias
LEARNED_RUNS = 3        # medidas antes de fiarse de un proveedor
POS_TTL = 6 * 3600      # un hash cacheado se recuerda 6 h
NEG_TTL = 3600          # uno no cacheado, 1 h (se cachean a diario)
PREFETCH_EVERY = 1.5
_CHUNK = 100            # hashes por consulta, el trozo de TorBox, Offcloud y DMM
PARTIAL_TTL = 20 * 60   # vida de una lista recortada en la cache de listas
HISTORY_KEEP = 50
PURGE_EVERY = 600       # v2.0.29: purga de hashes caducados, como mucho cada 10 min

_LOCK = threading.Lock()
_AUTH_FAILED = {}       # debrid -> el token fue rechazado en la ultima consulta
_QUALITY_TIERS = ('4K', '1080p', '720p', 'SD')
_KIND_LABEL = {'movie': 'movie', 'episode': 'episode', 'season': 'season pack', 'show': 'show pack'}
_NOT_PLAYABLE = re.compile(r'^uncached')
_SCHEMA_OK = set()      # v2.0.29: rutas de base con el esquema ya creado en este proceso
_LAST_PURGE = [0.0]
_NORM = []              # v2.0.29: norm_hash de torbox, resuelto una vez


# ── base de datos ─────────────────────────────────────────────────────────

def _db_path():
	return os.path.join(control.dataPath, DB_NAME)


def _connect():
	if not control.existsPath(control.dataPath): control.makeFile(control.dataPath)
	path = _db_path()
	known = path in _SCHEMA_OK and control.existsPath(path) # antes de connect(), que crea el fichero vacio
	con = database.connect(path, timeout=20)
	con.execute('PRAGMA synchronous = NORMAL')
	if known: return con
	con.execute('PRAGMA journal_mode = WAL')
	con.execute('''CREATE TABLE IF NOT EXISTS speed (provider TEXT, kind TEXT, runs INTEGER, fails INTEGER,
		ewma_s REAL, ewma_dev REAL, ewma_found REAL, ewma_good REAL, ewma_excl REAL, judged INTEGER,
		last INTEGER, PRIMARY KEY(provider, kind))''')
	con.execute('''CREATE TABLE IF NOT EXISTS avail (hash TEXT, debrid TEXT, cached INTEGER, files TEXT,
		expires INTEGER, PRIMARY KEY(hash, debrid))''')
	con.execute('''CREATE TABLE IF NOT EXISTS searches (ts INTEGER, content TEXT, elapsed REAL, ended TEXT,
		ready INTEGER, saved REAL, cut TEXT)''')
	con.execute('CREATE INDEX IF NOT EXISTS avail_expires ON avail (expires)')
	_SCHEMA_OK.add(path)
	return con


def load_stats():
	"""{(provider, kind): dict} con lo aprendido."""
	out = {}
	try:
		with _LOCK:
			con = _connect()
			try:
				rows = con.execute('SELECT provider, kind, runs, fails, ewma_s, ewma_dev, ewma_found, ewma_good, ewma_excl, judged, last FROM speed').fetchall()
			finally: con.close()
		for r in rows:
			out[(r[0], r[1])] = {'runs': r[2] or 0, 'fails': r[3] or 0, 'secs': r[4], 'dev': r[5] or 0.0,
				'found': r[6] or 0.0, 'good': r[7] or 0.0, 'excl': r[8] or 0.0, 'judged': r[9] or 0, 'last': r[10] or 0}
	except Exception:
		log_utils.error()
	return out


def _ewma(old, new):
	return new if old is None else old + ALPHA * (new - old)


def _write_speed(con, rows):
	"""rows: lista de (provider, kind, secs|None, failed, found|None)."""
	now = int(time())
	for provider, kind, secs, failed, found in rows:
		r = con.execute('SELECT runs, fails, ewma_s, ewma_dev, ewma_found, ewma_good, ewma_excl, judged FROM speed WHERE provider=? AND kind=?', (provider, kind)).fetchone()
		runs, fails, s, dev, f, g, e, j = (r if r else (0, 0, None, 0.0, None, 0.0, 0.0, 0))
		if failed: fails = (fails or 0) + 1
		else:
			runs = (runs or 0) + 1
			if secs is not None:
				if s is None: s, dev = secs, 0.0
				else:
					dev = _ewma(dev or 0.0, abs(secs - s))
					s = _ewma(s, secs)
			if found is not None: f = _ewma(f, float(found))
		con.execute('INSERT OR REPLACE INTO speed VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)',
			(provider, kind, runs, fails, s, dev or 0.0, f, g or 0.0, e or 0.0, j or 0, now))


def _write_usefulness(con, rows):
	"""rows: lista de (provider, kind, good, exclusive)."""
	for provider, kind, good, excl in rows:
		r = con.execute('SELECT ewma_good, ewma_excl, judged FROM speed WHERE provider=? AND kind=?', (provider, kind)).fetchone()
		if not r: continue
		g, e, j = r
		g = float(good) if not j else _ewma(g, float(good))
		e = float(excl) if not j else _ewma(e, float(excl))
		con.execute('UPDATE speed SET ewma_good=?, ewma_excl=?, judged=? WHERE provider=? AND kind=?', (g, e, (j or 0) + 1, provider, kind))


def reset():
	try:
		with _LOCK:
			con = _connect()
			try:
				con.execute('DELETE FROM speed')
				con.execute('DELETE FROM searches')
				con.execute('DELETE FROM avail')
				con.commit()
				con.execute('VACUUM')
			finally: con.close()
		return True
	except Exception:
		log_utils.error()
		return False


# ── cache de disponibilidad por hash ──────────────────────────────────────

def _plain_hash(h):
	return (h or '').strip().lower()


def norm_hash(h):
	if not _NORM:
		try:
			from resources.lib.debrid.torbox import norm_hash as _nh
			_NORM.append(_nh)
		except Exception:
			log_utils.error()
			_NORM.append(_plain_hash)
	try: return _NORM[0](h)
	except Exception: return _plain_hash(h)


def avail_split(debrid, hashes, need_files=False):
	"""(known, unknown): known = {hash: (cached, files)} vigentes; unknown =
	hashes sin dato. Con need_files, un cacheado guardado sin ficheros cuenta
	como desconocido (TorBox los pide para quitar packs sin el episodio)."""
	hashes = [h for h in dict.fromkeys(hashes) if h]
	known = {}
	if not hashes: return known, []
	try:
		now = int(time())
		with _LOCK:
			con = _connect()
			try:
				for n in range(0, len(hashes), 500):
					chunk = hashes[n:n + 500]
					q = 'SELECT hash, cached, files FROM avail WHERE debrid=? AND expires>? AND hash IN (%s)' % ','.join('?' * len(chunk))
					for h, c, f in con.execute(q, [debrid, now] + chunk).fetchall():
						files = None
						if f:
							try: files = jsloads(f)
							except Exception: files = None
						if need_files and c and files is None: continue
						known[h] = (bool(c), files)
			finally: con.close()
	except Exception:
		log_utils.error()
	return known, [h for h in hashes if h not in known]


def avail_store(debrid, status):
	"""status: {hash: (cached, files)}."""
	if not status: return
	try:
		now = int(time())
		rows = [(h, debrid, 1 if c else 0, jsdumps(f) if f is not None else None, now + (POS_TTL if c else NEG_TTL))
				for h, (c, f) in status.items() if h]
		with _LOCK:
			con = _connect()
			try:
				con.executemany('INSERT OR REPLACE INTO avail VALUES (?, ?, ?, ?, ?)', rows)
				if now - _LAST_PURGE[0] >= PURGE_EVERY:
					_LAST_PURGE[0] = now
					con.execute('DELETE FROM avail WHERE expires<?', (now,))
				con.commit()
			finally: con.close()
	except Exception:
		log_utils.error()


def check(debrid, hashes, want_files=False):
	"""Comprobacion de cache con memoria por hash. debrid: 'pm', 'tb' u 'oc'.
	Devuelve {hash_normalizado: (cached, files)} con todo lo que se sabe, o
	None si no se sabe nada (ni guardado ni contestado): el llamador se
	comporta entonces como antes ante un fallo de la API."""
	keys = [norm_hash(h) for h in hashes if h]
	_AUTH_FAILED[debrid] = False
	# La memoria va atada a la cuenta: con otro token (uno nuevo, o uno rechazado)
	# no se aprovecha lo guardado y se pregunta, y asi un token rechazado se
	# detecta y su debrid no ensena nada, como antes de la cache por hash.
	dkey = _account_key(debrid)
	known, unknown = avail_split(dkey, keys, need_files=want_files)
	if unknown:
		# v2.0.26: troceado AQUI, de 100 en 100 y en paralelo. Con mas de 100
		# hashes TorBox y Offcloud contestaban por trozos sin decir cual fallo,
		# los no cacheados no se podian guardar y la comprobacion final volvia a
		# preguntar por todos: 4 s de Offcloud en la primera busqueda del log.
		# Un trozo que contesta es completo, asi que sus negativos ya valen.
		chunks = [unknown[i:i + _CHUNK] for i in range(0, len(unknown), _CHUNK)]
		results = [None] * len(chunks)
		def _one(n):
			results[n] = _query(debrid, chunks[n], want_files)
		if len(chunks) == 1: _one(0)
		else:
			ts = [threading.Thread(target=_one, args=(n,), daemon=True) for n in range(len(chunks))]
			[t.start() for t in ts]
			[t.join() for t in ts]
		store = {}
		for res in results:
			fresh, keep = res if res else (None, False)
			if fresh is None: continue
			known.update(fresh)
			store.update((h, v) for h, v in fresh.items() if v[0] or keep)
		avail_store(dkey, store)
	return known or None


_TOKEN_SETTING = {'pm': 'premiumize.token', 'tb': 'torbox.token', 'oc': 'offcloud.token'}


def _account_key(debrid):
	from hashlib import md5
	tok = getSetting(_TOKEN_SETTING.get(debrid, '')) or ''
	return '%s:%s' % (debrid, md5(tok.encode('utf-8')).hexdigest()[:10])


def auth_failed(debrid):
	return _AUTH_FAILED.get(debrid, False)


def _query(debrid, unknown, want_files):
	"""(estado, negativos_fiables) o (None, False). Los no cacheados solo se
	guardan cuando la respuesta cubre seguro todos los hashes: TorBox y
	Offcloud contestan por trozos y no dicen cual fallo."""
	try:
		if debrid == 'pm':
			from resources.lib.debrid.premiumize import Premiumize
			res = Premiumize().check_cache_list(unknown)
			if not res: return None, False
			if len(res) < len(unknown):
				log_utils.log('scrape_planner: Premiumize answered %d of %d hashes' % (len(res), len(unknown)), level=log_utils.LOGWARNING)
			return dict((h, (v is not False, None)) for h, v in zip(unknown, res)), True
		if debrid == 'tb':
			from resources.lib.debrid.torbox import TorBox, CACHE_CHUNK
			res = TorBox().check_cache(unknown, list_files=want_files)
			if not res: return None, False
			out = dict((h, (False, None)) for h in unknown)
			for row in res.get('data') or []:
				h = norm_hash(row.get('hash'))
				if not h: continue
				names = None
				if want_files and isinstance(row.get('files'), list):
					names = [str(f.get('short_name') or f.get('name') or f.get('path') or '').split('/')[-1]
							 for f in row['files'] if isinstance(f, dict)]
				out[h] = (True, names)
			return out, len(unknown) <= CACHE_CHUNK
		if debrid == 'oc':
			from resources.lib.debrid.offcloud import Offcloud, CACHE_CHUNK
			oc = Offcloud()
			res = oc.check_cache(unknown)
			if oc.auth_failed: _AUTH_FAILED['oc'] = True
			if res is None: return None, False
			return dict((h, (h in res, None)) for h in unknown), len(unknown) <= CACHE_CHUNK
	except Exception:
		log_utils.error()
	return None, False


# ── deteccion del montaje ─────────────────────────────────────────────────

def profile():
	"""Lo que el usuario tiene activado y como afecta a la busqueda."""
	on = lambda k: getSetting(k) == 'true'
	checking, unchecked = [], []
	if getSetting('premiumize.token') and on('premiumize.enable'): checking.append(('pm', 'Premiumize'))
	if getSetting('torbox.token') and on('torbox.enable'): checking.append(('tb', 'TorBox'))
	if getSetting('offcloud.token') and on('offcloud.enable'): checking.append(('oc', 'Offcloud'))
	if getSetting('realdebrid.token') and on('realdebrid.enable'): unchecked.append('Real-Debrid')
	if getSetting('alldebrid.token') and on('alldebrid.enable'): unchecked.append('AllDebrid')
	usenet = []
	if on('provider.newznab'): usenet.append('Newznab')
	if getSetting('easynews.username') and (on('provider.easynews') or (on('provider.newznab') and (getSetting('newznab.use_easynews') or 'true') == 'true')):
		usenet.append('Easynews')
	return {'checking': checking, 'unchecked': unchecked, 'usenet': usenet}


def enabled():
	return getSetting('scrapers.smart') != 'false'


def target():
	try: return max(3, min(60, int(getSetting('scrapers.smart.target') or 10)))
	except Exception: return 10


# ── el planificador de una busqueda ──────────────────────────────────────

class Planner:
	def __init__(self, content, autoplay, timeout):
		self.enabled = enabled()
		self.content = content
		self.autoplay = bool(autoplay)
		self.timeout = timeout
		self.target = target() if self.autoplay else target() * 2
		self.prof = profile()
		self.stats = load_stats()
		self.threads = []           # (thread, provider, kind)
		self.keys = {}              # (provider, kind) -> set de claves
		self.done = set()           # (provider, kind) terminados, en vivo o de cache
		self.pending_speed = []     # filas para _write_speed
		self.closed = False
		self.quorum_at = None
		self.cut = []
		self.reason = 'all answered'
		self._seen_hashes = set()
		self._pos = set()           # hashes que algun debrid con comprobacion tiene
		self._prefetch_threads = []
		self._last_prefetch = 0.0
		self._scan_at = 0           # v2.0.29: hasta donde ha mirado prefetch() en la cola
		self._pending = []          # hashes vistos aun sin enviar al debrid
		self._ready_sig = None      # v2.0.29: (fuentes, hashes confirmados) de la ultima cuenta
		self._ready_val = (0, 0)
		self._lock = threading.Lock()
		self.t0 = time()            # v2.0.26: cronologia para el log
		self.timeline = {}          # (provider, kind) -> (segundo, resultados, 'live'|'cache'|'fail')
		self.debrid_calls = []      # (debrid, hashes, segundos)
		self.loop_end = None
		self.prefetch_wait = 0.0
		allowed = getSetting('hosts.quality') or '0'
		try: self.tiers = _QUALITY_TIERS[int(allowed):]
		except Exception: self.tiers = _QUALITY_TIERS
		self.top = self.tiers[:2]

	@staticmethod
	def kind_of(content, pack):
		return pack if pack in ('season', 'show') else content

	def register(self, thread, provider, kind):
		self.threads.append((thread, provider, kind))

	# llamadas desde los hilos de los scrapers
	def from_cache(self, provider, kind, sources):
		self.timeline.setdefault((provider, kind), (time() - self.t0, len(sources or []), 'cache'))
		with self._lock:
			self.keys[(provider, kind)] = set(self._key(i) for i in sources or [])
			self.done.add((provider, kind))

	def live(self, provider, kind, secs, sources):
		self.timeline.setdefault((provider, kind), (time() - self.t0, len(sources or []), 'live'))
		with self._lock:
			self.keys[(provider, kind)] = set(self._key(i) for i in sources or [])
			self.done.add((provider, kind))
			row = (provider, kind, secs, False, len(sources or []))
			late = self.closed
			if not late: self.pending_speed.append(row)
		if late:
			self._flush_late([row])
			self._maybe_release_partial()
			# Llego tarde: se mide lo que habria aportado contra la lista que se
			# enseno, para que aprenda tambien si trae exclusivos (si no, a un
			# proveedor que siempre se corta nunca se le podria juzgar).
			threading.Thread(target=self._judge_late, args=(provider, kind, list(sources or [])), daemon=True).start()

	def _judge_late(self, provider, kind, sources):
		try:
			shown = getattr(self, '_final_keys', set())
			new = [i for i in sources if self._key(i) not in shown]
			mags = [norm_hash(i.get('hash')) for i in new if 'magnet:' in (i.get('url') or '') and i.get('hash')]
			if mags and self.prof['checking'] and not self.prof['unchecked']:
				for code, _n in self.prof['checking']:
					st = check(code, mags, want_files=False)
					if st: self._pos.update(h for h, (c, _f) in st.items() if c)
			good = set(self._key(i) for i in sources if self._playable(i))
			excl = len(set(self._key(i) for i in new if self._playable(i)))
			with _LOCK:
				con = _connect()
				try:
					_write_usefulness(con, [(provider, kind, len(good), excl)])
					con.commit()
				finally: con.close()
		except Exception:
			log_utils.error()

	def failed(self, provider, kind, secs):
		self.timeline.setdefault((provider, kind), (time() - self.t0, 0, 'fail'))
		with self._lock:
			self.done.add((provider, kind))
			row = (provider, kind, secs, True, None)
			late = self.closed
			if not late: self.pending_speed.append(row)
		if late:
			self._flush_late([row])
			self._maybe_release_partial()

	def _maybe_release_partial(self):
		"""v2.0.26: cuando ya han terminado TODOS los proveedores que se cortaron,
		se borra la lista recortada de la cache de listas. La siguiente apertura
		vuelve a montar la lista, al momento porque cada proveedor ya esta en
		rel_src, y con lo de los que llegaron tarde (Newznab, Easynews...)."""
		key = getattr(self, 'partial_key', None)
		if not key or not self.cut: return
		with self._lock:
			if not all(pk in self.done for pk in self.cut): return
			self.partial_key = None
		try:
			from resources.lib.database import providerscache
			providerscache.remove_key(key)
			log_utils.log('[ luc_kodi ] smart search: late providers finished, the full list is ready next time', level=log_utils.LOGINFO)
		except Exception:
			log_utils.error()

	@staticmethod
	def _key(item):
		h = (item.get('hash') or '').strip().lower()
		return h or (item.get('url') or '')

	def _flush_late(self, rows):
		try:
			with _LOCK:
				con = _connect()
				try:
					_write_speed(con, rows)
					con.commit()
				finally: con.close()
		except Exception:
			log_utils.error()

	def alive(self):
		return [(p, k) for t, p, k in self.threads if t.is_alive()]

	# comprobacion de cache mientras se busca
	def prefetch(self, scraper_sources, force=False):
		if not self.enabled or not self.prof['checking']: return
		# v2.0.29: la cola solo crece durante la busqueda, asi que se mira solo lo
		# que ha llegado desde la ultima vez. Si alguien la vaciara o recortara,
		# se vuelve a empezar (lo ya visto sigue en _seen_hashes).
		n = len(scraper_sources)
		if n < self._scan_at: self._scan_at = 0
		if n > self._scan_at:
			for i in islice(scraper_sources, self._scan_at, n):
				try:
					if 'magnet:' not in (i.get('url') or ''): continue
					h = norm_hash(i.get('hash'))
					if h and h not in self._seen_hashes:
						self._seen_hashes.add(h)
						self._pending.append(h)
				except Exception: pass
			self._scan_at = n
		if not self._pending: return
		now = time()
		if not force and now - self._last_prefetch < PREFETCH_EVERY: return
		new, self._pending = self._pending, []
		self._last_prefetch = now # el reloj corre solo cuando se envia algo: el primer lote sale en cuanto llega
		want_files = self.content == 'episode'
		for code, _name in self.prof['checking']:
			t = threading.Thread(target=self._prefetch_one, args=(code, new, want_files), daemon=True)
			t.start()
			self._prefetch_threads.append(t)

	def _prefetch_one(self, code, hashes, want_files):
		try:
			_t = time()
			status = check(code, hashes, want_files=want_files and code == 'tb')
			self.debrid_calls.append((code, len(hashes), time() - _t))
			if status:
				with self._lock:
					self._pos.update(h for h, (c, _f) in status.items() if c)
		except Exception:
			log_utils.error()

	def join_prefetch(self, limit=5.0):
		_t = time()
		end = _t + limit
		for t in self._prefetch_threads:
			left = end - time()
			if left <= 0: break
			t.join(left)
		self.prefetch_wait = time() - _t

	# ¿basta con lo que hay?
	def _playable(self, item):
		try:
			if item.get('local') or item.get('source') == 'cloud': return True
			if item.get('direct'): return True
			src = item.get('source') or ''
			if src == 'usenet' and item.get('hash'):
				return item.get('en_health') in ('ok', 'partial')
			url = item.get('url') or ''
			if 'magnet:' in url:
				if self.prof['unchecked']: return True
				return norm_hash(item.get('hash')) in self._pos
		except Exception: pass
		return False

	def ready(self, scraper_sources):
		"""(total, en las dos mejores calidades) reproducibles, sin repetir.
		v2.0.29: la cuenta solo cambia si llegan fuentes o el debrid confirma
		hashes; si no ha cambiado nada se devuelve la de la vuelta anterior."""
		sig = (len(scraper_sources), len(self._pos))
		if sig == self._ready_sig: return self._ready_val
		seen, total, top = set(), 0, 0
		for i in list(scraper_sources):
			q = i.get('quality')
			if q in ('SCR', 'CAM'): q = 'SD'
			if q not in self.tiers or not self._playable(i): continue
			k = self._key(i)
			if k in seen: continue
			seen.add(k)
			total += 1
			if q in self.top: top += 1
		self._ready_sig, self._ready_val = sig, (total, top)
		return total, top

	def should_stop(self, elapsed, scraper_sources):
		if not self.enabled: return False
		alive = self.alive()
		if not alive: return False
		total, top = self.ready(scraper_sources)
		self.last_ready = total
		if total < self.target or top < max(2, self.target // 2):
			self.quorum_at = None
			return False
		if self.quorum_at is None: self.quorum_at = elapsed
		# v2.0.26: el margen depende de lo que sobre. Medido en la tablet (2.0.26):
		# quorum a los 0,2-0,5 s con 100-300 listas y la lista cerrandose a los
		# 4-5 s esperando a Newznab, que en Usenet siempre cuenta como exclusivo.
		abundance = top / float(max(1, self.target))
		grace = BASE_GRACE if abundance < 2 else max(MIN_GRACE, BASE_GRACE * 2.0 / abundance)
		self.last_grace = grace
		bonus = 0.0
		for p, k in ([] if abundance >= PLENTY else alive):
			st = self.stats.get((p, k))
			if st and st['judged'] >= LEARNED_RUNS:
				bonus = max(bonus, EXCL_GRACE * min(1.0, st['excl'] / max(1.0, self.target / 2.0)))
			elif not st or st['runs'] < LEARNED_RUNS:
				bonus = max(bonus, EXCL_GRACE / 2.0) # aun no se sabe lo que aporta
		self.last_grace += bonus
		if elapsed < MIN_WAIT or elapsed < self.quorum_at + grace + bonus: return False
		if elapsed < USENET_FLOOR and any(p == 'newznab' for p, _k in alive): return False
		self.cut = alive
		self.reason = 'enough ready to play'
		return True

	def expected(self, provider, kind):
		st = self.stats.get((provider, kind))
		if not st or st['runs'] < LEARNED_RUNS or st['secs'] is None: return None
		return st['secs']

	def status(self, elapsed, alive_names):
		"""Texto corto para la fila de proveedores del cuadro de progreso."""
		if not self.enabled: return None
		n = getattr(self, 'last_ready', 0)
		if self.quorum_at is not None:
			return '%d ready to play · finishing' % n
		return '%d ready to play' % n if n else None

	# cierre: medir lo que aporto cada uno
	def finish(self, elapsed, final_sources):
		playable = set()
		for i in final_sources or []:
			try:
				if _NOT_PLAYABLE.match(i.get('source') or ''): continue
				playable.add(self._key(i))
			except Exception: pass
		self._final_keys = playable # antes de cerrar: _judge_late() lo necesita
		with self._lock:
			self.closed = True
			rows = list(self.pending_speed)
			self.pending_speed = []
			keys = dict(self.keys)
		try:
			owners = {}
			for pk, ks in keys.items():
				for k in ks & playable: owners.setdefault(k, set()).add(pk[0])
			useful = []
			for pk, ks in keys.items():
				good = ks & playable
				excl = [k for k in good if owners.get(k) == {pk[0]}]
				useful.append((pk[0], pk[1], len(good), len(excl)))
			saved = 0.0
			if self.cut:
				waits = []
				for p, k in self.cut:
					e = self.expected(p, k)
					waits.append(min(self.timeout, e) if e is not None else self.timeout)
				saved = max(0.0, max(waits) - elapsed)
				# Un proveedor cortado tardo al menos esto: si su media era menor, se corrige
				# ya; si termina luego, live() apunta la medida real.
				for p, k in self.cut:
					e = self.expected(p, k)
					if e is not None and e < elapsed: rows.append((p, k, elapsed, False, None))
			with _LOCK:
				con = _connect()
				try:
					_write_speed(con, rows)
					_write_usefulness(con, useful)
					con.execute('INSERT INTO searches VALUES (?, ?, ?, ?, ?, ?, ?)', (int(time()), self.content, round(elapsed, 2),
						self.reason, len(playable), round(saved, 1), ', '.join(sorted(set(p for p, _k in self.cut)))))
					con.execute('DELETE FROM searches WHERE rowid NOT IN (SELECT rowid FROM searches ORDER BY ts DESC LIMIT %d)' % HISTORY_KEEP)
					con.commit()
				finally: con.close()
			log_utils.log('[ luc_kodi ] smart search: %s in %.1fs, %d ready to play%s'
				% (self.reason, elapsed, len(playable), (' — still running: %s' % ', '.join('%s %s' % (p, _KIND_LABEL.get(k, k)) for p, k in self.cut)) if self.cut else ''),
				level=log_utils.LOGINFO)
			self._log_timeline(elapsed)
		except Exception:
			log_utils.error()

	def _log_timeline(self, elapsed):
		"""v2.0.26: una linea con donde se fue el tiempo, para afinar con el
		kodi.log real: cuando hubo quorum, cuando se cerro la espera, cuanto se
		espero al debrid y cuanto tardo el filtrado; y cada proveedor con su
		segundo de llegada y sus resultados (c = servido desde la cache)."""
		try:
			f = lambda v: '-' if v is None else '%.1f' % v
			parts = []
			for (p, k), (sec, n, how) in sorted(self.timeline.items(), key=lambda kv: kv[1][0]):
				tag = '' if k in ('movie', 'episode') else ('/' + k)
				parts.append('%s%s %ss/%d%s' % (p, tag, f(sec), n, {'cache': 'c', 'fail': ' FAIL'}.get(how, '')))
			for p, k in self.cut:
				if (p, k) not in self.timeline: parts.append('%s%s >%ss' % (p, '' if k in ('movie', 'episode') else '/' + k, f(self.loop_end)))
			deb = {}
			for code, n, secs in self.debrid_calls:
				d = deb.setdefault(code, [0, 0, 0.0])
				d[0] += 1 ; d[1] += n ; d[2] = max(d[2], secs)
			deb_txt = ', '.join('%s %d calls/%d hashes (slowest %.1fs)' % (c, v[0], v[1], v[2]) for c, v in sorted(deb.items())) or 'none'
			filt = (elapsed - self.loop_end - self.prefetch_wait) if self.loop_end is not None else None
			log_utils.log('[ luc_kodi ] smart search timeline: quorum %ss · margin %ss · wait closed %ss · debrid wait %.1fs · filter %ss | %s | debrid: %s'
				% (f(self.quorum_at), f(getattr(self, 'last_grace', None)), f(self.loop_end), self.prefetch_wait, f(filt), ' · '.join(parts), deb_txt), level=log_utils.LOGINFO)
		except Exception:
			log_utils.error()


# ── informe (Tools > Search speed) ────────────────────────────────────────

def _verdict(st):
	if st['runs'] + st['fails'] < LEARNED_RUNS: return 'learning'
	if st['fails'] > st['runs']: return 'often fails'
	secs = st['secs'] or 0
	if st['judged'] >= LEARNED_RUNS:
		if secs >= 8 and st['excl'] < 0.5: return 'slow, adds little'
		if st['good'] < 0.5 and st['found'] >= 1: return 'nothing playable'
		if st['excl'] >= 2: return 'brings unique sources'
	return 'ok'


def _fmt_s(v):
	return '-' if v is None else ('%.1f s' % v)


def report_text():
	G, A, R, W = 'FF00FA9A', 'FFFDB515', 'FFFF6B6B', 'FFBBBBBB'
	c = lambda col, t: '[COLOR %s]%s[/COLOR]' % (col, t)
	prof = profile()
	stats = load_stats()
	from resources.lib.jacksparrow import sources as fs_sources
	active = sorted(m for m, _c in (fs_sources() or []))
	lines = []
	lines.append(c(G, '[B]YOUR SETUP[/B]'))
	lines.append('Providers on: %s' % (', '.join(active) if active else 'none'))
	lines.append('Debrid with cache check: %s' % (', '.join(n for _c, n in prof['checking']) or 'none'))
	if prof['unchecked']: lines.append('Debrid shown unchecked (checked when you play): %s' % ', '.join(prof['unchecked']))
	lines.append('Usenet: %s' % (', '.join(prof['usenet']) or 'off'))
	lines.append('Smart search: %s · ends when %d sources are ready to play (autoplay), %d (source list)'
		% ('on' if enabled() else 'off', target(), target() * 2))
	lines.append('')
	lines.append(c(G, '[B]PROVIDERS[/B]') + '   ' + c(W, 'typical time · results · ready to play · only from it · runs'))
	order = sorted(stats.items(), key=lambda kv: (kv[0][0], ('movie', 'episode', 'season', 'show').index(kv[0][1]) if kv[0][1] in ('movie', 'episode', 'season', 'show') else 9))
	advice = []
	for (p, k), st in order:
		if p not in active and not p.endswith('_cloud'): continue
		v = _verdict(st)
		col = {'slow, adds little': A, 'often fails': R, 'nothing playable': A, 'brings unique sources': G}.get(v, W)
		lines.append('[B]%s[/B] %s   %s · %.0f · %.0f · %.0f · %d%s   %s' % (p.upper(), _KIND_LABEL.get(k, k), _fmt_s(st['secs']),
			st['found'], st['good'], st['excl'], st['runs'], (' (%d failed)' % st['fails']) if st['fails'] else '', c(col, v)))
		if v == 'slow, adds little' and k in ('movie', 'episode') and st['runs'] >= 10: advice.append(p)
	if not order: lines.append('Nothing measured yet. Play a few titles and come back.')
	lines.append('')
	try:
		with _LOCK:
			con = _connect()
			try: rows = con.execute('SELECT elapsed, ended, saved FROM searches ORDER BY ts DESC').fetchall()
			finally: con.close()
	except Exception: rows = []
	if rows:
		early = [r for r in rows if r[1] != 'all answered']
		lines.append(c(G, '[B]LAST %d SEARCHES[/B]' % len(rows)))
		lines.append('Average time: %.1f s · ended early: %d · time saved: about %.0f s in total'
			% (sum(r[0] for r in rows) / len(rows), len(early), sum(r[2] or 0 for r in rows)))
		lines.append(c(W, 'A provider that is still searching when the list closes keeps going in the background, and what it finds is ready the next time you open the title.'))
	advice = sorted(set(advice))
	return '[CR]'.join(lines), advice


def show():
	"""Router action tools_searchSpeed."""
	try:
		text, advice = report_text()
		from resources.lib.modules.provider_test import _show_report
		_show_report(control.lang(401100), text)
		names = ', '.join(a.upper() for a in advice)
		if advice and control.yesnoDialog(control.lang(401105) % names, '', ''):
			for a in advice: control.setSetting('provider.%s' % a, 'false')
			control.notification(message=control.lang(401106) % names)
	except Exception:
		log_utils.error()


def reset_action():
	"""Router action tools_searchSpeedReset."""
	if not control.yesnoDialog(control.lang(401107), '', ''): return
	if reset(): control.notification(message=401108)
