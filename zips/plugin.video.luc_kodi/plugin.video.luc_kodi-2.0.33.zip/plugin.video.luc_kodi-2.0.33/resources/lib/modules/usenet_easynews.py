# -*- coding: utf-8 -*-
"""
	luc_kodi - Easynews como proveedor Usenet para el scraper Newznab (v2.0.24 test)

	Modelo: el INDEXER (NZBGeek u otro Newznab) encuentra el NZB, EASYNEWS lo
	sirve por NNTP (tu cuenta de Easynews es tambien un servidor Usenet) y el
	motor local de luc_kodi (usenet_stream.py, en el servicio) lo reproduce
	al momento, sin descargarlo entero y sin pasar por ningun debrid.

	Este modulo es el pegamento del lado del plugin:
	  enabled()         ajuste newznab.use_easynews + credenciales de Easynews
	  nntp_config()     servidor/puerto/conexiones desde los ajustes
	  fetch_nzb()       baja el .nzb del indexer UNA vez y lo guarda en el
	                    perfil (usenet/nzb/<hash>.nzb, sin el apikey)
	  health_filter()   comprobacion de salud en el scraper: descarta los NZB
	                    borrados en Easynews y marca los verificados
	  resolve()         prepara la sesion en el servicio y devuelve la URL local
	  start_service() / stop_service()   arranque del motor en service.py
	  test()            accion de ajustes "Test Easynews Usenet (NNTP)"

	Las credenciales se leen de los ajustes en cada uso; no se escriben en
	ningun fichero ni salen en el log.
"""

import hashlib
import json
import os
import re
import threading
import time
from urllib.request import Request, urlopen

from resources.lib.modules import control
from resources.lib.modules import log_utils
from resources.lib.modules import usenet_core as core

getSetting = control.setting
LOGDEBUG = log_utils.LOGDEBUG

HEALTH_TTL_OK = 12 * 3600       # un NZB sano se da por bueno 12 h
# v2.0.33: un NZB borrado (DMCA) no vuelve: se recuerda 7 dias, no 1. Si cambian
# los proveedores de respaldo se vuelve a mirar (el nuevo puede tenerlo).
HEALTH_TTL_DEAD = 7 * 86400
HEALTH_TTL_PLAYED = 7 * 86400   # v2.0.33: un NZB que de verdad se reprodujo
PLAYED_MIN_BYTES = 64 * 1024 * 1024   # lo que hay que ver para darlo por bueno
ARCHIVE_CHECKS = 6              # v2.0.33: cabeceras de archivo que se leen por busqueda
NZB_KEEP_SECS = 3 * 86400       # los .nzb del perfil se limpian a los 3 dias
# Sube cada vez que el motor aprende a abrir algo que antes rechazaba (4 =
# RAR con un ajeno colado entre volumenes con nombre): lo rechazado por un motor
# anterior se vuelve a ofrecer.
ENGINE_VERSION = 6 # v2.0.32: M2TS de Blu-ray; los que el motor 5 dio por no reproducibles se vuelven a mirar. Antes: v2.0.28: 7z 'store'; los 7z que dio por no reproducibles el motor 4 se vuelven a mirar
HEALTH_BUDGET_SECS = 18         # tiempo maximo de la comprobacion por busqueda
# v2.0.25: un NZB que el indexer tarda en dar no retiene la busqueda. Log del
# 2-nov-2026: en 6 de 7 busquedas un solo NZB agotaba los 20 s de espera y la
# lista tardaba 20,1 s en salir con los otros 7 ya comprobados en 2-7 s.
HEALTH_NZB_TIMEOUT = 8
HEALTH_WANT_OK = 8              # se para al encontrar estos releases buenos
HEALTH_CONNECTIONS = 8          # conexiones para STAT (Easynews permite 60)
UA = 'luc_kodi for Kodi'

_health_lock = threading.Lock()
_DISC_RE = re.compile(r'(?:^|[ ._\-\[(])(?:COMPLETE[ ._\-]+(?:UHD[ ._\-]+)?BLU-?RAY|BDMV|BD(?:25|50|66|100)|ISO|DISC\d*)(?:[ ._\-\])]|$)', re.I)
# v2.0.33 (kodi.log del 12-nov-2026): 'Project.Hail.Mary.2026.COMPLETE.2160p.USA.UHD.Blu-ray...-TMT' es
# el disco entero en 7z y se colaba: entre COMPLETE y BLU-RAY van la resolucion y la region. Hasta 5
# etiquetas en medio, y nunca si el nombre dice que es un fichero (x264/x265, REMUX, WEB): un pack de
# serie 'S01.COMPLETE.1080p.BluRay.x264' no es un disco.
_DISC_LOOSE_RE = re.compile(r'(?:^|[ ._\-\[(])COMPLETE(?:[ ._\-]+[A-Za-z0-9]{1,8}){0,5}?[ ._\-]+(?:UHD[ ._\-]+)?BLU-?RAY(?:[ ._\-\])]|$)', re.I)
_NOT_DISC_RE = re.compile(r'(?i)(?:^|[ ._\-\[(])(?:[xh][ ._]?26[45]|REMUX|WEB(?:-?DL|-?RIP)?|AVC[ ._\-]?REMUX)(?:[ ._\-\])]|$)')
# v2.0.33 (auditoria del 13-nov-2026): la regla amplia tomaba por disco 5 de cada 10 packs de
# temporada (en HEVC, AV1 o sin codec en el nombre) y, sin Premiumize ni TorBox, los quitaba de la
# lista. Un nombre con marca de temporada no es disco por la regla amplia; un disco de temporada
# sigue cayendo por la estricta (S01.COMPLETE.BLURAY) o por su primer trozo (v2.0.33).
_SEASON_MARK_RE = re.compile(r'(?i)(?:^|[ ._\-\[(])(?:S\d{1,2}(?:[ ._\-]?E\d{1,3})?|SEASONS?[ ._\-]?\d{1,2}|COMPLETE[ ._\-]SERIES)(?:[ ._\-\])]|$)')


def is_disc(name):
	"""Imagen de disco Blu-ray (BDMV/ISO o el disco entero empaquetado)."""
	name = name or ''
	if _DISC_RE.search(name):
		return True
	return bool(_DISC_LOOSE_RE.search(name)) and not _NOT_DISC_RE.search(name) and not _SEASON_MARK_RE.search(name)


# -------------------------------------------------------------- ajustes -----
def _bool(id_, default='true'):
	v = getSetting(id_)
	return (v or default) == 'true'


def credentials():
	return (getSetting('easynews.username') or '').strip(), (getSetting('easynews.password') or '').strip()


def enabled():
	"""Easynews activado como reproductor de NZB y con credenciales."""
	if not _bool('newznab.use_easynews'):
		return False
	u, p = credentials()
	return bool(u and p)


def other_services():
	"""Hay otro servicio de NZB activo (Premiumize/TorBox) como respaldo."""
	pm = _bool('newznab.use_premiumize') and getSetting('premiumize.enable') == 'true' and bool(getSetting('premiumize.token'))
	tb = _bool('newznab.use_torbox') and getSetting('torbox.enable') == 'true' and bool(getSetting('torbox.token'))
	return pm or tb


def nntp_config():
	u, p = credentials()
	server = getSetting('newznab.en_server') or '0'
	host = core.EASYNEWS_HOSTS['us' if server == '1' else 'eu']
	port = 443 if (getSetting('newznab.en_port') or '0') == '1' else 563
	try: conns = int(getSetting('newznab.en_connections') or DEFAULT_CONNECTIONS)
	except ValueError: conns = DEFAULT_CONNECTIONS
	return {'host': host, 'port': port, 'user': u, 'password': p,
			'connections': max(2, min(conns, MAX_CONNECTIONS)), 'ssl': True, 'timeout': 20,
			'profile': _profile(), 'backups': backup_configs()}


MAX_CONNECTIONS = 60      # Easynews: 60 a la vez por cuenta, en todas las cuentas
DEFAULT_CONNECTIONS = 20


LOW_RAM_MB = 2048     # por debajo, Balanced pasa solo a Efficient

def _device_ram_mb():
	"""RAM total del aparato en MB segun Kodi, o None."""
	try:
		import xbmc
		raw = xbmc.getInfoLabel('System.Memory(total)') or ''
		m = re.search(r'([\d.,]+)\s*([GM])B', raw, re.I)
		if not m: return None
		n = float(m.group(1).replace(',', '.'))
		return int(n * 1024) if m.group(2).upper() == 'G' else int(n)
	except Exception:
		return None

_PROFILE_NOTED = []

def _profile():
	"""0 Efficient, 1 Balanced. v2.0.32: Balanced pasa solo a Efficient en
	aparatos de menos de 2 GB de RAM (cajas y TV con skin y addons)."""
	try: p = max(0, min(1, int(getSetting('newznab.en_profile') or 1)))
	except ValueError: p = 1
	if p == 1:
		ram = _device_ram_mb()
		if ram and ram < LOW_RAM_MB:
			if not _PROFILE_NOTED:
				_PROFILE_NOTED.append(1)
				log_utils.log('USENET: %d MB of RAM on this device: the Efficient profile is used' % ram, level=log_utils.LOGINFO)
			return 0
	return p


_BK_SLOTS = {1: 'newznab.bk_', 2: 'newznab.bk2_'}


def backup_config(slot=1):
	"""v2.0.32 (informe L7): proveedor Usenet de respaldo n.º slot (1 o 2), solo
	para los articulos que Easynews ya no tiene. None si no esta configurado.
	Arreglo B2: un puerto escrito en el servidor ('host:443') manda sobre el
	desplegable, y la prueba lo dice."""
	pre = _BK_SLOTS.get(int(slot or 1), 'newznab.bk_')
	host = (getSetting(pre + 'host') or '').strip()
	if not host:
		return None
	host = re.sub(r'^\w+://', '', host).split('/')[0].strip()
	port = {'1': 443, '2': 119}.get(getSetting(pre + 'port') or '0', 563)
	typed = False
	m = re.match(r'^\[?([^\]]+?)\]?:(\d{2,5})$', host)
	if m:
		host, port, typed = m.group(1), int(m.group(2)), True
	# SSL salvo en los puertos clasicos sin cifrar (119 y los de Easynews sin SSL)
	ssl = port not in (119, 23, 25, 80, 110, 8000) if typed else port != 119
	try: conns = int(getSetting(pre + 'connections') or 4)
	except ValueError: conns = 4
	return {'host': host, 'port': port, 'ssl': ssl, 'timeout': 20, 'port_typed': typed, 'slot': int(slot or 1),
			'name': 'backup provider %d' % int(slot or 1),
			'user': (getSetting(pre + 'user') or '').strip(), 'password': getSetting(pre + 'pass') or '',
			'connections': max(1, min(conns, 20))}


def backup_configs():
	"""Los proveedores de respaldo configurados, por orden (1 y luego 2)."""
	return [b for b in (backup_config(1), backup_config(2)) if b]


def _usenet_dir():
	d = os.path.join(control.dataPath, 'usenet')
	nzb = os.path.join(d, 'nzb')
	if not os.path.isdir(nzb):
		try: os.makedirs(nzb)
		except OSError: pass
	return d


def nzb_dir():
	return os.path.join(_usenet_dir(), 'nzb')


def nzb_key(nzb_url):
	"""Misma clave que el 'hash' del scraper Newznab: md5 del enlace."""
	return hashlib.md5((nzb_url or '').encode('utf-8')).hexdigest()


def _mask(text, nzb_url=None):
	key = getSetting('newznab.apikey') or ''
	if key and text:
		text = text.replace(key, '<APIKEY>')
	return text


# ------------------------------------------------------------- informe ------
def _stats(kind, key='', title='', **data):
	"""v2.0.25: apunta en usenet_stats (Tools > Usenet report). Nunca falla."""
	try:
		from resources.lib.modules import usenet_stats
		usenet_stats.record(kind, key, title, **data)
	except Exception:
		pass


def _group(name):
	try:
		from resources.lib.modules.release_groups import parse_group
		g = parse_group(name or '') or ''
		# as the group writes itself in the release name (FLUX, NTb), not lowercased
		m = re.search(r'(?i)(?<![A-Za-z0-9])(%s)(?![A-Za-z0-9])' % re.escape(g), name or '') if g else None
		return m.group(1) if m else g
	except Exception:
		return ''


# ------------------------------------------------------------------ NZB -----
# v2.0.32 — descargas de NZB por indexer (log del 11-nov-2026: tras ~30 grabs de
# comprobaciones de salud un indexer devolvio 429 a cada NZB, tambien al darle
# a reproducir, y Forrest Gump / Fight Club no arrancaron). Cada .nzb es 1 grab
# del cupo diario y las cuentas gratis traen 3-10. Ahora:
#   - un 429 (o el error 500/501 de Newznab: cupo agotado) deja ese indexer en
#     reposo (Retry-After o 1 h): ni busqueda ni NZB, sin martillearlo;
#   - si el indexer manda newznab:apilimits, la salud deja GRAB_RESERVE grabs
#     sin tocar para poder reproducir;
#   - el mismo release en otro indexer queda como alternativa ('alts') y
#     se usa si el primero no da el NZB.
GRAB_RESERVE = 3
_REST_PROP = 'luc_kodi.newznab.rest.%s'      # el mismo que mira newznab.py
_LEFT_PROP = 'luc_kodi.newznab.grableft.%s'  # 'quedan|epoch', lo pone newznab.py
_LEFT_FRESH = 1800
_NZB_LIMIT_CODES = ('429', '500', '501')


def _host(url):
	try: return str(url).split('://', 1)[1].split('/', 1)[0].lower()
	except Exception: return ''


def _short(host):
	h = re.sub(r'^(api|www)\.', '', (host or '').split(':')[0])
	return (h.split('.')[0] or 'indexer').upper()


def grab_resting(host):
	try: return float(control.homeWindow.getProperty(_REST_PROP % host) or 0) > time.time()
	except Exception: return False


def _grab_rest(host, why, secs=3600):
	if not host: return
	if grab_resting(host): return      # otro hilo ya lo dejo en reposo
	try: control.homeWindow.setProperty(_REST_PROP % host, str(int(time.time() + secs)))
	except Exception: pass
	log_utils.log('USENET: %s gives no more NZBs (%s); it rests for %d min' % (_short(host), why, secs // 60),
				  level=log_utils.LOGINFO)


def grabs_left(host):
	"""Grabs que le quedan hoy al indexer segun su ultima respuesta, o None."""
	try:
		raw = control.homeWindow.getProperty(_LEFT_PROP % host) or ''
		left, ts = raw.split('|')
		if time.time() - float(ts) > _LEFT_FRESH: return None
		return int(left)
	except Exception:
		return None


def _spent_grab(host):
	n = grabs_left(host)
	if n is None: return
	try: control.homeWindow.setProperty(_LEFT_PROP % host, '%d|%d' % (max(0, n - 1), int(time.time())))
	except Exception: pass


def candidates(item):
	"""[(url, host)] del item: el suyo y los del mismo release en otros indexers."""
	url = item.get('url') or ''
	out = [(url, item.get('nzb_host') or _host(url))]
	for alt in item.get('alts') or []:
		try:
			u, h = alt[0], alt[1] or _host(alt[0])
			if u and u != url: out.append((u, h))
		except Exception: pass
	return out


def _cached_nzb(key):
	path = os.path.join(nzb_dir(), '%s.nzb' % key)
	return path if os.path.exists(path) and os.path.getsize(path) > 0 else None


def fetch_nzb(nzb_url, key=None, timeout=20, host=None):
	"""Ruta local del .nzb (descargandolo si hace falta) o None."""
	key = key or nzb_key(nzb_url)
	path = os.path.join(nzb_dir(), '%s.nzb' % key)
	if _cached_nzb(key):
		_stats('cached', key)
		return path
	if not str(nzb_url or '').lower().startswith(('http://', 'https://')):
		return None
	host = host or _host(nzb_url)
	if grab_resting(host):
		return None
	try:
		req = Request(nzb_url, headers={'User-Agent': UA})
		with urlopen(req, timeout=timeout) as r:
			raw = r.read()
		if b'<nzb' not in raw:
			snippet = raw[:160].decode('utf-8', 'replace')
			m = re.search(r'<error\b[^>]*\bcode="(\d+)"', snippet, re.I)
			if m and m.group(1) in _NZB_LIMIT_CODES:
				_grab_rest(host, 'indexer error %s' % m.group(1))
			log_utils.log('USENET: %s did not return an NZB: %s' % (_short(host), _mask(snippet)), level=LOGDEBUG)
			return None
		tmp = path + '.part'
		# v2.0.25: comprimido (un NZB de un remux pesa 4-6 MB de XML y baja a la
		# quinta parte); usenet_core.parse_nzb lo abre igual comprimido o no.
		import gzip
		with open(tmp, 'wb') as f:
			f.write(gzip.compress(raw, 6))
		os.replace(tmp, path)
		_spent_grab(host)
		_stats('grab', key, bytes=len(raw))
		return path
	except Exception as e:
		code = getattr(e, 'code', None)
		if code == 429:
			try: secs = int((e.headers or {}).get('Retry-After') or 0)
			except Exception: secs = 0
			_grab_rest(host, 'HTTP 429 Too Many Requests', secs if 60 <= secs <= 86400 else 3600)
		log_utils.log('USENET: NZB download from %s failed: %s' % (_short(host), _mask('%s: %s' % (type(e).__name__, e))),
					  level=LOGDEBUG)
		return None


def fetch_nzb_item(item, key=None, timeout=20):
	"""Prueba el NZB del item y, si su indexer no lo da, el mismo release en
	los otros. (ruta, None) o (None, motivo)."""
	key = key or item.get('hash') or nzb_key(item.get('url'))
	if _cached_nzb(key):
		_stats('cached', key)
		return _cached_nzb(key), None
	tried, resting = [], []
	for url, host in candidates(item):
		if grab_resting(host):
			resting.append(_short(host)); continue
		tried.append(_short(host))
		path = fetch_nzb(url, key, timeout=timeout, host=host)
		if path:
			if len(tried) > 1 or resting:
				log_utils.log('USENET: NZB taken from %s (the same release on another indexer)' % _short(host),
							  level=log_utils.LOGINFO)
			return path, None
		if grab_resting(host):
			resting.append(_short(host))
	if resting:
		return None, '%s gives no more NZBs today (download limit); pick a release from another indexer' \
			% '/'.join(sorted(set(resting)))
	return None, 'could not download the NZB from the indexer'


def cleanup(max_age=NZB_KEEP_SECS):
	try:
		d = nzb_dir(); now = time.time()
		for n in os.listdir(d):
			p = os.path.join(d, n)
			try:
				if now - os.path.getmtime(p) > max_age:
					os.remove(p)
			except OSError: pass
	except Exception:
		pass


# --------------------------------------------------------------- salud ------
def _health_path():
	# Ficheros de versiones de prueba anteriores: se borran una vez. Desde
	# aqui los 'no reproducible' llevan la version del motor (ENGINE_VERSION)
	# y caducan solos cuando el motor aprende algo nuevo.
	for oldname in ('health.json', 'health_v2.json'):
		old = os.path.join(_usenet_dir(), oldname)
		if os.path.exists(old):
			try: os.remove(old)
			except OSError: pass
	return os.path.join(_usenet_dir(), 'health_v3.json')


def _health_load():
	try:
		with open(_health_path(), 'r') as f:
			return json.load(f)
	except Exception:
		return {}


def _ttl(v):
	if v.get('status') in ('dead', 'unplayable'):
		return HEALTH_TTL_DEAD
	if v.get('played'):
		return HEALTH_TTL_PLAYED
	return HEALTH_TTL_OK


def providers_mark(cfg=None):
	"""v2.0.33: huella de los proveedores de respaldo. Un 'borrado' que se
	apunto con otros proveedores se vuelve a comprobar."""
	try:
		bks = (cfg or {}).get('backups') if cfg is not None else backup_configs()
		return '|'.join(sorted('%s:%s' % (b.get('host'), b.get('port')) for b in bks or []))
	except Exception:
		return ''


def _health_save(data):
	now = time.time()
	keep = {k: v for k, v in data.items() if now - v.get('ts', 0) < _ttl(v)}
	try:
		tmp = _health_path() + '.part'
		with open(tmp, 'w') as f:
			json.dump(keep, f)
		os.replace(tmp, _health_path())
	except Exception:
		pass


def _cached_verdict(cache, key, mark=None):
	v = cache.get(key)
	if not v:
		return None
	if v.get('eng') is not None and v.get('eng') != ENGINE_VERSION:
		return None      # lo rechazo un motor anterior: se vuelve a mirar
	if mark is not None and v.get('status') == 'dead' and v.get('eng') is None and (v.get('pf') or '') != mark:
		return None      # v2.0.33: otros proveedores de respaldo; puede que ahora si este
	return v if time.time() - v.get('ts', 0) < _ttl(v) else None


def _remember_dead(key, pct=0, engine=False):
	"""engine=True: no es que falten articulos, es que el motor no sabe
	abrirlo; el veredicto lleva su version y caduca con la siguiente."""
	try:
		with _health_lock:
			cache = _health_load()
			cache[key] = {'status': 'dead', 'pct': pct, 'kind': None, 'checked': 1, 'ts': time.time(),
						  'pf': providers_mark()}
			if engine:
				cache[key]['eng'] = ENGINE_VERSION
			_health_save(cache)
	except Exception:
		pass


def _remember_played(summary):
	"""v2.0.33: un NZB que se reprodujo de verdad (sin cortarse por
	incompleto) queda como bueno 7 dias: sale el primero en el salto al
	siguiente NZB y no se vuelve a comprobar. Corre en el servicio."""
	try:
		key = summary.get('key') or ''
		if not (key and summary.get('ready')) or summary.get('incomplete') is not None:
			return
		if int(summary.get('bytes') or 0) < PLAYED_MIN_BYTES:
			return
		with _health_lock:
			cache = _health_load()
			old = cache.get(key) or {}
			cache[key] = {'status': 'ok', 'pct': old.get('pct', 100) if old.get('status') == 'partial' else 100,
						  'kind': old.get('kind'), 'checked': old.get('checked', 0), 'ts': time.time(), 'played': 1}
			if old.get('status') == 'partial':
				cache[key]['status'] = 'partial'
			_health_save(cache)
	except Exception:
		pass


def _on_incomplete(key, pct):
	"""El motor corto un release al que le faltan articulos: se oculta en
	las proximas busquedas y se avisa (esto corre en el servicio)."""
	_remember_dead(key, pct)
	try:
		control.notification(message='Easynews: this release is incomplete (~%d%% missing). Pick another one.' % pct)
	except Exception:
		pass


def known_status(items):
	"""v2.0.32: {clave: 'ok'|'partial'|'dead'} de lo que ya se sabe de estos
	items en Easynews, tambien lo que comprobo la salud en segundo plano
	despues de abrirse la lista (el salto al siguiente NZB lo usa)."""
	with _health_lock:
		cache = _health_load()
	mark = providers_mark()
	out = {}
	for it in items or []:
		k = it.get('hash') or nzb_key(it.get('url'))
		v = _cached_verdict(cache, k, mark)
		if v:
			st = v.get('status')
			out[k] = 'dead' if st in ('dead', 'empty', 'unplayable') else ('played' if v.get('played') else st)
	return out


def dead_keys():
	"""Claves de NZB que se sabe que estan borrados en Easynews (vigentes).
	sources.py las quita tambien de los resultados que vienen de la cache de
	proveedores (que no vuelve a pasar por el scraper durante horas).
	v2.0.33: tambien los que el motor no puede abrir (RAR comprimido...), salvo
	que haya Premiumize o TorBox para bajarlos."""
	with _health_lock:
		cache = _health_load()
	mark = providers_mark()
	gone = ('dead', 'unplayable') if not other_services() else ('dead',)
	return {k for k in cache if (_cached_verdict(cache, k, mark) or {}).get('status') in gone}


def _badge_into_info(info, badge):
	"""El badge va DETRAS del tamano: la lista de fuentes corta todo lo que
	hay antes de 'GB ' (prueba del 1-nov-2026: 'EN OK' delante no se veia)."""
	if not info:
		return badge
	parts = info.split(' | ')
	if parts and re.match(r'^\d+(\.\d+)?\s*(GB|MB|GiB|MiB)$', parts[0].strip(), re.I):
		return ' | '.join([parts[0], badge] + parts[1:])
	return '%s | %s' % (badge, info)


def _pick_grab(key, cands, budget):
	"""(url, host) con el que comprobar un release, o None si bajar su NZB
	gastaria un grab que hace falta para reproducir. Se llama con el lock."""
	if _cached_nzb(key):
		return cands[0]
	for url, host in cands:
		if grab_resting(host):
			continue
		if host not in budget:
			left = grabs_left(host)
			budget[host] = None if left is None else max(0, left - GRAB_RESERVE)
		b = budget[host]
		if b is None:
			return url, host
		if b > 0:
			budget[host] = b - 1
			return url, host
	return None


class _BackupChain(object):
	"""v2.0.32 (informe L7, B1): los proveedores de respaldo, por orden, para la
	comprobacion de salud (solo STAT de lo que falta en Easynews). Cada uno con
	su grupo de conexiones compartido, nunca mas de las de su ajuste."""
	def __init__(self, cfgs):
		from resources.lib.modules.usenet_stream import BackupPool
		self.pools = [BackupPool(dict(c, connections=min(2, c.get('connections') or 2)),
								 lambda m: log_utils.log(m, level=log_utils.LOGINFO)) for c in cfgs]

	def get(self):
		return self if any(not p.failed for p in self.pools) else None

	def stat_many(self, ids):
		codes = [None] * len(ids)
		todo = list(range(len(ids)))
		for pool in self.pools:
			if not todo or pool.failed:
				continue
			try: got = pool.stat_many([ids[i] for i in todo])
			except Exception: continue
			left = []
			for i, c in zip(todo, got):
				if c == core.NNTP_OK_STAT: codes[i] = c
				else: left.append(i)
			todo = left
		return [c if c is not None else core.NNTP_NO_ARTICLE for c in codes]

	def close(self):
		for p in self.pools:
			p.close()


def health_filter(items, other_resolvers=None, wait=None):
	"""Comprueba en Easynews los NZB de la lista y devuelve la lista filtrada.

	Orden: el mismo que vera el usuario (mejor calidad primero, luego grabs).
	Se sigue comprobando hasta tener HEALTH_WANT_OK releases buenos, o llegar
	al tope del ajuste (cada comprobacion baja el NZB = 1 grab del indexer), o
	agotar el tiempo. Prueba del 1-nov-2026 (Supergirl 2026, Tenzing 2026):
	los 8 primeros estaban todos borrados y el usuario fue pinchando, uno
	tras otro, releases sin comprobar que tambien lo estaban.

	  - 'dead' (borrado en Easynews)          -> fuera
	  - 'ok' / 'partial'                       -> marcado (en_health, badge)
	  - 7z                                     -> se queda (v2.0.28: el motor
	                                              reproduce los 7z 'store'; uno
	                                              comprimido lo dice al abrirlo)
	  - sin comprobar                          -> 'EN ?'; y si la mitad o mas
	    de lo comprobado estaba borrado, fuera tambien: en ese titulo lo que
	    queda sin comprobar casi seguro que tampoco esta.
	"""
	if not items or not enabled() or not _bool('newznab.en_health'):
		return items
	if other_resolvers is None:
		other_resolvers = other_services()
	try: limit = int(getSetting('newznab.en_health_checks') or 20)
	except ValueError: limit = 20
	cfg = nntp_config()
	mark = providers_mark(cfg)
	fg_bytes = [0]     # v2.0.33: MB de cabeceras leidos antes de abrir la lista
	t0 = time.time()
	with _health_lock:
		cache = _health_load()
	# Discos Blu-ray completos (BDMV/ISO dentro del RAR): ni el motor ni Kodi
	# los reproducen como un fichero. Log del 1-nov-2026: Addams Family y
	# Shawshank 'COMPLETE.UHD.BLURAY' pasaban la salud y fallaban al abrirlos.
	n_disc = 0
	if not other_resolvers:
		keep = [i for i in items if not is_disc(i.get('name'))]
		n_disc = len(items) - len(keep)
		items = keep
	_qrank = {'4K': 0, '1080p': 1, '720p': 2, 'SD': 3, 'SCR': 4, 'CAM': 5}
	ordered = sorted(items, key=lambda i: (_qrank.get(i.get('quality'), 3), -int(i.get('seeders') or 0)))
	verdicts = {}
	queue = []
	for it in ordered:
		if it.get('package'):
			continue   # v2.0.33: un pack se comprueba al abrir SU episodio, no el fichero mayor
		k = it.get('hash') or nzb_key(it.get('url'))
		v = _cached_verdict(cache, k, mark)
		if v: verdicts[k] = v
		else: queue.append((k, candidates(it)))
	state = {'auth_failed': False, 'checked': 0, 'inflight': 0, 'archives': 0, 'abytes': 0,
			 'ok': sum(1 for v in verdicts.values() if v.get('status') in ('ok', 'partial'))}

	fresh = set()
	found = {}          # lo que comprueban los hilos; se copia al acabar el tiempo
	if queue and limit > 0:
		lock = threading.Lock()
		budget = {}     # grabs que la salud puede gastar por indexer (None: sin datos)
		backup = _BackupChain(cfg['backups']) if cfg.get('backups') else None

		def worker():
			conn = None
			while time.time() - t0 < HEALTH_BUDGET_SECS and not state['auth_failed']:
				with lock:
					if not queue or state['checked'] >= limit or state['ok'] >= HEALTH_WANT_OK:
						break
					# Con 8 hilos en vuelo se pasaba de largo: la prueba del
					# 1-nov-2026 comprobo 15 para quedarse con 8 (15 grabs). Si
					# los que ya estan en vuelo bastan, se espera a ver como
					# acaban antes de bajar otro NZB.
					wait = state['ok'] + state['inflight'] >= HEALTH_WANT_OK
					pick = None
					while not wait and queue and pick is None:
						k, cands = queue.pop(0)
						pick = _pick_grab(k, cands, budget)
					if pick is None and not wait:
						break      # lo que queda no se puede bajar sin gastar los grabs de reproducir
					if not wait:
						url, host = pick
						state['checked'] += 1
						state['inflight'] += 1
				if wait:
					time.sleep(0.05)
					continue
				try:
					left = HEALTH_BUDGET_SECS - (time.time() - t0)
					path = fetch_nzb(url, k, timeout=max(3, min(HEALTH_NZB_TIMEOUT, left)), host=host)
					if not path:
						# el indexer se acaba de quedar sin cupo: el release vuelve
						# a la cola con los NZB de los otros indexers
						rest_c = [c for c in cands if c[1] != host]
						if rest_c and grab_resting(host):
							with lock:
								queue.insert(0, (k, rest_c))
								state['checked'] -= 1
						continue
					with open(path, 'rb') as f:
						files = core.parse_nzb(f.read())
					if conn is None:
						conn = core.NNTPConn(cfg['host'], cfg['port'], cfg['user'], cfg['password'], timeout=15)
					v = core.check_health(conn, files, backup=backup.get if backup else None)
					# v2.0.33: en un release en archivo (RAR, 7z, ofuscado) se lee
					# la cabecera (1 articulo): un RAR comprimido o cifrado se sabe
					# ahora y no al darle a reproducir
					if v['status'] in ('ok', 'partial') and v.get('kind') in core.ARCHIVE_KINDS:
						with lock:
							look = state['archives'] < ARCHIVE_CHECKS
							if look: state['archives'] += 1
						meter = []
						why = core.check_archive(conn, files, meter) if look else None
						if meter:
							with lock: state['abytes'] += meter[0]
						if why:
							v = dict(v, status='unplayable', why=why, eng=ENGINE_VERSION)
					v['ts'] = time.time()
					if v['status'] == 'dead':
						v['pf'] = mark
					with lock:
						found[k] = v
						if v['status'] in ('ok', 'partial'): state['ok'] += 1
				except core.NNTPAuthError as e:
					state['auth_failed'] = True
					log_utils.log('USENET: Easynews login refused during health check: %s' % e, level=log_utils.LOGINFO)
				except Exception as e:
					log_utils.log('USENET: health check error: %s: %s' % (type(e).__name__, e), level=LOGDEBUG)
					try:
						if conn: conn.close()
					except Exception: pass
					conn = None
				finally:
					with lock: state['inflight'] -= 1
			if conn: conn.close()

		# Solo STAT, sin decodificar nada: aqui mas conexiones si cunden.
		n = min(len(queue), limit, HEALTH_CONNECTIONS)
		threads = [threading.Thread(target=worker) for _ in range(n)]
		for t in threads:
			t.daemon = True
			t.start()
		# no se espera a los rezagados: lo que no acabe a tiempo sale como 'EN ?'.
		# v2.0.32: con wait (la busqueda, log del 11-nov-2026) se espera solo eso:
		# la comprobacion entera tardaba 6-10 s y la busqueda rapida abria la
		# lista sin ningun resultado de NZBGeek ni de altHUB. Lo que siga
		# comprobandose se guarda al acabar y vale para la siguiente vez y para
		# el salto al siguiente NZB.
		cap = HEALTH_BUDGET_SECS + 1 if wait is None else max(0.1, float(wait))
		for t in threads:
			left = cap - (time.time() - t0)
			if left <= 0: break
			t.join(left)
		with lock:
			done = dict(found)
			fg_bytes[0] = state['abytes']
		verdicts.update(done)
		fresh = set(done)
		with _health_lock:
			cache = _health_load()
			for k, v in list(verdicts.items()):
				if 'ts' in v: cache[k] = v
			_health_save(cache)
		late = [t for t in threads if t.is_alive()]
		if not late and backup:
			backup.close()
		if late:
			def _finish():
				for t in late:
					t.join(max(0.1, HEALTH_BUDGET_SECS + 1 - (time.time() - t0)))
				if backup:
					backup.close()
				with lock:
					rest = {k: v for k, v in found.items() if k not in done}
					late_bytes = state['abytes'] - fg_bytes[0]
				if late_bytes > 0:
					_stats('headers', header_bytes=late_bytes)   # v2.0.33: lo leido en segundo plano
				if not rest:
					return
				with _health_lock:
					c = _health_load()
					c.update(rest)
					_health_save(c)
				n_ok = sum(1 for v in rest.values() if v.get('status') in ('ok', 'partial'))
				n_un = sum(1 for v in rest.values() if v.get('status') == 'unplayable')
				log_utils.log('USENET: health check finished in the background: %d more checked, %d good, %d removed, '
							  '%d not streamable here (%.1fs)'
							  % (len(rest), n_ok, len(rest) - n_ok - n_un, n_un, time.time() - t0), level=log_utils.LOGINFO)
			fin = threading.Thread(target=_finish)
			fin.daemon = True
			fin.start()

	# v2.0.33 (kodi.log del 13-nov-2026): ya no se esconden los no comprobados
	# cuando la mitad de lo comprobado esta borrado. Con los borrados recordados
	# 7 dias esa cuenta crecia en cada busqueda: Mayday y Eternity abrian la
	# lista VACIA y la salud de detras encontraba luego 4 y 5 releases buenos;
	# al repetir la busqueda salian 4 y 1. Desde la 2.0.32, si uno sin comprobar
	# esta borrado se prueba solo el siguiente NZB (primero los verificados).
	hide_unchecked = False
	out, dead, rar_dropped, ok, hidden, unplay = [], 0, n_disc, 0, 0, 0
	for it in items:
		if it.get('package'):
			new = dict(it)
			new['info'] = _badge_into_info(new.get('info') or '', 'EN PACK')
			out.append(new); continue
		k = it.get('hash') or nzb_key(it.get('url'))
		v = verdicts.get(k)
		if not v:
			if hide_unchecked:
				hidden += 1; continue
			new = dict(it)
			new['info'] = _badge_into_info(new.get('info') or '', 'EN ?')
			out.append(new); continue
		if v['status'] in ('dead', 'empty'):
			dead += 1; continue
		if v['status'] == 'unplayable':
			# v2.0.33: el motor no lo abre; con Premiumize/TorBox se queda para
			# ellos (sin pasar por Easynews), sin ellos fuera
			unplay += 1
			if not other_resolvers:
				continue
			new = dict(it)
			new['en_unplayable'] = v.get('why') or 'not streamable'
			new['info'] = _badge_into_info(new.get('info') or '', 'EN %s' % ('7Z' if '7z' in (v.get('why') or '') else 'RAR'))
			out.append(new); continue
		kind = v.get('kind')
		# v2.0.24: el motor ya reproduce RAR 'store'; v2.0.28: y 7z 'store'. Los
		# comprimidos o cifrados los dice el motor al abrirlos (y se apuntan).
		new = dict(it)
		new['en_health'] = v['status']
		new['en_kind'] = kind
		badge = 'EN %d%%' % v.get('pct', 0) if v['status'] == 'partial' else ('EN PLAYED' if v.get('played') else 'EN OK')
		if kind == '7z':
			badge += ' ' + kind.upper()
		new['info'] = _badge_into_info(new.get('info') or '', badge)
		ok += 1
		out.append(new)
	if fresh:
		names = {(it.get('hash') or nzb_key(it.get('url'))): it.get('name') or '' for it in ordered}
		groups = {}
		for k in fresh:
			g = _group(names.get(k))
			if not g: continue
			a = groups.setdefault(g, [0, 0]); a[0] += 1
			if verdicts[k].get('status') in ('dead', 'empty'): a[1] += 1
		_stats('health', checked=len(fresh),
			   ok=sum(1 for k in fresh if verdicts[k].get('status') == 'ok'),
			   partial=sum(1 for k in fresh if verdicts[k].get('status') == 'partial'),
			   dead=sum(1 for k in fresh if verdicts[k].get('status') in ('dead', 'empty')),
			   unplayable=sum(1 for k in fresh if verdicts[k].get('status') == 'unplayable'),
			   secs=round(time.time() - t0, 1), groups=groups, header_bytes=fg_bytes[0])
	log_utils.log('USENET: health check on Easynews: %d verified, %d removed/dead, %d not streamable here '
				  '(compressed or encrypted archives), %d disc images skipped, %d unchecked%s (%d checked now, %.1fs)'
				  % (ok, dead, unplay, rar_dropped, hidden or (len(out) - ok - (unplay if other_resolvers else 0)),
					 ' and hidden (most checked releases of this title are gone)' if hidden else '',
					 state['checked'], time.time() - t0), level=log_utils.LOGINFO)
	return out


# ------------------------------------------------------------- resolver -----
def _service_port():
	try:
		return int(control.homeWindow.getProperty('luc_kodi.usenet.port') or 0)
	except Exception:
		return 0


def _local_get(port, path, timeout=60):
	with urlopen('http://127.0.0.1:%d%s' % (port, path), timeout=timeout) as r:
		return r.read()


def _episode_files(files, season, episode):
	"""v2.0.33: los ficheros de UN episodio dentro de un pack de temporada:
	los que lo nombran (S01E05, 1x05...). Solo el nombre del fichero, nunca el
	asunto entero: su '[01/05]' parece un S01E05. [] si no se puede saber."""
	try:
		from resources.lib.modules.source_utils import seas_ep_filter
	except Exception:
		return []
	out = []
	for f in files or []:
		if core.classify(f.get('name')) in ('par2', 'extra', 'obfuscated'):
			continue
		try:
			if seas_ep_filter(season, episode, f.get('name') or ''):
				out.append(f)
		except Exception:
			pass
	return out


def _write_nzb(path, files):
	"""Un NZB minimo con estos ficheros (el motor pide por message-id: no
	hacen falta grupos), comprimido como los demas."""
	from xml.sax.saxutils import escape, quoteattr
	parts = ['<?xml version="1.0" encoding="utf-8"?>\n<nzb xmlns="http://www.newzbin.com/DTD/2003/nzb">']
	for f in files:
		parts.append('<file poster="" date="0" subject=%s><groups><group>alt.binaries</group></groups><segments>'
					 % quoteattr(f.get('subject') or '"%s"' % (f.get('name') or '')))
		for num, nb, mid in f.get('segments') or []:
			parts.append('<segment bytes="%d" number="%d">%s</segment>' % (int(nb or 0), int(num or 0), escape(mid)))
		parts.append('</segments></file>')
	parts.append('</nzb>')
	import gzip
	tmp = path + '.part'
	with open(tmp, 'wb') as fh:
		fh.write(gzip.compress(''.join(parts).encode('utf-8'), 6))
	os.replace(tmp, path)


def pack_episode(path, key, season, episode):
	"""v2.0.33: de un NZB de pack, (clave, None) de un NZB propio con solo el
	episodio pedido, o (None, motivo). Antes el motor abria el fichero mayor del
	pack: otro episodio (con 'solo episodios' apagado)."""
	try:
		s_n, e_n = int(season), int(episode)
	except (TypeError, ValueError):
		return None, 'season pack: no episode number to pick'
	sub = nzb_key('%s|S%02dE%02d' % (key, s_n, e_n))
	if _cached_nzb(sub):
		return sub, None
	try:
		with open(path, 'rb') as f:
			files = core.parse_nzb(f.read())
	except Exception as e:
		return None, 'season pack: NZB unreadable (%s)' % type(e).__name__
	mine = _episode_files(files, s_n, e_n)
	if not mine:
		return None, 'season pack with hidden file names: S%02dE%02d cannot be picked (not streamable)' % (s_n, e_n)
	try:
		_write_nzb(os.path.join(nzb_dir(), '%s.nzb' % sub), mine)
	except Exception as e:
		return None, 'season pack: %s' % type(e).__name__
	log_utils.log('USENET: season pack: S%02dE%02d is %d of its %d files' % (s_n, e_n, len(mine), len(files)),
				  level=log_utils.LOGINFO)
	return sub, None


def resolve(item, runtime=None, season=None, episode=None):
	"""(url local reproducible, None) o (None, motivo). runtime: segundos de
	video si se saben (v2.0.32, informe N3: la lectura anticipada se calcula
	con la duracion real, no con 90 min supuestos). v2.0.33: season/episode
	para un pack de temporada (se reproduce ese episodio, no el fichero mayor)."""
	if not enabled():
		return None, 'Easynews is not enabled or has no credentials'
	port = _service_port()
	if not port:
		return None, 'luc_kodi service stream server is not running'
	url = item.get('url') or ''
	key = item.get('hash') or nzb_key(url)
	# v2.0.33 (kodi.log del 12-nov-2026): la salud que sigue detras de la lista
	# ya habia visto el disco de Project Hail Mary y aun asi se abrio. Lo ya
	# sabido se dice al momento y se pasa al siguiente NZB.
	if not item.get('package'):
		try:
			with _health_lock:
				v = _cached_verdict(_health_load(), key, providers_mark())
		except Exception:
			v = None
		if v and v.get('status') in ('dead', 'empty'):
			return None, 'removed from Easynews (430), found by the availability check'
		if v and v.get('status') == 'unplayable':
			return None, '%s (not streamable), found by the availability check' % (v.get('why') or 'archive')
	path, why = fetch_nzb_item(item, key)
	if not path:
		return None, why
	if item.get('package'):
		key, why = pack_episode(path, key, season, episode)
		if not key:
			return None, why
	try:
		q = ('?rt=%d' % int(runtime)) if runtime else ''
		info = json.loads(_local_get(port, '/prepare/%s%s' % (key, q), timeout=60).decode('utf-8'))
	except Exception as e:
		return None, 'stream server: %s: %s' % (type(e).__name__, e)
	if not info.get('ok'):
		reason = info.get('reason') or 'not streamable'
		# El primer articulo ya no esta en Easynews: release borrado. Se apunta
		# como 'dead' para que la proxima busqueda no lo vuelva a ensenar.
		# Lo mismo si no se puede reproducir (RAR/7z, imagen de disco, ...):
		# log del 1-nov-2026, un Blu-ray completo (Hocus Pocus BeyondHD) con
		# nombre ofuscado pasaba la salud y fallaba aqui cada vez.
		# Un RAR/7z si lo puede bajar Premiumize/TorBox: no se oculta.
		# Borrado, incompleto o post danado: es el contenido del servidor, no
		# el motor; ninguna version nueva lo arregla.
		if '(430)' in reason or 'incomplete' in reason or 'damaged post' in reason:
			_remember_dead(key)
		elif 'not streamable' in reason and not other_services():
			_remember_dead(key, engine=True)
		return None, reason
	ext = info.get('container') or 'mkv'
	name = (item.get('name') or 'video').replace('/', ' ')
	safe = ''.join(c if (c.isalnum() or c in '._-') else '.' for c in name)[:120].strip('.') or 'video'
	_stats('resolve', key, name, size=info.get('size') or 0)
	log_utils.log('USENET: Easynews stream ready: %s (%s, %.2f GB)'
				  % (name, info.get('detail'), (info.get('size') or 0) / 1073741824.0), level=log_utils.LOGINFO)
	return 'http://127.0.0.1:%d/stream/%s/%s.%s' % (port, key, safe, ext), None


# -------------------------------------------------------------- servicio ----
_server = None


def start_service():
	"""Arranca el motor en el servicio y publica el puerto. Siempre arranca
	(es un socket en 127.0.0.1 sin conexiones hasta que se usa): asi activar
	Easynews en ajustes no exige reiniciar Kodi."""
	global _server
	if _server:
		return _server.port
	from resources.lib.modules.usenet_stream import StreamServer
	_usenet_dir()
	cleanup()

	def _log(msg, level=None):
		log_utils.log(msg, level=log_utils.LOGINFO)
	def _on_close(summary):
		_stats('play', summary.get('key', ''), **{k: v for k, v in summary.items() if k != 'key'})
		_remember_played(summary)   # v2.0.33
	_server = StreamServer(nzb_dir(), nntp_config, _log, on_incomplete=_on_incomplete, on_close=_on_close)
	port = _server.start()
	if port:
		control.homeWindow.setProperty('luc_kodi.usenet.port', str(port))
	return port


def stop_service():
	global _server
	try: control.homeWindow.clearProperty('luc_kodi.usenet.port')
	except Exception: pass
	if _server:
		_server.stop()
		_server = None


# ----------------------------------------------------------------- test -----
def test():
	"""Accion de ajustes: login NNTP + control de STAT + puerto del motor."""
	u, p = credentials()
	if not (u and p):
		control.okDialog(title='Easynews Usenet — test',
						 message='Fill in your Easynews username and password in Settings > Usenet first.')
		return
	cfg = nntp_config()
	lines = []
	try:
		t = time.time()
		conn = core.NNTPConn(cfg['host'], cfg['port'], cfg['user'], cfg['password'], timeout=15)
		lines.append('[COLOR ff00fa9a]Login OK[/COLOR] on %s:%d (%.1fs)' % (cfg['host'], cfg['port'], time.time() - t))
		ok_ctrl = None
		for group in ('alt.binaries.multimedia', 'alt.binaries.teevee'):
			code, line = conn.cmd('GROUP %s' % group)
			if code != 211: continue
			last = line.split()[2]
			code, line = conn.cmd('STAT %s' % last)
			mid = line.split()[-1] if code == 223 else ''
			ok_ctrl = (conn.stat(mid) == 223) if mid else False
			break
		conn.close()
		lines.append('Article lookup: %s' % ('[COLOR ff00fa9a]OK[/COLOR]' if ok_ctrl else '[COLOR ffff6666]could not verify[/COLOR]'))
	except core.NNTPAuthError as e:
		lines.append('[COLOR ffff6666]Login refused[/COLOR] (%s). Check the username/password, or your plan may not include NNTP access.' % e)
	except Exception as e:
		lines.append('[COLOR ffff6666]Could not connect[/COLOR]: %s: %s' % (type(e).__name__, e))
	port = _service_port()
	lines.append('Stream engine: %s' % (('[COLOR ff00fa9a]running on port %d[/COLOR]' % port) if port
										else '[COLOR ffff6666]not running — restart Kodi[/COLOR]'))
	control.okDialog(title='Easynews Usenet — test', message='\n'.join(lines))


def test_backup(slot=1):
	"""v2.0.32 (informe L7): accion de ajustes, prueba el proveedor de respaldo n.º slot."""
	b = backup_config(slot)
	title = 'Backup Usenet provider %d — test' % int(slot or 1)
	if not b:
		control.okDialog(title=title, message='Fill in the backup provider\'s server first.')
		return
	lines = []
	if b.get('port_typed'):
		lines.append('Port %d taken from the server field (the Port list is ignored).' % b['port'])
	try:
		t = time.time()
		conn = core.NNTPConn(b['host'], b['port'], b['user'], b['password'], timeout=15, use_ssl=b['ssl'])
		lines.append('[COLOR ff00fa9a]Login OK[/COLOR] on %s:%d%s (%.1fs)'
					 % (b['host'], b['port'], '' if b['ssl'] else ' without SSL', time.time() - t))
		conn.close()
		lines.append('It is asked only for the pieces Easynews no longer has, with up to %d connection%s.'
					 % (b['connections'], '' if b['connections'] == 1 else 's'))
	except core.NNTPTooMany as e:
		lines.append('[COLOR fffdb515]Login OK, but the provider allows no more connections right now[/COLOR] (%s).' % e)
	except core.NNTPAuthError as e:
		lines.append('[COLOR ffff6666]Login refused[/COLOR] (%s). Check the username and password.' % e)
	except Exception as e:
		lines.append('[COLOR ffff6666]Could not connect[/COLOR]: %s: %s' % (type(e).__name__, e))
	control.okDialog(title=title, message='\n'.join(lines))
