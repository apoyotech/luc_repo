# -*- coding: utf-8 -*-
"""
	luc_kodi Add-on
	WeTrakr integration module — cliente completo dentro del plugin.

	Quinto servicio de tracking del addon, junto a Trakt, SIMKL, MDBList y
	PunchPlay, y con el mismo principio: totalmente autonomo, sin depender de
	ninguno de los otros cuatro.

	API publica (beta): https://api.wetrakr.com   — documentacion en /#/
	  * SIN prefijo /api ni /v1: la version viaja en la cabecera
	    `wetrakr-api-version: 1`.
	  * TODA peticion lleva `wetrakr-api-key` (el client id de la app). Con
	    sesion, ademas `Authorization: Bearer`.

	AUTENTICACION — Device Flow (PIN + QR), igual que los otros cuatro:
	  POST /oauth/device/code     -> device_code, user_code, verification_url,
	                                 expires_in, interval
	  POST /oauth/device/token    -> access_token + refresh_token (polling)
	  POST /oauth/token/refresh   -> renovacion; el refresh ROTA en cada uso
	  POST /oauth/logout          -> revoca el refresh al desautorizar

	SIN client_secret, a proposito: los terminos de WeTrakr prohiben llevarlo
	en una app que instala el usuario y la documentacion lo reserva para un
	servidor propio. El Device Flow funciona solo con el client id, y un
	secret equivocado ademas QUEMA el codigo. En este modulo no hay, ni debe
	haber nunca, ningun secret.

	DIFERENCIAS con los otros servicios que hay que tener presentes:

	  1) IDS. El campo `id` es el id de WeTrakr, NO el de TMDb, y los dos
	     espacios de numeracion se solapan. Hacia WeTrakr solo se mandan
	     `ids.tmdb` / `ids.imdb` / `ids.tvdb`; de sus respuestas solo se leen
	     esos mismos `ids`, nunca `id`.

	  2) EL SERVIDOR DECIDE EL VISTO. `/scrobble/stop` con progreso >= 80
	     marca visto (201); por debajo lo deja en pausa reanudable (200). Un
	     `/scrobble/start` repetido sobre lo mismo solo mueve el progreso: es
	     como WeTrakr recibe un salto, y aqui sirve de latido. No hace falta
	     partir el stop en ramas como en SIMKL y MDBList.

	  3) TOKENS. Access de 7 dias y refresh de 180 que ROTA: el viejo muere
	     al emitirse el nuevo. Mismo almacen en window properties y misma
	     renovacion single-flight que punchplay.py, por la misma razon (el
	     settings.xml de disco va por detras de setSetting y releerlo tras una
	     renovacion devolveria el refresh muerto).

	  4) CUOTAS. 200 GET y 60 escrituras por minuto, y una cuota diaria en
	     fase de prueba. Sin token cuenta contra la clave de la APP, compartida
	     por todos los usuarios; con token, contra la de cada usuario. Por eso
	     todo lo que puede ir con token va con token, y un 429 bloquea las
	     peticiones durante el Retry-After en vez de insistir.

	PARSERS TOLERANTES: la documentacion fija rutas y parametros pero no el
	esquema exacto de cada fila. Cada lector acepta varias envolturas y alias,
	y cuando una respuesta no vacia da cero items se registra su FORMA (tipos y
	nombres de clave, nunca contenido) de forma incondicional.
"""

import hashlib
import json
import time
from threading import Lock

import requests

from resources.lib.modules import app_keys
from resources.lib.modules import control
from resources.lib.modules import log_utils

BASE_URL = 'https://api.wetrakr.com'
WEB_URL = 'https://wetrakr.com'
API_VERSION = '1'
APP_NAME = 'luc_kodi'
LOG_TAG = '[luc_kodi-wetrakr]'

# Puente de la app luc_kodi registrada en wetrakr.com/profile/settings/api.
# Viaja oculto pero funcional, igual que las demas credenciales de
# aplicacion; el usuario puede sustituirlo en Ajustes por el de su app.
DEFAULT_CLIENT_ID = app_keys.get('wetrakr')

getSetting = control.setting
setSetting = control.setSetting

_REFRESH_MARGIN = 6 * 3600  # el access dura 7 dias: se renueva con 6 h de margen
_refresh_lock = Lock()

_PROP_TOKEN = 'luc_kodi.wetrakr.tok'
_PROP_REFRESH = 'luc_kodi.wetrakr.ref'
_PROP_EXPIRES = 'luc_kodi.wetrakr.exp'
_PROP_REFRESH_DEAD = 'luc_kodi.wetrakr.refdead'
_PROP_REAUTH = 'luc_kodi.wetrakr.reauth'
_PROP_OUTAGE = 'luc_kodi.wetrakr.outage'
_PROP_BLOCKED = 'luc_kodi.wetrakr.blocked'
_PROP_QUOTA = 'luc_kodi.wetrakr.quota'
_PROP_MEDIA = 'luc_kodi.wetrakr.media'
_PROP_MISMATCH = 'luc_kodi.wetrakr.mismatch'
_PROP_ACTIVITY_CHECK = 'luc_kodi.wetrakr.actcheck'
_REFRESH_DEAD_COOLDOWN = 600
_OUTAGE_WINDOW = 300
_ACTIVITY_EVERY = 300

# Mismo techo que PunchPlay: lo practicamente terminado es historial.
PROGRESS_MAX_PCT = 98.0
# Umbral de visto del SERVIDOR (fijo en la API, no configurable).
WATCHED_PCT = 80.0

_last_error = {'msg': ''}


# ---------------------------------------------------------------------------
# Window properties y diagnostico
# ---------------------------------------------------------------------------

def _prop(name):
	try:
		return control.homeWindow.getProperty(name) or ''
	except Exception:
		return ''


def _set_prop(name, value):
	try:
		control.homeWindow.setProperty(name, str(value))
	except Exception:
		pass


def _clear_prop(name):
	try:
		control.homeWindow.clearProperty(name)
	except Exception:
		pass


def _recent(prop, window):
	mark = _prop(prop)
	if not mark:
		return False
	try:
		return (time.time() - float(mark)) < window
	except Exception:
		return False


def _hard_log(msg, level=2):
	"""Traza incondicional a kodi.log (log_utils.log depende de debug.enabled)."""
	try:
		import xbmc
		xbmc.log('%s %s' % (LOG_TAG, msg), level)
	except Exception:
		pass


def _dev_log(msg):
	try:
		if getSetting('dev.mode.enable') == 'true':
			_hard_log(msg, 1)
	except Exception:
		pass


def _shape(data, depth=0):
	"""Forma COMPACTA de una respuesta: tipos y nombres de clave, nunca valores."""
	try:
		if data is None:
			return 'None'
		if isinstance(data, list):
			s = 'list[%d]' % len(data)
			if data and depth < 2:
				s += ' -> ' + _shape(data[0], depth + 1)
			return s
		if isinstance(data, dict):
			keys = sorted(str(k) for k in data.keys())
			s = 'dict{%s}' % ', '.join(keys[:32])
			if len(keys) > 32:
				s += ', +%d' % (len(keys) - 32)
			return s
		return type(data).__name__
	except Exception:
		return '?'


def _log_shape(tag, data, extra=''):
	_hard_log('%s: 0 items parsed from %s %s' % (tag, _shape(data), extra), 3)


def _error_text(r):
	"""Mensaje de error de WeTrakr, en sus dos formas: `error` texto o
	`{error:{code,message}}`, mas `message` cuando viene aparte."""
	try:
		body = r.json()
	except Exception:
		try:
			return (r.text or '')[:200].replace('\n', ' ')
		except Exception:
			return ''
	if not isinstance(body, dict):
		return ''
	err = body.get('error')
	if isinstance(err, dict):
		return '%s %s' % (err.get('code') or '', err.get('message') or '')
	return '%s %s' % (err or '', body.get('message') or '')


def service_is_down():
	return _recent(_PROP_OUTAGE, _OUTAGE_WINDOW)


def _is_blocked():
	"""True mientras dure un 429: no se insiste contra el limite."""
	until = _prop(_PROP_BLOCKED)
	if not until:
		return False
	try:
		return time.time() < float(until)
	except Exception:
		return False


# ---------------------------------------------------------------------------
# Credenciales y tokens
# ---------------------------------------------------------------------------

def _client_id():
	"""Se lee en CADA llamada (reuselanguageinvoker conserva el modulo)."""
	cid = (getSetting('wetrakr.client_id') or '').strip()
	return cid or DEFAULT_CLIENT_ID


def _access_token():
	return (_prop(_PROP_TOKEN) or getSetting('wetrakr.token') or '').strip()


def _refresh_token():
	return (_prop(_PROP_REFRESH) or getSetting('wetrakr.refresh') or '').strip()


def getWeTrakrCredentialsInfo():
	tok = _access_token()
	return bool(tok and tok not in ('0', 'empty_setting'))


def getWeTrakrScrobbleInfo():
	if getSetting('wetrakr.scrobble') != 'true':
		return False
	return getWeTrakrCredentialsInfo()


def _client_version():
	try:
		return control.getluc_kodiVersion()
	except Exception:
		return '1.0.0'


def _store_tokens(data):
	"""El refresh ROTA: se guardan los dos juntos, primero en properties."""
	try:
		access = data.get('access_token')
		if not access:
			return False
		refresh = data.get('new_refresh_token') or data.get('refresh_token')
		try:
			expires_in = float(data.get('expires_in') or 604800)
		except Exception:
			expires_in = 604800
		expires_at = str(time.time() + expires_in)
		_set_prop(_PROP_TOKEN, access)
		if refresh:
			_set_prop(_PROP_REFRESH, refresh)
		_set_prop(_PROP_EXPIRES, expires_at)
		_clear_prop(_PROP_REFRESH_DEAD)
		setSetting('wetrakr.token', access)
		if refresh:
			setSetting('wetrakr.refresh', refresh)
		setSetting('wetrakr.expires', expires_at)
		setSetting('wetrakr.isauthed', 'true')
		return True
	except Exception:
		log_utils.error()
		return False


def _token_expired():
	expires = (_prop(_PROP_EXPIRES) or getSetting('wetrakr.expires') or '').strip()
	if not expires:
		return True
	try:
		return (float(expires) - time.time()) < _REFRESH_MARGIN
	except Exception:
		return True


def _base_headers(with_token=True):
	h = {
		'wetrakr-api-version': API_VERSION,
		'wetrakr-api-key': _client_id(),
		'Accept': 'application/json',
		'Content-Type': 'application/json',
		'User-Agent': '%s/%s' % (APP_NAME, _client_version()),
	}
	if with_token:
		tok = _access_token()
		if tok:
			h['Authorization'] = 'Bearer %s' % tok
	return h


def _mark_reauth_needed():
	"""Aviso de volver a autorizar, como maximo uno por hora."""
	try:
		if _recent(_PROP_REAUTH, 3600):
			return
		_set_prop(_PROP_REAUTH, time.time())
		setSetting('wetrakr.isauthed', 'false')
		control.notification(title='WeTrakr', message='Please re-authorize your WeTrakr account.')
	except Exception:
		pass


def _do_refresh_token():
	"""Renovacion real. SIEMPRE con _refresh_lock adquirido."""
	if _recent(_PROP_REFRESH_DEAD, _REFRESH_DEAD_COOLDOWN) or service_is_down():
		return False
	refresh = _refresh_token()
	if not refresh:
		return False
	try:
		r = requests.post(BASE_URL + '/oauth/token/refresh', json={'refresh_token': refresh},
						  headers=_base_headers(with_token=False), timeout=20)
	except Exception as e:
		_hard_log('POST /oauth/token/refresh FAILED: %s' % type(e).__name__, 3)
		_set_prop(_PROP_OUTAGE, time.time())
		return False
	if r.status_code >= 500:
		_hard_log('POST /oauth/token/refresh FAILED: HTTP %s (service down)' % r.status_code, 3)
		_set_prop(_PROP_OUTAGE, time.time())
		return False
	if r.status_code == 200:
		try:
			data = r.json()
		except Exception:
			data = {}
		if _store_tokens(data):
			_hard_log('token renewed', 1)
			return True
		return False
	_hard_log('POST /oauth/token/refresh FAILED: HTTP %s | %s' % (r.status_code, _error_text(r)), 3)
	# 401 = refresh muerto para siempre (rotado hace mas de un minuto, revocado
	# o caducado). Solo una autorizacion nueva lo arregla.
	if r.status_code in (400, 401, 403):
		_set_prop(_PROP_REFRESH_DEAD, time.time())
		_mark_reauth_needed()
	return False


def ensure_token():
	"""Refresco proactivo single-flight, con doble chequeo dentro del lock: dos
	renovaciones en paralelo se invalidan entre si porque el refresh rota."""
	if not getWeTrakrCredentialsInfo():
		return False
	if not _token_expired():
		return True
	with _refresh_lock:
		if not _token_expired():
			return True
		return _do_refresh_token()


# ---------------------------------------------------------------------------
# Transporte
# ---------------------------------------------------------------------------

def _request(method, path, json_data=None, params=None, timeout=15, auth=True,
			 _retry=True, full=False):
	"""Peticion a la API. auth: True (exige sesion), 'optional' (token si lo
	hay, si no solo la clave de app) o False.

	Devuelve el JSON ({} sin cuerpo) o None si fallo; con full=True devuelve
	(data, headers, status), y data puede ser None. Nunca lanza."""
	fail = (None, {}, 0) if full else None
	if auth is True and not getWeTrakrCredentialsInfo():
		return fail
	if not _client_id():
		_hard_log('missing client id', 3)
		return fail
	if _is_blocked():
		_dev_log('%s %s skipped: rate limited' % (method, path))
		return fail
	with_token = bool(auth) and getWeTrakrCredentialsInfo()
	if with_token:
		ensure_token()
	try:
		r = requests.request(method, BASE_URL + path, headers=_base_headers(with_token),
							 json=json_data, params=params, timeout=timeout)
	except Exception as e:
		_hard_log('%s %s FAILED: %s' % (method, path, type(e).__name__), 3)
		_set_prop(_PROP_OUTAGE, time.time())
		return fail

	try:
		q = r.headers.get('X-Quota-Remaining')
		if q is not None:
			_set_prop(_PROP_QUOTA, '%s/%s' % (q, r.headers.get('X-Quota-Limit') or '?'))
	except Exception:
		pass

	status = r.status_code
	if status == 429:
		try:
			wait = float(r.headers.get('Retry-After') or r.headers.get('RateLimit-Reset') or 60)
		except Exception:
			wait = 60
		wait = min(max(wait, 5), 3600)
		_set_prop(_PROP_BLOCKED, time.time() + wait)
		_hard_log('%s %s: HTTP 429 rate limited, pausing requests %ds | %s'
				  % (method, path, wait, _error_text(r)), 3)
		return fail
	if status >= 500:
		_hard_log('%s %s FAILED: HTTP %s' % (method, path, status), 3)
		_set_prop(_PROP_OUTAGE, time.time())
		return fail
	if status == 401 and with_token and _retry:
		with _refresh_lock:
			ok = _do_refresh_token()
		if ok:
			return _request(method, path, json_data=json_data, params=params, timeout=timeout,
							auth=auth, _retry=False, full=full)
		if auth is True:
			_mark_reauth_needed()
		return fail
	if status >= 400:
		msg = _error_text(r)
		_last_error['msg'] = msg.strip()
		# 420 = cuota del plan (lista bloqueada, tope de listas); 426 = funcion
		# solo VIP. No se reintentan: se registra el mensaje de WeTrakr.
		_hard_log('%s %s FAILED: HTTP %s | %s' % (method, path, status, msg), 3)
		if full:
			return None, r.headers, status
		return None
	_clear_prop(_PROP_OUTAGE)
	try:
		data = r.json()
	except Exception:
		data = {}
	_dev_log('%s %s -> %s %s' % (method, path, status, _shape(data)))
	if full:
		return data, r.headers, status
	return data


def _get(path, params=None, timeout=15, auth=True):
	return _request('GET', path, params=params, timeout=timeout, auth=auth)


_LIST_KEYS = ('items', 'results', 'data', 'lists', 'entries', 'likes', 'movies', 'shows', 'episodes')


def _unwrap(data, extra=()):
	if data is None:
		return []
	if isinstance(data, list):
		return data
	if not isinstance(data, dict):
		return []
	for k in tuple(extra) + _LIST_KEYS:
		v = data.get(k)
		if isinstance(v, list):
			return v
	lists = [v for v in data.values() if isinstance(v, list)]
	return lists[0] if len(lists) == 1 else []


def _get_pages(path, params=None, limit=100, max_pages=20, auth=True, extra=()):
	"""Pagina con page/limit y X-Pagination-Page-Count. None si la PRIMERA
	pagina falla, para distinguir 'error' de 'vacio'."""
	p = dict(params or {})
	p['limit'] = limit
	out, page = [], 1
	while page <= max_pages:
		p['page'] = page
		data, headers, status = _request('GET', path, params=p, timeout=20, auth=auth, full=True)
		if data is None:
			return out if page > 1 else None
		chunk = _unwrap(data, extra)
		out.extend(chunk)
		try:
			count = int(headers.get('X-Pagination-Page-Count') or 0)
		except Exception:
			count = 0
		if not chunk or (count and page >= count) or (not count and len(chunk) < limit):
			break
		page += 1
	if page > 1:
		_hard_log('%s read in %d pages (%d rows)' % (path, page, len(out)), 1)
	return out


# ---------------------------------------------------------------------------
# Lectura tolerante de filas
# ---------------------------------------------------------------------------

def _first(d, *keys):
	if not isinstance(d, dict):
		return ''
	for k in keys:
		v = d.get(k)
		if v not in (None, '', [], {}):
			return v
	return ''


def _int(v):
	try:
		return int(str(v).strip())
	except Exception:
		return None


def _ids_of(raw):
	"""(imdb, tmdb, tvdb) de `ids`. NUNCA se lee `id`: es el id de WeTrakr."""
	if not isinstance(raw, dict):
		return '', '', ''
	ids = raw.get('ids') if isinstance(raw.get('ids'), dict) else {}

	def val(k, *alts):
		v = ids.get(k)
		if isinstance(v, dict):
			v = v.get('id')
		if v in (None, ''):
			v = _first(raw, *alts)
		return str(v).strip() if v not in (None, '') else ''

	imdb = val('imdb', 'imdb_id')
	if imdb and not imdb.startswith('tt'):
		imdb = ''
	tmdb = val('tmdb', 'tmdb_id')
	tvdb = val('tvdb', 'tvdb_id')
	if tmdb and not tmdb.isdigit():
		tmdb = ''
	if tvdb and not tvdb.isdigit():
		tvdb = ''
	return imdb, tmdb, tvdb


def _kind(raw):
	k = str(_first(raw, 'type', 'media_type', 'target') or '').lower()
	if k in ('movies', 'film'):
		return 'movie'
	if k in ('shows', 'tv', 'tvshow', 'series'):
		return 'show'
	if k in ('episodes',):
		return 'episode'
	if k in ('seasons',):
		return 'season'
	return k


def _media_of(row):
	"""El objeto media de una fila, venga plano o envuelto."""
	if not isinstance(row, dict):
		return {}
	if isinstance(row.get('ids'), dict) or _kind(row) in ('movie', 'show', 'episode', 'season'):
		return row
	for k in ('media', 'item', 'movie', 'show', 'episode', 'title'):
		v = row.get(k)
		if isinstance(v, dict) and (isinstance(v.get('ids'), dict) or v.get('type')):
			return v
	return row


def _year_of(raw):
	y = _first(raw, 'year')
	if y:
		return str(y)[:4]
	d = str(_first(raw, 'release_date', 'first_air_date', 'released', 'air_date') or '')
	return d[:4] if len(d) >= 4 and d[:4].isdigit() else ''


def _title_of(raw):
	return str(_first(raw, 'title', 'name', 'original_title', 'original_name') or '')


def _item(raw, want):
	"""Fila -> forma minima del worker de movies/tvshows, o None."""
	m = _media_of(raw)
	k = _kind(m)
	if k and k != want:
		return None
	imdb, tmdb, tvdb = _ids_of(m)
	if not (tmdb or imdb):
		return None
	name = _title_of(m)
	values = {'next': '', 'imdb': imdb, 'tmdb': tmdb, 'tvdb': tvdb, 'title': name,
			  'originaltitle': name, 'year': _year_of(m), 'metacache': False}
	if want == 'show':
		values['tvshowtitle'] = name
	return values


def _items(rows, want, tag):
	out, seen = [], set()
	for r in (rows or []):
		try:
			v = _item(r, want)
			if not v:
				continue
			key = v['tmdb'] or v['imdb']
			if key in seen:
				continue
			seen.add(key)
			out.append(v)
		except Exception:
			log_utils.error()
	_hard_log('%s(%s): %d rows, %d titles' % (tag, want, len(rows or []), len(out)), 1)
	if rows and not out:
		_log_shape(tag, rows[0], 'want=%s' % want)
	return out


def _show_of(row, _depth=0):
	"""Bloque de la SERIE de una fila de episodio. Se busca tambien un nivel
	por debajo (`episode`, `media`, `item`): el historial puede anidarla."""
	if not isinstance(row, dict):
		return {}
	for k in ('show', 'tvshow', 'series'):
		v = row.get(k)
		if isinstance(v, dict):
			return v
	if isinstance(row.get('show_ids'), dict):
		return {'ids': row['show_ids'], 'title': row.get('show_title') or ''}
	if _depth == 0:
		for k in ('episode', 'media', 'item'):
			v = _show_of(row.get(k), 1)
			if v:
				return v
	return {}


def _episode_numbers(row):
	"""(temporada, episodio) de una fila de episodio, plana o anidada."""
	src = row
	for k in ('episode', 'next_episode', 'nextEpisode'):
		if isinstance(row.get(k), dict):
			src = row[k]
			break
	season = _int(_first(src, 'season_number', 'season', 'seasonNumber'))
	number = src.get('number') if isinstance(src, dict) else None
	if number in (None, '') or isinstance(number, dict):
		number = _first(src, 'episode_number', 'episodeNumber', 'episode')
	number = _int(number)
	return season, number


def _fill_show_ids(items):
	"""Rellena imdb/tvdb y el ANO de la SERIE desde TMDb cuando WeTrakr no los
	trae: sin IMDB ID casi ningun scraper encuentra fuentes (leccion de
	PunchPlay), y sin ano Bookmarks().get() no busca el punto de resume (sale
	con `if not year` y el episodio arranca desde cero). En las filas de
	episodio WeTrakr manda la serie como {id, title, ids}, sin fecha."""
	if not items:
		return items
	try:
		from resources.lib.indexers.tmdb import TVshows as tmdb_indexer
		from resources.lib.database import cache as _cache
	except Exception:
		return items
	resolved = {}
	for i in items:
		tmdb = i.get('tmdb')
		if not tmdb or (i.get('imdb') and i.get('tvdb') and i.get('year')):
			continue
		if tmdb not in resolved:
			try:
				meta = _cache.get(tmdb_indexer().get_showSeasons_meta, 96, tmdb, True) or {}
			except Exception:
				meta = {}
			resolved[tmdb] = (str(meta.get('imdb') or ''), str(meta.get('tvdb') or ''),
							  str(meta.get('year') or '')[:4])
		imdb, tvdb, year = resolved[tmdb]
		if imdb and not i.get('imdb'):
			i['imdb'] = imdb
		if tvdb and not i.get('tvdb'):
			i['tvdb'] = tvdb
		if year.isdigit() and not i.get('year'):
			i['year'] = year
	return items


# ---------------------------------------------------------------------------
# Autorizacion (Device Flow)
# ---------------------------------------------------------------------------

def _qr_remote_url(url):
	try:
		from urllib.parse import quote_plus
		return 'https://api.qrserver.com/v1/create-qr-code/?size=256x256&qzone=1&data=' + quote_plus(url)
	except Exception:
		return ''


def getDeviceCode():
	cid = _client_id()
	if not cid:
		_last_error['msg'] = 'missing client id'
		return None
	try:
		r = requests.post(BASE_URL + '/oauth/device/code', json={'client_id': cid},
						  headers=_base_headers(with_token=False), timeout=20)
	except Exception as e:
		_last_error['msg'] = 'Network error: %s' % type(e).__name__
		return None
	if r.status_code != 200:
		reasons = {401: 'the client ID is not a registered WeTrakr app',
				   423: 'the app is suspended by WeTrakr',
				   429: 'too many codes requested; wait 15 minutes and try again'}
		_last_error['msg'] = reasons.get(r.status_code) or 'HTTP %s %s' % (r.status_code, _error_text(r))
		_hard_log('POST /oauth/device/code FAILED: HTTP %s' % r.status_code, 3)
		return None
	try:
		return r.json()
	except Exception:
		_last_error['msg'] = 'invalid response'
		return None


def pollDeviceToken(device_data):
	device_code = device_data.get('device_code')
	user_code = device_data.get('user_code')
	if not device_code or not user_code:
		return None
	cid = _client_id()
	try:
		expires_in = int(device_data.get('expires_in') or 600)
	except Exception:
		expires_in = 600
	try:
		interval = max(int(device_data.get('interval') or 5), 1)
	except Exception:
		interval = 5
	verify = str(device_data.get('verification_url') or device_data.get('verification_uri') or WEB_URL)
	verify_full = str(device_data.get('verification_url_complete')
					  or device_data.get('verification_uri_complete') or verify)
	verify_short = verify.replace('https://', '').replace('http://', '').rstrip('/')
	qr_icon = _qr_remote_url(verify_full)
	try:
		from resources.lib.modules.source_utils import copy2clip
		copy2clip(verify_full)
	except Exception:
		pass
	try:
		control.notification(title='WeTrakr', message='%s  |  %s' % (verify_short, user_code),
							 icon=qr_icon, time=15000)
	except Exception:
		pass
	progressDialog = control.progressDialog
	progressDialog.create('WeTrakr authorization')
	line = ('[B]Visit:[/B] %s\n[B]Enter code:[/B] %s\n'
			'OR scan the QR  ·  link copied to clipboard\n\nWaiting for authorization...'
			% (verify_short, user_code))
	try:
		progressDialog.update(0, line)
	except Exception:
		pass
	elapsed, next_poll, token = 0, interval, None
	while True:
		if progressDialog.iscanceled():
			break
		if elapsed >= expires_in:
			control.notification(title='WeTrakr', message='Code expired, please try again.')
			break
		control.sleep(1000)
		elapsed += 1
		try:
			progressDialog.update(int(elapsed * 100.0 / expires_in))
		except Exception:
			pass
		if elapsed < next_poll:
			continue
		next_poll = elapsed + interval
		try:
			r = requests.post(BASE_URL + '/oauth/device/token',
							  json={'code': device_code, 'device_code': device_code, 'client_id': cid},
							  headers=_base_headers(with_token=False), timeout=20)
		except Exception:
			continue
		if r.status_code == 200:
			try:
				token = r.json()
			except Exception:
				token = None
			break
		if r.status_code == 400 and 'authorization_pending' in _error_text(r):
			continue
		if r.status_code == 429:
			interval += 5
			next_poll = elapsed + interval
			continue
		msgs = {410: 'Code expired, please try again.', 418: 'Access denied on WeTrakr.',
				409: 'Code already used, please try again.'}
		_hard_log('POST /oauth/device/token: HTTP %s | %s' % (r.status_code, _error_text(r)), 3)
		control.notification(title='WeTrakr', message=msgs.get(r.status_code, 'Authorization failed.'))
		break
	try:
		progressDialog.close()
	except Exception:
		pass
	return token


def getUserInfo():
	"""GET /account/settings — id, info.username y plan de la cuenta."""
	return _get('/account/settings')


def _username_of(info):
	if not isinstance(info, dict):
		return ''
	sub = info.get('info') if isinstance(info.get('info'), dict) else {}
	return str(_first(sub, 'username', 'display_name') or _first(info, 'username', 'name') or '')


def authenticate():
	if not _client_id():
		control.dialog.ok('WeTrakr', 'Missing client ID.')
		return False
	device_data = getDeviceCode()
	if not device_data or not device_data.get('user_code'):
		control.dialog.ok('WeTrakr — could not start',
						  'Could not get the authorization code.\n\n[B]Reason:[/B] %s'
						  % (_last_error.get('msg') or 'unknown'))
		return False
	token = pollDeviceToken(device_data)
	if not token or not _store_tokens(token):
		control.notification(title='WeTrakr', message='Authorization canceled.')
		return False
	_clear_prop(_PROP_REAUTH)
	_clear_prop(_PROP_BLOCKED)
	info = getUserInfo() or {}
	username = _username_of(info) or 'WeTrakr User'
	try:
		setSetting('wetrakr.username', username)
		if info.get('id'):
			setSetting('wetrakr.user_id', str(info.get('id')))
		if info.get('plan'):
			setSetting('wetrakr.plan', str(info.get('plan')))
	except Exception:
		pass
	invalidateSectionCaches(account_change=True)
	control.notification(title='WeTrakr', message='Account authorized: %s' % username)
	return True


def auth():
	authenticate()


def deauth():
	"""Revoca el refresh en WeTrakr (sus terminos piden cerrar la sesion y
	borrar los datos del usuario al desconectar) y limpia todo lo local."""
	try:
		refresh, access = _refresh_token(), _access_token()
		if refresh and access:
			try:
				requests.post(BASE_URL + '/oauth/logout', json={'refresh_token': refresh},
							  headers=_base_headers(with_token=True), timeout=10)
			except Exception:
				pass
		for k in ('wetrakr.token', 'wetrakr.refresh', 'wetrakr.expires', 'wetrakr.username',
				  'wetrakr.user_id', 'wetrakr.plan', 'wetrakr.activity'):
			setSetting(k, '')
		setSetting('wetrakr.isauthed', 'false')
		setSetting('wetrakr.scrobble', 'false')
		for p in (_PROP_TOKEN, _PROP_REFRESH, _PROP_EXPIRES, _PROP_REFRESH_DEAD, _PROP_REAUTH,
				  _PROP_BLOCKED, _PROP_QUOTA, _PROP_MEDIA, _PROP_MISMATCH, _PROP_ACTIVITY_CHECK):
			_clear_prop(p)
		invalidateSectionCaches(account_change=True)
		control.notification(title='WeTrakr', message='Deauthorized')
	except Exception:
		log_utils.error()


def account_info_to_dialog():
	info = getUserInfo()
	if not info:
		if service_is_down():
			control.dialog.ok('WeTrakr', 'WeTrakr is not responding right now.\n\n'
							  'This is the service being unavailable, not a problem with your account.')
		elif getWeTrakrCredentialsInfo():
			control.dialog.ok('WeTrakr', 'Your WeTrakr session has expired and could not be renewed.\n\n'
							  'Use [B]Authorize[/B] to sign in again (PIN + QR).')
		else:
			control.dialog.ok('WeTrakr', 'Not authorized yet. Use Authorize (PIN + QR).')
		return
	expires = (_prop(_PROP_EXPIRES) or getSetting('wetrakr.expires') or '').strip()
	try:
		hours = max(int((float(expires) - time.time()) / 3600), 0)
		expires_txt = '%d d %d h' % (hours // 24, hours % 24)
	except Exception:
		expires_txt = '?'
	plan = str(info.get('plan') or getSetting('wetrakr.plan') or '?')
	quota = _prop(_PROP_QUOTA) or '?'
	lines = ('[B]User:[/B] %s\n[B]Plan:[/B] %s\n[B]Requests left today:[/B] %s\n'
			 '[B]Access token renews in:[/B] %s') % (_username_of(info) or '?', plan, quota, expires_txt)
	control.dialog.ok('WeTrakr account', lines)


# ---------------------------------------------------------------------------
# Scrobble en vivo
# ---------------------------------------------------------------------------

def _remember_media(title, year):
	if title:
		_set_prop(_PROP_MEDIA, '%s\n%s' % (title, year or ''))


def _recall_media():
	raw = _prop(_PROP_MEDIA)
	if not raw:
		return '', ''
	parts = raw.split('\n')
	return parts[0], (parts[1] if len(parts) > 1 else '')


def _has(v):
	return v not in (None, '', 'None', '0', 0)


def _scrobble_body(imdb=None, tmdb=None, tvdb=None, season=None, episode=None,
				   watched_percent=0, title=None, year=None):
	"""Cuerpo de start/pause/stop. Pelicula O serie+episodio, nunca ambos.
	Se mandan juntos los ids que existan: imdb, tmdb y tvdb de la SERIE para
	un episodio (el addon guarda los de la serie en self.imdb/tmdb/tvdb)."""
	ids = {}
	if _has(tmdb) and _int(tmdb):
		ids['tmdb'] = _int(tmdb)
	if imdb and str(imdb).startswith('tt'):
		ids['imdb'] = str(imdb)
	if _has(tvdb) and _int(tvdb):
		ids['tvdb'] = _int(tvdb)
	if not ids:
		return None
	if not title:
		title, y = _recall_media()
		year = year or y
	node = {'ids': ids}
	if title:
		node['title'] = str(title)
	if year and _int(str(year)[:4]):
		node['year'] = _int(str(year)[:4])
	is_episode = season not in (None, '', 'None') and episode not in (None, '', 'None')
	if is_episode:
		if _int(season) is None or _int(episode) is None:
			return None
		body = {'show': node, 'episode': {'season': _int(season), 'number': _int(episode)}}
	else:
		if 'tmdb' in ids or 'imdb' in ids:
			ids.pop('tvdb', None)
		body = {'movie': node}
	try:
		pct = float(watched_percent or 0)
	except Exception:
		pct = 0.0
	body['progress'] = round(min(max(pct, 0.01), 100.0), 2)
	body['app_version'] = _client_version()
	return body


def _desc(body):
	if 'episode' in body:
		return 'episode S%sE%s' % (body['episode'].get('season'), body['episode'].get('number'))
	return 'movie'


def _scrobble_post(action, body, notify=False):
	"""POST /scrobble/{action}. True si WeTrakr lo acepto."""
	if not body:
		_hard_log('scrobble/%s skipped: no usable ids' % action, 3)
		return False
	if 'episode' in body and _prop(_PROP_MISMATCH) == _mismatch_key(body):
		_hard_log('scrobble/%s skipped: WeTrakr matched another episode at start' % action, 2)
		return False
	data, headers, status = _request('POST', '/scrobble/%s' % action, json_data=body,
									 timeout=20, full=True)
	if data is None:
		if status == 404:
			_hard_log('scrobble/%s: %s not found on WeTrakr (ids %s)' % (action, _desc(body),
					  ','.join(sorted((body.get('movie') or body.get('show') or {}).get('ids', {}).keys()))), 3)
		else:
			_hard_log('scrobble/%s FAILED (%s progress=%s)' % (action, _desc(body), body.get('progress')), 3)
		return False
	if isinstance(data, dict) and data.get('ignored') is True:
		_hard_log('scrobble/%s ignored by WeTrakr: %s' % (action, data.get('reason') or '?'), 2)
		return True
	_hard_log('scrobble/%s OK (HTTP %s, %s, action=%s, progress=%s)'
			  % (action, status, _desc(body), (data or {}).get('action') if isinstance(data, dict) else '?',
				 body.get('progress')), 1)
	if action == 'start' and 'episode' in body:
		_check_episode_echo(body, data)
	if notify and getSetting('wetrakr.scrobble.notify') == 'true':
		try:
			control.notification(title='WeTrakr', message='Scrobble started')
		except Exception:
			pass
	return True


def _mismatch_key(body):
	try:
		ids = body['show']['ids']
		return '%s|%s|%s' % (ids.get('tmdb') or ids.get('imdb') or ids.get('tvdb'),
							 body['episode']['season'], body['episode']['number'])
	except Exception:
		return ''


def _check_episode_echo(body, data):
	"""WeTrakr devuelve el episodio que ha resuelto. Si no es el que se mando
	(numeracion absoluta frente a por temporadas, tipico del anime), se cancela
	la sesion sin registrar nada: es preferible no marcar a marcar otro."""
	try:
		ep = data.get('episode') if isinstance(data, dict) else None
		if not isinstance(ep, dict):
			return
		s = _int(_first(ep, 'season_number', 'season'))
		n = _int(ep.get('number'))
		if s is None or n is None:
			return
		if (s, n) == (body['episode']['season'], body['episode']['number']):
			return
		_hard_log('start matched S%sE%s instead of S%sE%s: session cancelled, no play logged'
				  % (s, n, body['episode']['season'], body['episode']['number']), 3)
		_request('DELETE', '/scrobble/playing', json_data={k: body[k] for k in ('show', 'episode')},
				 timeout=15)
		_set_prop(_PROP_MISMATCH, _mismatch_key(body))
		control.notification(title='WeTrakr', message='Episode numbering differs on WeTrakr; not tracked')
	except Exception:
		log_utils.error()


def scrobbleStart(imdb=None, tmdb=None, tvdb=None, season=None, episode=None,
				  watched_percent=0, title=None, year=None):
	"""Arranque: pone "viendo ahora" con el progreso real (el resume incluido)."""
	_clear_prop(_PROP_MISMATCH)
	_remember_media(title, year)
	body = _scrobble_body(imdb, tmdb, tvdb, season, episode, watched_percent, title, year)
	return _scrobble_post('start', body, notify=True)


def scrobbleProgress(imdb=None, tmdb=None, tvdb=None, season=None, episode=None,
					 watched_percent=0, title=None, year=None):
	"""Latido: un `start` repetido solo mueve el progreso (es como WeTrakr
	recibe un salto). NO es `pause`: la web pasaria a "en pausa"."""
	body = _scrobble_body(imdb, tmdb, tvdb, season, episode, watched_percent, title, year)
	return _scrobble_post('start', body)


def scrobblePause(imdb=None, tmdb=None, tvdb=None, season=None, episode=None,
				  watched_percent=0, title=None, year=None):
	body = _scrobble_body(imdb, tmdb, tvdb, season, episode, watched_percent, title, year)
	return _scrobble_post('pause', body)


def scrobbleResume(imdb=None, tmdb=None, tvdb=None, season=None, episode=None,
				   watched_percent=0, title=None, year=None):
	"""WeTrakr no tiene `resume`: lo documentado es volver a mandar `start`."""
	body = _scrobble_body(imdb, tmdb, tvdb, season, episode, watched_percent, title, year)
	return _scrobble_post('start', body)


def scrobbleStop(imdb=None, tmdb=None, tvdb=None, season=None, episode=None,
				 watched_percent=100, title=None, year=None):
	"""Una sola llamada: el servidor decide (>= 80 visto, < 80 pausa)."""
	body = _scrobble_body(imdb, tmdb, tvdb, season, episode, watched_percent, title, year)
	ok = _scrobble_post('stop', body)
	_clear_prop(_PROP_MEDIA)
	invalidateSectionCaches()
	return ok


# ---------------------------------------------------------------------------
# Progreso
# ---------------------------------------------------------------------------

def _playing_rows():
	rows = _get_pages('/sync/tracking/playing/all', max_pages=5)
	if rows is None:
		movies = _get_pages('/sync/tracking/playing/movies', max_pages=5) or []
		episodes = _get_pages('/sync/tracking/playing/episodes', max_pages=5) or []
		rows = movies + episodes
	return rows or []


def _playback_of(row):
	pb = row.get('playback') if isinstance(row.get('playback'), dict) else row
	try:
		pct = float(_first(pb, 'progress_percent', 'progress') or 0)
	except Exception:
		pct = 0.0
	try:
		dur = float(_first(pb, 'runtime_seconds', 'duration_seconds') or 0)
	except Exception:
		dur = 0.0
	if not dur:
		try:
			dur = float(_first(_media_of(row), 'runtime') or 0) * 60
		except Exception:
			dur = 0.0
	return pct, dur, str(_first(pb, 'tracked_at', 'updated_at', 'paused_at') or '')


def getMoviesProgress():
	rows = _playing_rows()
	out = []
	for r in rows:
		try:
			m = _media_of(r)
			if _kind(m) not in ('movie', ''):
				continue
			if _kind(m) == '' and _show_of(r):
				continue
			v = _item(r, 'movie')
			if not v:
				continue
			pct, dur, at = _playback_of(r)
			if pct <= 0 or pct >= PROGRESS_MAX_PCT:
				continue
			v.update({'progress': pct, 'duration': dur, 'paused_at': at})
			out.append(v)
		except Exception:
			log_utils.error()
	_hard_log('moviesProgress: %d playing rows, %d movies' % (len(rows), len(out)), 1)
	return sorted(out, key=lambda k: k.get('paused_at', ''), reverse=True)


def getEpisodesProgress():
	rows = _playing_rows()
	out = []
	for r in rows:
		try:
			m = _media_of(r)
			show = _show_of(r) or _show_of(m)
			if _kind(m) == 'movie' or not show:
				continue
			imdb, tmdb, tvdb = _ids_of(show)
			season, number = _episode_numbers(m)
			if not (tmdb or imdb) or season is None or not number:
				_log_shape('episodesProgress', r)
				continue
			pct, dur, at = _playback_of(r)
			if pct <= 0 or pct >= PROGRESS_MAX_PCT:
				continue
			title = _title_of(show)
			out.append({'next': '', 'imdb': imdb, 'tmdb': tmdb, 'tvdb': tvdb, 'title': title,
						'originaltitle': title, 'tvshowtitle': title, 'year': _year_of(show),
						'season': season, 'episode': number, 'progress': pct, 'duration': dur,
						'paused_at': at, 'metacache': False})
		except Exception:
			log_utils.error()
	_hard_log('episodesProgress: %d playing rows, %d episodes' % (len(rows), len(out)), 1)
	if rows and not out:
		kinds = {}
		for r in rows:
			k = _kind(_media_of(r)) or '?'
			kinds[k] = kinds.get(k, 0) + 1
		other = [r for r in rows if _kind(_media_of(r)) != 'movie']
		_hard_log('episodesProgress kinds %s | first non-movie row: %s' % (kinds, ', '.join(
			'%s=%s' % (k, _shape(v)) for k, v in sorted(other[0].items())) if other and isinstance(other[0], dict) else 'none'), 2)
	return sorted(_fill_show_ids(out), key=lambda k: k.get('paused_at', ''), reverse=True)


def getWatchingShows():
	"""Siguiente episodio por serie en curso.

	La lista `watching` dice QUE series van a medias pero no por donde. Si la
	fila trae el siguiente episodio se usa; si no, se toma el ultimo visto de
	cada serie desde el historial de episodios y el siguiente se resuelve con
	next_episode.resolve(), el mismo que usa el popup de PlayNext (respeta
	emitidos, fin de temporada y fin de serie)."""
	shows = _get_pages('/sync/tracking/watching/shows', max_pages=10)
	if not shows:
		return []
	last = {}
	history = _get_pages('/sync/tracking/watched/history/episodes', max_pages=10) or []
	parsed = 0
	for h in history:
		try:
			imdb, tmdb, tvdb = _ids_of(_show_of(h))
			s, n = _episode_numbers(h)
			if not tmdb or s is None or not n or s < 1:
				continue
			parsed += 1
			if (s, n) > last.get(tmdb, (0, 0)):
				last[tmdb] = (s, n)
		except Exception:
			pass
	try:
		from resources.lib.modules import next_episode as _ne
	except Exception:
		_ne = None
	out = []
	for row in shows:
		try:
			show = _media_of(row)
			imdb, tmdb, tvdb = _ids_of(show)
			if not tmdb:
				continue
			s = n = None
			nxt, lst = _progress_episodes(row)
			if nxt:
				s, n = nxt
			elif _ne and (lst or tmdb in last):
				ls, ln = max(lst or (0, 0), last.get(tmdb, (0, 0)))
				state, ns, nn = _ne.resolve(tmdb, ls, ln)
				if state in (_ne.UNAIRED, _ne.ENDED):
					continue
				s, n = _int(ns), _int(nn)
			if s is None or not n:
				continue
			title = _title_of(show)
			out.append({'next': '', 'imdb': imdb, 'tmdb': tmdb, 'tvdb': tvdb, 'title': title,
						'originaltitle': title, 'tvshowtitle': title, 'year': _year_of(show),
						'season': s, 'episode': n, 'metacache': False})
		except Exception:
			log_utils.error()
	_hard_log('nextEpisodes: %d shows watching, %d history rows (%d parsed, %d shows), %d with a next episode'
			  % (len(shows), len(history), parsed, len(last), len(out)), 1)
	if not out:
		# Sin siguiente episodio para NINGUNA serie: puede ser real (todas al
		# dia o sin emitir) o una forma de fila que no se reconoce. Se deja la
		# forma de las dos fuentes para poder distinguirlo con el log.
		_hard_log('nextEpisodes shapes: watching=%s | history=%s'
				  % (_shape(shows[0]), _shape(history[0]) if history else 'empty'), 2)
		if history and not parsed:
			h0 = history[0]
			_hard_log('nextEpisodes history row: %s' % ', '.join(
				'%s=%s' % (k, _shape(v)) for k, v in sorted(h0.items())) if isinstance(h0, dict) else '?', 2)
	return _fill_show_ids(out)


def _progress_episodes(row):
	"""((s, n) siguiente, (s, n) ultimo) que traiga la propia fila de la
	serie, bajo cualquier clave que hable de `next` o de `last`."""
	nxt = lst = None
	if not isinstance(row, dict):
		return nxt, lst
	for k, v in row.items():
		if not isinstance(v, dict):
			continue
		key = str(k).lower()
		if 'next' not in key and 'last' not in key:
			continue
		s, n = _episode_numbers({'episode': v})
		if s is None or not n:
			continue
		if 'next' in key and not nxt:
			nxt = (s, n)
		elif 'last' in key and not lst:
			lst = (s, n)
	return nxt, lst


# ---------------------------------------------------------------------------
# Watchlist, favoritos, ratings, historial
# ---------------------------------------------------------------------------

def _target(media_type):
	return 'shows' if media_type in ('show', 'tvshow', 'tv') else 'movies'


def _want(media_type):
	return 'show' if media_type in ('show', 'tvshow', 'tv') else 'movie'


def getWatchlistFor(media_type):
	"""Watchlist = lista `planning` de WeTrakr."""
	rows = _get_pages('/sync/tracking/planning/%s' % _target(media_type), max_pages=30)
	return _items(rows, _want(media_type), 'watchlist')


def getWatchedFor(media_type):
	rows = _get_pages('/sync/tracking/watched/%s' % _target(media_type),
					  params={'sort_by': 'my_last_watched'}, max_pages=30)
	return _items(rows, _want(media_type), 'watched')


def getHistory():
	"""Peliculas vistas, una fila por reproduccion (se dedupe por titulo)."""
	rows = _get_pages('/sync/tracking/watched/history/movies', max_pages=10)
	return _items(rows, 'movie', 'history')


def getFavoritesFor(media_type):
	rows = _get_pages('/sync/favorites/%s' % _target(media_type), max_pages=30)
	return _items(rows, _want(media_type), 'favorites')


def getRatingsFor(media_type):
	rows = _get_pages('/sync/ratings/%s' % _target(media_type), max_pages=30)
	return _items(rows, _want(media_type), 'ratings')


# ---------------------------------------------------------------------------
# Listas
# ---------------------------------------------------------------------------

def _list_summary(raw, src):
	if not isinstance(raw, dict):
		return None
	lst = raw.get('list') if isinstance(raw.get('list'), dict) else raw
	list_id = _first(lst, 'id', 'list_id')
	if list_id in ('', None):
		return None
	count = _first(lst, 'items_count', 'item_count', 'items_total', 'total_items', 'count')
	if count in ('', None) and isinstance(lst.get('counters'), dict):
		count = _first(lst['counters'], 'items', 'all', 'total')
	if count in ('', None) and isinstance(lst.get('items'), int):
		count = lst.get('items')
	owner = lst.get('user') or lst.get('owner')
	if isinstance(owner, dict):
		owner = _username_of(owner) or _first(owner, 'username', 'name')
	return {'id': str(list_id), 'name': str(_first(lst, 'name', 'title') or '?'),
			'items': count if count not in ('', None) else '?', 'owner': str(owner or ''),
			'privacy': str(lst.get('privacy') or ''), 'locked': bool(lst.get('locked')),
			'locked_reason': str(lst.get('locked_reason') or ''), 'src': src}


def _summaries(rows, src, tag):
	out = [s for s in (_list_summary(r, src) for r in (rows or [])) if s]
	if rows and not out:
		_log_shape(tag, rows[0])
	return out


def getUserLists():
	return _summaries(_unwrap(_get('/sync/lists', params={'sort': 'manual'})), 'own', 'userLists')


def getLikedLists():
	rows = _get_pages('/sync/likes/lists', max_pages=10)
	return _summaries(rows, 'public', 'likedLists')


def getFollowedLists():
	"""Leer listas seguidas es VIP: en una cuenta gratuita llegan todas con
	locked y locked_reason 'followed'."""
	return _summaries(_unwrap(_get('/sync/lists/followed')), 'public', 'followedLists')


def getTrendingLists():
	return _summaries(_unwrap(_get('/lists/trending', params={'limit': 20}, auth='optional')),
					  'public', 'trendingLists')


def getListItems(list_id, media_type='movie', src='own', stamp=''):
	"""`stamp` no se usa dentro: forma parte de la clave de cache. Es la firma
	de /sync/last_activities, asi que un cambio en la cuenta abre una entrada
	nueva y la lista no sale vieja hasta 6 h (por id no se pueden invalidar)."""
	if not list_id:
		return []
	want = _want(media_type)
	rows = None
	if src == 'own':
		rows = _get_pages('/sync/lists/%s/items' % list_id, max_pages=30)
	if rows is None:
		rows = _get_pages('/lists/%s/items/%s' % (list_id, _target(media_type)),
						  auth='optional', max_pages=30)
	if rows is None and _last_error.get('msg'):
		control.notification(title='WeTrakr', message=_last_error['msg'][:120] or 'List unavailable')
	return _items(rows or [], want, 'listItems %s' % list_id)


# ---------------------------------------------------------------------------
# Calendario personal
# ---------------------------------------------------------------------------

def _tz_name():
	"""Huso IANA para agrupar los dias. Kodi no expone el nombre IANA, asi que
	se usa el desfase local como Etc/GMT (con el signo invertido, que es como
	lo define la base IANA). Con desfase no entero se omite y van dias UTC."""
	try:
		off = -time.altzone if (time.daylight and time.localtime().tm_isdst) else -time.timezone
		if off % 3600:
			return ''
		h = off // 3600
		return 'UTC' if h == 0 else 'Etc/GMT%+d' % (-h)
	except Exception:
		return ''


def _calendar_days(data):
	"""{fecha: [entradas]} de la respuesta, venga como venga envuelta."""
	if not isinstance(data, dict):
		return {}
	for k in ('days', 'calendar', 'dates', 'data'):
		v = data.get(k)
		if isinstance(v, dict):
			data = v
			break
		if isinstance(v, list):
			out = {}
			for d in v:
				if isinstance(d, dict):
					out[str(d.get('date') or '')] = _unwrap(d, ('episodes', 'movies', 'items'))
			return out
	return {k: (_unwrap(v, ('episodes', 'movies', 'items')) if isinstance(v, dict) else v)
			for k, v in data.items()
			if isinstance(k, str) and len(k) == 10 and k[4] == '-' and isinstance(v, (list, dict))}


def _empty_calendar(data):
	"""Ventana sin estrenos: WeTrakr devuelve solo {total: 0}. No es un error."""
	try:
		return isinstance(data, dict) and int(data.get('total', -1)) == 0
	except Exception:
		return False


def _window(back, span=30):
	from datetime import date, timedelta
	start = date.today() - timedelta(days=back)
	return start.isoformat(), (start + timedelta(days=span)).isoformat()


def getCalendarEpisodes():
	start, end = _window(7)
	params = {'mode': 'following', 'start': start, 'end': end, 'sort': 'air_time'}
	tz = _tz_name()
	if tz:
		params['tz'] = tz
	data = _get('/calendar/shows', params=params, timeout=20)
	days = _calendar_days(data)
	if data and not days and not _empty_calendar(data):
		_log_shape('calendarShows', data)
	out, seen = [], set()
	for day, entries in sorted(days.items()):
		for e in (entries or []):
			try:
				show = _show_of(e)
				imdb, tmdb, tvdb = _ids_of(show)
				s, n = _episode_numbers(e)
				if not (tmdb or imdb) or not s or not n:
					continue
				key = (tmdb or imdb, s, n)
				if key in seen:
					continue
				seen.add(key)
				title = _title_of(show)
				out.append({'next': '', 'imdb': imdb, 'tmdb': tmdb, 'tvdb': tvdb, 'title': title,
							'originaltitle': title, 'tvshowtitle': title, 'year': _year_of(show),
							'season': s, 'episode': n, 'premiered': day, 'metacache': False})
			except Exception:
				continue
	_hard_log('calendarShows: %d episodes %s..%s' % (len(out), start, end), 1)
	return sorted(_fill_show_ids(out), key=lambda k: k.get('premiered', ''))


def getCalendarMovies():
	start, end = _window(14)
	data = _get('/calendar/movies', params={'mode': 'following', 'start': start, 'end': end},
				timeout=20)
	days = _calendar_days(data)
	if data and not days and not _empty_calendar(data):
		_log_shape('calendarMovies', data)
	rows = []
	for day, entries in sorted(days.items()):
		rows.extend(entries or [])
	return _items(rows, 'movie', 'calendarMovies')


# ---------------------------------------------------------------------------
# Catalogo (Discover) para las entradas de Movies y TV Shows
# ---------------------------------------------------------------------------

def wetrakr_list(url):
	"""Lee un endpoint de Discover. `url` llega completa desde movies.py y
	tvshows.py para que la cache la use de clave. Va con el token del usuario
	si lo hay: asi cuenta contra su cuota y no contra la de la app."""
	if not url or BASE_URL not in url:
		return []
	try:
		path = url.split(BASE_URL, 1)[1]
		params = {}
		if '?' in path:
			path, qs = path.split('?', 1)
			for pair in qs.split('&'):
				if '=' in pair:
					k, v = pair.split('=', 1)
					params[k] = v
		want = 'show' if params.get('filter_type') == 'show' else 'movie'
		auth = True if path.startswith('/discover/recommended') else 'optional'
		data = _get(path, params=params, timeout=20, auth=auth)
	except Exception:
		log_utils.error()
		return []
	rows = _unwrap(data, (_target(want),))
	if data and not rows:
		_log_shape('wetrakr_list', data, url)
	return _items(rows, want, 'discover')


# ---------------------------------------------------------------------------
# Caches
# ---------------------------------------------------------------------------

_CACHE_VERSION_SETTING = 'wetrakr._cache_bust_version'


def bust_caches_on_version_change():
	try:
		current = _client_version()
		if (getSetting(_CACHE_VERSION_SETTING) or '') == current:
			return
		invalidateSectionCaches(account_change=True)
		setSetting(_CACHE_VERSION_SETTING, current)
	except Exception:
		log_utils.error()


def refresh_if_changed():
	"""Consulta /sync/last_activities como mucho cada 5 minutos y, si algo se
	movio en la cuenta (desde la web, el movil u otro aparato), invalida las
	caches. Es lo que pide WeTrakr en vez de releer listas completas."""
	if not getWeTrakrCredentialsInfo() or _recent(_PROP_ACTIVITY_CHECK, _ACTIVITY_EVERY):
		return
	_set_prop(_PROP_ACTIVITY_CHECK, time.time())
	data = _get('/sync/last_activities')
	if not isinstance(data, dict):
		return
	try:
		stamp = {k: v for k, v in data.items() if 'visible' not in str(k)}
		# md5 y no hash(): hash() cambia de semilla en cada proceso de Kodi.
		sig = hashlib.md5(json.dumps(stamp, sort_keys=True, default=str).encode('utf-8')).hexdigest()
		if sig != (getSetting('wetrakr.activity') or ''):
			invalidateSectionCaches()
			setSetting('wetrakr.activity', sig)
			_hard_log('account activity changed: caches refreshed', 1)
	except Exception:
		log_utils.error()


def invalidateSectionCaches(account_change=False):
	"""La clave de cache es funcion + argumentos: hay que pasar cada tipo."""
	try:
		from resources.lib.database import cache
		targets = [(getMoviesProgress, ()), (getEpisodesProgress, ()), (getWatchingShows, ()),
				   (getCalendarEpisodes, ()), (getCalendarMovies, ()), (getHistory, ()),
				   (getUserLists, ()), (getLikedLists, ()), (getFollowedLists, ())]
		for fn in (getWatchlistFor, getWatchedFor, getFavoritesFor, getRatingsFor):
			targets += [(fn, ('movie',)), (fn, ('show',))]
		if account_change:
			targets.append((getTrendingLists, ()))
		try:
			targets += [(getRatingValues, ('movie',)), (getRatingValues, ('show',))]
		except NameError:
			pass
		for fn, args in targets:
			try:
				cache.remove(fn, *args)
			except Exception:
				pass
	except Exception:
		pass


def force_wetrakrSync(silent_confirm=False):
	try:
		if not getWeTrakrCredentialsInfo():
			control.notification(title='WeTrakr', message='Not authorized.')
			return
		invalidateSectionCaches(account_change=True)
		_clear_prop(_PROP_ACTIVITY_CHECK)
		info = getUserInfo()
		if info is None:
			control.notification(title='WeTrakr', message='WeTrakr is unavailable right now'
								 if service_is_down() else 'Sync failed — see kodi.log')
			return
		if not silent_confirm:
			control.notification(title='WeTrakr', message='Sync complete')
	except Exception:
		log_utils.error()


# ---------------------------------------------------------------------------
# WeTrakr Manager (menu contextual)
# ---------------------------------------------------------------------------
#
# Mismo papel que el Trakt Manager: gestionar un titulo desde su ficha sin
# salir del plugin. Escribe con el documento de lote de /sync/tracking,
# /sync/favorites, /sync/ratings y /sync/lists/{id}/items, siempre por
# ids.tmdb/imdb/tvdb (nunca `id`, que es el de WeTrakr).
#
# El menu muestra el ESTADO real (en watchlist o no, favorito, nota actual,
# visto) leyendolo de las mismas caches que usan las carpetas, asi abrirlo no
# cuesta peticiones cuando ya estan calientes. Tras cada escritura se
# invalidan y se refresca el directorio.

def _wt_ids(imdb=None, tmdb=None, tvdb=None, media_type='movie'):
	ids = {}
	if _has(tmdb) and _int(tmdb):
		ids['tmdb'] = _int(tmdb)
	if imdb and str(imdb).startswith('tt'):
		ids['imdb'] = str(imdb)
	if media_type != 'movie' and _has(tvdb) and _int(tvdb):
		ids['tvdb'] = _int(tvdb)
	return ids


def _batch(media_type, ids, extra=None, season=None, episode=None):
	"""Documento de lote. Episodio: forma anidada show > seasons > episodes,
	con `status` en el EPISODIO (una temporada que lista episodios no cambia)."""
	node = {'ids': ids}
	if season is not None and episode is not None:
		ep = {'number': _int(episode)}
		ep.update(extra or {})
		node['seasons'] = [{'number': _int(season), 'episodes': [ep]}]
		return {'shows': [node]}
	node.update(extra or {})
	return {'movies' if media_type == 'movie' else 'shows': [node]}


def _nonempty(v):
	if isinstance(v, list):
		return len(v) > 0
	if isinstance(v, dict):
		return any(_nonempty(x) for x in v.values())
	return bool(v) and not isinstance(v, (int, float))


def _write(path, body):
	"""POST de escritura. Devuelve 'ok', 'existing', 'notfound' o 'error'.
	WeTrakr responde 200 tambien cuando no ha hecho nada: lo que no resuelve
	va en notFound y lo que no aplica en errored."""
	data = _request('POST', path, json_data=body, timeout=20)
	if data is None:
		return 'error'
	if not isinstance(data, dict):
		return 'ok'
	if _nonempty(data.get('notFound')) or _nonempty(data.get('not_found')):
		_hard_log('%s: title not found on WeTrakr' % path, 2)
		return 'notfound'
	if _nonempty(data.get('errored')) or _nonempty(data.get('errors')):
		_hard_log('%s: errored %s' % (path, _shape(data.get('errored') or data.get('errors'))), 2)
		return 'error'
	added = data.get('added') or data.get('removed') or data.get('updated') or data.get('saved')
	if _nonempty(data.get('existing')) and not _nonempty(added):
		return 'existing'
	return 'ok'


def _report(result):
	msgs = {'ok': 47068, 'existing': 47069, 'notfound': 47070, 'error': 47071}
	try:
		control.notification(title='WeTrakr', message=msgs.get(result, 47071))
	except Exception:
		pass


def _after_write(list_change=False):
	invalidateSectionCaches()
	try:
		from resources.lib.database import cache as _cache
		_cache.remove(getRatingValues, 'movie')
		_cache.remove(getRatingValues, 'show')
	except Exception:
		pass
	if list_change:
		# La clave de cache de los items de lista incluye la firma de actividad:
		# vaciarla abre una entrada nueva sin esperar a los 5 minutos.
		setSetting('wetrakr.activity', '')
	_clear_prop(_PROP_ACTIVITY_CHECK)
	# Solo se recarga la vista si ES de WeTrakr (lo cambiado puede salir o
	# entrar en ella). Desde Trakt Trending u otra lista cualquiera no cambia
	# nada visible y recargarla costaba ~2 s de busy por cada accion.
	try:
		if 'wetrakr' in (control.infoLabel('Container.FolderPath') or '').lower():
			control.refresh()
	except Exception:
		pass


def getRatingValues(media_type):
	"""{tmdb o imdb: nota} de las puntuaciones del usuario."""
	rows = _get_pages('/sync/ratings/%s' % _target(media_type), max_pages=30) or []
	out = {}
	for r in rows:
		try:
			m = _media_of(r)
			imdb, tmdb, tvdb = _ids_of(m)
			val = _first(r, 'rating', 'user_rating')
			if val in ('', None):
				inter = r.get('interactions') or m.get('interactions') or {}
				user = inter.get('user') if isinstance(inter, dict) else {}
				val = _first(user if isinstance(user, dict) else {}, 'rating')
				if isinstance(val, dict):
					val = val.get('rating')
			if val in ('', None):
				continue
			for key in (tmdb, imdb):
				if key:
					out[key] = val
		except Exception:
			continue
	return out


def _in(items, imdb, tmdb):
	for i in (items or []):
		if (tmdb and str(i.get('tmdb')) == str(tmdb)) or (imdb and i.get('imdb') == imdb):
			return True
	return False


def _state(media_type, imdb, tmdb):
	"""Estado del titulo desde las caches de las carpetas."""
	from resources.lib.database import cache as _cache
	st = {}
	try:
		st['watchlist'] = _in(_cache.get(getWatchlistFor, 1, media_type), imdb, tmdb)
	except Exception:
		st['watchlist'] = None
	try:
		st['favorite'] = _in(_cache.get(getFavoritesFor, 1, media_type), imdb, tmdb)
	except Exception:
		st['favorite'] = None
	try:
		vals = _cache.get(getRatingValues, 1, media_type) or {}
		st['rating'] = vals.get(str(tmdb)) or vals.get(imdb)
	except Exception:
		st['rating'] = None
	if media_type == 'movie':
		try:
			st['watched'] = _in(_cache.get(getWatchedFor, 1, 'movie'), imdb, tmdb)
		except Exception:
			st['watched'] = None
	return st


def _pick_rating(current=None):
	choices = [str(n) for n in range(10, 0, -1)]
	head = 'WeTrakr - %s' % getLS(47057)
	if current not in (None, ''):
		head = 'WeTrakr - %s' % _fmt(47058, current)
	sel = control.selectDialog(choices, heading=head)
	return None if sel < 0 else int(choices[sel])


def _pick_list():
	from resources.lib.database import cache as _cache
	lists = [l for l in (_cache.get(getUserLists, 6) or []) if not l.get('locked')]
	if not lists:
		control.notification(title='WeTrakr', message=47072)
		return None
	sel = control.selectDialog(['%s  (%s)' % (l['name'], l.get('items', '?')) for l in lists],
							   heading='WeTrakr - %s' % getLS(47018))
	return None if sel < 0 else lists[sel]['id']


def getLS(i):
	return control.lang(i)


def _fmt(i, value):
	"""Etiqueta con valor sin reventar si la traduccion pierde el %s."""
	text = getLS(i) or ''
	try:
		return text % value if '%s' in text else '%s (%s)' % (text, value)
	except Exception:
		return '%s (%s)' % (text, value)


def manager(name='', imdb=None, tmdb=None, tvdb=None, season=None, episode=None,
			media_type='movie', unfinished=False):
	"""Menu contextual de WeTrakr para peliculas, series y episodios."""
	try:
		if not getWeTrakrCredentialsInfo():
			return control.notification(title='WeTrakr', message='Not authorized.')
		is_episode = season not in (None, '', 'None') and episode not in (None, '', 'None')
		media_type = 'show' if (is_episode or media_type in ('show', 'tvshow', 'episode')) else 'movie'
		ids = _wt_ids(imdb, tmdb, tvdb, media_type)
		if not ids:
			return _report('notfound')
		control.busy()
		refresh_if_changed()
		st = {} if is_episode else _state(media_type, imdb, str(tmdb or ''))
		control.hide()

		items = []
		if is_episode:
			items += [(getLS(47066), 'ep_watch'), (getLS(47067), 'ep_unwatch')]
		else:
			if media_type == 'movie':
				items.append((getLS(47052), 'unwatch') if st.get('watched') else (getLS(47051), 'watch'))
			items.append((getLS(47054), 'wl_remove') if st.get('watchlist') else (getLS(47053), 'wl_add'))
			items.append((getLS(47056), 'fav_remove') if st.get('favorite') else (getLS(47055), 'fav_add'))
			if st.get('rating') not in (None, ''):
				items += [(_fmt(47058, st['rating']), 'rate'), (getLS(47059), 'unrate')]
			else:
				items.append((getLS(47057), 'rate'))
			items += [(getLS(47060), 'list_add'), (getLS(47061), 'list_remove')]
			if media_type == 'show':
				items += [(getLS(47064), 'st_watching'), (getLS(47062), 'st_paused'),
						  (getLS(47063), 'st_dropped'), (getLS(47073), 'show_watched')]
		if str(unfinished).lower() == 'true':
			items.append((getLS(47065), 'cancel_playing'))

		sel = control.selectDialog([i[0] for i in items], heading='%s - %s' % (getLS(47050), name or ''))
		if sel < 0:
			return
		act = items[sel][1]
		result, list_change = None, False
		target = '/sync/tracking'
		if act == 'watch':
			result = _write(target, _batch('movie', ids, {'status': 'watched'}))
		elif act == 'unwatch':
			result = _write(target + '/remove/last', _batch('movie', ids, {'status': 'watched'}))
		elif act == 'ep_watch':
			result = _write(target, _batch('show', ids, {'status': 'watched'}, season, episode))
		elif act == 'ep_unwatch':
			result = _write(target + '/remove/last', _batch('show', ids, {'status': 'watched'}, season, episode))
		elif act == 'wl_add':
			result = _write(target, _batch(media_type, ids, {'status': 'planning'}))
		elif act == 'wl_remove':
			result = _write(target + '/remove', _batch(media_type, ids, {'status': 'planning'}))
		elif act in ('st_watching', 'st_paused', 'st_dropped'):
			result = _write(target, _batch('show', ids, {'status': act[3:]}))
		elif act == 'show_watched':
			if not control.yesnoDialog(_fmt(47074, name or ''), '', '', heading='WeTrakr'):
				return
			result = _write(target, _batch('show', ids, {'status': 'watched'}))
		elif act == 'fav_add':
			result = _write('/sync/favorites', _batch(media_type, ids))
		elif act == 'fav_remove':
			result = _write('/sync/favorites/remove', _batch(media_type, ids))
		elif act == 'rate':
			value = _pick_rating(st.get('rating'))
			if value is None:
				return
			result = _write('/sync/ratings', _batch(media_type, ids, {'rating': value}))
		elif act == 'unrate':
			result = _write('/sync/ratings/remove', _batch(media_type, ids))
		elif act in ('list_add', 'list_remove'):
			list_id = _pick_list()
			if not list_id:
				return
			path = '/sync/lists/%s/items' % list_id + ('' if act == 'list_add' else '/remove')
			result = _write(path, _batch(media_type, ids))
			list_change = True
		elif act == 'cancel_playing':
			body = {'show': {'ids': ids}, 'episode': {'season': _int(season), 'number': _int(episode)}} \
				if is_episode else {'movie': {'ids': ids}}
			data = _request('DELETE', '/scrobble/playing', json_data=body, timeout=15)
			result = 'ok' if data is not None else 'error'
		_hard_log('manager %s (%s%s): %s' % (act, media_type, ' S%sE%s' % (season, episode) if is_episode else '', result), 1)
		_report(result)
		if result in ('ok', 'existing'):
			_after_write(list_change)
	except Exception:
		control.hide()
		log_utils.error()
