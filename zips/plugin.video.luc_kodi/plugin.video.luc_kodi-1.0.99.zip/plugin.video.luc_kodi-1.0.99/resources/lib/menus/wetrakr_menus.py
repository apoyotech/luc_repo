# -*- coding: utf-8 -*-
"""
	luc_kodi Add-on
	WeTrakr menus — Continue Watching, Next Episodes, watchlist, lists,
	favorites, ratings, history and personal calendar.

	_seed_bookmarks (punto de resume en traktsync.db y bookmarks.db) se importa
	de mdblist_menus: trabaja sobre la forma de item comun del addon, la misma
	que produce wetrakr.py.

	REGLA en todas las ramas: nunca se sale de un constructor de directorio sin
	haber cargado el directorio (reuselanguageinvoker + Android).
"""

from resources.lib.modules import control
from resources.lib.modules import log_utils
from resources.lib.database import cache
from resources.lib.menus.mdblist_menus import _seed_bookmarks

getLS = control.lang


def _ensure_fresh():
	"""Cambio de version y actividad de la cuenta. Va en la capa de menus: las
	funciones de datos viven debajo de cache.get() y en un acierto de cache no
	llegan a ejecutarse."""
	try:
		from resources.lib.modules import wetrakr
		wetrakr.bust_caches_on_version_change()
		wetrakr.refresh_if_changed()
	except Exception:
		pass


def _close_empty_directory(notify=True):
	try:
		from sys import argv
		control.hide()
		if notify:
			control.notification(title='WeTrakr', message=32049)
		control.content(int(argv[1]), '')
		control.directory(int(argv[1]), cacheToDisc=False)
	except Exception:
		pass


def _render_movies(items, **kwargs):
	from resources.lib.menus.movies import Movies
	mv = Movies()
	mv.list = items or []
	if mv.list:
		mv.worker()
	control.hide()
	mv.movieDirectory(mv.list, **kwargs)
	return mv.list


def _render_shows(items):
	from resources.lib.menus.tvshows import TVshows
	tv = TVshows()
	tv.list = items or []
	if tv.list:
		tv.worker()
	control.hide()
	tv.tvshowDirectory(tv.list)


def _enrich_episodes(ep, raw, tag):
	"""Mismo camino que Trakt, MDBList y PunchPlay: trakt_episodes_list con los
	items ya cargados (no llama a la API de Trakt)."""
	enriched = cache.get(ep.trakt_episodes_list, 0, ep.traktunfinished_link, ep.trakt_user, ep.lang, raw)
	if raw and not enriched:
		from resources.lib.modules.wetrakr import _hard_log
		_hard_log('%s: %d episodes NOT enriched (shown bare)' % (tag, len(raw)), 3)
	return enriched or raw


def _render_episodes(raw, tag, unfinished=False, sort_key=None, reverse=False):
	from resources.lib.menus.episodes import Episodes
	ep = Episodes()
	if not raw:
		control.hide()
		ep.episodeDirectory([], unfinished=unfinished, next=False)
		return
	ep.list = _enrich_episodes(ep, raw, tag)
	if sort_key:
		ep.list = sorted(ep.list, key=lambda k: k.get(sort_key, ''), reverse=reverse)
	if unfinished:
		_seed_bookmarks(ep.list)
	ep.episodeDirectory(ep.list, unfinished=unfinished, next=False)


def _build_list_directory(lists, media_type):
	"""Directorio de LISTAS. Las bloqueadas por el plan (VIP) se muestran
	atenuadas y sin enlace util, con el motivo en el plot."""
	from sys import argv
	highlight = control.getHighlightColor()
	art_path = control.artPath()
	icon = control.joinPath(art_path, 'wetrakr.png') if art_path else 'DefaultVideoPlaylists.png'
	action = 'wetrakr_showListItems' if media_type == 'show' else 'wetrakr_movieListItems'
	for lst in (lists or []):
		try:
			label = lst.get('name', '?')
			if lst.get('owner'):
				label = '%s — [COLOR %s]%s[/COLOR]' % (label, highlight, lst['owner'])
			bits = ['%s items' % lst.get('items', '?')]
			if lst.get('privacy'):
				bits.append(lst['privacy'])
			if lst.get('locked'):
				label = '[COLOR gray]%s[/COLOR]' % label
				bits.append('locked (%s) — WeTrakr VIP' % (lst.get('locked_reason') or 'plan'))
			url = 'plugin://plugin.video.luc_kodi/?action=%s&list_id=%s&src=%s' % (action, lst['id'], lst.get('src', 'own'))
			item = control.item(label=label, offscreen=True)
			item.setArt({'icon': icon, 'thumb': icon, 'poster': icon, 'fanart': control.addonFanart()})
			plot = '%s  •  %s' % (lst.get('name', ''), '  •  '.join(bits))
			try:
				item.getVideoInfoTag().setPlot(plot)
			except Exception:
				item.setInfo('video', {'plot': plot})
			control.addItem(handle=int(argv[1]), url=url, listitem=item, isFolder=True)
		except Exception:
			log_utils.error()
	control.content(int(argv[1]), '')
	control.directory(int(argv[1]), cacheToDisc=True)


# ---------------------------------------------------------------------------
# Constructores
# ---------------------------------------------------------------------------

def continue_movies():
	from resources.lib.modules.wetrakr import getMoviesProgress
	raw = cache.get(getMoviesProgress, 1)
	if not raw:
		return _render_movies([], unfinished=True, next=False)
	from resources.lib.menus.movies import Movies
	mv = Movies()
	mv.list = raw
	mv.worker()
	mv.list = sorted(mv.list, key=lambda k: k.get('paused_at', ''), reverse=True)
	_seed_bookmarks(mv.list)
	control.hide()
	mv.movieDirectory(mv.list, unfinished=True, next=False)


def continue_episodes():
	from resources.lib.modules.wetrakr import getEpisodesProgress
	_render_episodes(cache.get(getEpisodesProgress, 1), 'continueEpisodes',
					 unfinished=True, sort_key='paused_at', reverse=True)


def next_episodes():
	from resources.lib.modules.wetrakr import getWatchingShows
	_render_episodes(cache.get(getWatchingShows, 1), 'nextEpisodes')


def calendar_episodes():
	from resources.lib.modules.wetrakr import getCalendarEpisodes
	_render_episodes(cache.get(getCalendarEpisodes, 6), 'calendar', sort_key='premiered')


def calendar_movies():
	from resources.lib.modules.wetrakr import getCalendarMovies
	_render_movies(cache.get(getCalendarMovies, 12))


def _library(fn_name, media_type, ttl):
	from resources.lib.modules import wetrakr
	items = cache.get(getattr(wetrakr, fn_name), ttl, media_type)
	if media_type == 'show':
		_render_shows(items)
	else:
		_render_movies(items)


def history_movies():
	from resources.lib.modules.wetrakr import getHistory
	_render_movies(cache.get(getHistory, 1))


def user_lists(media_type):
	from resources.lib.modules.wetrakr import getUserLists
	_build_list_directory(cache.get(getUserLists, 6) or [], media_type)


def liked_lists(media_type):
	from resources.lib.modules.wetrakr import getLikedLists
	_build_list_directory(cache.get(getLikedLists, 6) or [], media_type)


def followed_lists(media_type):
	from resources.lib.modules.wetrakr import getFollowedLists
	_build_list_directory(cache.get(getFollowedLists, 6) or [], media_type)


def trending_lists(media_type):
	from resources.lib.modules.wetrakr import getTrendingLists
	_build_list_directory(cache.get(getTrendingLists, 12) or [], media_type)


def list_items(list_id, media_type, src):
	from resources.lib.modules.wetrakr import getListItems
	stamp = control.setting('wetrakr.activity') or ''
	items = cache.get(getListItems, 6, list_id, media_type, src or 'own', stamp)
	if media_type == 'show':
		_render_shows(items)
	else:
		_render_movies(items)


# accion -> (funcion, argumentos, es_directorio_de_listas)
_ROUTES = {
	'wetrakr_continueMovies': (continue_movies, (), False),
	'wetrakr_continueEpisodes': (continue_episodes, (), False),
	'wetrakr_showProgress': (next_episodes, (), False),
	'wetrakr_calendarEpisodes': (calendar_episodes, (), False),
	'wetrakr_calendarMovies': (calendar_movies, (), False),
	'wetrakr_movieWatchlist': (_library, ('getWatchlistFor', 'movie', 1), False),
	'wetrakr_showWatchlist': (_library, ('getWatchlistFor', 'show', 1), False),
	'wetrakr_movieFavorites': (_library, ('getFavoritesFor', 'movie', 1), False),
	'wetrakr_showFavorites': (_library, ('getFavoritesFor', 'show', 1), False),
	'wetrakr_movieRatings': (_library, ('getRatingsFor', 'movie', 1), False),
	'wetrakr_showRatings': (_library, ('getRatingsFor', 'show', 1), False),
	'wetrakr_showWatched': (_library, ('getWatchedFor', 'show', 1), False),
	'wetrakr_movieHistory': (history_movies, (), False),
	'wetrakr_movieUserLists': (user_lists, ('movie',), True),
	'wetrakr_showUserLists': (user_lists, ('show',), True),
	'wetrakr_movieLikedLists': (liked_lists, ('movie',), True),
	'wetrakr_showLikedLists': (liked_lists, ('show',), True),
	'wetrakr_movieFollowedLists': (followed_lists, ('movie',), True),
	'wetrakr_showFollowedLists': (followed_lists, ('show',), True),
	'wetrakr_movieTrendingLists': (trending_lists, ('movie',), True),
	'wetrakr_showTrendingLists': (trending_lists, ('show',), True),
}


def route(action, params):
	"""Despacha todas las acciones wetrakr_* desde router.py. True si la
	reconocio."""
	if action in ('wetrakr_Authorize', 'wetrakr_Deauthorize', 'wetrakr_AccountInfo', 'wetrakr_ForceSync'):
		from resources.lib.modules import wetrakr
		{'wetrakr_Authorize': wetrakr.auth, 'wetrakr_Deauthorize': wetrakr.deauth,
		 'wetrakr_AccountInfo': wetrakr.account_info_to_dialog,
		 'wetrakr_ForceSync': wetrakr.force_wetrakrSync}[action]()
		return True
	if action == 'wetrakr_Manager':
		from resources.lib.modules import wetrakr
		wetrakr.manager(params.get('name', ''), imdb=params.get('imdb'), tmdb=params.get('tmdb'),
						tvdb=params.get('tvdb'), season=params.get('season'), episode=params.get('episode'),
						media_type=params.get('media_type', 'movie'), unfinished=params.get('unfinished', False))
		return True
	if action in ('wetrakr_movieNavigator', 'wetrakr_tvNavigator'):
		from resources.lib.menus import navigator
		if action == 'wetrakr_movieNavigator':
			navigator.Navigator().wetrakr_movies()
		else:
			navigator.Navigator().wetrakr_tv()
		return True
	if action in ('wetrakr_movieListItems', 'wetrakr_showListItems'):
		try:
			_ensure_fresh()
			list_items(params.get('list_id'), 'show' if action == 'wetrakr_showListItems' else 'movie',
					   params.get('src'))
		except Exception:
			log_utils.error()
			_close_empty_directory()
		return True
	entry = _ROUTES.get(action)
	if not entry:
		return False
	fn, args, is_lists = entry
	try:
		_ensure_fresh()
		fn(*args)
	except Exception:
		log_utils.error()
		_close_empty_directory(notify=not is_lists)
	return True
