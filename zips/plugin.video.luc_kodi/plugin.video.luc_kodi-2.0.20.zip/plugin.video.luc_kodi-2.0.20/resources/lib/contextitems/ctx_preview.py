# -*- coding: utf-8 -*-
"""
	luc_kodi Add-on
	Global context entry "Preview" (addon.xml kodi.context.item, v2.0.18).
	Same mechanism as ctx_hub.py: Kodi gives this script a copy of the focused
	item in sys.listitem; what the Preview window needs (titles, ids, art, plot,
	the item's own context options) is handed to the plugin through a window
	property and the plugin opens windows/preview.py. Kept minimal on purpose:
	it runs in its own interpreter, outside the plugin's module path.
"""

import sys
from json import dumps
import xbmc
import xbmcgui

ART_KEYS = ('poster', 'tvshow.poster', 'fanart', 'tvshow.fanart', 'landscape', 'tvshow.landscape',
			'clearlogo', 'tvshow.clearlogo', 'thumb', 'icon')


def _tag_value(tag, name):
	try:
		value = getattr(tag, name)()
		return value if value not in (None, -1) else ''
	except Exception:
		return ''


if __name__ == '__main__':
	try:
		li = sys.listitem
		data = {'cm': li.getProperty('luc_kodi.cm'), 'label': li.getLabel()}
		try:
			data['path'] = str(li.getPath() or '')
			data['playable'] = 'true' if li.getProperty('IsPlayable') == 'true' else 'false'
		except Exception:
			pass
		art = {}
		for key in ART_KEYS:
			try: value = li.getArt(key)
			except Exception: value = ''
			if value: art[key] = value
		data['art'] = art
		data['poster'] = art.get('poster') or art.get('tvshow.poster') or art.get('thumb') or art.get('icon') or ''
		try:
			tag = li.getVideoInfoTag()
			data['title'] = _tag_value(tag, 'getTitle') or data['label']
			data['year'] = _tag_value(tag, 'getYear')
			data['mediatype'] = _tag_value(tag, 'getMediaType')
			data['rating'] = _tag_value(tag, 'getRating')
			data['playcount'] = _tag_value(tag, 'getPlayCount')
			data['duration'] = _tag_value(tag, 'getDuration')
			data['tvshowtitle'] = _tag_value(tag, 'getTVShowTitle')
			data['season'] = _tag_value(tag, 'getSeason')
			data['episode'] = _tag_value(tag, 'getEpisode')
			data['plot'] = _tag_value(tag, 'getPlot')
			data['tagline'] = _tag_value(tag, 'getTagLine')
			data['trailer'] = _tag_value(tag, 'getTrailer')
			try: data['genre'] = ', '.join(tag.getGenres() or [])
			except Exception: data['genre'] = ''
			for key in ('tmdb', 'imdb', 'tvdb'):
				try: data[key] = tag.getUniqueID(key) or ''
				except Exception: data[key] = ''
		except Exception:
			data['title'] = data['label']
		# the show's ids, for an episode or a season (luc_kodi sets them as properties)
		for key in ('tvshow.tmdb_id', 'tmdb_id'):
			try: data['prop.' + key] = li.getProperty(key) or ''
			except Exception: pass
		data['folderpath'] = xbmc.getInfoLabel('Container.FolderPath')
		data['foldername'] = xbmc.getInfoLabel('Container.FolderName')
		data['inVideos'] = 'true' if xbmc.getCondVisibility('Window.IsActive(10025)') else 'false'
		xbmcgui.Window(10000).setProperty('luc_kodi.ctx.preview.payload', dumps(data))
		xbmc.executebuiltin('RunPlugin(plugin://plugin.video.luc_kodi/?action=ctx_Preview)')
	except Exception as e:
		xbmc.log('[ plugin.video.luc_kodi ] ctx_preview: %s' % e, xbmc.LOGWARNING)
