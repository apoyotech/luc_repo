"""
	luc_kodi Add-on

	oc_cloud (v2.0.20) -- lo que el usuario ya tiene en su nube de Offcloud,
	como fuentes directas. Mismo criterio de titulo y episodio que tb_cloud.
	La version de Umbrella llamaba a Offcloud().build_url(), que no existe, y
	leia isDirectory/server, campos que la API de 2026 ya no da en el
	historial; aqui los ficheros salen de /cloud/explore.
"""

import re
from threading import Thread
from resources.lib.cloud_scrapers import cloud_utils
from resources.lib.debrid.offcloud import Offcloud
from resources.lib.modules.source_utils import supported_video_extensions
from resources.lib.jacksparrow import source_utils as fs_utils

MAX_FOLDERS = 25 # carpetas cuyo nombre encaja que se abren por busqueda


class source:
	priority = 0
	pack_capable = False # to avoid being added to pack scrape threads
	hasMovies = True
	hasEpisodes = True
	def __init__(self):
		self.language = ['en']

	def sources(self, data, hostDict):
		sources = []
		if not data: return sources
		try:
			title = data['tvshowtitle'] if 'tvshowtitle' in data else data['title']
			title = title.replace('&', 'and').replace('Special Victims Unit', 'SVU')
			aliases = data['aliases']
			episode_title = data['title'] if 'tvshowtitle' in data else None
			self.year = data['year']
			hdlr = 'S%02dE%02d' % (int(data['season']), int(data['episode'])) if 'tvshowtitle' in data else self.year
			self.season = str(data['season']) if 'tvshowtitle' in data else None
			self.episode = str(data['episode']) if 'tvshowtitle' in data else None
			query_list = self.episode_query_list() if 'tvshowtitle' in data else self.year_query_list()
			oc = Offcloud()
			folders = [i for i in oc.user_cloud() if i.get('status') == 'downloaded' and i.get('requestId')]
			# Solo se abren las entradas cuyo nombre es del titulo: cada una es
			# una llamada a /cloud/explore.
			folders = [i for i in folders if cloud_utils.cloud_check_title(title, aliases, i.get('fileName', ''))][:MAX_FOLDERS]
			if not folders: return sources
			extras_filter = cloud_utils.extras_filter()
			files_by_id = {}
			def _explore(item):
				try: files_by_id[str(item['requestId'])] = oc._cloud_files(str(item['requestId']), item)
				except Exception: files_by_id[str(item['requestId'])] = []
			threads = [Thread(target=_explore, args=(i,)) for i in folders]
			[t.start() for t in threads]
			[t.join() for t in threads]
		except:
			from resources.lib.modules import log_utils
			log_utils.error('OC_CLOUD: ')
			return sources

		extensions = tuple(supported_video_extensions())
		for folder in folders:
			folder_name = folder.get('fileName', '')
			for file in files_by_id.get(str(folder['requestId'])) or []:
				try:
					name = file['filename']
					rt = cloud_utils.release_title_format(name)
					if not name.lower().endswith(extensions): continue
					if any(value in rt for value in extras_filter): continue
					if name.lower().endswith('m2ts'): continue
					if all(not bool(re.search(i, rt)) for i in query_list):
						if 'tvshowtitle' in data:
							nl = name.lower()
							if all(not bool(re.search(i, nl)) for i in self.season_folder_list()): continue
							if all(not bool(re.search(i, rt)) for i in self.episode_list()): continue
						else:
							if all(not bool(re.search(i, folder_name)) for i in query_list): continue
							name = folder_name
					link = Offcloud.requote_uri(file['url'])
					name_info = fs_utils.info_from_name(name, title, self.year, hdlr, episode_title)
					quality, info = fs_utils.get_release_quality(name_info, name)
					try:
						dsize, isize = fs_utils.convert_size(file.get('size') or '', to='GB')
						info.insert(0, isize)
					except: dsize = 0
					info = ' / '.join(info)
					sources.append({'provider': 'oc_cloud', 'source': 'cloud', 'debrid': 'Offcloud', 'seeders': '', 'hash': '', 'name': name, 'name_info': name_info,
									'quality': quality, 'language': 'en', 'url': link, 'info': info, 'direct': True, 'debridonly': True, 'size': dsize})
				except:
					from resources.lib.modules import log_utils
					log_utils.error('OC_CLOUD: ')
		return sources

	def year_query_list(self):
		return [str(self.year), str(int(self.year)+1), str(int(self.year)-1)] if self.year else []

	def episode_query_list(self):
		return [
				'[.-]%d[.-]?%02d[.-]' % (int(self.season), int(self.episode)),
				'[.-]%02d[.-]%02d[.-]' % (int(self.season), int(self.episode)),
				'[.-]%dx%02d[.-]' % (int(self.season), int(self.episode)),
				'[.-]%02dx%02d[.-]' % (int(self.season), int(self.episode)),
				's%de%02d' % (int(self.season), int(self.episode)),
				's%02de%02d' % (int(self.season), int(self.episode)),
				's%dep%02d' % (int(self.season), int(self.episode)),
				's%02dep%02d' % (int(self.season), int(self.episode)),
				'season%depisode%d' % (int(self.season), int(self.episode)),
				'season%depisode%02d' % (int(self.season), int(self.episode)),
				'season%02depisode%02d' % (int(self.season), int(self.episode))]

	def season_folder_list(self):
		return [
				r'[.-]s\s?%d[\s/.-]' % int(self.season),
				r'[.-]s\s?%02d[\s/.-]' % int(self.season),
				r'season\s?%d[\s/.-]' % int(self.season),
				r'season\s?%02d[\s/.-]' % int(self.season)]

	def episode_list(self): # checks against formatted release_title with removed whitespace
		return [
				'[.-]e%d[.-]' % int(self.episode),
				'[.-]e%02d[.-]' % int(self.episode),
				'[.-]ep%d[.-]' % int(self.episode),
				'[.-]ep%02d[.-]' % int(self.episode),
				'episode[.-]?%d[.-]' % int(self.episode),
				'episode[.-]?%02d[.-]' % int(self.episode)]

	def resolve(self, url):
		return url # los enlaces de la nube de Offcloud ya son el fichero
