# -*- coding: utf-8 -*-
"""
	luc_kodi Add-on
	Preview (v2.0.18): a quick look at a movie, show, season or episode without
	leaving the poster wall, in any skin.

	Kodi's own context menu (long press OK on a remote, long press on a touch
	screen) shows "luc_kodi  Preview" on luc_kodi's titles
	(addon.xml kodi.context.item -> resources/lib/contextitems/ctx_preview.py).
	It opens windows/preview.py (preview.xml): the panel of Rescrape Options at
	its largest size, with the clearlogo and the ratings top left, the YouTube
	trailer top right (it starts after a countdown, 3 s by default), the
	synopsis below and three buttons: Play (Open for a show or season),
	Full-screen trailer and More options (the luc_kodi context panel).

	Settings > Navigation > Preview: the entry itself, the countdown (Off, 3, 5,
	8 s), the trailer's sound, and hiding the plot of unwatched episodes.
"""

from json import dumps as jsdumps, loads as jsloads
from resources.lib.modules import control
from resources.lib.modules import log_utils

PROP_PAYLOAD = 'luc_kodi.ctx.preview.payload'
PROP_ENABLED = 'luc_kodi.ctx.preview'
SYSADDON = 'plugin://plugin.video.luc_kodi/'
L = control.lang


def refresh_property():
	"""Window property read by the visible condition of the context entry (addon.xml)."""
	try: control.homeWindow.setProperty(PROP_ENABLED, 'true' if control.setting('preview.enabled') != 'false' else 'false')
	except Exception: log_utils.error()


def _art(data, *keys):
	art = data.get('art') or {}
	for k in keys:
		if art.get(k): return art[k]
	return ''


def _unwatched(data):
	try: return int(data.get('playcount') or 0) <= 0
	except Exception: return True


def build(data):
	"""Payload of ctx_preview.py -> (window properties, data for the window)."""
	from resources.lib.modules import context_hub
	mt = (data.get('mediatype') or '').lower()
	head = context_hub.header_from_info(data)
	meta = head.get('meta') or ''
	genre = (data.get('genre') or '').strip()
	if genre and mt in ('movie', 'tvshow'):
		meta = '  ·  '.join([p for p in (meta, genre) if p])
	is_show_art = mt in ('episode', 'season')
	clearlogo = _art(data, 'tvshow.clearlogo', 'clearlogo') if is_show_art else _art(data, 'clearlogo', 'tvshow.clearlogo')
	# the trailer box shows the fanart: never an episode's own still, which can give the scene away
	fanart = _art(data, 'fanart', 'tvshow.fanart', 'landscape', 'tvshow.landscape')
	if not fanart and mt != 'episode': fanart = _art(data, 'thumb')
	plot = (data.get('plot') or '').strip()
	if mt == 'episode' and _unwatched(data) and control.setting('preview.antispoiler') != 'false':
		plot = L(48208)
	title = head.get('title') or data.get('title') or ''
	if mt == 'episode' and data.get('tvshowtitle'):
		title = context_hub.clean_label(data.get('tvshowtitle'))
	props = {
		'poster': data.get('poster') or '',
		'meta': meta,
		'title': title,
		'clearlogo': clearlogo,
		'tagline': (data.get('tagline') or '').strip(),
		'fanart': fanart,
		'plot': plot,
		'play': L(48133) if data.get('playable') == 'true' else L(48207),
	}
	try: props['version'] = 'v%s' % control.addon('plugin.video.luc_kodi').getAddonInfo('version')
	except Exception: props['version'] = ''
	# TMDb's own vote is in hand: its icon shows at once, the others when they arrive
	try:
		r = float(data.get('rating') or 0)
		if r > 0: props['r.tmdb'] = '%.1f' % r
	except Exception: pass
	ref = None
	if mt in ('movie', 'tvshow') and str(data.get('imdb') or '').startswith('tt'):
		ref = {'mediatype': 'movie' if mt == 'movie' else 'tvshow', 'imdb': data['imdb'], 'rating': data.get('rating') or ''}
	win = dict(data)
	win['ratings_ref'] = ref
	return props, win


def ratings_props(ref):
	"""The other ratings of a movie or show: pv.r.imdb r.rt r.mc r.tmdb r.trakt.
	ratings.fetch is the cascade of the sources window and the Assistant
	(MDBList, Trakt, OMDb, cached), so a title rated once costs nothing again."""
	out = {}
	try:
		from resources.lib.modules import ratings
		r = ratings.fetch(ref, live=True)
		if r.get('imdb') and r.get('imdb_source') == 'imdb': out['r.imdb'] = r['imdb']
		if r.get('rt'): out['r.rt'] = r['rt']
		if r.get('metacritic'): out['r.mc'] = r['metacritic']
		if r.get('tmdb'): out['r.tmdb'] = r['tmdb']
		if r.get('trakt'): out['r.trakt'] = r['trakt']
	except Exception:
		log_utils.error()
	return out


def youtube_ready():
	try:
		from resources.lib.modules.trailer import _has_addon, YT_PLUGIN
		return _has_addon(YT_PLUGIN)
	except Exception:
		return False


def trailer_ids(data):
	"""YouTube ids for the title, best first: the same lookup as the Trailer entry
	(trailer.py: TMDb videos in the trailer language, official only by default,
	then Trakt). Seasons and episodes ask for their season's trailer first."""
	from resources.lib.modules.trailer import Trailer
	mt = (data.get('mediatype') or '').lower()
	kind = 'movie' if mt == 'movie' else 'show'
	tmdb = data.get('tmdb') or ''
	if mt in ('episode', 'season'): tmdb = data.get('prop.tvshow.tmdb_id') or tmdb
	if mt == 'tvshow': tmdb = data.get('prop.tmdb_id') or tmdb
	name = data.get('tvshowtitle') if mt in ('episode', 'season') else data.get('title')
	season = ''
	try:
		if mt in ('episode', 'season') and int(data.get('season') or 0) > 0: season = str(int(data['season']))
	except Exception: season = ''
	year = str(data.get('year') or '')
	return Trailer().worker(kind, name or '', year, data.get('trailer') or '', data.get('imdb') or '', tmdb, season=season) or []


def _go(data):
	"""Play the item, or open it when it is a show or a season."""
	path = data.get('path') or ''
	if not path.startswith(SYSADDON): return
	if data.get('playable') == 'true':
		control.execute('PlayMedia(%s)' % path)
	elif control.condVisibility('Window.IsActive(videos)'):
		control.execute('Container.Update(%s)' % path)
	else:
		control.execute('ActivateWindow(Videos,%s,return)' % path)


def open_from_payload():
	"""Router action ctx_Preview."""
	raw = control.homeWindow.getProperty(PROP_PAYLOAD)
	control.homeWindow.clearProperty(PROP_PAYLOAD)
	try: data = jsloads(raw) if raw else {}
	except Exception: data = {}
	if not data: return
	try:
		props, win_data = build(data)
		from resources.lib.windows.preview import PreviewXML
		control.hide()
		window = PreviewXML('preview.xml', control.addonPath(control.addonId()), data=win_data, props=props)
		result = window.run()
		vids = window.fullscreen_candidates() if result == 'trailer' and not window.keep_playing else []
		keep = window.keep_playing
		del window
	except Exception:
		log_utils.error()
		return
	control.sleep(120)  # let the window finish closing before the next one takes focus
	if result == 'play':
		_go(data)
	elif result == 'trailer':
		if keep:
			control.execute('ActivateWindow(fullscreenvideo)')
		elif vids:
			from resources.lib.modules.trailer import Trailer
			resolved = Trailer().resolve(vids[0])
			if resolved:
				item = control.item(label='%s - Trailer' % (props.get('title') or ''), offscreen=True)
				try: item.setArt({'icon': props.get('poster') or '', 'thumb': props.get('poster') or ''})
				except Exception: pass
				control.player.play(resolved['url'], item)
		else:
			control.notification(message=L(48203))
	elif result == 'more':
		cm_payload = dict(data)
		cm_payload.pop('art', None)
		control.homeWindow.setProperty('luc_kodi.ctx.payload', jsdumps(cm_payload))
		control.execute('RunPlugin(%s?action=ctx_Hub)' % SYSADDON)
