# -*- coding: utf-8 -*-
"""
	luc_kodi Add-on
	preview.py (v2.0.18) - the Preview window (preview.xml), opened from Kodi's
	own context menu on a movie, show, season or episode (modules/preview.py).

	The trailer plays INSIDE the window: preview.xml has a videowindow control
	over the 16:9 box, and the trailer is started with xbmc.Player().play(...,
	windowed=True), so Kodi keeps the window on screen instead of going full
	screen. This works in Kodi 21 and 22 alike.

	TRAILER, step by step (thread _trailer):
	  1. the YouTube ids are looked up at once (trailer.Trailer().worker, the same
	     search and the same "Trailer language" and "official only" settings as
	     the Trailer entry), while the countdown runs: the wait hides the lookup
	  2. after the countdown (Settings > Navigation > Preview: Off, 3, 5 or 8 s)
	     the first id is handed to plugin.video.youtube, as every luc_kodi trailer
	  3. if it does not start within 20 s, or the player reports an error, the
	     next id is tried (three at most), then "No trailer found"
	  Nothing starts by itself when something else is already playing, or with
	  the countdown Off; the Full-screen trailer button always works.
	SOUND: with "Trailer sound" off, Kodi is muted while the trailer plays and
	  the mute is put back as it was when the window closes.
	CLOSING: a trailer still playing in the window is stopped, unless it was
	  sent to full screen with the button. The trailer mark
	  (luc_kodi.trailer.playing, read by trailer_audio.py) is cleared.
	The failover property of trailer.py is never set here, so service.py does
	not start a full-screen trailer on its own when one fails in the window.
"""

import threading

import xbmc

from resources.lib.modules import control
from resources.lib.windows.base import BaseDialog

BTN_PLAY, BTN_TRAILER, BTN_MORE = 9701, 9702, 9703
DELAYS = {'0': 0, '1': 3, '2': 5, '3': 8}   # preview.trailer.delay -> seconds (0 = Off)
START_TIMEOUT = 20.0
MAX_TRIES = 3
YT_PLAY = 'plugin://plugin.video.youtube/play/?video_id=%s'
MARK = 'luc_kodi.trailer.playing'


def _lang(sid):
	try: return control.lang(sid)
	except Exception: return ''


class PreviewXML(BaseDialog):
	def __init__(self, *args, **kwargs):
		BaseDialog.__init__(self, args)
		self.data = kwargs.get('data') or {}
		self.props = kwargs.get('props') or {}
		self.result = None            # 'play' | 'trailer' | 'more' | None
		self._alive = True
		self._threads = []
		self._candidates = None       # None until the lookup has finished
		self._lookup_done = threading.Event()
		self._vid = ''                # the id playing (or being started) in the window
		self._keep_playing = False    # sent to full screen: do not stop it on close
		self._unmute = False
		self._player = xbmc.Player()
		self._monitor = xbmc.Monitor()
		for key, value in self.props.items():
			self.setProperty('pv.%s' % key, value or '')
		self.setProperty('pv.state', 'wait')

	# ───────────────────────── window ─────────────────────────
	def onInit(self):
		try: self.setFocusId(BTN_PLAY)
		except Exception: pass
		self._start(self._lookup)
		self._start(self._trailer)
		if self.data.get('ratings_ref'):
			self._start(self._ratings)

	def _start(self, target):
		t = threading.Thread(target=target)
		t.daemon = True
		t.start()
		self._threads.append(t)

	def run(self):
		self.doModal()
		self._alive = False
		for t in self._threads: t.join(2.0)
		self._teardown()
		self.clearProperties()
		return self.result

	def close(self):
		self._alive = False
		BaseDialog.close(self)

	def onClick(self, controlID):
		if controlID == BTN_PLAY: self.result = 'play'
		elif controlID == BTN_TRAILER:
			self.result = 'trailer'
			self._keep_playing = self._ours_playing()
		elif controlID == BTN_MORE: self.result = 'more'
		else: return
		self.close()

	def onAction(self, action):
		try:
			aid = action.getId()
			if aid in self.context_actions:
				self.result = 'more'
				self.close()
			elif aid in self.closing_actions:
				self.result = None
				self.close()
		except Exception:
			from resources.lib.modules import log_utils
			log_utils.error()

	# ───────────────────────── ratings ─────────────────────────
	def _ratings(self):
		try:
			from resources.lib.modules import preview
			props = preview.ratings_props(self.data.get('ratings_ref'))
			if not self._alive: return
			for key, value in (props or {}).items():
				self.setProperty('pv.%s' % key, value)
		except Exception:
			from resources.lib.modules import log_utils
			log_utils.error()

	# ───────────────────────── trailer ─────────────────────────
	def _lookup(self):
		"""The YouTube ids of the title, best first (runs during the countdown)."""
		ids = []
		try:
			from resources.lib.modules import preview
			ids = preview.trailer_ids(self.data)
		except Exception:
			from resources.lib.modules import log_utils
			log_utils.error()
		self._candidates = ids or []
		self._lookup_done.set()

	def _wait(self, seconds):
		"""Sleep while the window is open; False once it closed or Kodi quits."""
		end = seconds
		while end > 0:
			if not self._alive or self._monitor.abortRequested(): return False
			step = 0.2 if end > 0.2 else end
			if self._monitor.waitForAbort(step): return False
			end -= step
		return self._alive

	def _status(self, text, state=None):
		if not self._alive: return
		self.setProperty('pv.status', text or '')
		if state: self.setProperty('pv.state', state)

	def _trailer(self):
		try:
			from resources.lib.modules import preview
			if not preview.youtube_ready():
				self._status(_lang(48209), 'none')
				return
			delay = DELAYS.get(control.setting('preview.trailer.delay') or '1', 3)
			if not delay:
				self._lookup_done.wait(15)
				if self._alive and not self._candidates: self._status(_lang(48203), 'none')
				return
			for left in range(delay, 0, -1):
				self._status(_lang(48201) % left, 'wait')
				if not self._wait(1.0): return
			if not self._lookup_done.is_set():
				self._status(_lang(48202), 'loading')
				while self._alive and not self._lookup_done.wait(0.25): pass
			if not self._alive: return
			if not self._candidates:
				self._status(_lang(48203), 'none')
				return
			if self._player.isPlaying():
				# something else is playing: the trailer waits for the button
				self._status('', 'wait')
				return
			self._play_in_window()
		except Exception:
			from resources.lib.modules import log_utils
			log_utils.error()

	def _play_in_window(self):
		for vid in self._candidates[:MAX_TRIES]:
			if not self._alive: return
			self._status(_lang(48202), 'loading')
			if not self._start_video(vid, windowed=True): continue
			started = self._wait_started(vid)
			if started is None: return          # window closed while starting
			if started:
				self._status('', 'playing')
				self._watch_end(vid)
				return
			from resources.lib.modules import log_utils
			log_utils.log('[ luc_kodi ] preview: trailer %s did not start, trying the next one' % vid, level=log_utils.LOGDEBUG)
			self._stop_ours()
		self._status(_lang(48203), 'none')

	def _start_video(self, vid, windowed):
		try:
			self._vid = vid
			control.homeWindow.setProperty(MARK, vid)
			if windowed: self._mute()
			li = control.item(label='%s - Trailer' % (self.props.get('title') or ''), offscreen=True)
			try: li.setArt({'icon': self.props.get('poster') or '', 'thumb': self.props.get('poster') or ''})
			except Exception: pass
			self._player.play(YT_PLAY % vid, li, windowed)
			return True
		except Exception:
			from resources.lib.modules import log_utils
			log_utils.error()
			return False

	def _ours_playing(self):
		try:
			if not self._vid or not self._player.isPlayingVideo(): return False
			path = xbmc.getInfoLabel('Player.FilenameAndPath') or ''
			return 'plugin.video.youtube' in path and self._vid in path
		except Exception:
			return False

	def _wait_started(self, vid):
		"""True once our trailer is on screen, False after the timeout, None if the window closed."""
		waited = 0.0
		while waited < START_TIMEOUT:
			if not self._alive: return None
			if self._ours_playing(): return True
			if self._monitor.waitForAbort(0.25): return None
			waited += 0.25
		return False

	def _watch_end(self, vid):
		"""Back to the fanart when the trailer ends by itself."""
		while self._alive and not self._monitor.abortRequested():
			if not self._ours_playing():
				if self._alive:
					self._restore_mute()
					self._status('', 'wait')
				return
			if self._monitor.waitForAbort(0.5): return

	# ───────────────────────── sound ─────────────────────────
	def _mute(self):
		if self._unmute or control.setting('preview.trailer.sound') != 'false': return
		try:
			from json import loads
			res = loads(control.jsonrpc('{"jsonrpc":"2.0","id":1,"method":"Application.GetProperties","params":{"properties":["muted"]}}'))
			if (res.get('result') or {}).get('muted'): return   # already muted by the user: leave it
			control.jsonrpc('{"jsonrpc":"2.0","id":1,"method":"Application.SetMute","params":{"mute":true}}')
			self._unmute = True
		except Exception:
			pass

	def _restore_mute(self):
		if not self._unmute: return
		try: control.jsonrpc('{"jsonrpc":"2.0","id":1,"method":"Application.SetMute","params":{"mute":false}}')
		except Exception: pass
		self._unmute = False

	# ───────────────────────── closing ─────────────────────────
	def _stop_ours(self):
		try:
			if self._ours_playing():
				self._player.stop()
				waited = 0.0
				while self._player.isPlaying() and waited < 3.0:
					xbmc.sleep(100)
					waited += 0.1
		except Exception:
			pass

	def _teardown(self):
		if not self._keep_playing:
			self._stop_ours()
			try:
				if control.homeWindow.getProperty(MARK) == self._vid: control.homeWindow.clearProperty(MARK)
			except Exception: pass
		self._restore_mute()

	# used by modules/preview.py for the Full-screen trailer button
	@property
	def keep_playing(self):
		return self._keep_playing

	def fullscreen_candidates(self):
		self._lookup_done.wait(10)
		return list(self._candidates or [])
