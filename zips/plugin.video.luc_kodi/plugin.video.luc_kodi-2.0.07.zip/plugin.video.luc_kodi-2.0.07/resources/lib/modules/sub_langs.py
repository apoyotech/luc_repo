# -*- coding: utf-8 -*-
"""
	luc_kodi Add-on — sub_langs.py (v2.0.04)

	Idiomas del ajuste de subtitulos y lo que cada uno significa para Kodi y
	para OpenSubtitles.

	CASTELLANO Y LATINO SON DOS IDIOMAS. El ajuste ofrece 'Spanish (Spain)' y
	'Spanish (Latin America)' ademas de 'Spanish', que acepta cualquiera de los
	dos. Con una variante elegida, la otra cuenta como otro idioma: no se elige
	esa pista del fichero ni se descarga ese subtitulo.

	De donde sale la variante:
	  - Kodi 22 da el idioma de cada pista en BCP 47. Si el fichero lo trae con
	    region: es-ES es castellano; es-419, es-MX, es-AR... son latino.
	  - Kodi 21 solo da 'spa'. Ahi, y en Kodi 22 sin region, lo dice el nombre
	    de la pista: 'Spanish (Castilian)', 'Latin America', 'Latino'...
	  - OpenSubtitles tiene tres codigos (GET /infos/languages, 12-oct-2026):
	    es = Spanish, sp = Spanish (EU), ea = Spanish (LA). Casi todo lo de
	    Espana se sube como 'es', asi que el castellano busca sp y es, y el
	    latino ea y es; dentro de 'es' decide el nombre del fichero.
	  - Sin ninguna senal la pista es 'neutra': vale para las dos variantes,
	    pero solo si no hay otra que lo diga.

	CODIGOS DE OPENSUBTITLES. No siempre son el ISO 639-1 de Kodi: portugues es
	pt-pt y pt-br, y el chino zh-cn, zh-tw o ze. Con convertLanguage salia 'pt'
	o 'zh', que su API no tiene, y la busqueda volvia vacia.
"""

import re

import xbmc

CAST, LAT = 'CAST', 'LAT'

# Valor del ajuste -> codigos de OpenSubtitles (los de su API, separados por comas).
_OS = {
	'Afrikaans': 'af', 'Albanian': 'sq', 'Arabic': 'ar', 'Armenian': 'hy', 'Basque': 'eu', 'Bengali': 'bn',
	'Bosnian': 'bs', 'Breton': 'br', 'Bulgarian': 'bg', 'Burmese': 'my', 'Catalan': 'ca',
	'Chinese': 'zh-cn,zh-tw,ze', 'Croatian': 'hr', 'Czech': 'cs', 'Danish': 'da', 'Dutch': 'nl',
	'English': 'en', 'Esperanto': 'eo', 'Estonian': 'et', 'Finnish': 'fi', 'French': 'fr', 'Galician': 'gl',
	'Georgian': 'ka', 'German': 'de', 'Greek': 'el', 'Hebrew': 'he', 'Hindi': 'hi', 'Hungarian': 'hu',
	'Icelandic': 'is', 'Indonesian': 'id', 'Italian': 'it', 'Japanese': 'ja', 'Kazakh': 'kk', 'Khmer': 'km',
	'Korean': 'ko', 'Latvian': 'lv', 'Lithuanian': 'lt', 'Luxembourgish': 'lb', 'Macedonian': 'mk',
	'Malay': 'ms', 'Malayalam': 'ml', 'Manipuri': 'ma', 'Mongolian': 'mn', 'Montenegrin': 'me',
	'Norwegian': 'no', 'Occitan': 'oc', 'Persian': 'fa', 'Polish': 'pl', 'Portuguese': 'pt-pt',
	'Portuguese(Brazil)': 'pt-br', 'Romanian': 'ro', 'Russian': 'ru', 'Serbian': 'sr', 'Sinhalese': 'si',
	'Slovak': 'sk', 'Slovenian': 'sl', 'Spanish': 'es,sp,ea', 'Spanish (Spain)': 'sp,es',
	'Spanish (Latin America)': 'ea,es', 'Swahili': 'sw', 'Swedish': 'sv', 'Syriac': 'sy', 'Tagalog': 'tl',
	'Tamil': 'ta', 'Telugu': 'te', 'Thai': 'th', 'Turkish': 'tr', 'Ukrainian': 'uk', 'Urdu': 'ur'}

_VARIANT_OF_SETTING = {'Spanish (Spain)': CAST, 'Spanish (Latin America)': LAT}
_OS_VARIANT = {'sp': CAST, 'ea': LAT}

# Nombre de una pista del fichero. 'eu' y 'la' sueltos solo cuentan aqui, entre
# parentesis o solos ('Spanish (LA)'), nunca dentro de un titulo.
_LAT_NAME = re.compile(r'latin|latam|latino|hispanoam|mexic|argentin|colombi|\(la\)|\blat\b|\b419\b', re.I)
_CAST_NAME = re.compile(r'castil|castell|espa[nñ]a|\bspain\b|europe|iberi|\(eu\)|\(es\)|\(spain\)', re.I)
# Nombre de un fichero de OpenSubtitles: lo mismo sin los codigos cortos.
_LAT_FILE = re.compile(r'latin|latam|latino|hispanoam|mexic', re.I)
_CAST_FILE = re.compile(r'castil|castell|espa[nñ]a|\bspain\b', re.I)


def split(value):
	"""'Spanish (Spain)' -> ('Spanish', 'CAST'). El resto -> (valor, None)."""
	value = (value or '').strip()
	var = _VARIANT_OF_SETTING.get(value)
	return ('Spanish', var) if var else (value, None)


def os_codes(value):
	"""Codigos para el parametro languages= de OpenSubtitles."""
	value = (value or '').strip()
	if value in _OS:
		# Su API pide los codigos en orden alfabetico (si no, redirige a la URL
		# ordenada). El orden no decide nada: la preferencia la pone rank().
		return ','.join(sorted(_OS[value].split(',')))
	try:
		return xbmc.convertLanguage(value, xbmc.ISO_639_1) or value
	except Exception:
		return value


def file_code(value):
	"""Codigo para TemporarySubs.<codigo>.srt, del que Kodi saca el idioma de
	la pista: el ISO 639-1 del idioma base ('es' en las dos variantes)."""
	base = split(value)[0]
	try:
		code = xbmc.convertLanguage(base.replace('(', ' (') if ' (' not in base else base, xbmc.ISO_639_1)
	except Exception:
		code = ''
	return code or os_codes(value).split(',')[0][:2]


def stream_variant(language, name=''):
	"""CAST, LAT o None para una pista de Kodi (idioma BCP 47 o ISO 639-2 y nombre)."""
	tag = (language or '').strip().lower().replace('_', '-')
	if tag.startswith('es-'):
		return CAST if tag == 'es-es' else LAT
	n = name or ''
	if _LAT_NAME.search(n): return LAT
	if _CAST_NAME.search(n): return CAST
	return None


def file_variant(fname, os_language=''):
	"""CAST, LAT o None para un resultado de OpenSubtitles (su codigo y su nombre)."""
	var = _OS_VARIANT.get((os_language or '').strip().lower())
	if var:
		return var
	n = fname or ''
	if _LAT_FILE.search(n): return LAT
	if _CAST_FILE.search(n): return CAST
	return None


def rank(var, want_var):
	"""2 = es la variante pedida, 1 = no dice cual es, 0 = es la otra (se descarta)."""
	if not want_var:
		return 1
	if var is None:
		return 1
	return 2 if var == want_var else 0
