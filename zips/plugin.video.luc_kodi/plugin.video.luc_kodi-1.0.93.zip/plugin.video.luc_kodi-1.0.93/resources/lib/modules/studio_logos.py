# -*- coding: utf-8 -*-
"""
	luc_kodi Add-on
	Channel and studio logos from the "Studio Icons - Coloured" pack
	(resource.images.studios.coloured, Team Kodi), served from GitHub.

	The Networks, Originals and streaming menus used to load their logos from
	postimg.cc and imgur.com: free image hosts with no guaranteed edge and
	hotlink throttling, which is what made those menus paint slowly. GitHub's
	raw CDN is fast and steady, and Kodi keeps each logo in its own thumbnail
	cache after the first time.

	Only logos that still point at postimg or imgur are replaced; logos that
	come from TMDb or ship inside the add-on stay as they are. The table maps
	each menu name to its file in the pack, and every entry was checked by eye:
	names whose file in the pack shows a different channel (City in Canada,
	Showcase in Australia, Paramount Network) are left out and keep their
	current logo.
"""

from urllib.parse import quote

BASE = 'https://raw.githubusercontent.com/TrainAgain2/resource.images.studios.coloured/master/resources/'
_SLOW_HOSTS = ('i.postimg.cc', 'postimg.cc', 'i.imgur.com', 'imgur.com')

_FILES = {
	'A&E': 'Aande.png',
	'ABC': 'ABC.png',
	'ABC (AU)': 'ABC Au.png',
	'ABC (US)': 'ABC (US).png',
	'ABC Family': 'ABCFamily.png',
	'AHC': 'ahc.png',
	'AMC': 'AMC.png',
	'AMC+': 'AMC+.png',
	'AT-X': 'AT-X.png',
	'AXN': 'Axn.png',
	'Acorn TV': 'Acorn TV.png',
	'Adult Swim': 'Adult Swim.png',
	'Amazon': 'Amazon.png',
	'Amazon Prime Video': 'Amazon Prime Video.png',
	'Animal Planet': 'Animal Planet.png',
	'Animax': 'Animax.png',
	'Apple TV+': 'Apple TV+.png',
	'Audience': 'Audience.png',
	'BBC America': 'BBC America.png',
	'BBC Four': 'BBC Four.png',
	'BBC One': 'BBC One.png',
	'BBC Three': 'BBC Three.png',
	'BBC Two': 'BBC Two.png',
	'BET': 'Bet.png',
	'Blackpills': 'Blackpills.png',
	'Bravo': 'Bravo!.png',
	'CBC': 'CBC.png',
	'CBS': 'CBS.png',
	'CBS All Access': 'CBS All Access.png',
	'CNBC': 'CNBC.png',
	'CTV': 'CTV.png',
	'CW': 'CW.png',
	'Cartoon Network': 'Cartoon Network.png',
	'Channel 4': 'Channel4.png',
	'Channel 5': 'Channel 5.png',
	'Cinemax': 'Cinemax.png',
	'Comedy Central': 'ComedyCentral.png',
	'Crackle': 'Crackle.png',
	'DC Universe': 'DC Universe.png',
	'Discovery Channel': 'Discovery Channel.png',
	'Discovery ID': 'Id.png',
	'Discovery+': 'Discovery+.png',
	'Disney Channel': 'Disney Channel.png',
	'Disney XD': 'Disney Xd.png',
	'Disney+': 'Disney+.png',
	'E! Entertainment': 'E! Entertainment.png',
	'E4': 'E4.png',
	'Epix': 'EPIX.png',
	'FOX': 'Fox.png',
	'FX': 'FX.png',
	'Fearnet': 'Fear Net.png',
	'Freeform': 'Freeform.png',
	'HBO': 'HBO.png',
	'HBO Max': 'HBO_Max.png',
	'HGTV': 'HGTV.png',
	'Hallmark': 'Hallmark.png',
	'History Channel': 'Historychannel.png',
	'Hulu': 'Hulu.png',
	'ITV': 'ITV.png',
	'Lifetime': 'Lifetime.png',
	'MTV': 'MTV.png',
	'MUBI': 'Mubi.png',
	'NBC': 'NBC.png',
	'National Geographic': 'National Geographic.png',
	'Netflix': 'Netflix.png',
	'Nick Junior': 'Nick Junior.png',
	'Nickelodeon': 'Nickelodeon.png',
	'Nicktoons': 'Nicktoons.png',
	'Oxygen': 'Oxygen.png',
	'PBS': 'Pbs.png',
	'Paramount+': 'Paramount+.png',
	'Peacock': 'Peacock.png',
	'Peacock Premium': 'Peacock.png',
	'Playboy TV': 'Playboy TV.png',
	'Reelz': 'ReelzChannel.png',
	'Showcase': 'Showcase.png',
	'Showcase (CA)': 'Showcase (Ca).png',
	'Showtime': 'Showtime.png',
	'Shudder': 'Shudder.png',
	'Sky Atlantic': 'Sky Atlantic.png',
	'Sky1': 'Sky 1.png',
	'Smithsonian': 'Smithsonian Channel.png',
	'Spike': 'Spike.png',
	'Stan (AU)': 'Stan.png',
	'Starz': 'Starz.png',
	'Sundance': 'SundanceTV.png',
	'Sundance TV': 'SundanceTV.png',
	'Syfy': 'Syfy.png',
	'TBS': 'TBS.png',
	'TCM': 'Tcm.png',
	'TLC': 'TLC.png',
	'TNT': 'TNT.png',
	'TV Land': 'TV Land.png',
	'The CW': 'The CW.png',
	'The Roku Channel': 'The_Roku_Channel.png',
	'Travel Channel': 'Travel Channel.png',
	'USA': 'USA.png',
	'USA Network': 'USA Network.png',
	'VH1': 'VH1.png',
	'Viceland': 'viceland.png',
	'WB': 'WB.png',
	'WE TV': 'WE TV.png',
	'WGN': 'Wgn.png',
	'WGN America': 'WGN-America.png',
	'WWE Network': 'WWE Network.png',
	'YouTube': 'YouTube.png',
	'YouTube Premium': 'YouTube Premium.png',
}


def _is_slow(url):
	try: return str(url).split('/')[2].lower() in _SLOW_HOSTS
	except Exception: return False

def logo(name, current=''):
	"""Pack logo for this menu name when the current one lives on a slow host
	(or is missing); otherwise the current logo unchanged."""
	try:
		filename = _FILES.get(name)
		if filename and (not current or _is_slow(current)):
			return BASE + quote(filename)
	except Exception: pass
	return current

def apply(items):
	"""Same list of (name, id, logo, ...) tuples, with logo resolved by logo()."""
	try: return [(i[0], i[1], logo(i[0], i[2])) + tuple(i[3:]) for i in items]
	except Exception: return items
