# -*- coding: utf-8 -*-
"""
	luc_kodi Add-on — display_test.py (v1.0.63)

	Diagnostico de pantalla. Hermano del test de proveedores, pero al reves:
	aquel sale a la red y tarda minutos; este no toca la red y es instantaneo.

	POR QUE NO ES UN FOLLETO. La tentacion era escribir "4K detectado, por lo
	tanto suben metadatos, fanart, posters, texto e iconos". Eso seria describir
	la INTENCION del codigo, no comprobarla: si manana la cadena se rompe, el
	folleto seguiria diciendo que todo esta bien, porque lo lleva escrito. Un
	test que no puede fallar no sirve de nada.

	Asi que aqui no se describe: se lee lo que hay y se calcula lo que VAN a
	hacer los consumidores con ello, usando las mismas funciones que usan ellos.
	tmdb.effective_level() es literalmente la que decide el tamano de imagen en
	produccion; si se duplicara aqui, el test podria decir una cosa y los menus
	hacer otra, y entonces el test seria peor que no tenerlo.

	QUE COMPRUEBA
	  1. Resolucion GUI de Kodi frente al modo fisico de la pantalla. Una Shield
	     saca 4K con la GUI a 1080p sin avisar a nadie: el addon ve 1080 y sirve
	     artwork pequeno mientras el usuario jura que su tele es 4K.
	  2. Que juego de XML propio se esta usando. El de 2160p NO es el de 1080i
	     estirado: es el mismo diseno con coordenadas, tamanos, bordes y cuerpos
	     de fuente al doble, escritos aparte. Kodi elige carpeta segun la altura
	     de la GUI, asi que con la GUI a 1080p en una tele 4K las ventanas del
	     addon se dibujan con el juego de 1080i y las escala la tele. Los iconos,
	     en cambio, son los MISMOS PNG en ambos casos: lo que cambia es la
	     geometria y el texto, no el arte.
	  3. Nivel efectivo de imagen de TMDb y si FanartTV quedara activo.
	  4. Por donde salio la deteccion (sonda sincrona, hilo de reintentos o
	     tarde) y cuanto tardo. Es el punto donde el primer menu tras un
	     arranque en frio de Android se construye sin artwork bueno.

	Y CADA HALLAZGO TRAE ARREGLO. Lo que se puede corregir cambiando un ajuste
	del addon se aplica desde el propio dialogo; lo que depende de Kodi o del
	dispositivo se explica con el camino exacto a seguir.
"""

import re

import xbmcgui

from resources.lib.modules import control
from resources.lib.modules import log_utils
from resources.lib.modules import gui_resolution

LOGINFO = log_utils.LOGINFO

GREEN = 'ff00fa9a'
RED = 'ffff4444'
# v1.0.63c — el problema no era el TONO, era el BRILLO, y esta medido: sobre
# la fila azul de Kodi el dorado daba 2,2 de contraste y el naranja puro 1,7,
# peor todavia. Ningun naranja de saturacion normal llega a 3:1 ahi, asi que
# buscar "otro naranja" no iba a resolverlo nunca. Solo pasan los tonos MUY
# claros: este melocoton da 3,1 sobre el azul y 12,4 sobre el fondo oscuro.
# Sigue leyendose como aviso y ahora se lee de verdad. La fila seleccionada de
# Kodi es un azul claro, y sobre ella cualquier color de brillo medio se pierde
# porque hay poca diferencia de luminosidad, sea dorado, sea naranja puro. Un
# color solo se lee sobre la fila azul Y sobre el fondo oscuro si es CLARO. De
# ahi que el aviso pase a un naranja palido y el gris de texto se aclare: no se
# ha cambiado de color, se ha subido el brillo. El gris oscuro se queda solo
# para la vineta de un proveedor apagado, que es una forma, no texto.
GREY = 'ffdfe4e7'
DIM = 'ff888888'

# v1.0.63d — reparto definitivo: el DATO va en verde de la casa, la PROSA que
# lo acompana en gris claro. Antes el dato heredaba el gris y quedaba del mismo
# color que la explicacion, con lo que la vista no tenia donde agarrarse. Ahora
# el ojo salta de dato en dato bajando la lista y solo se para a leer el texto
# cuando algo no cuadra.
# v1.0.63b — el aviso vuelve a ser naranja, pero otro naranja. El anterior
# (fdb515) tiraba a dorado, un tono vecino del azul de la fila seleccionada, y
# encima de ella se apagaba. Este es naranja puro: al ser el complementario del
# azul destaca sobre la fila activa y sigue leyendose sobre el fondo oscuro.
# Rojo queda reservado para lo que falla de verdad; naranja es "mira esto".
ATTN = 'ffffe0b2'

_4K = gui_resolution._4K_HEIGHT_THRESHOLD


DOT = '●'


def _color(text, col):
	return '[COLOR %s]%s[/COLOR]' % (col, text)


def _physical_mode():
	"""Modo real de salida, tal y como lo reporta Kodi. Devuelve (ancho, alto,
	texto crudo). En Android el infolabel suele traer '3840x2160 - Full Screen'
	aunque la GUI este a 1080p, que es justo la discrepancia que buscamos."""
	raw = ''
	try:
		raw = control.infoLabel('System.ScreenResolution') or ''
	except Exception:
		pass
	m = re.search(r'(\d{3,5})\s*[xX]\s*(\d{3,5})', raw)
	if not m:
		return 0, 0, raw.strip()
	return int(m.group(1)), int(m.group(2)), raw.strip()


def _gui_size():
	w = h = 0
	try:
		h = int(float(control.infoLabel('System.ScreenHeight') or 0))
	except Exception:
		h = 0
	try:
		w = int(float(control.infoLabel('System.ScreenWidth') or 0))
	except Exception:
		w = 0
	return w, h


def _skin_set(gui_height):
	"""Carpeta de XML que Kodi resolvera para las ventanas del addon."""
	return '2160p' if gui_height >= _4K else '1080i'


def gather():
	"""Recoge el estado. Sin efectos secundarios: no cambia ningun ajuste."""
	gui_w, gui_h = _gui_size()
	phys_w, phys_h, phys_raw = _physical_mode()

	# El flag ya escrito por gui_resolution durante el arranque; is_4k_display()
	# espera con timeout corto si todavia no estaba.
	try:
		is_4k = gui_resolution.is_4k_display()
	except Exception:
		is_4k = gui_h >= _4K

	path = control.homeWindow.getProperty(gui_resolution.DISPLAY_PATH_FLAG) or 'unknown'
	took = control.homeWindow.getProperty(gui_resolution.DISPLAY_MS_FLAG) or '?'

	try:
		user_level = int(control.setting('tmdb.imageResolutions') or '4')
	except ValueError:
		user_level = 4
	from resources.lib.indexers import tmdb as tmdb_mod
	wide = gui_w >= 2400
	eff = tmdb_mod.effective_level(user_level, is_4k, wide)
	sizes = tmdb_mod.IMAGE_LEVELS[eff]

	return {
		'gui_w': gui_w, 'gui_h': gui_h,
		'phys_w': phys_w, 'phys_h': phys_h, 'phys_raw': phys_raw,
		'is_4k': is_4k,
		'skin_set': _skin_set(gui_h),
		'path': path, 'took': took,
		'user_level': user_level, 'eff_level': eff, 'sizes': sizes, 'wide': wide,
		'fanarttv': control.setting('enable.fanarttv') == 'true',
		'gui_service': control.setting('gui.resolution.enabled') == 'true',
		'gui_target': control.setting('gui.resolution.target') or '0',
	}


# ─────────────────────────────────────────────────────────────────────────────
#  Recomendaciones
#
#  Cada una es (titulo, explicacion, accion). accion=None cuando el arreglo no
#  esta en manos del addon: entonces la explicacion lleva el camino exacto en
#  los ajustes de Kodi, que es mas util que un boton que no puede hacer nada.
# ─────────────────────────────────────────────────────────────────────────────

def recommendations(st):
	out = []

	# 1. Panel 4K con la GUI a 1080p. El caso de soporte mas comun y el mas
	#    invisible: todo "funciona", solo que a media resolucion.
	if st['phys_h'] >= _4K and st['gui_h'] and st['gui_h'] < _4K:
		if not st['gui_service']:
			out.append((
				'Kodi is running its interface at 1080p on a 4K screen',
				'Your display outputs %dx%d but Kodi draws at %dp, so this add-on '
				'uses its 1080p window layout and smaller artwork. Turning on the '
				'GUI resolution service lets the add-on switch Kodi to 2160p on '
				'startup.' % (st['phys_w'], st['phys_h'], st['gui_h']),
				[('gui.resolution.enabled', 'true'), ('gui.resolution.target', '1')]))
		elif st['gui_target'] != '1':
			out.append((
				'GUI resolution service is on but targeting 1080p',
				'Your display is 4K and the service is enabled, but its target is '
				'set to 1080p, so it keeps Kodi at the lower resolution.',
				[('gui.resolution.target', '1')]))
		else:
			out.append((
				'4K display, 1080p interface, service already set correctly',
				'The service is on and targeting 2160p, so Kodi should switch on '
				'the next start. If it does not, Kodi itself is refusing the mode: '
				'check Settings > System > Display > Resolution.',
				None))

	# 2. Nivel de imagen que no aprovecha la pantalla.
	if st['is_4k'] and st['eff_level'] < 3:
		out.append((
			'Artwork is not using the full resolution your screen can show',
			'A 4K screen was detected but image quality resolves to %s posters and '
			'%s fanart. Setting image quality to Auto lets it follow the screen '
			'instead of a fixed level.' % (st['sizes']['poster'], st['sizes']['fanart']),
			[('tmdb.imageResolutions', '4')]))

	# 3. Deteccion tardia: el primer menu pudo construirse antes de tiempo, y
	#    entonces la metacache guarda URLs de artwork pequeno que persisten.
	if st['path'] in ('thread', 'late'):
		out.append((
			'Screen detection did not answer immediately at startup',
			'The display driver took %s ms to report a size, so menus opened during '
			'that window may have cached small artwork URLs. Clearing the metadata '
			'cache rebuilds them: Settings > Cache > Clear metadata cache.'
			% st['took'],
			None))

	# 4. FanartTV en 4K se auto-activa; conviene decirlo, porque el ajuste
	#    seguira mostrandose apagado y parece un fallo.
	if st['is_4k'] and not st['fanarttv']:
		out.append((
			'FanartTV is switched off in settings but active anyway',
			'On a 4K screen the add-on turns FanartTV on by itself to use the extra '
			'high-resolution art. Nothing to fix — the settings toggle just does not '
			'reflect it.',
			None))

	return out


def _report_rows(st):
	rows = []

	gui = '%dx%d' % (st['gui_w'], st['gui_h']) if st['gui_h'] else 'not reported'
	phys = st['phys_raw'] or 'not reported'
	mismatch = bool(st['phys_h'] >= _4K and st['gui_h'] and st['gui_h'] < _4K)
	rows.append((
		'Screen',
		'Kodi interface: %s   Display output: %s' % (
			_color(gui, ATTN if mismatch else GREEN), _color(phys, GREEN))))

	rows.append((
		'Detected as',
		'%s   %s' % (
			_color('4K' if st['is_4k'] else '1080p or lower', GREEN),
			_color('(detection path: %s, %s ms)' % (st['path'], st['took']), GREY))))

	# El punto que mas se malinterpreta. La version anterior describia el
	# COMO ("double coordinates, font bodies") en vez del QUE, y encima se
	# cortaba por ancho. Ahora dice que hay dos versiones, cual te ha tocado y
	# por que, que es lo unico que el usuario necesita saber.
	if st['skin_set'] == '2160p':
		layout_text = '%s — %s' % (
			_color('2160p', GREEN),
			_color("you are getting the 4K version of this add-on's own screens. "
			       'Menus, text and spacing are drawn at full size instead of a '
			       '1080p layout blown up to fit.', GREY))
	else:
		layout_text = '%s — %s' % (
			_color('1080i', GREEN),
			_color('this add-on carries two versions of its own screens, one built '
			       'for 1080p and one for 4K, and Kodi picks by the resolution the '
			       'interface runs at. Yours is on the 1080p one.', GREY))
	rows.append(("This add-on's own screens", layout_text))

	level_names = {0: 'Low', 1: 'Medium', 2: 'High', 3: 'Original', 4: 'Auto'}
	rows.append((
		'Artwork quality',
		'Setting: %s   In use: posters %s, fanart %s, stills %s' % (
			_color(level_names.get(st['user_level'], '?'), GREEN),
			_color(st['sizes']['poster'], GREEN if st['eff_level'] >= 3 else ATTN),
			st['sizes']['fanart'], st['sizes']['still'])))

	rows.append((
		'FanartTV',
		_color('on', GREEN) if (st['fanarttv'] or st['is_4k'])
		else _color('off', GREY)))

	return rows


def run():
	try:
		st = gather()
	except Exception:
		log_utils.error()
		control.okDialog(message='Could not read the display information.')
		return

	recs = recommendations(st)
	control.log('[ luc_kodi ] display_test: gui=%sx%s phys=%sx%s is_4k=%s skin=%s '
	            'level=%s->%s path=%s recs=%d'
	            % (st['gui_w'], st['gui_h'], st['phys_w'], st['phys_h'], st['is_4k'],
	               st['skin_set'], st['user_level'], st['eff_level'], st['path'],
	               len(recs)), LOGINFO)

	items = []
	applicable = [r for r in recs if r[2]]
	if applicable:
		head = xbmcgui.ListItem(
			_color('[B]Apply the %d recommended setting%s[/B]'
			       % (len(applicable), '' if len(applicable) == 1 else 's'), GREEN),
			offscreen=True)
		head.setLabel2('Changes only this add-on\'s own settings. '
		               'Everything else below is explained but left alone.')
		items.append(head)

	for title, text in _report_rows(st):
		li = xbmcgui.ListItem('%s  [B]%s[/B]' % (_color(DOT, GREY), title),
		                      offscreen=True)
		li.setLabel2(text)
		items.append(li)

	if not recs:
		li = xbmcgui.ListItem(_color('[B]Nothing to change[/B]', GREEN), offscreen=True)
		li.setLabel2('Your display, your interface resolution and your artwork '
		             'settings already agree with each other.')
		items.append(li)
	for title, text, action in recs:
		li = xbmcgui.ListItem('%s  %s' % (
			_color(DOT, ATTN if action else GREY),
			_color('[B]%s[/B]' % title, ATTN if action else GREY)), offscreen=True)
		li.setLabel2(text)
		items.append(li)

	choice = xbmcgui.Dialog().select('Display test', items, useDetails=True)
	if applicable and choice == 0:
		_apply(applicable)


def _apply(applicable):
	changed = []
	for title, _text, action in applicable:
		for sid, value in action:
			try:
				control.setSetting(sid, value)
				changed.append(sid)
			except Exception:
				log_utils.error()
	if not changed:
		control.okDialog(message='Nothing could be changed.')
		return
	control.log('[ luc_kodi ] display_test: applied %s' % ', '.join(changed), LOGINFO)
	# La resolucion GUI solo se toca al arrancar, y el artwork ya cacheado
	# conserva las URLs viejas. Decirlo aqui evita el "no ha hecho nada".
	control.okDialog(
		heading='Display test',
		message='Applied %d setting%s.[CR][CR]If the interface resolution changed, '
		        'restart Kodi for it to take effect. Artwork already cached keeps '
		        'its old size until you clear the metadata cache.'
		        % (len(changed), '' if len(changed) == 1 else 's'))
