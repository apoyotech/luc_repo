# -*- coding: utf-8 -*-
"""
	luc_kodi Add-on — modules/release_info.py

	Puts what the chosen release claims about itself into the one field every
	skin is guaranteed to draw during playback: the synopsis.

	Why this way, after two dead ends
	--------------------------------
	Attaching stream details to the ListItem does nothing here. Confirmed on
	device: during full screen playback ListItem.* resolves to nothing at all,
	because there is no container, and the VideoPlayer.* labels a skin does
	read are filled by the player itself. There is no way in.

	Drawing our own information window does not reach every setup either.
	Skins in the Arctic family draw their information inside VideoOSD.xml
	rather than as a separate window, so there is nothing to intercept, and on
	a touch screen there is no Info key to catch.

	What is left is the synopsis, and it works precisely because it is not
	clever: VideoPlayer.Plot comes from the metadata we hand Kodi, every skin
	shows it, and it needs no key, no window and no keymap.

	The cost is real and worth stating: this writes into the film's synopsis.
	That is why it is off by default, why the line is clearly marked as coming
	from the release name rather than from Kodi, and why it goes at the end
	where it can be ignored.

	Only flags Kodi cannot report are worth the intrusion. ATMOS, DTS-X,
	DTS-HD MA, TrueHD, REMUX, BluRay and WEB have no infolabel anywhere in
	Kodi; resolution and codec do, and any skin already has them from the
	first frame, so repeating those would be noise.
"""

from resources.lib.modules import control
from resources.lib.modules import log_utils

NAME_PROP    = 'luc_kodi.release.name'
FLAGS_PROP   = 'luc_kodi.release.flags'
SIZE_PROP    = 'luc_kodi.release.size'
QUALITY_PROP = 'luc_kodi.release.quality'
_ALL_PROPS = (NAME_PROP, FLAGS_PROP, SIZE_PROP, QUALITY_PROP)

HEAD_COLOR = 'FF00FA9A'
DATA_COLOR = 'FFD39886'

# Flags with no Kodi infolabel anywhere. On their own they justify writing
# into a synopsis at all.
EXCLUSIVE = ('ATMOS', 'DTS-X', 'DTS-HD MA', 'DTS-HD', 'DOLBY-TRUEHD', 'DD-EX',
				'REMUX', 'BLURAY', 'DVD', 'WEB', 'HDTV', 'PDTV', 'SCR', 'HDRIP',
				'3D', 'MULTI-LANG', 'HC', 'WITH SUBS', 'SUBS', 'ADS')

# Container names. Never shown: knowing a file is an MKV tells nobody anything
# about how it will look or sound.
CONTAINERS = ('MKV', 'AVI', 'WMV', 'MPEG')

# getFileType() counts channels; people think in speaker layouts. 8CH and 7.1
# are the same thing, but sitting next to a skin's own '7.1' badge they read
# as two different claims.
#
# Only these four exist. source_utils has no token for 2.1 (AUDIO_2CH matches
# 2.0 and stereo, never 2.1), so a 2.1 release produces no channel flag at all
# and none is invented here.
CHANNEL_LAYOUTS = {'8CH': '7.1', '7CH': '6.1', '6CH': '5.1', '2CH': '2.0'}


def enabled():
	return control.setting('player.info.release') == 'true'


def remember(item):
	"""Called at resolve time. play_source() receives only the resolved URL,
	and a debrid link keeps none of the release name, size or quality."""
	if not isinstance(item, dict):
		return
	try:
		home = control.homeWindow
		home.setProperty(NAME_PROP, str(item.get('name') or item.get('name_info') or ''))
		home.setProperty(QUALITY_PROP, str(item.get('quality') or ''))
		home.setProperty(SIZE_PROP, str(item.get('size') or ''))

		from resources.lib.modules.source_utils import getFileType
		if item.get('name_info'):
			flags = getFileType(name_info=item.get('name_info'))
		else:
			flags = getFileType(url=item.get('url'))
		home.setProperty(FLAGS_PROP, flags or '')
	except Exception:
		log_utils.error()


def context():
	home = control.homeWindow
	return {'name':    home.getProperty(NAME_PROP),
			'flags':   home.getProperty(FLAGS_PROP),
			'size':    home.getProperty(SIZE_PROP),
			'quality': home.getProperty(QUALITY_PROP)}


def forget():
	for prop in _ALL_PROPS:
		try:
			control.homeWindow.clearProperty(prop)
		except Exception:
			pass


def full_detail():
	"""'1' = show everything the release states, '0' = only what Kodi cannot
	report itself."""
	return control.setting('player.info.release.detail') != '0'


def _flag_list(flags, full=None):
	"""getFileType() returns ' A / B / C'. Split it, exclusive flags first.

	Whether to keep the rest is a real question with no universal answer. Kodi
	does hold the codec, the HDR flavour and the channel count from the first
	frame, so on a skin that draws them the release line would just repeat
	what is already on screen. But plenty of skins draw none of it during
	playback, and then dropping them means the information exists nowhere.
	This was hardcoded to drop them, which was wrong for exactly that case.
	Now it is a setting, and the default keeps them.

	Container names are always dropped: MKV or AVI says nothing useful."""
	if not flags:
		return []
	full = full_detail() if full is None else full
	parts = [part.strip() for part in flags.split('/') if part.strip()]
	parts = [p for p in parts if p not in CONTAINERS]
	parts = [CHANNEL_LAYOUTS.get(p, p) for p in parts]
	exclusive = [p for p in parts if p in EXCLUSIVE]
	if not full:
		return exclusive
	# Exclusive first, then the rest in the order getFileType emitted them,
	# which already runs picture before sound.
	return exclusive + [p for p in parts if p not in EXCLUSIVE]


def line(ctx=None):
	"""The single line appended to the synopsis, or '' when there is nothing
	worth saying. Never invents: absent means absent."""
	ctx = context() if ctx is None else ctx
	bits = []
	if ctx.get('quality'):
		bits.append(ctx['quality'])
	bits.extend(_flag_list(ctx.get('flags')))
	# 4K already says 2160p; drop the duplicate the parser adds for some names.
	if ctx.get('quality') == '4K' and '2160P' in [b.upper() for b in bits[1:]]:
		bits = [bits[0]] + [b for b in bits[1:] if b.upper() != '2160P']
	size = ctx.get('size')
	if size:
		try:
			bits.append('%.2f GB' % float(size))
		except Exception:
			bits.append(str(size))
	if not bits:
		return ''
	separator = ' [COLOR %s]\u00b7[/COLOR] ' % HEAD_COLOR
	return ('[COLOR %s][B]RELEASE[/B][/COLOR]  %s'
			% (HEAD_COLOR, separator.join('[COLOR %s]%s[/COLOR]' % (DATA_COLOR, b) for b in bits)))


def announce():
	"""One line per playback saying whether this is even switched on.

	Written because three different builds went out numbered 1.0.66 and a log
	could not be told apart from another. A log should never leave you
	guessing which build produced it."""
	try:
		log_utils.log('[ luc_kodi ] release_info: player.info.release = %s, detail = %s'
					% ('ON' if enabled() else 'OFF',
						'FULL' if full_detail() else 'EXCLUSIVE-ONLY'), level=log_utils.LOGINFO)
	except Exception:
		pass


def append_to_plot(item, meta):
	"""Re-write the plot with the release line at the end. Called after
	infoTagger(), so it overwrites what that just set rather than racing it."""
	if not enabled():
		return False
	try:
		suffix = line()
		if not suffix:
			return False
		plot = ((meta or {}).get('plot') or '').strip()
		combined = '%s\n\n%s' % (plot, suffix) if plot else suffix

		if control.KODI_VERSION < 20:
			item.setInfo(type='video', infoLabels={'plot': combined})
		else:
			item.getVideoInfoTag().setPlot(combined)
		log_utils.log('[ luc_kodi ] release_info: %s' % suffix, level=log_utils.LOGINFO)
		return True
	except Exception:
		log_utils.error()
		return False
