# -*- coding: utf-8 -*-
"""
	luc_kodi Add-on
	Assistant welcome window (v2.0.14) - centred over the main menu, see
	modules/assistant.py. Close and Check again only.
"""

import threading
import time

import xbmc

from resources.lib.modules import control
from resources.lib.modules import assistant
from resources.lib.modules import system_status as st
from resources.lib.windows.base import BaseDialog

BUTTONS_ID = 9100
CHECK_ID = 9101
CLOSE_ID = 9102
PROGRESS_ID = 9110
AUTOCLOSE = {'1': 10, '2': 20, '3': 30}   # Settings > Personal Assistant > Close automatically after


class AssistantWelcomeXML(BaseDialog):
	def __init__(self, *args, **kwargs):
		BaseDialog.__init__(self, args)
		self.snap = kwargs.get('snapshot') or {}
		self._alive = True
		self._testing = False
		self._refreshing = False
		self._touched = False
		self._checked = False
		self._done = self._total = 0
		self._monitor = xbmc.Monitor()
		self._lock = threading.RLock()

	# ───────── lifecycle ─────────
	def run(self):
		self.doModal()
		self._alive = False
		self.clearProperties()

	def onInit(self):
		try:
			snap = self.snap or assistant.snapshot()
			self.setProperty('as.icon', snap.get('icon') or '')
			self.setProperty('as.greeting', snap.get('greeting') or '')
			self._apply_accounts(snap.get('accounts') or [])
			self._apply_scrapers(snap.get('scrapers') or assistant.scrapers_view(None))
			self.setProperty('as.testing', '')
			self.setFocusId(CHECK_ID)
		except Exception:
			from resources.lib.modules import log_utils
			log_utils.error()
		# expiry dates: from the 6-hour cache, or asked now without holding the window
		self._spawn(self._refresh_accounts, False, track=True)
		if not self.snap.get('has_test'): self._spawn(self._count_enabled)
		secs = AUTOCLOSE.get(assistant._get('assistant.welcome.autoclose'))
		if secs: self._spawn(self._autoclose, secs)

	def _spawn(self, target, *args, **kwargs):
		t = threading.Thread(target=target, args=args)
		t.daemon = True
		t.start()
		if kwargs.get('track'): st.track(t)
		return t

	def close(self):
		self._alive = False
		BaseDialog.close(self)

	def _autoclose(self, secs):
		end = time.time() + secs
		while self._alive and time.time() < end:
			if self._monitor.waitForAbort(0.25): return
		# the user is reading or a check is running: stay
		if self._alive and not self._touched and not self._testing: self.close()

	# ───────── accounts ─────────
	def _apply_accounts(self, accts):
		with self._lock:
			for i in range(1, st.MAX_SLOTS + 1):
				a = accts[i - 1] if i <= len(accts) else None
				self.setProperty('as.acc%d.logo' % i, a['logo'] if a else '')
				self.setProperty('as.acc%d.dot' % i, a['dot'] if a else '')
			line1, line2 = assistant.accounts_view(accts)
			self.setProperty('as.acc.line1', line1)
			self.setProperty('as.acc.line2', line2)

	def _refresh_accounts(self, force):
		if self._refreshing: return
		self._refreshing = True
		try:
			days = st.debrid_days(force)
			if self._alive: self._apply_accounts(st.accounts(days))
		except Exception:
			from resources.lib.modules import log_utils
			log_utils.error()
		finally:
			self._refreshing = False

	# ───────── scrapers ─────────
	def _apply_scrapers(self, view):
		with self._lock:
			self.setProperty('as.scr.dot', view.get('dot') or st.GREY)
			self.setProperty('as.scr.line', view.get('line') or '')
			self.setProperty('as.scr.sub', view.get('sub') or '')

	def _count_enabled(self):
		count = assistant.enabled_count()
		# Check again owns the block from the moment it is pressed: a late count
		# must not paint over a test result or the cooldown message
		if self._alive and not self._checked and count is not None:
			self._apply_scrapers(assistant.scrapers_view(None, enabled_count=count))

	def _check_again(self):
		self._checked = True
		self._spawn(self._refresh_accounts, True, track=True)
		if self._testing: return
		wait = st.test_blocked()
		if wait:
			last = assistant.last_scrapers()
			view = assistant.scrapers_view(last) if last else assistant.scrapers_view(None)
			view['sub'] = '[COLOR %s]%s[/COLOR]' % (st.ORANGE, control.lang(400976) % wait)
			self._apply_scrapers(view)
			return
		entries = []
		try: entries = st.enabled_providers()
		except Exception:
			from resources.lib.modules import log_utils
			log_utils.error()
		if not entries:
			self._apply_scrapers(assistant.scrapers_view(None, enabled_count=0))
			return
		self._testing, self._done, self._total = True, 0, len(entries)
		self._progress()
		self.setProperty('as.testing', 'true')
		self._spawn(st.run_test, entries, self._on_row, self._on_done, track=True)

	def _progress(self):
		self._apply_scrapers({'dot': st.GREY, 'line': control.lang(400972) % (min(self._done, self._total), self._total),
							  'sub': '[COLOR FF7878A0]%s[/COLOR]' % control.lang(400973)})
		try: self.getControlProgress(PROGRESS_ID).setPercent(int(self._done * 100.0 / max(1, self._total)))
		except Exception: pass

	def _on_row(self, name, view):
		with self._lock:
			self._done += 1
			if self._alive and self._testing: self._progress()

	def _on_done(self, text, views):
		# saved first: the window may already be closed
		last = st.last_test()
		if last: assistant.save_disk(last)
		self._testing = False
		if not self._alive: return
		self.setProperty('as.testing', '')
		self._apply_scrapers(assistant.scrapers_view(last))

	# ───────── input ─────────
	def onClick(self, controlID):
		self._touched = True
		try:
			if controlID == CHECK_ID: self._check_again()
			elif controlID == CLOSE_ID: self.close()
		except Exception:
			from resources.lib.modules import log_utils
			log_utils.error()

	def onAction(self, action):
		self._touched = True
		try:
			if action.getId() in self.closing_actions or action.getId() in self.context_actions:
				self.close()
		except Exception:
			from resources.lib.modules import log_utils
			log_utils.error()
