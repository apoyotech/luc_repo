# -*- coding: utf-8 -*-
"""
	luc_kodi Add-on
	Assistant TV show sheet (v2.0.14) - opened by the search assistant for a TV
	show: seasons, episodes, latest and next episode, and Continue from the
	user's progress. Returns what to do; modules/assistant_search.py does it.
"""

from resources.lib.modules import control
from resources.lib.modules import assistant_search as asr
from resources.lib.windows.base import BaseDialog

CONTINUE_ID = 9401
LATEST_ID = 9402
FIRST_ID = 9403
SEASONS_ID = 9410
ALL_ID = 9421


class AssistantShowXML(BaseDialog):
	def __init__(self, *args, **kwargs):
		BaseDialog.__init__(self, args)
		self.info = kwargs.get('info') or {}
		self.next = kwargs.get('next')
		self.show = self.info.get('show') or {}
		self.result = None
		self._seasons = []

	def run(self):
		self.doModal()
		self.clearProperties()
		return self.result

	def onInit(self):
		try:
			try: icon = control.addonInfo('icon')
			except Exception: icon = ''
			self.setProperty('as.icon', icon)
			self.setProperty('as.poster', self.info.get('poster') or '')
			year = self.info.get('year') or ''
			self.setProperty('as.title', ('%s (%s)' % (self.info.get('title'), year)) if year else self.info.get('title') or '')
			line1, line2 = asr.show_lines(self.show)
			self.setProperty('as.line1', line1)
			self.setProperty('as.line2', line2)
			last = self.show.get('last') or {}
			first = self._first_episode()
			buttons = (
				(CONTINUE_ID, bool(self.next), (control.lang(401029) % asr._code(*self.next)) if self.next else ''),
				(LATEST_ID, bool(last.get('season') and last.get('episode')),
				 (control.lang(401030) % asr._code(last['season'], last['episode'])) if last.get('season') else ''),
				(FIRST_ID, bool(first), control.lang(401031)),
			)
			focus = None
			for cid, show, label in buttons:
				ctl = self.getControl(cid)
				ctl.setLabel(label)
				ctl.setVisible(show)   # set here, not by a visible condition, so the focus can go to it now
				if show and focus is None: focus = cid
			self._fill_seasons()
			self.setFocusId(focus or (SEASONS_ID if self._seasons else ALL_ID))
		except Exception:
			from resources.lib.modules import log_utils
			log_utils.error()

	def _first_episode(self):
		real = sorted(x['season'] for x in self.show.get('seasons') or [] if x['season'] > 0 and x['count'])
		return (real[0], 1) if real else None

	def _fill_seasons(self):
		lst = self.getControl(SEASONS_ID)
		lst.reset()
		self._seasons = []
		items = []
		# seasons with episodes, the specials (season 0) last
		seasons = [x for x in self.show.get('seasons') or [] if x['count']]
		seasons.sort(key=lambda x: (x['season'] == 0, x['season']))
		for x in seasons:
			li = self.make_listitem()
			li.setLabel(control.lang(401034) if x['season'] == 0 else control.lang(401033) % x['season'])
			li.setLabel2(control.lang(401022) if x['count'] == 1 else control.lang(401021) % x['count'])
			items.append(li)
			self._seasons.append(x['season'])
		lst.addItems(items)

	def onClick(self, controlID):
		try:
			if controlID == CONTINUE_ID and self.next: self.result = ('play', self.next[0], self.next[1])
			elif controlID == LATEST_ID:
				last = self.show.get('last') or {}
				self.result = ('play', last['season'], last['episode'])
			elif controlID == FIRST_ID:
				first = self._first_episode()
				if first: self.result = ('play', first[0], first[1])
			elif controlID == SEASONS_ID:
				pos = self.get_position(SEASONS_ID)
				if 0 <= pos < len(self._seasons): self.result = ('season', self._seasons[pos])
			elif controlID == ALL_ID: self.result = ('all',)
			else: return
			if self.result: self.close()
		except Exception:
			from resources.lib.modules import log_utils
			log_utils.error()

	def onAction(self, action):
		try:
			if action.getId() in self.closing_actions or action.getId() in self.context_actions:
				self.result = None
				self.close()
		except Exception:
			from resources.lib.modules import log_utils
			log_utils.error()
