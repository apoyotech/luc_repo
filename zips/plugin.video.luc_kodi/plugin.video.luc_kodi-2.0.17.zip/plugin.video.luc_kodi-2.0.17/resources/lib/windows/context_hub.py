# -*- coding: utf-8 -*-
"""
	luc_kodi Add-on
	Context hub window (v2.0.09) - right side panel,
	see modules/context_hub.py
"""

from resources.lib.windows.base import BaseDialog

LIST_ID = 2000
EXITS_ID = 3000  # grouplist: Back / Exit <subcategory> / Home (v2.0.09)
EXIT_ID = 3001
BACK_ID = 3002
HOME_ID = 3003
INFO_TEXT_ID = 2100  # v2.0.09: Information view (textbox, its scrollbar, button back to the options)
INFO_SCROLL_ID = 2101
INFO_BACK_ID = 2102
SEARCH_ID = 3010  # v2.0.09: Search luc_kodi
ACTION_MOVE_UP, ACTION_MOVE_DOWN = 3, 4
ACTION_PAGE_UP, ACTION_PAGE_DOWN = 5, 6


class ContextHubXML(BaseDialog):
	def __init__(self, *args, **kwargs):
		BaseDialog.__init__(self, args)
		self.entries = kwargs.get('entries') or []
		self.header = kwargs.get('header') or {}
		self.info_loader = kwargs.get('info_loader')
		self.info_mode = False
		self._last_pos = 0
		self.chosen = None
		self.item_list = []
		self.make_items()
		self.set_properties()

	def make_items(self):
		for e in self.entries:
			li = self.make_listitem()
			li.setLabel(e.get('label', ''))
			li.setProperty('kind', e.get('kind', 'action'))
			if e.get('kind') != 'header':
				li.setLabel2(e.get('hint', ''))
				li.setProperty('icon', e.get('icon', 'ctx/ic_dot.png'))
				li.setProperty('color', e.get('color', 'FFB0B0D0'))
				li.setProperty('tile', e.get('tile', '2EB0B0D0'))
				if e.get('logo'): li.setProperty('logo', e['logo'])
			self.item_list.append(li)

	def set_properties(self):
		for key in ('poster', 'artkind', 'title', 'meta', 'crumb', 'back', 'exit', 'home', 'rating', 'watched', 'progress', 'version'):
			self.setProperty('ctx.%s' % key, self.header.get(key, '') or '')

	def _first_action(self, start=0, step=1):
		i = start
		while 0 <= i < len(self.entries):
			if self.entries[i].get('kind') != 'header': return i
			i += step
		return -1

	def onInit(self):
		try:
			lst = self.getControl(LIST_ID)
			lst.reset()
			lst.addItems(self.item_list)
			first = self._first_action()
			if first >= 0:
				lst.selectItem(first)
				self.setFocusId(LIST_ID)
			elif self._has_exits():
				self.setFocusId(EXITS_ID)
		except Exception:
			from resources.lib.modules import log_utils
			log_utils.error()

	def _has_exits(self):
		return any(self.header.get(k) for k in ('back', 'exit', 'home'))

	def run(self):
		self.doModal()
		self.clearProperties()
		return self.chosen

	def onClick(self, controlID):
		try:
			if controlID == LIST_ID:
				pos = self.get_position(LIST_ID)
				if 0 <= pos < len(self.entries) and self.entries[pos].get('kind') != 'header':
					if self.entries[pos].get('builtin') == '__info__':
						self._show_info(True)
						return
					self.chosen = self.entries[pos].get('builtin')
					self.close()
			elif controlID == INFO_BACK_ID:
				self._show_info(False)
			elif controlID == SEARCH_ID:
				self.chosen = '__search__'
				self.close()
			elif controlID in (EXIT_ID, BACK_ID, HOME_ID):
				self.chosen = {EXIT_ID: '__exit__', BACK_ID: '__back__', HOME_ID: '__home__'}[controlID]
				self.close()
		except Exception:
			from resources.lib.modules import log_utils
			log_utils.error()

	def _show_info(self, on):
		"""Swap the options list for the Information view and back."""
		from xbmc import sleep
		if on:
			if self.getProperty('ctx.infotext') == '':
				self.setProperty('ctx.infotext', ' ')
				try:
					from resources.lib.modules import control
					control.busy()
					text = self.info_loader() if self.info_loader else ''
				except Exception:
					text = ''
				finally:
					try: control.hide()
					except Exception: pass
				self.setProperty('ctx.infotext', text or ' ')
			self.setProperty('ctx.mode', 'info')
			self.info_mode = True
			sleep(60)  # let the info controls become visible before focusing them
			self.setFocusId(INFO_BACK_ID)
		else:
			self.setProperty('ctx.mode', '')
			self.info_mode = False
			sleep(60)
			self.setFocusId(LIST_ID)

	def onAction(self, action):
		try:
			action_id = action.getId()
			if self.info_mode and action_id in self.closing_actions and action_id != 13:
				self._show_info(False)  # Back from the Information view returns to the options
				return
			if action_id in self.closing_actions or action_id in self.context_actions:
				self.close()
				return
			# v2.0.09: the search button sits above the exit row; with no exit row
			# (main menu, widgets) it is reached straight from the options
			focus = self.getFocusId()
			if focus == SEARCH_ID and action_id == ACTION_MOVE_DOWN and not self._has_exits():
				self.setFocusId(LIST_ID if not self.info_mode else INFO_BACK_ID)
				return
			if focus == LIST_ID:
				pos_now = self.get_position(LIST_ID)
				# only when Up is pressed while ALREADY on the first option (Kodi
				# did not move), not on the press that just arrived there
				if action_id == ACTION_MOVE_UP and not self._has_exits() and pos_now == 0 and self._last_pos == 0:
					self.setFocusId(SEARCH_ID)
					return
				self._last_pos = pos_now
			# header rows are labels, not options: hop over them
			if self.getFocusId() == LIST_ID and action_id in (ACTION_MOVE_UP, ACTION_MOVE_DOWN, ACTION_PAGE_UP, ACTION_PAGE_DOWN):
				pos = self.get_position(LIST_ID)
				if 0 <= pos < len(self.entries) and self.entries[pos].get('kind') == 'header':
					step = -1 if action_id in (ACTION_MOVE_UP, ACTION_PAGE_UP) else 1
					target = self._first_action(pos + step, step)
					if target < 0:
						if step < 0 and self._has_exits():
							self.setFocusId(EXITS_ID)
							return
						target = self._first_action(pos - step, -step)
					if target >= 0: self.getControl(LIST_ID).selectItem(target)
		except Exception:
			from resources.lib.modules import log_utils
			log_utils.error()
