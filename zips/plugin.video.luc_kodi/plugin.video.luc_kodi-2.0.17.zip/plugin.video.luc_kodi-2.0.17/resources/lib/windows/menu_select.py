# -*- coding: utf-8 -*-
"""
	luc_kodi Add-on
	menu_select.py (v2.0.16) - window of modules/menu_panel.py: the menus opened
	from the context panel, in the style of the Assistant's welcome window.

	v2.0.17: the window fits the menu. Its height follows the number of options
	(one row per option, up to seven; more scroll), and its width is the
	smallest of three steps (s 960, m 1180, l 1400) that holds the longest
	option and the header: menu name, the title's line and the title. Kodi
	cannot measure text, so the width is estimated from the characters (see
	text_px) with some room to spare; a label that still does not fit scrolls
	when focused, as before. menu_select.xml draws the rows in the three widths
	and each row shows the one in its ListItem.Property(size) (a Window.Property
	is not seen inside a list's rows); the panel, shadow, header, footer and the
	group that holds the scrollbar are resized and moved here in onInit, and the
	panel stays centred. Kodi's Python cannot reach a scrollbar control, so the
	scrollbar sits in group 9617 and the group is moved. Every control is set on
	its own: one that cannot be changed does not stop the others.
"""

from resources.lib.windows.base import BaseDialog

LIST_ID = 9601
SCROLL_GROUP_ID = 9617  # holds scrollbar 9602
GROUP_ID, SHADOW_ID, PANEL_ID = 9600, 9610, 9611
MENU_ID, META_ID, TITLE_ID = 9612, 9613, 9614
FOOT_LEFT_ID, FOOT_RIGHT_ID = 9615, 9616
PROPS = ('menu', 'meta', 'title', 'poster', 'artkind', 'version')

# geometry in 1080i coordinates (2160p is the same x2, see menu_select.xml)
SCREEN_W, SCREEN_H = 1920, 1080
TIERS = (('s', 960), ('m', 1180), ('l', 1400))  # panel width per step
XML_WIDTH = 1400                                  # what the XML declares (largest step)
ROW_H, ROWS_MAX = 66, 7
LIST_TOP = 236
PAD_X = 60            # panel side margin
HEADER_X = 162        # menu name and the title's line start right of the poster
ROW_TEXT_X = 76       # label start inside a row (after the icon tile)
ROW_TEXT_END = 40     # room after the text inside a row
FOOTER_GAP = 10       # list bottom -> footer
BOTTOM = 52           # footer -> panel bottom
SHADOW = 44           # shadow around the panel

# Approximate glyph widths (in em) of the skin's sans fonts and the em of each
# font this window uses, measured on the 2.0.16 window: an estimate with 8% to
# spare, so a step is never chosen too narrow for the text it has to hold.
EM = {'font13': 31.0, 'font12': 26.0, 'font30_title': 34.0}
SPARE = 1.08
_NARROW = set("iljI.,:;'!|·")
_SEMI = set('frt()[]-/')


def text_units(text):
	total = 0.0
	for c in text or '':
		if c == ' ': total += 0.26
		elif c in _NARROW: total += 0.27
		elif c in _SEMI: total += 0.35
		elif c in 'MW': total += 0.88
		elif c == 'm': total += 0.85
		elif c == 'w': total += 0.74
		elif c.isupper(): total += 0.66
		elif c.isdigit(): total += 0.57
		else: total += 0.55
	return total


def text_px(text, font):
	return text_units(text) * EM[font] * SPARE


def layout(labels, header):
	"""Size of the window for these options and header: {'size', 'width', 'height', 'rows'}."""
	header = header or {}
	need = [PAD_X + ROW_TEXT_X + text_px(label, 'font13') + ROW_TEXT_END + PAD_X for label in labels]
	need.append(HEADER_X + text_px((header.get('menu') or '').upper(), 'font12') + PAD_X)
	need.append(HEADER_X + text_px(header.get('meta') or '', 'font12') + PAD_X)
	need.append(PAD_X + text_px(header.get('title') or '', 'font30_title') + PAD_X)
	widest = max(need)
	size, width = TIERS[-1]
	for s, w in TIERS:
		if widest <= w:
			size, width = s, w
			break
	rows = max(1, min(len(labels), ROWS_MAX))
	height = LIST_TOP + rows * ROW_H + FOOTER_GAP + BOTTOM
	return {'size': size, 'width': width, 'height': height, 'rows': rows}


class MenuSelectXML(BaseDialog):
	def __init__(self, *args, **kwargs):
		BaseDialog.__init__(self, args)
		self.entries = kwargs.get('entries') or []
		self.header = kwargs.get('header') or {}
		self.chosen = -1
		self.item_list = []
		try: self.geo = layout([e.get('label', '') for e in self.entries], self.header)
		except Exception: self.geo = None
		size = self.geo['size'] if self.geo else 'l'
		for e in self.entries:
			li = self.make_listitem()
			li.setLabel(e.get('label', ''))
			li.setProperty('icon', e.get('icon', 'ctx/ic_dot.png'))
			li.setProperty('color', e.get('color', 'FFB0B0D0'))
			li.setProperty('tile', e.get('tile', '2EB0B0D0'))
			li.setProperty('size', size)
			self.item_list.append(li)
		for key in PROPS:
			self.setProperty('ms.%s' % key, self.header.get(key, '') or '')

	def _set(self, cid, x=None, y=None, w=None, h=None):
		"""Move or resize one control; False if Kodi does not let it."""
		try:
			c = self.getControl(cid)
			if x is not None: c.setPosition(x, y)
			if w is not None: c.setWidth(w)
			if h is not None: c.setHeight(h)
			return True
		except Exception:
			from resources.lib.modules import log_utils
			log_utils.log('[luc_kodi] menu_select: control %s not resized' % cid, level=log_utils.LOGDEBUG)
			return False

	def _fit(self):
		"""Resize and centre the panel (onInit). The rows already carry their width
		(ListItem.Property(size)), so the panel, list, scrollbar and footer are set
		to that same width here."""
		g = self.geo
		if not g: return
		try: declared = self.getControl(PANEL_ID).getWidth()
		except Exception: return  # nothing can be resized: the XML size stays, rows of the same step inside it
		scale = 2.0 if declared >= XML_WIDTH * 1.5 else 1.0  # 2160p folder chosen by Kodi
		def px(v): return int(round(v * scale))
		w, h = g['width'], g['height']
		inner = w - 2 * PAD_X
		half = inner // 2
		footer_top = LIST_TOP + g['rows'] * ROW_H + FOOTER_GAP
		self._set(GROUP_ID, px((SCREEN_W - w) // 2), px((SCREEN_H - h) // 2))
		self._set(SHADOW_ID, w=px(w + 2 * SHADOW), h=px(h + 2 * SHADOW))
		self._set(PANEL_ID, w=px(w), h=px(h))
		for cid in (MENU_ID, META_ID): self._set(cid, w=px(w - HEADER_X - (PAD_X - 2)))
		self._set(TITLE_ID, w=px(inner))
		self._set(LIST_ID, w=px(inner))
		self._set(SCROLL_GROUP_ID, px(w - SHADOW), px(LIST_TOP))
		self._set(FOOT_LEFT_ID, px(PAD_X), px(footer_top), w=px(half))
		self._set(FOOT_RIGHT_ID, px(PAD_X + half), px(footer_top), w=px(half))

	def onInit(self):
		self._fit()
		try:
			lst = self.getControl(LIST_ID)
			lst.reset()
			lst.addItems(self.item_list)
			lst.selectItem(0)
			self.setFocusId(LIST_ID)
		except Exception:
			from resources.lib.modules import log_utils
			log_utils.error()

	def run(self):
		self.doModal()
		self.clearProperties()
		return self.chosen

	def onClick(self, controlID):
		try:
			if controlID == LIST_ID:
				pos = self.get_position(LIST_ID)
				if 0 <= pos < len(self.entries):
					self.chosen = pos
					self.close()
		except Exception:
			from resources.lib.modules import log_utils
			log_utils.error()

	def onAction(self, action):
		try:
			if action.getId() in self.closing_actions or action.getId() in self.context_actions:
				self.chosen = -1
				self.close()
		except Exception:
			from resources.lib.modules import log_utils
			log_utils.error()
