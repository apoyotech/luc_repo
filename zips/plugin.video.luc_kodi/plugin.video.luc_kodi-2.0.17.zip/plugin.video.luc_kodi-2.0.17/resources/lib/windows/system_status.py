# -*- coding: utf-8 -*-
"""
	luc_kodi Add-on
	System status window (v2.0.12) - same right side panel as the context hub,
	see modules/system_status.py
"""

import threading

import xbmc

from resources.lib.modules import control
from resources.lib.modules import system_status as st
from resources.lib.windows.base import BaseDialog

EXITS_ID = 3000   # grouplist: Back / Check again / Home
BACK_ID = 3002
HOME_ID = 3003
CHECK_ID = 3004
SEARCH_ID = 3010
RAM_BAR_ID = 4010
LIST_IDS = {'a0': 4300, 'a1': 4301, 'a2': 4302, 'n': 4303}
ACTION_MOVE_UP, ACTION_MOVE_DOWN = 3, 4
ACTION_PAGE_UP, ACTION_PAGE_DOWN = 5, 6


class SystemStatusXML(BaseDialog):
	def __init__(self, *args, **kwargs):
		BaseDialog.__init__(self, args)
		self.from_panel = bool(kwargs.get('from_panel'))
		self.result = None
		self._alive = True
		self._testing = False
		self._api_testing = False
		self._refreshing = False
		self._api_rows, self._scr_rows = [], []
		self._api_sum = self._scr_sum = ''
		self._pending_apis = None
		self._layout = 'a0'
		self._items = []
		self._by_name = {}
		self._monitor = xbmc.Monitor()
		self._lock = threading.RLock()

	# ───────── lifecycle ─────────
	def run(self):
		self.doModal()
		self._alive = False
		self.clearProperties()
		return self.result

	def onInit(self):
		try:
			info = st.header_info()
			for key in ('meta', 'profile', 'version'):
				self.setProperty('status.%s' % key, info.get(key, ''))
			self._apply_device(st.device_snapshot())
			# accounts straight from the settings; expiry dates and the update
			# check come from the 6-hour cache, or from the thread below
			cached = st._read_cache(st.PROP_DEBRID, st.CACHE_TTL) or {}
			self._apply_accounts(st.accounts(cached.get('days') or {}))
			upd = st._read_cache(st.PROP_UPDATE, st.CACHE_TTL)
			if upd: self.setProperty('status.update', upd.get('label') or '')
			self._show_last_test()
			self.setFocusId(CHECK_ID)
		except Exception:
			from resources.lib.modules import log_utils
			log_utils.error()
		self._spawn(self._live)
		self._spawn(self._refresh_accounts, False, track=True)

	def _spawn(self, target, *args, **kwargs):
		t = threading.Thread(target=target, args=args)
		t.daemon = True
		t.start()
		if kwargs.get('track'): st.track(t)
		return t

	def close(self):
		self._alive = False
		BaseDialog.close(self)

	# ───────── live device values ─────────
	def _apply_device(self, snap):
		for key in ('ram', 'ram2', 'screen', 'screen2', 'refresh', 'refresh2'):
			self.setProperty('status.%s' % key, snap.get(key, ''))
		self.setProperty('status.aspect', ('\u00b7 %s' % snap['aspect']) if snap.get('aspect') else '')
		try: self.getControlProgress(RAM_BAR_ID).setPercent(snap.get('ram_pct', 0))
		except Exception: pass

	def _live(self):
		while self._alive and not self._monitor.abortRequested():
			if self._monitor.waitForAbort(1.0) or not self._alive: break
			try: self._apply_device(st.device_snapshot())
			except Exception: pass

	# ───────── accounts ─────────
	def _apply_accounts(self, accts):
		with self._lock:
			for i in range(1, st.MAX_SLOTS + 1):
				a = accts[i - 1] if i <= len(accts) else None
				self.setProperty('status.acc%d.logo' % i, a['logo'] if a else '')
				self.setProperty('status.acc%d.dot' % i, a['dot'] if a else '')
			warns = st.warnings(accts)
			self.setProperty('status.warn1', warns[0] if len(warns) > 0 else '')
			self.setProperty('status.warn2', warns[1] if len(warns) > 1 else '')
			self._set_layout(st.layout_key(accts, warns))

	def _refresh_accounts(self, force):
		if self._refreshing: return
		self._refreshing = True
		try:
			days = st.debrid_days(force)
			if self._alive: self._apply_accounts(st.accounts(days))
			label = st.update_label(force)
			if self._alive: self.setProperty('status.update', label)
		except Exception:
			from resources.lib.modules import log_utils
			log_utils.error()
		finally:
			self._refreshing = False

	# ───────── APIs and scrapers: one list, a header row before each section ─────────
	def _set_layout(self, key):
		if key not in LIST_IDS: key = 'a0'
		changed = key != self._layout or not self.getProperty('status.layout')
		self._layout = key
		self.setProperty('status.layout', key)
		if changed:
			self._fill_list()
			# the list on screen changed (a warning line came or went): keep the focus on it
			try:
				if self.getFocusId() in LIST_IDS.values(): self.setFocusId(LIST_IDS[key])
			except Exception: pass

	def _list(self):
		return self.getControl(LIST_IDS[self._layout])

	def _fill_list(self):
		try:
			lst = self._list()
			lst.reset()
			if self._items: lst.addItems(self._items)
		except Exception:
			from resources.lib.modules import log_utils
			log_utils.error()

	def _paint(self, li, view):
		# The colours travel inside the text. A textcolor taken from
		# $INFO[ListItem.Property(...)] is resolved against the FOCUSED item, so
		# every row was painted in the colours of the selected one (seen on the
		# tablet while testing); BBCode in the label is resolved per row.
		li.setProperty('dot', view.get('dot', ''))
		note, value = view.get('note', ''), view.get('value', '')
		li.setProperty('note', ('[COLOR %s]%s[/COLOR]' % (view.get('notecolor') or st.GREY, note)) if note else '')
		li.setProperty('value', ('[COLOR %s]%s[/COLOR]' % (view.get('dot') or st.GREY, value)) if value else '')

	def _header(self, sid, text):
		li = self.make_listitem()
		li.setLabel(control.lang(sid))
		li.setProperty('kind', 'header')
		li.setProperty('note', text or '')
		return li

	def _rebuild(self):
		"""APIs header + rows, Scrapers header + rows."""
		with self._lock:
			self._items, self._by_name = [], {}
			self._api_head = self._header(48188, self._api_sum)
			self._items.append(self._api_head)
			for name, label, view in self._api_rows:
				li = self.make_listitem(); li.setLabel(label); self._paint(li, view)
				self._items.append(li)
				if name: self._by_name['api:' + name] = li
			self._scr_head = self._header(48159, self._scr_sum)
			self._items.append(self._scr_head)
			for name, label, view in self._scr_rows:
				li = self.make_listitem(); li.setLabel(label); self._paint(li, view)
				self._items.append(li)
				if name: self._by_name['scr:' + name] = li
			self._fill_list()

	def _set_sum(self, section, text):
		if section == 'api':
			self._api_sum = text
			head = getattr(self, '_api_head', None)
		else:
			self._scr_sum = text
			head = getattr(self, '_scr_head', None)
		if head is not None and self._alive: head.setProperty('note', text or '')

	def _show_last_test(self):
		last = st.last_api_test()
		if last and last.get('rows'):
			self._api_rows = [(r.get('name'), r.get('label') or r.get('name'), r) for r in last['rows']]
			self._api_sum = last.get('sum') or ''
		else:
			self._api_rows = [(k, n, dict(st.pending_view(), note=control.lang(48191))) for k, n, f in st.active_apis()]
			self._api_sum = ''
		last = st.last_test()
		if last and last.get('rows'):
			self._scr_rows = [(r.get('name'), r.get('label') or st.display_name(r.get('name') or ''), r) for r in last['rows']]
			self._scr_sum = last.get('sum') or ''
		else:
			self._scr_rows = [('', control.lang(48171), dict(st.pending_view(), note=control.lang(48186)))]
			self._scr_sum = ''
		self._rebuild()

	def _check_again(self):
		self._spawn(self._refresh_accounts, True, track=True)
		rebuild = False
		if not self._api_testing:
			apis = st.active_apis()
			if apis:
				self._api_testing, self._api_done, self._api_total = True, 0, len(apis)
				self._api_rows = [(k, n, st.pending_view()) for k, n, f in apis]
				self._api_sum = control.lang(48172) % (0, self._api_total)
				rebuild = True
				self._pending_apis = apis
		start_scr = None
		if not self._testing:
			wait = st.test_blocked()
			if wait:
				self._scr_sum = control.lang(48183) % wait
				rebuild = True
			else:
				try: entries = st.enabled_providers()
				except Exception:
					from resources.lib.modules import log_utils
					log_utils.error()
					entries = []
				if not entries:
					self._scr_rows = [('', control.lang(48184), dict(st.pending_view(), note=''))]
					self._scr_sum = ''
				else:
					self._testing, self._done, self._total = True, 0, len(entries)
					self._scr_rows = [(n, st.display_name(n), st.pending_view()) for n, c in entries]
					self._scr_sum = control.lang(48172) % (0, self._total)
					start_scr = entries
				rebuild = True
		if rebuild: self._rebuild()
		apis = getattr(self, '_pending_apis', None)
		if apis:
			self._pending_apis = None
			self._spawn(st.run_api_test, apis, self._on_api_row, self._on_api_done, track=True)
		if start_scr:
			self._spawn(st.run_test, start_scr, self._on_row, self._on_done, track=True)

	@staticmethod
	def _keep(rows, name, view):
		for i, row in enumerate(rows):
			if row[0] == name: rows[i] = (row[0], row[1], view)

	def _on_api_row(self, key, view):
		with self._lock:
			self._keep(self._api_rows, key, view)
			li = self._by_name.get('api:' + key)
			if li is not None: self._paint(li, view)
			self._api_done += 1
			if self._api_testing: self._set_sum('api', control.lang(48172) % (min(self._api_done, self._api_total), self._api_total))

	def _on_api_done(self, text, views):
		self._api_testing = False
		self._api_rows = [(v['name'], v['label'], v) for v in views]
		self._set_sum('api', text)

	def _on_row(self, name, view):
		with self._lock:
			self._keep(self._scr_rows, name, view)
			li = self._by_name.get('scr:' + name)
			if li is not None: self._paint(li, view)
			self._done += 1
			if self._testing: self._set_sum('scr', control.lang(48172) % (min(self._done, self._total), self._total))

	def _on_done(self, text, views):
		self._testing = False
		self._scr_rows = [(v['name'], v['label'], v) for v in views]
		self._set_sum('scr', text)

	# ───────── input ─────────
	def _leave(self, result):
		self.result = result
		self.close()

	def onClick(self, controlID):
		try:
			if controlID == CHECK_ID: self._check_again()
			elif controlID == BACK_ID: self._leave('back' if self.from_panel else None)
			elif controlID == HOME_ID: self._leave('home')
			elif controlID == SEARCH_ID: self._leave('__search__')
		except Exception:
			from resources.lib.modules import log_utils
			log_utils.error()

	def _is_header(self, pos):
		return 0 <= pos < len(self._items) and self._items[pos].getProperty('kind') == 'header'

	def _first_row(self, start=0, step=1):
		i = start
		while 0 <= i < len(self._items):
			if not self._is_header(i): return i
			i += step
		return -1

	def onAction(self, action):
		try:
			action_id = action.getId()
			if action_id in self.closing_actions:
				self._leave('back' if self.from_panel and action_id != 13 else None)
				return
			if action_id in self.context_actions:
				self._leave(None)
				return
			focus = self.getFocusId()
			# from the buttons, Down goes to the first row of the list on screen
			if action_id == ACTION_MOVE_DOWN and focus in (BACK_ID, CHECK_ID, HOME_ID) and self._items:
				first = self._first_row()
				if first >= 0:
					self._list().selectItem(first)
					self.setFocusId(LIST_IDS[self._layout])
				return
			# the section titles are rows of the list, not options: hop over them
			if focus == LIST_IDS[self._layout] and action_id in (ACTION_MOVE_UP, ACTION_MOVE_DOWN, ACTION_PAGE_UP, ACTION_PAGE_DOWN):
				pos = self.get_position(focus)
				if self._is_header(pos):
					step = -1 if action_id in (ACTION_MOVE_UP, ACTION_PAGE_UP) else 1
					target = self._first_row(pos + step, step)
					if target < 0 and step < 0:
						self.setFocusId(EXITS_ID)
						return
					if target < 0: target = self._first_row(pos - step, -step)
					if target >= 0: self._list().selectItem(target)
		except Exception:
			from resources.lib.modules import log_utils
			log_utils.error()
