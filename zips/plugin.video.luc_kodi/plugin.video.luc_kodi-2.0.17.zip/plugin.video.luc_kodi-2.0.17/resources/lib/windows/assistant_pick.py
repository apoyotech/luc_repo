# -*- coding: utf-8 -*-
"""
	luc_kodi Add-on
	Assistant picker (v2.0.14) - the assistant's own window to pick one title
	(the films of a saga, titles that share a name, Gemini's answers) or one
	episode of a season. Replaces Kodi's select dialog in the search assistant.
	items: [{'label', 'label2', 'art', 'props'}]; mode 'posters' or 'stills'.
	v2.0.14: under each poster only label2 (the year); the full title, props
	'meta' and 'plot' of the focused item go in the info strip below the row.
	run() -> index of the item picked, or None.
	v2.0.14: ratings(ref) -> {'r.imdb', 'r.rt', 'r.mc', 'r.tmdb', 'r.trakt'} is asked
	in the background for the item the focus rests on (0.35 s), once per item,
	and shown as icons in the strip.
"""

import threading
import time

import xbmc

from resources.lib.modules import control
from resources.lib.windows.base import BaseDialog

LISTS = {'posters': 9501, 'stills': 9502}
STRIPS = {'posters': 9511, 'stills': 9512}


class AssistantPickXML(BaseDialog):
	def __init__(self, *args, **kwargs):
		BaseDialog.__init__(self, args)
		self.items = kwargs.get('items') or []
		self.heading = kwargs.get('heading') or ''
		self.sub = kwargs.get('sub') or ''
		self.hint = kwargs.get('hint') or ''
		self.mode = kwargs.get('mode') if kwargs.get('mode') in LISTS else 'posters'
		self.preselect = kwargs.get('preselect') or 0
		self.ratings = kwargs.get('ratings')
		self.choice = None
		self._lis = []
		self._alive = True
		self._threads = []

	def run(self):
		self.doModal()
		self._alive = False
		for t in self._threads: t.join(1.5)   # a rating still on its way is not left running
		self.clearProperties()
		return self.choice

	def close(self):
		self._alive = False
		BaseDialog.close(self)

	def onInit(self):
		try:
			try: icon = control.addonInfo('icon')
			except Exception: icon = ''
			self.setProperty('as.icon', icon)
			self.setProperty('as.heading', self.heading)
			self.setProperty('as.sub', self.sub)
			self.setProperty('as.hint', self.hint)
			art_key = 'poster' if self.mode == 'posters' else 'thumb'
			lid = LISTS[self.mode]
			for mode, other in LISTS.items():
				# shown here and not by a visible condition, so the focus can go to it now
				self.getControl(other).setVisible(mode == self.mode)
				self.getControl(STRIPS[mode]).setVisible(mode == self.mode)
			lst = self.getControl(lid)
			lst.reset()
			items = []
			for it in self.items:
				li = self.make_listitem()
				li.setLabel(it.get('label') or '')
				li.setLabel2(it.get('label2') or '')
				if it.get('art'): li.setArt({art_key: it['art']})
				for k, v in (it.get('props') or {}).items(): li.setProperty(k, v or '')
				items.append(li)
			lst.addItems(items)
			self._lis = items
			self.setFocusId(lid)
			if 0 < self.preselect < len(items): lst.selectItem(self.preselect)
			if self.ratings and self.mode == 'posters' and items:
				t = threading.Thread(target=self._rate_focused, args=(lid,))
				t.daemon = True
				t.start()
				self._threads.append(t)
		except Exception:
			from resources.lib.modules import log_utils
			log_utils.error()

	def _rate_focused(self, lid):
		"""Ratings of the title the focus rests on, once per title."""
		monitor = xbmc.Monitor()
		done, last, since = set(), -1, time.time()
		while self._alive and not monitor.abortRequested():
			try: pos = self.getControl(lid).getSelectedPosition()
			except Exception: pos = -1
			if pos != last: last, since = pos, time.time()
			elif 0 <= pos < len(self._lis) and pos not in done and time.time() - since >= 0.35:
				done.add(pos)
				ref = self.items[pos].get('ref')
				if ref is not None:
					props = self.ratings(ref) or {}
					if not self._alive: break
					for k, v in props.items(): self._lis[pos].setProperty(k, v)
			if monitor.waitForAbort(0.15): break

	def onClick(self, controlID):
		if controlID != LISTS[self.mode]: return
		pos = self.get_position(controlID)
		if 0 <= pos < len(self.items):
			self.choice = pos
			self.close()

	def onAction(self, action):
		try:
			if action.getId() in self.closing_actions or action.getId() in self.context_actions:
				self.choice = None
				self.close()
		except Exception:
			from resources.lib.modules import log_utils
			log_utils.error()
