# -*- coding: utf-8 -*-
"""
	luc_kodi Add-on
	Assistant guided results (v2.0.14) - shown by sources.play when the search
	assistant asked for it (select=2): how many sources, from how many scrapers,
	how many in each resolution, and which one to play.
"""

from resources.lib.modules import control
from resources.lib.modules import assistant_search as asr
from resources.lib.windows.base import BaseDialog

QUALITY_IDS = {9301: '4K', 9302: '1080p', 9303: '720p', 9304: 'SD'}
BEST_ID = 9311
ALL_ID = 9312
TILE_PROPS = {'4K': 1, '1080p': 2, '720p': 3, 'SD': 4}


def _ink(bucket):
	try:
		from resources.lib.modules import color_norm
		return color_norm.header_ink('1080P' if bucket == '1080p' else '720P' if bucket == '720p' else bucket)
	except Exception:
		return 'FFD2D2E4'


class AssistantResultsXML(BaseDialog):
	def __init__(self, *args, **kwargs):
		BaseDialog.__init__(self, args)
		self.items = kwargs.get('items') or []
		self.meta = kwargs.get('meta') or {}
		self.title = kwargs.get('title') or self.meta.get('title') or ''
		self.year = kwargs.get('year') or self.meta.get('year') or ''
		self.missing = kwargs.get('missing')
		self.choice = None

	def run(self):
		self.doModal()
		self.clearProperties()
		return self.choice

	def onInit(self):
		try:
			try: icon = control.addonInfo('icon')
			except Exception: icon = ''
			self.setProperty('as.icon', icon)
			self.setProperty('as.poster', self.meta.get('poster') or '')
			season, episode = self.meta.get('season'), self.meta.get('episode')
			if season not in (None, '') and episode not in (None, ''):
				# v2.0.14: an episode -> 'Silo  ·  S03E01  ·  Who Are You?'
				show = self.meta.get('tvshowtitle') or self.title
				name = self.meta.get('title') or ''
				head = '%s  ·  %s' % (show, asr._code(season, episode))
				if name and name != show: head = '%s  ·  %s' % (head, name)
				self.setProperty('as.title', head)
			else:
				self.setProperty('as.title', ('%s (%s)' % (self.title, self.year)) if self.year else self.title)
			line, counts = asr.summary(self.items)
			self.setProperty('as.line1', control.lang(401004))
			self.setProperty('as.line2', line)
			if self.missing:
				self.setProperty('as.note', '[COLOR FFFFAA44]%s[/COLOR]' % (control.lang(401010) % self.missing))
			for b, n in TILE_PROPS.items():
				c = counts.get(b, 0)
				ink = _ink(b)
				self.setProperty('as.t%d.count' % n, ('[COLOR %s]%d[/COLOR]' % (ink, c)) if c else '')
				self.setProperty('as.t%d.label' % n, (control.lang(401005) % b) if c else '')
			first = None
			for cid, b in sorted(QUALITY_IDS.items()):
				c = counts.get(b, 0)
				self.setProperty('as.q%d' % (cid - 9300), ('%s  ·  %d' % (b, c)) if c else '')
				# v2.0.14: shown or hidden here and not by a visible condition, which
				# Kodi applies a frame later: focusing 9301 then was refused in the log
				try: self.getControl(cid).setVisible(bool(c))
				except Exception: pass
				if c and first is None: first = cid
			focus = first or BEST_ID
			last = asr.remembered()
			if last == 'best': focus = BEST_ID
			elif last:
				for cid, b in QUALITY_IDS.items():
					if b == last and counts.get(b): focus = cid
			self.setFocusId(focus)
		except Exception:
			from resources.lib.modules import log_utils
			log_utils.error()

	def onClick(self, controlID):
		if controlID in QUALITY_IDS: self.choice = QUALITY_IDS[controlID]
		elif controlID == BEST_ID: self.choice = 'best'
		elif controlID == ALL_ID: self.choice = 'all'
		else: return
		self.close()

	def onAction(self, action):
		try:
			if action.getId() in self.closing_actions or action.getId() in self.context_actions:
				self.choice = None
				self.close()
		except Exception:
			from resources.lib.modules import log_utils
			log_utils.error()
