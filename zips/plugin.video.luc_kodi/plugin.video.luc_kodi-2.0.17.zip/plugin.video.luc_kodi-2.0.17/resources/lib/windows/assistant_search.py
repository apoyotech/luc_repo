# -*- coding: utf-8 -*-
"""
	luc_kodi Add-on
	Assistant search hub (v2.0.14) - the Search entry of the main menu, see
	modules/assistant_search.py. The window only collects what the user wants;
	the search itself runs after it closes.
"""

from resources.lib.modules import control
from resources.lib.modules import assistant_search as asr
from resources.lib.windows.base import BaseDialog

FIELD_ID = 9201
SCOPE_IDS = {9211: 'all', 9212: 'movie', 9213: 'tv'}
SCOPE_LABELS = {'all': 400989, 'movie': 400990, 'tv': 400991}
RECENT_ID = 9220
# button id -> (kind, action): folders open as listings, scripts run (they ask with Kodi's keyboard)
CLASSIC = {
	9231: ('folder', 'movieSearch', 33042),
	9232: ('folder', 'tvSearch', 33043),
	9233: ('script', 'moviePerson', 33044),
	9234: ('script', 'tvPerson', 33045),
	9235: ('folder', 'tools_searchNavigator', 400999),
}
DOT = '[COLOR FF00D488]●[/COLOR]  '


class AssistantSearchXML(BaseDialog):
	def __init__(self, *args, **kwargs):
		BaseDialog.__init__(self, args)
		self.result = None
		self.scope = 'all'
		self._recent = []

	def run(self):
		self.doModal()
		self.clearProperties()
		return self.result

	def onInit(self):
		try:
			try: icon = control.addonInfo('icon')
			except Exception: icon = ''
			self.setProperty('as.icon', icon)
			for cid, (kind, action, sid) in CLASSIC.items():
				self.getControl(cid).setLabel(control.lang(sid))
			self._paint_scopes()
			self._fill_recent()
			self.setFocusId(FIELD_ID)
		except Exception:
			from resources.lib.modules import log_utils
			log_utils.error()

	def _paint_scopes(self):
		for cid, scope in SCOPE_IDS.items():
			text = control.lang(SCOPE_LABELS[scope])
			self.getControl(cid).setLabel((DOT + text) if scope == self.scope else text)

	def _fill_recent(self):
		self._recent = asr.history()
		lst = self.getControl(RECENT_ID)
		lst.reset()
		items = []
		for h in self._recent:
			li = self.make_listitem()
			li.setLabel(h['term'])
			li.setLabel2(control.lang(401015) if h.get('kind') == 'ask' else control.lang(401016))
			items.append(li)
		if not items:
			li = self.make_listitem()
			li.setLabel('[COLOR FF7878A0]%s[/COLOR]' % control.lang(400994))
			li.setProperty('empty', 'true')
			items.append(li)
		lst.addItems(items)

	def _ask(self):
		k = control.keyboard('', control.lang(400986))
		k.doModal()
		text = k.getText().strip() if k.isConfirmed() else ''
		if text:
			self.result = ('query', text, self.scope)
			self.close()

	def onClick(self, controlID):
		try:
			if controlID == FIELD_ID: self._ask()
			elif controlID in SCOPE_IDS:
				self.scope = SCOPE_IDS[controlID]
				self._paint_scopes()
			elif controlID == RECENT_ID:
				pos = self.get_position(RECENT_ID)
				if 0 <= pos < len(self._recent):
					h = self._recent[pos]
					self.result = ('query', h['term'], h.get('scope') or 'all')
					self.close()
			elif controlID in CLASSIC:
				kind, action, sid = CLASSIC[controlID]
				self.result = (kind, action)
				self.close()
		except Exception:
			from resources.lib.modules import log_utils
			log_utils.error()

	def onAction(self, action):
		try:
			if action.getId() in self.closing_actions or action.getId() in self.context_actions:
				self.close()
		except Exception:
			from resources.lib.modules import log_utils
			log_utils.error()
