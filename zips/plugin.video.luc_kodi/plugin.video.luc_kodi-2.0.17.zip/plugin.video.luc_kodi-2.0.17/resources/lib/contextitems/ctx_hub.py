# -*- coding: utf-8 -*-
"""
	luc_kodi Add-on
	Global context entry "luc_kodi" (addon.xml kodi.context.item, v2.0.09).
	Kodi gives this script a copy of the focused item in sys.listitem; it is
	handed to the plugin through a window property and the plugin opens its
	own panel (modules/context_hub.py). Kept minimal on purpose: it runs in
	its own interpreter, outside the plugin's module path.
"""

import sys
from json import dumps
import xbmc
import xbmcgui


def _tag_value(tag, name):
	try:
		value = getattr(tag, name)()
		return value if value not in (None, -1) else ''
	except Exception:
		return ''


if __name__ == '__main__':
	try:
		li = sys.listitem
		data = {'cm': li.getProperty('luc_kodi.cm'), 'label': li.getLabel()}
		try:  # v2.0.09: Play entry in the panel
			data['path'] = str(li.getPath() or '')
			data['playable'] = 'true' if li.getProperty('IsPlayable') == 'true' else 'false'
		except Exception:
			pass
		try:
			art = li.getArt('poster') or li.getArt('thumb') or li.getArt('icon')
		except Exception:
			art = ''
		data['poster'] = art or ''
		try:
			tag = li.getVideoInfoTag()
			data['title'] = _tag_value(tag, 'getTitle') or data['label']
			data['year'] = _tag_value(tag, 'getYear')
			data['mediatype'] = _tag_value(tag, 'getMediaType')
			data['rating'] = _tag_value(tag, 'getRating')
			data['playcount'] = _tag_value(tag, 'getPlayCount')
			data['duration'] = _tag_value(tag, 'getDuration')
			data['tvshowtitle'] = _tag_value(tag, 'getTVShowTitle')
			data['season'] = _tag_value(tag, 'getSeason')
			data['episode'] = _tag_value(tag, 'getEpisode')
			data['resume'] = _tag_value(tag, 'getResumeTime')
			data['total'] = _tag_value(tag, 'getResumeTimeTotal')
			# v2.0.09: Information view
			data['plot'] = _tag_value(tag, 'getPlot')
			data['premiered'] = _tag_value(tag, 'getPremieredAsW3C') or _tag_value(tag, 'getFirstAiredAsW3C')
			try: data['genre'] = ', '.join(tag.getGenres() or [])
			except Exception: data['genre'] = ''
			try: data['tmdb'] = tag.getUniqueID('tmdb') or ''
			except Exception: data['tmdb'] = ''
		except Exception:
			data['title'] = data['label']
		data['folderpath'] = xbmc.getInfoLabel('Container.FolderPath')
		data['foldername'] = xbmc.getInfoLabel('Container.FolderName')
		data['inVideos'] = 'true' if xbmc.getCondVisibility('Window.IsActive(10025)') else 'false'
		xbmcgui.Window(10000).setProperty('luc_kodi.ctx.payload', dumps(data))
		xbmc.executebuiltin('RunPlugin(plugin://plugin.video.luc_kodi/?action=ctx_Hub)')
	except Exception as e:
		xbmc.log('[ plugin.video.luc_kodi ] ctx_hub: %s' % e, xbmc.LOGWARNING)
