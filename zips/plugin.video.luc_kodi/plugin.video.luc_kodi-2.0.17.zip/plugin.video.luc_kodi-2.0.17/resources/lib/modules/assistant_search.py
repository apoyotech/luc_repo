# -*- coding: utf-8 -*-
"""
	luc_kodi Add-on — assistant_search.py (v2.0.14)

	Personal assistant, second part: the Search category of the main menu.

	  HUB       Search opens its own window: one field for a title or a request
	            in your own words, Look in (Everything / Movies / TV Shows), the
	            recent searches, and the classic searches, which keep working as
	            they did. The context menu search is not touched.

	  TITLE     "Titanic", "Titanic 1997", "play Titanic in 4K": TMDb is asked
	            once; a title that matches exactly is opened straight away. When
	            several titles share the name and none clearly leads (three times
	            the popularity of the next), the user picks one. A movie goes
	            through the normal play pipeline with select=2, which answers
	            with the guided results (sources.play); a TV show opens its
	            seasons.

	  SAGAS     v2.0.14: a title that names a saga (Rambo, Avatar, Minions, Mission:
	            Impossible) lists every film of its TMDb collection in release
	            order, with the one typed selected. "Rambo 2", "Rambo II", "rambo
	            primera parte", "second Avatar" open that film of the saga; a saga
	            with no film of that exact name (Harry Potter) lists its films.
	            TMDb entries with no date and no votes are never a match.

	  TV SHOWS  v2.0.14: a show opens the assistant's own sheet (seasons, episodes,
	            latest and next episode, Continue from your Trakt or SIMKL
	            progress); picking an episode goes through the same guided
	            results. "Silo s3e1", "Silo 3x01", "Silo season 3 episode 1" play
	            that episode; "Silo season 2" lists its episodes.

	  WINDOWS   v2.0.14: every choice is made in the assistant's own picker
	            (posters for titles, pictures for episodes), not in Kodi's select
	            dialog, and listings are opened with Container.Update inside the
	            Videos window. ActivateWindow(...,return) from inside that same
	            window rewrote its history and, after a few searches in a row,
	            the main menu stopped answering.

	  BREADTH   v2.0.14: as many results as the classic search (Settings > Personal
	            Assistant > Title Search limit, TMDb pages of 20). A saga lists
	            its films first and then every other title found; a title opens
	            straight away only when nothing else starts with its name or the
	            query says which one (a year, play ..., in 4K). Otherwise the
	            picker shows them all, the exact title first and selected.
	            The info strip shows the ratings with their icons (TMDb at once;
	            IMDb, Rotten Tomatoes, Metacritic and Trakt through ratings.py,
	            MDBList and OMDb included, for the title the focus rests on).

	  REQUEST   anything that is not a title ("a 90s sci-fi movie with aliens")
	            is read by Gemini (gemini_api, the same intent and TMDb Discover
	            query as AI Search) and its answers open in the assistant's
	            picker with what was understood; the pick goes on like a title.
	            Without keys, or switched off, the classic title search lists
	            what TMDb finds.

	  STATUS    "is everything working?" opens the welcome summary.

	  GUIDED    after scraping: how many sources from how many scrapers, how
	            many in each resolution, and which one to play. The choice
	            starts autoplay with the best source of that resolution.
"""

import json
import re
import time
import unicodedata
from urllib.parse import quote_plus

from resources.lib.modules import control
from resources.lib.modules import log_utils

LOGINFO = log_utils.LOGINFO
SYSADDON = 'plugin://plugin.video.luc_kodi/'
TMDB = 'https://api.themoviedb.org/3'
TMDB_IMG = 'https://image.tmdb.org/t/p/%s%s'
TABLE = 'assistant'
HISTORY_MAX = 8
MAX_TITLE_WORDS = 7
LEAD = 3.0                       # popularity lead that skips the "which one?" question
PROP_QUALITY = 'luc_kodi.assistant.quality'   # quality asked in the query ("... in 4K")
QUALITY_TTL = 600

SCOPES = ('all', 'movie', 'tv')
BUCKETS = ('4K', '1080p', '720p', 'SD')
BUCKET_OF = {'4K': '4K', '1080P': '1080p', '720P': '720p', 'SD': 'SD', 'SCR': 'SD', 'CAM': 'SD'}

QUALITY_WORDS = (
	(r'\b(?:in\s+)?(?:4k|uhd|2160p?)\b', '4K'),
	(r'\b(?:in\s+)?(?:1080p?|full\s*hd|fhd)\b', '1080p'),
	(r'\b(?:in\s+)?720p?\b', '720p'),
)
PLAY_WORDS = r'^(?:please\s+)?(?:play|watch|put\s+on|start|stream|open|pon|ver|reproduce|reproducir)\s+'
STATUS_RE = re.compile(r"\b(?:is\s+everything\s+(?:ok|okay|fine|working|alright)|everything\s+(?:ok|okay|fine|working)|"
					   r"are\s+my\s+(?:accounts|scrapers)\s+(?:ok|working|fine)|"
					   r"(?:accounts|scrapers)\s+(?:ok|working|status)|check\s+(?:my\s+)?(?:accounts|scrapers))\b"
					   r"|^\s*(?:system\s+)?status\s*\??\s*$", re.I)
ARTICLES = r'^(?:the|a|an|el|la|los|las|le|les|il|der|die|das)\s+'
ORDINAL_WORDS = {
	'first': 1, 'one': 1, '1st': 1, 'primera': 1, 'primero': 1, 'uno': 1,
	'second': 2, 'two': 2, '2nd': 2, 'segunda': 2, 'segundo': 2, 'dos': 2,
	'third': 3, 'three': 3, '3rd': 3, 'tercera': 3, 'tercero': 3, 'tres': 3,
	'fourth': 4, 'four': 4, '4th': 4, 'cuarta': 4, 'cuarto': 4, 'cuatro': 4,
	'fifth': 5, 'five': 5, '5th': 5, 'quinta': 5, 'quinto': 5, 'cinco': 5,
	'sixth': 6, 'six': 6, '6th': 6, 'sexta': 6, 'sexto': 6, 'seis': 6,
	'seventh': 7, 'seven': 7, '7th': 7, 'septima': 7, 'septimo': 7, 'siete': 7,
	'eighth': 8, 'eight': 8, '8th': 8, 'octava': 8, 'octavo': 8, 'ocho': 8,
	'ninth': 9, 'nine': 9, '9th': 9, 'novena': 9, 'noveno': 9, 'nueve': 9,
	'tenth': 10, 'ten': 10, '10th': 10, 'decima': 10, 'decimo': 10, 'diez': 10,
}
ROMAN = {'i': 1, 'ii': 2, 'iii': 3, 'iv': 4, 'v': 5, 'vi': 6, 'vii': 7, 'viii': 8, 'ix': 9, 'x': 10}
PART_WORD = r'(?:part|parte|movie|film|pelicula|entrega|chapter|capitulo)'
COLLECTION_WORDS = r'\b(?:collection|coleccion|saga|trilogy|trilogia)\b'
MAX_PARTS = 20
EP_WORD = r'(?:episode|episodio|capitulo|cap|ep|e)'
SEASON_WORD = r'(?:season|temporada|series|serie|t)'


def _log(msg):
	control.log('[ luc_kodi ] assistant search: %s' % msg, LOGINFO)


def L(sid):
	return control.lang(sid)


def _get(sid):
	try: return (control.setting(sid) or '').strip()
	except Exception: return ''


def enabled():
	return _get('assistant.search') != 'false'


# ───────────────────────── words ─────────────────────────
def norm(text):
	"""Title for comparing: no accents, no punctuation, no leading article."""
	text = unicodedata.normalize('NFKD', str(text or '')).encode('ascii', 'ignore').decode('ascii').lower()
	text = text.replace('&', ' and ')
	text = re.sub(r"[^a-z0-9]+", ' ', text).strip()
	return re.sub(ARTICLES, '', text).strip()


def parse(query):
	"""-> {'text', 'year', 'quality', 'play', 'full'} from what the user typed.
	full: the text with the year still in it, for titles that end in one
	(Blade Runner 2049, Wonder Woman 1984)."""
	text = ' '.join(str(query or '').split())
	low = text.lower()
	play = bool(re.match(PLAY_WORDS, low, re.I))
	if play: text = re.sub(PLAY_WORDS, '', text, flags=re.I)
	quality = None
	for pattern, q in QUALITY_WORDS:
		if re.search(pattern, text, re.I):
			quality = quality or q
			text = re.sub(pattern, ' ', text, flags=re.I)
	year = None
	full = re.sub(r'\s+(?:in|en)\s*$', '', ' '.join(text.split()), flags=re.I).strip(' -·,')
	m = re.search(r'[\(\[]?\b(19[0-9]{2}|20[0-9]{2})\b[\)\]]?\s*$', text.strip())
	if m and len(text.strip()) > len(m.group(0)):
		year = int(m.group(1))
		text = text.strip()[:m.start()]
	text = re.sub(r'\s+(?:in|en)\s*$', '', ' '.join(text.split()), flags=re.I).strip(' -·,')
	return {'text': text, 'year': year, 'quality': quality, 'play': play, 'full': full}


def _ordinal(token):
	if token.isdigit():
		n = int(token)
		return n if 0 < n <= 30 else None
	return ORDINAL_WORDS.get(token) or ROMAN.get(token)


def split_ordinal(text):
	"""'Rambo 2', 'Rambo II', 'Rambo part two', 'rambo primera parte',
	'second Avatar', 'primera parte de Rambo' -> ('rambo', n); else (None, None)."""
	t = unicodedata.normalize('NFKD', str(text or '')).encode('ascii', 'ignore').decode('ascii').lower()
	t = ' '.join(re.sub(r'[^a-z0-9]+', ' ', t).split())
	m = re.match(r'^(.+?)\s+(?:%s\s+)?([a-z0-9]+)(?:\s+%s)?$' % (PART_WORD, PART_WORD), t)
	if m:
		n = _ordinal(m.group(2))
		if n and m.group(1).strip(): return m.group(1).strip(), n
	m = re.match(r'^(?:the\s+)?([a-z0-9]+)\s+(?:%s\s+)?(?:(?:of|de|del)\s+)?(.+)$' % PART_WORD, t)
	if m and not m.group(1).isdigit():
		n = _ordinal(m.group(1))
		if n and m.group(2).strip(): return m.group(2).strip(), n
	return None, None


def split_episode(text):
	"""'Silo s3e1', 'Silo 3x01', 'Silo season 3 episode 1', 'silo temporada 3 capitulo 1'
	-> ('silo', 3, 1); 'Silo season 2', 'Silo s2' -> ('silo', 2, None); else (None, None, None)."""
	t = unicodedata.normalize('NFKD', str(text or '')).encode('ascii', 'ignore').decode('ascii').lower()
	t = ' '.join(re.sub(r'[^a-z0-9]+', ' ', t).split())
	for pattern in (r'^(.+?)\s+s\s?(\d{1,2})\s?e\s?(\d{1,3})$', r'^(.+?)\s+(\d{1,2})x(\d{1,3})$',
					r'^(.+?)\s+%s\s?(\d{1,2})\s+%s\s?(\d{1,3})$' % (SEASON_WORD, EP_WORD)):
		m = re.match(pattern, t)
		if m and int(m.group(2)) > 0 and int(m.group(3)) > 0: return m.group(1).strip(), int(m.group(2)), int(m.group(3))
	for pattern in (r'^(.+?)\s+(?:season|temporada)\s?(\d{1,2})$', r'^(.+?)\s+s(\d{1,2})$'):
		m = re.match(pattern, t)
		if m and int(m.group(2)) > 0: return m.group(1).strip(), int(m.group(2)), None
	return None, None, None


def is_status(query):
	return bool(STATUS_RE.search(query or ''))


# ───────────────────────── history ─────────────────────────
def _db():
	from resources.lib.database import cache
	con = cache.get_connection_search()
	con.execute('CREATE TABLE IF NOT EXISTS %s (ID INTEGER PRIMARY KEY AUTOINCREMENT, term TEXT, scope TEXT, kind TEXT)' % TABLE)
	return con


def history(limit=HISTORY_MAX):
	"""-> [{'term', 'scope', 'kind'}] newest first, one per term."""
	out, seen = [], set()
	con = None
	try:
		con = _db()
		for row in con.execute('SELECT term, scope, kind FROM %s ORDER BY ID DESC LIMIT 60' % TABLE).fetchall():
			term = row['term'] if isinstance(row, dict) else row[0]
			key = (term or '').lower()
			if not term or key in seen: continue
			seen.add(key)
			if isinstance(row, dict): out.append({'term': term, 'scope': row.get('scope') or 'all', 'kind': row.get('kind') or ''})
			else: out.append({'term': term, 'scope': row[1] or 'all', 'kind': row[2] or ''})
			if len(out) >= limit: break
	except Exception:
		log_utils.error()
	finally:
		try: con.close()
		except Exception: pass
	return out


def save_history(term, scope, kind):
	con = None
	try:
		con = _db()
		con.execute('DELETE FROM %s WHERE lower(term) = ?' % TABLE, (term.lower(),))
		con.execute('INSERT INTO %s (term, scope, kind) VALUES (?, ?, ?)' % TABLE, (term, scope, kind))
		con.execute('DELETE FROM %s WHERE ID NOT IN (SELECT ID FROM %s ORDER BY ID DESC LIMIT 30)' % (TABLE, TABLE))
		con.commit()
	except Exception:
		log_utils.error()
	finally:
		try: con.close()
		except Exception: pass


# ───────────────────────── TMDb ─────────────────────────
def _tmdb_key():
	from resources.lib.modules import app_keys
	return _get('tmdb.api.key') or app_keys.get('tmdb')


def _tmdb_get(path, **params):
	import requests
	params['api_key'] = _tmdb_key()
	r = requests.get(TMDB + path, params=params, timeout=10)
	r.raise_for_status()
	return r.json()


def _language():
	try: return control.apiLanguage()['tmdb'] or 'en'
	except Exception: return 'en'


def _row(item, kind):
	title = item.get('title') if kind == 'movie' else item.get('name')
	date = (item.get('release_date') if kind == 'movie' else item.get('first_air_date')) or ''
	original = item.get('original_title') if kind == 'movie' else item.get('original_name')
	return {'kind': kind, 'id': item.get('id'), 'title': title or '', 'original': original or '', 'date': date,
			'plot': item.get('overview') or '', 'rating': float(item.get('vote_average') or 0),
			'year': int(date[:4]) if date[:4].isdigit() else None,
			'popularity': float(item.get('popularity') or 0), 'poster': item.get('poster_path') or '',
			'votes': int(item.get('vote_count') or 0)}


def limit():
	"""How many titles a search lists: the classic search's own setting."""
	try: n = int(float(_get('search.page.limit') or 20))
	except Exception: n = 20
	return max(20, min(100, n))


def tmdb_search(text, scope='all', year=None, pages=None):
	"""-> TMDb results as rows, movies and TV shows only, as many pages as the
	Title Search limit asks for (20 per page)."""
	lang = _language()
	pages = pages or max(1, min(5, (limit() + 19) // 20))
	out = []
	for page in range(1, pages + 1):
		try:
			params = {'query': text, 'include_adult': 'false', 'language': lang, 'page': page}
			if scope == 'movie':
				if year: params['year'] = year
				data = _tmdb_get('/search/movie', **params)
				out += [_row(i, 'movie') for i in data.get('results') or []]
			elif scope == 'tv':
				if year: params['first_air_date_year'] = year
				data = _tmdb_get('/search/tv', **params)
				out += [_row(i, 'tv') for i in data.get('results') or []]
			else:
				data = _tmdb_get('/search/multi', **params)
				out += [_row(i, i.get('media_type')) for i in data.get('results') or [] if i.get('media_type') in ('movie', 'tv')]
		except Exception as e:
			_log('TMDb search failed (%s)' % type(e).__name__)
			break
		if page >= int(data.get('total_pages') or 1): break
	return out


def related(rows, exclude):
	"""The real titles of a search not already listed, in TMDb's order."""
	out = []
	for r in rows:
		if not real(r) or any(_same(r, x) for x in exclude) or any(_same(r, x) for x in out): continue
		out.append(r)
	return out


def starts_with(rows, text, exclude):
	"""Other real titles whose name starts with what was typed (Titanic -> Titanic II)."""
	want = norm(text)
	return [r for r in related(rows, exclude) if norm(r['title']).startswith(want + ' ') or norm(r['original']).startswith(want + ' ')]


def word_hits(rows, text):
	"""Real titles that hold every word typed ('rise of gru' -> Minions: The Rise of Gru)."""
	words = norm(text).split()
	if not words: return []
	return [r for r in rows if real(r) and all(w in (norm(r['title']) + ' ' + norm(r['original'])).split() for w in words)]


def real(row):
	"""TMDb also keeps empty entries (seen: 'Rambo 1', no date, no votes): never a match."""
	return bool(row.get('year')) and (int(row.get('votes') or 0) > 0 or float(row.get('popularity') or 0) >= 1.0)


def exact_matches(rows, text, year=None):
	"""Rows whose title (or original title) is what the user typed, most popular first."""
	want = norm(text)
	if not want: return []
	out = [r for r in rows if real(r) and want in (norm(r['title']), norm(r['original'])) and (not year or r['year'] == year)]
	return sorted(out, key=lambda r: r['popularity'], reverse=True)


def leader(matches):
	"""The match to open without asking, or None when the user should choose."""
	if not matches: return None
	if len(matches) == 1: return matches[0]
	first, second = matches[0], matches[1]
	if first['popularity'] >= LEAD * max(second['popularity'], 0.1): return first
	return None


# ───────────────────────── sagas (TMDb collections) ─────────────────────────
def collection_of(row):
	"""-> (collection id, name) of a film, or (None, '')."""
	try:
		data = _tmdb_get('/movie/%s' % row['id'], language=_language())
		c = data.get('belongs_to_collection') or {}
		return c.get('id'), c.get('name') or ''
	except Exception as e:
		_log('TMDb movie lookup failed (%s)' % type(e).__name__)
		return None, ''


def collection_parts(cid):
	"""-> (name, films already released, oldest first)."""
	try:
		data = _tmdb_get('/collection/%s' % cid, language=_language())
	except Exception as e:
		_log('TMDb collection lookup failed (%s)' % type(e).__name__)
		return '', []
	today = time.strftime('%Y-%m-%d')
	parts = [_row(p, 'movie') for p in data.get('parts') or []]
	parts = [p for p in parts if p['date'] and p['date'] <= today]
	parts.sort(key=lambda p: p['date'])
	return data.get('name') or '', parts[:MAX_PARTS]


def search_collection(text):
	"""A saga by its own name ('Harry Potter' -> Harry Potter Collection)."""
	try:
		data = _tmdb_get('/search/collection', query=text, language=_language())
	except Exception as e:
		_log('TMDb collection search failed (%s)' % type(e).__name__)
		return None, ''
	want = norm(text)
	for c in data.get('results') or []:
		if norm(re.sub(COLLECTION_WORDS, ' ', c.get('name') or '', flags=re.I)) == want:
			return c.get('id'), c.get('name') or ''
	return None, ''


def names_saga(text, parts):
	"""True when what was typed is the saga's name, not one film of it: at
	least two of its films start with it (Rambo -> Rambo III, Rambo: Last Blood)."""
	want = norm(text)
	hits = [p for p in parts if norm(p['title']) == want or norm(p['title']).startswith(want + ' ')]
	return len(hits) >= 2


def saga(matches, scope):
	"""-> (name, films) of the collection the typed film belongs to."""
	if scope == 'tv': return '', []
	movie = next((m for m in matches if m['kind'] == 'movie'), None)
	if not movie: return '', []
	cid, name = collection_of(movie)
	if not cid: return '', []
	cname, parts = collection_parts(cid)
	return cname or name, parts


def saga_part(base, n, scope):
	"""The n-th film of the saga called base, or None."""
	if scope == 'tv': return None
	matches = exact_matches(tmdb_search(base, 'movie'), base)
	cid = collection_of(matches[0])[0] if matches else None
	if not cid: cid = search_collection(base)[0]
	if not cid: return None
	parts = collection_parts(cid)[1]
	return parts[n - 1] if 0 < n <= len(parts) else None


def _same(a, b):
	return a['kind'] == b['kind'] and str(a['id']) == str(b['id'])


def details(row):
	"""imdb / tvdb ids and art for the chosen title, in one request."""
	kind = row['kind']
	data = _tmdb_get('/%s/%s' % (kind, row['id']), language=_language(), append_to_response='external_ids')
	ext = data.get('external_ids') or {}
	title = data.get('title') if kind == 'movie' else data.get('name')
	date = (data.get('release_date') if kind == 'movie' else data.get('first_air_date')) or ''
	show = None
	if kind == 'tv':
		def ep(x):
			if not x: return None
			return {'season': int(x.get('season_number') or 0), 'episode': int(x.get('episode_number') or 0),
					'name': x.get('name') or '', 'date': x.get('air_date') or ''}
		show = {'seasons': [{'season': int(x.get('season_number') or 0), 'count': int(x.get('episode_count') or 0),
							 'name': x.get('name') or '', 'date': x.get('air_date') or ''} for x in data.get('seasons') or []],
				'last': ep(data.get('last_episode_to_air')), 'next': ep(data.get('next_episode_to_air')),
				'n_seasons': int(data.get('number_of_seasons') or 0), 'n_episodes': int(data.get('number_of_episodes') or 0),
				'status': data.get('status') or '', 'kind': 'tv'}
	return {
		'show': show,
		'tmdb': str(row['id']), 'imdb': data.get('imdb_id') or ext.get('imdb_id') or '',
		'tvdb': str(ext.get('tvdb_id') or ''), 'title': title or row['title'],
		'year': date[:4] or (str(row['year']) if row['year'] else ''), 'premiered': date,
		'poster': TMDB_IMG % ('w500', data['poster_path']) if data.get('poster_path') else '',
		'fanart': TMDB_IMG % ('w1280', data['backdrop_path']) if data.get('backdrop_path') else '',
		'plot': data.get('overview') or '',
	}


# ───────────────────────── opening what was found ─────────────────────────
def play_url(info, ask=True):
	meta = {'mediatype': 'movie', 'title': info['title'], 'year': info['year'], 'imdb': info['imdb'],
			'tmdb': info['tmdb'], 'poster': info['poster'], 'fanart': info['fanart'], 'plot': info['plot'],
			'premiered': info['premiered']}
	return '%s?action=play_Item&title=%s&year=%s&imdb=%s&tmdb=%s&premiered=%s&meta=%s&select=%s' % (
		SYSADDON, quote_plus(info['title']), info['year'], info['imdb'], info['tmdb'],
		quote_plus(info['premiered']), quote_plus(json.dumps(meta)), '2' if ask else '1')


def navigate(path):
	"""Open a listing. Inside the Videos window (where the assistant always is)
	Container.Update keeps the normal history: Back goes up one level."""
	import xbmc
	if xbmc.getCondVisibility('Window.IsActive(videos)'): control.execute('Container.Update(%s)' % path)
	else: control.execute('ActivateWindow(Videos,%s,return)' % path)


def seasons_url(info):
	return '%s?action=seasons&tvshowtitle=%s&year=%s&imdb=%s&tmdb=%s&tvdb=%s' % (
		SYSADDON, quote_plus(info['title']), info['year'], info['imdb'], info['tmdb'], info['tvdb'])


def _remember_quality(quality, tmdb):
	"""A quality asked in the query skips the question when that quality is there."""
	if quality:
		control.homeWindow.setProperty(PROP_QUALITY, json.dumps({'q': quality, 'ts': time.time(), 'tmdb': tmdb}))
	else:
		control.homeWindow.clearProperty(PROP_QUALITY)
	return _get('assistant.search.ask') != 'false' or bool(quality)


def open_title(row, quality=None):
	if row['kind'] == 'tv': return open_show(row, quality)
	info = details(row)
	ask = _remember_quality(quality, info['tmdb'])
	control.execute('PlayMedia(%s)' % play_url(info, ask))
	return 'play'


# ───────────────────────── TV shows ─────────────────────────
def _fmt_date(date):
	try: return time.strftime('%d %b %Y', time.strptime(date[:10], '%Y-%m-%d')).lstrip('0')
	except Exception: return date or ''


def _code(s, e):
	return 'S%02dE%02d' % (int(s), int(e))


def show_lines(show):
	"""-> (line1, line2): '3 seasons · 30 episodes · Returning Series', 'Latest ... / Next ...'."""
	if not show: return '', ''
	ns, ne = show.get('n_seasons') or 0, show.get('n_episodes') or 0
	bits = [L(401020) if ns == 1 else L(401019) % ns, L(401022) if ne == 1 else L(401021) % ne]
	if show.get('status'): bits.append(show['status'])
	lines = []
	for key, sid in (('last', 401026), ('next', 401027)):
		x = show.get(key)
		if x and x['season'] and x['episode']:
			text = _code(x['season'], x['episode'])
			if x['name']: text = '%s  %s' % (text, x['name'])
			if x['date']: text = '%s  ·  %s' % (text, _fmt_date(x['date']))
			lines.append(L(sid) % text)
	return '  ·  '.join(bits), '[CR]'.join(lines)


def watched_episodes(info):
	"""(season, episode) watched, from the Trakt or SIMKL indicators the plugin already keeps."""
	try:
		from resources.lib.modules import playcount
		if not (playcount.traktIndicators or playcount.simklIndicators): return []
		for i in playcount.getTVShowIndicators() or []:
			ids = i[0] if isinstance(i, (list, tuple)) and isinstance(i[0], dict) else {}
			if (info['imdb'] and ids.get('imdb') == info['imdb']) or str(ids.get('tmdb')) == info['tmdb'] or \
					(info['tvdb'] and str(ids.get('tvdb')) == info['tvdb']):
				return [(int(x[0]), int(x[1])) for x in i[2]]
	except Exception:
		log_utils.error()
	return []


def next_to_watch(show, seen):
	"""The first aired episode after the highest one watched, or None."""
	seen = [x for x in seen or [] if x[0] > 0]
	if not show or not seen: return None
	counts = dict((x['season'], x['count']) for x in show.get('seasons') or [] if x['season'] > 0)
	s, e = max(seen)
	if e < counts.get(s, 0): cand = (s, e + 1)
	else:
		later = sorted(n for n in counts if n > s and counts[n])
		cand = (later[0], 1) if later else None
	last = show.get('last')
	if cand and last and cand <= (last['season'], last['episode']): return cand
	return None


def season_episodes(info, season):
	"""-> [{'episode', 'name', 'date', 'plot', 'still'}] of one season."""
	try:
		data = _tmdb_get('/tv/%s/season/%s' % (info['tmdb'], season), language=_language())
	except Exception as e:
		_log('TMDb season lookup failed (%s)' % type(e).__name__)
		return []
	return [{'episode': int(x.get('episode_number') or 0), 'name': x.get('name') or '', 'date': x.get('air_date') or '',
			 'plot': x.get('overview') or '', 'still': x.get('still_path') or ''} for x in data.get('episodes') or []]


def _aired(date):
	return bool(date) and date[:10] <= time.strftime('%Y-%m-%d')


def episode_url(info, season, ep, ask=True):
	show = info.get('show') or {}
	meta = {'mediatype': 'episode', 'title': ep['name'] or _code(season, ep['episode']), 'tvshowtitle': info['title'],
			'season': int(season), 'episode': int(ep['episode']), 'year': info['year'], 'imdb': info['imdb'],
			'tmdb': info['tmdb'], 'tvdb': info['tvdb'], 'premiered': ep['date'], 'poster': info['poster'],
			'fanart': info['fanart'], 'plot': ep['plot'] or info['plot'],
			'thumb': TMDB_IMG % ('w780', ep['still']) if ep['still'] else '',
			'total_seasons': show.get('n_seasons') or '',
			'season_isAiring': 'true' if (show.get('next') or {}).get('season') == int(season) else 'false'}
	return '%s?action=play_Item&title=%s&year=%s&imdb=%s&tmdb=%s&tvdb=%s&season=%s&episode=%s&tvshowtitle=%s&premiered=%s&meta=%s&select=%s' % (
		SYSADDON, quote_plus(meta['title']), info['year'], info['imdb'], info['tmdb'], info['tvdb'], int(season),
		int(ep['episode']), quote_plus(info['title']), quote_plus(ep['date']), quote_plus(json.dumps(meta)), '2' if ask else '1')


def play_episode(info, season, episode, quality=None, eps=None):
	eps = eps if eps is not None else season_episodes(info, season)
	ep = next((x for x in eps if x['episode'] == int(episode)), None)
	if not ep or not _aired(ep['date']):
		control.notification(message=L(401040) % _code(season, episode))
		return 'missing'
	ask = _remember_quality(quality, info['tmdb'])
	_log('episode %s %s' % (info['title'], _code(season, episode)))
	control.execute('PlayMedia(%s)' % episode_url(info, season, ep, ask))
	return 'play'


def pick(items, heading, sub='', preselect=0, mode='posters', hint=None):
	"""The assistant's picker -> index of the item picked, or None."""
	from resources.lib.windows.assistant_pick import AssistantPickXML
	window = AssistantPickXML('assistant_pick.xml', control.addonPath(control.addonId()), items=items, heading=heading,
							  sub=sub, preselect=preselect, mode=mode, hint=L(401048) if hint is None else hint,
							  ratings=rating_props if mode == 'posters' else None)
	idx = window.run()
	del window
	return idx if idx is not None and 0 <= idx < len(items) else None


def choose_episode(info, season, preselect=None, eps=None):
	"""The aired episodes of a season in the picker -> episode number, or None."""
	eps = [x for x in (eps if eps is not None else season_episodes(info, season)) if _aired(x['date'])]
	if not eps:
		control.notification(message=L(401041) % season)
		return None
	items = [{'label': '%d.  %s' % (x['episode'], x['name'] or _code(season, x['episode'])), 'label2': _fmt_date(x['date']),
			  'art': TMDB_IMG % ('w300', x['still']) if x['still'] else '',
			  'props': {'meta': '%s  ·  %s' % (_code(season, x['episode']), _fmt_date(x['date'])), 'plot': x['plot']}} for x in eps]
	pre = next((i for i, x in enumerate(eps) if x['episode'] == preselect), 0)
	idx = pick(items, L(401037) % (info['title'], season), L(401042), pre, 'stills')
	return eps[idx]['episode'] if idx is not None else None


def open_show(row, quality=None, season=None, episode=None):
	"""The assistant's sheet for a TV show, or straight to the episode asked for."""
	info = details(row)
	if season and episode: return play_episode(info, season, episode, quality)
	if season:
		e = choose_episode(info, season)
		return play_episode(info, season, e, quality) if e else 'cancelled'
	nxt = next_to_watch(info.get('show'), watched_episodes(info))
	from resources.lib.windows.assistant_show import AssistantShowXML
	for _ in range(10):   # Back in the episode list returns to the sheet
		window = AssistantShowXML('assistant_show.xml', control.addonPath(control.addonId()), info=info, next=nxt)
		act = window.run()
		del window
		if not act: return 'cancelled'
		if act[0] == 'play': return play_episode(info, act[1], act[2], quality)
		if act[0] == 'all':
			navigate(seasons_url(info))
			return 'seasons'
		if act[0] == 'season':
			e = choose_episode(info, act[1], preselect=nxt[1] if nxt and nxt[0] == act[1] else None)
			if e: return play_episode(info, act[1], e, quality)
	return 'cancelled'


def _external_imdb(kind, tid):
	data = _tmdb_get('/%s/%s/external_ids' % ('movie' if kind == 'movie' else 'tv', tid))
	return data.get('imdb_id') or ''


def rating_props(row):
	"""The ratings of one title for the picker's strip: r.imdb r.rt r.mc r.tmdb r.trakt.
	ratings.fetch is the same cascade as the sources window (MDBList, Trakt, OMDb,
	cached 24-48 h), so a title rated once costs nothing the next time."""
	out = {}
	try:
		from resources.lib.database import cache
		from resources.lib.modules import ratings
		imdb = cache.get(_external_imdb, 168, row['kind'], str(row['id'])) or ''
		r = ratings.fetch({'mediatype': 'movie' if row['kind'] == 'movie' else 'tvshow', 'imdb': imdb,
						   'rating': row.get('rating') or ''}, live=True)
		if r.get('imdb') and r.get('imdb_source') == 'imdb': out['r.imdb'] = r['imdb']
		if r.get('rt'): out['r.rt'] = r['rt']
		if r.get('metacritic'): out['r.mc'] = r['metacritic']
		if r.get('tmdb') and int(row.get('votes') or 0) > 0: out['r.tmdb'] = r['tmdb']
		if r.get('trakt'): out['r.trakt'] = r['trakt']
	except Exception:
		log_utils.error()
	return out


def title_items(rows, numbered=0):
	"""Rows -> picker items. Under the poster only the year (v2.0.14: the long
	line did not fit in 212 px); the full title, 'year · Movie · 2 of 5 in the
	saga · TMDb 7.1' and the plot go in the info strip of the focused one."""
	items = []
	for i, r in enumerate(rows):
		bits = [str(r['year'])] if r.get('year') else []
		bits.append(L(400996) if r['kind'] == 'movie' else L(400997))
		if i < numbered: bits.append(L(401051) % (i + 1, numbered))
		props = {'meta': '  ·  '.join(bits), 'plot': r.get('plot') or ''}
		# TMDb's own vote is in hand: its icon shows at once, the rest when the focus rests on it
		if r.get('rating') and int(r.get('votes') or 0) > 0: props['r.tmdb'] = '%.1f' % r['rating']
		items.append({'label': r['title'], 'label2': str(r['year']) if r.get('year') else '',
					  'art': TMDB_IMG % ('w342', r['poster']) if r.get('poster') else '',
					  'props': props, 'ref': r})
	return items


def choose(matches, heading=None, preselect=0, numbered=0, sub=None):
	"""Titles in the picker. numbered: how many of the rows are films of a saga."""
	rows = matches[:limit()]
	idx = pick(title_items(rows, numbered), heading or L(400995), L(401042) if sub is None else sub, max(0, preselect))
	return rows[idx] if idx is not None else None


def classic_term(query, scope):
	action = 'tvSearchterm' if scope == 'tv' else 'movieSearchterm'
	navigate('%s?action=%s&name=%s' % (SYSADDON, action, quote_plus(query)))


def understood(intent, media_type):
	"""Gemini's reading of the request, in a line: 'Movie · Science fiction · 1990–1999 · aliens'."""
	bits = [L(400996) if media_type == 'movie' else L(400997)]
	bits += [g[:1].upper() + g[1:] for g in intent.get('genres') or []]
	bits += list(intent.get('people') or [])
	yr = intent.get('year_range') or {}
	start, end = yr.get('start'), yr.get('end')
	if start and end: bits.append('%s\u2013%s' % (start, end) if start != end else str(start))
	elif start: bits.append(L(401049) % start)
	elif end: bits.append(L(401050) % end)
	bits += list(intent.get('keywords') or [])[:3]
	seen, out = set(), []
	for b in bits:
		if b and b.lower() not in seen:
			seen.add(b.lower()); out.append(b)
	return '  ·  '.join(out)


def natural_results(query, scope):
	"""Gemini reads the request; TMDb Discover answers it. -> (rows, understood line)
	or (None, error message)."""
	from resources.lib.modules import gemini_api, ai_search
	control.notification(message=L(401045), time=3000)
	intent = gemini_api.interpret_prompt(query)
	if not intent:
		err = gemini_api.last_error_message() or ''
		return None, ('%s: %s' % (L(401046), err[:100])) if err else L(401046)
	forced = {'movie': 'movie', 'tv': 'tvshow'}.get(scope)
	media_type = forced or intent.get('media_type') or 'movie'
	kind = 'movie' if media_type == 'movie' else 'tv'
	rows = []
	try:
		import requests
		url = ai_search._build_tmdb_url(media_type, intent, query)
		# page=1 is always the last parameter of AI Search's URLs: the next pages
		# are the same query, up to the Title Search limit
		pages = max(1, min(5, (limit() + 19) // 20))
		for page in range(1, pages + 1):
			page_url = url if page == 1 or not url.endswith('page=1') else url[:-len('page=1')] + 'page=%d' % page
			r = requests.get(page_url % _tmdb_key(), timeout=12)
			r.raise_for_status()
			data = r.json()
			rows += [_row(i, kind) for i in (data.get('results') or [])]
			if page >= int(data.get('total_pages') or 1) or not url.endswith('page=1'): break
	except Exception as e:
		_log('TMDb answer to Gemini failed (%s)' % type(e).__name__)
	rows = related(rows, [])[:limit()]
	if not rows: return None, L(401047)
	return rows, understood(intent, media_type)


def natural_on():
	if _get('assistant.search.natural') == 'false': return False
	try:
		from resources.lib.modules import gemini_api
		return gemini_api.has_gemini_keys()
	except Exception:
		return False


def run(query, scope='all'):
	"""What the hub does with a query. Returns what it did (for the log and tests)."""
	query = ' '.join(str(query or '').split())
	if not query: return None
	scope = scope if scope in SCOPES else 'all'
	if is_status(query):
		save_history(query, scope, 'ask')
		from resources.lib.modules import assistant
		assistant.show_summary()
		return 'status'
	p = parse(query)
	# "Silo s3e1", "Silo season 2": a TV show and its episode or season
	if scope != 'movie' and p['text']:
		base, season, episode = split_episode(p['text'])
		if base:
			matches = exact_matches(tmdb_search(base, 'tv'), base)
			if matches:
				save_history(query, scope, 'title')
				pick = leader(matches) or choose(matches)
				if not pick: return 'cancelled'
				_log('show %r -> %s (%s) %s' % (query, pick['title'], pick['year'], _code(season, episode or 0)))
				return open_show(pick, p['quality'], season, episode)
	if p['text'] and len(p['text'].split()) <= MAX_TITLE_WORDS:
		rows = tmdb_search(p['text'], scope, p['year'])
		matches = exact_matches(rows, p['text'], p['year'])
		if not matches and p['year'] and p['full'] != p['text']:
			# the number was part of the title, not its year
			rows2 = tmdb_search(p['full'], scope)
			matches = exact_matches(rows2, p['full'])
			if matches: p.update(text=p['full'], year=None); rows = rows2
		explicit = bool(p['year'] or p['quality'] or p['play'])
		if matches:
			save_history(query, scope, 'title')
			pick = None
			# the name of a saga: its films first, then every other title found (a year typed means that one film)
			if not p['year']:
				cname, parts = saga(matches, scope)
				if len(parts) > 1 and names_saga(p['text'], parts):
					rest = related(rows, parts)
					family = (parts + rest)[:limit()]
					pre = next((i for i, x in enumerate(family) if _same(x, matches[0])), 0)
					sub = (L(401054) % (len(parts), len(family) - len(parts))) if len(family) > len(parts) else L(401042)
					pick = choose(family, L(401055) % (cname, len(parts)), pre, numbered=len(parts), sub=sub)
					if not pick: return 'cancelled'
					_log('saga %r -> %s (%d films, %d more)' % (query, cname, len(parts), len(family) - len(parts)))
			if not pick:
				lead = leader(matches)
				others = starts_with(rows, p['text'], matches)
				# straight away only when there is nothing to choose from, or the query said which one
				if lead and (explicit or (len(matches) == 1 and not others)):
					pick = lead
				else:
					# every title found, the exact ones first and the most popular selected
					family = (matches + related(rows, matches))[:limit()]
					pick = choose(family, L(401053) % (p['text'], len(family)), 0)
					if not pick: return 'cancelled'
			_log('title %r -> %s %s (%s)' % (query, pick['kind'], pick['id'], pick['year']))
			return open_title(pick, p['quality'])
		# "Rambo 2", "rambo primera parte": that film of the saga
		base, n = split_ordinal(p['text'])
		if base and n:
			part = saga_part(base, n, scope)
			if part:
				save_history(query, scope, 'title')
				_log('saga part %r -> %s (%s), film %d' % (query, part['title'], part['year'], n))
				return open_title(part, p['quality'])
		# a saga by its own name with no film called just that ("Harry Potter")
		if scope != 'tv':
			cid, cname = search_collection(p['text'])
			if cid:
				name2, parts = collection_parts(cid)
				if len(parts) > 1:
					save_history(query, scope, 'title')
					family = (parts + related(rows, parts))[:limit()]
					sub = (L(401054) % (len(parts), len(family) - len(parts))) if len(family) > len(parts) else L(401042)
					pick = choose(family, L(401055) % (name2 or cname, len(parts)), 0, numbered=len(parts), sub=sub)
					if not pick: return 'cancelled'
					_log('saga %r -> %s, picked %s (%s)' % (query, name2 or cname, pick['title'], pick['year']))
					return open_title(pick, p['quality'])
		# part of a title ("rise of gru"): the titles holding every word, then the rest found
		hits = word_hits(rows, p['text'])
		if hits:
			save_history(query, scope, 'title')
			family = (hits + related(rows, hits))[:limit()]
			pick = choose(family, L(401053) % (p['text'], len(family)), 0)
			if not pick: return 'cancelled'
			_log('words %r -> %s %s (%s)' % (query, pick['kind'], pick['id'], pick['year']))
			return open_title(pick, p['quality'])
	if natural_on():
		save_history(query, scope, 'ask')
		rows, line = natural_results(query, scope)
		if not rows:
			control.notification(message=line, time=6000)
			return 'natural-empty'
		_log('natural %r -> %d titles (%s)' % (query, len(rows), line))
		chosen = choose(rows, L(401043), sub=L(401044) % line)
		if not chosen: return 'cancelled'
		_log('natural pick %s %s (%s)' % (chosen['kind'], chosen['id'], chosen['year']))
		return open_title(chosen, p['quality'])
	save_history(query, scope, 'title')
	classic_term(p['text'] or query, scope)
	return 'classic'


# ───────────────────────── hub entry ─────────────────────────
def open_hub():
	"""Router action assistant_search (the Search entry of the main menu)."""
	result = None
	try:
		from resources.lib.windows.assistant_search import AssistantSearchXML
		window = AssistantSearchXML('assistant_search.xml', control.addonPath(control.addonId()))
		result = window.run()
		del window
	except Exception:
		log_utils.error()
	if not result: return
	kind = result[0]
	try:
		if kind == 'query':
			done = run(result[1], result[2])
			_log('query done: %s' % done)
		elif kind == 'folder':
			navigate('%s?action=%s' % (SYSADDON, result[1]))
		elif kind == 'script':
			control.execute('RunPlugin(%s?action=%s)' % (SYSADDON, result[1]))
	except Exception:
		log_utils.error()


# ───────────────────────── guided results (called by sources.play) ─────────────────────────
def bucket(item):
	return BUCKET_OF.get(str(item.get('quality') or 'SD').upper(), 'SD')


def bucket_counts(items):
	counts = dict((b, 0) for b in BUCKETS)
	for i in items: counts[bucket(i)] += 1
	return counts


def filter_quality(items, choice):
	if choice in (None, 'best'): return list(items)
	return [i for i in items if bucket(i) == choice]


def providers(items):
	from resources.lib.modules import system_status as st
	seen = []
	for i in items:
		name = str(i.get('provider') or '').lower()
		if name and name not in seen: seen.append(name)
	return [st.display_name(n) for n in seen]


def names_line(names, limit=6):
	if len(names) <= 1: return ''.join(names)
	if len(names) <= limit: return '%s %s %s' % (', '.join(names[:-1]), L(400998), names[-1])
	return '%s %s' % (', '.join(names[:limit]), L(400982) % (len(names) - limit))


def summary(items):
	"""-> (line, counts): '16 sources from 5 scrapers: Torz, Comet ...'."""
	names = providers(items)
	counts = bucket_counts(items)
	src = L(401001) if len(items) == 1 else L(401000) % len(items)
	scr = L(401003) if len(names) == 1 else L(401002) % len(names)
	line = '%s %s' % (src, scr)
	if names: line = '%s: %s' % (line, names_line(names))
	return line, counts


def asked_quality(tmdb=None):
	"""The quality typed in the query ("... in 4K"), once."""
	home = control.homeWindow
	raw = home.getProperty(PROP_QUALITY)
	home.clearProperty(PROP_QUALITY)
	try: data = json.loads(raw) if raw else None
	except Exception: data = None
	if not data or (time.time() - float(data.get('ts') or 0)) > QUALITY_TTL: return None
	if tmdb and data.get('tmdb') and str(data['tmdb']) != str(tmdb): return None
	return data.get('q') if data.get('q') in BUCKETS else None


def remembered():
	if _get('assistant.search.remember') != 'true': return None
	last = _get('assistant.search.last')
	return last if last in BUCKETS + ('best',) else None


def guided_choice(items, meta, title, year):
	"""-> '4K' / '1080p' / '720p' / 'SD' / 'best' / 'all', or None (cancelled)."""
	tmdb = (meta or {}).get('tmdb') if isinstance(meta, dict) else None
	counts = bucket_counts(items)
	want = asked_quality(tmdb)
	if want and counts.get(want):
		_log('quality asked in the query: %s (%d sources)' % (want, counts[want]))
		return want
	from resources.lib.windows.assistant_results import AssistantResultsXML
	window = AssistantResultsXML('assistant_results.xml', control.addonPath(control.addonId()),
								 items=items, meta=meta if isinstance(meta, dict) else {}, title=title, year=year,
								 missing=want)
	choice = window.run()
	del window
	if choice in BUCKETS + ('best',):
		try:
			if _get('assistant.search.last') != choice: control.setSetting('assistant.search.last', choice)
		except Exception: pass
	_log('guided choice: %s' % choice)
	return choice
