# -*- coding: utf-8 -*-
"""
	luc_kodi Add-on — assistant.py (v2.0.14)

	Personal assistant, first part: a welcome summary over the main menu.

	  WHEN      only when the plugin's root menu is opened in the Videos window
	            (never from a skin widget on the home screen, never during video),
	            once per Kodi session or once a day (Settings > Personal Assistant),
	            and optionally only when something needs attention. It runs in its
	            own script call (RunPlugin), so the main menu is never held up.

	  NAME      typed by the user, or taken from the first signed-in account in
	            this order: Trakt, PunchPlay, SIMKL, WeTrakr, TVmaze, MDBList, Real-Debrid,
	            TorBox, AllDebrid, Premiumize. Only the user names those services
	            already keep in the settings: nothing is asked over the network.
	            A value that is not a name (a customer number, an email, a
	            placeholder) is skipped and the next service is tried.

	  ACCOUNTS  the same list as System status (system_status.accounts): active
	            services only, orange when a subscription ends within 7 days or a
	            tracker needs signing in again. Expiry dates come from System
	            status' 6-hour cache and are refreshed in the background.

	  SCRAPERS  never tested on opening: the last result is shown, with its age.
	            It is the newest of this session's test (System status or Check
	            again here) and a copy kept on disk, so it survives a restart.
	            Check again runs System status' own test (same lock and
	            cooldown as the provider test) while the window stays usable.
"""

import json
import os
import time
from datetime import datetime

import xbmc

from resources.lib.modules import control
from resources.lib.modules import log_utils
from resources.lib.modules import system_status as st

LOGINFO = log_utils.LOGINFO

PROP_SHOWN = 'luc_kodi.assistant.shown'   # this Kodi session already decided
PROP_OPEN = 'luc_kodi.assistant.open'     # the window is on screen
LAST_FILE = 'assistant_scrapers.json'     # last scraper test, kept across restarts

# (service, shown name, username setting) in the order the name is looked for
NAME_SOURCES = (
	('trakt', 'Trakt', 'trakt.username'),
	('punchplay', 'PunchPlay', 'punchplay.username'),
	('simkl', 'SIMKL', 'simkl.username'),
	('wetrakr', 'WeTrakr', 'wetrakr.username'),
	('tvmaze', 'TVmaze', 'tvmaze.username'),
	('mdblist', 'MDBList', 'mdblist.username'),
	('realdebrid', 'Real-Debrid', 'realdebrid.username'),
	('torbox', 'TorBox', 'torbox.username'),
	('alldebrid', 'AllDebrid', 'alldebrid.username'),
	('premiumize', 'Premiumize', 'premiumize.username'),
)
TRACKER_TOKENS = dict((t[0], t[3]) for t in st.TRACKERS)

MAX_NAMES = 6   # scrapers named on the "need a look" line before "+N more"


def _log(msg):
	control.log('[ luc_kodi ] assistant: %s' % msg, LOGINFO)


def L(sid):
	return control.lang(sid)


def _get(sid):
	try: return (control.setting(sid) or '').strip()
	except Exception: return ''


# ───────────────────────── name ─────────────────────────
def clean_name(raw):
	"""A user name as the services store it -> a name to greet with, or ''."""
	value = (raw or '').strip()
	if '@' in value: value = value.split('@', 1)[0].strip()
	if not value or len(value) > 32: return ''
	if value.lower() in ('simkl user', 'user', 'unknown', 'none'): return ''
	if value.lower().startswith('cus_'): return ''   # TorBox keeps a customer id
	if not any(c.isalpha() for c in value): return ''   # Premiumize keeps a number
	return value


def _service_active(key):
	if key in TRACKER_TOKENS:
		try: return st._tracker_active(key, TRACKER_TOKENS[key])
		except Exception: return False
	return _get('%s.enable' % key) == 'true' and bool(_get('%s.token' % key))


def found_name():
	"""-> (name, service shown name) from the first signed-in account, or ('', '')."""
	for key, label, sid in NAME_SOURCES:
		if not _service_active(key): continue
		name = clean_name(_get(sid))
		if name: return name, label
	return '', ''


def user_name():
	if _get('assistant.name.source') == '1':
		typed = _get('assistant.name.custom')
		if typed: return typed
	return found_name()[0]


def sync_found_setting():
	"""Keeps Settings > Personal Assistant > Found up to date. Writes only on change."""
	try:
		name, service = found_name()
		value = ('%s (%s)' % (name, service)) if name else L(400981)
		if _get('assistant.name.found') != value: control.setSetting('assistant.name.found', value)
	except Exception:
		log_utils.error()


def greeting(name=None, hour=None):
	hour = time.localtime().tm_hour if hour is None else hour
	if 5 <= hour < 12: text = L(400951)
	elif 12 <= hour < 18: text = L(400952)
	else: text = L(400953)
	name = user_name() if name is None else name
	return ('%s, %s' % (text, name)) if name else text


# ───────────────────────── launch ─────────────────────────
def _enabled():
	return _get('assistant.welcome') != 'false'   # on by default


def _today():
	return datetime.now().strftime('%Y-%m-%d')


def _daily():
	return _get('assistant.welcome.when') == '1'


def maybe_launch(just_updated=False):
	"""Called by the router after the root menu is listed. Cheap: settings and
	window properties only; the window itself opens in its own script call."""
	try:
		sync_found_setting()
		if just_updated or not _enabled(): return   # the changelog is on screen
		home = control.homeWindow
		if home.getProperty(PROP_SHOWN) or home.getProperty(PROP_OPEN): return
		# a skin widget on the home screen lists the root menu too: only the Videos window counts
		if not xbmc.getCondVisibility('Window.IsActive(videos)'): return
		if xbmc.getCondVisibility('Player.HasVideo'): return
		home.setProperty(PROP_SHOWN, 'true')
		if _daily() and _get('assistant.welcome.day') == _today(): return
		control.execute('RunPlugin(plugin://plugin.video.luc_kodi/?action=assistant_welcome)')
	except Exception:
		log_utils.error()


def show_summary():
	"""The same window on request (Search: "is everything working?"): no
	once-per-session or attention rule, it was asked for."""
	welcome(asked=True)


def welcome(asked=False):
	"""Router action assistant_welcome."""
	home = control.homeWindow
	if home.getProperty(PROP_OPEN): return
	try:
		snap = snapshot()
		if not asked and _get('assistant.welcome.issues') == 'true' and not snap['attention']:
			_log('nothing needs attention: welcome not shown')
			return
		if _daily() and not asked: control.setSetting('assistant.welcome.day', _today())
		home.setProperty(PROP_OPEN, 'true')
		from resources.lib.windows.assistant_welcome import AssistantWelcomeXML
		window = AssistantWelcomeXML('assistant_welcome.xml', control.addonPath(control.addonId()), snapshot=snap)
		window.run()
		del window
	except Exception:
		log_utils.error()
	finally:
		home.clearProperty(PROP_OPEN)
	# a Check again still running finishes and is saved (the window is already closed)
	st.wait_background()


# ───────────────────────── accounts ─────────────────────────
def accounts_view(accts):
	"""-> (line1, line2) with their colour as BBCode."""
	if not accts:
		return '[COLOR %s]%s[/COLOR]' % (st.GREY, L(400960)), ''
	warns = st.warnings(accts)
	if warns:
		lines = ['[COLOR %s]%s[/COLOR]' % (st.ORANGE, w) for w in warns]
		return lines[0], (lines[1] if len(lines) > 1 else '')
	text = L(400959) if len(accts) == 1 else L(400958) % len(accts)
	return '[COLOR FFD2D2E4]%s[/COLOR]' % text, ''


def cached_days():
	cached = st._read_cache(st.PROP_DEBRID, st.CACHE_TTL) or {}
	return cached.get('days') or {}


# ───────────────────────── scrapers ─────────────────────────
def _last_path():
	return os.path.join(control.dataPath, LAST_FILE)


def _load_disk():
	try:
		with open(_last_path(), 'r', encoding='utf-8') as f:
			data = json.load(f)
		return data if isinstance(data, dict) and data.get('rows') else None
	except Exception:
		return None


def save_disk(data):
	"""Only what the summary needs: name, label, state and the moment."""
	try:
		rows = [{'name': r.get('name') or '', 'label': r.get('label') or '', 'state': r.get('state') or ''}
				for r in (data.get('rows') or [])]
		if not rows: return
		if not os.path.isdir(control.dataPath): control.makeDirs(control.dataPath)
		with open(_last_path(), 'w', encoding='utf-8') as f:
			json.dump({'ts': float(data.get('ts') or time.time()), 'rows': rows}, f)
	except Exception:
		log_utils.error()


def last_scrapers():
	"""The newest scraper test: this session's (window property) or the saved one."""
	mem = st.last_test()
	disk = _load_disk()
	if mem and mem.get('rows') and (not disk or float(mem.get('ts') or 0) > float(disk.get('ts') or 0)):
		save_disk(mem)
		return mem
	return disk


def age_text(ts, now=None):
	now = time.time() if now is None else now
	secs = max(0, int(now - float(ts or 0)))
	if secs < 60: return L(400965)
	if secs < 3600: return L(400966) % (secs // 60)
	if secs < 86400: return L(400967) % (secs // 3600)
	days = secs // 86400
	return L(400969) if days == 1 else L(400968) % days


def _names(rows):
	names = [r.get('label') or st.display_name(r.get('name') or '') for r in rows]
	if len(names) > MAX_NAMES:
		return '%s %s' % (', '.join(names[:MAX_NAMES]), L(400982) % (len(names) - MAX_NAMES))
	return ', '.join(names)


def scrapers_view(last, enabled_count=None, now=None):
	"""-> {'dot', 'line', 'sub', 'ok'} for the SCRAPERS block.
	ok: True all fine, False something needs a look, None unknown."""
	rows = (last or {}).get('rows') or []
	if not rows:
		if enabled_count == 1: line = L(400984)
		elif enabled_count: line = L(400970) % enabled_count
		else: line = L(400983)
		if enabled_count == 0:
			return {'dot': st.GREY, 'line': L(400974), 'sub': '', 'ok': None}
		return {'dot': st.GREY, 'line': line, 'sub': '[COLOR FF7878A0]%s[/COLOR]' % L(400971), 'ok': None}
	good = [r for r in rows if r.get('state') == 'ok']
	bad = [r for r in rows if r.get('state') != 'ok']
	age = '[COLOR FF7878A0]  ·  %s[/COLOR]' % (L(400964) % age_text(last.get('ts'), now))
	if not bad:
		text = L(400980) if len(rows) == 1 else L(400962) % len(rows)
		return {'dot': st.GREEN, 'line': text + age, 'sub': '[COLOR FF7878A0]%s[/COLOR]' % _names(rows), 'ok': True}
	text = L(400963) % (len(good), len(rows))
	return {'dot': st.ORANGE if good else st.RED, 'line': text + age,
			'sub': '[COLOR %s]%s[/COLOR]' % (st.ORANGE, L(400975) % _names(bad)), 'ok': False}


def enabled_count():
	try: return len(st.enabled_providers())
	except Exception:
		log_utils.error()
		return None


# ───────────────────────── everything the window opens with ─────────────────────────
def snapshot():
	accts = st.accounts(cached_days())
	acc1, acc2 = accounts_view(accts)
	last = last_scrapers()
	scr = scrapers_view(last)
	attention = bool(st.warnings(accts)) or scr['ok'] is False
	try: icon = control.addonInfo('icon')
	except Exception: icon = ''
	return {'greeting': greeting(), 'icon': icon, 'accounts': accts, 'acc1': acc1, 'acc2': acc2,
			'scrapers': scr, 'has_test': bool(last), 'attention': attention}
