# -*- coding: utf-8 -*-
"""
	luc_kodi Add-on

	v2.0.08: ayudante de busqueda para Movies > Languages y TV Shows > Languages,
	en todos los idiomas de esas listas salvo el ingles (con el ingles solo
	repetiria lo que ya buscan los demas scrapers).

	Lo que no esta en ingles se publica muchas veces con nombres que no casan
	con el titulo ingles de TMDb ni con su IMDb: "Kizil Goncalar 45. Bolum",
	"Lovely Runner EP05", "第05集", "Anatomie d'une chute", "Мастер и Маргарита".
	El scraper langhelper los busca por sus titulos alternativos y entiende esas
	numeraciones. Este modulo es la parte que no es scraper:

	- register(): al abrir una lista de Languages, apunta cada titulo (tmdb +
	  tipo) en una tabla propia de cache.db. El registro es lo que hace que el
	  ayudante actue: fuera de esos titulos no corre nunca. Va por titulo y no
	  por ruta para que siga ayudando al continuar la serie desde Progress, el
	  siguiente episodio o un widget.
	- lookup(): lo consulta sources.py antes de buscar.
	- titles(): los titulos alternativos de TMDb y el reparto de episodios por
	  temporada (para el numero absoluto), cacheados una semana.

	El anime queda fuera dos veces: al registrar (genero Animation en el idioma
	del usuario) y al buscar (genero 16 de TMDb, que no depende del idioma).
"""

import re
import unicodedata
from time import time
from resources.lib.modules import control

# Idiomas de Movies > Languages y TV Shows > Languages menos el ingles. Si se
# anade uno a esas listas hay que anadirlo aqui y sus palabras en ORIGINAL_MARKERS.
HELPER_LANGS = ('ar', 'zh', 'nl', 'fi', 'fr', 'de', 'hi', 'it', 'ja', 'ko', 'no', 'pl', 'pt', 'ro', 'ru', 'es', 'sv', 'tr')
REGISTRY_DAYS = 90
TITLES_HOURS = 168
ANIMATION_GENRE = 16

# Palabras sueltas con las que una release dice en que idioma va. Lo que diga
# otro de estos idiomas, y no el original ni ingles/multi, es un doblaje.
ORIGINAL_MARKERS = {
	'ar': ('arabic', 'ara', 'arab'),
	'zh': ('chinese', 'mandarin', 'cantonese', 'chi', 'chs', 'cht', 'chn'),
	'nl': ('dutch', 'nederlands', 'dut', 'nld', 'flemish', 'nlsub'),
	'fi': ('finnish', 'suomi', 'fin'),
	'fr': ('french', 'truefrench', 'francais', 'fre', 'fra', 'vff', 'vfq', 'vf', 'vf2', 'vfi'),
	'de': ('german', 'deutsch', 'ger', 'deu'),
	'hi': ('hindi', 'hin'),
	'it': ('italian', 'italiano', 'ita'),
	'ja': ('japanese', 'jpn', 'jap'),
	'ko': ('korean', 'kor'),
	'no': ('norwegian', 'norsk', 'nor'),
	'pl': ('polish', 'polski', 'pol', 'pldub', 'lektor'),
	'pt': ('portuguese', 'portugues', 'por', 'dublado', 'legendado', 'ptbr'),
	'ro': ('romanian', 'romana', 'rum', 'ron'),
	'ru': ('russian', 'rus'),
	'es': ('spanish', 'castellano', 'espanol', 'latino', 'spa', 'esp'),
	'sv': ('swedish', 'svenska', 'swe'),
	'tr': ('turkish', 'turkce', 'tur')}
LANGUAGE_WORDS = frozenset(w for ws in ORIGINAL_MARKERS.values() for w in ws) | frozenset((
	'ukr', 'ukrainian', 'persian', 'farsi', 'tamil', 'telugu', 'vietnamese', 'thai', 'indonesian', 'greek', 'hebrew',
	'hungarian', 'czech', 'danish', 'dubbed', 'dub'))
# Para declarar un doblaje no cuentan las que tambien son palabras corrientes en
# un nombre de release ("Ep16 FIN" no es finlandes, "POR" no es portugues).
DUB_WORDS = LANGUAGE_WORDS - frozenset(('fin', 'por', 'nor', 'ara', 'arab', 'ron', 'rum', 'vf'))

# Letras latinas que NFKD no descompone (ı, ł, ø, ß...): a mano.
_TR_MAP = str.maketrans({'ı': 'i', 'İ': 'I', 'ł': 'l', 'Ł': 'L', 'ø': 'o', 'Ø': 'O', 'đ': 'd', 'Đ': 'D', 'ð': 'd', 'Ð': 'D',
						'þ': 'th', 'Þ': 'Th', 'ß': 'ss', 'æ': 'ae', 'Æ': 'Ae', 'œ': 'oe', 'Œ': 'Oe'})
# kana, kanji (bloques comun, extension A y compatibilidad) y hangul
_CJK = re.compile('[%s-%s%s-%s%s-%s%s-%s%s-%s]' % (chr(0x3040), chr(0x30ff), chr(0x3400), chr(0x4dbf), chr(0x4e00), chr(0x9fff),
													chr(0xac00), chr(0xd7af), chr(0xf900), chr(0xfaff)))
_LANG_IN_URL = re.compile(r'with_original_language=([a-z]{2})')
_TABLE = 'lang_assist'


def enabled():
	return control.setting('provider.langhelper') == 'true'


def translit(text):
	"""Letras latinas a ASCII (Kızıl -> Kizil, Łódź -> Lodz, Ștefan -> Stefan).
	Lo que no es latino (hangul, kanji, cirilico, arabe, devanagari) se queda
	como esta: NFKD partiria el hangul en jamo y le quitaria la breve a la й."""
	try:
		text = (text or '').translate(_TR_MAP)
		out = []
		for ch in text:
			# letras de otras escrituras tal cual; lo latino y los simbolos con forma
			# compatible (², ０５ de ancho completo) se descomponen: 50M² -> 50M2
			if ord(ch) < 128 or (ch.isalpha() and 'LATIN' not in unicodedata.name(ch, '')):
				out.append(ch)
				continue
			out.extend(c for c in unicodedata.normalize('NFKD', ch) if unicodedata.category(c) != 'Mn')
		return ''.join(out)
	except Exception:
		return text or ''


def norm_latin(text):
	"""Forma de comparacion: minusculas, solo a-z0-9 separados por un espacio."""
	text = translit(text).lower().replace('&', ' and ')
	text = re.sub(r"['’`]", '', text)
	return re.sub(r'[^a-z0-9]+', ' ', text).strip()


def has_cjk(text):
	return bool(_CJK.search(text or ''))


def is_native(text):
	"""Titulo en otra escritura (kanji, hangul, cirilico, arabe...): se busca
	tal cual y se compara como texto, sin transliterar."""
	return any(ch.isalpha() and ord(ch) >= 128 for ch in translit(text or ''))


def is_latin(text):
	"""Un titulo sirve para buscar en latino si tras transliterar le quedan
	letras y no lleva otra escritura."""
	# v2.0.08: tambien solo cifras (la serie polaca "1670" se quedaba sin consultas)
	return bool(text) and not is_native(text) and len(norm_latin(text).replace(' ', '')) >= 2


def _is_animation(item):
	genre = item.get('genre') or ''
	if isinstance(genre, (list, tuple)): genre = ' / '.join(str(g) for g in genre)
	genre = genre.lower()
	return any(w in genre for w in ('anim', 'мульт', 'アニメ', '动画', '動畫', '애니메이션'))


def _shape(url):
	from urllib.parse import urlparse
	u = urlparse(url)
	keys = sorted(set(p.split('=', 1)[0] for p in u.query.split('&') if p))
	return u.netloc, u.path, keys


def lang_from_url(url, template=None):
	"""Idioma de una lista de Languages, o '' si la URL no es una de ellas.
	template es el tmdb_language_link del menu: la URL tiene que tener su misma
	forma (ruta y parametros). Asi no cuentan Anime (genero 16) ni la busqueda
	natural, que tambien filtra por idioma original."""
	try:
		if not url or 'with_genres=16' in url: return ''
		if template:
			# v2.0.08: varias listas por idioma (Popular, New, Top rated, Everything)
			templates = template if isinstance(template, (list, tuple)) else (template,)
			if _shape(url) not in [_shape(t) for t in templates]: return ''
		m = _LANG_IN_URL.search(url)
		lang = m.group(1) if m else ''
		return lang if lang in HELPER_LANGS else ''
	except Exception:
		return ''


def _connect():
	from resources.lib.database import cache
	dbcon = cache.get_connection()
	dbcon.execute('''CREATE TABLE IF NOT EXISTS %s (media TEXT, tmdb TEXT, lang TEXT, date INTEGER, UNIQUE(media, tmdb));''' % _TABLE)
	return dbcon


def register(url, items, media, template=None):
	"""Apunta los titulos de una lista de Languages. media: 'movie' o 'tv'."""
	try:
		lang = lang_from_url(url, template)
		if not lang or not items or not enabled(): return 0
		now = int(time())
		rows = [(media, str(i.get('tmdb')), lang, now) for i in items
				if isinstance(i, dict) and i.get('tmdb') and not _is_animation(i)]
		if not rows: return 0
		dbcon = _connect()
		try:
			dbcon.executemany('''INSERT OR REPLACE INTO %s Values (?, ?, ?, ?)''' % _TABLE, rows)
			dbcon.commit()
		finally:
			dbcon.close()
		return len(rows)
	except Exception:
		from resources.lib.modules import log_utils
		log_utils.error()
		return 0


def lookup(tmdb, media):
	"""Idioma con el que se registro el titulo, o ''. media acepta 'movie',
	'tv' y 'episode' (un episodio se busca por su serie)."""
	try:
		if not tmdb or not enabled(): return ''
		media = 'movie' if media == 'movie' else 'tv'
		dbcon = _connect()
		try:
			row = dbcon.execute('''SELECT * FROM %s WHERE media=? AND tmdb=?''' % _TABLE, (media, str(tmdb))).fetchone()
		finally:
			dbcon.close()
		if not row: return ''
		if (int(time()) - int(row['date'])) > REGISTRY_DAYS * 86400: return ''
		return row['lang'] if row['lang'] in HELPER_LANGS else ''
	except Exception:
		from resources.lib.modules import log_utils
		log_utils.error()
		return ''


def _api_key():
	key = control.setting('tmdb.api.key')
	if not key:
		from resources.lib.modules import app_keys
		key = app_keys.get('tmdb')
	return key


def _fetch_titles(tmdb, media):
	"""TMDb en ingles con alternative_titles. La URL lleva la clave, asi que
	no se escribe en el log en ningun caso."""
	import requests
	path = 'movie' if media == 'movie' else 'tv'
	url = 'https://api.themoviedb.org/3/%s/%s' % (path, tmdb)
	params = {'api_key': _api_key(), 'language': 'en-US', 'append_to_response': 'alternative_titles'}
	try:
		result = requests.get(url, params=params, timeout=8).json()
	except Exception:
		return None
	if not isinstance(result, dict) or not result.get('id'): return None
	genres = [g.get('id') for g in result.get('genres') or [] if isinstance(g, dict)]
	if media == 'movie':
		main, original = result.get('title') or '', result.get('original_title') or ''
		alts = (result.get('alternative_titles') or {}).get('titles') or []
		year = (result.get('release_date') or '')[:4]
		origin = [c.upper() for c in (result.get('origin_country') or [])]
		if not origin: origin = [c.get('iso_3166_1', '').upper() for c in (result.get('production_countries') or []) if isinstance(c, dict)]
	else:
		main, original = result.get('name') or '', result.get('original_name') or ''
		alts = (result.get('alternative_titles') or {}).get('results') or []
		year = (result.get('first_air_date') or '')[:4]
		origin = [c.upper() for c in (result.get('origin_country') or [])]
	home = [a.get('title') for a in alts if (a.get('iso_3166_1') or '').upper() in origin]
	# orden: titulo ingles, original, los del pais de origen, los de EE. UU./R. Unido, el resto
	ranked = [main, original] + home
	ranked += [a.get('title') for a in alts if (a.get('iso_3166_1') or '').upper() in ('US', 'GB')]
	ranked += [a.get('title') for a in alts]
	latin, seen = [], set()
	for t in ranked:
		t = (t or '').strip()
		if not t or is_native(t): continue
		n = norm_latin(t)
		if len(n) < 2 or n in seen: continue
		seen.add(n)
		latin.append(t)
	# en otra escritura solo el original y los de su pais: el titulo japones de
	# una pelicula francesa no ayuda a encontrarla
	native = []
	for t in [original] + home:
		t = (t or '').strip()
		if t and is_native(t) and t not in native: native.append(t)
	seasons = {}
	for s in result.get('seasons') or []:
		try:
			if int(s.get('season_number') or 0) > 0: seasons[str(int(s['season_number']))] = int(s.get('episode_count') or 0)
		except Exception: pass
	return {'latin': latin[:12], 'native': native[:4], 'year': year, 'seasons': seasons,
			'animation': ANIMATION_GENRE in genres, 'original_language': result.get('original_language') or ''}


def titles(tmdb, media):
	try:
		from resources.lib.database import cache
		return cache.get(_fetch_titles, TITLES_HOURS, str(tmdb), 'movie' if media == 'movie' else 'tv') or {}
	except Exception:
		from resources.lib.modules import log_utils
		log_utils.error()
		return {}


def absolute_number(seasons, season, episode):
	"""Numero absoluto del episodio contando las temporadas anteriores. Las
	series turcas se publican asi ("45. Bolum" para la 2x10)."""
	try:
		season, episode = int(season), int(episode)
		before = sum(int(seasons.get(str(s), 0) or 0) for s in range(1, season))
		if season > 1 and not before: return 0
		return before + episode
	except Exception:
		return 0
