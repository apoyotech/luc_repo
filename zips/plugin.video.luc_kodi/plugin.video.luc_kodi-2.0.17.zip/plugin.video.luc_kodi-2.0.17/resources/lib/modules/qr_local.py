# -*- coding: utf-8 -*-
"""
	luc_kodi Add-on
	qr_local.py (v2.0.15) - QR codes made on the device.

	Every sign-in used to ask api.qrserver.com for its QR, so the link with the
	user's code in it left the device for a third party, and the QR depended on
	that site being up. Now the QR is drawn here: the encoder is Project
	Nayuki's qrcodegen (MIT, resources/lib/externals) and the PNG is written by
	hand with zlib, so nothing outside the Python standard library is needed
	(Kodi on Android has no PIL).

	The PNG is sized to stay under Kodi's default <imageres> (720), so the
	texture cache keeps it as it is instead of resampling it, and each code gets
	its own file name so a cached texture of an older code is never shown.
"""

import os
import struct
import zlib
from hashlib import sha1

from resources.lib.modules import control

_DIR = 'special://temp/luc_kodi_qr/'
_MAX_PX = 720       # Kodi's default <imageres>
_BORDER = 2         # quiet zone in modules; the white tile around it adds the rest
_DARK, _LIGHT = 0x14, 0xFF


def _folder():
	path = control.transPath(_DIR)
	if not os.path.isdir(path): os.makedirs(path)
	return path


def _png(matrix, scale, border):
	"""8-bit greyscale PNG of a square module matrix (list of rows of bools)."""
	size = len(matrix)
	side = (size + 2 * border) * scale
	blank = bytes([_LIGHT]) * side
	raw = bytearray()
	for _ in range(border * scale): raw += b'\x00' + blank
	pad = bytes([_LIGHT]) * (border * scale)
	for row in matrix:
		line = bytearray(pad)
		for dark in row: line += bytes([_DARK if dark else _LIGHT]) * scale
		line += pad
		line = b'\x00' + bytes(line)
		for _ in range(scale): raw += line
	for _ in range(border * scale): raw += b'\x00' + blank

	def chunk(kind, data):
		return struct.pack('>I', len(data)) + kind + data + struct.pack('>I', zlib.crc32(kind + data) & 0xffffffff)
	header = struct.pack('>IIBBBBB', side, side, 8, 0, 0, 0, 0)
	return b'\x89PNG\r\n\x1a\n' + chunk(b'IHDR', header) + chunk(b'IDAT', zlib.compress(bytes(raw), 9)) + chunk(b'IEND', b'')


def matrix(text):
	"""Module matrix of `text` (error correction M, enough for a TV screen)."""
	from resources.lib.externals.qrcodegen import QrCode
	qr = QrCode.encode_text(str(text), QrCode.Ecc.MEDIUM)
	n = qr.get_size()
	return [[qr.get_module(x, y) for x in range(n)] for y in range(n)]


def make(text):
	"""Path of a PNG with the QR of `text`, or '' if it could not be made."""
	try:
		if not text: return ''
		m = matrix(text)
		scale = max(4, _MAX_PX // (len(m) + 2 * _BORDER))
		folder = _folder()
		name = 'qr_%s.png' % sha1(str(text).encode('utf-8')).hexdigest()[:16]
		path = os.path.join(folder, name)
		data = _png(m, scale, _BORDER)
		with open(path, 'wb') as f: f.write(data)
		clear(keep=name)
		return path
	except Exception:
		from resources.lib.modules import log_utils
		log_utils.error('qr_local.make')
		return ''


def clear(keep=None):
	"""Delete the QR files left in the temp folder (all but `keep`)."""
	try:
		folder = control.transPath(_DIR)
		if not os.path.isdir(folder): return
		for name in os.listdir(folder):
			if name != keep and name.startswith('qr_') and name.endswith('.png'):
				try: os.remove(os.path.join(folder, name))
				except Exception: pass
	except Exception: pass
