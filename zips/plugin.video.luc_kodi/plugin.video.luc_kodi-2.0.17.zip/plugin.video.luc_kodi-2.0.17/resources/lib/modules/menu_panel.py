# -*- coding: utf-8 -*-
"""
	luc_kodi Add-on
	menu_panel.py (v2.0.16) - the menus opened from the context panel, in a
	window in the style of the Assistant's welcome (windows/menu_select.py,
	menu_select.xml) instead of Kodi's select dialog.

	Trakt, MDBList, SIMKL, WeTrakr, PunchPlay and TVmaze Manager (and the lists
	and ratings they ask for next), Playlist Manager and Rescrape Options call
	select() with the same list of labels they gave control.selectDialog(), and
	get the same answer back: the index chosen, or -1.

	The window shows the item the menu belongs to (poster, title and the S02E03
	line the context panel showed a moment before), the menu name, and one
	full-width row per option, with an icon in the colour of its service.
	With the classic context menu style (Settings > Navigation) nothing changes:
	Kodi's own dialog opens, as before.
"""

import re
import time
from json import dumps as jsdumps, loads as jsloads
from resources.lib.modules import control

PROP_HEADER = 'luc_kodi.ctx.lastheader'
HEADER_TTL = 600  # seconds the context panel's header is used for the menus opened from it
HEADER_KEYS = ('poster', 'artkind', 'title', 'meta', 'rating', 'watched', 'progress')

# accent per service, the same ones the context panel uses for its Manager rows
SERVICE_COLOR = {
	'trakt': 'FFED1C24', 'mdblist': 'FFAA78FF', 'simkl': 'FF4FC3F7', 'wetrakr': 'FF26C6DA',
	'punchplay': 'FFFF7043', 'tvmaze': 'FF3C948B', 'sources': 'FFFFAA44', 'playlist': 'FFFDB515',
}
_BBCODE = re.compile(r'\[/?(?:COLOR[^\]]*|B|I|UPPERCASE|LOWERCASE|CAPITALIZE|LIGHT|CR)\]', re.I)

# (words in the label, icon): the first rule that matches wins
_ICON_RULES = (
	(('unwatch',), 'eye'),
	(('unrate', 'remove rating', 'clear rating', 'remove your rating'), 'x'),
	(('unfollow', 'unlike', 'undrop', 'unhide'), 'x'),
	(('restore', 'undo'), 'redo'),
	(('remove', 'delete', 'clear', 'drop'), 'trash'),
	(('watched', 'mark as watch', 'mark watch', 'check in', 'checkin'), 'check'),
	(('rate', 'rating'), 'star'),
	(('favourite', 'favorite', 'like'), 'heart'),
	(('follow', 'add', 'create', 'new list'), 'plus'),
	(('hide',), 'eye'),
	(('reset', 'restart', 'rescrape', 'sync'), 'redo'),
	(('filterless',), 'bolt'),
	(('custom query', 'search'), 'search'),
	(('playlist', 'queue'), 'queue'),
	(('autoplay', 'auto play', 'play'), 'play'),
	(('source select', 'select'), 'list'),
	(('collection',), 'folder'),
	(('list', 'manager', 'watchlist', 'show'), 'list'),
	(('info', 'details'), 'info'),
)


def clean(label):
	try: return _BBCODE.sub('', str(label)).strip()
	except Exception: return str(label)


def icon_for(label):
	low = clean(label).lower()
	if re.match(r'^\d+(\s|$|[-.:])', low): return 'star'  # rating pickers: "10 - Totally Ninja!"
	for words, icon in _ICON_RULES:
		if any(w in low for w in words): return icon
	return 'dot'


def remember_header(header):
	"""context_hub.show() keeps what its header showed, for the menus it opens."""
	try:
		h = dict((k, (header or {}).get(k, '') or '') for k in HEADER_KEYS)
		control.homeWindow.setProperty(PROP_HEADER, jsdumps({'t': time.time(), 'h': h}))
	except Exception: pass


def _last_header():
	try:
		data = jsloads(control.homeWindow.getProperty(PROP_HEADER) or '{}')
		if time.time() - float(data.get('t') or 0) <= HEADER_TTL: return data.get('h') or {}
	except Exception: pass
	return {}


def _menu_name(heading):
	"""'luc_kodi - Trakt Manager' -> 'Trakt Manager'."""
	text = clean(heading)
	try: name = clean(control.addonInfo('name'))
	except Exception: name = 'luc_kodi'
	for prefix in (name + ' - ', 'luc_kodi - '):
		if text.startswith(prefix): return text[len(prefix):]
	return text


def is_modern():
	try:
		from resources.lib.modules import context_hub
		return context_hub.is_modern()
	except Exception:
		return False


def select(labels, heading='', service='', title='', icons=None):
	"""Drop-in for control.selectDialog(labels, heading): index chosen or -1.
	icons: one icon name per label (ctx/ic_<name>.png), a single name for all
	of them, or None to pick each one from the label."""
	labels = list(labels or [])
	if not labels: return -1
	if not is_modern(): return control.selectDialog(labels, heading=heading)
	color = SERVICE_COLOR.get(service, 'FF00C8FF')
	if isinstance(icons, str): icons = [icons] * len(labels)
	names = [(icons[i] if icons and i < len(icons) and icons[i] else icon_for(label)) for i, label in enumerate(labels)]
	entries = [{'label': clean(label), 'icon': 'ctx/ic_%s.png' % names[i], 'color': color, 'tile': '2E' + color[2:]}
			   for i, label in enumerate(labels)]
	header = _last_header()
	if not header.get('title'):
		header = {'title': clean(title) or _menu_name(heading), 'artkind': 'icon', 'poster': control.addonIcon(), 'meta': ''}
	header = dict(header)
	menu = _menu_name(heading)
	t = clean(header.get('title') or '')
	# the title is already below it: "SIMKL - Tenzing (2026)" -> "SIMKL", "WeTrakr Manager - Dark Matter 2x03" -> "WeTrakr Manager"
	if t and ' - ' in menu:
		head, tail = menu.split(' - ', 1)
		show = clean(header.get('meta') or '').lower()
		if tail.lower().startswith(t.lower()) or (show and any(p and tail.lower().startswith(p.strip()) for p in show.split('·'))): menu = head
	if t and menu.lower() == t.lower(): menu = ''
	header['menu'] = menu
	if header.get('artkind') != 'poster': header['artkind'] = 'icon'
	if not header.get('poster'): header['poster'] = control.addonIcon()
	try: header['version'] = 'v%s' % control.addon('plugin.video.luc_kodi').getAddonInfo('version')
	except Exception: header['version'] = ''
	try:
		from resources.lib.windows.menu_select import MenuSelectXML
		control.hide()
		window = MenuSelectXML('menu_select.xml', control.addonPath(control.addonId()), entries=entries, header=header)
		chosen = window.run()
		del window
	except Exception:
		from resources.lib.modules import log_utils
		log_utils.error()
		return control.selectDialog(labels, heading=heading) # never leave the user without the menu
	return chosen if isinstance(chosen, int) and 0 <= chosen < len(labels) else -1
