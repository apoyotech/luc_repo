# -*- coding: utf-8 -*-
"""
	luc_kodi Add-on

	v2.0.13 - Sync your devices: credenciales entre aparatos de la misma red.

	Lleva de un luc_kodi a otro las credenciales que NO caducan ni cambian al
	usarse: claves de API, usuario y contrasena, y los tokens fijos de
	AllDebrid y TorBox. Las sesiones OAuth con token de renovacion (Trakt,
	SIMKL, MDBList, PunchPlay, WeTrakr, Real-Debrid, Premiumize) NO viajan:
	si dos aparatos compartieran el mismo token de renovacion, el primero que
	renovase dejaria al otro sin sesion.

	COMO
	  Menu propio en Tools y en Settings > Accounts (fuera de Premiere Lists).
	  Aparato B: Receive credentials. Queda esperando 5
	  minutos; solo en ese rato acepta credenciales, y solo de un aparato ya
	  emparejado.
	  Aparato A: Send credentials. Elige B y marca en la
	  lista lo que quiere mandar (solo salen las que tiene puestas).
	  B ensena lo que ha llegado, todo marcado, y guarda lo que el usuario deje
	  marcado. Nada se escribe sin que lo confirme quien esta delante de B.

	SEGURIDAD
	  Va por el mismo canal que las Premiere Lists: TCP en la red local, con
	  la clave de la pareja que salio del emparejamiento con PIN. Ademas de
	  firmarse, el contenido va CIFRADO (AES-256 en modo CTR, pyaes) con una
	  clave nueva en cada envio, derivada de la de la pareja y de los dos
	  nonces del intercambio. La firma cubre el texto cifrado. Lo recibido
	  pasa del servicio a la ventana por una propiedad en memoria que se borra
	  al terminar: nunca toca el disco ni el log, y solo se aceptan los
	  ajustes de esta lista, nunca otros.
"""
import hashlib
import hmac
import json
import os
import secrets
import time

from resources.lib.modules import control
from resources.lib.modules import log_utils
from resources.lib.modules import sync_ui

getLS = control.lang

WAIT_SECONDS = 300
MAX_VALUE = 4096
PROP_WAIT = 'luc_kodi.csync.wait'
PROP_INBOX = 'luc_kodi.csync.inbox'
YT_ID = 'plugin.video.youtube'
YT_FIELDS = ('api_key', 'client_id', 'client_secret')
YT_SETTINGS = {'api_key': 'youtube.api.key', 'client_id': 'youtube.api.id', 'client_secret': 'youtube.api.secret'}
GREY, AMBER, GREEN = 'ff9e9e9e', 'fffdb515', 'ff00fa9a'

# Etiquetas: 32781 '%s personal API key', 32782 '%s account', 32783 '%s API key',
# 32784 '%s API keys', 32785 '%s configuration'. Grupos: 32788-32793.
# 'ids'   = lo que es la credencial; con alguno puesto, se ofrece.
# 'extra' = lo que viaja con ella para que funcione al llegar (la instancia
#           del scraper, su interruptor, el 'Debrid detected' que se ensena).
CATALOG = (
	{'key': 'alldebrid', 'name': 'AllDebrid', 'fmt': None, 'group': 32788, 'icon': 'alldebrid.png',
		'ids': ('alldebrid.token',), 'extra': ('alldebrid.username', 'alldebrid.enable')},
	{'key': 'torbox', 'name': 'TorBox', 'fmt': None, 'group': 32788, 'icon': 'torbox.png',
		'ids': ('torbox.token',), 'extra': ('torbox.username', 'torbox.enable')},
	{'key': 'easynews', 'name': 'Easynews', 'fmt': 32782, 'group': 32788, 'icon': 'easynews.png',
		'ids': ('easynews.username', 'easynews.password'), 'extra': ('provider.easynews',)},
	{'key': 'dmm', 'name': 'DMM', 'fmt': 32783, 'group': 32788, 'icon': 'realdebrid.png',
		'ids': ('dmm.api_key',), 'extra': ('realdebrid.check_cache',)},
	{'key': 'torz', 'name': 'Torz', 'fmt': 32785, 'group': 32789, 'icon': '',
		'ids': ('torz.config',), 'extra': ('torz.url', 'torz.debrid.detected', 'provider.torz')},
	{'key': 'comet', 'name': 'Comet', 'fmt': 32785, 'group': 32789, 'icon': '',
		'ids': ('comet.config',), 'extra': ('comet.url', 'comet.debrid.detected', 'provider.comet')},
	{'key': 'mediafusion', 'name': 'MediaFusion', 'fmt': 32785, 'group': 32789, 'icon': '',
		'ids': ('mediafusion.secret',), 'extra': ('mediafusion.url', 'provider.mediafusion')},
	{'key': 'sootio', 'name': 'Sootio', 'fmt': 32785, 'group': 32789, 'icon': '',
		'ids': ('sootio.config',), 'extra': ('sootio.url', 'sootio.debrid.detected', 'sootio.sources.detected', 'provider.sootio')},
	{'key': 'meteor', 'name': 'Meteor', 'fmt': 32785, 'group': 32789, 'icon': '',
		'ids': ('meteor.config_token',), 'extra': ('meteor.debrid.detected', 'provider.meteor')},
	{'key': 'aiostreams', 'name': 'AIOStreams', 'fmt': 32785, 'group': 32789, 'icon': '',
		'ids': ('aiostreams.uuid', 'aiostreams.password'), 'extra': ('aiostreams.url', 'aiostreams.custom_url', 'aiostreams.debrid.detected', 'provider.aiostreams')},
	{'key': 'newznab', 'name': 'Newznab', 'fmt': 32785, 'group': 32789, 'icon': '',
		'ids': ('newznab.url', 'newznab.apikey'), 'extra': ('provider.newznab',)},
	{'key': 'orion', 'name': 'Orion', 'fmt': 32783, 'group': 32789, 'icon': '',
		'ids': ('orion.api_key',), 'extra': ('provider.orion',)},
	{'key': 'opensubtitles', 'name': 'OpenSubtitles', 'fmt': 32782, 'group': 32791, 'icon': '',
		'ids': ('opensubsusername', 'opensubspassword'), 'extra': ()},
	{'key': 'tmdb_key', 'name': 'TMDb', 'fmt': 32781, 'group': 32790, 'icon': 'tmdb.png',
		'ids': ('tmdb.api.key',), 'extra': ()},
	{'key': 'tmdb_account', 'name': 'TMDb', 'fmt': 32782, 'group': 32790, 'icon': 'tmdb.png',
		'ids': ('tmdb.username', 'tmdb.password', 'tmdb.session_id'), 'extra': ()},
	{'key': 'fanart', 'name': 'Fanart.tv', 'fmt': 32781, 'group': 32790, 'icon': '',
		'ids': ('fanart_tv.api_key',), 'extra': ()},
	{'key': 'tvdb', 'name': 'TheTVDB', 'fmt': 32781, 'group': 32790, 'icon': 'tvdb.png',
		'ids': ('tvdb.personal_key',), 'extra': ('tvdb.pin',)},
	{'key': 'tvmaze', 'name': 'TVmaze', 'fmt': 32782, 'group': 32790, 'icon': 'tvmaze.png',
		'ids': ('tvmaze.username', 'tvmaze.apikey'), 'extra': ('tvmaze.premium',)},
	{'key': 'omdb', 'name': 'OMDb', 'fmt': 32783, 'group': 32790, 'icon': '',
		'ids': ('omdb.apikey',), 'extra': ()},
	{'key': 'tidb', 'name': 'TheIntroDB', 'fmt': 32783, 'group': 32790, 'icon': '',
		'ids': ('tidb.api.key',), 'extra': ()},
	{'key': 'gemini', 'name': 'Gemini', 'fmt': 32784, 'group': 32792, 'icon': '',
		'ids': ('gemini.api.key', 'gemini.api.key2', 'gemini.api.key3', 'gemini.api.key4', 'gemini.api.key5'), 'extra': ()},
	{'key': 'youtube', 'name': 'YouTube add-on', 'fmt': 32784, 'group': 32793, 'icon': 'youtube.png',
		'ids': (), 'extra': ()},
)
BY_KEY = dict((c['key'], c) for c in CATALOG)


def label_of(entry):
	return getLS(entry['fmt']) % entry['name'] if entry['fmt'] else entry['name']

def _allowed(entry):
	return YT_FIELDS if entry['key'] == 'youtube' else tuple(entry['ids']) + tuple(entry['extra'])


# ---------------------------------------------------------------- leer y escribir

def _yt_path():
	return os.path.join(control.transPath('special://profile/'), 'addon_data', YT_ID, 'api_keys.json')

def _yt_read():
	"""Las claves personales del addon de YouTube: el bloque 'user' de
	api_keys.json (7.x), si no 'personal' (antiguas), si no sus ajustes."""
	out = dict((f, '') for f in YT_FIELDS)
	try:
		with open(_yt_path(), 'r', encoding='utf-8') as f:
			keys = (json.load(f) or {}).get('keys') or {}
		block = keys.get('user') or keys.get('personal') or {}
		for f in YT_FIELDS: out[f] = str(block.get(f) or '').strip()
	except: pass
	if not any(out.values()):
		try:
			import xbmcaddon
			yt = xbmcaddon.Addon(YT_ID)
			for f in YT_FIELDS: out[f] = (yt.getSetting(YT_SETTINGS[f]) or '').strip()
		except: pass
	return out

def _yt_write(values):
	"""Igual que el script del usuario: 'user' y 'personal' en api_keys.json,
	conservando lo demas del fichero, y tambien en los ajustes del addon."""
	path = _yt_path()
	data = {}
	try:
		with open(path, 'r', encoding='utf-8') as f: data = json.load(f) or {}
	except: data = {}
	if not isinstance(data, dict): data = {}
	keys = data.get('keys') if isinstance(data.get('keys'), dict) else {}
	block = dict((f, values.get(f, '')) for f in YT_FIELDS)
	keys['user'], keys['personal'] = dict(block), dict(block)
	keys.setdefault('developer', {})
	data['keys'] = keys
	try:
		folder = os.path.dirname(path)
		if not os.path.isdir(folder): os.makedirs(folder)
		tmp = path + '.tmp'
		with open(tmp, 'w', encoding='utf-8') as f: json.dump(data, f, indent=2)
		os.replace(tmp, path)
	except:
		log_utils.error()
		return False
	try:
		import xbmcaddon
		yt = xbmcaddon.Addon(YT_ID)
		for f in YT_FIELDS: yt.setSetting(YT_SETTINGS[f], block[f])
	except: pass
	return True

def current(entry):
	"""Lo que este aparato tiene ahora de esa credencial: {id: valor}."""
	if entry['key'] == 'youtube': return _yt_read()
	return dict((i, control.setting(i) or '') for i in _allowed(entry))

def _present(entry, values):
	if entry['key'] == 'youtube': return bool(values.get('api_key') or values.get('client_id'))
	return any(values.get(i) for i in entry['ids'])

def collect():
	"""Las credenciales que este aparato puede mandar: [(entry, valores)]."""
	out = []
	for entry in CATALOG:
		try:
			values = current(entry)
			if _present(entry, values): out.append((entry, values))
		except: log_utils.error()
	return out

def sanitize(items):
	"""Lo que llega se queda solo en lo que esta lista permite."""
	clean = {}
	if not isinstance(items, dict): return clean
	for key, values in items.items():
		entry = BY_KEY.get(key)
		if not entry or not isinstance(values, dict): continue
		allowed = _allowed(entry)
		kept = {}
		for sid, val in values.items():
			if sid in allowed and isinstance(val, str) and len(val) <= MAX_VALUE: kept[sid] = val
		if kept and _present(entry, kept): clean[key] = kept
	return clean

def apply(items):
	"""Guarda en este aparato. Devuelve cuantas credenciales se guardaron."""
	saved = 0
	for key, values in items.items():
		entry = BY_KEY.get(key)
		if not entry: continue
		try:
			if key == 'youtube':
				if _yt_write(values): saved += 1
				continue
			for sid in _allowed(entry):
				if sid in values: control.setSetting(sid, values[sid])
			if key == 'opensubtitles': control.setSetting('opensubstoken', '') # que inicie sesion con lo nuevo
			saved += 1
		except: log_utils.error()
	return saved

def status_of(entry, values):
	"""'same', 'new' o 'replace' respecto a lo que hay en este aparato."""
	mine = current(entry)
	if all((mine.get(k) or '') == v for k, v in values.items()): return 'same'
	return 'replace' if _present(entry, mine) else 'new'


# ---------------------------------------------------------------- cifrado

def _key(secret, nonce_s, nonce_c):
	return hmac.new(secret.encode('utf-8'), ('luc_kodi.csync.v1|%s|%s' % (nonce_s, nonce_c)).encode('utf-8'), hashlib.sha256).digest()

def _crypt(key, data):
	# CTR: cifrar y descifrar son la misma operacion. La clave es nueva en cada
	# envio (sale de los dos nonces), asi que el contador puede empezar en cero.
	from resources.lib.modules import pyaes
	return pyaes.AESModeOfOperationCTR(key).encrypt(data)

def seal(secret, nonce_s, nonce_c, obj):
	return _crypt(_key(secret, nonce_s, nonce_c), json.dumps(obj, separators=(',', ':')).encode('utf-8')).hex()

def unseal(secret, nonce_s, nonce_c, ct):
	return json.loads(_crypt(_key(secret, nonce_s, nonce_c), bytes.fromhex(ct)).decode('utf-8'))


# ---------------------------------------------------------------- estado de espera (memoria)

def receiving():
	try: return float(control.homeWindow.getProperty(PROP_WAIT) or 0) > time.time()
	except: return False

def _inbox():
	raw = control.homeWindow.getProperty(PROP_INBOX)
	if not raw: return None
	try: return json.loads(raw)
	except: return None


# ---------------------------------------------------------------- lado del que escucha (servicio)

def serve(conn, dbcon, req, me, nonce_s, addr):
	from resources.lib.modules import premiere_sync as ps
	pid, nonce_c, ct = ps._s(req.get('id'), 64), ps._s(req.get('nonce'), 64), req.get('ct')
	peer = ps._get_peer(dbcon, pid)
	if not peer or not nonce_c or not isinstance(ct, str) or len(ct) > ps.MAX_LINE: return conn.send({'ok': 0, 'err': 'unknown'})
	if not hmac.compare_digest(ps._s(req.get('mac'), 64), ps._mac(peer['secret'], 'creds', pid, nonce_s, nonce_c, ps._h(ct))):
		return conn.send({'ok': 0, 'err': 'unknown'})
	if not receiving(): return conn.send({'ok': 0, 'err': 'not_waiting'})
	if _inbox(): return conn.send({'ok': 0, 'err': 'busy'})
	try: clean = sanitize((unseal(peer['secret'], nonce_s, nonce_c, ct) or {}).get('items'))
	except: clean = {}
	if not clean: return conn.send({'ok': 0, 'err': 'bad'})
	name = ps._s(req.get('name'), 60) or peer['name']
	control.homeWindow.setProperty(PROP_INBOX, json.dumps({'from': name, 'id': pid, 'items': clean}))
	ps._touch_peer(dbcon, pid, host=addr[0], name=name)
	log_utils.log('Credentials sync: %d received from a paired device' % len(clean), level=log_utils.LOGINFO)
	conn.send({'ok': 1, 'n': len(clean), 'mac': ps._mac(peer['secret'], 'creds-ok', me, nonce_s, nonce_c, len(clean))})


# ---------------------------------------------------------------- lado del que manda

def deliver(peer, items, timeout=5):
	"""Manda las credenciales elegidas. Devuelve 'ok' o el motivo."""
	from resources.lib.modules import premiere_sync as ps
	try: conn = ps._open(peer['host'], peer['port'], timeout)
	except: return 'net'
	try:
		hello = conn.recv()
		if not hello or hello.get('app') != ps.APP: return 'net'
		if hello.get('id') != peer['id']: return 'moved'
		if not hello.get('cred'): return 'old'
		if not hello.get('receiving'): return 'not_waiting'
		dbcon = ps._connect()
		try: me, myname = ps.device_id(dbcon), ps.device_name(dbcon)
		finally: dbcon.close()
		nonce_s, nonce_c = ps._s(hello.get('nonce'), 64), secrets.token_hex(16)
		ct = seal(peer['secret'], nonce_s, nonce_c, {'v': 1, 'items': items})
		conn.send({'op': 'creds', 'id': me, 'name': myname, 'nonce': nonce_c, 'ct': ct,
			'mac': ps._mac(peer['secret'], 'creds', me, nonce_s, nonce_c, ps._h(ct))})
		r = conn.recv()
		if not r: return 'net'
		if not r.get('ok'): return r.get('err') or 'bad'
		if not hmac.compare_digest(ps._s(r.get('mac'), 64), ps._mac(peer['secret'], 'creds-ok', peer['id'], nonce_s, nonce_c, r.get('n'))): return 'bad'
		return 'ok'
	except Exception:
		log_utils.error()
		return 'net'
	finally: conn.close()


# ---------------------------------------------------------------- dialogos

def _art(name):
	if not name: return control.addonIcon()
	return os.path.join(control.artPath(), name)

# Los logos que el panel ya tiene (media/ctx); el resto lleva el glifo de su grupo
CTX_LOGOS = ('alldebrid.png', 'torbox.png', 'easynews.png', 'realdebrid.png', 'tmdb.png', 'tvdb.png', 'youtube.png', 'tvmaze.png')
GROUP_GLYPH = {32788: ('ctx/ic_cloud.png', 'FF00C8FF'), 32789: ('ctx/ic_search.png', 'FFFDB515'),
			   32790: ('ctx/ic_star.png', 'FFFDB515'), 32791: ('ctx/ic_list.png', 'FF00FA9A'),
			   32792: ('ctx/ic_spark.png', 'FFC77DFF'), 32793: ('ctx/ic_play.png', 'FFFF5252')}

def _cred_rows(pairs):
	"""pairs: (entry, hint) en el orden del CATALOG; una cabecera por grupo."""
	rows, last = [], None
	for entry, hint in pairs:
		if entry['group'] != last:
			glyph, color = GROUP_GLYPH.get(entry['group'], ('ctx/ic_dot.png', 'FFB0B0D0'))
			rows.append({'kind': 'header', 'key': 'group.%s' % entry['group'], 'label': getLS(entry['group']), 'icon': glyph, 'color': color})
			last = entry['group']
		glyph, color = GROUP_GLYPH.get(entry['group'], ('ctx/ic_dot.png', 'FFB0B0D0'))
		rows.append({'key': entry['key'], 'label': label_of(entry), 'hint': hint, 'classic_hint': hint or getLS(entry['group']),
					 'icon': glyph, 'color': color, 'tile': '2E' + color[2:], 'art': _art(entry['icon']),
					 'logo': 'ctx/logo_%s' % entry['icon'] if entry['icon'] in CTX_LOGOS else ''})
	return rows

def _peers():
	from resources.lib.modules import premiere_sync as ps
	dbcon = ps._connect()
	try: return ps.get_peers(dbcon), ps.device_name(dbcon)
	finally: dbcon.close()

def _title():
	return getLS(32817)

def menu():
	"""Tools y Accounts > Sync credentials with your devices. Lleva tambien el
	emparejamiento, que es el mismo de Premiere Lists: quien solo quiere pasar
	credenciales no tiene que entrar en las listas de estreno para emparejar.
	Con el panel, Back en un paso vuelve aqui; aqui, cierra."""
	from resources.lib.modules import premiere_sync as ps
	try:
		while True:
			peers, name = _peers()
			rows = []
			if peers:
				rows += [{'key': 'send', 'label': getLS(32762), 'hint': getLS(32801), 'icon': 'ctx/ic_redo.png',
						  'color': 'FF00FA9A', 'tile': '2E00FA9A', 'more': ps.CHEVRON},
						 {'key': 'receive', 'label': getLS(32763), 'hint': getLS(32802), 'icon': 'ctx/ic_download.png',
						  'color': 'FF00C8FF', 'tile': '2E00C8FF', 'more': ps.CHEVRON},
						 {'kind': 'header', 'key': 'pairing', 'label': getLS(32815), 'icon': 'ctx/ic_link.png', 'color': 'FF00C8FF'}]
			rows += ps.pairing_rows(peers, name, sync_row=False)
			key = sync_ui.choose(_title(), rows, crumb_text=ps.paired_text(len(peers)), meta=ps.device_line(name))
			if key in (None, sync_ui.BACK): return
			step = {'send': send, 'receive': receive}.get(key) or ps.STEPS[key]
			if step(root=_title()) != sync_ui.BACK: return
	except: log_utils.error()

def send(root=None):
	from resources.lib.modules import premiere_sync as ps
	root = root or _title()
	peers, _ = _peers()
	if not peers: return control.okDialog(title=getLS(32761), message=getLS(32767))
	where = sync_ui.crumb(root, getLS(32762))
	if len(peers) == 1: peer = peers[0]
	else:
		rows = [{'key': p['id'], 'label': p['name'], 'hint': '%s · %s' % (p['host'], getLS(32758) % ps._when(p['last_sync'])),
				 'classic': '%s  [COLOR %s]· %s[/COLOR]' % (p['name'], GREY, p['host']),
				 'icon': 'ctx/ic_play.png', 'color': 'FF00C8FF', 'tile': '2E00C8FF', 'more': ps.CHEVRON} for p in peers]
		key = sync_ui.choose(getLS(32764), rows, crumb_text=where, hint='')
		if key == sync_ui.BACK: return key
		peer = next((p for p in peers if p['id'] == key), None)
		if not peer: return
	offer = collect()
	if not offer: return control.okDialog(title=getLS(32761), message='%s[CR][CR]%s' % (getLS(32766), getLS(32780)))
	values = dict((e['key'], v) for e, v in offer)
	chosen = sync_ui.check(getLS(32762), _cred_rows([(e, '') for e, _ in offer]), [],
						   go_row=lambda n: (getLS(32795) % peer['name'], getLS(32796) % n if n else getLS(32797)),
						   all_labels=(getLS(32799), getLS(32800)), crumb_text=where,
						   meta=getLS(32765) % peer['name'], classic_heading=getLS(32765) % peer['name'])
	if chosen == sync_ui.BACK: return chosen
	if not chosen: return
	items = dict((k, values[k]) for k in chosen if k in values)
	control.busy()
	try:
		status = deliver(peer, items)
		if status in ('net', 'moved'):
			# la IP cambio (DHCP): se le busca por su id, como en la sincronizacion de listas
			hit = ps.discover(1.5, want_id=peer['id'], sweep=False).get(peer['id'])
			if hit and hit['host'] != peer['host']:
				peer = dict(peer, host=hit['host'], port=hit['port'])
				dbcon = ps._connect()
				try: ps._touch_peer(dbcon, peer['id'], host=peer['host'], port=peer['port'])
				finally: dbcon.close()
				status = deliver(peer, items)
	finally: control.hide()
	name = peer['name']
	if status == 'ok': return control.notification(title=getLS(32761), message=(getLS(32830) % name) if len(items) == 1 else (getLS(32770) % (len(items), name)), time=5000)
	if status == 'not_waiting': return control.okDialog(title=getLS(32761), message=getLS(32768) % (name, name))
	if status == 'busy': return control.okDialog(title=getLS(32761), message=getLS(32779) % name)
	if status == 'old': return control.okDialog(title=getLS(32761), message=getLS(32769) % name)
	if status in ('net', 'moved'): return control.okDialog(title=getLS(32761), message=getLS(32750) % name)
	return control.okDialog(title=getLS(32761), message=getLS(32778) % name)

def receive(root=None):
	from resources.lib.modules import premiere_sync as ps
	root = root or _title()
	peers, name = _peers()
	if not peers: return control.okDialog(title=getLS(32761), message=getLS(32767))
	home = control.homeWindow
	home.clearProperty(PROP_INBOX)
	home.setProperty(PROP_WAIT, str(time.time() + WAIT_SECONDS))
	if home.getProperty('luc_kodi.psync.listening') == 'fail': home.clearProperty('luc_kodi.psync.listening')
	ps._wake()
	where = sync_ui.crumb(root, getLS(32763))
	try:
		for _ in range(24):
			if home.getProperty('luc_kodi.psync.listening') in ('1', 'fail'): break
			if control.monitor.waitForAbort(0.25): return
		if home.getProperty('luc_kodi.psync.listening') != '1':
			return control.okDialog(title=getLS(32761), message=getLS(32753) % ps.PORT)
		text = '%s[CR][CR][COLOR %s]%s[/COLOR]' % (getLS(32771) % name, GREY, ps.device_line(name))
		res = sync_ui.wait(getLS(32763), _inbox, WAIT_SECONDS, big=name, text=text, crumb_text=where,
						   meta=getLS(32802), classic_text=lambda big, txt: txt.replace('[CR][CR]', '\n'))
		home.clearProperty(PROP_WAIT) # deja de aceptar en cuanto llega algo o se cierra
		if res == sync_ui.BACK: return res
		inbox = res if isinstance(res, dict) else _inbox()
		if not inbox: return
		items = sanitize(inbox.get('items'))
		if not items: return
		keys = [c['key'] for c in CATALOG if c['key'] in items]
		labels = {'same': getLS(32775), 'new': getLS(32777), 'replace': '[COLOR %s]%s[/COLOR]' % (AMBER, getLS(32776))}
		sender = inbox.get('from', '')
		rows = _cred_rows([(BY_KEY[k], labels[status_of(BY_KEY[k], items[k])]) for k in keys])
		chosen = sync_ui.check(getLS(32763), rows, keys,
							   go_row=lambda n: (getLS(32798), getLS(32796) % n if n else getLS(32797)),
							   all_labels=(getLS(32799), getLS(32800)), crumb_text=where,
							   meta=getLS(32772) % sender, classic_heading=getLS(32772) % sender)
		if not chosen or chosen == sync_ui.BACK: return
		saved = apply(dict((k, items[k]) for k in chosen if k in items))
		if saved: control.notification(title=getLS(32761), message=(getLS(32774) % sender) if saved == 1 else (getLS(32773) % (saved, sender)), time=5000)
	finally:
		home.clearProperty(PROP_WAIT)
		home.clearProperty(PROP_INBOX) # lo recibido no se queda en memoria
