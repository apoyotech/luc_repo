# -*- coding: utf-8 -*-
"""
	luc_kodi Add-on

	v2.0.13 - Premiere Movies.
	Lo mismo que Premiere TV Shows (premiere_lists.py) para peliculas: listas
	con nombre propio donde se apartan peliculas que aun no han salido en
	digital. La fecha que cuenta es la del estreno DIGITAL (alquiler, compra o
	streaming): hasta entonces no hay fuentes que reproducir. La de cines solo
	se ensena. Las mismas reglas que las series:
	  waiting    sin fecha digital, o a mas de WINDOW_DAYS (90) dias
	  scheduled  con fecha digital dentro de la ventana
	  added      ya en la biblioteca; sale de la lista a los KEEP_ADDED_DAYS dias
	El servicio relee las fechas en TMDb cada 12 horas, avisa la vispera y el
	dia, y el dia del estreno digital (con el retraso de 24 h de la biblioteca,
	si esta puesto) la mete en la biblioteca de peliculas.

	Fecha digital: la de Estados Unidos (tipo 4 de release_dates de TMDb), como
	el calendario Digital Releases del plugin; si Estados Unidos no la tiene, la
	primera de cualquier pais.

	Tablas propias (premiere_mlists, premiere_movies): los ids de TMDb de
	peliculas y de series son espacios distintos y no pueden compartir la clave
	(tmdb, season) de premiere_items. Las lapidas van en premiere_tombstones con
	kind 'mlist' (uid de la lista) y 'movie' (id de TMDb).

	Sincronizacion (premiere_sync.py): viajan en la seccion 'movies' del estado.
	Los aparatos con luc_kodi 2.0.12 o anterior no la leen ni la mandan: alli no
	llegan peliculas, y lo de las series sigue igual.
"""
from datetime import datetime, timedelta, timezone
from urllib.parse import quote_plus
import re
from resources.lib.modules import control
from resources.lib.modules import log_utils
from resources.lib.modules import premiere_lists as pl
from resources.lib.modules.context_hub import attach_cm

getLS = control.lang
WINDOW_DAYS = pl.WINDOW_DAYS
KEEP_ADDED_DAYS = pl.KEEP_ADDED_DAYS
REFRESH_HOURS = pl.REFRESH_HOURS
LIBRARY_RETRY_HOURS = pl.LIBRARY_RETRY_HOURS
OFFER_DAYS = 365 # el menu contextual solo lo ofrece si salio en cines hace menos de esto (o aun no)
GREEN, AMBER, GREY = pl.GREEN, pl.AMBER, pl.GREY
DIGITAL = 4
CINEMA = (2, 3)

_COLS = ('list_id', 'tmdb', 'imdb', 'title', 'year', 'digital_date', 'cinema_date', 'state', 'notified', 'added_on', 'poster', 'fanart', 'updated')

def _connect():
	return pl._connect() # crea tambien las tablas de peliculas

def _rows(dbcon, where='', args=()):
	rows = dbcon.execute('SELECT %s FROM premiere_movies %s' % (', '.join(_COLS), where), args).fetchall()
	return [dict(zip(_COLS, r)) for r in rows]

def _update(dbcon, item, **changes):
	item.update(changes)
	sets = ', '.join('%s=?' % k for k in changes)
	dbcon.execute('UPDATE premiere_movies SET %s WHERE tmdb=?' % sets, tuple(changes.values()) + (item['tmdb'],))

def get_lists():
	try:
		dbcon = _connect()
		try:
			rows = dbcon.execute('''SELECT l.id, l.name, COUNT(m.tmdb) FROM premiere_mlists l LEFT JOIN premiere_movies m ON m.list_id = l.id GROUP BY l.id ORDER BY l.name COLLATE NOCASE''').fetchall()
			return [{'id': r[0], 'name': r[1], 'count': r[2]} for r in rows]
		finally: dbcon.close()
	except:
		log_utils.error()
		return []

def offer(premiered):
	"""El menu contextual de una pelicula ofrece Add to Premiere Movies...: sin
	fecha, por estrenar o estrenada en cines hace menos de OFFER_DAYS."""
	d = pl._parse(premiered)
	return not d or d >= pl._today() - timedelta(days=OFFER_DAYS)


# ---------------------------------------------------------------- TMDb

def _details(tmdb):
	from resources.lib.indexers import tmdb as tmdb_indexer
	result = tmdb_indexer.Movies().get_movie_request(tmdb, light=True)
	if not result or isinstance(result, str) or not result.get('id'): return None
	return result

def _resolve_tmdb(imdb):
	try:
		from resources.lib.indexers import tmdb as tmdb_indexer
		result = tmdb_indexer.Movies().IdLookup(imdb)
		if isinstance(result, dict) and result.get('id'): return str(result['id'])
	except: log_utils.error()
	return ''

def dates(details):
	"""(digital, cines) como 'AAAA-MM-DD' o ''."""
	digital_us = cinema_us = None
	digital_any = []
	for country in ((details.get('release_dates') or {}).get('results') or []):
		cc = country.get('iso_3166_1')
		for r in country.get('release_dates') or []:
			d = pl._parse(r.get('release_date'))
			if not d: continue
			kind = r.get('type')
			if kind == DIGITAL:
				digital_any.append(d)
				if cc == 'US' and (digital_us is None or d < digital_us): digital_us = d
			elif kind in CINEMA and cc == 'US' and (cinema_us is None or d < cinema_us): cinema_us = d
	digital = digital_us or (min(digital_any) if digital_any else None)
	cinema = cinema_us or pl._parse(details.get('release_date'))
	return (digital.isoformat() if digital else ''), (cinema.isoformat() if cinema else '')

def _snapshot(details):
	release = details.get('release_date') or ''
	return {
		'title': details.get('title') or details.get('original_title') or '',
		'year': release[:4] if release else '',
		'imdb': details.get('imdb_id') or '',
		'poster': ('https://image.tmdb.org/t/p/w500%s' % details['poster_path']) if details.get('poster_path') else '',
		'fanart': ('https://image.tmdb.org/t/p/original%s' % details['backdrop_path']) if details.get('backdrop_path') else ''}

def _label(item):
	return '%s (%s)' % (item['title'], item['year']) if item.get('year') else item['title']

def _notify(item, message):
	control.notification(title=_label(item), message=message, icon=item.get('poster') or None, time=6000)
	control.sleep(6500)


# ---------------------------------------------------------------- alta desde el menu contextual

def add(title, year, imdb, tmdb):
	try:
		if not tmdb and imdb: tmdb = _resolve_tmdb(imdb)
		details = _details(tmdb) if tmdb else None
		if not details: return control.notification(title=title, message=32729)
		tmdb = str(details['id'])
		snap = _snapshot(details)
		name = snap['title'] or title
		digital, cinema = dates(details)
		d, c = pl._parse(digital), pl._parse(cinema)
		if d and d <= pl._today(): return control.notification(title=name, message=getLS(32820) % pl._fmt(d))
		if not d and c and c < pl._today() - timedelta(days=OFFER_DAYS): return control.notification(title=name, message=32821)
		dbcon = _connect()
		try:
			dupe = dbcon.execute('SELECT l.name FROM premiere_movies m JOIN premiere_mlists l ON l.id = m.list_id WHERE m.tmdb=?', (tmdb,)).fetchone()
			if dupe: return control.notification(title=name, message=getLS(32712) % dupe[0])
			list_id, list_name = _choose_list(dbcon)
			if not list_id: return
			state = pl._state_for(digital)
			values = {'list_id': list_id, 'tmdb': tmdb, 'imdb': snap['imdb'] or imdb or '', 'title': name, 'year': snap['year'] or year or '',
					  'digital_date': digital, 'cinema_date': cinema, 'state': state, 'notified': '', 'added_on': '',
					  'poster': snap['poster'], 'fanart': snap['fanart'], 'updated': pl.stamp()}
			dbcon.execute('INSERT INTO premiere_movies (%s) VALUES (%s)' % (', '.join(_COLS), ', '.join('?' * len(_COLS))), tuple(values[k] for k in _COLS))
			dbcon.commit()
		finally: dbcon.close()
		pl.mark_dirty()
		when = ('%s · %s' % (getLS(32715), pl._fmt(digital))) if (state == 'waiting' and digital) else getLS(32715) if state == 'waiting' else getLS(32826) % pl._fmt(digital)
		control.notification(title=_label(values), message='%s · %s' % (getLS(32711) % list_name, when), icon=snap['poster'] or None, time=5000)
	except:
		log_utils.error()

def _choose_list(dbcon):
	lists = dbcon.execute('SELECT id, name FROM premiere_mlists ORDER BY name COLLATE NOCASE').fetchall()
	if lists:
		labels = [r[1] for r in lists] + ['[COLOR %s]%s[/COLOR]' % (AMBER, getLS(32702))]
		pick = control.selectDialog(labels, heading=getLS(32710))
		if pick < 0: return None, None
		if pick < len(lists): return lists[pick][0], lists[pick][1]
	name = _ask_name(dbcon)
	if not name: return None, None
	cur = dbcon.execute('INSERT INTO premiere_mlists (name, created, uid, updated) VALUES (?, ?, ?, ?)', (name, pl._today().isoformat(), pl.new_uid(), pl.stamp()))
	dbcon.commit()
	return cur.lastrowid, name

def _ask_name(dbcon, current=''):
	while True:
		name = control.dialog.input(getLS(32703), defaultt=current).strip()
		if not name: return None
		taken = dbcon.execute('SELECT 1 FROM premiere_mlists WHERE name=? COLLATE NOCASE', (name,)).fetchone()
		if taken and name.lower() != current.lower():
			control.notification(message=32709)
			current = name
			continue
		return name


# ---------------------------------------------------------------- gestion de listas

def new_list():
	try:
		dbcon = _connect()
		try:
			name = _ask_name(dbcon)
			if not name: return
			dbcon.execute('INSERT INTO premiere_mlists (name, created, uid, updated) VALUES (?, ?, ?, ?)', (name, pl._today().isoformat(), pl.new_uid(), pl.stamp()))
			dbcon.commit()
		finally: dbcon.close()
		pl.mark_dirty()
		control.refresh()
	except: log_utils.error()

def rename_list(list_id):
	try:
		dbcon = _connect()
		try:
			row = dbcon.execute('SELECT name FROM premiere_mlists WHERE id=?', (int(list_id),)).fetchone()
			if not row: return
			name = _ask_name(dbcon, row[0])
			if not name or name == row[0]: return
			dbcon.execute('UPDATE premiere_mlists SET name=?, updated=? WHERE id=?', (name, pl.stamp(), int(list_id)))
			dbcon.commit()
		finally: dbcon.close()
		pl.mark_dirty()
		control.refresh()
	except: log_utils.error()

def delete_list(list_id):
	try:
		dbcon = _connect()
		try:
			row = dbcon.execute('SELECT name, uid FROM premiere_mlists WHERE id=?', (int(list_id),)).fetchone()
			if not row: return
			if not control.yesnoDialog(getLS(32706) % row[0], '', ''): return
			for (tmdb,) in dbcon.execute('SELECT tmdb FROM premiere_movies WHERE list_id=?', (int(list_id),)).fetchall():
				pl.tomb(dbcon, 'movie', tmdb, 'user')
			if row[1]: pl.tomb(dbcon, 'mlist', row[1], 'user')
			dbcon.execute('DELETE FROM premiere_movies WHERE list_id=?', (int(list_id),))
			dbcon.execute('DELETE FROM premiere_mlists WHERE id=?', (int(list_id),))
			dbcon.commit()
		finally: dbcon.close()
		pl.mark_dirty()
		control.refresh()
	except: log_utils.error()

def remove_item(tmdb):
	try:
		dbcon = _connect()
		try:
			pl.tomb(dbcon, 'movie', str(tmdb), 'user')
			dbcon.execute('DELETE FROM premiere_movies WHERE tmdb=?', (str(tmdb),))
			dbcon.commit()
		finally: dbcon.close()
		pl.mark_dirty()
		control.refresh()
	except: log_utils.error()


# ---------------------------------------------------------------- vigilancia (servicio)

def _due_refresh(dbcon):
	row = dbcon.execute("SELECT value FROM premiere_meta WHERE key='mlast_refresh'").fetchone()
	if not row: return True
	try: return datetime.now() - datetime.strptime(row[0], '%Y-%m-%d %H:%M:%S') >= timedelta(hours=REFRESH_HOURS)
	except: return True

def _refresh(dbcon, items, notices):
	"""Vuelve a leer las fechas en TMDb, una peticion por pelicula."""
	for item in items:
		if control.monitor.abortRequested(): return False
		details = _details(item['tmdb'])
		if not details: continue # sin red o sin respuesta: se conserva lo guardado
		snap = _snapshot(details)
		old_date, old_state = item['digital_date'], item['state']
		digital, cinema = dates(details)
		new_state = pl._state_for(digital)
		changes = {'digital_date': digital, 'cinema_date': cinema, 'state': new_state}
		for k in ('title', 'year', 'imdb', 'poster', 'fanart'):
			if snap[k]: changes[k] = snap[k]
		_update(dbcon, item, **changes)
		old_d, new_d = pl._parse(old_date), pl._parse(digital)
		if old_state == 'waiting' and new_state == 'scheduled':
			notices.append((item, getLS(32823) % pl._fmt(new_d)))
		elif old_state == 'scheduled' and old_d and (not new_d or new_d > old_d):
			notices.append((item, getLS(32824) % (pl._fmt(new_d) if new_d else getLS(32715))))
	dbcon.execute("INSERT OR REPLACE INTO premiere_meta VALUES ('mlast_refresh', ?)", (datetime.now().strftime('%Y-%m-%d %H:%M:%S'),))
	dbcon.commit()
	return True

def _to_library(item):
	"""1 si la pelicula esta en la biblioteca (escrita ahora o ya estaba), None si fallo."""
	from resources.lib.modules import library
	written = library.libmovies().add(_label(item), item['title'], item['year'], item['imdb'], item['tmdb'], range=True)
	return None if written is None else 1

def _may_try_library(dbcon, item, manual):
	key = 'mtry:%s' % item['tmdb']
	row = dbcon.execute('SELECT value FROM premiere_meta WHERE key=?', (key,)).fetchone()
	now = datetime.now()
	if row and not manual:
		try:
			if now - datetime.strptime(row[0], '%Y-%m-%d %H:%M:%S') < timedelta(hours=LIBRARY_RETRY_HOURS): return False
		except: pass
	dbcon.execute('INSERT OR REPLACE INTO premiere_meta VALUES (?, ?)', (key, now.strftime('%Y-%m-%d %H:%M:%S')))
	dbcon.commit()
	return True

def check(force_refresh=False, manual=False):
	"""Una pasada: refresco de fechas si toca, avisos, altas en la biblioteca y limpieza."""
	if not manual and control.condVisibility('Player.HasVideo'): return
	try: dbcon = _connect()
	except:
		log_utils.error()
		return
	written_any = False
	notices = []
	try:
		items = _rows(dbcon, 'WHERE state != ?', ('added',))
		if items and (force_refresh or _due_refresh(dbcon)):
			if not _refresh(dbcon, items, notices): return
		today, cutoff = pl._today(), pl._library_cutoff()
		for item in items:
			if control.monitor.abortRequested(): return
			if item['state'] != 'scheduled': continue
			d = pl._parse(item['digital_date'])
			if not d: continue
			eve_tag, day_tag = 'eve:%s' % d.isoformat(), 'day:%s' % d.isoformat()
			if d <= cutoff:
				if not _may_try_library(dbcon, item, manual): continue
				if _to_library(item):
					_update(dbcon, item, state='added', added_on=today.isoformat())
					dbcon.commit()
					written_any = True
					notices.append((item, getLS(32722)))
			elif d == today + timedelta(days=1) and item['notified'] != eve_tag:
				notices.append((item, getLS(32822)))
				_update(dbcon, item, notified=eve_tag)
			elif d == today and item['notified'] not in (eve_tag, day_tag):
				notices.append((item, getLS(32829)))
				_update(dbcon, item, notified=day_tag)
		done_cut = (today - timedelta(days=KEEP_ADDED_DAYS)).isoformat()
		done = dbcon.execute('SELECT tmdb FROM premiere_movies WHERE state=? AND added_on < ?', ('added', done_cut)).fetchall()
		for (tmdb,) in done: pl.tomb(dbcon, 'movie', tmdb, 'done')
		if done: pl.mark_dirty()
		dbcon.execute('DELETE FROM premiere_movies WHERE state=? AND added_on < ?', ('added', done_cut))
		dbcon.execute("DELETE FROM premiere_meta WHERE key LIKE 'mtry:%' AND substr(key, 6) NOT IN (SELECT tmdb FROM premiere_movies WHERE state != 'added')")
		dbcon.commit()
	except:
		log_utils.error()
	finally:
		try: dbcon.close()
		except: pass
	try:
		for item, message in notices:
			if control.monitor.abortRequested(): break
			_notify(item, message)
	except: log_utils.error()
	if written_any and control.setting('library.update') != 'false' and not control.condVisibility('Library.IsScanningVideo'):
		control.execute('UpdateLibrary(video)')
	if manual: control.notification(message=32732)


# ---------------------------------------------------------------- sincronizacion (seccion 'movies')

def snapshot(dbcon):
	lists, uid_of = [], {}
	for list_id, uid, name, created, updated in dbcon.execute('SELECT id, uid, name, created, updated FROM premiere_mlists').fetchall():
		uid_of[list_id] = uid
		lists.append({'uid': uid, 'name': name, 'created': created or '', 'updated': updated or ''})
	items = []
	for i in _rows(dbcon):
		uid = uid_of.get(i['list_id'])
		if not uid: continue
		items.append({'list': uid, 'tmdb': i['tmdb'], 'imdb': i['imdb'] or '', 'title': i['title'] or '', 'year': i['year'] or '',
			'digital': i['digital_date'] or '', 'cinema': i['cinema_date'] or '', 'poster': i['poster'] or '', 'fanart': i['fanart'] or '',
			'updated': i['updated'] or ''})
	tombs = [{'kind': k, 'key': key, 'ts': ts, 'reason': r} for k, key, ts, r in
			 dbcon.execute("SELECT kind, key, ts, reason FROM premiere_tombstones WHERE kind IN ('mlist', 'movie')").fetchall()]
	return {'lists': lists, 'items': items, 'tombs': tombs}

def _s(v, n=300):
	return v.strip()[:n] if isinstance(v, str) else ''

def _join_lists(dbcon, a_id, b_id):
	ua = dbcon.execute('SELECT uid FROM premiere_mlists WHERE id=?', (a_id,)).fetchone()[0] or ''
	ub = dbcon.execute('SELECT uid FROM premiere_mlists WHERE id=?', (b_id,)).fetchone()[0] or ''
	keep, drop = (a_id, b_id) if ua <= ub else (b_id, a_id)
	dbcon.execute('UPDATE premiere_movies SET list_id=? WHERE list_id=?', (keep, drop))
	dbcon.execute('DELETE FROM premiere_mlists WHERE id=?', (drop,))
	return keep

def merge(dbcon, data):
	"""Las mismas reglas que premiere_sync.merge para las series. True si cambio algo que se ve."""
	changed = False
	if not isinstance(data, dict): return False
	tomb_ts = lambda kind, key: (dbcon.execute('SELECT ts FROM premiere_tombstones WHERE kind=? AND key=?', (kind, key)).fetchone() or [''])[0]
	for t in data.get('tombs') or []:
		if not isinstance(t, dict): continue
		kind, key, ts, reason = _s(t.get('kind')), _s(t.get('key'), 64), _s(t.get('ts')), _s(t.get('reason'))
		if kind not in ('mlist', 'movie') or not key or not ts: continue
		if tomb_ts(kind, key) >= ts: continue
		dbcon.execute('INSERT OR REPLACE INTO premiere_tombstones VALUES (?, ?, ?, ?)', (kind, key, ts, reason or 'user'))
		if kind == 'mlist':
			row = dbcon.execute('SELECT id, updated FROM premiere_mlists WHERE uid=?', (key,)).fetchone()
			if row and (row[1] or '') <= ts:
				dbcon.execute('DELETE FROM premiere_movies WHERE list_id=?', (row[0],))
				dbcon.execute('DELETE FROM premiere_mlists WHERE id=?', (row[0],))
				changed = True
		elif reason != 'done': # 'done': cada aparato la mete en SU biblioteca y deja su propia lapida
			row = dbcon.execute('SELECT updated FROM premiere_movies WHERE tmdb=?', (key,)).fetchone()
			if row and (row[0] or '') <= ts:
				dbcon.execute('DELETE FROM premiere_movies WHERE tmdb=?', (key,))
				changed = True
	remap = {}
	for L in data.get('lists') or []:
		if not isinstance(L, dict): continue
		uid, name, updated = _s(L.get('uid'), 64), _s(L.get('name'), 100), _s(L.get('updated'))
		if not uid or not name: continue
		if tomb_ts('mlist', uid) >= updated: continue
		row = dbcon.execute('SELECT id, name, updated FROM premiere_mlists WHERE uid=?', (uid,)).fetchone()
		if row:
			lid = row[0]
			if updated > (row[2] or '') and name != row[1]:
				clash = dbcon.execute('SELECT id FROM premiere_mlists WHERE name=? COLLATE NOCASE AND id != ?', (name, lid)).fetchone()
				if clash: lid = _join_lists(dbcon, lid, clash[0])
				dbcon.execute('UPDATE premiere_mlists SET name=?, updated=? WHERE id=?', (name, updated, lid))
				changed = True
			remap[uid] = lid
			continue
		clash = dbcon.execute('SELECT id, uid, updated FROM premiere_mlists WHERE name=? COLLATE NOCASE', (name,)).fetchone()
		if clash:
			if uid < (clash[1] or ''):
				dbcon.execute('UPDATE premiere_mlists SET uid=?, updated=? WHERE id=?', (uid, max(updated, clash[2] or ''), clash[0]))
			remap[uid] = clash[0]
			continue
		cur = dbcon.execute('INSERT INTO premiere_mlists (name, created, uid, updated) VALUES (?, ?, ?, ?)', (name, _s(L.get('created'), 10), uid, updated))
		remap[uid] = cur.lastrowid
		changed = True
	for I in data.get('items') or []:
		if not isinstance(I, dict): continue
		tmdb, updated = _s(str(I.get('tmdb') or ''), 20), _s(I.get('updated'))
		if not tmdb.isdigit() or not updated: continue
		if tomb_ts('movie', tmdb) >= updated: continue
		lid = remap.get(_s(I.get('list'), 64))
		if not lid: continue
		row = dbcon.execute('SELECT list_id, updated FROM premiere_movies WHERE tmdb=?', (tmdb,)).fetchone()
		if row:
			if updated > (row[1] or ''):
				dbcon.execute('UPDATE premiere_movies SET list_id=?, updated=? WHERE tmdb=?', (lid, updated, tmdb))
				if row[0] != lid: changed = True
			continue
		digital = _s(I.get('digital'), 10)
		values = {'list_id': lid, 'tmdb': tmdb, 'imdb': _s(I.get('imdb'), 20), 'title': _s(I.get('title'), 200), 'year': _s(str(I.get('year') or ''), 4),
			'digital_date': digital, 'cinema_date': _s(I.get('cinema'), 10), 'state': pl._state_for(digital), 'notified': '', 'added_on': '',
			'poster': _s(I.get('poster'), 500), 'fanart': _s(I.get('fanart'), 500), 'updated': updated}
		dbcon.execute('INSERT INTO premiere_movies (%s) VALUES (%s)' % (', '.join(_COLS), ', '.join('?' * len(_COLS))), tuple(values[c] for c in _COLS))
		changed = True
	dbcon.commit()
	return changed


# ---------------------------------------------------------------- directorios

def lists_directory():
	sysaddon, handle = pl._sysaddon()
	paired = 0
	try:
		from resources.lib.modules import premiere_sync
		paired = premiere_sync.peer_count()
		if paired: premiere_sync.quick_sync()
	except: log_utils.error()
	try:
		for l in get_lists():
			item = control.item(label='%s  [COLOR %s](%s)[/COLOR]' % (l['name'], GREY, l['count']), offscreen=True)
			item.setArt({'icon': 'DefaultVideoPlaylists.png', 'thumb': 'DefaultVideoPlaylists.png', 'fanart': control.addonFanart()})
			attach_cm(item, [
				(getLS(32704), 'RunPlugin(%s?action=library_premiereMovieRename&list_id=%s)' % (sysaddon, l['id'])),
				(getLS(32705), 'RunPlugin(%s?action=library_premiereMovieDelete&list_id=%s)' % (sysaddon, l['id'])),
				(getLS(32708), 'RunPlugin(%s?action=library_premiereMovieCheck)' % sysaddon)])
			control.addItem(handle=handle, url='%s?action=library_premiereMovieList&list_id=%s' % (sysaddon, l['id']), listitem=item, isFolder=True)
		item = control.item(label='[COLOR %s]%s[/COLOR]' % (AMBER, getLS(32702)), offscreen=True)
		item.setArt({'icon': 'DefaultAddSource.png', 'thumb': 'DefaultAddSource.png', 'fanart': control.addonFanart()})
		control.addItem(handle=handle, url='%s?action=library_premiereMovieNewList' % sysaddon, listitem=item, isFolder=False)
		label = getLS(32733) + ('  [COLOR %s](%s)[/COLOR]' % (GREY, getLS(32759) % paired) if paired else '')
		item = control.item(label=label, offscreen=True)
		item.setArt({'icon': 'DefaultNetwork.png', 'thumb': 'DefaultNetwork.png', 'fanart': control.addonFanart()})
		control.addItem(handle=handle, url='%s?action=library_premiereSync' % sysaddon, listitem=item, isFolder=False)
	except: log_utils.error()
	pl._end(handle, 'files')

def _status(item):
	if item['state'] == 'added': return '[COLOR %s]%s[/COLOR]' % (GREEN, getLS(32727))
	d = pl._parse(item['digital_date'])
	if item['state'] == 'waiting':
		return '[COLOR %s]%s%s[/COLOR]' % (GREY, getLS(32715), (' · %s %d' % (pl.MONTHS[d.month - 1], d.year)) if d else '')
	if not d: return '[COLOR %s]%s[/COLOR]' % (GREY, getLS(32715))
	days = (d - pl._today()).days
	if days < 0: return '[COLOR %s]%s[/COLOR]' % (AMBER, getLS(32825))
	when = getLS(32724) if days == 0 else getLS(32725) if days == 1 else getLS(32726) % days
	return '[COLOR %s]%s[/COLOR] [COLOR %s]· %s[/COLOR]' % (GREEN if days <= 1 else AMBER, when, GREY, getLS(32826) % pl._fmt(d))

def _plot(item):
	lines = [_label(item), re.sub(r'\[/?COLOR[^\]]*\]', '', _status(item))]
	if item['digital_date']: lines.append(getLS(32826) % pl._fmt(item['digital_date']))
	if item['cinema_date']: lines.append(getLS(32827) % pl._fmt(item['cinema_date']))
	return '\n'.join(lines)

def list_directory(list_id):
	sysaddon, handle = pl._sysaddon()
	try:
		dbcon = _connect()
		try: items = _rows(dbcon, 'WHERE list_id=?', (int(list_id),))
		finally: dbcon.close()
		order = {'scheduled': 0, 'waiting': 1, 'added': 2}
		items.sort(key=lambda i: (order.get(i['state'], 3), i['digital_date'] or '9999', (i['title'] or '').lower()))
		for i in items:
			label = '[B]%s[/B]  %s' % (_label(i), _status(i))
			systitle = quote_plus(i['title'])
			item = control.item(label=label, offscreen=True)
			poster = i['poster'] or control.missingPoster()
			item.setArt({'poster': poster, 'thumb': poster, 'icon': poster, 'fanart': i['fanart'] or control.missingFanart()})
			try:
				tag = item.getVideoInfoTag()
				tag.setMediaType('movie')
				tag.setTitle(i['title'])
				if i['year']: tag.setYear(int(i['year']))
				if i['digital_date']: tag.setPremiered(i['digital_date'])
				tag.setPlot(_plot(i))
			except: pass
			attach_cm(item, [
				('Play Trailer', 'PlayMedia(%s?action=play_Trailer&type=movie&name=%s&year=%s&imdb=%s&tmdb=%s&url=)' % (sysaddon, systitle, i['year'], i['imdb'], i['tmdb'])),
				(getLS(32707), 'RunPlugin(%s?action=library_premiereMovieRemove&tmdb=%s)' % (sysaddon, i['tmdb'])),
				(getLS(32708), 'RunPlugin(%s?action=library_premiereMovieCheck)' % sysaddon)])
			# como en las listas de peliculas: buscar fuentes (si ya salio en digital antes de lo que dice TMDb, se puede ver)
			url = '%s?action=play_Item&title=%s&year=%s&imdb=%s&tmdb=%s' % (sysaddon, systitle, i['year'], i['imdb'], i['tmdb'])
			item.setProperty('IsPlayable', 'true')
			control.addItem(handle=handle, url=url, listitem=item, isFolder=False)
		if not items:
			item = control.item(label='[COLOR %s]%s[/COLOR]' % (GREY, getLS(32828)), offscreen=True)
			item.setArt({'icon': 'DefaultIconInfo.png', 'thumb': 'DefaultIconInfo.png', 'fanart': control.addonFanart()})
			control.addItem(handle=handle, url='%s?action=library_premiereNoop' % sysaddon, listitem=item, isFolder=False)
	except: log_utils.error()
	pl._end(handle, 'movies')
