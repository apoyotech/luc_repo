# -*- coding: utf-8 -*-
"""
	luc_kodi Add-on — kodi_objects.py (v2.0.14)

	Kodi objects (Window, Monitor, Player, PlayList, Dialog, DialogProgress,
	Addon) that the plugin keeps as module globals, created when first used and
	released when the run is over.

	Why: control.py (and jacksparrow/control.py) built them when the module was
	imported and kept them for ever. With reuselanguageinvoker the modules stay
	loaded between runs, so when Kodi finally stopped the interpreter it found
	them still alive and wrote:
	  "the python script ... has left several classes in memory that we
	   couldn't clean up. The classes include: Window, Monitor, Player,
	   PlayList, Addon, DialogProgress, DialogProgressBG, Dialog ..."

	How: Lazy() is a plain Python object, which Kodi does not track. It makes
	the real object the first time something is asked of it and keeps it until
	release(), so `control.homeWindow.getProperty(...)` works exactly as before.
	A Kodi function that needs the object itself, not its methods
	(Player().play(playlist)), gets it with ._real().

	When: luc_kodi.py calls run_started() before the router and release() when
	it returns. Threads of the run can still be working then (scrapers that had
	not answered, a count behind the welcome window...) and may use the objects
	again, so release() drops what it can at once and leaves a janitor thread
	that drops the rest when the last of them ends. Kodi waits for the threads
	of a script before it checks, so by then nothing is left.
	(Waiting for those threads instead and, if they were still running,
	releasing nothing left Window, Addon, Monitor and PlayList in the log.)

	A progress dialog that is open (create() without close()) is never dropped
	while something may still be using it: dropping the object closes it on
	screen.
"""

import threading
import time

_REGISTRY = []
_LOCK = threading.Lock()
_STATE = {'running': False, 'janitor': None}


class Lazy(object):
	__slots__ = ('_factory', '_obj', '_name', '_busy')

	def __init__(self, factory, name=''):
		self._factory = factory
		self._obj = None
		self._name = name
		self._busy = False
		_REGISTRY.append(self)

	def _real(self):
		obj = self._obj
		if obj is None:
			with _LOCK:
				obj = self._obj
				if obj is None:
					obj = self._obj = self._factory()
		return obj

	def __getattr__(self, attr):
		return getattr(self._real(), attr)

	def _release(self):
		self._obj = None
		self._busy = False

	def _alive(self):
		return self._obj is not None

	def __repr__(self):
		return '<Lazy %s%s>' % (self._name or 'kodi object', '' if self._obj is None else ' (made)')


class LazyProgress(Lazy):
	"""A DialogProgress or DialogProgressBG: open between create() and close()."""
	__slots__ = ()

	def create(self, *args, **kwargs):
		result = self._real().create(*args, **kwargs)
		self._busy = True
		return result

	def close(self, *args, **kwargs):
		obj = self._obj
		self._busy = False
		# never made: nothing on screen to close (before, close() made one to close it)
		if obj is None: return None
		return obj.close(*args, **kwargs)


def _log(msg):
	try:
		import xbmc
		xbmc.log('[ luc_kodi ] kodi_objects: %s' % msg, xbmc.LOGDEBUG)
	except Exception:
		pass


def _others():
	"""Threads started by this script that are still running, other than the
	caller. Kodi's own threads (seen by Python as dummy threads) and the
	interpreter's main thread are not counted: they are not doing our work."""
	current = threading.current_thread()
	main = threading.main_thread()
	return [t for t in threading.enumerate()
			if t is not current and t is not main and t.is_alive()
			and not isinstance(t, threading._DummyThread)
			and t is not _STATE['janitor']]


def _drop(keep_busy):
	dropped, kept = [], []
	for proxy in _REGISTRY:
		if not proxy._alive(): continue
		if keep_busy and proxy._busy:
			kept.append(proxy._name)
			continue
		proxy._release()
		dropped.append(proxy._name)
	return dropped, kept


def run_started():
	_STATE['running'] = True


def release(force=False, wait=0.0):
	"""End of a run: drop every Kodi object made through Lazy. Threads of this
	script still running keep an open progress dialog for now, and a janitor
	drops the rest when they end. force drops everything (the service, when
	Kodi stops). True when nothing is left."""
	_STATE['running'] = False
	others = _others()
	if others and wait > 0:
		end = time.time() + wait
		while others and time.time() < end:
			time.sleep(0.05)
			others = _others()
	dropped, kept = _drop(keep_busy=bool(others) and not force)
	if dropped or kept or others:
		_log('released %s%s%s' % (', '.join(dropped) or 'nothing',
			('; kept open: %s' % ', '.join(kept)) if kept else '',
			('; %d thread(s) still running: %s' % (len(others), ', '.join(t.name for t in others[:6]))) if others else ''))
	if others and not force: _start_janitor()
	return not kept and (force or not others)


def _start_janitor():
	with _LOCK:
		t = _STATE['janitor']
		if t is not None and t.is_alive(): return
		t = threading.Thread(target=_janitor, name='luc_kodi objects janitor')
		t.daemon = True
		_STATE['janitor'] = t
	t.start()


def _janitor(limit=1800.0, step=0.25):
	end = time.time() + limit
	try:
		while True:
			while time.time() < end and _others():
				time.sleep(step)
			# objects made again by those threads; an open progress dialog only
			# when no run is going on (a new run's own dialog is not ours to close)
			dropped, kept = _drop(keep_busy=_STATE['running'] or bool(_others()))
			if dropped or kept:
				_log('janitor released %s%s' % (', '.join(dropped) or 'nothing', ('; kept open: %s' % ', '.join(kept)) if kept else ''))
			with _LOCK:
				# a release() meanwhile found this janitor alive and left its threads to it
				if _others() and time.time() < end: continue
				_STATE['janitor'] = None
				return
	except Exception:
		_STATE['janitor'] = None


def alive():
	"""Names of the objects made and not released (for tests and the log)."""
	return [p._name for p in _REGISTRY if p._alive()]
