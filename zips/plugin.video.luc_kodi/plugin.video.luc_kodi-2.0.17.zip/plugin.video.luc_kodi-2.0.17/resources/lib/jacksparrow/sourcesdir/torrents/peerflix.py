# created by luc_kodi for jacksparrowscrapers
"""
jacksparrowscrapers Project
Fuente: Peerflix (Stremio add-on: com.keopps.peerflix)

Formato real del stream object (addon.peerflix.mov, oct-2026):
  name:  "Peerflix 🇪🇸 1080p"          → bandera + calidad
  title/description:
         "Titulo humano [tags]\n       → línea 0: título legible (opcional)
          Filename.mkv\n               → línea 1: fichero real con extensión
          👤 3 💾 1.37 GB 🌐 Origen"     → última línea: seeders, tamaño y la web
                                         de donde Peerflix saco el torrent

Peerflix es una fuente de España (comprobado el 21-oct-2026, manifest 2.12.0):
con language=es trae los releases en castellano; con language=en devuelve 0
streams en casi todo (Interstellar, Gladiator II, Dune: Part Two, Matrix, Juego
de Tronos) y solo quedan restos de un indice ingles viejo en algun titulo suelto.
Por eso se pide siempre 'es', una sola vez.

Configuración Kodi (settings.xml):
  peerflix.language       → 0 = solo los que llevan tambien audio ingles (dual)
                            1 = todos (castellano, con o sin ingles)
  peerflix.qualityfilter  → calidades que se dejan fuera (en la API y aqui)
  peerflix.min.seeders    → mínimo de seeders para incluir resultado

v2.0.13:
  - el proveedor es siempre 'peerflix'. El "🌐 Origen" (Peerflix, PeerflixBot,
    BitSearch, DonTorrent...) es la web de la que Peerflix saco el torrent; como
    proveedor dividia la lista en nombres que nadie reconocia como Peerflix;
  - fuera la peticion doble en paralelo (en + es): Peerflix solo contesta 'es';
  - la reserva peerflix.mov es una copia estatica (IPFS): no acepta la
    configuracion en la ruta, se le pide /stream/... sin ella y las calidades
    excluidas se quitan aqui.
"""
from urllib.parse import quote
from json import loads as jsloads
import re
from resources.lib.jacksparrow import client
from resources.lib.jacksparrow import source_utils
from resources.lib.jacksparrow.control import setting as getSetting

# ── Regex helpers ──────────────────────────────────────────────────────────────
_META_RE   = re.compile(r'[👤💾🌐]')
_VIDEO_EXT = re.compile(r'\.(mkv|avi|mp4|mov|m4v|ts|m2ts|wmv)$', re.IGNORECASE)
_SIZE_RE   = re.compile(r'([\d]+(?:[.,]\d+)?\s*(?:GB|GiB|Gb|MB|MiB|Mb))', re.IGNORECASE)
_FLAG_RE   = re.compile('[\U0001F1E6-\U0001F1FF]{2}')
_MULTI_RE  = re.compile(r'\b(multi|dual|dl)\b', re.IGNORECASE)
# v2.0.13: audio doble con ingles escrito a la española: [ES-EN], ESP.ENG,
# "Castellano-Ingles+Subs", "AC3 5.1-Ingles"; v2.0.13: y "Lat-Cast-Ing"
_EN_AUDIO_RE = re.compile(r'(\bes[-_. ]?en\b|\besp[-_. ]eng\b|ingl[eé]s|\benglish\b|\beng\b|\bing\b)', re.IGNORECASE)
_YEAR_RE   = re.compile(r'(?<!\d)((?:19|20)\d{2})(?!\d)')

# ── Flag → idioma ISO-639-1 ────────────────────────────────────────────────────
_FLAG_LANG = {
    '🇪🇸': 'es', '🇲🇽': 'es', '🇦🇷': 'es', '🇨🇴': 'es', '🇵🇪': 'es',
    '🇬🇧': 'en', '🇺🇸': 'en',
    '🇫🇷': 'fr', '🇧🇪': 'fr',
    '🇩🇪': 'de', '🇦🇹': 'de',
    '🇮🇹': 'it',
    '🇵🇹': 'pt', '🇧🇷': 'pt',
    '🇷🇺': 'ru',
    '🇯🇵': 'ja', '🇰🇷': 'ko', '🇨🇳': 'zh',
    '🇳🇱': 'nl', '🇵🇱': 'pl', '🇹🇷': 'tr',
}

# ── Opciones de qualityfilter (índice → valor para la API) ─────────────────────
_QF_MAP = {
    '0': '',                                   # Sin filtro
    '1': 'screener,vhs,cam',                   # Excluir CAM/Screener
    '2': 'screener,vhs,cam,sd',                # + SD
}
# v2.0.13: lo mismo en las calidades de luc_kodi, para la reserva estatica (que
# no filtra) y por si la API deja pasar algo
_QF_DROP = {'0': (), '1': ('CAM', 'SCR'), '2': ('CAM', 'SCR', 'SD')}


def _parse_stream(file):
    """
    Parsea un objeto stream de Peerflix y devuelve un dict con los campos
    necesarios para construir el item de fuente.
    """
    name_field  = file.get('name') or ''
    title_field = (file.get('title') or file.get('description') or '').replace('┈➤', '\n')

    lines = [l.strip() for l in title_field.split('\n') if l.strip()]

    meta_line     = ''
    content_lines = []
    for line in lines:
        if _META_RE.search(line):
            meta_line = line
        else:
            content_lines.append(line)

    # Filename: línea con extensión de vídeo; fallback → última línea de contenido
    filename = ''
    for line in reversed(content_lines):
        if _VIDEO_EXT.search(line):
            filename = line
            break
    if not filename:
        filename = content_lines[-1] if content_lines else ''

    # Web de origen desde "🌐 BitSearch" (solo para el log: el proveedor es Peerflix)
    m_prov = re.search(r'🌐\s*(\S+)', meta_line)
    origin = m_prov.group(1) if m_prov else 'Peerflix'

    # Seeders desde "👤 3"
    m_seed  = re.search(r'👤\s*(\d+)', meta_line)
    seeders = int(m_seed.group(1)) if m_seed else 0

    # Tamaño: behaviorHints > "💾 X GB" en meta_line > "[1.37GB]" en contenido
    size_str   = ''
    hints      = file.get('behaviorHints') or {}
    video_size = int(hints.get('videoSize') or 0)
    if video_size > 0:
        size_str = '%.2f GB' % (video_size / 1073741824)
    else:
        m_size = re.search(r'💾\s*' + _SIZE_RE.pattern, meta_line, re.IGNORECASE)
        if m_size:
            size_str = m_size.group(1)
        else:
            for line in content_lines:
                m_br = re.search(r'\[(' + _SIZE_RE.pattern[1:-1] + r')\]', line, re.IGNORECASE)
                if m_br:
                    size_str = m_br.group(1)
                    break
            if not size_str:
                m_any = _SIZE_RE.search(meta_line)
                if m_any:
                    size_str = m_any.group(1)

    # Idioma desde flag en name_field ("Peerflix 🇪🇸 1080p")
    lang        = 'en'
    flag_match  = re.search('[\U0001F1E6-\U0001F1FF]{2}', name_field)
    if flag_match:
        lang = _FLAG_LANG.get(flag_match.group(0), file.get('language') or 'en')
    elif file.get('language'):
        lang = file['language'].lower()

    # ── Todos los idiomas detectados (client-side filter, v1.0.31) ─────────────
    # Un stream multi-audio puede traer varias flags; las recogemos todas de
    # name + title, más el campo 'language' si existe, más la marca MULTI/DUAL.
    langs    = set()
    all_text = '%s %s' % (name_field, title_field)
    for flag in _FLAG_RE.findall(all_text):
        code = _FLAG_LANG.get(flag)
        if code:
            langs.add(code)
    if file.get('language'):
        langs.add(str(file['language']).lower())
    is_multi = bool(_MULTI_RE.search(all_text))
    if is_multi:
        langs.add('multi')
    if _EN_AUDIO_RE.search(all_text):
        langs.add('en')
    if not langs:
        # Sin flag ni campo language: release scene típica -> asumimos inglés
        langs.add('en')

    return {
        'filename'    : filename,
        'all_names'   : content_lines,
        'origin'      : origin,
        'seeders'     : seeders,
        'lang'        : lang,
        'langs'       : langs,
        'lang_hint'   : ' '.join(_FLAG_RE.findall(all_text)) + (' multi' if is_multi else ''),
        'is_multi'    : is_multi,
        'size_str'    : size_str,
    }


def _id_match(parsed, is_tv, year, season, episode):
    """v2.0.13: la linea del stream que dice el año pedido (pelicula, con un año
    de margen) o la temporada y el episodio pedidos (1x01, 01x01, S01E01,
    Cap.101). None si ninguna lo dice: entonces el release no se acepta por
    esta via."""
    lines = [parsed['filename']] + [l for l in parsed['all_names'] if l != parsed['filename']]
    if is_tv:
        pat = _episode_re(season, episode)
        for line in lines:
            if line and pat.search(line): return line
        return None
    try: wanted = int(year)
    except Exception: return None
    # v2.0.13: muchas releases en castellano no llevan año ("Mad Max Furia en la
    # carretera [4K UHDremux][2160p]...", "Gladiator II BDrip XviD Castellano").
    # La busqueda es por IMDb, asi que sin año se acepta; lo que se descarta es
    # la que dice OTRO año (Peerflix mezcla a veces "Dune (2021)" en Dune: Part Two).
    other_year = False
    for line in lines:
        years = [int(y) for y in _YEAR_RE.findall(line or '')]
        if years and any(abs(y - wanted) <= 1 for y in years): return line
        if years: other_year = True
    if other_year: return None
    return next((l for l in lines if l), None)


_SITE_TAG_RE = re.compile(r'^\s*\[[^\]]*\.(?:to|com|org|net|me|cc|tv)\]\s*', re.IGNORECASE)
_PF_QUALITY = (('4K', re.compile(r'\b(4k|2160p)\b', re.I)), ('1080p', re.compile(r'1080p', re.I)), ('720p', re.compile(r'720p', re.I)))


def _display(parsed, matched):
    """v2.0.13: el nombre que se ensena. El fichero de muchas releases en
    castellano es ilegible ("MadMaxFuriaCarretera4Kwww.newpct1.com.mkv") y la
    primera linea lo dice todo ("Mad Max Fury Road [4K UHD 2160p HEVC X265][AC3
    5.1 Castellano+Subs][ES-EN]"): se usa esa, sin el "[Bitsearch.to]" delante."""
    first = parsed['all_names'][0] if parsed['all_names'] else matched
    if first and ('[' in first or len(first) > len(matched or '')):
        return _SITE_TAG_RE.sub('', first)
    return _SITE_TAG_RE.sub('', matched or '')


def _peerflix_quality(name_field):
    for q, rx in _PF_QUALITY:
        if rx.search(name_field or ''): return q
    return None


def _episode_re(season, episode):
    return re.compile(r'(?<!\d)0?%dx0?%d(?!\d)|\bs0?%de0?%d(?!\d)|\bcap\.?\s*%d%02d(?!\d)'
                      % (season, episode, season, episode, season, episode), re.IGNORECASE)


def _tags(parsed, name_field, is_tv, season, episode):
    """v2.0.13: las etiquetas de un release con el titulo en castellano, sin el
    titulo. Cada linea se corta en el primer '[' o '(', en el año o en el
    episodio: lo de delante es el titulo ("Juego de Tronos", "Dune Parte Dos") y
    sus palabras confunden a los filtros ('de' es la abreviatura del aleman).
    Se añade la calidad que Peerflix pone en el nombre ("Peerflix 🇪🇸 1080p")."""
    ep = _episode_re(season, episode) if is_tv else None
    parts = []
    for line in [parsed['filename']] + parsed['all_names']:
        if not line: continue
        cuts = [m.start() for m in (re.search(r'[\[(]', line), _YEAR_RE.search(line), ep.search(line) if ep else None) if m]
        if cuts: parts.append(line[min(cuts):])
    parts.append(_FLAG_RE.sub('', name_field or '').replace('Peerflix', ''))
    flat = re.sub(r'[^a-z0-9]+', '.', ' '.join(parts).lower()).strip('.')
    return '.%s.' % flat


class source:
    timeout    = 10
    priority   = 2
    pack_capable = False
    hasMovies  = True
    hasEpisodes = True

    # v2.0.13: addon.peerflix.mov primero, que es la que usa AIOStreams.
    # v2.0.13: peerflix.mov es una copia estatica que solo sirve la ruta sin
    # configuracion (/stream/movie/tt...json); con ella delante da error.
    DEFAULT_CANDIDATES = (
        ('https://addon.peerflix.mov', True),
        ('https://peerflix.mov', False),
    )

    def __init__(self):
        # ── Settings ──────────────────────────────────────────────────────────
        # v2.0.13: 0 = solo los que llevan tambien audio ingles; 1 = todos. El 2
        # (el antiguo English + Español) hace lo mismo que el 1.
        try: lang_idx = int(getSetting('peerflix.language') or '0')
        except Exception: lang_idx = 0
        self.dual_only = lang_idx == 0

        qf_idx = getSetting('peerflix.qualityfilter') or '0'
        self._qualityfilter = _QF_MAP.get(qf_idx, '')
        self._quality_drop = _QF_DROP.get(qf_idx, ())

        try:
            self.min_seeders = int(getSetting('peerflix.min.seeders') or '0')
        except Exception:
            self.min_seeders = 0

        self._default_headers = {
            'Accept'    : 'application/json',
            'Referer'   : 'https://peerflix.mov',
            'User-Agent': 'jacksparrowscrapers/peerflix (+https://peerflix.mov)',
        }
        self._bases = [(b.rstrip('/'), cfg) for b, cfg in self.DEFAULT_CANDIDATES]
        # el test de proveedores mira este host (Host: OK)
        self.base_link = self._bases[0][0]

    def _headers(self):
        return dict(self._default_headers)

    def _build_path(self, is_tv, imdb, season=None, episode=None, with_cfg=True):
        """La ruta con language=es y qualityfilter= delante, o sin nada para la
        copia estatica."""
        if is_tv: tail = '/stream/series/%s:%s:%s.json' % (imdb, season, episode)
        else: tail = '/stream/movie/%s.json' % imdb
        if not with_cfg: return tail
        parts = ['language=es']
        if self._qualityfilter:
            parts.append('qualityfilter=%s' % self._qualityfilter)
        # Formato: /language=es|qualityfilter=.../stream/..., codificado (%3D, %7C)
        return '/%s%s' % (quote('|'.join(parts), safe=''), tail)

    def _fetch_streams(self, is_tv, imdb, season, episode):
        """GET sobre las bases por orden. Devuelve (payload, base_url).
        Una respuesta valida con 0 streams tambien cuenta: el titulo no esta."""
        from resources.lib.jacksparrow import log_utils
        last_exc = None
        for base, with_cfg in self._bases:
            url = base + self._build_path(is_tv, imdb, season, episode, with_cfg)
            try:
                res = client.request(url, headers=self._headers(), timeout=self.timeout)
                if not res:
                    log_utils.log('PEERFLIX: respuesta vacía/None de %s' % client.scrub_url(url), level=log_utils.LOGDEBUG)
                    continue
                try:
                    payload = jsloads(res)
                except Exception:
                    log_utils.log('PEERFLIX: respuesta no-JSON de %s -- %s'
                                  % (client.scrub_url(url), str(res)[:160]), level=log_utils.LOGWARNING)
                    continue
                if isinstance(payload, dict) and 'streams' in payload:
                    n = len(payload.get('streams') or [])
                    log_utils.log('PEERFLIX: %d streams de %s' % (n, client.scrub_url(url)), level=log_utils.LOGDEBUG)
                    return payload, base
                log_utils.log('PEERFLIX: JSON sin clave "streams" de %s (keys=%s)'
                              % (client.scrub_url(url), list(payload.keys()) if isinstance(payload, dict) else type(payload).__name__),
                              level=log_utils.LOGWARNING)
            except Exception as e:
                last_exc = e
                continue
        if last_exc:
            source_utils.scraper_error('PEERFLIX (sin payload): %s' % last_exc)
        else:
            log_utils.log('PEERFLIX: ninguna base devolvió payload para %s' % imdb, level=log_utils.LOGDEBUG)
        return None, None

    def sources(self, data, hostDict):
        sources = []
        if not data:
            return sources
        append = sources.append

        try:
            title = data['tvshowtitle'] if 'tvshowtitle' in data else data['title']
            title = title.replace('&', 'and').replace('Special Victims Unit', 'SVU').replace('/', ' ')
            aliases       = data.get('aliases', [])
            episode_title = data['title'] if 'tvshowtitle' in data else None
            total_seasons = data.get('total_seasons') if 'tvshowtitle' in data else None
            year  = data['year']
            imdb  = data['imdb']
            if not imdb:
                return sources

            if 'tvshowtitle' in data:
                season  = int(data['season'])
                episode = int(data['episode'])
                hdlr    = 'S%02dE%02d' % (season, episode)
                is_tv   = True
            else:
                season = episode = None
                hdlr   = year
                is_tv  = False

            # ── Una sola peticion: Peerflix solo contesta en español ───────────
            payload, base_used = self._fetch_streams(is_tv, imdb, season, episode)
            all_files = []
            seen_hashes = set()
            for f in (payload or {}).get('streams') or []:
                h = (f.get('infoHash') or f.get('infohash') or f.get('hash') or '').lower()
                if h:
                    if h in seen_hashes:
                        continue
                    seen_hashes.add(h)
                all_files.append(f)

            if not all_files:
                return sources

            undesirables        = source_utils.get_undesirables()
            # v2.0.13: con All en el ajuste de Peerflix el usuario PIDE audio en
            # castellano; el filtro general de audio extranjero (activo por defecto)
            # no puede quitarle justo eso. Con dual audio sigue mandando.
            check_foreign_audio = source_utils.check_foreign_audio() and self.dual_only
            origins = {}
        except Exception as e:
            source_utils.scraper_error('PEERFLIX: %s' % e)
            return sources

        for file in all_files:
            try:
                package, episode_start = None, 0

                # ── infoHash / magnet ──────────────────────────────────────────
                info_hash = file.get('infoHash') or file.get('infohash') or file.get('hash')
                magnet    = None
                if not info_hash:
                    raw_magnet = file.get('url') or file.get('magnet') or ''
                    if raw_magnet.startswith('magnet:?'):
                        m = re.search(r'btih:([a-fA-F0-9]{40}|[a-zA-Z0-9]{32})', raw_magnet)
                        if m:
                            info_hash = m.group(1)
                        magnet = raw_magnet
                else:
                    magnet = 'magnet:?xt=urn:btih:%s' % info_hash

                if not magnet:
                    continue

                # ── Parseo multi-línea ─────────────────────────────────────────
                parsed    = _parse_stream(file)

                # ── Audio ───────────────────────────────────────────────────────
                # Con dual audio solo pasan los MULTI/DUAL y los que dicen ingles
                # (ES-EN, Castellano-Ingles...); con All pasan todos.
                if self.dual_only and not parsed['is_multi'] and 'en' not in parsed['langs']:
                    continue

                filename  = parsed['filename']
                all_names = parsed['all_names']
                name      = source_utils.clean_name(filename) if filename else source_utils.clean_name(title)

                # check_title: probamos filename y después resto de líneas
                title_ok = source_utils.check_title(title, aliases, name, hdlr, year)
                if not title_ok:
                    for candidate in all_names:
                        alt = source_utils.clean_name(candidate)
                        if alt != name and source_utils.check_title(title, aliases, alt, hdlr, year):
                            name     = alt
                            title_ok = True
                            break

                alt_tags = None
                if not title_ok:
                    # v2.0.13: titulo en castellano; la busqueda ya es por IMDb
                    alt = _id_match(parsed, is_tv, year, season, episode)
                    if alt:
                        name, title_ok = source_utils.clean_name(_display(parsed, alt)), True
                        alt_tags = _tags(parsed, file.get('name'), is_tv, season, episode)

                if not title_ok:
                    if not is_tv:
                        continue
                    valid, last_season = source_utils.filter_show_pack(
                        title, aliases, imdb, year, season, name, total_seasons
                    )
                    if not valid:
                        valid, episode_start, episode_end = source_utils.filter_season_pack(
                            title, aliases, year, season, name
                        )
                        if not valid:
                            continue
                        package = 'season'
                    else:
                        package = 'show'

                if alt_tags:
                    # el idioma ya lo dicen las banderas y [ES-EN]: el filtro de audio
                    # extranjero mira eso y no las palabras del titulo en castellano
                    name_info = alt_tags
                    if source_utils.remove_lang(name_info, False):
                        continue
                    if check_foreign_audio and not parsed['is_multi'] and 'en' not in parsed['langs']:
                        continue
                else:
                    name_info = source_utils.info_from_name(name, title, year, hdlr, episode_title)
                    if source_utils.remove_lang(name_info, check_foreign_audio):
                        continue
                if undesirables and source_utils.remove_undesirables(name_info, undesirables):
                    continue

                # ── Seeders ────────────────────────────────────────────────────
                seeders = parsed['seeders'] or int(file.get('seed', 0) or 0)
                if self.min_seeders > seeders:
                    continue

                # ── Calidad e info ─────────────────────────────────────────────
                quality, info = source_utils.get_release_quality(name_info, magnet)
                # v2.0.13: el nombre no siempre dice la resolucion (el remux de "Mad.Max.
                # Fury.Road.2015.BluRay.REMUX..." salia SD); Peerflix si la pone en el suyo
                # ("Peerflix 🇪🇸 1080p"), y manda cuando la release no dice nada.
                if quality not in ('4K', '1080p', '720p'):
                    pq = _peerflix_quality(file.get('name'))
                    if pq: quality = pq
                if quality in self._quality_drop:
                    continue
                # Tags codec/HDR/DV/HDR10+/Atmos extraídos del nombre crudo
                # (info_from_name() suprime '+' y otros chars necesarios para
                # detectar HDR10+, AV1, etc.). Sin esto los filtros remove.hdr/
                # hevc/dolby.vision no afectan a fuentes de Peerflix y el
                # _smart_autoplay_sort no aplica el bonus correspondiente.
                info += [t for t in source_utils.get_extra_tags(name) if t not in info]

                # ── Tamaño ─────────────────────────────────────────────────────
                dsize = 0
                try:
                    if parsed['size_str']:
                        dsize, isize = source_utils._size(parsed['size_str'])
                        if isize:
                            info.insert(0, isize)
                except Exception:
                    pass

                info_str = ' | '.join(info)
                item = {
                    'source'    : 'torrent',
                    'language'  : parsed['lang'],
                    'lang_hint' : parsed.get('lang_hint', ''),
                    'direct'    : False,
                    'debridonly': True,
                    'provider'  : 'peerflix',
                    'url'       : magnet,
                    'hash'      : info_hash or '',
                    'name'      : name,
                    'name_info' : name_info,
                    'quality'   : quality,
                    'info'      : info_str,
                    'size'      : dsize,
                    'seeders'   : seeders,
                }

                if package:
                    item['package'] = package
                if package == 'show':
                    item.update({'last_season': last_season})
                if episode_start:
                    item.update({'episode_start': episode_start, 'episode_end': episode_end})

                append(item)
                origins[parsed['origin']] = origins.get(parsed['origin'], 0) + 1
            except Exception as e:
                source_utils.scraper_error('PEERFLIX (item): %s' % e)

        if origins:
            from resources.lib.jacksparrow import log_utils
            log_utils.log('PEERFLIX: %d de %d kept (%s); origen: %s' % (
                len(sources), len(all_files), 'dual audio only' if self.dual_only else 'all',
                ', '.join('%s %d' % kv for kv in sorted(origins.items(), key=lambda kv: -kv[1]))), level=log_utils.LOGDEBUG)
        return sources
