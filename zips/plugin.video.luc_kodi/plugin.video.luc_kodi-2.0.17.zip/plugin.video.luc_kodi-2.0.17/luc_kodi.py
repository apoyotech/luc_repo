# -*- coding: utf-8 -*-
"""
	luc_kodi Add-on
"""

from sys import argv
from urllib.parse import parse_qsl
from resources.lib.modules import router

if __name__ == '__main__':
	try:
		url = dict(parse_qsl(argv[2].replace('?', '')))
	except:
		from resources.lib.modules import log_utils
		log_utils.error()
		url = {}

	try:
		from resources.lib.modules import kodi_objects
		kodi_objects.run_started()
	except Exception:
		pass
	try:
		router.router(url)
	finally:
		# v2.0.14: drop the Kodi objects made in this run (modules/kodi_objects.py),
		# so Kodi does not report "classes left in memory" when it stops the script;
		# what threads of the run still use is dropped when they end
		try:
			from resources.lib.modules import kodi_objects
			kodi_objects.release()
		except Exception:
			pass
