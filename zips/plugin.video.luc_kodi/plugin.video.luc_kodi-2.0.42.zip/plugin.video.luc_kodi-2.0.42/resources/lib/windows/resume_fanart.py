# -*- coding: utf-8 -*-
"""
	luc_kodi Add-on — windows/resume_fanart.py

	v2.0.37 (Lucian, 19-nov-2026): al reanudar, luc_kodi arranca la pelicula y la
	manda al punto guardado (player.onAVStarted -> seekTime). Mientras Kodi busca
	ese punto la pantalla se queda en negro o congelada: 4-17 s en los kodi.log
	del 19-nov-2026 con discos de Usenet. Si tarda, se tapa SOLO con el fanart
	del contenido, sin barra ni texto (decision de Lucian: el fanart ya dice de
	que se trata), y se quita en cuanto la pelicula avanza desde ese punto.

	No es modal: el reproductor sigue atendiendo al mando. Cualquier tecla lo
	quita. Nunca se queda encima del video mas de MAX_SECS.
"""

import threading
import time

import xbmc
from resources.lib.windows.base import BaseDialog

SHOW_AFTER = 1.0          # si la pelicula ya esta en su sitio antes, no se muestra
MAX_SECS = 60             # tope: nunca se queda encima del video mas que esto
NEAR_SECS = 5             # "ya esta en el punto" (Kodi cae en el fotograma clave anterior)


class ResumeFanartXML(BaseDialog):
	def __init__(self, *args, **kwargs):
		BaseDialog.__init__(self, args)
		self.fanart = kwargs.get('fanart') or ''
		self.closed = False

	def onInit(self):
		try: self.setProperty('fanart', self.fanart)
		except Exception: pass

	def onAction(self, action):
		self.doClose()           # cualquier tecla: el usuario quiere ver el video

	def doClose(self):
		if self.closed: return
		self.closed = True
		try: self.close()
		except Exception: pass


def _arrived(player, target):
	"""En el punto y avanzando (no solo pedido: mientras busca, el tiempo no corre)."""
	try:
		t1 = player.getTime()
		if t1 < target - NEAR_SECS: return False
		xbmc.sleep(300)
		return player.getTime() > t1
	except Exception:
		return True


def cover(player, target, fanart, playing_file=None):
	"""Lanza en un hilo aparte: si a SHOW_AFTER la pelicula no ha llegado a
	target, pone el fanart encima hasta que llega, se para, se pausa o MAX_SECS."""
	if not fanart or not target or target <= NEAR_SECS:
		return
	threading.Thread(target=_run, args=(player, float(target), fanart, playing_file), daemon=True).start()


def _run(player, target, fanart, playing_file):
	from resources.lib.modules import control
	monitor = xbmc.Monitor()
	if monitor.waitForAbort(SHOW_AFTER): return
	if _gone(player, playing_file) or _arrived(player, target): return
	window = None
	try:
		window = ResumeFanartXML('resume_fanart.xml', control.addonPath(control.addonId()), fanart=fanart)
		window.show()
		t0 = time.time()
		while not window.closed and time.time() - t0 < MAX_SECS:
			if monitor.waitForAbort(0.25): break
			if _gone(player, playing_file) or xbmc.getCondVisibility('Player.Paused'): break
			if _arrived(player, target): break
		control.log('[ luc_kodi ] resume: fanart shown %.1fs while Kodi found %d:%02d:%02d' % (
			time.time() - t0, int(target) // 3600, int(target) % 3600 // 60, int(target) % 60), 1)
	except Exception:
		from resources.lib.modules import log_utils
		log_utils.error()
	finally:
		if window is not None:
			window.doClose()
			del window


def _gone(player, playing_file):
	try:
		if not player.isPlayingVideo(): return True
		return bool(playing_file) and player.getPlayingFile() != playing_file
	except Exception:
		return True
