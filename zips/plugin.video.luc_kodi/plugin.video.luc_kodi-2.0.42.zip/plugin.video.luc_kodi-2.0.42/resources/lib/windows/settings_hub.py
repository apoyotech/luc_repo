# -*- coding: utf-8 -*-
"""
	luc_kodi Add-on
	settings_hub.py (v2.0.38) - luc_kodi's own Settings window.

	The same settings as Kodi's dialog (resources/settings.xml, read through
	modules/settings_def.py), drawn by the plugin so it looks the same in every
	skin: sections on the left, the section's settings on the right, grouped
	under their headings. Values are read and written with xbmcaddon, so the
	window and Kodi's dialog always agree.

	Rules taken from Kodi (xbmc/settings/lib/Setting.cpp):
	  - a setting is shown when all its visible conditions hold;
	  - it can be changed when all its enable conditions hold AND its parent
	    can be changed; it is drawn indented under its parent;
	  - a heading is shown only when something under it is shown.
	After every change the conditions are checked again, so settings appear,
	disappear or unlock at once, as in Kodi's dialog.

	Keys: OK changes the focused setting (on/off flips, a list opens a picker,
	text opens the keyboard, an action runs). Left goes to the sections, Right
	back to the settings, Back closes.

	IDs
	9700 Group   the panel          9702 List  sections (rail)
	9701 List    settings of the section       9703 Scrollbar of 9701
	9705 Label   section name       9706 Label section line
	Window properties: sh.title  sh.version  sh.cat  sh.line
	ListItem properties of 9701: kind (header|row), vkind (toggle|value|go),
	  on (true|false), dis (1 when it cannot be changed), indent (1 under a parent)
"""

import xbmcaddon
from resources.lib.modules import control, settings_def
from resources.lib.windows.base import BaseDialog

LIST_ID, RAIL_ID = 9701, 9702
ACTION_UP, ACTION_DOWN, ACTION_LEFT, ACTION_RIGHT = 3, 4, 1, 2
ACTION_PAGE_UP, ACTION_PAGE_DOWN = 5, 6

# strings.po
S_TITLE, S_SEARCH, S_COUNT = 402400, 402401, 402403
S_SET, S_NOT_SET = 402404, 402405
S_ON, S_OFF = 48143, 48144

# rail entry that is not a section
RAIL_SEARCH = 'search'

SECTION_ICONS = (
	('general', 'gear'), ('navigation', 'list'), ('tv shows', 'film'), ('playback', 'play'),
	('providers', 'search'), ('usenet', 'queue'), ('source', 'shuffle'), ('tracking', 'eye'),
	('accounts (meta)', 'info'), ('accounts', 'link'), ('library', 'folder'), ('downloads', 'download'),
	('debug', 'bolt'), ('shortcut', 'star'), ('subtitle', 'pencil'), ('update', 'redo'),
	('maintenance', 'trash'), ('assistant', 'spark'),
)


def lang(sid):
	try: return control.lang(int(sid)) if sid else ''
	except Exception: return ''


def plain(text):
	try:
		from resources.lib.modules.context_hub import clean_label
		text = clean_label(text)
	except Exception: pass
	return ' '.join(str(text or '').split())


def heading_style(raw, title):
	"""How a group heading is drawn. The settings already tell them apart:
	a service or block (Trakt, SIMKL, Premiumize.me...) is written in the
	plugin's green, an explanation in grey or as a long sentence, and the rest
	are parts inside a block."""
	low = raw.lower()
	if 'ff808080' in low or len(title) > 60: return 'note'
	if '[color' in low: return 'service'
	return 'section'


def section_icon(name):
	low = name.lower()
	for word, icon in SECTION_ICONS:
		if word in low: return 'ctx/ic_%s.png' % icon
	return 'ctx/ic_dot.png'


class SettingsHubXML(BaseDialog):
	def __init__(self, *args, **kwargs):
		BaseDialog.__init__(self, args)
		self.cats = settings_def.categories()
		self.defs = settings_def.settings()
		self.cat = max(0, min(int(kwargs.get('cat') or 0), len(self.cats) - 1)) if self.cats else 0
		self.focus_id = kwargs.get('focus') or ''
		self.rows = []           # what each row of 9701 is: ('header', None) or ('row', setting id)
		self.values = {}
		self.after = None        # builtin to run once the window is closed
		self.rail = []           # what each row of 9702 is: section index or RAIL_*
		try: self.setProperty('sh.version', 'v%s' % xbmcaddon.Addon().getAddonInfo('version'))
		except Exception: pass
		self.setProperty('sh.title', lang(S_TITLE))

	# ---------------------------------------------------------------- values
	def _read(self):
		addon = xbmcaddon.Addon()
		vals = {}
		for sid, s in self.defs.items():
			if s['store'] == 'none': continue
			try: vals[sid] = addon.getSetting(sid)
			except Exception: vals[sid] = s['default']
		self.values = vals

	def _enabled(self, sid, depth=0):
		s = self.defs.get(sid)
		if not s or depth > 8: return True
		if s['parent'] and not self._enabled(s['parent'], depth + 1): return False
		return settings_def.holds(s['enable'], self.values)

	def _visible(self, sid):
		return settings_def.holds(self.defs[sid]['visible'], self.values)

	def _value_text(self, s):
		v = self.values.get(s['id'], s['default'])
		k = s['kind']
		if k == 'bool': return lang(S_ON) if v == 'true' else lang(S_OFF)
		if s['options']:
			for lab, val in s['options']:
				if val == v: return plain(lang(lab)) if lab else val
			return v
		if k == 'action': return v if s['store'] == 'str' and v and v not in ('true', 'false') else ''
		if k == 'text' and s['hidden']: return lang(S_SET) if v else lang(S_NOT_SET)
		if k == 'slider':
			try:
				f = float(v)
				return ('%d' % f) if s['store'] == 'int' or f == int(f) else ('%.1f' % f)
			except Exception: return v
		return v

	# ---------------------------------------------------------------- lists
	def _fill_rail(self):
		items = []
		self.rail = []
		li = self.make_listitem()
		li.setLabel(lang(S_SEARCH)); li.setProperty('icon', 'ctx/ic_search.png'); li.setProperty('extra', '1')
		items.append(li); self.rail.append(RAIL_SEARCH)
		for c in self.cats:
			name = plain(lang(c['label']))
			li = self.make_listitem()
			li.setLabel(name)
			li.setProperty('icon', section_icon(name))
			li.setProperty('cur', 'true' if c['index'] == self.cat else 'false')
			items.append(li); self.rail.append(c['index'])
		rail = self.getControl(RAIL_ID)
		rail.reset()
		rail.addItems(items)
		rail.selectItem(self.rail.index(self.cat))

	def _mark_rail(self):
		try:
			rail = self.getControl(RAIL_ID)
			for i, what in enumerate(self.rail):
				it = rail.getListItem(i)
				if it is not None and isinstance(what, int): it.setProperty('cur', 'true' if what == self.cat else 'false')
		except Exception: pass

	def _build(self, keep=None):
		"""(Re)draws the settings of the current section; keeps the focus on `keep`."""
		self._read()
		cat = self.cats[self.cat] if self.cats else {'groups': [], 'label': 0}
		items, rows, shown = [], [], 0
		for g in cat['groups']:
			vis = [sid for sid in g['ids'] if self._visible(sid) and self.defs[sid]['label']]
			if not vis: continue
			raw = lang(g['label']) if g['label'] else ''
			title = plain(raw)
			if title:
				li = self.make_listitem()
				li.setLabel(title); li.setProperty('kind', 'header')
				li.setProperty('hstyle', heading_style(raw, title))
				items.append(li); rows.append(('header', None))
			elif rows:
				li = self.make_listitem()
				li.setLabel(''); li.setProperty('kind', 'header')  # a gap between groups without a name
				items.append(li); rows.append(('header', None))
			for sid in vis:
				s = self.defs[sid]
				li = self.make_listitem()
				li.setLabel(plain(lang(s['label'])))
				li.setLabel2(self._value_text(s))
				li.setProperty('kind', 'row')
				k = s['kind']
				li.setProperty('vkind', 'toggle' if k == 'bool' else ('go' if k == 'action' and not li.getLabel2() else 'value'))
				li.setProperty('on', 'true' if self.values.get(sid) == 'true' else 'false')
				li.setProperty('dis', '' if self._enabled(sid) else '1')
				li.setProperty('indent', '1' if s['parent'] else '')
				items.append(li); rows.append(('row', sid))
				shown += 1
		self.rows = rows
		self.setProperty('sh.cat', plain(lang(cat['label'])))
		self.setProperty('sh.line', lang(S_COUNT) % shown if '%' in lang(S_COUNT) else '')
		lst = self.getControl(LIST_ID)
		lst.reset()
		lst.addItems(items)
		pos = self._first_row()
		if keep:
			for i, (kind, sid) in enumerate(rows):
				if sid == keep: pos = i; break
		if pos >= 0: lst.selectItem(pos)
		return pos

	def _refresh_values(self):
		"""Values changed but the same rows are shown: only the texts change."""
		self._read()
		lst = self.getControl(LIST_ID)
		for i, (kind, sid) in enumerate(self.rows):
			if kind != 'row': continue
			it = lst.getListItem(i)
			if it is None: continue
			s = self.defs[sid]
			it.setLabel2(self._value_text(s))
			it.setProperty('on', 'true' if self.values.get(sid) == 'true' else 'false')
			it.setProperty('dis', '' if self._enabled(sid) else '1')

	def _shown_ids(self):
		return [sid for kind, sid in self.rows if kind == 'row']

	def _after_change(self, sid):
		before = self._shown_ids()
		self._read()
		cat = self.cats[self.cat]
		now = [i for g in cat['groups'] for i in g['ids'] if self._visible(i) and self.defs[i]['label']]
		if now != before: self._build(keep=sid)
		else: self._refresh_values()

	def _first_row(self):
		for i, (kind, sid) in enumerate(self.rows):
			if kind == 'row': return i
		return -1

	# ---------------------------------------------------------------- editing
	def _pick(self, s, labels, current):
		try:
			from resources.lib.windows.menu_select import MenuSelectXML
			entries = [{'label': lab, 'icon': 'ctx/ic_check.png' if i == current else 'ctx/ic_dot.png',
						'color': 'FFFDB515' if i == current else 'FFB0B0D0',
						'tile': '2EFDB515' if i == current else '2EB0B0D0'} for i, lab in enumerate(labels)]
			header = {'menu': self.getProperty('sh.cat'), 'title': plain(lang(s['label'])), 'meta': '',
					  'artkind': 'icon', 'poster': control.addonIcon(), 'version': self.getProperty('sh.version')}
			w = MenuSelectXML('menu_select.xml', control.addonPath(control.addonId()), entries=entries, header=header,
							  preselect=max(current, 0))
			chosen = w.run()
			del w
			return chosen
		except Exception:
			from resources.lib.modules import log_utils
			log_utils.error()
			return control.dialog.select(plain(lang(s['label'])), labels, preselect=max(current, 0))

	def _edit(self, sid):
		s = self.defs[sid]
		if not self._enabled(sid): return
		k, cur = s['kind'], self.values.get(sid, s['default'])
		title = plain(lang(s['label']))
		new = None
		if k == 'bool':
			new = 'false' if cur == 'true' else 'true'
		elif s['options']:
			labels = [plain(lang(lab)) if lab else val for lab, val in s['options']]
			vals = [val for _, val in s['options']]
			idx = vals.index(cur) if cur in vals else -1
			sel = self._pick(s, labels, idx)
			if sel is None or sel < 0 or sel == idx: return
			new = vals[sel]
		elif k == 'slider':
			new = self._slider(s, cur, title)
		elif k == 'number':
			got = control.dialog.numeric(0, title, cur or '0')
			if got != '' and got is not None: new = str(int(got))
		elif k == 'text':
			import xbmcgui
			if s['hidden']: got = control.dialog.input(title, defaultt='', option=xbmcgui.ALPHANUM_HIDE_INPUT)
			else: got = control.dialog.input(title, defaultt=cur)
			if got is None: return
			if got == '' and cur and not control.dialog.yesno(title, control.lang(402406)): return
			new = got
		elif k == 'folder':
			got = control.dialog.browse(3, title, 'files', defaultt=cur or '')
			if got: new = got
		elif k == 'action':
			builtin = (s['action'] or '').strip()
			if not builtin: return
			if s['close']:
				self.after = builtin
				self.close()
				return
			control.execute(builtin)
			control.sleep(400)
			self._after_change(sid)
			return
		if new is None or new == cur: return
		control.setSetting(sid, new)
		self._after_change(sid)

	def _slider(self, s, cur, title):
		try:
			mn, st, mx = float(s.get('min') or 0), float(s.get('step') or 1), float(s.get('max') or 0)
		except Exception:
			return None
		is_int = s['store'] == 'int'
		steps = int(round((mx - mn) / st)) + 1 if st > 0 else 0
		if 1 < steps <= 61:  # a short range: pick it from a list
			vals = [mn + i * st for i in range(steps)]
			labels = [('%d' % v) if is_int or v == int(v) else ('%.1f' % v) for v in vals]
			try: idx = min(range(steps), key=lambda i: abs(vals[i] - float(cur)))
			except Exception: idx = 0
			sel = self._pick(s, labels, idx)
			if sel is None or sel < 0: return None
			v = vals[sel]
		else:
			head = '%s  (%s - %s)' % (title, ('%d' % mn) if is_int else mn, ('%d' % mx) if is_int else mx)
			try: now = float(cur or mn)
			except Exception: now = mn
			if is_int: got = control.dialog.numeric(0, head, '%d' % now)
			else: got = control.dialog.input(head, defaultt=('%.6f' % now).rstrip('0').rstrip('.'))  # Kodi's number pad has no decimal point
			try: v = float(str(got).replace(',', '.'))
			except Exception: return None
			v = max(mn, min(mx, v))
			if st > 0: v = mn + round((v - mn) / st) * st  # onto the slider's steps, as Kodi does
			v = max(mn, min(mx, v))
		return ('%d' % v) if is_int else ('%.6f' % v).rstrip('0').rstrip('.')

	# ---------------------------------------------------------------- kodi
	def onInit(self):
		try:
			self._fill_rail()
			pos = self._build(keep=self.focus_id)
			self.setFocusId(LIST_ID if pos >= 0 else RAIL_ID)
		except Exception:
			from resources.lib.modules import log_utils
			log_utils.error()

	def run(self):
		control.homeWindow.setProperty('luc_kodi.settings.open', 'true')
		try: self.doModal()
		finally:
			control.homeWindow.clearProperty('luc_kodi.settings.open')
			self.clearProperties()
		return self.after

	def _open_rail(self, pos):
		what = self.rail[pos] if 0 <= pos < len(self.rail) else None
		if what == RAIL_SEARCH:
			self.after = 'RunPlugin(plugin://plugin.video.luc_kodi/?action=ctx_Search)'
			self.close()
		elif isinstance(what, int) and what != self.cat:
			self.cat = what
			self._mark_rail()
			self._build()

	def onClick(self, controlID):
		try:
			if controlID == LIST_ID:
				pos = self.get_position(LIST_ID)
				if 0 <= pos < len(self.rows) and self.rows[pos][0] == 'row':
					self._edit(self.rows[pos][1])
			elif controlID == RAIL_ID:
				self._open_rail(self.get_position(RAIL_ID))
				if isinstance(self.rail[self.get_position(RAIL_ID)], int) and self._first_row() >= 0:
					self.setFocusId(LIST_ID)
		except Exception:
			from resources.lib.modules import log_utils
			log_utils.error()

	def onAction(self, action):
		try:
			aid = action.getId()
			if aid in self.closing_actions:
				self.close()
				return
			focus = self.getFocusId()
			if focus == RAIL_ID and aid in (ACTION_UP, ACTION_DOWN, ACTION_PAGE_UP, ACTION_PAGE_DOWN):
				# moving through the sections shows each one at once
				pos = self.get_position(RAIL_ID)
				if isinstance(self.rail[pos], int): self._open_rail(pos)
			elif focus == LIST_ID and aid in (ACTION_UP, ACTION_DOWN, ACTION_PAGE_UP, ACTION_PAGE_DOWN):
				# headings are not settings: the focus jumps over them
				lst = self.getControl(LIST_ID)
				pos = lst.getSelectedPosition()
				if 0 <= pos < len(self.rows) and self.rows[pos][0] == 'header':
					step = -1 if aid in (ACTION_UP, ACTION_PAGE_UP) else 1
					nxt = pos
					while 0 <= nxt < len(self.rows) and self.rows[nxt][0] == 'header': nxt += step
					if not 0 <= nxt < len(self.rows):
						nxt = pos
						while 0 <= nxt < len(self.rows) and self.rows[nxt][0] == 'header': nxt -= step
					if 0 <= nxt < len(self.rows): lst.selectItem(nxt)
		except Exception:
			from resources.lib.modules import log_utils
			log_utils.error()
