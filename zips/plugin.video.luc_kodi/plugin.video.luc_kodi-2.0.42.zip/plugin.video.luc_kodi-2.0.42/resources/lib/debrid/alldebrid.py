# -*- coding: utf-8 -*-
"""
	luc_kodi Add-on
"""

from json import dumps as jsdumps, loads as jsloads
import re
import requests
from requests.adapters import HTTPAdapter
from sys import argv, exit as sysexit
from urllib3.util.retry import Retry
from urllib.parse import quote_plus
from resources.lib.database import cache
from resources.lib.modules import control
from resources.lib.modules.context_hub import attach_cm # v2.0.09: modern panel or classic Kodi menu
from resources.lib.modules import log_utils
from resources.lib.modules import string_tools
from resources.lib.modules.source_utils import supported_video_extensions

getLS = control.lang
getSetting = control.setting
base_url = 'https://api.alldebrid.com/v4/'
base_url_2 = 'https://api.alldebrid.com/v4.1/'
user_agent = 'luc_kodi_for_Kodi'
ad_icon = control.joinPath(control.artPath(), 'alldebrid.png')
#ad_qr = control.joinPath(control.artPath(), 'alldebridqr.png')
addonFanart = control.addonFanart()
invalid_extensions = ('.bmp', '.exe', '.gif', '.jpg', '.nfo', '.part', '.png', '.rar', '.sample.', '.srt', '.txt', '.zip', '.clpi', '.mpls', '.bdmv', '.xml', '.crt', 'crl', 'sig')
from resources.lib.modules.source_utils import is_archive_part  # v1.0.54

session = requests.Session()
retries = Retry(total=5, backoff_factor=0.1, status_forcelist=[500, 502, 503, 504])
session.mount('https://api.alldebrid.com', HTTPAdapter(max_retries=retries, pool_maxsize=100))


class AllDebrid:
	name = "AllDebrid"
	sort_priority = getSetting('alldebrid.priority')
	def __init__(self):
		# Settings ids in this add-on use dotted keys (see resources/settings.xml).
		# Older builds mistakenly used legacy ids (alldebridtoken/alldebridusername),
		# which caused auth to "succeed" but not persist.
		self.token = getSetting('alldebrid.token')
		# Migrate legacy token if present
		if not self.token:
			legacy = getSetting('alldebridtoken')
			if legacy:
				self.token = legacy
				control.setSetting('alldebrid.token', legacy)
		self.timeout = 20
		self.server_notifications = getSetting('alldebrid.server.notifications') == 'true' # v2.0.01: the bare string 'false' was truthy
		self.store_to_cloud = getSetting('alldebrid.saveToCloud') == 'true'
		self.highlight_color = control.setting('highlight.color')

	def _get(self, url, url_append=''):
		response = None
		try:
			if self.token == '':
				log_utils.log('No All-Debrid Token Found')
				return None
			if 'magnet/status' in url:
				url = base_url_2 + url + '?agent=%s&apikey=%s' % (user_agent, self.token) + url_append
			else:
				url = base_url + url + '?agent=%s&apikey=%s' % (user_agent, self.token) + url_append
			response = session.get(url, timeout=self.timeout)
			if 'Response [500]' in str(response):
				log_utils.log('AllDebrid: Status code 500 – Internal Server Error', __name__, log_utils.LOGWARNING)
				return None
			if not response:
				log_utils.log('AllDebrid: No Response from server', __name__, log_utils.LOGWARNING)
				return None
			response = response.json()
			if 'status' in response:
				if response.get('status') == 'success':
					if 'data' in response: response = response['data']
				elif response.get('status') == 'error':
					if self.server_notifications: control.notification(message=response.get('error').get('message'), icon=ad_icon)
					log_utils.log('AllDebrid: %s' % response.get('error').get('message'), __name__, log_utils.LOGWARNING)
					return None
		except requests.exceptions.ConnectionError:
			if self.server_notifications: control.notification(message='Failed to connect to AllDebrid', icon=ad_icon)
			log_utils.log('Failed to connect to AllDebrid', __name__, log_utils.LOGWARNING)
			return None
		except BaseException:
			log_utils.error()
			return None
		return response

	def _post(self, url, data=None):
		response = None
		try:
			if self.token == '': return None
			url = base_url + url + '?agent=%s&apikey=%s' % (user_agent, self.token)
			response = session.post(url, data=data or {}, timeout=self.timeout)
			if 'Response [500]' in str(response):
				log_utils.log('AllDebrid: Status code 500 – Internal Server Error', __name__, log_utils.LOGWARNING)
				return None
			if response is None:
				log_utils.log('AllDebrid: No Response from server', __name__, log_utils.LOGWARNING)
				return None
			response = response.json()
			if 'status' in response:
				if response.get('status') == 'success':
					if 'data' in response: response = response['data']
				elif response.get('status') == 'error':
					if self.server_notifications:control.notification(message=response.get('error').get('message'), icon=ad_icon)
					log_utils.log('AllDebrid: %s' % response.get('error').get('message'), __name__, log_utils.LOGWARNING)
					return None
		except requests.exceptions.ConnectionError:
			if self.server_notifications: control.notification(message='Failed to connect to AllDebrid', icon=ad_icon)
			log_utils.log('Failed to connect to AllDebrid', __name__, log_utils.LOGWARNING)
		except BaseException:
			log_utils.error()
		return response

	# v2.0.28: asociacion rehecha. Lo de antes, en una llamada sin red o con el PIN
	# caducado, reventaba sin decir nada (un 'error' in None, un .json() de una
	# respuesta vacia, un account_info None) y la ventana se quedaba o se iba sin
	# guardar nada; sin linea en el log que dijera por que. Ahora cada paso se
	# apunta en el log (sin el apikey) y cada fallo se dice en pantalla.
	PIN_POLL_SECS = 5

	@staticmethod
	def _api(method, url, **kwargs):
		"""(json, '') o (None, motivo). Nunca lanza."""
		try:
			r = session.request(method, url, timeout=20, headers={'User-Agent': 'luc_kodi for Kodi'}, **kwargs)
		except requests.exceptions.SSLError as e:
			return None, 'secure connection failed (%s)' % e.__class__.__name__
		except requests.exceptions.RequestException as e:
			return None, 'no connection (%s)' % e.__class__.__name__
		except Exception as e:
			log_utils.error('AllDebrid: request: ')
			return None, 'request failed (%s)' % e.__class__.__name__
		try:
			data = r.json()
		except Exception:
			return None, 'HTTP %s without a valid answer' % r.status_code
		if not isinstance(data, dict):
			return None, 'unexpected answer'
		if data.get('status') == 'error':
			err = data.get('error') or {}
			return None, '%s %s' % (err.get('code') or '', err.get('message') or 'error')
		return data.get('data') if isinstance(data.get('data'), dict) else data, ''

	def auth_loop(self):
		"""Una consulta a pin/check. True = asociado, False = sigue esperando,
		None = el PIN ya no vale (caducado o rechazado)."""
		data, why = self._api('POST', base_url + 'pin/check?agent=%s' % user_agent, data={'check': self.check, 'pin': self.pin})
		if data is None:
			# un corte de red o una respuesta rara no tiran la asociacion: se
			# reintenta. Solo un error de AllDebrid (PIN caducado...) la termina
			if why.startswith(('no connection', 'secure connection', 'HTTP ', 'request failed', 'unexpected')):
				log_utils.always('AllDebrid: PIN check failed, retrying: %s' % why, 'luc_kodi-auth', log_utils.LOGWARNING)
				return False
			log_utils.always('AllDebrid: PIN no longer valid: %s' % why, 'luc_kodi-auth', log_utils.LOGWARNING)
			self.auth_error = why
			return None
		err = data.get('error')
		if err:
			# AllDebrid tambien puede mandar el error dentro de data (PIN_EXPIRED...):
			# eso termina la asociacion, no se reintenta hasta que caduque
			why = str((err.get('code') or err.get('message')) if isinstance(err, dict) else err)
			log_utils.always('AllDebrid: PIN no longer valid: %s' % why, 'luc_kodi-auth', log_utils.LOGWARNING)
			self.auth_error = why
			return None
		if not data.get('activated'): return False
		apikey = str(data.get('apikey') or '')
		if not apikey:
			self.auth_error = 'activated without an API key'
			return None
		self.token = apikey
		return True

	def auth(self, fromSettings=0):
		self.token, self.auth_error = '', ''
		log_utils.always('AllDebrid: sign-in started (Kodi %s)' % control.getKodiVersion(), 'luc_kodi-auth', log_utils.LOGINFO)
		response, why = self._api('GET', base_url_2 + 'pin/get?agent=%s' % user_agent)
		pin = (response or {}).get('pin')
		check = (response or {}).get('check')
		if not pin or not check:
			# v2.0.28: con el motivo, en pantalla y en el log
			why = why or 'no PIN in the answer'
			control.notification(message='AllDebrid: could not get a PIN - %s' % why, icon=ad_icon)
			log_utils.always('AllDebrid: could not get a PIN: %s' % why, 'luc_kodi-auth', log_utils.LOGWARNING)
			if fromSettings == 1:
				control.openSettings('8.0', 'plugin.video.luc_kodi')
			return
		pin_url = 'https://alldebrid.com/pin'
		# v2.0.15: ventana de asociacion comun con el QR hecho en el aparato. El QR
		# abre el enlace con el PIN ya puesto (user_url de la API, o el mismo armado).
		qr_link = response.get('user_url') or ('https://alldebrid.com/pin?pin=%s' % pin)
		try: expires_in = int(response.get('expires_in') or 600)
		except Exception: expires_in = 600
		self.check = check
		self.pin = pin
		from resources.lib.modules import device_auth
		self.progressDialog = device_auth.start('alldebrid', pin_url, pin, qr_data=qr_link,
												 expires_in=expires_in, qr_has_code=True)
		import time
		deadline = time.time() + expires_in
		next_check = time.time() + 2
		state = False
		try:
			while True:
				if self.progressDialog.iscanceled():
					# v2.0.34: aprobado en el movil y Atras antes del siguiente sondeo
					try: state = self.auth_loop()
					except Exception: state = False
					log_utils.always('AllDebrid: window closed; last check: %s' % ('signed in' if state is True else 'not approved yet, cancelled'), 'luc_kodi-auth', log_utils.LOGINFO)
					break
				if time.time() >= deadline:
					self.auth_error = 'the PIN expired'
					break
				if time.time() >= next_check:
					state = self.auth_loop()
					if state is not False: break
					next_check = time.time() + self.PIN_POLL_SECS
				control.sleep(500) # la cancelacion se nota al momento, no cada 5 s
		except Exception:
			log_utils.error('AllDebrid: sign-in loop: ')
			self.auth_error = self.auth_error or 'unexpected error'
		finally:
			# v2.0.15: cerrar siempre (con el PIN rechazado o caducado se quedaba abierta)
			try: self.progressDialog.close()
			except Exception: pass
		if state is not True:
			if self.auth_error:
				control.notification(message='AllDebrid: %s' % self.auth_error, icon=ad_icon)
				log_utils.always('AllDebrid: sign-in failed: %s' % self.auth_error, 'luc_kodi-auth', log_utils.LOGWARNING)
			self.token = ''
			if fromSettings == 1:
				control.openSettings('8.0', 'plugin.video.luc_kodi')
			return
		control.setSetting('alldebrid.token', self.token)
		# v2.0.28: comprobar que Kodi lo ha guardado de verdad (Kodi descarta en
		# silencio la escritura a un ajuste que no conoce)
		saved = control.saved_state('alldebrid.token', self.token)
		control.remember_settings({'alldebrid.token': self.token})
		log_utils.always('AllDebrid: API key received, saved in settings: %s' % saved, 'luc_kodi-auth', log_utils.LOGWARNING if saved == 'NO' else log_utils.LOGINFO)
		account_info = self._get('user') or {}
		username = str((account_info.get('user') or {}).get('username') or '')
		control.setSetting('alldebrid.username', username)
		control.remember_settings({'alldebrid.username': username})
		if not username:
			log_utils.always('AllDebrid: signed in, but the account details did not come back', 'luc_kodi-auth', log_utils.LOGWARNING)
		try:
			from resources.lib.modules.debrid_state import sync_state
			sync_state()
		except Exception: pass
		if fromSettings == 1:
			control.openSettings('8.0', 'plugin.video.luc_kodi')
		control.notification(message=40010, icon=ad_icon)
		log_utils.log(40010, __name__, log_utils.LOGWARNING)

	def revoke_auth(self, fromSettings=0):
		try:
			# Clear the stored credentials
			control.setSetting('alldebrid.token', '')
			control.setSetting('alldebrid.username', '')
			try:
				from resources.lib.modules.debrid_state import sync_state
				sync_state()
			except Exception:
				pass
			if fromSettings == 1:
				control.openSettings('8.0', 'plugin.video.luc_kodi')
			control.okDialog(title=40059, message=40009)
		except Exception: log_utils.error()

	def account_info(self):
		response = self._get('user')
		return response

	def account_info_to_dialog(self):
		from datetime import datetime
		try:
			account_info = self.account_info()['user']
			username = account_info['username']
			email = account_info['email']
			status = 'Premium' if account_info['isPremium'] else 'Not Active'
			expires = datetime.fromtimestamp(account_info['premiumUntil'])
			days_remaining = (expires - datetime.today()).days
			items = []
			items += [getLS(40036) % username]
			items += [getLS(40035) % email]
			items += [getLS(40037) % status]
			items += [getLS(40041) % expires]
			items += [getLS(40042) % days_remaining]
			return control.selectDialog(items, 'AllDebrid')
		except Exception: log_utils.error()

	def check_cache(self, hashes):
		try:
			data = {'magnets[]': hashes}
			response = self._post('magnet/instant', data)
			try: return response
			except Exception: return None
		except Exception: log_utils.error()

	def check_single_magnet(self, hash_string):
		try:
			cache_info = self.check_cache(hash_string)['magnets'][0]
			try: return cache_info['instant']
			except Exception: return None
		except Exception: log_utils.error()

	def unrestrict_link(self, link, returnAll=False):
		try:
			url = 'link/unlock'
			url_append = '&link=%s' % link
			response = self._get(url, url_append)
			if returnAll: return response
			else:
				try: return response['link']
				except Exception: return None
		except Exception: log_utils.error()

	def create_transfer(self, magnet):
		try:
			url = 'magnet/upload'
			url_append = '&magnet=%s' % magnet
			#log_utils.log('create transfer url=%s%s' % (url, url_append), __name__, log_utils.LOGDEBUG)
			result = self._get(url, url_append)
			try: result = result['magnets'][0]
			except Exception: return None
			log_utils.log('AllDebrid: Sending MAGNET to cloud: %s' % magnet, __name__, log_utils.LOGDEBUG)
			try: return result.get('id', "")
			except Exception: return None
		except Exception: log_utils.error()

	def list_transfer(self, transfer_id):
		try:
			url = 'magnet/status'
			url_append = '&id=%s' % transfer_id
			result = self._get(url, url_append)
			try: return result['magnets']
			except Exception: return None
		except Exception: log_utils.error()

	def delete_transfer(self, transfer_id, folder_name=None, silent=True):
		try:
			if not silent:
				if not control.yesnoDialog(getLS(40050) % '?\n' + folder_name, '', ''): return
			url = 'magnet/delete'
			url_append = '&id=%s' % transfer_id
			response = self._get(url, url_append)
			if silent: return
			else:
				if response and 'message' in response:
					if self.server_notifications: control.notification(message=response.get('message'), icon=ad_icon)
					log_utils.log('%s successfully deleted from the AllDebrid cloud' % folder_name, __name__, log_utils.LOGDEBUG)
					control.refresh()
					return
		except Exception: log_utils.error()

	def restart_transfer(self, transfer_id, folder_name=None, silent=True):
		try:
			if not silent:
				if not control.yesnoDialog(getLS(40007) % '\n' + folder_name, '', ''): return
			url = 'magnet/restart'
			url_append = '&id=%s' % transfer_id
			response = self._get(url, url_append)
			if silent: return
			else:
				if response and 'message' in response:
					if self.server_notifications: control.notification(message=response.get('message'), icon=ad_icon)
					log_utils.log('AllDebrid: %s' % response.get('message'), __name__, log_utils.LOGDEBUG)
					return control.refresh()
		except Exception: log_utils.error()

	def user_cloud(self):
		url = 'magnet/status'
		return self._get(url)

	def user_transfers_to_listItem(self):
		sysaddon, syshandle = 'plugin://plugin.video.luc_kodi/', int(argv[1])
		transfer_files = self.user_cloud()['magnets']
		if not transfer_files:
			if self.server_notifications: control.notification(message='Request Failure-Empty Content', icon=ad_icon)
			log_utils.log('AllDebrid: Request Failure-Empty Content', __name__, log_utils.LOGDEBUG)
			return
		folder_str, deleteMenu, restartMenu = getLS(40046).upper(), getLS(40050), getLS(40008)
		for count, item in enumerate(transfer_files, 1):
			try:
				status_code = item['statusCode'] 
				if status_code in (0,1, 2, 3):
					active = True
					downloaded = item['downloaded']
					size = item['size']
					try: percent = str(round(float(downloaded) / size * 100, 1))
					except Exception: percent = '0'
				else: active = False
				folder_name = string_tools.strip_non_ascii_and_unprintable(item['filename'])
				id = item['id']
				status_str = '[COLOR %s]%s[/COLOR]' % (self.highlight_color, item['status'].capitalize())
				if active: label = '%02d | [B]%s[/B] - %s | [B]%s[/B]' % (count, status_str, str(percent) + '%', folder_name)
				else: label = '%02d | [B]%s[/B] | [B]%s[/B] | [I]%s [/I]' % (count, status_str, folder_str, folder_name)
				if status_code == 4:
					url = '%s?action=ad_BrowseUserCloud&source=%s' % (sysaddon, quote_plus(jsdumps(item)))
					isFolder = True
				else:
					url = ''
					isFolder = False
				cm = []
				cm.append((deleteMenu % 'Transfer', 'RunPlugin(%s?action=ad_DeleteTransfer&id=%s&name=%s)' % (sysaddon, id, folder_name)))
				if status_code in (6, 7, 9, 10):
					cm.append((restartMenu, 'RunPlugin(%s?action=ad_RestartTransfer&id=%s&name=%s)' % (sysaddon, id, folder_name)))
				item = control.item(label=label, offscreen=True)
				attach_cm(item, cm)
				item.setArt({'icon': ad_icon, 'poster': ad_icon, 'thumb': ad_icon, 'fanart': addonFanart, 'banner': ad_icon})
				control.addItem(handle=syshandle, url=url, listitem=item, isFolder=isFolder)
			except Exception: log_utils.error()
		control.content(syshandle, 'files')
		control.directory(syshandle, cacheToDisc=True)

	def user_cloud_to_listItem(self, folder_id=None):
		sysaddon, syshandle = 'plugin://plugin.video.luc_kodi/', int(argv[1])
		folder_str, deleteMenu = getLS(40046).upper(), getLS(40050)
		cloud_dict = self.user_cloud()['magnets']
		cloud_dict = [i for i in cloud_dict if i['statusCode'] == 4]

		for count, item in enumerate(cloud_dict, 1):
			try:
				cm = []
				folder_name = string_tools.strip_non_ascii_and_unprintable(item['filename'])
				id = item['id']
				status_str = '[COLOR %s]%s[/COLOR]' % (self.highlight_color, item['status'].capitalize())
				label = '%02d | [B]%s[/B] | [B]%s[/B] | [I]%s [/I]' % (count, status_str, folder_str, folder_name)
				url = '%s?action=ad_BrowseUserCloud&source=%s' % (sysaddon, quote_plus(jsdumps(item)))
				cm.append((deleteMenu % 'Transfer', 'RunPlugin(%s?action=ad_DeleteTransfer&id=%s&name=%s)' %
					(sysaddon, id, folder_name)))
				item = control.item(label=label, offscreen=True)
				attach_cm(item, cm)
				item.setArt({'icon': ad_icon, 'poster': ad_icon, 'thumb': ad_icon, 'fanart': addonFanart, 'banner': ad_icon})
				control.addItem(handle=syshandle, url=url, listitem=item, isFolder=True)
			except Exception: log_utils.error()
		control.content(syshandle, 'files')
		control.directory(syshandle, cacheToDisc=True)

	def browse_user_cloud(self, folder):
		sysaddon, syshandle = 'plugin://plugin.video.luc_kodi/', int(argv[1])
		extensions = supported_video_extensions()

		try:
			torrent_folder = jsloads(folder)
		except Exception:
			log_utils.error('AllDebrid: invalid folder JSON')
			return

		status_code = torrent_folder.get('statusCode', 0)
		transfer_id = torrent_folder.get('id')

		file_str, downloadMenu = getLS(40047).upper(), getLS(40048)

		# New API: pull the file tree via /magnet/files, then flatten to leaf files
		files_tree = self._get_magnet_files(transfer_id)
		leaf_files = list(self._iter_leaf_files(files_tree))

		count = 0
		for f in leaf_files:
			try:
				name = string_tools.strip_non_ascii_and_unprintable(f.get('n', '') or '')
				if not name:
					continue
				low = name.lower().strip()

				if low.endswith(invalid_extensions) or is_archive_part(low):
					continue

				if not low.endswith(tuple(extensions)):
					# try unlock to get accurate filename (sometimes container name differs)
					try:
						link_info = cache.get(self.unrestrict_link, 168, f.get('l', ''), True)
						name2 = string_tools.strip_non_ascii_and_unprintable(link_info.get('filename', name))
						if name2.lower().endswith(invalid_extensions) or not name2.lower().endswith(tuple(extensions)):
							continue
						name = name2
						if 'filesize' in link_info:
							f['s'] = link_info['filesize']
					except Exception:
						continue

				size = int(f.get('s') or 0)
				display_size = float(size) / 1073741824 if size else 0.0
				url_link = f.get('l', '') or ''
				count += 1

				label = '%02d | [B]%s[/B] | %.2f GB | [I]%s [/I]' % (count, file_str, display_size, name)

				if status_code == 4 and url_link:
					url = '%s?action=play_URL&url=%s&caller=alldebrid&type=unrestrict' % (sysaddon, url_link)
				else:
					url = ''

				cm = []
				cm.append((
					downloadMenu,
					'RunPlugin(%s?action=download&name=%s&image=%s&url=%s&caller=alldebrid)' %
					( sysaddon, quote_plus(name), quote_plus(ad_icon), url_link )
				))

				li = control.item(label=label, offscreen=True)
				attach_cm(li, cm)
				li.setArt({'icon': ad_icon, 'poster': ad_icon, 'thumb': ad_icon, 'fanart': addonFanart, 'banner': ad_icon})
				control.addItem(handle=syshandle, url=url, listitem=li, isFolder=False)
			except Exception:
				log_utils.error()

		control.content(syshandle, 'files')
		control.directory(syshandle, cacheToDisc=True)



	def resolve_magnet(self, magnet_url, info_hash, season, episode, ep_title):
		from resources.lib.modules.source_utils import seas_ep_filter, extras_filter
		try:
			failed_reason, media_id, file_url = 'Unknown', None, None
			correct_files = []
			append = correct_files.append
			extras_filtering_list = extras_filter()
			transfer_id = self.create_transfer(magnet_url)
			transfer_info = self.list_transfer(transfer_id)
			if not transfer_info: return log_utils.log('AllDebrid: Error RESOLVE MAGNET "%s" : (Server Failed to respond)' % magnet_url, __name__, log_utils.LOGWARNING)
			#filenames = [i.get('filename') for i in transfer_info.get('links')]
			filenames = [i.get('n') for i in transfer_info.get('files', [])]
			if all(i.lower().endswith('.rar') for i in filenames): failed_reason = 'AD returned unsupported .rar file'
			# valid_results = [i for i in transfer_info.get('links') if any(i.get('filename').lower().endswith(x) for x in extensions) and not i.get('link', '') == ''] #.m2ts file extension is not in "filename" so this fails

			#log_utils.log('AllDebrid: resolve_magnet results=%s' % results, __name__, log_utils.LOGDEBUG)
			stack = list(transfer_info.get('files', []))
			leaf_files = []
			while stack:
				node = stack.pop()
				if 'e' in node:
					stack.extend(node['e'])
				elif node.get('l'):
					leaf_files.append(node)

			valid_results = [
				f for f in leaf_files
				if f.get('l') and not any(f.get('n','').lower().strip().endswith(ext) for ext in invalid_extensions)
			]

			if len(valid_results) == 0 and failed_reason == 'Unknown': failed_reason = 'No valid video extension found'

			if season:
				correct_files = []
				append = correct_files.append

				for item in valid_results:
					name = item.get('n', '')
					link = item.get('l', '')

					# skip BD structures
					if '.m2ts' in name.lower():
						failed_reason = 'Can not resolve .m2ts season disk episode'
						continue

					if seas_ep_filter(season, episode, name):
						norm = {'filename': name, 'link': link, 'size': item.get('s', 0)}
						append(norm)
						continue
					try:
						link_info = cache.get(self.unrestrict_link, 168, link, True)  # returnAll=True path
						resolved_name = link_info.get('filename', name)
						if seas_ep_filter(season, episode, resolved_name):
							norm = {'filename': resolved_name, 'link': link, 'size': item.get('s', 0)}
							append(norm)
					except Exception:
						log_utils.error()

				if len(correct_files) == 0:
					failed_reason = 'no matching episode found'
				else:
					episode_title = re.sub(r'[^A-Za-z0-9-]+', '.', (ep_title or '').replace("'", '')).lower()
					for i in correct_files:
						try:
							compare_link = seas_ep_filter(season, episode, i['filename'], split=True)
							compare_link = re.sub(episode_title, '', compare_link)
							if not any(x in compare_link for x in extras_filtering_list):
								media_id = i['link']
								break
						except Exception:
							log_utils.error()
			else:
				media_id = max(valid_results, key=lambda x: x.get('s')).get('l', None)
			if not self.store_to_cloud: self.delete_transfer(transfer_id)
			if not media_id:
				log_utils.log('AllDebrid: FAILED TO RESOLVE MAGNET "%s" : (%s)' % (magnet_url, failed_reason), __name__, log_utils.LOGWARNING)
				return None
			file_url = self.unrestrict_link(media_id)
			if not file_url:
				log_utils.log('AllDebrid: FAILED TO UNRESTRICT MAGNET "%s" ' % magnet_url, __name__, log_utils.LOGWARNING)
			return file_url
		except Exception:
			if failed_reason != 'Unknown': log_utils.log('AllDebrid: FAILED TO RESOLVE MAGNET "%s" : (%s)' % (magnet_url, failed_reason), __name__, log_utils.LOGWARNING)
			else: log_utils.error('AllDebrid: Error RESOLVE MAGNET %s : ' % magnet_url)
			if transfer_id: self.delete_transfer(transfer_id)
			return None

	def display_magnet_pack(self, magnet_url, info_hash):
		try:
			extensions = supported_video_extensions()
			transfer_id = self.create_transfer(magnet_url)
			transfer_info = self.list_transfer(transfer_id)
			if not transfer_info:
				if transfer_id and not self.store_to_cloud:
					self.delete_transfer(transfer_id)
				return None

			files_tree = self._get_magnet_files(transfer_id)
			leaf_files = list(self._iter_leaf_files(files_tree))

			end_results = []
			append = end_results.append

			for f in leaf_files:
				name = f.get('n', '') or ''
				link = f.get('l', '') or ''
				size_b = int(f.get('s') or 0)
				if not link:
					continue

				if any(name.lower().endswith(x) for x in extensions):
					append({'link': link, 'filename': name, 'size': float(size_b) / 1073741824})
				else:
					# try unlock to get final filename/size
					try:
						link_info = cache.get(self.unrestrict_link, 168, link, True)
						lname = link_info.get('filename', name)
						lsize = int(link_info.get('filesize') or size_b)
						if any(lname.lower().endswith(x) for x in extensions):
							append({'link': link, 'filename': lname, 'size': float(lsize) / 1073741824})
					except Exception:
						pass

			if not self.store_to_cloud:
				self.delete_transfer(transfer_id)

			return end_results
		except Exception:
			log_utils.error()
			try:
				if transfer_id and not self.store_to_cloud:
					self.delete_transfer(transfer_id)
			except Exception:
				pass
			return None



	def add_uncached_torrent(self, magnet_url, pack=False):
		def _return_failed(message=getLS(33586)):
			try: self.progressDialog.close()
			except Exception: pass
			self.delete_transfer(transfer_id)
			control.hide()
			control.sleep(500)
			control.okDialog(title=getLS(40018), message=message)
			return False
		control.busy()
		transfer_id = self.create_transfer(magnet_url)
		if not transfer_id: return _return_failed()
		transfer_info = self.list_transfer(transfer_id)
		if not transfer_info: return _return_failed()
		# if pack:
			# control.hide()
			# control.okDialog(title='default', message=getLS(40017) % getLS(40059))
			# return True
		interval = 5
		line = '%s\n%s\n%s'
		line1 = '%s...' % (getLS(40017) % getLS(40059))
		line2 = transfer_info['filename']
		line3 = transfer_info['status']
		self.progressDialog = control.progressDialog
		self.progressDialog.create(getLS(40018), line % (line1, line2, line3))
		while not transfer_info['statusCode'] == 4:
			control.sleep(1000 * interval)
			transfer_info = self.list_transfer(transfer_id)
			file_size = transfer_info['size']
			line2 = transfer_info['filename']
			if transfer_info['statusCode'] == 1:
				download_speed = round(float(transfer_info['downloadSpeed']) / (1000**2), 2)
				progress = int(float(transfer_info['downloaded']) / file_size * 100) if file_size > 0 else 0
				line3 = getLS(40016) % (download_speed, transfer_info['seeders'], progress, round(float(file_size) / (1000 ** 3), 2))
			elif transfer_info['statusCode'] == 3:
				upload_speed = round(float(transfer_info['uploadSpeed']) / (1000 ** 2), 2)
				progress = int(float(transfer_info['uploaded']) / file_size * 100) if file_size > 0 else 0
				line3 = getLS(40015) % (upload_speed, progress, round(float(file_size) / (1000 ** 3), 2))
			else:
				line3 = transfer_info['status']
				progress = 0
			self.progressDialog.update(progress, line % (line1, line2, line3))
			if control.monitor.abortRequested(): return sysexit()
			try:
				if self.progressDialog.iscanceled():
					if control.yesnoDialog('Delete AD download also?', 'No will continue the download', 'but close dialog','AllDebrid', 'No', 'Yes'):
						return _return_failed(getLS(40014))
					else:
						self.progressDialog.close()
						control.hide()
						return False
			except Exception: pass
			if 5 <= transfer_info['statusCode'] <= 10: return _return_failed()
		control.sleep(1000 * interval)
		try: self.progressDialog.close()
		except Exception: pass
		control.hide()
		return True

	def valid_url(self, host):
		try:
			self.hosts = self.get_hosts()
			if not self.hosts['AllDebrid']: return False
			if any(host in item for item in self.hosts['AllDebrid']): return True
			return False
		except Exception: log_utils.error()

	def get_hosts(self):
		url = 'hosts'
		hosts_dict = {'AllDebrid': []}
		hosts = []
		extend = hosts.extend
		try:
			result = cache.get(self._get, 168, url)
			result = result['hosts']
			for k, v in result.items():
				try: extend(v['domains'])
				except Exception: pass
			hosts_dict['AllDebrid'] = list(set(hosts))
		except Exception: log_utils.error()
		return hosts_dict
	
	#new helper classes for all debrid api changes.
	def _get_magnet_files(self, transfer_id):
		try:
			resp = self._post('magnet/files', {'id[]': [transfer_id]})
			if not resp:
				return []
			for m in resp.get('magnets', []):
				if str(m.get('id')) == str(transfer_id):
					return m.get('files', []) or []
		except Exception:
			log_utils.error()
		return []

	def _iter_leaf_files(self, tree):
		try:
			for node in tree or []:
				if 'e' in node:  # folder
					for child in self._iter_leaf_files(node.get('e', [])):
						yield child
				else:            # file (leaf)
					if node.get('n') and node.get('l'):
						yield node
		except Exception:
			log_utils.error()
			return


def expiry_notice():
	"""v2.0.04. Aviso de caducidad de AllDebrid Premium (ajuste alldebrid.expires).

	0 = apagado. Con N dias, si al Premium le quedan N dias o menos se avisa una
	vez al dia: el dia del ultimo aviso queda en alldebrid.expires.notified, asi
	que reiniciar Kodi no repite el aviso. Sin cuenta o sin respuesta de
	AllDebrid no hace nada."""
	from datetime import datetime
	try:
		days = int(getSetting('alldebrid.expires') or 0)
	except (TypeError, ValueError):
		days = 0
	if days <= 0 or not getSetting('alldebrid.token') or getSetting('alldebrid.enable') != 'true':
		return None
	today = datetime.today().strftime('%Y-%m-%d')
	if getSetting('alldebrid.expires.notified') == today:
		return None
	try:
		info = (AllDebrid().account_info() or {}).get('user') or {}
		until = int(info.get('premiumUntil') or 0)
	except Exception:
		log_utils.error()
		return None
	if not until or not info.get('isPremium'):
		return None
	left = (datetime.fromtimestamp(until).date() - datetime.today().date()).days
	if left > days or left < 0:
		return left
	control.setSetting('alldebrid.expires.notified', today)
	control.notification(title='AllDebrid', message=getLS(48008) if left == 0 else getLS(48013) if left == 1 else getLS(48007) % left, icon=ad_icon)
	log_utils.log('[ luc_kodi ] AllDebrid premium: %s days left (notice at %s)' % (left, days), level=log_utils.LOGINFO)
	return left
