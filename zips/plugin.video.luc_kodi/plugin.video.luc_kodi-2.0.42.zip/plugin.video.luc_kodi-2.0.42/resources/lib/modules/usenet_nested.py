# -*- coding: utf-8 -*-
"""
	luc_kodi Add-on
	v2.0.42 -- RAR dentro de otro archivo (7z o RAR) y nombres reales desde PAR2.

	RAR dentro de un archivo (kodi.log del 26-nov-2026: Michael y Supergirl de
	SURCODE y GAZPROM, "7z holds an archive inside the archive (.r00)"): hay
	quien vuelve a subir un release de la scene, con sus volumenes .rar/.r00 y
	su .sfv y .nfo, metido en un 7z (o en otro RAR) 'store'. Cada volumen de
	dentro es un fichero del archivo de fuera, que ya sabemos leer por trozos;
	aqui se ordenan por nombre, se leen sus cabeceras y se sabe donde esta cada
	fichero de dentro: [(volumen de dentro, desde, bytes)].

	Para no leer cientos de cabeceras (un UHD de 80 GB en volumenes de 250 MB
	son 330), con muchos volumenes se leen solo el primero, el segundo, uno de
	en medio y el ultimo: en un juego RAR los volumenes de en medio miden lo
	mismo y la cabecera de cada uno ocupa lo mismo (en RAR5 un byte mas desde
	el volumen 129). Si lo previsto no cuadra con lo leido, se leen todas.
	Idea tomada del motor de NuvioTV/AltMount (rar_in_rar.go, nested.go).

	PAR2 (especificacion de Parchive 2.0, paquete FileDesc): el indice .par2 de
	un release guarda el nombre real de cada fichero, su tamano y el MD5 de sus
	primeros 16 KB. En un post ofuscado (nombres al azar) se lee el primer
	articulo de cada fichero y se le devuelve su nombre por contenido, nunca
	por posicion. Despues el motor ya ordena volumenes y ve discos por nombre.

	Puro Python (struct, hashlib, re).
"""

import hashlib
import re
import struct
import threading

from resources.lib.modules import usenet_rar

FULL_MAX = 24            # hasta aqui se leen las cabeceras de todos los volumenes
WALK_MAX = 900           # con mas, sin prevision posible, no se sirve
_RE_RARVOL = re.compile(r'(?i)(\.part\d+\.rar|\.rar|\.[r-z]\d\d)$')


class NestedError(ValueError):
	pass


# ------------------------------------------------------------ volumenes ----
def _key(name):
	n = (name or '').lower().replace('\\', '/').rsplit('/', 1)[-1]
	m = re.search(r'\.part(\d+)\.rar$', n)
	if m:
		return n[:m.start()], (0, int(m.group(1)))
	if n.endswith('.rar'):
		return n[:-4], (1, -1)
	m = re.search(r'\.([r-z])(\d\d)$', n)
	if m:
		return n[:m.start()], (1, (ord(m.group(1)) - ord('r')) * 100 + int(m.group(2)))
	return None, None


def rar_volumes(items, name=lambda x: x['name'], size=lambda x: x['size']):
	"""Los volumenes RAR del archivo de fuera, en orden: el juego que mas pesa
	(puede haber otro de subtitulos, o una muestra en su propio RAR)."""
	groups = {}
	for it in items:
		stem, k = _key(name(it))
		if stem is None:
			continue
		groups.setdefault(stem, []).append((k, it))
	if not groups:
		return []
	best = max(groups.values(), key=lambda g: sum(size(it) for _k, it in g))
	best.sort(key=lambda x: x[0])
	return [it for _k, it in best]


def holds_rar_set(items, name=lambda x: x['name'], size=lambda x: x['size']):
	"""Si lo que mas pesa del archivo es un juego de volumenes RAR."""
	vols = rar_volumes(items, name, size)
	if not vols:
		return False
	total = sum(size(x) for x in items) or 1
	return sum(size(x) for x in vols) * 2 > total


# ---------------------------------------------------------------- layout ----
def _vint_len(v):
	n = 1
	while v >= 0x80:
		v >>= 7
		n += 1
	return n


def _files_of(parsed):
	return [b for b in parsed['blocks'] if not b['dir']]


def layout(sizes, open_reader, password=None, aes=None, workers=6, log=None, full_max=None):
	"""Ficheros del juego RAR de dentro.

	sizes: tamano de cada volumen de dentro (en orden). open_reader() ->
	(read_of, close): read_of(k) da read(off, n) del volumen k por una conexion
	propia; close() la devuelve. -> (entradas como usenet_rar.entries,
	'read'|'predicted'). Las entradas llevan 'pieces' [(volumen, desde, bytes)]."""
	n = len(sizes)
	if not n:
		raise NestedError('no RAR volumes inside')
	if n <= (FULL_MAX if full_max is None else full_max):
		return _walk(sizes, open_reader, password, aes, workers), 'read'
	try:
		return _predict(sizes, open_reader, password, aes), 'predicted'
	except NestedError as e:
		if log:
			log('the RAR volumes inside do not follow the usual layout (%s): reading every header' % e)
	if n > WALK_MAX:
		raise NestedError('%d RAR volumes inside, too many to read one by one' % n)
	return _walk(sizes, open_reader, password, aes, workers), 'read'


def _parse(read_of, k, size, password, aes):
	try:
		return usenet_rar.parse_volume(read_of(k), size, password, aes)
	except usenet_rar.RarError:
		raise
	except (ValueError, IndexError, KeyError, struct.error) as e:
		raise NestedError('RAR volume %d inside unreadable (%s)' % (k + 1, type(e).__name__))


def _walk(sizes, open_reader, password, aes, workers):
	n = len(sizes)
	parsed = [None] * n
	todo = list(range(n))
	errors = []
	lock = threading.Lock()

	def work():
		read_of, close = open_reader()
		try:
			while True:
				with lock:
					if not todo or errors:
						return
					k = todo.pop(0)
				try:
					parsed[k] = _parse(read_of, k, sizes[k], password, aes)
				except Exception as e:
					with lock:
						errors.append(e)
					return
		finally:
			close()

	ts = [threading.Thread(target=work, name='usenet-nested-rar', daemon=True) for _ in range(max(1, min(workers, n)))]
	[t.start() for t in ts]
	[t.join() for t in ts]
	if errors:
		raise errors[0]
	if any(p is None for p in parsed):
		raise NestedError('RAR headers inside could not be read')
	if len(set(p['fmt'] for p in parsed)) > 1:
		raise NestedError('RAR volumes inside mix format versions')
	try:
		return usenet_rar.entries(parsed)
	except usenet_rar.RarError as e:
		raise NestedError(str(e))


def _predict(sizes, open_reader, password, aes):
	"""Un fichero grande que atraviesa el juego (el caso de la pelicula): se
	leen 4 cabeceras y se calcula el resto."""
	n = len(sizes)
	read_of, close = open_reader()
	try:
		p0 = _parse(read_of, 0, sizes[0], password, aes)
		f0 = _files_of(p0)
		span = [b for b in f0 if b['sa']]
		if not span:
			raise NestedError('the first volume inside has no file that goes on')
		s0 = span[-1]
		if s0['sb']:
			raise NestedError('the set inside starts in the middle of a file')
		p1 = _parse(read_of, 1, sizes[1], password, aes)
		b1 = [b for b in _files_of(p1) if b['sb'] and b['name'] == s0['name']]
		if not b1:
			raise NestedError('volume 2 inside does not go on from volume 1')
		b1 = b1[0]
		fmt = p0['fmt']

		def grow(k):
			return _vint_len(k) - _vint_len(1) if fmt == 5 else 0

		pieces = [(0, s0['data_off'], s0['data_size'])]
		rem = s0['unp'] - s0['data_size'] if s0['store'] else None
		if rem is None:
			raise NestedError('compressed RAR inside')
		k = 1
		while rem > 0:
			if k >= n:
				raise NestedError('RAR volumes inside missing (%d of more)' % n)
			if k < n - 1 and sizes[k] != sizes[1]:
				raise NestedError('RAR volumes inside of different sizes')
			d = b1['data_size'] - grow(k)
			if k == 1:
				d = b1['data_size']
			take = min(rem, d)
			pieces.append((k, b1['data_off'] + grow(k), take))
			rem -= take
			k += 1
		last = k - 1
		checks = sorted(set([last] + ([last // 2] if last > 2 else [])))
		for c in checks:
			if c <= 1:
				continue
			pc = _parse(read_of, c, sizes[c], password, aes)
			bc = [b for b in _files_of(pc) if b['sb'] and b['name'] == s0['name']]
			want = pieces[c]
			if not bc or bc[0]['data_size'] != want[2]:
				raise NestedError('volume %d inside is not where it was expected' % (c + 1))
			if c == last:
				# la cabecera del ultimo puede medir distinto (sin 'sigue en el
				# siguiente'): manda la leida, como con los RAR de fuera
				if bc[0]['sa']:
					raise NestedError('the file inside goes on past its last volume')
				pieces[c] = (c, bc[0]['data_off'], bc[0]['data_size'])
			elif bc[0]['data_off'] != want[1]:
				raise NestedError('volume %d inside is not where it was expected' % (c + 1))
		entry = {'name': s0['name'], 'unp': s0['unp'], 'store': s0['store'], 'enc': s0['enc'],
				 'pieces': pieces, 'open': False}
		before = []
		for b in f0:
			if b is s0:
				break
			before.append({'name': b['name'], 'unp': b['unp'], 'store': b['store'], 'enc': b['enc'],
						   'pieces': [(0, b['data_off'], b['data_size'])], 'open': b['sa']})
		return before + [entry]
	finally:
		close()


def slice_pieces(pieces, start, length):
	"""Los trozos [(vol, desde, bytes)] de [start, start+length) de un fichero
	repartido en `pieces`."""
	out, pos, end = [], 0, start + length
	for v, off, sz in pieces:
		a, b = max(start, pos), min(end, pos + sz)
		if a < b:
			out.append((v, off + (a - pos), b - a))
		pos += sz
		if pos >= end:
			break
	return out


# ------------------------------------------------------------------ PAR2 ----
PAR2_MAGIC = b'PAR2\x00PKT'
_FILEDESC = b'PAR 2.0\x00FileDesc'
HASH16K = 16384
PAR2_INDEX_MAX = 32 * 1024 * 1024
PAR2_MAX_FILES = 1000


def parse_par2(data):
	"""Descripciones de fichero de un .par2: [{'name', 'size', 'hash16k'}].
	Un paquete cuyo MD5 no cuadra se salta (un indice danado solo pierde ese)."""
	out, seen, off, ln = [], set(), 0, len(data)
	while off + 64 <= ln:
		if data[off:off + 8] != PAR2_MAGIC:
			nxt = data.find(PAR2_MAGIC, off + 1)
			if nxt < 0:
				break
			off = nxt
			continue
		size = struct.unpack_from('<Q', data, off + 8)[0]
		if size < 64 or size % 4 or off + size > ln:
			off += 8
			continue
		pkt = data[off:off + size]
		if hashlib.md5(pkt[32:]).digest() != pkt[16:32]:
			off += 8
			continue
		if pkt[48:64] == _FILEDESC and len(pkt) > 64 + 56:
			body = pkt[64:]
			fid = body[:16]
			if fid not in seen:
				seen.add(fid)
				name = body[56:].rstrip(b'\x00').decode('utf-8', 'replace').replace('\\', '/').rsplit('/', 1)[-1]
				out.append({'name': name, 'size': struct.unpack_from('<Q', body, 48)[0], 'hash16k': body[32:48]})
		off += size
	return out


def par2_worth(files, classify):
	"""Si el NZB tiene nombres que no dicen nada (ofuscados) y trae PAR2."""
	if not any((f.get('name') or '').lower().endswith('.par2') for f in files):
		return False
	return any(classify(f.get('name')) == 'obfuscated' for f in files)


def match_names(descs, heads):
	"""heads: [(fichero, tamano exacto, primeros 16 KB)]. -> [(fichero, nombre real)]
	de los que casan con una sola descripcion por MD5 y tamano."""
	by_hash = {}
	for d in descs:
		by_hash.setdefault(d['hash16k'], []).append(d)
	out = []
	for f, size, head in heads:
		if head is None or head.startswith(PAR2_MAGIC):
			continue
		m = by_hash.get(hashlib.md5(head[:HASH16K]).digest()) or []
		if len(m) == 1 and m[0]['size'] == size and m[0]['name'] not in ('', '.'):
			out.append((f, m[0]['name']))
	return out
