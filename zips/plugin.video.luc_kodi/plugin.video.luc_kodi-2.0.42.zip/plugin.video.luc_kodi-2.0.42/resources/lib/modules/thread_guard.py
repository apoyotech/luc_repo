# -*- coding: utf-8 -*-
"""
	luc_kodi Add-on — thread_guard.py (v2.0.40)

	Kodi 22 hardening, installed first thing by luc_kodi.py and service.py.

	Python keeps some of its own registries behind weak references whose
	callbacks run when an object is freed: the set of threads
	(threading._dangling), the locks of the import system, and logging's
	handlers. When Kodi tears an interpreter down at the end of a call, a
	callback can find its registry already gone. On Kodi 22 (Python 3.14)
	other add-ons have logged "Exception ignored while calling weakref
	callback WeakSet._remove" followed by a SIGSEGV in
	PyObject_ClearWeakRefs, which closes Kodi. luc_kodi starts many threads
	(catalog precache, scrapers, service loops), so it is exposed the same way.

	The fix is to keep those registries with plain references, so no callback
	is ever left behind:
	  - threading._dangling only serves Python's own test suite: an inert set.
	  - import locks: kept for good (a few hundred small objects per call).
	  - logging: handlers kept in a plain dict; a call makes a handful. Applied
    at start if logging is already loaded and again by finish() at the end.

	Only on Python 3.12 and later (Kodi 22). Kodi 21 runs Python 3.11, where
	the crash was never seen, and stays exactly as before. Every step is
	optional: if Python's internals differ, that step is skipped and the
	plugin runs as in 2.0.39.

	Imports nothing of the plugin, so it can run before anything else.
"""

import sys
import threading

ACTIVE = sys.version_info >= (3, 12)


class _Inert(object):
	"""Takes the place of a WeakSet nobody needs to read."""
	def add(self, *_args):
		pass

	def discard(self, *_args):
		pass

	def remove(self, *_args):
		pass

	def clear(self):
		pass

	def __len__(self):
		return 0

	def __iter__(self):
		return iter(())

	def __contains__(self, _item):
		return False


def _threads():
	old = threading._dangling
	if isinstance(old, _Inert): return
	threading._dangling = _Inert()
	old.clear()


def _import_locks():
	try:
		import _frozen_importlib as boot
	except ImportError:
		import importlib._bootstrap as boot
	if getattr(boot, '_luc_kodi_locks', False): return
	imp = boot._imp
	needed = ('_module_locks', '_ModuleLock', '_DummyModuleLock', '_get_module_lock')
	if not all(hasattr(boot, n) for n in needed): return
	kept = {}
	imp.acquire_lock()
	try:
		for name, ref in list(boot._module_locks.items()):
			try: lock = ref()
			except Exception: lock = None
			if lock is not None: kept[name] = lock

		def _get_module_lock(name):
			imp.acquire_lock()
			try:
				lock = kept.get(name)
				if lock is None:
					lock = boot._DummyModuleLock(name) if boot._thread is None else boot._ModuleLock(name)
					kept[name] = lock
			finally:
				imp.release_lock()
			return lock

		# Python 3.12+ also keeps, per thread, the locks it waits on in a weak
		# dictionary (used to detect import deadlocks). A plain dict does the
		# same job: each thread only touches its own entry, an empty list when
		# idle. Nobody is waiting here (install runs between imports).
		blocking = getattr(boot, '_blocking_on', None)
		if blocking is not None and not isinstance(blocking, dict):
			boot._blocking_on = {}
		# switch last, once nothing above can fail; the weak references go too:
		# one freed before its lock never calls back
		boot._get_module_lock = _get_module_lock
		boot._module_locks.clear()
		boot._luc_kodi_locks = True
	finally:
		imp.release_lock()


def _logging():
	# Not imported here: it costs ~1 MB and 15 ms on every menu click. requests
	# and urllib3 bring it in when a call goes to the network, and finish()
	# runs again at the end of the call, before Kodi tears the interpreter down.
	logging = sys.modules.get('logging')
	if logging is None: return False
	if getattr(logging, '_luc_kodi_refs', False): return
	lock = getattr(logging, '_lock', None)
	if lock is not None: lock.acquire()
	try:
		if not isinstance(logging._handlers, dict):
			logging._handlers = dict(logging._handlers.items())
		# _handlerList is only walked by logging.shutdown() at exit, which Kodi
		# does not reach for an add-on interpreter
		logging._handlerList[:] = []
		logging._addHandlerRef = lambda _handler: None
		old = getattr(logging, '_at_fork_reinit_lock_weakset', None)
		if old is not None and not isinstance(old, _Inert):
			logging._at_fork_reinit_lock_weakset = _Inert()   # read only after a fork
			old.clear()
		logging._luc_kodi_refs = True
	finally:
		if lock is not None: lock.release()


def _run(steps):
	done = []
	if not ACTIVE: return done
	for name, step in steps:
		try:
			if step() is not False: done.append(name)
		except Exception:
			pass
	return done


def install():
	"""First thing in luc_kodi.py and service.py. Returns the steps run."""
	return _run((('threads', _threads), ('import_locks', _import_locks), ('logging', _logging)))


def finish():
	"""At the end of a call: logging may have been loaded during it, and a
	thread started by a module that put its own set back is forgotten too."""
	return _run((('threads', _threads), ('logging', _logging)))
