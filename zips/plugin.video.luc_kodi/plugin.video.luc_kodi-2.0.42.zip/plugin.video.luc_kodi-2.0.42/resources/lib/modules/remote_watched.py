# -*- coding: utf-8 -*-
"""
	luc_kodi Add-on
	remote_watched.py (v2.0.38) - the watched history of SIMKL or MDBList
	painted as luc_kodi's watched marks, when Trakt is not the source.

	How: the account's history is copied into the local watched base
	(database/watchedcache.py), the same base that keeps the marks without any
	tracking account. Every menu already knows how to read it, movies, shows,
	seasons and episodes alike, so the marks follow the account everywhere.
	A small table (remote_mirror) remembers which rows came from the account:
	when the account forgets one, that row goes; marks made in luc_kodi stay.

	Which account:
	  - Trakt, when Trakt is the source of the marks (playcount.py, unchanged);
	  - otherwise SIMKL, when "Use SIMKL for watched indicators" is on;
	  - otherwise MDBList, when "Use MDBList for watched indicators" is on (on
	    by default: until 2.0.37 an MDBList account never showed what had been
	    watched, everything appeared unwatched).

	When: at most one cheap "anything new?" request every 10 minutes (SIMKL
	/sync/activities, MDBList /sync/last_activities); the whole history is read
	only when that answer changes, the first time, or on "refresh".
	Marks changed in luc_kodi are sent to the account too (push_*).
"""

import time
from resources.lib.modules import control, log_utils

CHECK_EVERY = 600  # s between "anything new?" requests
PROP_LOCK = 'luc_kodi.remote_watched.busy'


def source():
	"""'simkl', 'mdblist' or None (Trakt is decided in playcount.py)."""
	try:
		from resources.lib.modules import simkl
		if simkl.getSimklIndicatorsInfo(): return 'simkl'
	except Exception: log_utils.error()
	try:
		from resources.lib.modules import mdblist
		if mdblist.getMDBListIndicatorsInfo(): return 'mdblist'
	except Exception: log_utils.error()
	return None


# ------------------------------------------------------------------ base
class _Conn:
	"""Its own connection to the watched base: the service calls this from a
	thread of its own, and sqlite connections belong to the thread that made
	them (the module-level one of watchedcache.py may come from another)."""
	def __init__(self):
		from sqlite3 import dbapi2 as db
		from resources.lib.database import watchedcache  # creates the base and its tables if needed
		self.dbcon = db.connect(watchedcache.watchedcacheFile, timeout=60)
		self.dbcur = self.dbcon.cursor()

	def close(self):
		try:
			self.dbcon.commit()
			self.dbcur.close(); self.dbcon.close()
		except Exception: pass


def _db():
	c = _Conn()
	c.dbcur.execute("""CREATE TABLE IF NOT EXISTS remote_mirror
		(source TEXT, media_type TEXT, imdb_id TEXT, tmdb_id TEXT, season TEXT, episode TEXT,
		UNIQUE (source, media_type, imdb_id, tmdb_id, season, episode));""")
	c.dbcur.execute("""CREATE TABLE IF NOT EXISTS remote_meta
		(source TEXT PRIMARY KEY, last_check INTEGER, activity TEXT);""")
	return c


def _meta(c, src):
	row = c.dbcur.execute('SELECT last_check, activity FROM remote_meta WHERE source = ?', (src,)).fetchone()
	return (int(row[0] or 0), row[1] or '') if row else (0, None)


def _set_meta(c, src, last_check, activity):
	c.dbcur.execute('INSERT OR REPLACE INTO remote_meta VALUES (?, ?, ?)', (src, int(last_check), activity or ''))


def _epoch(text):
	try:
		from resources.lib.modules import cleandate
		return int(cleandate.iso_2_utc(text))
	except Exception:
		return int(time.time())


# ------------------------------------------------------------------ remote
def _remote(src):
	"""set of keys (media_type, imdb, tmdb, season, episode) -> watched_at epoch; None if unreadable."""
	out = {}
	if src == 'mdblist':
		from resources.lib.modules import mdblist
		got = mdblist.getWatchedHistory()
		if got is None: return None
		movies, episodes = got
		for m in movies:
			out[('movie', m['imdb'], m['tmdb'] if not m['imdb'] else '', '', '')] = _epoch(m['watched_at'])
		for e in episodes:
			out[('episode', e['imdb'], e['tmdb'] if not e['imdb'] else '', str(e['season']), str(e['episode']))] = _epoch(e['watched_at'])
		return out
	if src == 'simkl':
		from resources.lib.modules import simkl
		movies = simkl.syncMovies()
		shows = simkl.syncTVShows()
		if movies is None and shows is None: return None
		now = int(time.time())
		for imdb in movies or []:
			if imdb: out[('movie', str(imdb), '', '', '')] = now
		for ids, _total, eps in shows or []:
			imdb = str((ids or {}).get('imdb') or '')
			tmdb = '' if imdb else str((ids or {}).get('tmdb') or '')
			if not (imdb or tmdb): continue
			for s, e in eps or []:
				out[('episode', imdb, tmdb, str(s), str(e))] = now
		return out
	return None


def _activity(src):
	try:
		if src == 'mdblist':
			from resources.lib.modules import mdblist
			return mdblist.getWatchedActivity()
		if src == 'simkl':
			from resources.lib.modules import simkl
			return '%s|%s' % (simkl.getMoviesWatchedActivity(), simkl.getEpisodesWatchedActivity())
	except Exception:
		log_utils.error()
	return ''


def _apply(c, src, remote):
	"""Copies `remote` into the watched base; returns (added, removed)."""
	cur = c.dbcur
	have = set(tuple(r) for r in cur.execute(
		'SELECT media_type, imdb_id, tmdb_id, season, episode FROM remote_mirror WHERE source = ?', (src,)).fetchall())
	want = set(remote)
	added = removed = 0
	for key in want - have:
		mt, imdb, tmdb, s, e = key
		# INSERT OR IGNORE: a mark already made in luc_kodi stays as it is
		cur.execute('INSERT OR IGNORE INTO watched VALUES (?, ?, ?, ?, ?, ?, ?, ?)',
					(mt, imdb, tmdb, s, e, '', remote[key], 5))
		cur.execute('INSERT OR IGNORE INTO remote_mirror VALUES (?, ?, ?, ?, ?, ?)', (src,) + key)
		added += 1
	for key in have - want:
		mt, imdb, tmdb, s, e = key
		cur.execute('DELETE FROM watched WHERE media_type = ? AND imdb_id = ? AND tmdb_id = ? AND season = ? AND episode = ?',
					(mt, imdb, tmdb, s, e))
		cur.execute('DELETE FROM remote_mirror WHERE source = ? AND media_type = ? AND imdb_id = ? AND tmdb_id = ? AND season = ? AND episode = ?',
					(src,) + key)
		removed += 1
	return added, removed


def _drop_other_sources(c, keep):
	"""When the source changes, what the old account copied is taken away."""
	cur = c.dbcur
	for (src,) in cur.execute('SELECT DISTINCT source FROM remote_mirror').fetchall():
		if src == keep: continue
		_apply(c, src, {})
		cur.execute('DELETE FROM remote_meta WHERE source = ?', (src,))


def ensure(refresh=False):
	"""Brings the watched base up to date with the account. Cheap when nothing changed."""
	src = source()
	home = control.homeWindow
	if home.getProperty(PROP_LOCK) == 'true': return src
	c, locked = None, False
	try:
		c = _db()
		_drop_other_sources(c, src)
		if not src:
			c.dbcon.commit()
			return None
		now = int(time.time())
		last_check, activity = _meta(c, src)
		if not refresh and now - last_check < CHECK_EVERY and activity is not None:
			c.dbcon.commit()
			return src
		home.setProperty(PROP_LOCK, 'true'); locked = True
		act = _activity(src)
		if activity is not None and act and act == activity:
			_set_meta(c, src, now, act)
			c.dbcon.commit()
			return src
		remote = _remote(src)
		if remote is None:  # the account could not be read: nothing is taken away, retried in 10 min
			_set_meta(c, src, now, activity or '')
			c.dbcon.commit()
			return src
		added, removed = _apply(c, src, remote)
		_set_meta(c, src, now, act)
		c.dbcon.commit()
		log_utils.log('remote_watched %s: %d watched in the account, %d added, %d removed'
					  % (src, len(remote), added, removed), level=log_utils.LOGINFO)
		return src
	except Exception:
		log_utils.error()
		return src
	finally:
		if c: c.close()
		if locked: home.clearProperty(PROP_LOCK)


def forget_check():
	"""The next ensure() asks the account again (after a mark made here)."""
	try:
		c = _db()
		c.dbcur.execute('UPDATE remote_meta SET last_check = 0')
		c.close()
	except Exception: log_utils.error()


# ------------------------------------------------------------------ marks made in luc_kodi
def _unmirror(src, key):
	"""A mark removed here must not come back from the copy of the account."""
	try:
		c = _db()
		c.dbcur.execute('DELETE FROM remote_mirror WHERE source = ? AND media_type = ? AND imdb_id = ? AND tmdb_id = ? AND season = ? AND episode = ?',
						(src,) + key)
		c.close()
	except Exception: log_utils.error()


def push_movie(imdb, tmdb, watched):
	src = source()
	if not src: return
	try:
		if src == 'mdblist':
			from resources.lib.modules import mdblist
			(mdblist.addWatched if watched else mdblist.removeWatched)(imdb=imdb or None, tmdb=tmdb or None)
		else:
			from resources.lib.modules import simkl
			if imdb: (simkl.markMovieAsWatched if watched else simkl.markMovieAsNotWatched)(imdb)
		if not watched: _unmirror(src, ('movie', imdb or '', '' if imdb else (tmdb or ''), '', ''))
		forget_check()
	except Exception: log_utils.error()


def push_episodes(imdb, tmdb, tvdb, eps, watched):
	"""eps: [(season, episode)] of one show, sent in ONE request."""
	src = source()
	if not src or not eps: return
	try:
		seasons = {}
		for s, e in eps: seasons.setdefault(int(s), []).append({'number': int(e)})
		ids = {}
		if imdb: ids['imdb'] = imdb if str(imdb).startswith('tt') else 'tt' + str(imdb)
		if tmdb and str(tmdb).isdigit(): ids['tmdb'] = int(tmdb)
		if tvdb and str(tvdb).isdigit(): ids['tvdb'] = int(tvdb) if src == 'mdblist' else str(tvdb)
		if not ids: return
		body = {'shows': [{'ids': ids, 'seasons': [{'number': s, 'episodes': v} for s, v in sorted(seasons.items())]}]}
		if src == 'mdblist':
			from resources.lib.modules import mdblist
			if watched: mdblist._post('/sync/watched', json_data=body, silent=True)
			else: mdblist._post('/sync/watched/remove', json_data=body, silent=True)
		else:
			from resources.lib.modules import simkl
			simkl.getSimkl('/sync/history' if watched else '/sync/history/remove', post=body)
		if not watched:
			for s, e in eps: _unmirror(src, ('episode', imdb or '', '' if imdb else (tmdb or ''), str(s), str(e)))
		forget_check()
	except Exception: log_utils.error()
