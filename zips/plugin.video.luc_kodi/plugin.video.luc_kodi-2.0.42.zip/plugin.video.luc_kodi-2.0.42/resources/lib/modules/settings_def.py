# -*- coding: utf-8 -*-
"""
	luc_kodi Add-on
	settings_def.py (v2.0.38) - the one reader of resources/settings.xml.

	resources/settings.xml is in Kodi's settings format version 1 (Kodi 18 and
	later): categories > groups > settings, every setting with its own id, and
	conditions that name the setting they read (<dependency> / <condition>)
	instead of the old relative eq(-N) offsets. Everything in the add-on that
	needs the definition (declared ids, defaults, options, the settings window,
	the search in the context panel, the clean-up of stale ids) reads it here,
	so the format lives in one place.

	Each setting comes out as a plain dict:
	  id, cat (category index), group (group index in the category),
	  kind     the classic name of the control: bool, text, number, slider,
	           folder, action, enum, select, labelenum
	  store    what Kodi keeps: bool, int, float, str, none (pure actions)
	  label    strings.po id (int, 0 when there is none)
	  default  text, as getSetting() returns it
	  options  [(label id, value)] for enum/select/labelenum
	  by_index True when the stored value is the option's index (enum, select
	           with labels), False when it is the option's text
	  min, step, max   sliders
	  hidden   text typed as a password
	  action   builtin of an action setting; close: the action closes the dialog
	  parent   id of the setting it hangs from (shown indented)
	  visible / enable   False when fixed off; otherwise a list of
	           (negated, setting id, value) that must all hold
	Categories: [{'index', 'id', 'label', 'groups': [{'index', 'label', 'ids'}]}]
	The category "launcher" (the only one Kodi's dialog shows, with the button
	that opens luc_kodi's window) is left out, so indexes stay as they were.
"""

import xml.etree.ElementTree as ET

_CACHE = {}


def _path():
	from resources.lib.modules import control
	return control.joinPath(control.addonPath(control.addonId()), 'resources', 'settings.xml')


def _int(v, fallback=0):
	try: return int(v)
	except Exception: return fallback


def _conds(dep):
	out = []
	for c in dep.iter('condition'):
		op = (c.get('operator') or 'is').strip()
		out.append((op.startswith('!'), c.get('setting') or '', c.text or ''))
	return out


def _kind(stype, s, ctl, has_opts):
	ctype = ctl.get('type') if ctl is not None else ''
	cfmt = ctl.get('format') if ctl is not None else ''
	if stype == 'boolean': return 'bool'
	if stype == 'action': return 'action'
	if stype == 'path': return 'folder'
	if ctype == 'button' and cfmt == 'action': return 'action'  # an action that keeps a value
	if has_opts:
		if stype == 'integer': return 'enum' if ctype == 'spinner' else 'select'
		return 'labelenum' if ctype == 'spinner' else 'select'
	if ctype == 'slider': return 'slider'
	if stype in ('integer', 'number'): return 'number'
	return 'text'


def _parse_v1(root):
	cats, settings, order = [], {}, []
	section = root.find('section')
	if section is None: return cats, settings, order
	for ci, c in enumerate(c_ for c_ in section.findall('category') if c_.get('id') != 'launcher'):
		cat = {'index': ci, 'id': c.get('id') or '', 'label': _int(c.get('label')), 'groups': []}
		cats.append(cat)
		for gi, g in enumerate(c.findall('group')):
			grp = {'index': gi, 'label': _int(g.get('label')), 'ids': []}
			cat['groups'].append(grp)
			for s in g.findall('setting'):
				sid = s.get('id')
				if not sid: continue
				stype = s.get('type') or 'string'
				ctl = s.find('control')
				opts = s.find('constraints/options')
				options = [(_int(o.get('label')), o.text or '') for o in opts.findall('option')] if opts is not None else []
				kind = _kind(stype, s, ctl, bool(options))
				d = s.find('default')
				rec = {
					'id': sid, 'cat': ci, 'group': gi, 'kind': kind,
					'store': {'boolean': 'bool', 'integer': 'int', 'number': 'float', 'action': 'none'}.get(stype, 'str'),
					'label': _int(s.get('label')),
					'default': (d.text or '') if d is not None else '',
					'options': options,
					'by_index': stype == 'integer' and bool(options),
					'parent': s.get('parent') or '',
					'hidden': False, 'action': '', 'close': False,
					'visible': [], 'enable': [],
				}
				# Kodi's dialog sees every setting as <visible>false</visible> (it only
				# shows the launcher); luc_hidden="true" says which are hidden here too
				if s.get('luc_hidden') == 'true': rec['visible'] = False
				v = s.find('enable')
				if v is not None and (v.text or '').strip() == 'false': rec['enable'] = False
				deps = s.find('dependencies')
				if deps is not None:
					for dep in deps.findall('dependency'):
						key = 'visible' if dep.get('type') == 'visible' else 'enable' if dep.get('type') == 'enable' else None
						if key and rec[key] is not False: rec[key] = rec[key] + _conds(dep)
				for k in ('minimum', 'step', 'maximum'):
					e = s.find('constraints/' + k)
					if e is not None: rec[{'minimum': 'min', 'maximum': 'max'}.get(k, k)] = e.text or ''
				if ctl is not None:
					h = ctl.find('hidden')
					rec['hidden'] = h is not None and (h.text or '').strip() == 'true'
					cl = ctl.find('close')
					rec['close'] = cl is not None and (cl.text or '').strip() == 'true'
					data = ctl.find('data')
					if data is not None: rec['action'] = data.text or ''
				data = s.find('data')
				if data is not None: rec['action'] = data.text or ''
				settings[sid] = rec
				order.append(sid)
				grp['ids'].append(sid)
	return cats, settings, order


def load(path=None):
	"""(categories, settings by id, ids in order). Read once per process."""
	key = path or 'addon'
	if key in _CACHE: return _CACHE[key]
	try:
		root = ET.parse(path or _path()).getroot()
		data = _parse_v1(root) if root.get('version') else ([], {}, [])
	except Exception:
		from resources.lib.modules import log_utils
		log_utils.error()
		data = ([], {}, [])
	if data[1]: _CACHE[key] = data
	return data


def categories(): return load()[0]
def settings(): return load()[1]
def ids(): return list(load()[2])
def get(setting_id): return load()[1].get(setting_id)


def stored_ids(path=None):
	"""v2.0.41: every id Kodi keeps in the user's settings.xml, the "launcher"
	category included. ids() leaves the launcher out (it is not part of
	luc_kodi's window), and the clean-up used it: launcher.note, a live
	setting, was taken for obsolete and removed on every update."""
	try: root = ET.parse(path or _path()).getroot()
	except Exception:
		from resources.lib.modules import log_utils
		log_utils.error()
		return []
	return [s.get('id') for s in root.iter('setting') if s.get('id') and (s.get('type') or 'string') != 'action']


def defaults():
	"""{id: default} of every setting that keeps a value."""
	return dict((k, v['default']) for k, v in load()[1].items() if v['store'] != 'none')


def option_values(setting_id):
	s = get(setting_id)
	return [v for _, v in s['options']] if s else []


def holds(conds, values):
	"""True when every (negated, id, value) holds for the current values."""
	if conds is False: return False
	for neg, sid, val in conds or ():
		res = (values.get(sid, '') == val)
		if neg: res = not res
		if not res: return False
	return True
