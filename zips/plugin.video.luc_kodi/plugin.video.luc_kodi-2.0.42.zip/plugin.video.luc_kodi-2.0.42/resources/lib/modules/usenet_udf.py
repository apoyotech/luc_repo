# -*- coding: utf-8 -*-
"""
	luc_kodi -- Usenet: imagen ISO de un Blu-ray (UDF) leida por dentro (v2.0.37)

	Muchos 'COMPLETE.UHD.BLURAY' son una ISO: el disco entero en un fichero con
	el sistema de ficheros UDF (2.50 en los Blu-ray, con particion de
	metadatos). Kodi no la abre por HTTP, pero dentro estan los mismos
	BDMV/PLAYLIST/*.mpls y BDMV/STREAM/*.m2ts que en un disco suelto, y sin
	comprimir: basta saber DONDE esta cada fichero dentro de la ISO (sus
	extensiones) para servir la pelicula como con un BDMV (usenet_disc).

	read(posicion, longitud) -> bytes de la ISO. Solo se leen los descriptores
	y los directorios BDMV, PLAYLIST y STREAM (unos pocos sectores).
"""

import struct

SECTOR = 2048
WALK = ('bdmv', 'playlist', 'stream')     # solo se baja por estas carpetas
MAX_FIDS = 20000


class UdfError(ValueError):
	pass


def _u16(b, i): return struct.unpack_from('<H', b, i)[0]
def _u32(b, i): return struct.unpack_from('<L', b, i)[0]
def _u64(b, i): return struct.unpack_from('<Q', b, i)[0]


def is_udf(read):
	"""Hay UDF (descriptor NSR02/NSR03 en el area de reconocimiento)."""
	try:
		for s in range(16, 32):
			d = read(s * SECTOR, 8)
			if d[1:6] in (b'NSR02', b'NSR03'):
				return True
			if d[1:6] == b'TEA01':
				break
	except Exception:
		pass
	return False


class Udf(object):
	def __init__(self, read):
		self._read = read
		self._cache = {}
		self.bs = SECTOR
		self.parts = {}          # numero de particion -> sector de inicio
		self.maps = []           # ('phys', num) | ('meta', num, sector del fichero de metadatos)
		self.meta_ext = None     # extensiones (sector fisico, bytes) del fichero de metadatos
		self.fsd = None
		self.short_mode = 'phys'
		self._volume()

	# -- lectura -------------------------------------------------------------
	def read(self, off, n):
		k = (off, n)
		if k not in self._cache:
			while len(self._cache) >= 512: # v2.0.41: fuera la mas antigua, no todas (los descriptores del volumen se quedan)
				self._cache.pop(next(iter(self._cache)))
			self._cache[k] = self._read(off, n)
		return self._cache[k]

	def _tag(self, b):
		return _u16(b, 0) if len(b) >= 16 else -1

	# -- descriptores de volumen --------------------------------------------
	def _volume(self):
		avdp = self.read(256 * SECTOR, SECTOR)
		if self._tag(avdp) != 2:
			raise UdfError('UDF anchor not found')
		vlen, vloc = _u32(avdp, 16), _u32(avdp, 20)
		lvd = None
		for i in range(min(64, max(1, vlen // SECTOR))):
			d = self.read((vloc + i) * SECTOR, SECTOR)
			t = self._tag(d)
			if t == 5:                                    # Partition Descriptor
				self.parts[_u16(d, 22)] = _u32(d, 188)
			elif t == 6:                                  # Logical Volume Descriptor
				lvd = d
			elif t == 8:                                  # Terminating
				break
		if lvd is None or not self.parts:
			raise UdfError('UDF volume descriptors not found')
		self.bs = _u32(lvd, 212) or SECTOR
		if self.bs != SECTOR:
			raise UdfError('UDF block size %d not supported' % self.bs)
		self.fsd = (_u32(lvd, 252), _u16(lvd, 256))      # lbn, particion (long_ad del FSD)
		n_maps, pos = _u32(lvd, 268), 440
		for _ in range(n_maps):
			ptype, plen = lvd[pos], lvd[pos + 1]
			if ptype == 1:
				self.maps.append(('phys', _u16(lvd, pos + 4)))
			elif ptype == 2:
				ident = lvd[pos + 5:pos + 28]
				if b'Metadata' in ident:
					self.maps.append(('meta', _u16(lvd, pos + 38), _u32(lvd, pos + 40)))
				else:                                     # Sparable, Virtual: como fisica
					self.maps.append(('phys', _u16(lvd, pos + 38)))
			else:
				raise UdfError('UDF partition map type %d' % ptype)
			pos += plen or 6
		for m in self.maps:
			if m[0] == 'meta':
				fe = self._fe_at(self._phys(m[1], m[2]))
				self.meta_ext = [(self._phys(m[1], lbn), ln) for kind, part, lbn, ln in fe['ads'] if kind == 'short']

	def _phys(self, partnum, lbn):
		if partnum not in self.parts:
			raise UdfError('UDF partition %d missing' % partnum)
		return (self.parts[partnum] + lbn) * SECTOR

	def addr(self, ref, lbn):
		"""Posicion en la ISO de un bloque logico de la particion `ref`."""
		if ref >= len(self.maps):
			raise UdfError('UDF partition reference %d' % ref)
		m = self.maps[ref]
		if m[0] == 'phys':
			return self._phys(m[1], lbn)
		off = lbn * SECTOR
		for start, ln in self.meta_ext or []:
			if off < ln:
				return start + off
			off -= ln
		raise UdfError('UDF metadata block %d out of range' % lbn)

	# -- File Entry ----------------------------------------------------------
	def _fe_at(self, pos, ref=None):
		d = self.read(pos, SECTOR)
		t = self._tag(d)
		if t == 261:
			lea, lad, base = _u32(d, 168), _u32(d, 172), 176
		elif t == 266:
			lea, lad, base = _u32(d, 208), _u32(d, 212), 216
		else:
			raise UdfError('UDF file entry expected, tag %d' % t)
		need = base + lea + lad
		if need > len(d):
			d = self.read(pos, -(-need // SECTOR) * SECTOR)
		size = _u64(d, 56)
		adtype = _u16(d, 16 + 18) & 7
		ads, embedded = [], None
		a, end = base + lea, base + lea + lad
		if adtype == 0:
			while a + 8 <= end:
				ln = _u32(d, a)
				if ln & 0x3FFFFFFF:
					ads.append(('short', ref, _u32(d, a + 4), ln & 0x3FFFFFFF) if ln >> 30 == 0 else ('hole', ref, 0, ln & 0x3FFFFFFF))
				a += 8
		elif adtype == 1:
			while a + 16 <= end:
				ln = _u32(d, a)
				if ln & 0x3FFFFFFF:
					ads.append(('long', _u16(d, a + 8), _u32(d, a + 4), ln & 0x3FFFFFFF) if ln >> 30 == 0 else ('hole', None, 0, ln & 0x3FFFFFFF))
				a += 16
		elif adtype == 3:
			embedded = d[a:end]
		else:
			raise UdfError('UDF extended allocation descriptors not supported')
		return {'size': size, 'ads': ads, 'embedded': embedded, 'dir': (d[16 + 11] == 4)}

	def fe(self, ref, lbn):
		return self._fe_at(self.addr(ref, lbn), ref)

	def extents(self, fe, mode=None):
		"""[(posicion en la ISO, bytes)] de los datos de un fichero."""
		mode = mode or self.short_mode
		out = []
		left = fe['size']
		for kind, ref, lbn, ln in fe['ads']:
			if left <= 0:
				break
			ln = min(ln, left)
			if kind == 'long':
				out.append((self.addr(ref, lbn), ln))
			elif kind == 'short':
				m = self.maps[ref] if ref is not None and ref < len(self.maps) else ('phys', 0)
				if m[0] == 'meta' and mode == 'phys':
					out.append((self._phys(m[1], lbn), ln))   # datos en la particion fisica
				else:
					out.append((self.addr(ref, lbn), ln))
			else:
				raise UdfError('UDF file with a hole')
			left -= ln
		return out

	def data(self, fe, mode=None):
		if fe['embedded'] is not None:
			return fe['embedded'][:fe['size']]
		return b''.join(self.read(p, ln) for p, ln in self.extents(fe, mode))

	# -- directorios ---------------------------------------------------------
	def root(self):
		lbn, ref = self.fsd
		d = self.read(self.addr(ref, lbn), SECTOR)
		if self._tag(d) != 256:
			raise UdfError('UDF file set descriptor not found')
		return _u16(d, 408), _u32(d, 404)              # (particion, lbn) del directorio raiz

	def listdir(self, ref, lbn):
		fe = self.fe(ref, lbn)
		d = self.data(fe, 'meta')
		out, pos, n = [], 0, 0
		while pos + 38 <= len(d) and n < MAX_FIDS:
			if _u16(d, pos) != 257:
				break
			fchar, lfi = d[pos + 18], d[pos + 19]
			icb_lbn, icb_ref = _u32(d, pos + 24), _u16(d, pos + 28)
			liu = _u16(d, pos + 36)
			raw = d[pos + 38 + liu:pos + 38 + liu + lfi]
			pos += (38 + liu + lfi + 3) & ~3
			n += 1
			if fchar & 0x08 or not raw:                   # carpeta de arriba
				continue
			if raw[0] == 16:
				name = raw[1:].decode('utf-16-be', 'replace')
			else:
				name = raw[1:].decode('latin-1', 'replace')
			out.append((name, bool(fchar & 0x02), icb_ref, icb_lbn))
		return out


def blu_ray_files(read):
	"""[(ruta, tamano, [(posicion, bytes)...])] de BDMV/PLAYLIST y BDMV/STREAM
	de una ISO UDF. Prueba las dos lecturas de los short_ad de la particion de
	metadatos (UDF 2.50) y se queda con la que da listas MPLS de verdad."""
	u = Udf(read)
	ref, lbn = u.root()
	found = []

	def walk(ref, lbn, path, depth):
		for name, isdir, r2, l2 in u.listdir(ref, lbn):
			low = name.lower()
			if isdir:
				if depth < 3 and low in WALK:
					walk(r2, l2, path + name + '/', depth + 1)
			elif path.lower().endswith(('bdmv/playlist/', 'bdmv/stream/')):
				found.append((path + name, u.fe(r2, l2)))
	walk(ref, lbn, '', 0)
	if not found:
		return []
	modes = ['phys', 'meta'] if any(m[0] == 'meta' for m in u.maps) else ['phys']
	probe = [fe for p, fe in found if p.lower().endswith('.mpls') and fe['size'] >= 8][:3]
	for mode in modes:
		try:
			if probe and not all(u.data(fe, mode)[:4] == b'MPLS' for fe in probe):
				continue
			u.short_mode = mode
			return [(p, fe['size'], u.extents(fe, mode)) for p, fe in found]
		except UdfError:
			continue
	raise UdfError('UDF: playlists not readable')
