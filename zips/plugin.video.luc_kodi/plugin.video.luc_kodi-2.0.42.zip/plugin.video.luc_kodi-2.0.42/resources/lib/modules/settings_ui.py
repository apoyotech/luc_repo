# -*- coding: utf-8 -*-
"""
	luc_kodi Add-on
	settings_ui.py (v2.0.38) - opens luc_kodi's Settings.

	Always luc_kodi's own window (windows/settings_hub.py), the same in every
	skin. Kodi opens its own dialog for the add-on's Configure / Settings without
	asking the plugin; the service (service_loop) closes it as soon as it opens
	and opens this window instead. If that ever misses, the dialog only holds a
	button that opens this window: every setting is hidden there (settings.xml).
	Kodi's dialog stays only as the fallback when the window cannot open.
"""

from resources.lib.modules import control

PROP_OPEN = 'luc_kodi.settings.open'
PROP_NATIVE = 'luc_kodi.settings.native'  # Kodi's dialog opened on purpose (fallback): leave it



def open_classic(cat=0):
	# Kodi's dialog only holds the launcher category: there is no section to focus
	import time
	control.homeWindow.setProperty(PROP_NATIVE, str(time.time()))
	return control.execute('Addon.OpenSettings(%s)' % control.addonId())


def open_window(cat=0, focus=''):
	"""Blocks until the window is closed; then runs what it was closed for."""
	if control.homeWindow.getProperty(PROP_OPEN) == 'true': return True  # already open underneath
	try:
		from resources.lib.windows.settings_hub import SettingsHubXML
		control.hide()
		window = SettingsHubXML('settings_hub.xml', control.addonPath(control.addonId()), cat=cat, focus=focus)
		after = window.run()
		del window
	except Exception:
		from resources.lib.modules import log_utils
		log_utils.error()
		control.homeWindow.clearProperty(PROP_OPEN)
		return False
	if after:
		control.sleep(80)
		control.execute(after)
	return True


def open_settings(cat=0, focus=''):
	if open_window(cat, focus): return
	open_classic(cat)


def service_loop():
	"""Kodi's dialog for luc_kodi (context menu > Settings, Configure) -> our window.
	Kodi marks its add-on settings dialog with the add-on's id (window property
	Addon.ID); only that one is replaced, other add-ons keep Kodi's dialog. One
	cheap check every 0.2 s, nothing else while the dialog is not open."""
	import time
	monitor = control.monitor
	aid = control.addonId()
	home = control.homeWindow
	seen_native = False
	while not monitor.waitForAbort(0.2):
		try:
			if not control.condVisibility('Window.IsActive(addonsettings)'):
				native = home.getProperty(PROP_NATIVE)
				if native:
					try: stale = time.time() - float(native) > 10
					except Exception: stale = True
					if seen_native or stale:
						home.clearProperty(PROP_NATIVE)
						seen_native = False
				continue
			if control.infoLabel('Window(addonsettings).Property(Addon.ID)') != aid: continue
			if home.getProperty(PROP_NATIVE):
				seen_native = True
				continue
			control.execute('Dialog.Close(addonsettings,true)')
			control.execute('RunPlugin(plugin://%s/?action=tools_openSettings)' % aid)
			for _ in range(20):  # until Kodi has really closed it (no second launch)
				if monitor.waitForAbort(0.1) or not control.condVisibility('Window.IsActive(addonsettings)'): break
		except Exception:
			from resources.lib.modules import log_utils
			log_utils.error()
			if monitor.waitForAbort(5): break
