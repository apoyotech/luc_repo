# -*- coding: utf-8 -*-
"""
	luc_kodi -- Usenet: Blu-ray entero dentro de un 7z o un RAR (v2.0.37)

	En un disco Blu-ray la pelicula no es un fichero: va cortada en trozos
	BDMV/STREAM/xxxxx.m2ts y cada version (cine, extendida...) es una lista de
	reproduccion BDMV/PLAYLIST/xxxxx.mpls que dice que trozos van seguidos.
	Hasta ahora se servia el .m2ts mayor, que es solo una parte (kodi.log y NZB
	del 18-nov-2026: Avatar Collector's Edition, 3 versiones en el disco).

	Aqui se leen las listas, se elige la mas larga (a igual duracion, la de mas
	bytes: el disco UHD antes que el Blu-ray normal) y se devuelven sus trozos
	en orden; el motor los sirve seguidos como un solo video.
"""

import re
import struct

MIN_MAIN_SECS = 20 * 60          # una lista mas corta no es la pelicula
MAX_PLAYLISTS = 600              # discos con cientos de listas de relleno
MAX_MPLS_BYTES = 512 * 1024
_RE_MPLS = re.compile(r'(?i)^(?:(.*)/)?BDMV/PLAYLIST/(\d{5})\.mpls$')
_RE_M2TS = re.compile(r'(?i)^(?:(.*)/)?BDMV/STREAM/(\d{5})\.m2ts$')


class DiscError(ValueError):
	pass


def parse_mpls(data):
	"""-> [(clip, in_45k, out_45k), ...] de la ruta principal de la lista.
	ValueError si no es un MPLS."""
	if len(data) < 20 or data[:4] != b'MPLS':
		raise DiscError('not a Blu-ray playlist')
	pl = struct.unpack_from('>L', data, 8)[0]
	if pl + 10 > len(data):
		raise DiscError('playlist truncated')
	n_items = struct.unpack_from('>H', data, pl + 6)[0]
	pos = pl + 10
	out = []
	for _ in range(n_items):
		if pos + 2 > len(data):
			raise DiscError('playlist truncated')
		ln = struct.unpack_from('>H', data, pos)[0]
		item = data[pos + 2:pos + 2 + ln]
		if len(item) < 20:
			raise DiscError('playlist item truncated')
		clip = item[0:5].decode('ascii', 'replace')
		t_in, t_out = struct.unpack_from('>LL', item, 12)
		out.append((clip, t_in, t_out))
		pos += 2 + ln
	return out


def _root(prefix):
	return (prefix or '').rstrip('/').lower()


def disc_layout(names):
	"""names: [(nombre, tamano, objeto)] -> ({raiz: {'mpls': {num: obj},
	'm2ts': {num: obj}}}) de los discos que trae el archivo."""
	discs = {}
	for name, size, obj in names:
		n = (name or '').replace('\\', '/')
		m = _RE_MPLS.match(n)
		if m:
			d = discs.setdefault(_root(m.group(1)), {'mpls': {}, 'm2ts': {}})
			d['mpls'][m.group(2)] = obj
			continue
		m = _RE_M2TS.match(n)
		if m:
			d = discs.setdefault(_root(m.group(1)), {'mpls': {}, 'm2ts': {}})
			d['m2ts'][m.group(2)] = obj
	return dict((k, v) for k, v in discs.items() if v['mpls'] and v['m2ts'])


def choose(names, read, size_of, runtime=None):
	"""Lista principal de los discos del archivo.

	names: [(nombre, tamano, objeto)] de todos los ficheros; read(obj) -> bytes
	del fichero (solo se llama con los .mpls); size_of(obj) -> bytes.
	runtime: duracion de la pelicula segun TMDb (segundos), si se sabe.
	-> {'playlist', 'root', 'clips': [obj...], 'secs', 'bytes', 'versions'} o
	None si no hay discos o ninguna lista llega a pelicula.

	kodi.log del 18-nov-2026 (Avatar de AsRequested): la lista mas larga del
	disco UHD era una de 271 min en 253 trozos, mas larga que cualquier
	version de la pelicula (162, 171 y 178 min): listas que juntan trozos de
	las tres versiones o repiten trozos (de relleno). Ahora no cuentan: ni
	las que repiten un trozo, ni, sabiendo la duracion de TMDb, las que pasan
	de ella en mas de un 35% (+10 min) o se quedan por debajo del 80%."""
	discs = disc_layout(names)
	if not discs:
		return None
	seen, cands, read_n = set(), [], 0
	for root in sorted(discs):
		d = discs[root]
		for num in sorted(d['mpls']):
			if read_n >= MAX_PLAYLISTS:
				break
			obj = d['mpls'][num]
			if size_of(obj) > MAX_MPLS_BYTES:
				continue
			read_n += 1
			try:
				items = parse_mpls(read(obj))
			except (DiscError, struct.error):
				continue
			if not items or any(c not in d['m2ts'] for c, _i, _o in items):
				continue
			secs = sum(max(0, o - i) for _c, i, o in items) / 45000.0
			if secs < MIN_MAIN_SECS:
				continue
			sig = (root, tuple(c for c, _i, _o in items))
			if sig in seen:
				continue      # la misma lista repetida (discos con listas de relleno)
			seen.add(sig)
			clips = [d['m2ts'][c] for c, _i, _o in items]
			cands.append({'playlist': num + '.mpls', 'root': root, 'clips': clips, 'secs': secs, 'deltas': deltas(items),
						  'bytes': sum(size_of(x) for x in clips), 'n': len(clips),
						  'repeats': len(items) - len(set(c for c, _i, _o in items))})
	if not cands:
		return None
	good = [c for c in cands if not c['repeats']] or cands
	if runtime and runtime > MIN_MAIN_SECS:
		fit = [c for c in good if runtime * 0.8 <= c['secs'] <= runtime * 1.35 + 600]
		if fit:
			good = fit
	cands = good
	# v2.0.37 (kodi.log del 19-nov-2026, Mockingjay Part 1 4K COMPLETE de
	# HDRINVASION): se elegia la mas larga, y la de 134 min (8 trozos, 14 GB)
	# era la version 1080p en H.264 del disco, no la pelicula en UHD (122 min,
	# 1 trozo, TMDb 123): entre las que caben en la duracion, la que mas pesa.
	# Las versiones de una misma pelicula (cine, extendida) comparten trozos, asi
	# que la extendida sigue ganando: pesa mas. A igual peso, la mas larga.
	cands.sort(key=lambda c: (c['bytes'], int(c['secs'] // 60)), reverse=True)
	best = dict(cands[0])
	best['versions'] = [(c['playlist'], c['root'], int(c['secs'] // 60), c['n'], c['bytes']) for c in cands[:6]]
	return best


# ------------------------------------------- marcas de tiempo seguidas ----
# v2.0.37 (kodi.log y capturas del 19-nov-2026, Gladiator EXTENDED de COASTER):
# cada .m2ts de la lista trae sus propias marcas de tiempo (empiezan cada uno
# en su IN de la lista), asi que servidos seguidos Kodi veia 6:49 de una
# pelicula de 170 min: la duracion sale de la primera y la ultima marca. Se
# corrigen al servir: a cada trozo se le suma lo que dura la lista hasta el
# (PTS/DTS de los PES y PCR, en 90 kHz y 27 MHz), y la pelicula sale seguida.
# Solo se tocan los paquetes que empiezan un PES o llevan PCR; el resto se
# localiza con operaciones de bytes en C (rebanadas de cada 192 bytes).

PKT = 192
_T40 = bytes(1 if b & 0x40 else 0 for b in range(256))     # TS: payload_unit_start
_T20 = bytes(1 if b & 0x20 else 0 for b in range(256))     # TS: adaptation field
_T10 = bytes(1 if b & 0x10 else 0 for b in range(256))     # AF: PCR
_WRAP = 1 << 33


def deltas(items):
	"""items de la lista [(clip, in, out)] (45 kHz) -> lo que hay que sumar a
	las marcas (90 kHz) de cada trozo para que la lista vaya seguida."""
	out, t = [], 0
	for _c, t_in, t_out in items:
		out.append(2 * (t - t_in + items[0][1]))
		t += max(0, t_out - t_in)
	return out


def _get_ts(b, i):
	return ((((b[i] >> 1) & 7) << 30) | (b[i + 1] << 22) | ((b[i + 2] >> 1) << 15) |
			(b[i + 3] << 7) | (b[i + 4] >> 1))


def _put_ts(b, i, v):
	v %= _WRAP
	b[i] = (b[i] & 0xF1) | ((v >> 29) & 0x0E)
	b[i + 1] = (v >> 22) & 0xFF
	b[i + 2] = (((v >> 14) & 0xFE) | 1)
	b[i + 3] = (v >> 7) & 0xFF
	b[i + 4] = (((v << 1) & 0xFE) | 1)


def fix_ts(buf, delta):
	"""Suma `delta` (90 kHz) a las marcas de tiempo de `buf` (bytearray de
	paquetes BDAV de 192 bytes, alineado). En su sitio."""
	if not delta or len(buf) < PKT:
		return buf
	n = len(buf) // PKT
	pusi = bytes(buf[5::PKT][:n]).translate(_T40)
	afc = bytes(buf[7::PKT][:n]).translate(_T20)
	pcrf = bytes(buf[9::PKT][:n]).translate(_T10)
	# un paquete interesa si empieza PES, o si lleva campo de adaptacion con PCR
	cand = int.from_bytes(pusi, 'big') | (int.from_bytes(afc, 'big') & int.from_bytes(pcrf, 'big'))
	if not cand:
		return buf
	mask = cand.to_bytes(n, 'big')
	k = mask.find(b'\x01')
	while k >= 0:
		p = k * PKT + 4                      # cabecera TS (tras los 4 bytes de llegada)
		if buf[p] == 0x47:
			flags = buf[p + 3]
			pay = p + 4
			if flags & 0x20:                 # campo de adaptacion
				afl = buf[p + 4]
				if afl and buf[p + 5] & 0x10 and afl >= 7:
					q = p + 6                # PCR: base de 33 bits + 6 reservados + 9 de extension
					base = (buf[q] << 25) | (buf[q + 1] << 17) | (buf[q + 2] << 9) | (buf[q + 3] << 1) | (buf[q + 4] >> 7)
					base = (base + delta) % _WRAP
					buf[q] = (base >> 25) & 0xFF
					buf[q + 1] = (base >> 17) & 0xFF
					buf[q + 2] = (base >> 9) & 0xFF
					buf[q + 3] = (base >> 1) & 0xFF
					buf[q + 4] = ((base & 1) << 7) | (buf[q + 4] & 0x7F)
				pay = p + 5 + afl
			if buf[p + 1] & 0x40 and flags & 0x10 and pay + 14 <= p + 188:
				if buf[pay] == 0 and buf[pay + 1] == 0 and buf[pay + 2] == 1 and buf[pay + 3] not in (0xBC, 0xBE, 0xBF, 0xF0, 0xF1, 0xF2, 0xF8, 0xFF):
					ptsdts = buf[pay + 7] >> 6
					if ptsdts & 2 and pay + 14 <= p + 188:
						_put_ts(buf, pay + 9, _get_ts(buf, pay + 9) + delta)
					if ptsdts == 3 and pay + 19 <= p + 188:
						_put_ts(buf, pay + 14, _get_ts(buf, pay + 14) + delta)
		k = mask.find(b'\x01', k + 1)
	return buf
