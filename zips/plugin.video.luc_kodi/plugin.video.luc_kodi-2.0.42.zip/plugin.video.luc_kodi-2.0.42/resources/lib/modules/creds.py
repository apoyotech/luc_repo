# -*- coding: utf-8 -*-
"""
	luc_kodi Add-on — creds.py (v2.0.40)

	"Is this account signed in?" for the menus, without loading the service
	modules. The answer only needs settings and window properties, but asking
	trakt.py, simkl.py, mdblist.py, punchplay.py or wetrakr.py brought in requests,
	urllib3, sqlite3 and the Trakt database on every menu click (about 300
	modules, since reuselanguageinvoker is off). This module imports control
	and nothing else.

	It is the only copy of these rules: trakt.py, simkl.py, mdblist.py,
	punchplay.py and wetrakr.py ask here, so the menus and the services can
	never disagree.
"""

from resources.lib.modules import control

getSetting = control.setting

# The token of a session just authorised lives first in a window property and
# only later in settings.xml (Kodi writes the file when it wants to).
PUNCHPLAY_TOKEN_PROP = 'luc_kodi.punchplay.tok'
WETRAKR_TOKEN_PROP = 'luc_kodi.wetrakr.tok'


def _prop(name):
	try:
		return control.homeWindow.getProperty(name) or ''
	except Exception:
		return ''


def _usable(token):
	return bool(token and token not in ('0', 'empty_setting'))


def trakt():
	username, token, refresh = getSetting('trakt.username').strip(), getSetting('trakt.token'), getSetting('trakt.refresh')
	if (username == '' or token == '' or refresh == ''): return False
	return True


def trakt_indicators():
	indicators = getSetting('indicators') if not trakt() else getSetting('indicators.alt')
	return True if indicators == '1' else False


def simkl():
	username = (getSetting('simkl.username') or '').strip()
	token = (getSetting('simkl.token') or '').strip()
	return bool(username and token)


def mdblist_token():
	"""access_token kept by the Device Flow (empty when not authorised)."""
	return (getSetting('mdblist.token') or '').strip()


def mdblist_oauth():
	return _usable(mdblist_token())


def mdblist():
	"""OAuth token or the user's API key. mdblist.DEFAULT_APIKEY is empty, so
	the plugin's own key never counts as an account; if it ever gets a value,
	mdblist.getMDBListCredentialsInfo() adds it on its side."""
	return mdblist_oauth() or bool((getSetting('mdblist.apikey') or '').strip())


def punchplay_token():
	return (_prop(PUNCHPLAY_TOKEN_PROP) or getSetting('punchplay.token') or '').strip()


def punchplay():
	return _usable(punchplay_token())


def wetrakr_token():
	return (_prop(WETRAKR_TOKEN_PROP) or getSetting('wetrakr.token') or '').strip()


def wetrakr():
	return _usable(wetrakr_token())
