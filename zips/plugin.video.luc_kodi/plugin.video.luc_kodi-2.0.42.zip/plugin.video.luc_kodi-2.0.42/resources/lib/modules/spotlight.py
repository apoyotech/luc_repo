# -*- coding: utf-8 -*-
"""
	luc_kodi Add-on
	Search luc_kodi (v2.0.09): the plugin's own search, opened from the context
	panel (or action=ctx_Search). It only looks INSIDE the plugin:

	  menus     the real navigator tree, built the same way the menus are, so it
	            follows what each user has switched on in Settings > Navigation
	            and which accounts are connected.
	  settings  every setting of settings.xml. On/off and list settings change
	            right there; the rest open Kodi's settings on their category and
	            the search comes back with the same words when they close.
	  actions   the buttons of the settings (authorize, clear cache, sync...) and
	            the menu entries that run something instead of opening a folder.

	Titles are not searched here: typing "search" leads to the plugin's Search
	menus, where movies, shows and people are searched as usual.
"""

import re
import unicodedata
from json import dumps as jsdumps, loads as jsloads
from resources.lib.modules import control

PROP_INDEX = 'luc_kodi.search.index'
INDEX_VERSION = '2'  # v2.0.38: index read from settings format version 1
SYSADDON = 'plugin://plugin.video.luc_kodi/'
SEP = '  »  '  # Latin-1 chevron
MAX_RESULTS = 60
MAX_RECENT = 10

# router action -> (Navigator method, kwargs). Only menus are walked; lists,
# searches and dialogs are indexed as entries but never opened while indexing.
NAV_MAP = {
	'movieNavigator': ('movies', {}), 'tvNavigator': ('tvshows', {}),
	'mymovieNavigator': ('mymovies', {}), 'mytvNavigator': ('mytvshows', {}),
	'movie_calendarNavigator': ('movie_calendar', {}), 'tv_calendarNavigator': ('tv_calendar', {}),
	'mdblist_movieNavigator': ('mdblist_movies', {}), 'mdblist_tvNavigator': ('mdblist_tv', {}),
	'punchplay_movieNavigator': ('punchplay_movies', {}), 'punchplay_tvNavigator': ('punchplay_tv', {}),
	'wetrakr_movieNavigator': ('wetrakr_movies', {}), 'wetrakr_tvNavigator': ('wetrakr_tv', {}),
	'anime_Navigator': ('anime', {}), 'tools_toolNavigator': ('tools', {}),
	'tools_traktToolsNavigator': ('traktTools', {}), 'tools_searchNavigator': ('search', {}),
	'tools_loggingNavigator': ('loggingNavigator', {}), 'library_Navigator': ('library', {}),
	'cache_Navigator': ('cf', {}), 'premiumNavigator': ('premium_services', {}),
	'ad_ServiceNavigator': ('alldebrid_service', {}), 'en_ServiceNavigator': ('easynews_service', {}),
	'pm_ServiceNavigator': ('premiumize_service', {}), 'rd_ServiceNavigator': ('realdebrid_service', {}),
	'tb_ServiceNavigator': ('torbox_service', {}), 'oc_ServiceNavigator': ('offcloud_service', {}),
}
SKIP_SETTING_ACTIONS = ('tools_ShowHelp',)  # the "-- Help --" buttons: noise in a search

LOGO_WORDS = (
	('trakt', 'trakt'), ('simkl', 'simkl'), ('mdblist', 'mdblist'), ('punchplay', 'punchplay'),
	('wetrakr', 'wetrakr'), ('real-debrid', 'realdebrid'), ('realdebrid', 'realdebrid'), ('real debrid', 'realdebrid'),
	('alldebrid', 'alldebrid'), ('all-debrid', 'alldebrid'), ('all debrid', 'alldebrid'), ('premiumize', 'premiumize'),
	('torbox', 'torbox'), ('offcloud', 'offcloud'), ('easynews', 'easynews'), ('youtube', 'youtube'), ('trailer', 'youtube'),
	('tmdb', 'tmdb'), ('themoviedb', 'tmdb'), ('tvdb', 'tvdb'),
)
# v2.0.09: languages are also found by their own name and by their Spanish name
LANGUAGE_ALIASES = {
	'ar': 'arabi arabe', 'zh': 'zhongwen chino mandarin', 'nl': 'nederlands neerlandes holandes', 'en': 'english ingles',
	'fi': 'suomi finlandes', 'fr': 'francais frances', 'de': 'deutsch aleman', 'hi': 'hindi', 'it': 'italiano',
	'ja': 'nihongo japones', 'ko': 'hangugeo coreano', 'no': 'norsk noruego', 'pl': 'polski polaco',
	'pt': 'portugues', 'ro': 'romana rumano', 'ru': 'russkiy ruso', 'es': 'espanol castellano spanish',
	'sv': 'svenska sueco', 'tr': 'turkce turco',
}
KIND_STYLE = {  # icon, colour
	'menu': ('folder', 'FF00FA9A'),
	'setting': ('gear', 'FFFDB515'),
	'action': ('bolt', 'FFFFAA44'),
}


# ───────────────────────── text helpers ─────────────────────────
def clean(text):
	try:
		from resources.lib.modules.context_hub import clean_label
		text = clean_label(text)
	except Exception: pass
	text = re.sub(r'\s+', ' ', str(text or '')).strip()
	return text.strip('-').strip() if text.startswith('--') else text


def norm(text):
	text = unicodedata.normalize('NFKD', str(text or '').lower())
	text = ''.join(c for c in text if not unicodedata.combining(c))
	return re.sub(r'[^a-z0-9]+', ' ', text).strip()


def logo_for(text):
	low = (text or '').lower()
	for word, logo in LOGO_WORDS:
		if word in low: return 'ctx/logo_%s.png' % logo
	return ''


def _label(value):
	if isinstance(value, int) or (isinstance(value, str) and value.isdigit()):
		return clean(control.lang(int(value)))
	return clean(value)


# ───────────────────────── index: menus ─────────────────────────
class _Skip(Exception):
	pass


def _menus():
	from resources.lib.menus import navigator
	out, seen = [], set()
	nav = navigator.Navigator()
	art = nav.artPath or ''

	def run(method, kwargs, crumb):
		captured = []
		def capture(name, query, poster, icon, context=None, queue=False, isAction=True, isFolder=True, isPlayable=False, isSearch=False, table=''):
			captured.append((name, query, poster, isAction, isFolder))
		def account_check():
			if not nav.traktCredentials: raise _Skip()
		nav.addDirectoryItem = capture
		nav.endDirectory = lambda *a, **k: None
		nav.accountCheck = account_check
		try: getattr(nav, method)(**kwargs)
		except (_Skip, SystemExit): return []
		except Exception:
			from resources.lib.modules import log_utils
			log_utils.error()
		return captured

	start = run('root', {}, [])
	pending = [(start, [])]
	while pending:
		items, crumb = pending.pop(0)
		for name, query, poster, is_action, is_folder in items:
			label = _label(name)
			if not label or label.startswith('Please visit'): continue
			if is_action:
				action = query.split('&', 1)[0]
				url = SYSADDON + '?action=' + query
			else:
				action, url = '', query
			if not url or url in seen: continue
			seen.add(url)
			kind = 'menu' if is_folder else 'action'
			icon = poster if (poster and '/' not in poster and art) else ''
			out.append({'k': kind, 'l': label, 'c': SEP.join(crumb) or 'luc_kodi', 'q': url, 'f': bool(is_folder),
						'g': logo_for(label + ' ' + poster), 'i': ('%s/%s' % (art.rstrip('/\\'), poster)) if icon else ''})
			spec = NAV_MAP.get(action)
			if spec and len(crumb) < 4:
				pending.append((run(spec[0], spec[1], crumb + [label]), crumb + [label]))
			elif action in ('movieLanguages', 'tvLanguages'):
				out.extend(_languages(action, crumb + [label], seen))
	return out


def _languages(action, crumb, seen):
	"""The languages of Movies/TV Shows > Languages (a static list), so typing
	"turkish" finds them."""
	from urllib.parse import quote_plus
	out = []
	try:
		if action == 'movieLanguages':
			from resources.lib.menus.movies import Movies as _List
		else:
			from resources.lib.menus.tvshows import TVshows as _List
		obj = _List()
		obj.addDirectory = lambda *a, **k: None
		for i in obj.languages() or []:
			url = '%s?action=%s&url=%s' % (SYSADDON, i['action'], quote_plus(i['url']))
			if url in seen: continue
			seen.add(url)
			# v2.0.09: the language's flag as its logo (ctx/flag_xx.png, a tile made from media/luc_kodi/flags)
			m = re.search(r'flags/([a-z]{2})\.png', i.get('icon') or '')
			flag = ('ctx/flag_%s.png' % m.group(1)) if m else ''
			out.append({'k': 'menu', 'l': clean(i.get('name')), 'c': SEP.join(crumb), 'q': url, 'f': True, 'g': flag, 'i': '',
						'a': LANGUAGE_ALIASES.get(m.group(1), '') if m else ''})
	except Exception:
		from resources.lib.modules import log_utils
		log_utils.error()
	return out


# ───────────────────────── index: settings ─────────────────────────
def _settings():
	"""v2.0.38: from settings_def (settings format version 1). Same entries as
	before: 't' keeps the classic kind (bool, enum, select, labelenum, text...),
	'o' the option labels and 'ov' the stored values of a list."""
	out = []
	try:
		from resources.lib.modules import settings_def
		cats = settings_def.categories()
		defs = settings_def.settings()
	except Exception:
		from resources.lib.modules import log_utils
		log_utils.error()
		return out
	for cat in cats:
		cat_label = _label(cat['label']) if cat['label'] else ''
		cat_index = cat['index']
		for grp in cat['groups']:
			# a group's name names the block below it; the long ones are explanations, not names
			section = _label(grp['label']) if grp['label'] else ''
			if len(section) > 24: section = ''
			for sid in grp['ids']:
				s = defs[sid]
				if s['visible'] is False: continue
				label = _label(s['label']) if s['label'] else ''
				if not label: continue
				stype = s['kind']
				crumb = SEP.join([p for p in (cat_label, section) if p])  # the gear tile already says "setting"
				logo = logo_for(label) or logo_for(section) or logo_for(cat_label)
				if stype == 'action':
					builtin = (s['action'] or '').strip()
					if not builtin or any(a in builtin for a in SKIP_SETTING_ACTIONS): continue
					out.append({'k': 'action', 'l': label, 'c': crumb, 'q': builtin, 'g': logo, 'cat': cat_index})
					continue
				entry = {'k': 'setting', 'l': label, 'c': crumb, 'q': sid, 't': stype, 'g': logo, 'cat': cat_index}
				if s['options']:
					entry['o'] = [_label(lab) if lab else clean(val) for lab, val in s['options']]
					entry['ov'] = [val for _, val in s['options']]
					# enum stores the index; select/labelenum with plain values store the text
					entry['vs'] = 'index' if s['by_index'] else 'value'
				out.append(entry)
	return out


def build_index(force=False):
	if not force:
		raw = control.homeWindow.getProperty(PROP_INDEX)
		if raw:
			try:
				data = jsloads(raw)
				if data.get('v') == INDEX_VERSION: return data.get('items') or []
			except Exception: pass
	items = []
	try: items += _menus()
	except Exception:
		from resources.lib.modules import log_utils
		log_utils.error()
	items += _settings()
	try: control.homeWindow.setProperty(PROP_INDEX, jsdumps({'v': INDEX_VERSION, 'items': items}, separators=(',', ':')))
	except Exception: pass
	return items


def clear_index():
	control.homeWindow.clearProperty(PROP_INDEX)


# ───────────────────────── matching ─────────────────────────
_KIND_ORDER = {'menu': 0, 'action': 1, 'setting': 2}


def _score(query_norm, tokens, entry):
	if entry.get('a'):  # other names of the same entry (languages)
		best = max(_score(query_norm, tokens, dict(entry, l=alias, a='')) for alias in entry['a'].split())
		return max(best, _score(query_norm, tokens, dict(entry, a='')))
	label = norm(entry.get('l'))
	crumb = norm(entry.get('c'))
	words = label.split()
	if not tokens: return 0
	if label == query_norm: return 100
	if label.startswith(query_norm): return 85
	in_label = [t for t in tokens if t in label]
	if len(in_label) == len(tokens):
		prefixed = all(any(w.startswith(t) for w in words) for t in tokens)
		return 70 if prefixed else 45
	initials = ''.join(w[0] for w in words if w)
	if len(query_norm) >= 2 and ' ' not in query_norm and initials.startswith(query_norm): return 55
	text = label + ' ' + crumb
	if all(t in text for t in tokens): return 20 if in_label else 12
	return 0


def search(query, items):
	qn = norm(query)
	tokens = qn.split()
	scored = []
	for e in items:
		s = _score(qn, tokens, e)
		if s: scored.append((-s, _KIND_ORDER.get(e.get('k'), 3), len(e.get('l') or ''), e))
	scored.sort(key=lambda x: x[:3])
	return [x[3] for x in scored[:MAX_RESULTS]]


def suggestions(items):
	"""Empty search: recent picks first, then the main menu."""
	recent = load_recent()
	by_key = dict((_key(e), e) for e in items)
	out = [by_key[k] for k in recent if k in by_key]
	out += [e for e in items if e.get('k') == 'menu' and e.get('c') == 'luc_kodi' and _key(e) not in recent]
	return out[:MAX_RESULTS]


# ───────────────────────── recents ─────────────────────────
def _key(entry):
	return '%s|%s' % (entry.get('k'), entry.get('q'))


def _recent_file():
	return control.joinPath(control.dataPath, 'search_recent.json')


def load_recent():
	try:
		with open(_recent_file(), 'r', encoding='utf-8') as f: return jsloads(f.read())[:MAX_RECENT]
	except Exception: return []


def add_recent(entry):
	try:
		keys = [k for k in load_recent() if k != _key(entry)]
		keys.insert(0, _key(entry))
		with open(_recent_file(), 'w', encoding='utf-8') as f: f.write(jsdumps(keys[:MAX_RECENT]))
	except Exception: pass


# ───────────────────────── settings values ─────────────────────────
def current_value(entry):
	"""Text shown on the right of a setting row. Text settings never show their
	value (they hold usernames, keys and tokens)."""
	t = entry.get('t')
	val = control.setting(entry.get('q'))
	if t == 'bool':
		return '[COLOR FF00D488]%s[/COLOR]' % control.lang(48143) if val == 'true' else '[COLOR FF7878A0]%s[/COLOR]' % control.lang(48144)
	opts = entry.get('o') or []
	if opts:
		if entry.get('vs') == 'value':
			vals = entry.get('ov') or []
			text = opts[vals.index(val)] if val in vals else val
		else:
			try: text = opts[int(val)]
			except Exception: text = ''
		text = clean(text)
		return '[COLOR FFFDB515]%s[/COLOR]' % ((text[:11] + '..') if len(text) > 12 else text) if text else ''
	return '»'


def is_inline(entry):
	return entry.get('k') == 'setting' and (entry.get('t') == 'bool' or bool(entry.get('o')))


def change_value(entry, step=1, pick=False):
	"""On/off flips; lists move one option (or open the list when pick)."""
	sid, t = entry.get('q'), entry.get('t')
	if t == 'bool':
		control.setSetting(sid, 'false' if control.setting(sid) == 'true' else 'true')
		return True
	opts = entry.get('o') or []
	if not opts: return False
	cur = control.setting(sid)
	vals = entry.get('ov') or opts
	try: idx = vals.index(cur) if entry.get('vs') == 'value' else int(cur or 0)
	except Exception: idx = 0
	if pick:
		sel = control.selectDialog(opts, heading=entry.get('l'))
		if sel < 0: return False
		idx = sel
	else:
		idx = (idx + step) % len(opts)
	control.setSetting(sid, vals[idx] if entry.get('vs') == 'value' else str(idx))
	return True


def wait_settings_closed(limit=1800):
	monitor = control.monitor
	waited = 0.0
	while waited < limit and not monitor.abortRequested():
		if not control.condVisibility('Window.IsActive(addonsettings)'): return
		monitor.waitForAbort(0.25)
		waited += 0.25


# ───────────────────────── run a result ─────────────────────────
def run_entry(entry):
	kind, q = entry.get('k'), entry.get('q') or ''
	add_recent(entry)
	if kind == 'menu':
		if control.condVisibility('Window.IsActive(10025)'): control.execute('Container.Update(%s)' % q)
		else: control.execute('ActivateWindow(Videos,%s,return)' % q)
	elif kind == 'action':
		if q.startswith(('RunPlugin(', 'PlayMedia(', 'Addon.', 'ActivateWindow(', 'RunScript(', 'Container.')): control.execute(q)
		else: control.execute('RunPlugin(%s)' % q)


def open_search(query=""):
	"""Router action ctx_Search and the panel's search button."""
	try:
		from resources.lib.windows.context_search import ContextSearchXML
		while True:
			control.busy()
			try: items = build_index()
			finally: control.hide()
			window = ContextSearchXML('context_search.xml', control.addonPath(control.addonId()), items=items, query=query)
			result = window.run()
			query = window.last_query
			del window
			if not result: return
			kind, entry = result
			if kind == 'settings':  # opens the settings on that setting, then back to the same search
				add_recent(entry)
				from resources.lib.modules import settings_ui  # v2.0.38: always luc_kodi's own window
				if not settings_ui.open_window(entry.get('cat', 0), entry.get('q') if entry.get('k') == 'setting' else ''):
					settings_ui.open_classic()
					wait_settings_closed()
				clear_index()
				continue
			control.sleep(80)
			run_entry(entry)
			return
	except Exception:
		from resources.lib.modules import log_utils
		log_utils.error()
