# -*- coding: utf-8 -*-
"""
	luc_kodi - motor de streaming Usenet (v2.0.24 test)

	Servidor HTTP local (127.0.0.1) que convierte un NZB en un fichero de
	video reproducible por Kodi SIN descargarlo entero y SIN debrid:

	  Kodi --GET Range--> 127.0.0.1:<puerto>/stream/<clave>/video.mkv
	        <-- bytes --- sesion: pide a Easynews (NNTP) solo los segmentos
	                      que cubren ese rango, los decodifica (yEnc) y los
	                      sirve en orden, con lectura anticipada.

	Vive en el SERVICIO de luc_kodi (service.py), no en la llamada del plugin:
	el plugin termina en cuanto entrega la URL a Kodi, y con
	reuseLanguageInvoker sus hilos no tienen una vida fiable. El servicio
	corre mientras Kodi este abierto. El puerto se publica en la propiedad de
	ventana 'luc_kodi.usenet.port' (Window 10000) para que el plugin lo lea.

	Rutas:
	  GET /ping                    -> 'luc_kodi-usenet'
	  GET /prepare/<clave>         -> JSON: abre la sesion, elige el video del
	                                  NZB, descarga el 1er segmento y comprueba
	                                  que se puede reproducir (MKV/MP4/AVI/TS).
	  GET|HEAD /stream/<clave>/<x> -> el video, con soporte de Range (seek).
	  GET /close/<clave>           -> cierra la sesion y sus conexiones.

	El NZB lo deja el plugin en <perfil>/usenet/nzb/<clave>.nzb (clave = md5
	del enlace del NZB, el mismo 'hash' que pone el scraper Newznab), asi que
	el apikey del indexer nunca viaja hasta aqui.

	Formatos: fichero directo (MKV/MP4/AVI/TS) y RAR 'store' (sin compresion,
	RAR4 y RAR5, en uno o cientos de volumenes, con nombres ofuscados o no).
	v2.0.28: tambien 7z 'store', en un volumen o partido (.7z.001...), como
	TMDb Movies.
	v2.0.36: del 7z se lee su cabecera final, asi que se sirve solo el fichero
	que toca: el episodio pedido de un pack de temporada (por los nombres que
	guarda el archivo), el video aunque lo primero guardado sea un .nfo, y con
	su tamano exacto. Un 7z partido con nombres ofuscados se ordena por el
	indice del asunto ('[03/45]') si todos lo traen.
	Limites (se dicen claro al plugin para que use el siguiente servicio
	activo, Premiumize o TorBox):
	  - 7z o RAR comprimidos, RAR cifrado, 7z partido ofuscado sin indice.
	  - un pack en UN solo juego RAR: solo se lee su primer fichero.
	  - sin reparacion PAR2: un articulo que falta se rellena con ceros
	    (un salto de imagen) y se anota en el log. Por eso la comprobacion
	    de salud del scraper descarta antes los NZB incompletos.
"""

import hashlib
import json
import os
import re
import socket
import struct
import threading
import time
from bisect import bisect_right
from collections import OrderedDict, deque
from heapq import heappush, heappop, heapify
from http.server import BaseHTTPRequestHandler, HTTPServer
from socketserver import ThreadingMixIn

from resources.lib.modules import usenet_core as core
from resources.lib.modules import usenet_rar
from resources.lib.modules import usenet_disc
from resources.lib.modules import usenet_udf
from resources.lib.modules import usenet_mkv
from resources.lib.modules import usenet_nested

PORT_PROPERTY = 'luc_kodi.usenet.port'
SEVEN_HEADER_MAX = 8 * 1024 * 1024    # v2.0.36: cabecera final de un 7z, como mucho
PORT_RANGE = range(47321, 47331)
KEY_RE = re.compile(r'^[0-9a-f]{32}$')

# Ventanas en BYTES, no en segmentos: hay posts con segmentos de 3,84 MB
# (log del 1-nov-2026, Hocus Pocus / Mayday) y con 16/48 segmentos fijos eran
# 61 MB por delante y 184 MB de RAM por sesion.
# v2.0.32 (auditoria del 11-nov-2026, L2/P1): la lectura anticipada se calcula
# por release, ~25 s de video. 12 MB fijos eran ~1,2 s de un remux a 80 Mbit/s.
# Sin la duracion a mano, se estima con una de 90 min: un remux de 60 GB da el
# tope de 96 MB; un 1080p de 12 GB, ~55 MB; un episodio de 2 GB, el minimo.
PREFETCH_MIN = 24 * 1024 * 1024
PREFETCH_MAX = 96 * 1024 * 1024
PREFETCH_SECS = 25
# v2.0.32: perfil del motor (ajuste newznab.en_profile). Cuanto video se lee
# por delante, con que tope de memoria y con cuantas conexiones se arranca;
# a partir de ahi se abren mas SOLO si la lectura se queda atras, hasta el
# maximo de conexiones del ajuste.
#            segundos   minimo MB  maximo MB  conexiones al arrancar
# Sin perfil "Powerful" (decision de Lucian, 12-nov-2026; informe E2): 224 MB
# por reproduccion, 448 con dos, no caben en una caja o TV de 1-2 GB con skin
# y addons. Balanced ya da de sobra: 25 s por delante y conexiones que crecen.
PROFILES = {0: (15, 16, 48, 4),        # Efficient: aparatos con poca RAM, datos medidos
			1: (25, 24, 96, 6)}        # Balanced (de fabrica)
ACCOUNT_CONNS = 60     # Easynews deja 60 conexiones a la vez por cuenta (todas las cuentas)
HEALTH_RESERVE = 8     # las que necesita la comprobacion de salud (usenet_easynews.HEALTH_CONNECTIONS)
GROW_EVERY = 0.25      # s entre dos conexiones nuevas al crecer
RETIRE_EVERY = 5.0     # s entre dos conexiones de mas que se cierran al sobrar
ASSUMED_RUNTIME = 5400
CACHE_EXTRA = 32 * 1024 * 1024      # la cache = lo anticipado + 32 MB ya leidos
# v2.0.37: al buscar un momento (saltar, reanudar) Kodi no lee de seguido: tantea
# 20-25 sitios del fichero leyendo unos KB en cada uno. Con articulos de 3,6 MB
# (Blu-ray en ISO o 7z) cada tanteo pedia ~95 MB por delante, la linea se llenaba
# de lo que nadie iba a leer, y lo tanteado se expulsaba y se volvia a bajar:
# kodi.log del 19-nov-2026, Avatar reanudado a los 32 min, 67 s buscando (6 s por
# tanteo). Ahora una lectura que empieza lejos pide solo PROBE_AHEAD por delante
# hasta que sigue de seguido, y lo ya leido es lo ultimo que sale de la cache.
# v2.0.37: 1,5 MB, no 4. En un salto Kodi lee poco en cada tanteo lejano; con 4 MB
# pedidos de golpe (6 articulos) la linea se reparte entre todos y el que hace
# falta llega a la vez que los demas: kodi.log del 20-nov-2026, The King's Speech
# con la linea a 33 Mbps, 13 s en seguir. Banco a 33 Mbps: el salto de 8,5 s a
# 6,8 s y el primer MB despues antes (0,76 s frente a 1,02); a 77 Mbps igual, y
# leer de seguido despues del salto va igual de rapido (lo limita la linea).
PROBE_AHEAD = 1536 * 1024           # por delante de una lectura recien saltada
# v2.0.37: 8 MB, no 2. En un disco (M2TS no tiene indice como el MKV) ffmpeg
# vuelve una y otra vez cerca del destino y Kodi lee ahi hasta 3,2 MB: con 2 MB
# cada relectura pasaba por 'viendo' y pedia los 95 MB por delante en plena
# busqueda (kodi.log del 20-nov-2026, The Hurt Locker: 18 s en seguir). Banco con
# la linea a 77 Mbps: la mitad de articulos y un 40 % menos de tiempo.
PROBE_SEQ = 8 * 1024 * 1024         # leido de seguido para dejar de ser un tanteo
PREFETCH_BYTES = PREFETCH_MIN       # (compat: informes antiguos)
CACHE_BYTES = PREFETCH_MIN + CACHE_EXTRA
SESSION_IDLE_SECS = 600     # una sesion sin lecturas se cierra a los 10 min
CONN_IDLE_SECS = 45         # una conexion NNTP ociosa se cierra (sin nadie viendo)
# v2.0.32 (L5/P2): con alguien viendo (pausa incluida) las conexiones no se
# cierran: cada 30 s sin uso se manda DATE para que el servidor no las corte, y
# al reanudar no hay que volver a hacer el TLS.
KEEPALIVE_SECS = 30
# v2.0.32 (informe N4): el final del fichero se fija por BYTES, no por
# segmentos: 2 segmentos eran ~1,5 MB, y el indice de un MKV grande (Cues)
# y lo que Kodi relee al saltar ocupan mas. TMDb Movies fija 8 MB.
PIN_TAIL_BYTES = 8 * 1024 * 1024
RUNTIME_MIN, RUNTIME_MAX = 600, 14400   # duracion real creible (10 min - 4 h)
# v2.0.32 (L1/P1): articulos pedidos en tuberia por conexion.
PIPELINE = 2
GET_TIMEOUT = 45            # espera maxima por un segmento
# v2.0.31: segundos que espera el reproductor por un segmento EN VUELO antes de
# pedirlo tambien por otra conexion. kodi.log del 11-nov-2026 (The Dog Stars):
# una conexion de Easynews se quedo callada y el segmento 4 no se reintento
# hasta que salto el timeout del socket a los 21,5 s; la imagen se congelo
# ~10 s y ffmpeg dio el fichero por terminado. Un segmento normal llega en
# 0,1-0,5 s (se registra a partir de 2 s), asi que 3 s ya es una conexion
# atascada. Gana la primera copia que llegue; la otra se descarta.
HEDGE_SECS = 3
HEDGE_TIMES = 3             # v2.0.37: o 3 veces lo que suele esperarse un articulo de este release,
HEDGE_MAX = 12              # si es mas (articulos grandes), y como mucho esto
VOID_BEHIND = 4 * 1024 * 1024   # un hueco a esta distancia de lo servido: esperar al Void (v2.0.37)
VOID_WAIT = 3.0                  # y como mucho esto
MKV_PREWARM = 6.0                # el indice del MKV se lee a los pocos segundos de empezar
TWIN_MAX = 3      # otros posts del release que se miran para tapar huecos (v2.0.37)
TWIN_TRIES = 4    # ficheros candidatos de cada uno que se comprueban
# v2.0.37: mientras Kodi tantea para reanudar se esta mirando la pantalla: un
# articulo atascado se pide tambien por otra conexion antes, a 4 veces lo que
# suele tardar uno de este release (minimo 1 s, maximo HEDGE_SECS). kodi.log del
# 19-nov-2026: Gladiator, articulos de 388 KB que solian tardar 0,3 s, siete
# atascados 3-4,5 s y 17 s para reanudar.
PROBE_HEDGE_MIN = 1.0
PROBE_HEDGE_TIMES = 4
MAX_SESSIONS = 2
SCAN_MAX_FILES = 250       # tope de ficheros para reparar el orden de un RAR ofuscado
MAX_CONSECUTIVE_MISSING = 12
# Release incompleto: si de lo ya pedido falta el 3% o mas (con al menos 40
# segmentos de muestra) se corta. Log del 1-nov-2026: un remux de Coco paso
# la comprobacion de salud (15 muestras) y faltaba ~6%: 35 huecos en 605
# segmentos, la imagen rota cada pocos segundos.
INCOMPLETE_MIN_SEGMENTS = 40
INCOMPLETE_RATIO = 0.03

CONTENT_TYPES = {'mkv': 'video/x-matroska', 'mp4': 'video/mp4', 'avi': 'video/x-msvideo',
				 'ts': 'video/mp2t', 'm2ts': 'video/mp2t'}
STREAMABLE = ('mkv', 'mp4', 'avi', 'ts', 'm2ts')


def _noop_log(msg, level=None):
	pass


# ---------------------------------------------- indice RAR junto al NZB ----
# v2.0.37: lo que costo leer (las cabeceras de todos los volumenes) se guarda
# en <clave>.nzb.rarix; se borra con el NZB (usenet_easynews.cleanup). Vale
# solo para los mismos volumenes (id del 1.er articulo) y la misma clave.
RARIX_VERSION = 1


def _rarix_id(vols, password):
	h = hashlib.sha256()
	for f in vols:
		h.update(((f.get('segments') or [(0, 0, '')])[0][2] or '').encode('utf-8', 'replace') + b'|')
	h.update(b'#' + (password or '').encode('utf-8', 'replace'))
	return h.hexdigest()


def _rarix_enc(o):
	if isinstance(o, bytes):
		return {'__b': o.hex()}
	if isinstance(o, dict):
		return dict((k, _rarix_enc(v)) for k, v in o.items())
	if isinstance(o, (list, tuple)):
		return [_rarix_enc(v) for v in o]
	return o


def _rarix_dec(o):
	if isinstance(o, dict):
		if len(o) == 1 and '__b' in o:
			return bytes.fromhex(o['__b'])
		return dict((k, _rarix_dec(v)) for k, v in o.items())
	if isinstance(o, list):
		return [_rarix_dec(v) for v in o]
	return o


def _rarix_save(path, vols, password, parsed):
	try:
		tmp = path + '.tmp'
		with open(tmp, 'w') as f:
			json.dump({'v': RARIX_VERSION, 'id': _rarix_id(vols, password), 'parsed': _rarix_enc(parsed)}, f,
					  separators=(',', ':'))
		os.replace(tmp, path)
	except Exception:
		pass


def _rarix_load(path, vols, password):
	try:
		with open(path) as f:
			d = json.load(f)
		if d.get('v') != RARIX_VERSION or d.get('id') != _rarix_id(vols, password):
			return None
		parsed = _rarix_dec(d['parsed'])
		return parsed if len(parsed) == len(vols) else None
	except Exception:
		return None


def _sevenix_save(path, vols, password, entries):
	try:
		tmp = path + '.tmp'
		with open(tmp, 'w') as f:
			json.dump({'v': RARIX_VERSION, 'id': _rarix_id(vols, password), 'entries': _rarix_enc(entries)}, f,
					  separators=(',', ':'))
		os.replace(tmp, path)
	except Exception:
		pass


def _sevenix_load(path, vols, password):
	try:
		with open(path) as f:
			d = json.load(f)
		if d.get('v') != RARIX_VERSION or d.get('id') != _rarix_id(vols, password):
			return None
		entries = _rarix_dec(d['entries'])
		return entries if isinstance(entries, list) and entries else None
	except Exception:
		return None



def _slice_pieces(pieces, a, b):
	"""v2.0.37: trozos [(volumen, desde, bytes)] que cubren [a, b) de su
	concatenacion."""
	out, pos = [], 0
	for vf, off, size in pieces:
		lo, hi = max(a, pos), min(b, pos + size)
		if lo < hi:
			out.append((vf, off + lo - pos, hi - lo))
		pos += size
		if pos >= b:
			break
	if sum(x[2] for x in out) != b - a:
		raise SessionError('ISO: a file lies outside the image (not streamable)')
	return out


class SessionError(Exception):
	pass


NEEDS_AES = 'password-protected release: install %s to play it' % core.AES_MODULE


def _chain(first, rest):
	for x in first: yield x
	for x in rest: yield x


def _decrypt_span(crypt, raw, raw_start):
	"""Descifra un tramo cifrado que empieza en raw_start (de la carpeta). Si no
	es el principio, su primer bloque es el iv y no sale en lo devuelto."""
	if raw_start:
		iv, raw = raw[:16], raw[16:]
	else:
		iv = crypt['iv']
	raw = raw[:len(raw) - len(raw) % 16]
	return crypt['new'](iv).decrypt(raw)


def _vint_len(n):
	k = 1
	while n >= 0x80:
		n >>= 7
		k += 1
	return k


class Session(object):
	def __init__(self, key, nzb_path, cfg, log=_noop_log, on_incomplete=None, on_close=None, runtime=None, ram=None, budget=None, want=None, warm_pool=None):
		self.key = key
		# v2.0.36: (temporada, episodio) pedido cuando el NZB es un pack: se elige
		# dentro del archivo por los nombres que guarda su cabecera
		self.want = want
		self.on_close = on_close
		# v2.0.32 (informe N3): duracion real del video (s), si la sabe el plugin
		try: rt = int(float(runtime or 0))
		except (TypeError, ValueError): rt = 0
		self.runtime = rt if RUNTIME_MIN <= rt <= RUNTIME_MAX else None
		self.ram = ram                       # v2.0.32 (N5): RAM de todas las sesiones a la vez
		# v2.0.32 (informe L7, B1): proveedores de respaldo, por orden, solo
		# para lo que falta; cada uno con su grupo de conexiones compartido
		bks = (cfg or {}).get('backups')
		if bks is None:
			bk = (cfg or {}).get('backup')
			bks = [bk] if bk else []
		self.backups = [BackupPool(b, log) for b in bks if b and b.get('host')]
		self.backup = bool(self.backups)
		self.backup_hits = 0
		# v2.0.37: el mismo release subido otra vez (otro post, otros articulos)
		self.twin_lock = threading.Lock()
		self.twins = None                    # [(url, host)] o [] (se lee al primer hueco)
		self.twin_files = None               # [lista de ficheros de cada NZB gemelo]
		self.twin_match = {}                 # id(fichero nuestro) -> fichero gemelo o None
		self.twin_conn = None
		self.twin_hits = 0
		# v2.0.37: huecos de un MKV tapados con EBML Void (usenet_mkv)
		self.voids = []                      # [{'start', 'end', 'hdr', 'skip'}]
		self.void_lock = threading.Lock()
		self.mkv_ix = None                   # (clusters de los Cues) o False si no vale
		self.rpos = {}                       # lector -> byte siguiente que va a servir
		self.void_hits = 0
		self.void_done = set()               # articulos que faltan ya mirados (tapados o no)
		self.void_pending = set()            # articulos en cola para el unico hilo de Void
		self.void_qlock = threading.Lock()
		self.void_worker = False
		self.mkv_why = None                  # por que no vale el indice (se dice en el primer hueco)
		# v2.0.32: conexiones que crecen solo si hace falta
		self.budget = budget
		self.profile = PROFILES.get(int((cfg or {}).get('profile', 1) or 0), PROFILES[1])
		self.max_workers = max(1, int((cfg or {}).get('connections') or 4))
		self.idle_workers = 0
		self.grow_stop = False
		self.last_grow = 0.0
		# v2.0.32 (informe E1, 2.a parte): ultima vez que llego trabajo sin ningun
		# hilo libre. Si en CONN_IDLE_SECS siempre sobro alguno, sobra una conexion.
		self.last_short = time.time()
		self.last_retire = 0.0
		self.retiring = 0
		self.too_many_logged = False
		self.nzb_path = nzb_path
		self.cfg = dict(cfg)
		self.log = log
		self.lock = threading.RLock()
		self.cond = threading.Condition(self.lock)
		self.cache = OrderedDict()           # idx -> bytes
		self.touched = set()                 # segmentos de la cache que algun lector ya leyo
		self.probing = set()                 # lectores que empezaron lejos (Kodi tanteando)
		self.fetch_avg = None                # lo que suele tardar un articulo (media movil, s)
		# v2.0.37: desde que una conexion toma un articulo hasta que llega (lo que
		# mira el umbral de 'atascado'), mediana de los ultimos
		self.wait_times = deque(maxlen=9)
		self.wait_med = None
		self.inflight = set()
		self.queued = {}                     # idx -> mejor prioridad encolada
		self.failed = {}                     # idx -> motivo (error duro)
		self.missing = set()                 # idx rellenados con ceros (430)
		self.consecutive_missing = 0
		self.incomplete = None               # % que falta, si se corta
		self.on_incomplete = on_incomplete
		self.heap = []
		self.seq = 0
		self.readers = {}                    # id lector -> segmento actual
		self.closed = False
		self.last_use = time.time()
		self.workers = []
		self.ready = False
		self.info = {}
		self.stats = {'bytes': 0, 'segments': 0, 'started': time.time()}
		# v2.0.25: medidas para el informe de uso (Tools > Usenet report)
		self.conns = []                      # toda conexion abierta, para sumar sus bytes
		self.cpu = 0.0                       # s de CPU decodificando yEnc
		self.cache_peak = 0                  # bytes en RAM, maximo
		self.buckets = {}                    # tramo de 5 s -> bytes recibidos
		self.stalls = 0                      # esperas de mas de 2 s viendo de seguido
		self.stall_secs = 0.0
		self.seeks = 0
		self.last_idx = None
		self.reads = {}                      # lector -> segmentos leidos de seguido
		self.started_at = {}                 # idx en vuelo -> cuando se pidio al servidor
		self.hedged = set()                  # idx con copia de respaldo esperando hilo libre
		self.hedge_tried = set()             # idx a los que ya se pidio respaldo (una vez)
		self.copies = {}                     # idx en vuelo -> conexiones pidiendolo ahora
		self.hedges = 0
		self.reconnects = 0
		self.retries = 0
		self.lag_max = 0.0                   # mayor retraso del reloj de Python (diagnostico)
		self.is_rar = False
		self.nseg = 0
		self.spare = []                      # v2.0.32: la conexion de prepare(), para un hilo
		self.pinned = set()                  # v2.0.32: principio y final, nunca se expulsan
		self.password = None                 # v2.0.37: <meta type="password"> del NZB
		self.crypt = None                    # v2.0.37: 7z cifrado: se descifra al servir
		self.ts_fix = None                   # v2.0.37: Blu-ray: marcas de tiempo seguidas
		self.warm_pool = warm_pool
		self._rx_base = {}
		self._rx_recycled = 0
		self.rollover_triggered = False

	def _fetch_first(self, conn, f):
		code, art = conn.body(f['segments'][0][2])
		if not art and code == core.NNTP_NO_ARTICLE and self.backup:
			code2, art = self._backup_body(f['segments'][0][2])
			if art:
				self.backup_hits += 1
				self.log('USENET: first article taken from a backup provider')
			else:
				code = code2 or code
		if not art:
			raise SessionError('first article not available (%s)' % code)
		return core.yenc_decode(art)

	# -- proveedores de respaldo (v2.0.32, informe L7 y B1) --------------------
	def _backup_body(self, msgid):
		"""(codigo, articulo o None) del primer proveedor de respaldo que lo tenga."""
		code = None
		for pool in self.backups:
			c, art = pool.body(msgid)
			if art:
				return c, art
			code = c or code
		return code, None

	@property
	def bk_conns(self):
		out = []
		for pool in self.backups:
			out.extend(pool.opened)
		return out

	def prepare(self):
		"""Abre el release: fichero directo (MKV/MP4/AVI/TS) o RAR 'store'
		(sin compresion) en uno o varios volumenes, con o sin nombres
		ofuscados. Lo que ve Kodi es el video de dentro.

		Modelo comun: una lista de volumenes, cada uno con sus segmentos y el
		trozo [data_off, data_off + data_size) que aporta al video. Un fichero
		directo es un unico 'volumen' con data_off 0. Los segmentos se numeran
		seguidos a traves de todos los volumenes (indice lineal), asi la cache,
		la lectura anticipada y el corte por incompleto no cambian.
		"""
		with open(self.nzb_path, 'rb') as f:
			raw = f.read()
		files = core.parse_nzb(raw)
		self.password = core.nzb_password(raw)   # v2.0.37: 7z cifrado, clave en el NZB
		self._par2_saved(files)                  # v2.0.42: nombres reales ya sacados del PAR2 otra vez
		try:
			info = self._prepare(files)
		except SessionError as e:
			# v2.0.42: un post ofuscado (nombres al azar) que no se pudo abrir: se le
			# devuelven sus nombres reales desde el indice PAR2 y se prueba otra vez
			if getattr(self, '_par2_done', False) or not self._par2_retry_worth(files, e):
				raise
			# v2.0.42 (kodi.log del 26-nov-2026, El Padrino II de ESiR): que conste por
			# que no se abrio con los nombres del post
			self.log('USENET: session %s: did not open with the posted names (%s): reading the PAR2 index' % (self.key[:8], e))
			if not self._par2_names(files):
				raise
			self.log('USENET: session %s: trying again with the names from the PAR2 index' % self.key[:8])
			info = self._prepare(files)
		self._find_subtitles(files, info)
		try:
			self.rtype = self._rtype_of(info)        # v2.0.42: tipo exacto, para la lista
			if isinstance(info, dict):
				info['rtype'] = self.rtype
		except Exception:
			pass
		return info

	def _rtype_of(self, info):
		"""v2.0.42: el tipo de release tal como lo abrio el motor (MKV, 7Z,
		7Z AES, RAR>ISO, 7Z>RAR>ISO, DISC...). Sustituye al que la comprobacion
		de salud dedujo de un solo articulo."""
		dl = (info.get('detail') or '').lower()
		label = str(info.get('inner') or '')
		nest = getattr(self, '_nested_in', None)
		if dl.startswith('loose blu-ray'):
			t = 'DISC'
		elif dl.startswith('iso in rar'):
			t = 'RAR>RAR>ISO' if nest == 'RAR' else 'RAR>ISO'
		elif dl.startswith('iso'):
			t = 'ISO'
		elif dl.startswith('7z') or dl.startswith('rar'):
			t = '7Z' if dl.startswith('7z') else 'RAR'
			if nest:
				t += '>RAR'
			if label.startswith('ISO - '):
				t += '>ISO'
			elif 'playlist' in dl:
				t += '>DISC'
			if ' aes' in dl:
				t += ' AES'
		else:
			t = core._TYPE_EXT.get(str(info.get('container') or '').lower(), str(info.get('container') or 'VIDEO').upper()[:5])
		if getattr(self, '_par2_used', False):
			t += ' PAR2'
		return t

	# -- subtitulos sueltos del NZB (v2.0.42) -----------------------------------
	def _find_subtitles(self, files, info):
		"""Los subtitulos de texto que el post trae sueltos (.srt, .ass, .ssa,
		.vtt), del episodio pedido si es un pack. Se ofrecen a Kodi como pistas
		para elegir; no se bajan hasta que se piden (como el motor de NuvioTV)."""
		subs = []
		for f in files:
			n = (f.get('name') or '').replace('\\', '/').rsplit('/', 1)[-1]
			if not n.lower().endswith(SUB_EXT) or not f.get('segments') or f.get('bytes', 0) > SUB_MAX_BYTES:
				continue
			if self.want and tuple(self.want) not in core.episode_pairs(n):
				continue
			subs.append(f)
			if len(subs) >= SUB_MAX:
				break
		self.subs, self._sub_cache = subs, {}
		if isinstance(info, dict):
			info['subs'] = [{'i': i, 'name': (f['name'].replace('\\', '/').rsplit('/', 1)[-1])} for i, f in enumerate(subs)]
		if subs:
			self.log('USENET: session %s: %d subtitle file(s) in the NZB offered to Kodi' % (self.key[:8], len(subs)))

	def subtitle(self, i):
		"""Bytes del subtitulo i (se bajan la primera vez)."""
		subs = getattr(self, 'subs', None) or []
		if not 0 <= i < len(subs):
			return None
		with self.lock:
			got = self._sub_cache.get(i)
		if got is not None:
			return got
		c = self._connect()
		try:
			parts = []
			for _n, _b, msgid in subs[i]['segments']:
				code, art = c.body(msgid)
				if not art and self.backup:
					code, art = self._backup_body(msgid)
				if not art:
					raise SessionError('subtitle article not available (%s)' % code)
				parts.append(core.yenc_decode(art))
		finally:
			self.spare.append(c)
		parts.sort(key=lambda d: d['begin'])
		data = b''.join(d['data'] for d in parts)
		with self.lock:
			self._sub_cache[i] = data
		return data

	def _prepare(self, files):
		media, kind = core.pick_media(files)
		if not media:
			raise SessionError('no video file in NZB')
		if kind == '7z':
			return self._prepare_7z(files, core.seven_volumes(files), kind)
		vol_files = core.rar_volumes(files) if kind == 'rar' else [media]
		if not vol_files:
			raise SessionError('no RAR volumes found in NZB')
		second = tail = None
		conn = self._connect()
		try:
			first = self._fetch_first(conn, vol_files[0])
			container, detail = core.sniff(first['data'])
			if container not in STREAMABLE and container != 'rar' and kind == 'obfuscated':
				# El mayor fichero puede ser justo un ajeno del tamano de un
				# volumen: se prueban los primeros candidatos en su orden.
				for alt in core.rar_candidates(files)[:3]:
					if alt is media:
						continue
					try:
						cand = self._fetch_first(conn, alt)
					except SessionError:
						continue
					c2, d2 = core.sniff(cand['data'])
					if c2 in ('rar', '7z') or c2 in STREAMABLE:
						media, first, container, detail = alt, cand, c2, d2
						vol_files = [alt]
						break
			if container == '7z' and kind == 'obfuscated':
				# v2.0.28: un 7z de un solo volumen con nombre ofuscado
				conn.close(); conn = None
				return self._prepare_7z(files, [media], kind, first=first)
			if container == '7z' and kind == 'rar':
				# v2.0.37 (kodi.log del 18-nov-2026, LOTR ROTK de FGT): un 7z partido
				# con los trozos renombrados a numeros (.001, .002 ...) se tomaba
				# por un RAR por el nombre. Lo que manda es lo que hay dentro; el
				# orden es el de los numeros.
				conn.close(); conn = None
				return self._prepare_7z(files, vol_files, '7z', first=first)
			if container == '7z':
				conn.close(); conn = None
				return self._prepare_7z(files, [media], 'obfuscated', first=first)
			if container == 'rar' and kind != 'rar':
				# ofuscado: el mayor fichero era un volumen; se ordenan todos
				vol_files = core.rar_volumes(files)
				if not vol_files:
					raise SessionError('RAR volumes not found (not streamable)')
				if vol_files[0] is not media:
					first = self._fetch_first(conn, vol_files[0])
			if container == 'rar':
				try:
					h1 = core.parse_rar(first['data'])
				except ValueError as e:
					raise SessionError('RAR: %s (not streamable)' % e)
				if h1['split_before']:
					# v2.0.32: el primer volumen "continua de otro". Antes se abandonaba
					# aqui (kodi.log del 11-nov-2026, Jimmy Fallon 2014 de CROOKS); la
					# reparacion por escaneo solo corria si fallaba un volumen
					# intermedio. Se mira el primer segmento de cada candidato y se
					# empieza por el que no continua de ninguno.
					cands = core.rar_volumes(files) if kind == 'rar' else core.rar_candidates(files)
					if len(cands) > SCAN_MAX_FILES:
						raise SessionError('RAR volumes out of order (not streamable)')
					try:
						vol_files = self._scan_rar(cands, h1['fmt'])
					except SessionError:
						raise SessionError('RAR first volume missing from the post (not streamable)')
					first = self._fetch_first(conn, vol_files[0])
					try:
						h1 = core.parse_rar(first['data'])
					except ValueError as e:
						raise SessionError('RAR: %s (not streamable)' % e)
					if h1['split_before']:
						raise SessionError('RAR first volume missing from the post (not streamable)')
					self.log('USENET: session %s: first RAR volume found by scanning %d files (%d volumes kept)'
							 % (self.key[:8], len(cands), len(vol_files)))
				# v2.0.37: RAR por dentro (usenet_rar): cifrado con la clave del NZB,
				# o con varios ficheros (disco BDMV, .nfo o muestra delante, pack de
				# temporada) cuando el primero no es el video que se quiere
				# v2.0.37 (kodi.log del 19-nov-2026, Saving Private Ryan COMPLETE.UHD.BLURAY
				# de COASTER): si lo primero del RAR es una imagen de disco (ISO), no se
				# leen las cabeceras de todos los volumenes para nada (110 s, y Kodi ya
				# habia dejado de esperar): se dice al momento
				_n1 = (h1.get('name') or '').replace('\\', '/')
				_b1 = _n1.rsplit('/', 1)[-1]
				iso_rar = (core.ext_of(_n1) == 'iso' or (not h1['encrypted'] and h1['store'] and core.sniff(
					first['data'][h1['data_off']:h1['data_off'] + 0x8006])[0] == 'iso'))
				if core.ext_of(_n1) in DISC_IMAGE_EXT and not iso_rar:
					raise SessionError('RAR holds a disc image (%s), not a playable video (not streamable)'
									   % (_b1 if len(_b1) <= 60 else '...' + _b1[-57:]))
				if iso_rar and (h1['encrypted'] or not h1['store']):
					iso_rar = False          # cifrado: lo lee _rar_inside (o lo dice comprimido)
				inside = bool(h1['encrypted'])
				if not inside and not h1['store'] and h1.get('unp_size', 0) < core.SMALL_LEAD \
						and core.ext_of(h1.get('name')) not in core._KIND_EXT['video']:
					inside = True      # .nfo o .txt comprimido delante; el video puede ir sin comprimir
				if not inside and h1['store'] and not iso_rar:
					if self.want and tuple(self.want) not in core.episode_pairs(h1.get('name')):
						inside = True
					else:
						_i0 = core.sniff(first['data'][h1['data_off']:h1['data_off'] + 4096])[0]
						inside = _i0 not in STREAMABLE and core.ext_of(h1.get('name')) not in core._KIND_EXT['music']
				if inside:
					try:
						res = self._rar_inside(vol_files, kind, first)
					except SessionError as e:
						if h1['encrypted'] or self.want or 'no video inside' not in str(e):
							raise
						res = None      # sin video dentro: se explica abajo que trae
					if res is not None:
						if conn is not None: self.spare.append(conn)
						conn = None
						return res
				if self.want and tuple(self.want) not in core.episode_pairs(h1.get('name')) and not iso_rar:
					# v2.0.36: un pack en un solo juego RAR. Solo se sabe leer el primer
					# fichero de dentro; si no es el episodio pedido, no se sirve otro.
					raise SessionError('season pack in one RAR set: S%02dE%02d is not its first file (not streamable)' % tuple(self.want))
				if h1['encrypted']:
					raise SessionError('encrypted RAR (not streamable)')
				if not h1['store']:
					raise SessionError('compressed RAR (not streamable)')
				inner, idetail = core.sniff(first['data'][h1['data_off']:h1['data_off'] + 4096])
				if inner not in STREAMABLE and not iso_rar:
					_h = first['data'][h1['data_off']:h1['data_off'] + 4]
					if _h[:4] == b'fLaC' or _h[:3] == b'ID3' or core.ext_of(h1.get('name')) in core._KIND_EXT['music']:
						# v2.0.37: musica dentro del RAR
						raise SessionError('this NZB holds music (%s): %s (not streamable)'
										   % ((h1.get('name') or '?')[:60], core.PLAYABLE))
					_n = (h1.get('name') or '').replace('\\', '/')
					if 'BDMV/' in _n.upper() or 'VIDEO_TS/' in _n.upper() or core.ext_of(_n) in ('bdmv', 'clpi', 'mpls', 'ifo', 'bup'):
						# v2.0.37 (kodi.log del 17-nov-2026, Shawshank UHD Blu-ray de TAG): un
						# disco entero (carpeta BDMV) dentro del RAR, no un video
						raise SessionError('RAR holds a whole %s disc (%s), not a playable video (not streamable)'
										   % ('DVD' if 'VIDEO_TS' in _n.upper() or core.ext_of(_n) in ('ifo', 'bup') else 'Blu-ray',
											  _n[:60]))
					_b = _n.rsplit('/', 1)[-1]
					_b = _b if len(_b) <= 60 else '...' + _b[-57:]   # se ve la extension
					if core.ext_of(_n) in DISC_IMAGE_EXT:
						# v2.0.37 (kodi.log del 17-nov-2026, Harry Potter UHD de d3g)
						raise SessionError('RAR holds a disc image (%s), not a playable video (not streamable)' % _b)
					raise SessionError('RAR holds %s (%s), not a playable video (not streamable)' % (inner.upper(), _b or '?'))
				def _layout(vol_files):
					second = tail = None
					n = len(vol_files) if h1['split_after'] else 1
					if n < 2 and h1['split_after']:
						raise SessionError('RAR volumes missing from NZB (not streamable)')
					offs, sizes = [h1['data_off']], [h1['data_size']]
					if h1['split_after']:
						second = self._fetch_first(conn, vol_files[1])
						try:
							h2 = core.parse_rar(second['data'])
						except ValueError as e:
							raise SessionError('RAR volume 2: %s (not streamable)' % e)
						if not h2['split_before']:
							raise SessionError('RAR volume order mismatch (not streamable)')
						mid = h2['data_size']
						if mid <= 0:
							raise SessionError('RAR volume layout mismatch (not streamable)')
						# RAR5 guarda el numero de volumen como vint en la cabecera
						# principal: a partir del volumen 129 ocupa 2 bytes, la
						# cabecera crece 1 byte y el volumen lleva 1 byte menos de
						# datos (el tamano de volumen es fijo). RAR4 no lo guarda ahi.
						def _grow(k):
							if h1['fmt'] != 5: return 0
							return _vint_len(k) - _vint_len(1)
						# Cuantos volumenes hacen falta sale de las cabeceras, no de
						# cuantos ficheros trae el NZB: log del 1-nov-2026, Miami
						# Bici, un fichero de mas (par2 ofuscado) se tomo por el
						# ultimo volumen.
						rem = h1['unp_size'] - h1['data_size']
						k = 1
						while rem > 0:
							d = mid - _grow(k)
							if rem <= d:
								sizes.append(rem)
							else:
								sizes.append(d)
							rem -= d
							k += 1
							if k > 20000:
								raise SessionError('RAR volume layout mismatch (not streamable)')
						n = len(sizes)
						if n > len(vol_files):
							# Log del 1-nov-2026, Miami Bici de PlayWEB: el volumen 33 de 60
							# esta sustituido por otro fichero en el propio post. Sin
							# reparacion PAR2 no hay forma de reproducirlo.
							_g = getattr(self, 'scan_gone', 0)
							if _g:
								raise SessionError('damaged post: %d RAR volume%s removed from the server, the first is volume %d of %d (not streamable)'
												   % (_g, '' if _g == 1 else 's', len(vol_files) + 1, n))
							raise SessionError('damaged post: RAR volume missing on the server (%d of %d), needs PAR2 repair (not streamable)' % (len(vol_files), n))
						offs += [h2['data_off'] + _grow(k) for k in range(1, n)]
						last = sizes[-1]
						if n == 2:
							if h2['split_after'] or h2['data_size'] != last:
								raise SessionError('RAR last volume mismatch (not streamable)')
						else:
							# El ultimo volumen no sigue el patron: su cabecera no lleva
							# 'continua en el siguiente' y su tamano de datos ocupa menos
							# (RAR5 lo guarda como vint). Se lee su cabecera de verdad.
							tail = self._fetch_first(conn, vol_files[n - 1])
							try:
								ht = core.parse_rar(tail['data'])
							except ValueError as e:
								raise SessionError('RAR last volume: %s (not streamable)' % e)
							if ht['split_after'] or ht['data_size'] != last:
								raise SessionError('RAR last volume mismatch (not streamable)')
							offs[n - 1] = ht['data_off']
					elif h1['data_size'] != h1['unp_size']:
						raise SessionError('RAR volume missing from NZB (not streamable)')
					vol_files = vol_files[:n]
					return vol_files, offs, sizes, second, tail, n
				try:
					vol_files, offs, sizes, second, tail, n = _layout(vol_files)
				except SessionError as e:
					# Un fichero ajeno colado entre los volumenes (log del
					# 1-nov-2026, Miami Bici de PlayWEB: el 33 de 70 era otro
					# fichero del mismo tamano) descuadra todo el orden. Si el
					# release es ofuscado y no muy grande, se mira el primer
					# segmento de cada candidato, se quitan los que no son
					# volumenes RAR y se vuelve a intentar una vez.
					# Tambien con nombres: log del 1-nov-2026, Miami Bici de
					# PlayWEB traia los volumenes nombrados y el ajeno entre ellos.
					cands = core.rar_volumes(files) if kind == 'rar' else core.rar_candidates(files)
					if 'not streamable' not in str(e) or len(cands) > SCAN_MAX_FILES:
						raise
					vol_files = self._scan_rar(cands, h1['fmt'])
					self.log('USENET: session %s: RAR order repaired by scanning %d files (%d volumes kept)'
							 % (self.key[:8], len(cands), len(vol_files)))
					vol_files, offs, sizes, second, tail, n = _layout(vol_files)
				if iso_rar:
					# v2.0.37 (kodi.log del 19-nov-2026, COMPLETE.UHD.BLURAY de COASTER): la
					# ISO del Blu-ray, sin comprimir dentro del RAR, se lee por dentro
					self.is_rar = True
					res = self._iso_serve(conn, kind, list(zip(vol_files, offs, sizes)), first, 'ISO in RAR%d' % h1['fmt'])
					self.spare.append(conn); conn = None
					return res
				total = h1['unp_size']
				detail = 'RAR%d store, %d vol, %s' % (h1['fmt'], n, idetail)
				container = inner
				self.is_rar = True
			elif container in STREAMABLE:
				if self.want and tuple(self.want) not in core.episode_pairs(media.get('name')):
					raise SessionError('season pack with hidden file names: S%02dE%02d cannot be picked (not streamable)' % tuple(self.want))
				if container == 'm2ts' and not self.want and len(files) > 1:
					# v2.0.42 (kodi.log del 26-nov-2026, Zootopia 2 UHD de TMT: 74 GB en el
					# indexer y se servian 4,64 GB): un Blu-ray publicado tal cual, sin
					# RAR ni 7z, con cada .m2ts y .mpls como fichero suelto del NZB. Se
					# servia el .m2ts mayor, un trozo de la pelicula. Ahora, como dentro
					# de un archivo, su lista de reproduccion y sus trozos seguidos.
					res = self._direct_disc(conn, files, media, first, kind, detail)
					if res is not None:
						self.spare.append(conn); conn = None
						return res
				total = first['size']
				offs, sizes = [0], [total]
				self.is_rar = False
			elif container == 'iso':
				# v2.0.37 (kodi.log del 19-nov-2026, Gladiator EXTENDED de COASTER): la
				# ISO de un Blu-ray se lee por dentro (UDF) y se sirve su pelicula
				res = self._iso_serve(conn, kind, [(vol_files[0], 0, first['size'])], first, 'ISO')
				self.spare.append(conn); conn = None
				return res
			else:
				raise SessionError('%s (%s) is not streamable yet' % (container.upper(), detail))
		except BaseException:
			if conn is not None: conn.close()
			raise
		# v2.0.32: la conexion de preparar se la queda el primer hilo de
		# descarga en vez de cerrarla y abrir otra (un TLS menos al arrancar).
		if conn is not None: self.spare.append(conn)
		return self._finish(media, kind, vol_files, offs, sizes, first, second, tail, total, container, detail)

	# -- nombres reales desde el PAR2 (v2.0.42) ------------------------------
	_PAR2_NO_RETRY = ('first article not available', 'password', 'compressed', 'encrypted', 'this NZB holds',
					  'install ', 'season pack', 'removed from', 'disc image', 'not a playable video')

	def _par2_retry_worth(self, files, e):
		text = str(e)
		if any(x in text for x in self._PAR2_NO_RETRY):
			return False
		return usenet_nested.par2_worth(files, core.classify)

	def _par2_saved(self, files):
		"""Los nombres que dio el PAR2 la vez anterior (guardados junto al NZB)."""
		if not self.nzb_path:
			return
		try:
			with open(self.nzb_path + '.par2names') as f:
				saved = json.load(f)
		except Exception:
			return
		n = 0
		for f in files:
			real = saved.get(f['segments'][0][2]) if f.get('segments') else None
			if real and f.get('name') != real:
				f['obf_name'] = f.get('name'); f['name'] = real; n += 1
		if n:
			self._par2_done = self._par2_used = True
			self.log('USENET: session %s: %d file names from the PAR2 index (saved)' % (self.key[:8], n))

	def _par2_names(self, files):
		"""Lee el indice PAR2 y el primer articulo de cada fichero, y les pone su
		nombre real por contenido (MD5 de los primeros 16 KB y tamano). -> cuantos."""
		self._par2_done = True
		par2 = [f for f in files if (f.get('name') or '').lower().endswith('.par2')]
		cands = [f for f in files if f not in par2 and f.get('segments')]
		if not par2 or not cands or len(cands) > usenet_nested.PAR2_MAX_FILES:
			return 0
		t0 = time.time()
		conn = self._connect()
		descs = []
		try:
			def whole(f):
				parts = []
				for _n, _b, msgid in f['segments']:
					code, art = conn.body(msgid)
					if not art and self.backup:
						code, art = self._backup_body(msgid)
					if not art:
						return None
					parts.append(core.yenc_decode(art))
				parts.sort(key=lambda d: d['begin'])
				return b''.join(d['data'] for d in parts)
			for f in sorted(par2, key=lambda f: f['bytes'])[:3]:
				if f['bytes'] > usenet_nested.PAR2_INDEX_MAX:
					break
				data = whole(f)
				descs = usenet_nested.parse_par2(data) if data else []
				if descs:
					break
		finally:
			self.spare.append(conn)
		if not descs:
			self.log('USENET: session %s: the PAR2 index could not be read' % self.key[:8])
			return 0
		heads = [None] * len(cands)
		todo = list(range(len(cands)))
		lock = threading.Lock()

		def work():
			c = self._connect()
			try:
				while True:
					with lock:
						if not todo:
							return
						i = todo.pop(0)
					f = cands[i]
					try:
						d = self._fetch_first(c, f)
						head = d['data']
						j = 1
						while len(head) < min(usenet_nested.HASH16K, d['size']) and j < len(f['segments']):
							code, art = c.body(f['segments'][j][2])
							if not art:
								break
							head += core.yenc_decode(art)['data']
							j += 1
						heads[i] = (f, d['size'], head)
					except Exception:
						pass
			finally:
				self.spare.append(c)
		ts = [threading.Thread(target=work, name='usenet-par2', daemon=True) for _ in range(min(8, len(cands)))]
		[t.start() for t in ts]
		[t.join(120) for t in ts]
		found = usenet_nested.match_names(descs, [h for h in heads if h])
		saved = {}
		for f, real in found:
			if f.get('name') != real:
				f['obf_name'] = f.get('name'); f['name'] = real
			saved[f['segments'][0][2]] = real
		self._par2_used = bool(found)
		self.log('USENET: session %s: PAR2 index: %d files described, %d of %d files named by content (%.1fs)'
				 % (self.key[:8], len(descs), len(found), len(cands), time.time() - t0))
		if saved and self.nzb_path:
			try:
				tmp = self.nzb_path + '.par2names.tmp'
				with open(tmp, 'w') as f:
					json.dump(saved, f)
				os.replace(tmp, self.nzb_path + '.par2names')
			except Exception:
				pass
		return len(found)

	def _prepare_7z(self, files, vol_files, kind, first=None):
		"""v2.0.28: 7z 'store'. Volumen 1: el contenido empieza en el byte 32;
		los siguientes son el mismo archivo cortado a trozos, sin cabecera."""
		if not vol_files:
			raise SessionError('no 7z volumes found in NZB')
		tail = None
		conn = self._connect()
		try:
			if first is None:
				first = self._fetch_first(conn, vol_files[0])
			try:
				h = core.parse_7z(first['data'])
			except ValueError as e:
				raise SessionError('7z: %s (not streamable)' % e)
			inner, idetail = core.sniff(first['data'][h['data_off']:h['data_off'] + 4096])
			# v2.0.37. MEASURED (NZB of The Odyssey 2160p SURCODE and Heart of the
			# Beast AMZN, kodi.log 17-nov-2026): the first piece of a split 7z can
			# be smaller than the rest (7-Zip '-v150m -v500m': 150 MB, then 500 MB
			# each). The size of piece 1 was taken for all of them, so 191 pieces
			# looked like 633 needed and every such release was refused as a
			# 'damaged post' (and hidden as dead). The size of the pieces is now
			# read from piece 2's own yEnc header; the middle ones must match it.
			s1 = first['size']
			second = None
			if h['archive'] <= s1:
				n, s2 = 1, s1
			else:
				if kind != '7z':
					# v2.0.36: partido y con nombres ofuscados. Solo el primer trozo lleva
					# cabecera; el orden de los demas se toma del indice del asunto
					# ('[03/45]'), y solo si todos lo traen seguido y sin huecos.
					vol_files = self._seven_hidden_order(files, vol_files[0])
				if len(vol_files) < 2:
					raise SessionError('damaged post: 7z volume missing on the server (1 of %d) (not streamable)'
									   % max(2, -(-h['archive'] // s1)))
				second = self._fetch_first(conn, vol_files[1])
				s2 = second['size']
				if s2 <= 0:
					raise SessionError('7z volume layout mismatch (not streamable)')
				n = 1 + max(1, -(-(h['archive'] - s1) // s2))
				if kind != '7z':
					vol_files = self._seven_hidden_order(files, vol_files[0], n)
			if n > len(vol_files):
				raise SessionError('damaged post: 7z volume missing on the server (%d of %d) (not streamable)' % (len(vol_files), n))
			if kind == '7z' and n < len(vol_files):
				# v2.0.37 (kodi.log del 18-nov-2026, Avatar de AsRequested): el NZB trae
				# mas trozos de los que cuadran con la cabecera y los tamanos de los
				# trozos 1 y 2. Se servia lo que no era; ahora se dice, con los numeros.
				self.log('USENET: session %s: 7z layout does not match the NZB: header says %d bytes, piece 1 %d bytes, '
						 'piece 2 %d bytes -> %d pieces, the NZB has %d'
						 % (self.key[:8], h['archive'], s1, s2, n, len(vol_files)))
				raise SessionError('7z pieces do not match the archive header (%d of %d) (not streamable)' % (n, len(vol_files)))
			vol_files = vol_files[:n]
			self.log('USENET: session %s: 7z of %.2f GB by its header, %d piece(s) of %d MB (piece 1: %d MB)'
					 % (self.key[:8], h['archive'] / 1073741824.0, n, s2 // 1048576, s1 // 1048576))
			# donde empieza cada trozo dentro del archivo (el ultimo, lo que quede)
			starts = [0] + [s1 + s2 * k for k in range(n - 1)]
			vsizes = [s1] + [s2] * (n - 2) + ([h['archive'] - starts[-1]] if n > 1 else [])
			if n == 1:
				vsizes = [s1]
			if n > 1 and s1 != s2:
				self.log('USENET: session %s: split 7z, piece 1 of %d MB and the rest of %d MB'
						 % (self.key[:8], s1 // 1048576, s2 // 1048576))
			part = first['end'] - first['begin']
			# v2.0.36: se lee la cabecera final del 7z (uno o dos articulos) y se
			# sirve solo el fichero elegido: el episodio pedido de un pack, el video
			# si lo primero guardado es un .nfo, y el tamano exacto del video (antes
			# se servian tambien los bytes de la cabecera comprimida que 7-Zip deja
			# detras de los datos). Si la cabecera no se entiende y lo del byte 32
			# ya es un video suelto, se sigue como antes.
			try:
				entry = self._seven_pick(conn, vol_files, starts, part, h)
			except SessionError as e:
				if str(e) == NEEDS_AES or str(e).startswith('this NZB holds'):
					raise
				if 'encrypted with a password' in str(e):
					raise SessionError('password-protected 7z without its password in the NZB (not streamable)')
				if self.want:
					raise
				if inner not in STREAMABLE:
					# sin cabecera legible no se sabe que hay dentro: lo del byte 32 no es
					# un video, asi que es un 7z comprimido (o guarda otra cosa)
					self.log('USENET: session %s: 7z header not readable (%s)' % (self.key[:8], e))
					raise SessionError('compressed 7z, or it holds %s and not a video (not streamable)' % inner.upper())
				self.log('USENET: session %s: 7z header not used (%s), playing from byte 32' % (self.key[:8], e))
				entry = None
			if entry is not None:
				# v2.0.37: un Blu-ray entero dentro: la lista de reproduccion mas larga
				# (todos sus .m2ts seguidos) en vez del .m2ts mayor
				clips, disc = [entry], None
				nested = None
				if usenet_nested.holds_rar_set(getattr(self, '_seven_entries', None) or []):
					# v2.0.42: un juego RAR dentro del 7z (SURCODE, GAZPROM)
					nested = self._seven_nested(conn, vol_files, starts, part, h)
					clips, disc, entry = nested
				elif not self.want:
					disc = self._seven_disc(conn, vol_files, starts, part, h)
					if disc:
						clips = disc['clips']
				if disc is None and nested is None and entry['stored'] and (core.ext_of(entry.get('name')) == 'iso' or core.sniff(
						self._seven_entry_read(conn, vol_files, starts, part, h, entry, 0, 0x8006))[0] == 'iso'):
					# v2.0.37: una ISO de Blu-ray dentro del 7z: se lee su UDF y se
					# sirven los trozos de la pelicula como si fueran ficheros del 7z
					_ec = {}
					disc = self._iso_disc(lambda a, n: self._seven_entry_read(conn, vol_files, starts, part, h, entry, a, n, _ec))
					clips = [dict(entry, offset=entry['offset'] + a, size=ln) for ext in disc['clips'] for a, ln in ext]
					disc['label'] = 'ISO - ' + disc['label']
					disc['n_clips'] = len(disc['clips'])   # v2.0.42: trozos de la pelicula, no tramos de la ISO
				spans, cl, vpos, rpos, keys = [], [], 0, 0, {}
				for e in clips:
					if not e['stored']:
						raise SessionError('compressed 7z (not streamable)')
					if e.get('encrypted'):
						# v2.0.37: store cifrado con AES-CBC. Se sirve el tramo cifrado que
						# cubre el video, alineado a bloques de 16 y con el bloque anterior
						# (es el iv del primero); al leer se descifra (iter_range).
						kk = repr(e['aes'])
						if kk not in keys:
							try:
								keys[kk] = core.aes_cipher(e['aes'], self.password)
							except core.NeedsAES:
								raise SessionError(NEEDS_AES)
							except ValueError as ex:
								raise SessionError('password-protected 7z: %s (not streamable)' % ex)
						new, fiv = keys[kk]
						f0 = e['offset'] - e['fstart']
						rend = -(-(f0 + e['size']) // 16) * 16
						if e.get('fpack'):
							rend = min(rend, e['fpack']) if len(clips) > 1 else e['fpack']
						rstart = max(0, (f0 // 16) * 16 - 16)
						cl.append({'new': new, 'iv': fiv, 'f0': f0, 'rstart': rstart, 'rend': rend,
								   'size': e['size'], 'vstart': vpos, 'roff': rpos})
						a0 = h['data_off'] + e['fstart'] + rstart
						a1 = h['data_off'] + e['fstart'] + rend
					else:
						a0 = h['data_off'] + e['offset']
						a1 = a0 + e['size']
					spans.append((a0, a1))
					vpos += e['size']; rpos += a1 - a0
				if cl and len(cl) != len(clips):
					raise SessionError('7z with encrypted and plain parts mixed (not streamable)')
				crypt = cl[0] if len(cl) == 1 else ({'clips': cl, 'size': vpos} if cl else None)
				ends = [starts[k] + vsizes[k] for k in range(n)]
				# v2.0.37 (kodi.log del 18-nov-2026, Avatar de AsRequested: '1 vol' para
				# 68 GB en 253 trozos y se sirvio otra cosa): lo que se va a servir tiene
				# que caer dentro del archivo segun su propia cabecera. Si no, se dice
				# con los numeros en vez de servir bytes que no son la pelicula.
				arch_end = ends[-1]
				bad = [(a0, a1) for a0, a1 in spans if a0 < 0 or a1 > arch_end or a1 <= a0]
				if bad:
					self.log('USENET: session %s: 7z layout check failed: archive %d bytes by its header, %d piece(s) '
							 'of %d / %d bytes (%d 7z files in the NZB), a file at %d-%d'
							 % (self.key[:8], h['archive'], n, s1, s2, len(core.seven_volumes(files)) or len(vol_files),
								bad[0][0], bad[0][1]))
					raise SessionError('7z: the files inside lie outside the archive pieces (%d of %d pieces read) (not streamable)'
									   % (n, len(core.seven_volumes(files)) or len(vol_files)))
				svols, offs, sizes = [], [], []
				for a0, a1 in spans:
					k0, k1 = bisect_right(starts, a0) - 1, bisect_right(starts, a1 - 1) - 1
					for k in range(k0, k1 + 1):
						svols.append(vol_files[k])
						offs.append(max(a0, starts[k]) - starts[k])
						sizes.append(min(a1, ends[k]) - max(a0, starts[k]))
				k0 = bisect_right(starts, spans[0][0]) - 1
				a0 = spans[0][0]
				if cl:
					c0 = cl[0]
					want_n = min(spans[0][1] - a0, ((c0['f0'] - c0['rstart'] + 4096) // 16 + 1) * 16)
					raw_head = self._seven_read(conn, vol_files, starts, part, a0, want_n)
					head = _decrypt_span(c0, raw_head, c0['rstart'])[c0['f0'] - c0['rstart'] - (16 if c0['rstart'] else 0):]
				else:
					head = self._seven_read(conn, vol_files, starts, part, a0, min(4096, spans[0][1] - a0))
				if k0:
					first = self._fetch_first(conn, svols[0])
				inner, idetail = core.sniff(head)
				if inner not in STREAMABLE:
					# v2.0.37: que se sepa que hay dentro (kodi.log del 17-nov-2026: un 7z
					# cifrado de 634 MB salio como 'UNKNOWN' sin mas)
					what = 'an archive inside the archive' if inner in ('rar', '7z') else inner.upper()
					raise SessionError('7z holds %s (%s, starts %s), not a playable video (not streamable)'
									   % (what, (entry.get('name') or '?').rsplit('/', 1)[-1][:80], head[:8].hex()))
				name = entry.get('name') or vol_files[0]['name']
				if disc:
					name = disc['label']
					detail = '7z store%s, %d vol, playlist %s: %d clips, %d min, %d MB, %s' % (
						' AES' if cl else '', len(set(id(v) for v in svols)), disc['playlist'], disc.get('n_clips', len(clips)),
						disc['secs'] // 60, vpos // 1048576, idetail)
				else:
					detail = '7z store%s, %d vol, file %d MB inside, %s' % (' AES' if cl else '', len(svols), entry['size'] // 1048576, idetail)
					self.log('USENET: session %s: 7z: playing %s from inside the archive' % (self.key[:8], name.rsplit('/', 1)[-1]))
				# el segundo trozo servido, si es el 2 del juego, ya esta leido
				_second = second if (second is not None and len(svols) > 1 and svols[0] is vol_files[0]
									 and svols[1] is vol_files[1]) else None
				if conn is not None:
					self.spare.append(conn)
					conn = None
				info = self._finish(dict(svols[0], name=name), kind, svols, offs, sizes, first, _second, None,
									rpos if cl else vpos, inner, detail)
				info['inner'] = name.rsplit('/', 1)[-1]   # v2.0.37: titulo de un NZB propio sin nombre
				if disc:
					self.ts_fix = disc.get('ts_fix')
				if crypt:
					# lo que ve Kodi es el video en claro, no el tramo cifrado
					self.crypt = crypt
					self.total = vpos
					info['size'] = vpos
					self.log('USENET: session %s: 7z encrypted with AES-256, decrypted while it plays (%s)'
							 % (self.key[:8], core.aes_module()[1]))
				return info
			offs = [h['data_off']] + [0] * (n - 1)
			rem, sizes = h['packed'], []
			for k in range(n):
				room = vsizes[k] - offs[k]
				sizes.append(min(rem, room))
				rem -= sizes[-1]
			if rem > 0:
				raise SessionError('7z volume layout mismatch (not streamable)')
			if n > 1:
				# los trozos de en medio miden lo mismo que el segundo (mismos
				# articulos en el NZB); el ultimo, lo que falta del archivo: se
				# comprueba con su propio yEnc
				if any(len(v['segments']) != len(vol_files[1]['segments']) for v in vol_files[1:n - 1]):
					raise SessionError('7z volumes of different sizes (not streamable)')
				tail = second if n == 2 else self._fetch_first(conn, vol_files[n - 1])
				if tail['size'] != vsizes[-1]:
					raise SessionError('7z last volume mismatch (not streamable)')
				# el ultimo trozo puede llevar solo la cabecera final del 7z
				while n > 1 and sizes[-1] == 0:
					n -= 1; sizes.pop(); offs.pop(); vol_files = vol_files[:n]; tail = None
			if conn is not None:
				self.spare.append(conn)
				conn = None
		finally:
			if conn is not None:
				conn.close()
		detail = '7z store, %d vol, %s' % (n, idetail)
		_second = second if (second is not None and len(vol_files) > 1 and second is not tail) else None
		return self._finish(vol_files[0], kind, vol_files, offs, sizes, first, _second, tail, h['packed'], inner, detail)

	def _seven_read(self, conn, vol_files, starts, part, pos, length, cache=None):
		"""v2.0.36: `length` bytes desde la posicion `pos` del juego de volumenes
		(contada desde el principio de vol_files[0]), pidiendo solo los
		articulos que los cubren. v2.0.37: `starts`, donde empieza cada trozo
		(el primero puede medir menos que los demas)."""
		out = bytearray() # v2.0.41: sin recopiar lo acumulado en cada articulo
		while length > 0:
			k = bisect_right(starts, pos) - 1
			inner = pos - starts[k]
			if k >= len(vol_files):
				raise SessionError('7z: read past the last volume')
			segs = vol_files[k]['segments']
			j = inner // part
			if j >= len(segs):
				raise SessionError('7z: read past the end of a volume')
			d = cache.get((k, j)) if cache is not None else None
			if d is None:
				code, art = conn.body(segs[j][2])
				if not art and self.backup:
					code, art = self._backup_body(segs[j][2])
				if not art:
					raise SessionError('7z header article not available (%s)' % code)
				d = core.yenc_decode(art)
				if cache is not None:
					cache[(k, j)] = d
					if len(cache) > 64: cache.pop(next(iter(cache)))
			chunk = d['data'][inner - d['begin']:]
			if not chunk:
				raise SessionError('7z: unexpected article layout')
			chunk = chunk[:length]
			out += chunk; pos += len(chunk); length -= len(chunk)
		return bytes(out)

	def _seven_pick(self, conn, vol_files, starts, part, h):
		"""v2.0.36: lee la cabecera final del 7z y elige el fichero a servir."""
		ixp = (self.nzb_path or '') + '.7zix'
		entries = _sevenix_load(ixp, vol_files, self.password) if self.nzb_path else None
		if entries is None:
			start = h['data_off'] + h['packed']
			size = h['archive'] - start
			if size <= 0 or size > SEVEN_HEADER_MAX:
				raise SessionError('7z header of %d bytes (not streamable)' % size)
			raw = self._seven_read(conn, vol_files, starts, part, start, size)
			def _read(pos, ln):
				if ln > SEVEN_HEADER_MAX:
					raise ValueError('7z packed header too big')
				return self._seven_read(conn, vol_files, starts, part, h['data_off'] + pos, ln)
			try:
				entries = core.seven_entries(raw, _read, self.password)
			except core.NeedsAES:
				# sin 'not streamable': no se recuerda como imposible, se podra en
				# cuanto se instale el modulo
				raise SessionError(NEEDS_AES)
			except ValueError as e:
				raise SessionError('7z: %s (not streamable)' % e)
			if self.nzb_path:
				_sevenix_save(ixp, vol_files, self.password, entries)
		# v2.0.37: lo que mas pesa dentro decide; musica, juegos o programas no
		# se toman por video
		kind, sample = core.content_kind([(x.get('name'), x.get('size')) for x in entries])
		if kind in core.NOT_VIDEO:
			raise SessionError('this NZB holds %s (%s): %s (not streamable)' % (kind, sample[:60], core.PLAYABLE))
		self._seven_entries = entries
		if usenet_nested.holds_rar_set(entries):
			# v2.0.42: lo que mas pesa son volumenes RAR: lo decide _seven_nested
			return max(entries, key=lambda x: x.get('size') or 0)
		s, e = self.want if self.want else (None, None)
		entry, why = core.pick_inner(entries, s, e)
		if not entry and not self.want:
			# v2.0.37: un Blu-ray de trozos pequenos (ninguno llega al minimo de un
			# video suelto): lo decide su lista de reproduccion (_seven_disc)
			m2ts = [x for x in entries if core.ext_of(x.get('name')) == 'm2ts']
			if m2ts and any(core.ext_of(x.get('name')) == 'mpls' for x in entries):
				entry = max(m2ts, key=lambda x: x['size'])
		if not entry:
			raise SessionError('%s (not streamable)' % why)
		return entry

	def _seven_nested(self, conn, vol_files, starts, part, h):
		"""v2.0.42: un juego RAR 'store' guardado dentro del 7z (kodi.log del
		26-nov-2026: Michael y Supergirl de SURCODE y GAZPROM). Cada volumen de
		dentro es un fichero del 7z; se leen sus cabeceras (usenet_nested) y se
		sirve el video de dentro, o su disco. -> (clips del 7z, disco o None,
		entrada con el nombre y el tamano de lo que se sirve)."""
		entries = getattr(self, '_seven_entries', None) or []
		vols = usenet_nested.rar_volumes(entries)
		self._nested_in = '7Z'
		if any(not v.get('stored') for v in vols):
			raise SessionError('compressed 7z holding RAR volumes (not streamable)')
		aes = core.aes_module()[0]
		lock = threading.Lock()
		state = {'main': conn}
		t0 = time.time()

		def open_reader():
			with lock:
				c = state.pop('main', None)
			own = c is None
			if own:
				c = self._connect()
			cache = {}

			def read_of(k):
				v = vols[k]
				return lambda off, ln: self._seven_entry_read(c, vol_files, starts, part, h, v, off, ln, cache)

			def close():
				if own:
					self.spare.append(c)
				else:
					with lock:
						state['main'] = c
			return read_of, close

		try:
			ents, how = usenet_nested.layout([v['size'] for v in vols], open_reader, self.password, aes,
											 workers=6, log=lambda m: self.log('USENET: session %s: %s' % (self.key[:8], m)))
		except usenet_rar.NeedsPassword:
			raise SessionError('password-protected RAR inside the 7z without its password in the NZB (not streamable)')
		except usenet_rar.WrongPassword:
			raise SessionError('wrong password for the RAR inside the 7z (not streamable)')
		except (usenet_rar.RarError, usenet_nested.NestedError) as e:
			raise SessionError('RAR inside the 7z: %s (not streamable)' % e)
		read_of, close = open_reader()
		try:
			def read_entry(e, start=0, ln=None):
				if ln is None:
					ln = e['unp'] - start
				return b''.join(read_of(v)(o, s) for v, o, s in usenet_nested.slice_pieces(e['pieces'], start, ln))

			def to_clips(pieces):
				return [dict(vols[v], offset=vols[v]['offset'] + o, size=s) for v, o, s in pieces]

			disc = None
			entry, why = usenet_rar.pick(ents, self.want, core.episode_pairs)
			if entry is None and not self.want:
				isos = [e for e in ents if core.ext_of(e['name']) == 'iso' and e['store'] and not e['enc']]
				if isos:
					iso_e = max(isos, key=lambda e: e['unp'])
					disc = self._iso_disc(lambda a, ln: read_entry(iso_e, a, ln))
					clips = [c for ext in disc['clips'] for a, ln in ext
							 for c in to_clips(usenet_nested.slice_pieces(iso_e['pieces'], a, ln))]
					disc['label'] = 'ISO - ' + disc['label']
					disc['n_clips'] = len(disc['clips'])   # v2.0.42: trozos de la pelicula, no tramos de la ISO
					entry = iso_e
			if entry is not None and disc is None and not self.want and any(e['name'].lower().endswith('.mpls') for e in ents):
				def read_list(e):
					if not e['store'] or e['enc'] or e.get('open'):
						raise usenet_disc.DiscError('playlist not readable')
					return read_entry(e)
				disc = self._disc_choose([(e['name'], e['unp'], e) for e in ents], read_list, lambda e: e['unp'])
				if disc:
					clips = [c for e in disc['clips'] for c in to_clips(e['pieces'])]
			if entry is None:
				kind2, sample = core.content_kind([(e['name'], e['unp']) for e in ents])
				if kind2 in core.NOT_VIDEO:
					raise SessionError('this NZB holds %s (%s): %s (not streamable)' % (kind2, sample[:60], core.PLAYABLE))
				raise SessionError('RAR inside the 7z: %s (not streamable)' % why)
			chosen = disc['clips'] if (disc and core.ext_of(entry['name']) != 'iso') else [entry]
			for e in chosen:
				if e.get('open'):
					raise SessionError('damaged post: RAR volumes inside the 7z missing for %s (not streamable)' % e['name'][-60:])
				if not e['store']:
					raise SessionError('compressed RAR inside the 7z (not streamable)')
				if e['enc']:
					raise SessionError('encrypted RAR inside the 7z (not streamable)')
			if disc is None:
				clips = to_clips(entry['pieces'])
		finally:
			close()
		size = sum(c['size'] for c in clips)
		self.log('USENET: session %s: the 7z holds a RAR%s set of %d volumes (headers %s): %s, %d MB (%.1fs)'
				 % (self.key[:8], '', len(vols), how, (disc['label'] if disc else entry['name'].rsplit('/', 1)[-1])[-70:],
					size // 1048576, time.time() - t0))
		return clips, disc, {'name': entry['name'], 'size': size, 'stored': False}

	def _seven_entry_read(self, conn, vol_files, starts, part, h, e, off, n, cache=None):
		"""v2.0.37: n bytes desde `off` de un fichero guardado (store) en el 7z,
		descifrados si el 7z va con clave."""
		n = max(0, min(n, e['size'] - off))
		if not n:
			return b''
		if not e.get('encrypted'):
			return self._seven_read(conn, vol_files, starts, part, h['data_off'] + e['offset'] + off, n, cache)
		new, fiv = core.aes_cipher(e['aes'], self.password)
		p = e['offset'] - e['fstart'] + off
		rstart = max(0, (p // 16) * 16 - 16)
		rend = -(-(p + n) // 16) * 16
		raw = self._seven_read(conn, vol_files, starts, part, h['data_off'] + e['fstart'] + rstart, rend - rstart, cache)
		plain = _decrypt_span({'new': new, 'iv': fiv}, raw, rstart)
		skip = p - rstart - (16 if rstart else 0)
		return plain[skip:skip + n]

	def _seven_disc(self, conn, vol_files, starts, part, h):
		"""v2.0.37: si el 7z trae un Blu-ray entero, la lista de reproduccion
		principal (usenet_disc) con sus entradas .m2ts en orden; None si no."""
		entries = getattr(self, '_seven_entries', None) or []
		if not any((e.get('name') or '').lower().endswith('.mpls') for e in entries):
			return None
		cache, keys = {}, {}

		def read(e):
			if not e['stored']:
				raise usenet_disc.DiscError('compressed playlist')
			if not e.get('encrypted'):
				return self._seven_read(conn, vol_files, starts, part, h['data_off'] + e['offset'], e['size'], cache)
			kk = repr(e['aes'])
			if kk not in keys:
				keys[kk] = core.aes_cipher(e['aes'], self.password)
			new, fiv = keys[kk]
			f0 = e['offset'] - e['fstart']
			rstart = max(0, (f0 // 16) * 16 - 16)
			rend = -(-(f0 + e['size']) // 16) * 16
			raw = self._seven_read(conn, vol_files, starts, part, h['data_off'] + e['fstart'] + rstart, rend - rstart, cache)
			plain = _decrypt_span({'new': new, 'iv': fiv}, raw, rstart)
			skip = f0 - rstart - (16 if rstart else 0)
			return plain[skip:skip + e['size']]
		return self._disc_choose([(e.get('name'), e['size'], e) for e in entries], read, lambda e: e['size'])

	def _iso_disc(self, read_iso):
		"""v2.0.37: la lista principal del Blu-ray de una ISO (UDF). Sus 'clips'
		son listas de extensiones [(posicion en la ISO, bytes)]."""
		try:
			if not usenet_udf.is_udf(read_iso):
				raise SessionError('ISO without UDF (an old CD/DVD image), not a playable video (not streamable)')
			files = usenet_udf.blu_ray_files(read_iso)
		except usenet_udf.UdfError as e:
			raise SessionError('ISO: %s (not streamable)' % e)
		except struct.error:
			raise SessionError('ISO: damaged UDF file system (not streamable)')
		if not files:
			raise SessionError('ISO without a Blu-ray inside (a DVD or a data disc), not a playable video (not streamable)')
		disc = self._disc_choose([(p, sz, ext) for p, sz, ext in files],
								 lambda ext: b''.join(read_iso(a, ln) for a, ln in ext),
								 lambda ext: sum(ln for _a, ln in ext))
		if not disc:
			# v2.0.42: sin listas de reproduccion legibles, el trozo mayor (como
			# hace el motor de NuvioTV); antes no se servia nada
			clips = [(p, sz, ext) for p, sz, ext in files if p.lower().endswith('.m2ts')]
			if not clips:
				raise SessionError('ISO: no Blu-ray playlist as long as the film (not streamable)')
			p, sz, ext = max(clips, key=lambda x: x[1])
			self.log('USENET: session %s: ISO without a usable playlist: playing its largest clip %s (%d MB)'
					 % (self.key[:8], p.rsplit('/', 1)[-1], sz // 1048576))
			disc = {'clips': [ext], 'playlist': p.rsplit('/', 1)[-1], 'secs': 0, 'label': p.rsplit('/', 1)[-1], 'ts_fix': None}
		return disc

	def _iso_serve(self, conn, kind, pieces, first, what):
		"""v2.0.37: ISO sin comprimir ni cifrar repartida en `pieces`
		[(volumen, desde, bytes)]: se lee su UDF, se elige la pelicula y se
		sirven sus .m2ts seguidos."""
		part = first['end'] - first['begin']
		starts, pos = [], 0
		for _vf, _o, sz in pieces:
			starts.append(pos); pos += sz
		iso_size = pos
		cache = {}

		def read_iso(off, n):
			out = bytearray()
			n = max(0, min(n, iso_size - off))
			while n > 0:
				k = bisect_right(starts, off) - 1
				vf, po, ps = pieces[k]
				fo = po + (off - starts[k])
				j = fo // part
				d = cache.get((id(vf), j))
				if d is None:
					if vf is pieces[0][0] and j == 0:
						d = first
					else:
						if j >= len(vf['segments']):
							raise SessionError('ISO: read past the end of a volume (not streamable)')
						code, art = conn.body(vf['segments'][j][2])
						if not art and self.backup:
							code, art = self._backup_body(vf['segments'][j][2])
						if not art:
							raise SessionError('ISO article not available (%s)' % code)
						d = core.yenc_decode(art)
					cache[(id(vf), j)] = d
					if len(cache) > 128: cache.pop(next(iter(cache)))
				take = min(n, starts[k] + ps - off, d['end'] - fo)
				chunk = d['data'][fo - d['begin']:fo - d['begin'] + take]
				if not chunk:
					raise SessionError('ISO: unexpected article layout (not streamable)')
				out += chunk; off += len(chunk); n -= len(chunk)
			return bytes(out)
		t0 = time.time()
		disc = self._iso_disc(read_iso)
		ranges = [r for ext in disc['clips'] for r in ext]
		svols, offs, sizes = [], [], []
		for a, ln in ranges:
			for vf, o, sz in _slice_pieces(pieces, a, a + ln):
				svols.append(vf); offs.append(o); sizes.append(sz)
		total = sum(ln for _a, ln in ranges)
		head = read_iso(ranges[0][0], min(4096, ranges[0][1]))
		inner, idetail = core.sniff(head)
		if inner not in STREAMABLE:
			raise SessionError('ISO: the film inside starts %s, not a playable video (not streamable)' % head[:8].hex())
		first0 = first if svols[0] is pieces[0][0] else self._fetch_first(conn, svols[0])
		detail = '%s, %d vol, playlist %s: %d clips, %d min, %d MB, %s' % (
			what, len(set(id(v) for v in svols)), disc['playlist'], len(disc['clips']), disc['secs'] // 60,
			total // 1048576, idetail)
		self.log('USENET: session %s: %s: Blu-ray read from inside the image (%.1fs)' % (self.key[:8], what, time.time() - t0))
		info = self._finish(dict(svols[0], name=disc['label']), kind, svols, offs, sizes, first0, None, None,
							total, inner, detail)
		self.verified = set(range(len(svols)))
		self.ts_fix = disc.get('ts_fix')
		info['inner'] = disc['label']
		return info

	def _direct_disc(self, conn, files, media, first, kind, idetail):
		"""v2.0.42: Blu-ray entero con sus ficheros sueltos en el NZB (sin archivo).
		-> info de la sesion sirviendo la lista principal, o None si el NZB no
		trae sus listas (.mpls) y trozos (.m2ts) con nombre: entonces se sigue
		con el .m2ts mayor, como antes, y el log dice que hay en el NZB."""
		names = []
		for f in files:
			n = (f.get('name') or '').replace('\\', '/')
			m = _RE_LOOSE_MPLS.search(n)
			if m:
				names.append(('BDMV/PLAYLIST/%s.mpls' % m.group(1), f['bytes'], f))
				continue
			m = _RE_LOOSE_M2TS.search(n)
			if m:
				names.append(('BDMV/STREAM/%s.m2ts' % m.group(1), f['bytes'], f))
		n_clips = sum(1 for x in names if x[0].endswith('.m2ts'))
		n_lists = len(names) - n_clips
		whole = sum(f['bytes'] for f in files)
		if (n_clips < 2 or not n_lists) and not getattr(self, '_par2_done', False) \
				and usenet_nested.par2_worth(files, core.classify) and self._par2_names(files):
			# v2.0.42: un disco con los nombres ofuscados: con los del PAR2 se monta
			return self._direct_disc(conn, files, media, first, kind, idetail)
		if n_clips < 2 or not n_lists:
			if media['bytes'] * 2 < whole:
				# lo que se va a servir es menos de la mitad del post: que se sepa por que
				sample = ', '.join((f.get('name') or '?')[-40:] for f in sorted(files, key=lambda f: -f['bytes'])[:4])
				self.log('USENET: session %s: the NZB holds %d files (%.2f GB); playing the largest (%.2f GB), '
						 'no Blu-ray playlist found by name (%d .m2ts, %d .mpls); largest: %s'
						 % (self.key[:8], len(files), whole / 1073741824.0, media['bytes'] / 1073741824.0,
							n_clips, n_lists, sample))
			return None

		def fetch_list(c, f):
			out = []
			for _n, _b, msgid in f['segments']:
				code, art = c.body(msgid)
				if not art and self.backup:
					code, art = self._backup_body(msgid)
				if not art:
					raise usenet_disc.DiscError('playlist article not available (%s)' % code)
				out.append(core.yenc_decode(art))
			out.sort(key=lambda d: d['begin'])
			return b''.join(d['data'] for d in out)

		# v2.0.42 (kodi.log del 26-nov-2026, Zootopia 2: 13,5 s eligiendo la lista):
		# las listas se leian una a una por una sola conexion. Se piden antes, a la
		# vez, por varias; elegir ya no espera a la red. Solo si no hay una
		# eleccion guardada de antes para este NZB.
		lists = [f for n, b, f in names if n.endswith('.mpls') and b <= usenet_disc.MAX_MPLS_BYTES * 2]
		got = {}
		if not (self.nzb_path and os.path.exists((self.nzb_path or '') + '.disc')) and len(lists) > 1:
			lists = lists[:usenet_disc.MAX_PLAYLISTS]
			queue, glock, conns = list(lists), threading.Lock(), [conn]

			def pull(c):
				while True:
					with glock:
						if not queue:
							return
						f = queue.pop()
					try:
						got[id(f)] = fetch_list(c, f)
					except Exception:
						pass         # se vuelve a pedir al elegir, y alli se ve el error

			t0 = time.time()
			try:
				for _k in range(min(5, len(lists) // 4)):
					try:
						conns.append(self._connect())
					except Exception:
						break
				ts = [threading.Thread(target=pull, args=(c,), daemon=True) for c in conns]
				[t.start() for t in ts]
				[t.join() for t in ts]
			finally:
				self.spare.extend(conns[1:])
			self.log('USENET: session %s: %d Blu-ray playlists read over %d connections (%.1fs)'
					 % (self.key[:8], len(got), len(conns), time.time() - t0))

		def read(f):
			data = got.get(id(f))
			return data if data is not None else fetch_list(conn, f)

		# para elegir basta el tamano del NZB (proporcional); el exacto se lee
		# despues, solo de los trozos de la lista elegida
		disc = self._disc_choose(names, read, lambda f: f['bytes'])
		if not disc:
			return None
		clips = disc['clips']
		t0 = time.time()
		heads = [None] * len(clips)
		heads[0] = first if clips[0] is media else None
		todo = [i for i in range(len(clips)) if heads[i] is None]
		errors = []
		lock = threading.Lock()

		def fetch(c):
			while True:
				with lock:
					if not todo or errors:
						return
					i = todo.pop(0)
				try:
					heads[i] = self._fetch_first(c, clips[i])
				except Exception as e:
					with lock:
						errors.append(e)
					return

		extra = []
		try:
			for _k in range(min(3, max(0, len(todo) - 1))):
				try:
					extra.append(self._connect())
				except Exception:
					break
			threads = [threading.Thread(target=fetch, args=(c,), daemon=True) for c in [conn] + extra]
			[t.start() for t in threads]
			[t.join() for t in threads]
		finally:
			self.spare.extend(extra)
		if errors:
			e = errors[0]
			raise e if isinstance(e, SessionError) else SessionError('Blu-ray clip not available (%s)' % e)
		for i, h in enumerate(heads):
			if h is None or h.get('begin') != 0:
				raise SessionError('Blu-ray clip %d: unexpected yEnc layout (not streamable)' % (i + 1))
		inner, idetail2 = core.sniff(heads[0]['data'][:4096])
		if inner not in STREAMABLE:
			raise SessionError('Blu-ray playlist starts %s, not a playable video (not streamable)' % heads[0]['data'][:8].hex())
		sizes = [h['size'] for h in heads]
		total = sum(sizes)
		# donde empieza cada trozo en lo servido, con los tamanos de verdad
		ts, pos = [], 0
		for sz, dl in zip(sizes, disc.get('deltas') or [0] * len(clips)):
			ts.append((pos, sz, int(dl or 0)))
			pos += sz
		detail = 'loose Blu-ray files, playlist %s: %d clips, %d min, %d MB, %s' % (
			disc['playlist'], disc.get('n_clips', len(clips)), disc['secs'] // 60, total // 1048576, idetail2)
		self.log('USENET: session %s: Blu-ray posted as loose files (%d files in the NZB): %d clips of %.2f GB read in %.1fs'
				 % (self.key[:8], len(files), len(clips), total / 1073741824.0, time.time() - t0))
		info = self._finish(dict(clips[0], name=disc['label']), kind, clips, [0] * len(clips), sizes, heads[0],
							None, None, total, inner, detail)
		self.verified = set(range(len(clips)))
		self.ts_fix = ts if any(x[2] for x in ts) else None
		info['inner'] = disc['label']
		return info

	def _disc_choose(self, names, read, size_of):
		"""Comun a 7z y RAR: elige la lista, la guarda junto al NZB y lo dice en
		el log. -> {'clips', 'playlist', 'secs', 'label'} o None."""
		t0 = time.time()
		ixp = (self.nzb_path or '') + '.disc'
		byname = dict((n, o) for n, _sz, o in names)
		saved = None
		if self.nzb_path:
			try:
				with open(ixp) as f:
					saved = json.load(f)
				if saved.get('v') != DISC_CHOICE_VERSION or any(c not in byname for c in saved.get('clips') or [None]):
					saved = None
			except Exception:
				saved = None
		if saved:
			best = dict(saved, clips=[byname[c] for c in saved['clips']])
		else:
			try:
				best = usenet_disc.choose(names, read, size_of, self.runtime)
			except SessionError:
				raise
			except Exception as e:
				self.log('USENET: session %s: Blu-ray playlists not readable (%s: %s); playing the largest clip'
						 % (self.key[:8], type(e).__name__, e))
				return None
			if not best:
				return None
			cname = dict((id(o), n) for n, _sz, o in names)
			root = best['root']
			best['label'] = '%s%s' % ((root.rsplit('/', 1)[-1] + ' - ') if root else '', best['playlist'])
			if self.nzb_path:
				try:
					tmp = ixp + '.tmp'
					with open(tmp, 'w') as f:
						json.dump({'v': DISC_CHOICE_VERSION, 'clips': [cname[id(o)] for o in best['clips']], 'playlist': best['playlist'],
								   'deltas': best.get('deltas'),
								   'secs': best['secs'], 'label': best['label'], 'versions': best['versions']}, f)
					os.replace(tmp, ixp)
				except Exception:
					pass
		best['secs'] = int(best['secs'])
		# v2.0.37: donde empieza cada trozo en lo servido y lo que hay que sumar a
		# sus marcas de tiempo para que la pelicula vaya seguida (usenet_disc.fix_ts)
		ts, pos = [], 0
		for o, dl in zip(best['clips'], best.get('deltas') or [0] * len(best['clips'])):
			sz = size_of(o)
			ts.append((pos, sz, int(dl or 0)))
			pos += sz
		best['ts_fix'] = ts if any(x[2] for x in ts) else None
		self.log('USENET: session %s: Blu-ray disc: playing playlist %s, %d min in %d clips%s (%.1fs)'
				 % (self.key[:8], best['label'], best['secs'] // 60, len(best['clips']),
					'' if saved is None else ', from the saved choice', time.time() - t0))
		others = (best.get('versions') or [])[1:]       # la primera es la elegida
		if others and saved is None:
			self.log('USENET: session %s: other versions on the disc: %s' % (self.key[:8], '; '.join(
				'%s%s %d min (%d clips)' % ((v[1].rsplit('/', 1)[-1] + '/') if v[1] else '', v[0], v[2], v[3]) for v in others[:5])))
		return best

	def _seven_hidden_order(self, files, head, n=None):
		"""v2.0.36: trozos de un 7z partido con nombres ofuscados, en orden.
		Hace falta el indice del asunto en todos, seguido y sin repetir; los
		trozos de en medio tienen que medir lo mismo que el segundo (v2.0.37: el
		primero puede ser menor). Sin n, los que siguen al primero, sin mas."""
		cands = [f for f in files if core.classify(f['name']) == 'obfuscated']
		idx = {}
		for f in cands:
			m = core._RE_SUBJ_IDX.search(f.get('subject') or '')
			if not m:
				raise SessionError('split 7z with hidden names and no file order (not streamable)')
			idx.setdefault(int(m.group(1)), f)
		if len(idx) != len(cands):
			raise SessionError('split 7z with hidden names and repeated file order (not streamable)')
		order = [idx[k] for k in sorted(idx)]
		if head not in order:
			raise SessionError('split 7z with hidden names (not streamable)')
		i = order.index(head)
		if n is None:
			return order[i:]
		vols = order[i:i + n]
		if len(vols) < n or any(len(v['segments']) != len(vols[1]['segments']) for v in vols[1:n - 1]):
			raise SessionError('split 7z with hidden names: pieces out of order (not streamable)')
		keys = sorted(idx)[i:i + n]
		if keys != list(range(keys[0], keys[0] + n)):
			raise SessionError('split 7z with hidden names: a piece is missing (not streamable)')
		self.log('USENET: session %s: split 7z with hidden names, %d pieces ordered by subject' % (self.key[:8], n))
		return vols

	def _finish(self, media, kind, vol_files, offs, sizes, first, second, tail, total, container, detail):
		part = first['end'] - first['begin']
		if first['begin'] != 0 or part <= 0 or total <= 0:
			raise SessionError('unexpected yEnc layout')
		expected = (first['size'] + part - 1) // part
		if expected != len(vol_files[0]['segments']):
			raise SessionError('irregular segments (%d in NZB, %d expected)' % (len(vol_files[0]['segments']), expected))
		for extra, vf in ((second, vol_files[1] if len(vol_files) > 1 else None), (tail, vol_files[-1])):
			if extra is not None and len(vf['segments']) > 1 and extra['end'] - extra['begin'] != part:
				raise SessionError('RAR volumes posted with different segment sizes')
		self.vols = vol_files
		self.offs, self.sizes = offs, sizes
		self.base, self.starts = [], []
		nseg = vstart = 0
		for v, sz in zip(vol_files, sizes):
			self.base.append(nseg)
			self.starts.append(vstart)
			nseg += len(v['segments'])
			vstart += sz
		self.nseg = nseg
		self.verified = set([0, 1] if second is not None else [0])
		if tail is not None:
			self.verified.add(len(vol_files) - 1)
		self.layout_error = None
		self.name = media['name']
		self.part = part
		runtime = self.runtime or ASSUMED_RUNTIME
		secs, pmin, pmax = self.profile[0], self.profile[1] * 1048576, self.profile[2] * 1048576
		ahead = min(pmax, max(pmin, total * secs // runtime))
		self.prefetch = max(4, ahead // part)
		self.cache_max = max(8, (ahead + CACHE_EXTRA) // part)
		self.total = total
		self.container = container
		# Kodi relee el principio y el indice del MKV (al final) al saltar: esos
		# segmentos se quedan en la cache toda la sesion (auditoria L6).
		last = self._lin_for(total - 1)
		tail_from = self._lin_for(max(0, total - PIN_TAIL_BYTES))
		self.pinned = set(i for i in [0, 1] + list(range(tail_from, last + 1)) if 0 <= i < nseg)
		with self.lock:
			self.cache[0] = first['data']
			if second is not None:
				self.cache[self.base[1]] = second['data']
			if tail is not None:
				self.cache[self.base[-1]] = tail['data']
		self.info = {'ok': True, 'size': total, 'container': container, 'detail': detail,
					 'name': self.name if not kind == 'obfuscated' else '',
					 'segments': nseg, 'part': part, 'kind': kind, 'volumes': len(vol_files)}
		self.ready = True
		t = threading.Thread(target=self._watchdog, name='usenet-watchdog')
		t.daemon = True
		t.start()
		self.peak_workers = 0
		self._start_workers()
		self.peak_workers = len(self.workers)
		# el final del fichero lo pide Kodi casi siempre (indices del MKV)
		self.request(self._lin_for(total - 1), 5)
		if container == 'mkv' and self.crypt is None and not getattr(self, 'ts_fix', None):
			threading.Thread(target=self._mkv_prewarm, name='usenet-mkv-index', daemon=True).start()
		self.log('USENET: session %s ready: %s %s, %.2f GB, %d segments of %d bytes; %d of up to %d connections; %d MB read ahead (%s), end %d MB kept%s'
				 % (self.key[:8], container, detail, total / 1073741824.0, self._articles(), part, len(self.workers), self.max_workers,
					self.prefetch * part // 1048576,
					'%d min long' % (self.runtime // 60) if self.runtime else 'length not known',
					(last - tail_from + 1) * part // 1048576,
					(', %d backup provider%s' % (len(self.backups), '' if len(self.backups) == 1 else 's')) if self.backup else ''))
		return self.info

	# -- RAR por dentro (v2.0.37) -------------------------------------------
	def _rar_nested(self, ents, heads, article, reader):
		"""v2.0.42: los volumenes RAR guardados dentro de un RAR. Se leen sus
		cabeceras (usenet_nested) y se devuelven los ficheros de dentro como
		entradas del RAR de fuera (sus trozos, en los volumenes de fuera), asi el
		resto (eleccion del video, ISO, disco) no cambia."""
		inner = usenet_nested.rar_volumes(ents, size=lambda e: e['unp'])
		self._nested_in = 'RAR'
		for e in inner:
			if not e['store'] or e['enc']:
				raise SessionError('RAR volumes inside a %s RAR (not streamable)' % ('compressed' if not e['store'] else 'encrypted'))
			if not usenet_rar.complete(e):
				raise SessionError('damaged post: RAR volumes missing for %s (not streamable)' % e['name'][-60:])
		t0 = time.time()

		def open_reader():
			c = self._connect()

			def read_of(k):
				def read(off, ln):
					out = bytearray()
					for pv, po, psz in usenet_nested.slice_pieces(inner[k]['pieces'], off, max(0, min(ln, inner[k]['unp'] - off))):
						if heads[pv] is None:
							heads[pv] = article(c, pv, 0)
						out += reader(c, pv)(po, psz)
					return bytes(out)
				return read
			return read_of, lambda: self.spare.append(c)

		try:
			found, how = usenet_nested.layout([e['unp'] for e in inner], open_reader, self.password, core.aes_module()[0],
											  workers=6, log=lambda m: self.log('USENET: session %s: %s' % (self.key[:8], m)))
		except usenet_rar.NeedsPassword:
			raise SessionError('password-protected RAR inside the RAR without its password in the NZB (not streamable)')
		except usenet_rar.WrongPassword:
			raise SessionError('wrong password for the RAR inside the RAR (not streamable)')
		except (usenet_rar.RarError, usenet_nested.NestedError) as e:
			raise SessionError('RAR inside the RAR: %s (not streamable)' % e)
		out = []
		for e in found:
			pieces = [p for k, o, sz in e['pieces'] for p in usenet_nested.slice_pieces(inner[k]['pieces'], o, sz)]
			out.append({'name': e['name'], 'unp': e['unp'], 'store': e['store'], 'enc': e['enc'],
						'pieces': pieces, 'open': e.get('open')})
		self.log('USENET: session %s: the RAR holds a RAR set of %d volumes (headers %s, %d files inside, %.1fs)'
				 % (self.key[:8], len(inner), how, len(out), time.time() - t0))
		return out

	def _rar_inside(self, vols, kind, first0):
		"""Recorre las cabeceras de todos los volumenes (8 conexiones a la vez),
		elige el video (el mayor, o el episodio pedido) y lo sirve; si va
		cifrado, se descifra al servirlo. Devuelve el info de _finish."""
		if not vols:
			raise SessionError('RAR volumes not found (not streamable)')
		aes = core.aes_module()[0]
		n = len(vols)
		heads = [None] * n
		heads[0] = first0
		parsed = [None] * n
		errors = []
		lock = threading.Lock()
		todo = list(range(n))
		arts = {(0, 0): first0}

		def article(c, v, j):
			k = (v, j)
			with lock:
				if k in arts:
					return arts[k]
			segs = vols[v]['segments']
			if j >= len(segs):
				raise SessionError('RAR: read past the end of a volume')
			code, art = c.body(segs[j][2])
			if not art and self.backup:
				code, art = self._backup_body(segs[j][2])
			if not art:
				raise SessionError('RAR header article not available (%s)' % code)
			d = core.yenc_decode(art)
			with lock:
				arts[k] = d
				# v2.0.37: 64 bastan (8 conexiones, cada una lee su volumen en orden); con 600 y
				# articulos de 3,8 MB el indice de un disco podia retener mas de 2 GB de RAM
				if len(arts) > 64: arts.pop(next(iter(arts)))
			return d

		def reader(c, v):
			part = heads[0]['end'] - heads[0]['begin']
			size = heads[v]['size']

			def read(off, ln):
				out = bytearray() # v2.0.41
				ln = max(0, min(ln, size - off))
				while ln > 0:
					d = article(c, v, off // part)
					chunk = d['data'][off - d['begin']:off - d['begin'] + ln]
					if not chunk:
						raise SessionError('RAR: unexpected article layout')
					out += chunk; off += len(chunk); ln -= len(chunk)
				return bytes(out)
			return read

		def work():
			c = None
			try:
				c = self._connect()
				while True:
					with lock:
						if not todo or errors: break
						v = todo.pop(0)
					try:
						if heads[v] is None:
							heads[v] = article(c, v, 0)
						parsed[v] = usenet_rar.parse_volume(reader(c, v), heads[v]['size'], self.password, aes)
					except usenet_rar.NeedsPassword as e:
						errors.append(SessionError('%s (not streamable)' % e))
					except usenet_rar.WrongPassword as e:
						errors.append(SessionError('%s (not streamable)' % e))
					except usenet_rar.RarError as e:
						if 'AES module missing' in str(e):
							errors.append(SessionError(NEEDS_AES))
						else:
							errors.append(SessionError('RAR volume %d: %s (not streamable)' % (v + 1, e)))
					except SessionError as e:
						errors.append(e)
					except (ValueError, IndexError, KeyError, struct.error) as e:
						errors.append(SessionError('RAR volume %d unreadable (%s) (not streamable)' % (v + 1, type(e).__name__)))
			except Exception as e:
				errors.append(SessionError('RAR: %s' % e))
			finally:
				if c:
					try: c.close()
					except Exception: pass
		t0 = time.time()
		# v2.0.37 (kodi.log del 18-nov-2026, Avatar Collector's: 5128 ficheros en
		# 99 volumenes, 38 s con 8 conexiones): tantas conexiones como permite la
		# cuenta, y el indice se guarda junto al NZB para la vez siguiente
		# (reanudar, volver a abrirlo).
		ixp = (self.nzb_path or '') + '.rarix'
		cached = _rarix_load(ixp, vols, self.password) if self.nzb_path else None
		if cached is not None:
			parsed = cached
		else:
			conns = max(4, min(20, int(self.max_workers or 8), n))
			th = [threading.Thread(target=work, name='usenet-rar-index') for _ in range(min(conns, n))]
			[t.start() for t in th]
			[t.join(300) for t in th]
			if errors:
				raise errors[0]
			if any(p is None for p in parsed):
				raise SessionError('RAR: volume headers could not be read (not streamable)')
			if self.nzb_path and n > 3:
				_rarix_save(ixp, vols, self.password, parsed)
		try:
			ents = usenet_rar.entries(parsed)
		except usenet_rar.RarError as e:
			raise SessionError('%s (not streamable)' % e)
		if usenet_nested.holds_rar_set(ents, size=lambda e: e['unp']):
			# v2.0.42: un juego RAR dentro del RAR (scene re-subida en un RAR propio)
			ents = self._rar_nested(ents, heads, article, reader)
		entry, why = usenet_rar.pick(ents, self.want, core.episode_pairs)
		iso_e = None
		if not entry:
			# v2.0.37: sin video pero con la ISO de un Blu-ray dentro
			_isos = [e for e in ents if core.ext_of(e['name']) == 'iso' and e['store']]
			if _isos:
				entry = iso_e = max(_isos, key=lambda e: e['unp'])
		if not entry:
			kind2, sample = core.content_kind([(e['name'], e['unp']) for e in ents])
			if kind2 in core.NOT_VIDEO:
				raise SessionError('this NZB holds %s (%s): %s (not streamable)' % (kind2, sample[:60], core.PLAYABLE))
			raise SessionError('%s (not streamable)' % why)
		c = self._connect()
		try:
			# v2.0.37: un Blu-ray entero dentro: la lista de reproduccion mas larga
			# (todos sus .m2ts seguidos) en vez del .m2ts mayor
			clips, disc = [entry], None
			if iso_e is not None:
				clips, disc = self._rar_iso_clips(iso_e, c, heads, article, reader, aes)
			elif not self.want and any(e['name'].lower().endswith('.mpls') for e in ents):
				ciphers = {}

				def cipher_of(e):
					k = id(e)
					if k not in ciphers:
						ciphers[k] = usenet_rar.cipher(e, self.password, aes)
					return ciphers[k]

				def read_entry(e):
					if not e['store'] or not usenet_rar.complete(e):
						raise usenet_disc.DiscError('playlist not readable')
					raw = b''
					for pv, po, psz in e['pieces']:
						if heads[pv] is None:
							heads[pv] = article(c, pv, 0)
						raw += reader(c, pv)(po, psz)
					if e['enc']:
						new, fiv = cipher_of(e)
						raw = new(fiv).decrypt(raw[:len(raw) & ~15])
					return raw[:e['unp']]
				disc = self._disc_choose([(e['name'], e['unp'], e) for e in ents], read_entry, lambda e: e['unp'])
				if disc:
					clips = disc['clips']
			vol_files, offs, sizes, cl = [], [], [], []
			vpos = rpos = 0
			for e in clips:
				if not usenet_rar.complete(e):
					raise SessionError('damaged post: RAR volumes missing for %s (not streamable)' % e['name'][-60:])
				if not e['store']:
					raise SessionError('compressed RAR (not streamable)')
				raw_n = sum(sz for _v, _o, sz in e['pieces'])
				if e['enc']:
					try:
						new, fiv = usenet_rar.cipher(e, self.password, aes)
					except usenet_rar.WrongPassword as ex:
						raise SessionError('%s (not streamable)' % ex)
					except usenet_rar.RarError as ex:
						raise SessionError(NEEDS_AES if 'AES module missing' in str(ex) else '%s (not streamable)' % ex)
					if raw_n % 16:
						raise SessionError('encrypted RAR: data not aligned (not streamable)')
					# v2.0.37: un trozo de una ISO cifrada lleva su sitio en el fichero
					cl.append({'new': new, 'iv': fiv, 'f0': e.get('_f0', 0), 'rstart': e.get('_rs', 0),
							   'rend': e.get('_re', raw_n), 'size': e['unp'], 'vstart': vpos, 'roff': rpos})
				for pv, po, psz in e['pieces']:
					vol_files.append(vols[pv]); offs.append(po); sizes.append(psz)
				vpos += e['unp']; rpos += raw_n
			if cl and len(cl) != len(clips):
				raise SessionError('RAR with encrypted and plain parts mixed (not streamable)')
			pieces = [p for e in clips for p in e['pieces']]
			if cached is not None:
				# del indice guardado: solo hace falta el 1.er articulo de los
				# volumenes que se van a servir
				for v in sorted(set([pieces[0][0], pieces[1][0] if len(pieces) > 1 else pieces[0][0], pieces[-1][0]])):
					if heads[v] is None:
						heads[v] = article(c, v, 0)
			first = heads[pieces[0][0]]
			second = heads[pieces[1][0]] if len(pieces) > 1 else None
			tail = heads[pieces[-1][0]] if len(pieces) > 2 else None
			raw_head = bytearray()
			for pv, po, psz in clips[0]['pieces']:
				if len(raw_head) >= 4096:
					break
				take = min(4096 - len(raw_head), psz)
				if take > 0:
					if heads[pv] is None:
						heads[pv] = article(c, pv, 0)
					raw_head.extend(reader(c, pv)(po, take))
			if cl:
				c0 = cl[0]
				hb = bytes(raw_head[:len(raw_head) & ~15])
				head = _decrypt_span(c0, hb, c0['rstart'])[c0['f0'] - c0['rstart'] - (16 if c0['rstart'] else 0):]
			else:
				head = bytes(raw_head)
		finally:
			try: c.close()
			except Exception: pass
		inner, idetail = core.sniff(head)
		if inner not in STREAMABLE:
			raise SessionError('RAR holds %s (%s), not a playable video (not streamable)'
							   % (inner.upper(), clips[0]['name'].rsplit('/', 1)[-1][-60:]))
		fmt = parsed[0]['fmt']
		enc_s = ' encrypted' if cl else ''
		if disc:
			name = disc['label']
			detail = 'RAR%d store%s, %d vol, playlist %s: %d clips, %d min, %d MB, %s' % (
				fmt, ' AES' if cl else '', len(set(id(v) for v in vol_files)), disc['playlist'], disc.get('n_clips', len(clips)),
				disc['secs'] // 60, vpos // 1048576, idetail)
			self.log('USENET: session %s: RAR%d%s: playing a Blu-ray playlist from inside (%d files, %d volumes %s in %.1fs)'
					 % (self.key[:8], fmt, enc_s, len(ents), n, 'from the saved index' if cached is not None else 'read',
						time.time() - t0))
		else:
			name = entry['name'].rsplit('/', 1)[-1]
			detail = 'RAR%d store%s, %d vol, file %d MB inside, %s' % (fmt, ' AES' if cl else '', len(vol_files),
																	   entry['unp'] // 1048576, idetail)
			self.log('USENET: session %s: RAR%d%s: playing %s from inside (%d files, %d volumes %s in %.1fs)'
					 % (self.key[:8], fmt, enc_s, name, len(ents), n,
						'from the saved index' if cached is not None else 'read', time.time() - t0))
		self.is_rar = True
		info = self._finish(dict(vol_files[0], name=name), kind, vol_files, offs, sizes, first, second, tail,
							rpos if cl else vpos, inner, detail)
		info['inner'] = name
		# Las cabeceras de todos los volumenes ya se leyeron y cuadraron arriba:
		# la comprobacion al entrar en cada volumen mira solo el primer fichero
		# (y no sabe leer cabeceras cifradas), aqui sobra.
		self.verified = set(range(len(vol_files)))
		if disc:
			self.ts_fix = disc.get('ts_fix')
		if cl:
			self.crypt = cl[0] if len(cl) == 1 else {'clips': cl, 'size': vpos}
			self.total = vpos
			info['size'] = vpos
		return info

	def _rar_iso_clips(self, e, c, heads, article, reader, aes):
		"""v2.0.37: la ISO de un Blu-ray dentro de un RAR (cifrado o no): se lee
		su UDF y cada extension de la pelicula pasa a ser un 'fichero' del RAR."""
		pieces = e['pieces']
		raw_n = sum(sz for _v, _o, sz in pieces)
		starts, pos = [], 0
		for _v, _o, sz in pieces:
			starts.append(pos); pos += sz

		def raw_read(a, n):
			out = bytearray()
			n = max(0, min(n, raw_n - a))
			while n > 0:
				k = bisect_right(starts, a) - 1
				v, o, sz = pieces[k]
				if heads[v] is None:
					heads[v] = article(c, v, 0)
				take = min(n, starts[k] + sz - a)
				out += reader(c, v)(o + a - starts[k], take)
				a += take; n -= take
			return bytes(out)
		new = fiv = None
		if e['enc']:
			try:
				new, fiv = usenet_rar.cipher(e, self.password, aes)
			except usenet_rar.WrongPassword as ex:
				raise SessionError('%s (not streamable)' % ex)
			except usenet_rar.RarError as ex:
				raise SessionError(NEEDS_AES if 'AES module missing' in str(ex) else '%s (not streamable)' % ex)

		def read_iso(a, n):
			n = max(0, min(n, e['unp'] - a))
			if not n:
				return b''
			if new is None:
				return raw_read(a, n)
			rs = max(0, (a // 16) * 16 - 16)
			re_ = min(raw_n, -(-(a + n) // 16) * 16)
			plain = _decrypt_span({'new': new, 'iv': fiv}, raw_read(rs, re_ - rs), rs)
			skip = a - rs - (16 if rs else 0)
			return plain[skip:skip + n]
		disc = self._iso_disc(read_iso)
		clips = []
		for ext in disc['clips']:
			for a, ln in ext:
				if new is None:
					clips.append(dict(e, pieces=[(p[0], p[1], p[2]) for p in _slice_pieces(pieces, a, a + ln)], unp=ln, open=False))
				else:
					rs = max(0, (a // 16) * 16 - 16)
					re_ = min(raw_n, -(-(a + ln) // 16) * 16)
					clips.append(dict(e, pieces=list(_slice_pieces(pieces, rs, re_)), unp=ln, open=False,
									  _f0=a, _rs=rs, _re=re_))
		disc['label'] = 'ISO - ' + disc['label']
		disc['n_clips'] = len(disc['clips'])   # v2.0.42: trozos de la pelicula, no tramos de la ISO
		return clips, disc

	def _scan_rar(self, cands, fmt):
		"""Primer segmento de cada candidato (4 conexiones a la vez): se quedan
		los que son volumenes RAR del mismo formato, en orden, desde el que no
		continua de otro hasta el que no sigue en otro."""
		heads = [None] * len(cands)
		gone = {}
		lock = threading.Lock()
		todo = list(range(len(cands)))

		def work():
			c = None
			try:
				c = self._connect()
				while True:
					with lock:
						if not todo: break
						i = todo.pop(0)
					try:
						code, art = c.body(cands[i]['segments'][0][2])
						if art:
							heads[i] = core.parse_rar(core.yenc_decode(art)['data'])
						else:
							gone[i] = code
					except (ValueError, KeyError):
						heads[i] = None
			except Exception:
				pass
			finally:
				if c: c.close()
		th = [threading.Thread(target=work) for _ in range(4)]
		[t.start() for t in th]
		[t.join(120) for t in th]
		# v2.0.37 (kodi.log del 18-nov-2026, Avatar de ExKinoRay): cuantos
		# volumenes ya no estan en el servidor, para decirlo tal cual
		self.scan_gone = len(gone)
		if gone:
			self.log('USENET: session %s: %d of %d files no longer on the server (%s)'
					 % (self.key[:8], len(gone), len(cands), '/'.join(sorted(set(str(x) for x in gone.values())))))
		vols = self._scan_by_number(cands, heads, fmt, gone)
		if vols is None:
			vols, started = [], False
			for f, h in zip(cands, heads):
				if not h or h.get('fmt') != fmt:
					continue
				if not started:
					if h['split_before']:
						continue
					started = True
				vols.append(f)
				if not h['split_after']:
					break
		if not vols:
			raise SessionError('RAR volumes not found after scan (not streamable)')
		return vols

	def _scan_by_number(self, cands, heads, fmt, gone):
		"""v2.0.37 (kodi.log del 18-nov-2026, Avatar de ExKinoRay: volumenes
		renombrados <hash>.10 ... <hash>.223 en un orden que no es el suyo):
		el orden verdadero sale del numero de volumen que guarda el propio RAR
		(RAR5: en la cabecera principal; RAR4: en el bloque de fin, ultimo
		articulo de cada volumen). Devuelve los volumenes en orden desde el
		primero hasta el ultimo o hasta el primero que falte; None si el RAR no
		trae numeros (se ordena como antes)."""
		idx = [i for i, h in enumerate(heads) if h and h.get('fmt') == fmt]
		if len(idx) < 2:
			return None
		num = {}
		if fmt == 5:
			for i in idx:
				num[i] = heads[i].get('volnum')
		else:
			lock = threading.Lock()
			todo = list(idx)

			def work():
				c = None
				try:
					c = self._connect()
					while True:
						with lock:
							if not todo: break
							i = todo.pop(0)
						try:
							code, art = c.body(cands[i]['segments'][-1][2])
							num[i] = core.rar4_volnum(core.yenc_decode(art)['data']) if art else None
						except (ValueError, KeyError, IndexError):
							num[i] = None
				except Exception:
					pass
				finally:
					if c: c.close()
			th = [threading.Thread(target=work) for _ in range(min(8, len(idx)))]
			[t.start() for t in th]
			[t.join(120) for t in th]
		if any(num.get(i) is None for i in idx):
			return None
		by = {}
		for i in idx:
			if num[i] in by:
				return None              # dos con el mismo numero: no se fia
			by[num[i]] = i
		if 0 not in by:
			return []
		vols, k, whole = [], 0, False
		while k in by:
			i = by[k]
			vols.append(cands[i])
			if not heads[i]['split_after']:
				whole = True
				break
			k += 1
		self.log('USENET: session %s: RAR volumes put in order by their own numbers (%d in a row from the first%s)'
				 % (self.key[:8], len(vols), '' if whole else ', then volume %d is missing' % (k + 1)))
		return vols

	# -- mapa fichero virtual -> (volumen, segmento) --------------------------
	def _vol_of(self, pos):
		return bisect_right(self.starts, pos) - 1

	def _articles(self):
		"""Articulos de verdad: los trozos de una ISO o de un RAR por dentro
		apuntan a la misma lista del NZB y no se cuentan dos veces (en el log
		del 19-nov-2026 salian 10722196 'segmentos' de una ISO de 78 GB)."""
		seen, n = set(), 0
		for v in self.vols:
			if id(v['segments']) not in seen:
				seen.add(id(v['segments']))
				n += len(v['segments'])
		return n

	def _lin_for(self, pos):
		k = self._vol_of(pos)
		fo = self.offs[k] + (pos - self.starts[k])
		return self.base[k] + fo // self.part

	def _split(self, lin):
		k = bisect_right(self.base, lin) - 1
		return k, lin - self.base[k]

	def _check_volume(self, k, data):
		"""Cabecera real del volumen k frente a la supuesta (los intermedios
		iguales al 2). Si no cuadra se corta: mejor un error que video con
		trozos cruzados."""
		try:
			h = core.parse_rar(data)
		except ValueError as e:
			return 'volume %d: %s' % (k + 1, e)
		if h['data_off'] != self.offs[k] or h['data_size'] != self.sizes[k]:
			return ('volume %d layout differs (data at %d+%d, expected %d+%d)'
					% (k + 1, h['data_off'], h['data_size'], self.offs[k], self.sizes[k]))
		return None

	def _connect(self):
		c = self.cfg
		if self.warm_pool is not None:
			conn = self.warm_pool.get(c)
			if conn is not None:
				with self.lock:
					self._rx_base[id(conn)] = getattr(conn, 'rx', 0)
					if conn not in self.conns:
						self.conns.append(conn)
				return conn
		try:
			conn = core.NNTPConn(c['host'], c['port'], c['user'], c['password'],
								 timeout=c.get('timeout', 20), use_ssl=c.get('ssl', True))
		except core.NNTPTooMany as e:
			# Easynews no deja abrir mas: se crece hasta aqui y no mas
			with self.lock:
				self.grow_stop = True
				self.max_workers = max(1, min(self.max_workers, len(self.workers) - 1))
				first = not self.too_many_logged
				self.too_many_logged = True
			if first:
				self.log('USENET: Easynews allows no more connections right now (%s); staying at %d' % (e, self.max_workers))
			raise
		with self.lock:
			self._rx_base[id(conn)] = 0
			self.conns.append(conn)
		return conn

	def _recycle_conn(self, conn):
		if conn is None:
			return
		with self.lock:
			if id(conn) in self._rx_base:
				self._rx_recycled += max(0, getattr(conn, 'rx', 0) - self._rx_base.pop(id(conn), 0))
			try:
				self.conns.remove(conn)
			except ValueError:
				pass
		if self.warm_pool is not None and not getattr(conn, 'closed', False) and len(getattr(conn, 'buf', b'')) == 0:
			self.warm_pool.put(self.cfg, conn)
		else:
			try: conn.close()
			except Exception: pass

	# -- conexiones que crecen solo si hace falta (v2.0.32) ---------------------
	def _start_workers(self):
		start = min(self.max_workers, self.profile[3])
		for _ in range(start):
			if not self._spawn_worker():
				break

	def _spawn_worker(self):
		"""Con o sin self.lock: un hilo (y su conexion) mas, si el presupuesto de
		la cuenta lo permite. False si no se pudo."""
		if self.budget is not None and not self.budget.take():
			return False
		t = threading.Thread(target=self._worker_main, name='usenet-worker')
		t.daemon = True
		self.workers.append(t)
		t.start()
		return True

	def _maybe_grow(self):
		"""Con self.lock tomado: si hay trabajo en cola y ningun hilo libre, abre
		otra conexion (como mucho una cada GROW_EVERY s, hasta max_workers)."""
		if self.grow_stop or self.closed or not self.ready or self.idle_workers > 0 or not self.heap:
			return
		if len(self.workers) >= self.max_workers:
			return
		now = time.time()
		if now - self.last_grow < GROW_EVERY:
			return
		self.last_grow = now
		if self._spawn_worker():
			n = len(self.workers)
			if n > self.peak_workers: self.peak_workers = n

	def _worker_main(self):
		try:
			self._worker()
		except core.NNTPTooMany:
			pass
		except Exception as e:
			self.log('USENET: worker stopped: %s: %s' % (type(e).__name__, e))
		finally:
			with self.lock:
				try: self.workers.remove(threading.current_thread())
				except ValueError: pass
				if getattr(threading.current_thread(), 'retiring', False):
					self.retiring -= 1
				self.cond.notify_all()
			if self.budget is not None:
				self.budget.give()

	def wire_bytes(self):
		with self.lock:
			active = sum(max(0, getattr(c, 'rx', 0) - self._rx_base.get(id(c), 0)) for c in self.conns)
			return self._rx_recycled + active

	# -- cola de segmentos ---------------------------------------------------
	def request(self, idx, prio):
		if idx < 0 or idx >= self.nseg:
			return
		with self.lock:
			if idx in self.cache or idx in self.inflight:
				return
			old = self.queued.get(idx)
			if old is not None and old <= prio:
				return
			# v2.0.32: cada lectura vuelve a pedir toda la ventana con la distancia
			# como prioridad, y cada segmento entraba en la cola una vez por paso
			# (hasta ~125 veces en un remux). Ahora solo si la prioridad mejora a
			# la mitad o es urgente: unas 7 veces como mucho. Simulacion: la cola
			# llego a 494.712 entradas (~35 MB) leyendo un fichero de 200 MB.
			if old is not None and prio > 0 and prio > old // 2:
				return
			self.queued[idx] = prio
			self.seq += 1
			heappush(self.heap, (prio, self.seq, idx))
			if len(self.heap) > 4 * len(self.queued) + 256:
				self.heap = [(p_, sq, i) for (p_, sq, i) in self.heap if self.queued.get(i) == p_ or i in self.hedged]
				heapify(self.heap)
			if len(self.heap) > self.idle_workers:
				self.last_short = time.time()   # mas trabajo que hilos libres
			self._maybe_grow()
			# v2.0.25: notify_all. Los lectores esperan en la misma condicion que los
			# hilos de descarga: notify() podia despertar a un lector en vez de a un
			# hilo libre, y el segmento esperaba al timeout del hilo (5 s). Log del
			# 2-nov-2026: una pausa de 4,7-4,9 s en cada reproduccion, siempre a los
			# 20-34 segmentos, con 78-228 Mb/s de linea.
			self.cond.notify_all()

	def _wanted(self, idx):
		for pos in self.readers.values():
			if pos - 1 <= idx <= pos + self.prefetch + 2:
				return True
		return idx == self.nseg - 1

	def _claim(self):
		"""Con self.lock tomado: el siguiente segmento de la cola que este hilo
		debe pedir, y si es la copia de respaldo de uno en vuelo. (None, False)
		si en la cola no queda nada util."""
		while self.heap:
			prio, _, idx = heappop(self.heap)
			if self.queued.get(idx) == prio:
				del self.queued[idx]
			if idx in self.cache:
				continue
			if idx in self.inflight:
				if idx not in self.hedged:
					continue
				self.hedged.discard(idx)   # copia de respaldo: una sola por segmento
				hedge = True
			else:
				if prio > 0 and not self._wanted(idx):
					continue           # prefetch viejo de antes de un seek
				self.inflight.add(idx)
				self.started_at[idx] = time.time()
				hedge = False
			self.copies[idx] = self.copies.get(idx, 0) + 1
			return idx, hedge
		return None, False

	def _release(self, idx):
		"""Con self.lock tomado: suelta un segmento tomado por un hilo que se va
		sin pedirlo (conexion rechazada) y lo devuelve a la cola, urgente."""
		left = self.copies.get(idx, 1) - 1
		if left > 0:
			self.copies[idx] = left
			return                       # otra copia sigue en camino
		self.copies.pop(idx, None)
		self.inflight.discard(idx)
		self.started_at.pop(idx, None)
		self.hedged.discard(idx)
		if idx in self.cache:
			return
		self.queued[idx] = 0
		self.seq += 1
		heappush(self.heap, (0, self.seq, idx))
		self.cond.notify_all()

	def _unclaim_hedge(self, idx):
		"""Con self.lock tomado: devuelve a la cola una copia de respaldo ya tomada."""
		left = self.copies.get(idx, 1) - 1
		if left > 0: self.copies[idx] = left
		else: self.copies.pop(idx, None)
		self.hedged.add(idx)
		self.seq += 1
		heappush(self.heap, (0, self.seq, idx))
		self.cond.notify_all()

	def _msgid(self, idx):
		vk, vi = self._split(idx)
		return self.vols[vk]['segments'][vi][2]

	def _decode(self, idx, code, art, tm=None):
		"""(datos, error, desplazamiento ajeno). Lanza NNTPError si el servidor
		contesto algo que no es el articulo ni un 430 (se reintenta).
		tm: (s hasta la respuesta, s en total) de ESTE articulo."""
		if art is None:
			if code == core.NNTP_NO_ARTICLE:
				if self.backup:
					c2, art = self._backup_body(self._msgid(idx))
					if art:
						self.backup_hits += 1
						if self.backup_hits <= 3:
							self.log('USENET: article %d/%d taken from a backup provider' % (idx + 1, self.nseg))
						return self._decode(idx, c2, art, None)
				data = self._twin_data(idx)
				if data is not None:
					return data, None, None
				return None, 'missing', None
			raise core.NNTPError('BODY %s' % code)
		tm = tm or (0, 0)
		if tm[1] > 0:
			self.fetch_avg = tm[1] if self.fetch_avg is None else 0.9 * self.fetch_avg + 0.1 * tm[1]
		if tm[1] > 2:
			self.log('USENET: segment %d took %.1fs from Easynews (answer after %.1fs, %d KB)'
					 % (idx + 1, tm[1], tm[0], len(art) // 1024))
		t_cpu = time.thread_time()
		dec = core.yenc_decode(art)
		self.cpu += time.thread_time() - t_cpu
		b5 = int(time.time() // 5)
		self.buckets[b5] = self.buckets.get(b5, 0) + len(art)
		vk, vi = self._split(idx)
		if dec['begin'] != vi * self.part:
			# v2.0.27. MEASURED (kodi.log 4-nov-2026, Esref Ruya 2x04
			# TURK265): the NZB pointed segments 24 and 39 at articles
			# from somewhere else (offsets 119238656 and 408252416, not
			# even on a segment boundary). Before, that was a hard
			# error: Kodi got a short read every 2 s and the episode
			# stopped after 30 s. It is treated as a missing article
			# now: zero-filled (a short glitch), counted towards the
			# 'release incomplete' limit like any other hole.
			data = self._twin_data(idx)
			if data is not None:
				return data, None, None
			return None, 'misplaced', dec['begin']
		if not dec['crc_ok']:
			self.log('USENET: crc mismatch on segment %d (kept)' % idx)
		return dec['data'], None, None

	# -- el mismo release en otro post (v2.0.37, Lucian 19-nov-2026) ----------
	# Muchos releases estan subidos mas de una vez (repost, otro indexer). Si un
	# articulo falta en este post y en los respaldos, se busca el mismo trozo del
	# mismo fichero en otro post del release, sin bajar nada de mas: es la
	# 'reparacion' que cabe reproduciendo al momento (PAR2 necesitaria el release
	# entero). Los gemelos los deja resolve() en <nzb>.twins (los NZB del mismo
	# release en otros indexers, que ya trae la busqueda): solo se bajan si hay
	# un hueco. Un fichero gemelo vale si tiene los mismos articulos (mismo
	# tamano de articulo) y un trozo vecino sale identico byte a byte.
	def _twin_data(self, idx):
		if self.twins == []:
			return None
		vk, vi = self._split(idx)
		vf = self.vols[vk]
		with self.twin_lock:
			try:
				if self.twins is None:
					self._twin_load()
				if not self.twins:
					return None
				if id(vf) not in self.twin_match:
					self.twin_match[id(vf)] = self._twin_pair(vf, vi)
				tf = self.twin_match[id(vf)]
				if tf is None:
					return None
				ours = vf['segments'][vi][2]
				theirs = tf['segments'][vi][2]
				if theirs == ours:
					return None
				dec = self._twin_get(theirs)
				if dec is None or dec['begin'] != vi * self.part:
					return None
				self.twin_hits += 1
				if self.twin_hits <= 5:
					self.log('USENET: article %d/%d missing here, taken from another posting of the release' % (idx + 1, self.nseg))
				return dec['data']
			except Exception as e:
				self.log('USENET: another posting of the release could not fill article %d: %s: %s' % (idx + 1, type(e).__name__, e))
				return None

	def _twin_load(self):
		# (con twin_lock: los demas esperan a que acabe, no ven una lista a medias)
		self.twin_files = []
		path = (self.nzb_path or '') + '.twins'
		try:
			with open(path) as f:
				twins = [tuple(x[:2]) for x in json.load(f) if x and x[0]][:TWIN_MAX]
		except (OSError, ValueError):
			self.twins = []
			return
		for url, host in twins:
			try:
				# ya bajado (mismo nombre que le da usenet_easynews.nzb_key), o se baja
				p = os.path.join(os.path.dirname(self.nzb_path), '%s.nzb' % hashlib.md5(url.encode('utf-8')).hexdigest())
				if not os.path.exists(p):
					from resources.lib.modules import usenet_easynews as ue
					p = ue.fetch_nzb(url, ue.nzb_key(url), timeout=20, host=host or None)
				if not p:
					continue
				with open(p, 'rb') as f:
					files = core.parse_nzb(f.read())
				if files:
					self.twin_files.append(files)
			except Exception:
				continue
		self.twins = twins if self.twin_files else []
		self.log('USENET: session %s: %d other posting(s) of the release to fill missing articles' % (self.key[:8], len(self.twin_files)))

	def _twin_get(self, msgid):
		for attempt in range(2):
			try:
				if self.twin_conn is None:
					c = self.cfg
					self.twin_conn = core.NNTPConn(c['host'], c['port'], c['user'], c['password'],
												   timeout=c.get('timeout', 20), use_ssl=c.get('ssl', True))
				code, art = self.twin_conn.body(msgid)
				if art is None and self.backup:
					code, art = self._backup_body(msgid)
				return core.yenc_decode(art) if art else None
			except Exception:
				try: self.twin_conn.close()
				except Exception: pass
				self.twin_conn = None
		return None

	def _twin_pair(self, vf, vi):
		"""El fichero de un post gemelo que es este mismo fichero, o None."""
		n, size = len(vf['segments']), vf.get('bytes') or 0
		mine = None
		for probe in (vi - 1, vi + 1, vi - 2, vi + 2):   # un vecino que si tengamos
			if 0 <= probe < n:
				mine = self._twin_get(vf['segments'][probe][2])
				if mine is not None:
					break
		if mine is None:
			return None
		for files in self.twin_files:
			cands = [f for f in files if len(f['segments']) == n and abs((f.get('bytes') or 0) - size) <= max(4096, size // 50)]
			cands.sort(key=lambda f: f.get('name') != vf.get('name'))
			for f in cands[:TWIN_TRIES]:
				if f['segments'][vi][2] == vf['segments'][vi][2]:
					continue           # el mismo post (otro indexer, los mismos articulos)
				other = self._twin_get(f['segments'][probe][2])
				if other is not None and other['data'] == mine['data'] and other['begin'] == mine['begin']:
					return f
		return None

	def _fetch_one(self, conn, idx, fresh):
		"""Un segmento con hasta 3 intentos. (conexion, datos, error, ajeno)."""
		data, err, misplaced = None, None, None
		for attempt in range(3):
			if attempt and idx in self.cache:
				break                      # la copia de respaldo ya llego
			try:
				if conn is None:
					if attempt or not fresh: self.reconnects += 1
					conn = self._connect()
				code, art = conn.body(self._msgid(idx))
				data, err, misplaced = self._decode(idx, code, art, getattr(conn, 'timing', None))
				break
			except core.NNTPTooMany:
				if len(self.workers) > 1:
					with self.lock:
						self._release(idx)
					raise
				data, err = None, 'Easynews: too many connections'
				time.sleep(2)
			except Exception as e:
				data, err = None, '%s: %s' % (type(e).__name__, e)
				self.retries += 1
				if self.retries <= 5:
					self.log('USENET: segment %d, attempt %d failed (%.1fs in): %s'
							 % (idx + 1, attempt + 1, time.time() - self.stats['started'], err))
				try:
					if conn: conn.close()
				except Exception: pass
				conn = None
				time.sleep(0.5 * (attempt + 1))
		return conn, data, err, misplaced

	def _worker(self):
		with self.lock:
			conn = self.spare.pop() if self.spare else None
		fresh = True
		last_used = time.time()      # ultimo uso de la conexion (articulo o keep-alive)
		last_work = time.time()      # ultimo ARTICULO: lo que decide si sobra (informe E1)
		while True:
			batch, ping = [], False
			with self.lock:
				while not self.closed:
					idx, hedge = self._claim()
					if idx is not None:
						batch.append(idx)
						# Pipelining dinamico: hasta 4 en arranque/seek, 2 en estado estable.
						pipe_max = 4 if len(self.cache) < max(2, self.prefetch // 2) else PIPELINE
						while not hedge and len(batch) < pipe_max:
							idx2, hedge2 = self._claim()
							if idx2 is None:
								break
							if hedge2:
								# v2.0.32 (informe N2): una copia de respaldo es urgente y
								# aqui iria detras de otro articulo: vuelve a la cola para
								# que la coja un hilo libre, sola.
								self._unclaim_hedge(idx2)
								break
							batch.append(idx2)
						break
					idle = time.time() - last_used
					if conn is not None and idle > KEEPALIVE_SECS and self.readers:
						ping = True
						break
					if conn is not None and idle > CONN_IDLE_SECS and not self.readers:
						self._recycle_conn(conn)
						conn = None
					# v2.0.32 (informe E1): sin articulos desde hace CONN_IDLE_SECS,
					# aunque el keep-alive la siga usando cada 30 s
					# y viendo de seguido: el trabajo nuevo despierta a todos y se
					# reparte, asi que ninguno pasa 45 s parado aunque sobren. Si en
					# 45 s siempre hubo un hilo libre al llegar trabajo, se va uno
					# (como mucho uno cada RETIRE_EVERY s).
					now = time.time()
					spare = (now - self.last_short > CONN_IDLE_SECS and now - self.last_retire > RETIRE_EVERY)
					if len(self.workers) - self.retiring > self.profile[3] and (now - last_work > CONN_IDLE_SECS or spare):
						self.last_retire = now
						self.retiring += 1   # se descuenta al salir: nunca bajan de las de base
						threading.current_thread().retiring = True
						# una conexion de mas que ya no hace falta: se devuelve al pool
						if conn is not None:
							self._recycle_conn(conn)
						return
					self.idle_workers += 1
					try: self.cond.wait(1)
					finally: self.idle_workers -= 1
				if self.closed:
					break
			if ping:
				try:
					if not conn.ping(): raise core.NNTPError('DATE refused')
				except Exception:
					try: conn.close()
					except Exception: pass
					conn = None
				last_used = time.time()
				continue
			results = None
			if len(batch) > 1:
				try:
					if conn is None:
						if not fresh: self.reconnects += 1
						conn = self._connect()
					results = conn.body_many([self._msgid(i) for i in batch])
				except core.NNTPTooMany:
					with self.lock:
						for i in batch: self._release(i)
					raise
				except Exception as e:
					self.retries += 1
					if self.retries <= 5:
						self.log('USENET: pipelined segments %s failed (%.1fs in): %s: %s'
								 % ('+'.join(str(i + 1) for i in batch), time.time() - self.stats['started'], type(e).__name__, e))
					try:
						if conn: conn.close()
					except Exception: pass
					conn, results = None, None
			for n, idx in enumerate(batch):
				data = err = misplaced = None
				done = False
				if results is not None:
					try:
						tms = getattr(conn, 'timings', None) or []
						data, err, misplaced = self._decode(idx, results[n][0], results[n][1], tms[n] if n < len(tms) else None)
						done = True
					except Exception:
						done = False           # respuesta rara: se pide de nuevo solo
				if not done:
					conn, data, err, misplaced = self._fetch_one(conn, idx, fresh)
				fresh = False
				self._store(idx, data, err, misplaced)
			last_used = last_work = time.time()
		if conn:
			self._recycle_conn(conn)

	def _evict(self):
		"""Con self.lock tomado: expulsa lo mas antiguo hasta caber, salvo el
		principio y el final fijados y lo que algun lector tiene por delante."""
		if len(self.cache) <= self.cache_max:
			return
		readers = list(self.readers.values())
		# v2.0.37: primero lo que se pidio por delante de una lectura que ya no
		# esta (un tanteo de Kodi buscando) y nadie leyo; lo leido se queda mas
		for k in list(self.cache.keys()):
			if len(self.cache) <= self.cache_max:
				return
			if k in self.pinned or k in self.touched or any(pos <= k <= pos + self.prefetch for pos in readers):
				continue
			del self.cache[k]
		tries = len(self.cache)
		while len(self.cache) > self.cache_max and tries > 0:
			tries -= 1
			k, v = self.cache.popitem(last=False)
			if k in self.pinned or any(pos <= k <= pos + self.prefetch for pos in readers):
				self.cache[k] = v        # al final de la cola: se queda
			else:
				self.touched.discard(k)
		while len(self.cache) > self.cache_max + len(self.pinned):
			k, _v = self.cache.popitem(last=False)   # tope duro, por si los lectores lo llenan todo
			self.touched.discard(k)

	def _store(self, idx, data, err, misplaced):
		vk, vi = self._split(idx)
		with self.lock:
			left_copies = self.copies.get(idx, 1) - 1
			if left_copies > 0:
				self.copies[idx] = left_copies
			else:
				self.copies.pop(idx, None)
				self.inflight.discard(idx)
				t0 = self.started_at.pop(idx, None)
				if t0 is not None and not err and idx not in self.hedge_tried:
					self.wait_times.append(time.time() - t0)
					wt = sorted(self.wait_times)
					self.wait_med = wt[len(wt) // 2]
				self.hedge_tried.discard(idx)
				self.hedged.discard(idx)
			if idx in self.cache or (err and err not in ('missing', 'misplaced') and left_copies > 0):
				# la otra copia ya llego, o sigue en camino y puede llegar bien:
				# esta no cuenta ni da el segmento por perdido
				self.cond.notify_all()
				return
			if err in ('missing', 'misplaced'):
				size = self._seg_len(idx)
				self.missing.add(idx)
				self.consecutive_missing += 1
				self.cache[idx] = b'\x00' * size
				if self.container == 'mkv' and self.crypt is None and not getattr(self, 'ts_fix', None):
					self._void_queue(idx)
				if err == 'missing':
					self.log('USENET: article %d/%d missing on server, zero-filled' % (idx + 1, self.nseg))
				else:
					self.log('USENET: article %d/%d belongs elsewhere (yEnc offset %d, expected %d): wrong article in the NZB, zero-filled'
							 % (idx + 1, self.nseg, misplaced, vi * self.part))
			elif err:
				self.failed[idx] = err
				self.log('USENET: segment %d failed: %s' % (idx, err))
			else:
				self.consecutive_missing = 0
				self.cache[idx] = data
				if self.is_rar and vk not in self.verified and vi == 0:
					self.verified.add(vk)
					bad = self._check_volume(vk, data)
					if bad and not self.layout_error:
						self.layout_error = bad
						self.log('USENET: session %s stopped: RAR %s' % (self.key[:8], bad))
				self.stats['bytes'] += len(data)
				self.stats['segments'] += 1
			fetched = self.stats['segments'] + len(self.missing)
			if (self.incomplete is None and fetched >= INCOMPLETE_MIN_SEGMENTS
					and len(self.missing) >= INCOMPLETE_RATIO * fetched):
				self.incomplete = round(100.0 * len(self.missing) / fetched)
				self.log('USENET: session %s stopped: release incomplete on the server '
						 '(%d of %d articles missing, ~%d%%)' % (self.key[:8], len(self.missing), fetched, self.incomplete))
				if self.on_incomplete:
					try: self.on_incomplete(self.key, self.incomplete)
					except Exception: pass
			self._evict()
			held = len(self.cache) * self.part
			if held > self.cache_peak: self.cache_peak = held
			if self.ram is not None:
				self.ram.update(self.key, held)
			self.cond.notify_all()

	def _watchdog(self):
		"""Diagnostico: si Python entero se queda parado (otro addon ocupando el
		interprete, CPU al arrancar el video), este reloj lo nota."""
		while not self.closed:
			t = time.time()
			time.sleep(0.25)
			lag = time.time() - t - 0.25
			if lag > self.lag_max: self.lag_max = lag

	def _seg_len(self, idx):
		return self.part

	def get(self, idx, reader):
		self.last_use = time.time()
		with self.lock:
			prev = self.readers.get(reader)
			self.readers[reader] = idx
			# Kodi abre una peticion nueva en cada salto: cuenta como salto la que
			# empieza lejos de donde se iba leyendo (sin el final: indices del MKV)
			last = self.last_idx
			if prev is None and last is not None and abs(idx - last) > 2 and 2 < idx < self.nseg - 3:
				self.seeks += 1
			# un tanteo de Kodi buscando cae a menudo en el mismo segmento que el
			# anterior o al lado: toda lectura nueva (sin el arranque ni el final)
			# empieza como tanteo y deja de serlo en cuanto lee de seguido PROBE_SEQ
			if prev is None and last is not None and 2 < idx < self.nseg - 3:
				self.probing.add(reader)
			self.last_idx = idx
			# viendo de seguido (no un salto): esperar aqui es un parón en pantalla.
			# v2.0.25: sin contar el arranque ni lo justo despues de un salto (los
			# primeros segmentos de cada lectura los espera Kodi antes de pintar):
			# log del 2-nov-2026, una 'pausa' por reproduccion, siempre al empezar.
			n_read = self.reads.get(reader, 0) + 1 if prev is not None and idx == prev + 1 else 0
			self.reads[reader] = n_read
			if reader in self.probing and n_read >= 1 and n_read * self.part >= PROBE_SEQ:
				self.probing.discard(reader)     # sigue de seguido: ya es ver la pelicula
			ahead = self.prefetch if reader not in self.probing else max(1, PROBE_AHEAD // self.part)
			watching = n_read > self.prefetch and idx not in self.cache
			if watching:   # para diagnosticar una pausa: como estaba el segmento al empezar a esperar
				w_state = ('in flight %.1fs' % (time.time() - self.started_at.get(idx, time.time()))) if idx in self.inflight else \
					(('queued, priority %s' % self.queued[idx]) if idx in self.queued else 'not requested')
				w_done, w_busy, w_heap = self.stats['segments'], len(self.inflight), len(self.heap)
				self.lag_max = 0.0
		t_wait = time.time()
		for k in range(idx + 1, min(idx + 1 + ahead, self.nseg)):
			self.request(k, k - idx)
		# RAR: la cabecera de un volumen nuevo se comprueba en cuanto se entra
		if self.is_rar:
			vk, vi = self._split(idx)
			if vk not in self.verified and vi != 0:
				self.request(self.base[vk], 3)
		self.request(idx, 0)
		deadline = time.time() + GET_TIMEOUT
		with self.lock:
			while True:
				if self.incomplete is not None:
					raise SessionError('release incomplete on the server (~%d%% missing)' % self.incomplete)
				if self.layout_error:
					raise SessionError('RAR %s' % self.layout_error)
				if idx in self.cache:
					self.cache.move_to_end(idx)
					self.touched.add(idx)
					if watching:
						waited = time.time() - t_wait
						if waited > 2:
							self.stalls += 1
							self.stall_secs += waited
							self.log('USENET: pause of %.1fs while watching, segment %d/%d (%s; %d in flight, %d queued; '
									 '%d segments fetched meanwhile; Python held up to %.1fs; %d reconnects, %d retries so far)'
									 % (waited, idx + 1, self.nseg, w_state, w_busy, w_heap, self.stats['segments'] - w_done,
										self.lag_max, self.reconnects, self.retries))
					return self.cache[idx]
				if idx in self.failed:
					err = self.failed.pop(idx)
					raise SessionError('segment %d: %s' % (idx, err))
				if self.consecutive_missing >= MAX_CONSECUTIVE_MISSING:
					if self.incomplete is None:
						fetched = max(1, self.stats['segments'] + len(self.missing))
						self.incomplete = max(1, round(100.0 * len(self.missing) / fetched))
						if self.on_incomplete:
							try: self.on_incomplete(self.key, self.incomplete)
							except Exception: pass
					raise SessionError('too many missing articles in a row')
				if self.closed:
					raise SessionError('session closed')
				left = deadline - time.time()
				if left <= 0:
					raise SessionError('timeout waiting for segment %d' % idx)
				if idx not in self.inflight and self.queued.get(idx) is None:
					self.request(idx, 0)
				elif (idx in self.inflight and idx not in self.hedge_tried
						and time.time() - self.started_at.get(idx, time.time()) > self._hedge_after(reader)):
					self.hedge_tried.add(idx)
					self.hedged.add(idx)
					self.hedges += 1
					self.seq += 1
					heappush(self.heap, (0, self.seq, idx))
					self.cond.notify_all()
					self.log('USENET: segment %d stuck %.1fs on one connection, asking another one too'
							 % (idx + 1, time.time() - self.started_at.get(idx, time.time())))
				self.cond.wait(min(left, 1))

	def _hedge_after(self, reader):
		# v2.0.37: lo que es 'atascado' depende de lo que suele esperarse un articulo
		# de ESTE release (desde que una conexion lo toma hasta que llega). Con articulos de 3,8 MB (Gladiator EXTENDED, kodi.log del
		# 19-nov-2026) uno normal tarda 2-3,5 s: a los 3 s fijos casi todos se pedian
		# dos veces y, tras un salto, la linea se gastaba en copias (12,5 s en seguir).
		if self.wait_med:
			base = min(HEDGE_MAX, max(HEDGE_SECS, HEDGE_TIMES * self.wait_med))
		else:   # nada medido aun: por el tamano del articulo (3 s por cada MB, desde 3 s)
			base = min(HEDGE_MAX, HEDGE_SECS * max(1.0, (getattr(self, 'part', 0) or 0) / 1048576.0))
		if reader in self.probing and self.fetch_avg:
			return max(PROBE_HEDGE_MIN, min(base, PROBE_HEDGE_TIMES * self.fetch_avg))
		return base

	def iter_range(self, start, end, reader):
		"""Bytes [start, end] inclusive del video, en trozos. v2.0.37: con un
		Blu-ray, las marcas de tiempo de cada trozo se ponen seguidas."""
		if getattr(self, 'ts_fix', None):
			return self._iter_fixed(start, end, reader)
		return self._iter_base(start, end, reader)

	def _iter_fixed(self, start, end, reader):
		pk = usenet_disc.PKT
		tf = self.ts_fix
		k = max(0, bisect_right([x[0] for x in tf], start) - 1)
		pos = start
		while pos <= end and k < len(tf):
			vs, sz, dl = tf[k]
			stop = min(end, vs + sz - 1)
			if stop >= pos:
				if not dl:
					for chunk in self._iter_base(pos, stop, reader):
						yield chunk
				else:
					a = vs + ((pos - vs) // pk) * pk              # al principio del paquete
					b = min(vs + sz - 1, vs + -(-(stop - vs + 1) // pk) * pk - 1)
					buf, cur = bytearray(), a                     # cur: donde empieza buf
					for chunk in self._iter_base(a, b, reader):
						buf += chunk
						if len(buf) >= 262144:
							n = len(buf) - len(buf) % pk
							part = usenet_disc.fix_ts(bytearray(buf[:n]), dl)
							lo, hi = max(pos, cur) - cur, min(stop, cur + n - 1) - cur + 1
							if hi > lo:
								yield bytes(part[lo:hi])
							del buf[:n]
							cur += n
					if buf:
						n = len(buf) - len(buf) % pk
						part = usenet_disc.fix_ts(bytearray(buf[:n]), dl) + buf[n:]
						lo, hi = max(pos, cur) - cur, min(stop, cur + len(buf) - 1) - cur + 1
						if hi > lo:
							yield bytes(part[lo:hi])
				pos = stop + 1
			k += 1
		if pos <= end:
			raise SessionError('Blu-ray clips: read past the end')

	def _iter_base(self, start, end, reader):
		if self.crypt is None:
			return self._iter_raw(start, end, reader)
		if 'clips' not in self.crypt:
			return self._iter_plain(self.crypt, start, end, reader)
		return self._iter_clips(start, end, reader)

	def _iter_clips(self, start, end, reader):
		"""v2.0.37: varios trozos cifrados seguidos (los .m2ts de una lista de
		reproduccion de un Blu-ray). Cada uno con su sitio en el video en claro
		(vstart), en lo servido cifrado (roff) y su descifrador."""
		clips = self.crypt['clips']
		k = max(0, bisect_right([c['vstart'] for c in clips], start) - 1)
		pos = start
		while pos <= end and k < len(clips):
			c = clips[k]
			stop = min(end, c['vstart'] + c['size'] - 1)
			if stop >= pos:
				for chunk in self._iter_plain(c, pos - c['vstart'], stop - c['vstart'], reader):
					yield chunk
				pos = stop + 1
			k += 1
		if pos <= end:
			raise SessionError('encrypted clips: read past the end')

	def _iter_plain(self, c, start, end, reader):
		p0, p1 = c['f0'] + start, c['f0'] + end              # en la carpeta, inclusive
		b0 = p0 - p0 % 16
		e1 = min(c['rend'], p1 - p1 % 16 + 16)
		r0 = b0 - 16 if b0 else 0                            # el bloque de antes es el iv
		roff = c.get('roff', 0)
		raw = self._iter_raw(roff + r0 - c['rstart'], roff + e1 - c['rstart'] - 1, reader)
		buf = b''
		if r0 < b0:
			for chunk in raw:
				buf += chunk
				if len(buf) >= 16: break
			if len(buf) < 16:
				raise SessionError('encrypted 7z: short read')
			iv, buf = buf[:16], buf[16:]
		else:
			iv = c['iv']
		dec = c['new'](iv)
		skip, left = p0 - b0, end - start + 1
		head, buf = ([buf] if buf else []), b''
		for chunk in _chain(head, raw):
			buf += chunk
			n = len(buf) - len(buf) % 16
			if not n:
				continue
			out = dec.decrypt(buf[:n]); buf = buf[n:]
			if skip:
				k = min(skip, len(out)); out = out[k:]; skip -= k
			if out:
				out = out[:left]; left -= len(out)
				yield out
				if left <= 0:
					return
		if left > 0:
			raise SessionError('encrypted 7z: data not aligned')

	def _iter_raw(self, start, end, reader):
		"""Bytes [start, end] inclusive del fichero virtual, en trozos."""
		pos = start
		while pos <= end:
			k = self._vol_of(pos)
			fo = self.offs[k] + (pos - self.starts[k])
			vi = fo // self.part
			data = self.get(self.base[k] + vi, reader)
			off = fo - vi * self.part
			n = min(len(data) - off, end - pos + 1, self.starts[k] + self.sizes[k] - pos)
			if n <= 0:
				raise SessionError('empty chunk at %d' % pos)
			chunk = data[off:off + n]
			if self.missing and self.container == 'mkv' and self.crypt is None and reader != '__void__':
				self._void_wait(pos, pos + n)
			if self.voids:
				chunk = self._apply_voids(pos, chunk, reader)
			self.rpos[reader] = pos + n
			yield chunk
			pos += n

	# -- huecos de un MKV: EBML Void en vez de ceros (v2.0.37) ---------------
	def _apply_voids(self, pos, chunk, reader):
		end = pos + len(chunk)
		out = None
		for v in self.voids:
			if v['end'] <= pos or v['start'] >= end or reader in v['skip']:
				continue
			if out is None:
				out = bytearray(chunk)
			a, b = max(pos, v['start']), min(end, v['end'])
			s0 = a - v['start']
			hdr = v['hdr'][s0:s0 + (b - a)] if s0 < len(v['hdr']) else b''
			out[a - pos:b - pos] = hdr + bytes((b - a) - len(hdr))
		return bytes(out) if out is not None else chunk

	def _void_wait(self, a, b):
		"""Si un hueco empieza poco despues de lo que se va a servir, espera
		(poco) a que se decida si se tapa: el Void empieza antes del hueco, en el
		bloque que lo contiene, y eso no se puede cambiar una vez servido."""
		todo = [i for i in list(self.missing) if i not in self.void_done]
		if not todo:
			return
		near = False
		for i in todo:
			r = self._plain_range(i)
			if r and a - VOID_BEHIND <= r[0] <= b + VOID_BEHIND:
				near = True
				break
		if not near:
			return
		t0 = time.time()
		while time.time() - t0 < VOID_WAIT and not self.closed:
			if all(i in self.void_done for i in todo):
				return
			time.sleep(0.05)

	def _plain_range(self, idx):
		"""[a, b) del fichero servido que ocupa el articulo idx."""
		k, vi = self._split(idx)
		f0, f1 = vi * self.part, vi * self.part + self._seg_len(idx)
		for j in range(len(self.starts)):
			if self.base[j] != self.base[k]:
				continue
			a, b = max(f0, self.offs[j]), min(f1, self.offs[j] + self.sizes[j])
			if a < b:
				return self.starts[j] + a - self.offs[j], self.starts[j] + b - self.offs[j]
		return None

	def _void_read(self, pos, n):
		rd = '__void__'
		try:
			end = min(self.total, pos + n) - 1
			return b''.join(self._iter_raw(pos, end, rd)) if end >= pos else b''
		finally:
			self.drop_reader(rd)
			self.rpos.pop(rd, None)

	def _void_queue(self, idx):
		"""v2.0.37: un solo hilo tapa los huecos, uno tras otro: un bloque entero
		de articulos perdidos no abre un hilo por articulo."""
		with self.void_qlock:
			if idx in self.void_done or idx in self.void_pending:
				return
			self.void_pending.add(idx)
			if self.void_worker:
				return
			self.void_worker = True
		threading.Thread(target=self._void_run, name='usenet-mkv-void', daemon=True).start()

	def _void_run(self):
		while True:
			with self.void_qlock:
				self.void_pending -= self.void_done
				if not self.void_pending or self.closed:
					self.void_pending.clear()
					self.void_worker = False
					return
				idx = min(self.void_pending)
			try:
				self._void_for(idx)
			finally:
				with self.void_qlock:
					self.void_pending.discard(idx)

	def _void_next_missing(self, j):
		"""v2.0.37: si el articulo siguiente al hueco falta tambien. Si aun no ha
		llegado se espera un poco (ya va pedido por delante): si falta y no se
		sabia, el Void acababa en un Cluster que cae dentro de ese otro hueco
		(ceros) y ese hueco se daba por tapado (banco E32, 1 de cada 6)."""
		if j >= self.nseg:
			return False
		if j in self.missing:
			return True
		self.request(j, 0)
		deadline = time.time() + VOID_WAIT
		with self.cond:
			while (j not in self.cache and j not in self.missing and not self.closed
					and time.time() < deadline):
				self.cond.wait(0.1)
			return j in self.missing

	def _mkv_index(self):
		"""Los clusters que listan los Cues, leidos una vez (con void_lock tomado)."""
		if self.mkv_ix is None:
			try:
				seg, cues = usenet_mkv.segment_head(self._void_read(0, 65536))
				if cues is None:
					raise usenet_mkv.MkvError('no Cues in the SeekHead')
				size = usenet_mkv.cues_element(self._void_read(cues, 16))
				self.mkv_ix = usenet_mkv.cue_clusters(self._void_read(cues, size), seg) or False
				if self.mkv_ix is False:
					self.mkv_why = 'the Cues list no clusters'
			except usenet_mkv.MkvError as e:
				self.mkv_ix = False
				self.mkv_why = str(e)
		return self.mkv_ix

	def _mkv_prewarm(self):
		"""v2.0.37: el indice del MKV se lee poco despues de empezar, sin esperar
		al primer hueco: casi siempre sale de lo que Kodi ya pidio (el principio
		y el final del fichero), y el primer hueco no tiene que esperarlo."""
		t0 = time.time()
		while time.time() - t0 < MKV_PREWARM and not self.closed:
			time.sleep(0.25)
		if self.closed:
			return
		try:
			with self.void_lock:
				self._mkv_index()
		except Exception as e:
			self.mkv_ix = False
			self.mkv_why = '%s: %s' % (type(e).__name__, e)

	def _void_for(self, idx):
		with self.void_lock:
			hole = [idx]
			try:
				r = self._plain_range(idx)
				if not r or self.closed:
					return
				h0, h1 = r
				# el hueco entero: los articulos de al lado que tambien faltan
				j = idx - 1
				while j >= 0 and j in self.missing:
					rr = self._plain_range(j)
					if not rr or rr[1] != h0: break
					h0, j = rr[0], j - 1
					hole.append(j + 1)
				j = idx + 1
				while self._void_next_missing(j):
					rr = self._plain_range(j)
					if not rr or rr[0] != h1: break
					h1, j = rr[1], j + 1
					hole.append(j - 1)
				if any(v['start'] <= h0 < v['end'] for v in self.voids):
					return                       # ya tapado (los articulos de al lado del mismo hueco)
				if not self._mkv_index():
					if self.mkv_why:
						self.log('USENET: MKV holes stay zero-filled here: %s' % self.mkv_why)
						self.mkv_why = None      # dicho una vez
					return
				plan = usenet_mkv.plan(self._void_read, self.mkv_ix, h0, h1)
				if not plan:
					return
				new = []
				for a, b in plan:
					skip = set(rd for rd, p in list(self.rpos.items()) if a < p)
					new.append({'start': a, 'end': b, 'hdr': usenet_mkv.void_bytes(b - a)[:9], 'skip': skip})
				self.voids = sorted(self.voids + new, key=lambda v: v['start'])
				self.void_hits += 1
				if self.void_hits <= 5:
					self.log('USENET: MKV hole at %.1f MB covered with EBML Void (%d KB skipped cleanly up to the next cluster)'
							 % (h0 / 1048576.0, sum(b - a for a, b in plan) // 1024))
			except Exception as e:
				self.log('USENET: MKV hole could not be covered (%s: %s); it stays zero-filled' % (type(e).__name__, e))
			finally:
				self.void_done.update(hole)

	def drop_reader(self, reader):
		with self.lock:
			self.readers.pop(reader, None)
			self.reads.pop(reader, None)
			self.probing.discard(reader)
			self.rpos.pop(reader, None)

	def trim_cache(self):
		"""Libera segmentos no fijados cuando no hay lectores activos."""
		with self.lock:
			if self.closed or self.readers:
				return
			for k in list(self.cache.keys()):
				if k not in self.pinned:
					del self.cache[k]
			self.touched.intersection_update(self.cache)
			if self.ram is not None:
				self.ram.update(self.key, len(self.cache) * self.part)

	def close(self):
		with self.lock:
			if self.closed:
				return
			self.closed = True
			spares, self.spare = list(self.spare), []
			self.cond.notify_all()
		for c in spares:
			self._recycle_conn(c)
		for pool in self.backups:
			pool.close()
		if self.twin_conn is not None:
			try: self.twin_conn.close()
			except Exception: pass
			self.twin_conn = None
		if self.ram is not None:
			self.ram.drop(self.key)
		if self.ready:
			self.log('USENET: session %s closed: %.1f MB in %d segments, %d missing, up to %d connections%s'
					 % (self.key[:8], self.stats['bytes'] / 1e6, self.stats['segments'], len(self.missing),
						getattr(self, 'peak_workers', 0),
						((', %d from the backup providers' % self.backup_hits) if self.backup_hits else '')
						+ ((', %d from another posting of the release' % self.twin_hits) if self.twin_hits else '')))
		if self.on_close:
			try: self.on_close(self.summary())
			except Exception: pass

	def summary(self):
		"""Lo que costo esta sesion: para el informe de uso (Tools > Usenet report)."""
		busy = [b for b in self.buckets.values() if b > 0]
		mbps = lambda b: b * 8 / 5.0 / 1e6
		return {'key': self.key, 'ready': bool(self.ready), 'wire': self.wire_bytes(), 'rtype': getattr(self, 'rtype', None),
				'bytes': self.stats['bytes'], 'segments': self.stats['segments'],
				'missing': len(self.missing), 'size': getattr(self, 'total', 0),
				'secs': round(time.time() - self.stats['started'], 1), 'cpu': round(self.cpu, 2),
				'peak_mbps': round(max(mbps(b) for b in busy), 1) if busy else 0,
				'avg_mbps': round(sum(mbps(b) for b in busy) / len(busy), 1) if busy else 0,
				'cache_peak': self.cache_peak, 'cache_max': getattr(self, 'cache_max', 0) * getattr(self, 'part', 0),
				'stalls': self.stalls, 'stall_secs': round(self.stall_secs, 1), 'seeks': self.seeks,
				'incomplete': self.incomplete, 'rar': bool(self.is_rar),
				'volumes': len(getattr(self, 'vols', []) or []), 'conns': getattr(self, 'peak_workers', 0) or int(self.cfg.get('connections') or 4),
				'conns_max': self.max_workers,
				'runtime': self.runtime or 0, 'backup_hits': self.backup_hits,
				'ram_peak': self.ram.peak if self.ram is not None else self.cache_peak,
				'backup_wire': sum(getattr(c, 'rx', 0) for c in list(self.bk_conns))}


class BackupPool(object):
	"""v2.0.32 (informe L7, arreglo B1): un proveedor de respaldo con un grupo
	de N conexiones COMPARTIDO entre los hilos: nunca se abren mas de las del
	ajuste (antes cada hilo abria la suya y con 2 configuradas salian 5)."""
	def __init__(self, cfg, log=_noop_log):
		self.cfg = cfg
		self.log = log
		self.size = max(1, int(cfg.get('connections') or 2))
		self.name = cfg.get('name') or 'backup provider'
		self.cond = threading.Condition(threading.Lock())
		self.free = []          # conexiones abiertas y libres
		self.opened = []        # todas las que se abrieron (bytes para el informe)
		self.alive = 0          # abiertas ahora (libres + en uso)
		self.failed = False     # login rechazado: no se insiste en esta sesion
		self.closed = False

	def _open(self):
		b = self.cfg
		try:
			return core.NNTPConn(b['host'], int(b.get('port') or 563), b.get('user') or '', b.get('password') or '',
								 timeout=b.get('timeout', 20), use_ssl=b.get('ssl', True))
		except core.NNTPTooMany as e:
			self.log('USENET: %s allows no more connections (%s)' % (self.name, e))
		except core.NNTPAuthError as e:
			self.failed = True
			self.log('USENET: %s refused the login (%s)' % (self.name, e))
		except Exception as e:
			self.log('USENET: %s not reachable: %s: %s' % (self.name, type(e).__name__, e))
		return None

	def _get(self, wait=30):
		"""Una conexion del grupo (espera a que quede una libre), o None."""
		deadline = time.time() + wait
		with self.cond:
			while True:
				if self.failed or self.closed:
					return None
				if self.free:
					return self.free.pop()
				if self.alive < self.size:
					self.alive += 1
					break
				left = deadline - time.time()
				if left <= 0:
					return None
				self.cond.wait(left)
		conn = self._open()           # fuera del lock: conectar tarda
		with self.cond:
			if conn is None or self.closed:
				self.alive -= 1
				self.cond.notify()
				if conn is not None:
					try: conn.close()
					except Exception: pass
				return None
			self.opened.append(conn)
		return conn

	def _put(self, conn, broken=False):
		with self.cond:
			broken = broken or self.closed
			if broken:
				self.alive -= 1
			else:
				self.free.append(conn)
			self.cond.notify()
		if broken:
			try: conn.close()
			except Exception: pass

	def body(self, msgid):
		if self.failed:
			return None, None
		for attempt in range(2):
			conn = self._get()
			if conn is None:
				return None, None
			try:
				r = conn.body(msgid)
			except Exception:
				self._put(conn, broken=True)
				continue
			self._put(conn)
			return r
		return None, None

	def stat_many(self, ids):
		conn = self._get()
		if conn is None:
			raise core.NNTPError('%s not available' % self.name)
		try:
			r = conn.stat_many(ids)
		except Exception:
			self._put(conn, broken=True)
			raise
		self._put(conn)
		return r

	def close(self):
		with self.cond:
			self.closed = True
			conns, self.free = list(self.free), []
			self.cond.notify_all()
		for c in conns:
			try: c.close()
			except Exception: pass


class ConnBudget(object):
	"""v2.0.32: conexiones de Easynews que pueden abrir todas las sesiones a
	la vez, para no pasar de las 60 de la cuenta (y dejar las de la salud)."""
	def __init__(self, total):
		self.total = max(1, total)
		self.used = 0
		self.lock = threading.Lock()

	def take(self):
		with self.lock:
			if self.used >= self.total:
				return False
			self.used += 1
			return True

	def give(self):
		with self.lock:
			self.used = max(0, self.used - 1)


class RamMeter(object):
	"""v2.0.32 (informe N5): bytes en RAM de todas las sesiones a la vez y su
	maximo, para el informe de uso (hasta MAX_SESSIONS a la vez)."""
	def __init__(self):
		self.lock = threading.Lock()
		self.held = {}
		self.peak = 0

	def update(self, key, nbytes):
		with self.lock:
			self.held[key] = nbytes
			total = sum(self.held.values())
			if total > self.peak: self.peak = total

	def drop(self, key):
		with self.lock:
			self.held.pop(key, None)


DISC_IMAGE_EXT = ('iso', 'img', 'bin', 'mdf', 'nrg')
_RE_LOOSE_MPLS = re.compile(r'(?i)(?:^|\D)(\d{5})\.mpls$')   # v2.0.42: disco en ficheros sueltos
_RE_LOOSE_M2TS = re.compile(r'(?i)(?:^|\D)(\d{5})\.m2ts$')
SUB_EXT = ('.srt', '.ass', '.ssa', '.vtt')   # v2.0.42: subtitulos de texto sueltos en el NZB
SUB_MAX = 40
SUB_MAX_BYTES = 8 * 1024 * 1024
DISC_CHOICE_VERSION = 4   # v2.0.37: la eleccion lleva las marcas de tiempo de cada trozo; 4: gana la que mas pesa (Mockingjay)
POOL_PROBE_SECS = 3   # guardada mas tiempo que esto: se prueba con DATE antes de usarla


class WarmPool(object):
	"""Pool compartido de conexiones NNTP autenticadas entre sesiones."""
	def __init__(self, max_conns=6, ttl=25):
		self.max_conns = max_conns
		self.ttl = ttl
		self.lock = threading.Lock()
		self.pool = {}  # (host, port, user, ssl) -> [(ts, conn), ...]

	def _key(self, cfg):
		return (cfg.get('host'), cfg.get('port'), cfg.get('user'), cfg.get('ssl', True))

	def get(self, cfg):
		k = self._key(cfg)
		now = time.time()
		stale = []
		chosen = idle = None
		with self.lock:
			items = self.pool.get(k) or []
			while items:
				ts, c = items.pop()
				if now - ts > self.ttl or getattr(c, 'closed', False) or len(getattr(c, 'buf', b'')) != 0:
					stale.append(c)
					continue
				chosen, idle = c, now - ts
				break
			if not items and k in self.pool:
				del self.pool[k]
		for c in stale:
			try: c.close()
			except Exception: pass
		# v2.0.37 (auditoria del 18-nov-2026): una conexion que lleva unos
		# segundos guardada puede haberla cerrado el servidor o la red (wifi que
		# cambia, la caja que se duerme), y el primer BODY de prepare() fallaria
		# con el release bueno. Un DATE (milisegundos) lo dice antes.
		if chosen is not None and idle > POOL_PROBE_SECS:
			try:
				ok = chosen.cmd('DATE')[0] == 111
			except Exception:
				ok = False
			if not ok:
				try: chosen.close()
				except Exception: pass
				chosen = None
		return chosen

	def put(self, cfg, conn):
		if conn is None or getattr(conn, 'closed', False) or len(getattr(conn, 'buf', b'')) != 0:
			if conn is not None:
				try: conn.close()
				except Exception: pass
			return
		k = self._key(cfg)
		now = time.time()
		evicted = []
		with self.lock:
			items = [x for x in (self.pool.get(k) or []) if now - x[0] <= self.ttl and not getattr(x[1], 'closed', False)]
			evicted.extend(x[1] for x in (self.pool.get(k) or []) if x not in items)
			if len(items) < self.max_conns:
				items.append((now, conn))
				self.pool[k] = items
			else:
				evicted.append(conn)
		for c in evicted:
			try: c.close()
			except Exception: pass

	def reap(self):
		now = time.time()
		stale = []
		with self.lock:
			for k in list(self.pool.keys()):
				alive = []
				for ts, c in self.pool[k]:
					if now - ts <= self.ttl and not getattr(c, 'closed', False):
						alive.append((ts, c))
					else:
						stale.append(c)
				if alive:
					self.pool[k] = alive
				else:
					del self.pool[k]
		for c in stale:
			try: c.close()
			except Exception: pass

	def close(self):
		with self.lock:
			all_conns = [c for items in self.pool.values() for _, c in items]
			self.pool.clear()
		for c in all_conns:
			try: c.close()
			except Exception: pass


class Engine(object):
	"""Registro de sesiones + configuracion. Uno por servicio."""

	def __init__(self, nzb_dir, cfg_provider, log=_noop_log, on_incomplete=None, on_close=None):
		self.nzb_dir = nzb_dir
		self.on_close = on_close
		self.cfg_provider = cfg_provider
		self.log = log
		self.sessions = OrderedDict()
		self.on_incomplete = on_incomplete
		self.lock = threading.Lock()
		self.prep_locks = {}
		self.ram = RamMeter()
		self.budget = ConnBudget(ACCOUNT_CONNS - HEALTH_RESERVE)
		self.warm_pool = WarmPool(max_conns=6, ttl=25)
		self.runtimes = {}                   # clave -> duracion pasada en /prepare

	def nzb_path(self, key):
		return os.path.join(self.nzb_dir, '%s.nzb' % key)

	def prepare(self, key, runtime=None, want=None):
		if not KEY_RE.match(key or ''):
			return {'ok': False, 'reason': 'bad key'}
		if runtime:
			self.runtimes[key] = runtime
			while len(self.runtimes) > 50: self.runtimes.pop(next(iter(self.runtimes)))
		runtime = self.runtimes.get(key)
		with self.lock:
			plock = self.prep_locks.setdefault(key, threading.Lock())
		with plock:
			with self.lock:
				s = self.sessions.get(key)
			if s and s.ready and not s.closed and s.incomplete is None:
				s.last_use = time.time()
				return s.info
			if s and s.incomplete is not None:
				return {'ok': False, 'reason': 'release incomplete on Easynews (~%d%% missing)' % s.incomplete}
			path = self.nzb_path(key)
			if not os.path.exists(path):
				return {'ok': False, 'reason': 'NZB not found'}
			cfg = self.cfg_provider()
			if not cfg or not cfg.get('user') or not cfg.get('password'):
				return {'ok': False, 'reason': 'Easynews credentials not set'}
			s = Session(key, path, cfg, self.log, self.on_incomplete, self.on_close, runtime=runtime, ram=self.ram, budget=self.budget, want=want, warm_pool=self.warm_pool)
			try:
				info = s.prepare()
			except core.NNTPAuthError as e:
				s.close()
				return {'ok': False, 'reason': 'Easynews login refused (%s)' % e}
			except Exception as e:
				s.close()
				self.log('USENET: prepare %s failed: %s: %s' % (key[:8], type(e).__name__, e))
				return {'ok': False, 'reason': str(e) or type(e).__name__}
			with self.lock:
				old = self.sessions.pop(key, None)
				others = list(self.sessions.values())
				self.sessions[key] = s
				extra = []
				while len(self.sessions) > MAX_SESSIONS:
					extra.append(self.sessions.popitem(last=False)[1])
			for o in ([old] if old else []) + extra:
				o.close()
			for other in others:
				if other not in extra:
					other.trim_cache()
			return info

	def get(self, key):
		with self.lock:
			s = self.sessions.get(key)
		if s and s.ready and not s.closed:
			return s
		return None

	def close(self, key=None):
		with self.lock:
			if key is None:
				items = list(self.sessions.values()); self.sessions.clear()
			else:
				s = self.sessions.pop(key, None); items = [s] if s else []
		for s in items:
			s.close()
		if key is None:
			self.warm_pool.close()

	def reap(self):
		now = time.time()
		with self.lock:
			dead = [k for k, s in self.sessions.items()
					if now - s.last_use > SESSION_IDLE_SECS and not s.readers]
			idle = [s for k, s in self.sessions.items()
					if k not in dead and now - s.last_use > CONN_IDLE_SECS and not s.readers]
		for k in dead:
			self.close(k)
		for s in idle:
			s.trim_cache()
		self.warm_pool.reap()


class _Server(ThreadingMixIn, HTTPServer):
	daemon_threads = True
	allow_reuse_address = True
	engine = None


class _Handler(BaseHTTPRequestHandler):
	protocol_version = 'HTTP/1.1'
	server_version = 'luc_kodi-usenet'

	def log_message(self, fmt, *args):
		pass

	def _send_plain(self, code, body, ctype='text/plain'):
		if isinstance(body, str):
			body = body.encode('utf-8')
		self.send_response(code)
		self.send_header('Content-Type', ctype)
		self.send_header('Content-Length', str(len(body)))
		self.send_header('Connection', 'close')
		self.end_headers()
		if self.command != 'HEAD':
			try: self.wfile.write(body)
			except Exception: pass
		self.close_connection = True

	def do_HEAD(self):
		self.do_GET()

	def do_GET(self):
		engine = self.server.engine
		parts = [p for p in self.path.split('?', 1)[0].split('/') if p]
		if not parts:
			return self._send_plain(404, 'not found')
		if parts[0] == 'ping':
			return self._send_plain(200, 'luc_kodi-usenet')
		if parts[0] == 'prepare' and len(parts) >= 2:
			rt = want = None
			if '?' in self.path:   # v2.0.32 (N3): ?rt=<segundos de video>
				from urllib.parse import parse_qs
				qs = parse_qs(self.path.split('?', 1)[1])
				try: rt = int((qs.get('rt') or [0])[0])
				except (TypeError, ValueError): rt = None
				# v2.0.36: ?s=<temporada>&e=<episodio> para un pack
				try: want = (int(qs['s'][0]), int(qs['e'][0]))
				except (KeyError, IndexError, TypeError, ValueError): want = None
			info = engine.prepare(parts[1], runtime=rt, want=want)
			return self._send_plain(200, json.dumps(info), 'application/json')
		if parts[0] == 'close' and len(parts) >= 2:
			engine.close(parts[1])
			return self._send_plain(200, 'closed')
		if parts[0] == 'stream' and len(parts) >= 2:
			return self._stream(engine, parts[1])
		if parts[0] == 'sub' and len(parts) >= 3:
			# v2.0.42: /sub/<clave>/<n>/<nombre>: un subtitulo suelto del NZB
			s = engine.get(parts[1])
			try:
				data = s.subtitle(int(parts[2])) if s is not None else None
			except Exception as e:
				engine.log('USENET: subtitle %s/%s not served: %s: %s' % (parts[1][:8], parts[2], type(e).__name__, e))
				data = None
			if data is None:
				return self._send_plain(404, 'no subtitle')
			return self._send_plain(200, data, 'application/octet-stream')
		return self._send_plain(404, 'not found')

	def _stream(self, engine, key):
		s = engine.get(key)
		if s is None:
			# Kodi puede volver a una URL tras cerrar la sesion por inactividad
			info = engine.prepare(key)
			s = engine.get(key) if info.get('ok') else None
			if s is None:
				return self._send_plain(404, info.get('reason') or 'no session')
		total = s.total
		start, end = 0, total - 1
		rng = self.headers.get('Range')
		partial = False
		if rng:
			m = re.match(r'^bytes=(\d*)-(\d*)$', rng.strip())
			if not m or (not m.group(1) and not m.group(2)):
				self.send_response(416)
				self.send_header('Content-Range', 'bytes */%d' % total)
				self.send_header('Content-Length', '0')
				self.end_headers()
				return
			a, b = m.group(1), m.group(2)
			if a == '' and b:
				start = max(0, total - int(b))
			else:
				start = int(a or 0)
				if b: end = min(int(b), total - 1)
			partial = True
		if start >= total or start > end:
			self.send_response(416)
			self.send_header('Content-Range', 'bytes */%d' % total)
			self.send_header('Content-Length', '0')
			self.end_headers()
			return
		length = end - start + 1
		self.send_response(206 if partial else 200)
		self.send_header('Content-Type', CONTENT_TYPES.get(s.container, 'application/octet-stream'))
		self.send_header('Accept-Ranges', 'bytes')
		self.send_header('Content-Length', str(length))
		if partial:
			self.send_header('Content-Range', 'bytes %d-%d/%d' % (start, end, total))
		self.end_headers()
		if self.command == 'HEAD':
			return
		reader = '%s-%s' % (threading.get_ident(), time.time())
		try:
			for chunk in s.iter_range(start, end, reader):
				self.wfile.write(chunk)
		except (BrokenPipeError, ConnectionResetError, ConnectionAbortedError, socket.timeout):
			pass   # Kodi corta la conexion al hacer seek: es lo normal
		except SessionError as e:
			engine.log('USENET: stream %s stopped: %s' % (key[:8], e))
			trigger = False
			with s.lock:
				if s.incomplete is not None and not s.rollover_triggered:
					s.rollover_triggered = True
					trigger = True
			if trigger:
				try:
					import xbmc, xbmcgui
					if xbmcgui.Window(10000).getProperty('luc_kodi.rollover'):
						xbmc.executebuiltin('RunPlugin(plugin://plugin.video.luc_kodi/?action=play_rollover)')
				except Exception:
					pass
		except Exception as e:
			engine.log('USENET: stream %s error: %s: %s' % (key[:8], type(e).__name__, e))
		finally:
			s.drop_reader(reader)
			self.close_connection = True


class StreamServer(object):
	def __init__(self, nzb_dir, cfg_provider, log=_noop_log, ports=PORT_RANGE, on_incomplete=None, on_close=None):
		self.engine = Engine(nzb_dir, cfg_provider, log, on_incomplete, on_close)
		self.log = log
		self.ports = ports
		self.httpd = None
		self.port = None
		self._stop = threading.Event()

	def start(self):
		for p in self.ports:
			try:
				httpd = _Server(('127.0.0.1', p), _Handler)
			except OSError:
				continue
			httpd.engine = self.engine
			self.httpd, self.port = httpd, p
			t = threading.Thread(target=httpd.serve_forever, kwargs={'poll_interval': 0.5}, name='usenet-httpd')
			t.daemon = True
			t.start()
			r = threading.Thread(target=self._reaper, name='usenet-reaper')
			r.daemon = True
			r.start()
			self.log('USENET: stream server listening on 127.0.0.1:%d' % p)
			return p
		self.log('USENET: no free port for the stream server')
		return None

	def _reaper(self):
		while not self._stop.wait(30):
			try: self.engine.reap()
			except Exception: pass

	def stop(self):
		self._stop.set()
		try: self.engine.close()
		except Exception: pass
		if self.httpd:
			try:
				self.httpd.shutdown()
				self.httpd.server_close()
			except Exception: pass