# -*- coding: utf-8 -*-
"""
	luc_kodi Add-on

	v2.0.41 -- the background work steps aside while the user is browsing.

	Kodi runs the service and every plugin call in one process, and all its
	Python interpreters share a single GIL (PythonInvoker uses Py_NewInterpreter
	in Kodi 21 and 22). While the precache, the Catalog Update or the light-meta
	upgrade decode TMDb details, each click waits for its turn.

	luc_kodi.py marks the start and the end of every plugin call in a window
	property; the background workers wait at their semaphore while the mark is
	there. A mark older than MAX_AGE seconds is ignored (a playback keeps its
	call alive for the whole film), and no worker waits more than MAX_WAIT.
"""
import time
from threading import Semaphore

PROP = 'luc_kodi.nav_busy'
MAX_AGE = 20.0
MAX_WAIT = 20.0
_POLL = 0.25
_MINE = []


def _window():
	from resources.lib.modules import control
	return control.homeWindow


def start():
	try:
		stamp = '%.3f' % time.time()
		_window().setProperty(PROP, stamp)
		_MINE[:] = [stamp]
	except Exception:
		pass


def end():
	# only the call that set the mark clears it: with several calls at once
	# (skin widgets) the last one to start keeps the pause
	try:
		if _MINE and _window().getProperty(PROP) == _MINE[0]:
			_window().clearProperty(PROP)
	except Exception:
		pass


def busy():
	try:
		value = _window().getProperty(PROP)
		if not value: return False
		# the call that set the mark is never paused by it (Tools > Update
		# Catalog runs the same workers inside a plugin call)
		if _MINE and value == _MINE[0]: return False
		return (time.time() - float(value)) < MAX_AGE
	except Exception:
		return False


def wait_idle(max_wait=MAX_WAIT):
	limit = time.time() + max_wait
	try:
		from resources.lib.modules import control
		monitor = control.monitor
	except Exception:
		monitor = None
	while time.time() < limit and busy():
		if monitor is not None:
			if monitor.waitForAbort(_POLL): return
		else:
			time.sleep(_POLL)


class PoliteSemaphore(Semaphore):
	"""A Semaphore whose acquire() first lets a running plugin call finish."""
	def acquire(self, blocking=True, timeout=None):
		if blocking: wait_idle()
		if timeout is None: return Semaphore.acquire(self, blocking)
		return Semaphore.acquire(self, blocking, timeout)

	__enter__ = acquire
