# -*- coding: utf-8 -*-
"""
	luc_kodi Add-on
	Title substitution database - used to remap show/movie titles
	when scraping for subtitles (e.g. "Fargo" → "Fargo US")
"""
from sqlite3 import dbapi2 as db
from resources.lib.modules import control

_WAL_SET = [False] # v2.0.42: journal_mode WAL fijado una vez por proceso


def substitute_get(key):
	"""Return the substituted title for 'key', or 'key' itself if no substitution exists."""
	try:
		dbcon = get_connection()
		dbcur = get_connection_cursor(dbcon)
		ck_table = dbcur.execute('''SELECT * FROM sqlite_master WHERE type='table' AND name='substitle';''').fetchone()
		if not ck_table:
			return key
		keyLower = str(key).lower()
		results = dbcur.execute('''SELECT * FROM substitle WHERE originalTitle=?''', (keyLower,)).fetchone()
		if results:
			return results.get('subTitle', '')
		else:
			return key
	except Exception:
		from resources.lib.modules import log_utils
		log_utils.error()
		return None
	finally:
		dbcur.close(); dbcon.close()


def all_substitutes(self):
	"""Return all stored title substitutions as a list of dicts."""
	results = []
	try:
		dbcon = get_connection()
		dbcur = get_connection_cursor(dbcon)
		sub_table = dbcur.execute('''SELECT * FROM sqlite_master WHERE type='table' AND name='substitle';''').fetchone()
		if not sub_table:
			return results
		results1 = dbcur.execute('''SELECT * FROM substitle''').fetchall()
		if results1:
			results = results1
		return results
	except Exception:
		from resources.lib.modules import log_utils
		log_utils.error()
		return results
	finally:
		dbcur.close(); dbcon.close()


def sub_insert(originalTitle, subTitle):
	"""Insert a new title substitution into the database."""
	try:
		dbcon = get_connection()
		dbcur = get_connection_cursor(dbcon)
		dbcur.execute('''CREATE TABLE IF NOT EXISTS substitle (ID Integer PRIMARY KEY AUTOINCREMENT, originalTitle TEXT, subTitle TEXT);''')
		key = str(originalTitle).lower()
		dbcur.execute('''INSERT OR REPLACE INTO substitle Values (?, ?, ?)''', (None, key, subTitle))
		dbcur.connection.commit()
	except Exception:
		from resources.lib.modules import log_utils
		log_utils.error()
	finally:
		dbcur.close(); dbcon.close()


def clear_substitute(table, key):
	"""Delete a title substitution by originalTitle key."""
	cleared = False
	try:
		dbcon = get_connection()
		dbcur = dbcon.cursor()
		dbcur.execute('''DELETE FROM {} WHERE originalTitle=?;'''.format(table), (key,))
		dbcur.connection.commit()
		control.refresh()
		cleared = True
	except Exception:
		from resources.lib.modules import log_utils
		log_utils.error()
		cleared = False
	finally:
		dbcur.close(); dbcon.close()
	return cleared


def get_connection():
	if not control.existsPath(control.dataPath):
		control.makeFile(control.dataPath)
	dbcon = db.connect(control.subsFile, timeout=60)
	# v2.0.42: WAL en vez de sin diario, como traktsync en la 2.0.41: un cierre de Kodi
	# a mitad de escritura ya no puede dejar la base corrupta y se puede leer mientras
	# otro hilo escribe. WAL queda guardado en el fichero: basta fijarlo una vez por proceso.
	if not _WAL_SET[0]:
		try:
			dbcon.execute('''PRAGMA journal_mode = WAL''')
			_WAL_SET[0] = True
		except Exception: pass
	dbcon.execute('''PRAGMA synchronous = NORMAL''')
	dbcon.execute('''PRAGMA temp_store = memory''')
	dbcon.execute('''PRAGMA mmap_size = 268435456''')
	dbcon.row_factory = _dict_factory
	return dbcon


def get_connection_cursor(dbcon):
	return dbcon.cursor()


def _dict_factory(cursor, row):
	d = {}
	for idx, col in enumerate(cursor.description):
		d[col[0]] = row[idx]
	return d


def get_connection_subs():
	control.makeFile(control.dataPath)
	conn = db.connect(control.subsFile)
	conn.row_factory = _dict_factory
	return conn
