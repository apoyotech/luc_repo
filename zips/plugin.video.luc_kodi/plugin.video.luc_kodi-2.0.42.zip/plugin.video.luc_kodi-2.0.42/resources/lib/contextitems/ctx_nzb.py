# -*- coding: utf-8 -*-
"""
	luc_kodi Add-on
	Global context entry "Play this NZB" (addon.xml kodi.context.item, v2.0.37).
	Shown on any .nzb / .nzb.gz file Kodi lists (file manager, sources, USB);
	see modules/usenet_local.py
"""

import sys
from urllib.parse import quote_plus

import xbmc

if __name__ == '__main__':
	try:
		path = sys.listitem.getPath()
	except Exception:
		path = xbmc.getInfoLabel('ListItem.FileNameAndPath')
	if path:
		xbmc.executebuiltin('RunPlugin(plugin://plugin.video.luc_kodi/?action=tools_playNzb&path=%s)' % quote_plus(path))
