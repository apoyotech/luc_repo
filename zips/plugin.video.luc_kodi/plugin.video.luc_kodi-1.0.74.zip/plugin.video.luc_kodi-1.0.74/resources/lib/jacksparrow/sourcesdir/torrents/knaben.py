"""
	jacksparrowscrapers Project
"""

import re
from urllib.parse import quote_plus, unquote_plus
from resources.lib.jacksparrow import cache
from resources.lib.jacksparrow import client
from resources.lib.jacksparrow import source_utils
from resources.lib.jacksparrow import workers


class source:
	priority = 3
	pack_capable = True
	hasMovies = True
	hasEpisodes = True
	def __init__(self):
		self.language = ['en']
		# knaben.org es el dominio canonico; knaben.eu es mirror activo
		# (verificado mayo 2026). __get_base_url itera la lista y valida
		# por <title>Knaben</title> antes de cachear.
		self.domains = ['knaben.org', 'knaben.eu']
		self._base_link = None
		self.moviesearch = '/search/index.php?cat=003000000&q={0}&search=fast'
		self.tvsearch = '/search/index.php?cat=002000000&q={0}&search=fast'
		self.min_seeders = 0

	@property
	def base_link(self):
		if not self._base_link:
			self._base_link = cache.get(self.__get_base_url, 120, 'https://%s' % self.domains[0])
		return self._base_link

	def __get_base_url(self, fallback):
		for domain in self.domains:
			try:
				url = 'https://%s' % domain
				result = client.request(url, limit=1, timeout=5)
				# v1.0.19: fix de regex rota — la 'r' estaba dentro del string
				# en lugar de prefijar la cadena como raw-string, asi que la
				# regex buscaba literalmente 'r<title>' y nunca matcheaba.
				# Consecuencia: el failover a knaben.eu (anadido en v1.0.15)
				# nunca se ejecutaba — siempre caia silenciosamente al
				# fallback que casualmente era knaben.org.
				try: result = re.search(r'<title>(.+?)</title>', result, re.I).group(1)
				except: result = None
				if result and 'Knaben' in result: return url
			except:
				source_utils.scraper_error('KNABEN')
		return fallback

	def sources(self, data, hostDict):
		self._results = []
		if not data: return self._results
		self._results_append = self._results.append
		try:
			self.aliases = data['aliases']
			self.year = data['year']
			if 'tvshowtitle' in data:
				self.title = data['tvshowtitle'].replace('&', 'and').replace('Special Victims Unit', 'SVU').replace('/', ' ').replace('$', 's')
				self.episode_title = data['title']
				self.hdlr = 'S%02dE%02d' % (int(data['season']), int(data['episode']))
				search_link = self.tvsearch
			else:
				self.title = data['title'].replace('&', 'and').replace('/', ' ').replace('$', 's')
				self.episode_title = None
				self.hdlr = self.year
				search_link = self.moviesearch
			query = '%s %s' % (re.sub(r'[^A-Za-z0-9\s\.-]+', '', self.title), self.hdlr)
			urls = []
			url = '%s%s' % (self.base_link, search_link.format(quote_plus(query)))
			urls.append(url)
			# if url.endswith('field=size&sorder=desc'): urls.append(url.rsplit("/", 1)[0] + '/2/')
			# else: urls.append(url + '/2/')
			# log_utils.log('urls = %s' % urls)
			self.undesirables = source_utils.get_undesirables()
			self.check_foreign_audio = source_utils.check_foreign_audio()
			threads = []
			append = threads.append
			for url in urls:
				append(workers.Thread(self.get_sources, url))
			[i.start() for i in threads]
			[i.join() for i in threads]
			return self._results
		except:
			source_utils.scraper_error('KNABEN')
			return self._results

	def get_sources(self, url):
		# log_utils.log('url = %s' % url)
		try:
			results = client.request(url, timeout=7)
			if not results: return
			rows = client.parseDOM(results, 'tr', attrs={'class': 'text-nowrap border-start'})
		except:
			source_utils.scraper_error('KNABEN')
			return
		for row in rows:
			try:
				columns = re.findall(r'<td.*?>(.+?)</td>', row, re.DOTALL)

				url = unquote_plus(columns[1]).replace('&amp;', '&')
				try: url = re.search(r'(magnet:.+?)&tr=', url, re.I).group(1).replace(' ', '.')
				except: continue
				# v1.0.54: la regex antigua exigia un '&' DETRAS del hash, asi que
				# cuando btih era el ultimo parametro del magnet la fila reventaba
				# con AttributeError y se perdia. Ahora el hash se captura por su
				# propio alfabeto (hex 40 / base32 32) sin depender de lo de detras.
				hash_m = re.search(r'btih:([a-zA-Z0-9]{32,40})', url, re.I)
				if not hash_m: continue
				hash = hash_m.group(1)
				# v1.0.54: si el magnet no trae '&dn=' (mismos magnets minimos que
				# antes reventaban en la regex del hash), el nombre se saca de la
				# columna de titulo de la propia fila en vez de perder el resultado
				# con IndexError.
				if '&dn=' in url:
					name = source_utils.clean_name(unquote_plus(url.split('&dn=')[1])) # some links on kickass dbl encoded
				else:
					name = source_utils.clean_name(re.sub(r'<[^>]+>', '', columns[0]).strip())
					if not name: continue

				if not source_utils.check_title(self.title, self.aliases, name, self.hdlr, self.year): continue
				name_info = source_utils.info_from_name(name, self.title, self.year, self.hdlr, self.episode_title)
				if source_utils.remove_lang(name_info, self.check_foreign_audio): continue
				if self.undesirables and source_utils.remove_undesirables(name_info, self.undesirables): continue

				if not self.episode_title: #filter for eps returned in movie query (rare but movie and show exists for Run in 2020)
					ep_strings = [r'[.-]s\d{2}e\d{2}([.-]?)', r'[.-]s\d{2}([.-]?)', r'[.-]season[.-]?\d{1,2}[.-]?']
					name_lower = name.lower()
					if any(re.search(item, name_lower) for item in ep_strings): continue

				try:
					seeders = int(columns[4].replace(',', ''))
					if self.min_seeders > seeders: continue
				except: seeders = 0

				quality, info = source_utils.get_release_quality(name_info, url)
				info += [t for t in source_utils.get_extra_tags(name) if t not in info]
				try:
					dsize, isize = source_utils._size(columns[2].split('<')[0])
					info.insert(0, isize)
				except: dsize = 0
				info = ' | '.join(info)
				self._results_append({'provider': 'knaben', 'source': 'torrent', 'seeders': seeders, 'hash': hash, 'name': name, 'name_info': name_info,
												'quality': quality, 'language': 'en', 'url': url, 'info': info, 'direct': False, 'debridonly': True, 'size': dsize})
			except:
				source_utils.scraper_error('KNABEN')

	def sources_packs(self, data, hostDict, search_series=False, total_seasons=None, bypass_filter=False):
		self._results = []
		if not data: return self._results
		self._results_append = self._results.append
		try:
			self.search_series = search_series
			self.total_seasons = total_seasons
			self.bypass_filter = bypass_filter

			self.title = data['tvshowtitle'].replace('&', 'and').replace('Special Victims Unit', 'SVU').replace('/', ' ').replace('$', 's')
			self.aliases = data['aliases']
			self.imdb = data['imdb']
			self.year = data['year']
			self.season_x = data['season']
			self.season_xx = self.season_x.zfill(2)
			self.undesirables = source_utils.get_undesirables()
			self.check_foreign_audio = source_utils.check_foreign_audio()

			query = re.sub(r'[^A-Za-z0-9\s\.-]+', '', self.title)
			if search_series:
				queries = [
						self.tvsearch.format(quote_plus(query + ' Season')),
						self.tvsearch.format(quote_plus(query + ' Complete'))]
			else:
				queries = [
							self.tvsearch.format(quote_plus(query + ' S%s' % self.season_xx)),
							self.tvsearch.format(quote_plus(query + ' Season %s' % self.season_x))]
			threads = []
			append = threads.append
			for url in queries:
				link = '%s%s' % (self.base_link, url)
				append(workers.Thread(self.get_sources_packs, link))
			[i.start() for i in threads]
			[i.join() for i in threads]
			return self._results
		except:
			source_utils.scraper_error('KNABEN')
			return self._results

	def get_sources_packs(self, link):
		try:
			results = client.request(link, timeout=7)
			if not results: return
			rows = client.parseDOM(results, 'tr', attrs={'class': 'text-nowrap border-start'})
		except:
			source_utils.scraper_error('KNABEN')
			return
		for row in rows:
			try:
				columns = re.findall(r'<td.*?>(.+?)</td>', row, re.DOTALL)

				url = unquote_plus(columns[1]).replace('&amp;', '&')
				try: url = re.search(r'(magnet:.+?)&tr=', url, re.I).group(1).replace(' ', '.')
				except: continue
				
				# v1.0.54: la regex antigua exigia un '&' DETRAS del hash, asi que
				# cuando btih era el ultimo parametro del magnet la fila reventaba
				# con AttributeError y se perdia. Ahora el hash se captura por su
				# propio alfabeto (hex 40 / base32 32) sin depender de lo de detras.
				hash_m = re.search(r'btih:([a-zA-Z0-9]{32,40})', url, re.I)
				if not hash_m: continue
				hash = hash_m.group(1)
				# v1.0.54: si el magnet no trae '&dn=' (mismos magnets minimos que
				# antes reventaban en la regex del hash), el nombre se saca de la
				# columna de titulo de la propia fila en vez de perder el resultado
				# con IndexError.
				if '&dn=' in url:
					name = source_utils.clean_name(unquote_plus(url.split('&dn=')[1])) # some links on kickass dbl encoded
				else:
					name = source_utils.clean_name(re.sub(r'<[^>]+>', '', columns[0]).strip())
					if not name: continue

				episode_start, episode_end = 0, 0
				if not self.search_series:
					if not self.bypass_filter:
						valid, episode_start, episode_end = source_utils.filter_season_pack(self.title, self.aliases, self.year, self.season_x, name)
						if not valid: continue
					package = 'season'

				elif self.search_series:
					if not self.bypass_filter:
						valid, last_season = source_utils.filter_show_pack(self.title, self.aliases, self.imdb, self.year, self.season_x, name, self.total_seasons)
						if not valid: continue
					else: last_season = self.total_seasons
					package = 'show'

				name_info = source_utils.info_from_name(name, self.title, self.year, season=self.season_x, pack=package)
				if source_utils.remove_lang(name_info, self.check_foreign_audio): continue
				if self.undesirables and source_utils.remove_undesirables(name_info, self.undesirables): continue
				try:
					seeders = int(columns[4].replace(',', ''))
					if self.min_seeders > seeders: continue
				except: seeders = 0

				quality, info = source_utils.get_release_quality(name_info, url)
				info += [t for t in source_utils.get_extra_tags(name) if t not in info]
				try:
					dsize, isize = source_utils._size(columns[2].split('<')[0])
					info.insert(0, isize)
				except: dsize = 0
				info = ' | '.join(info)
				item = {'provider': 'knaben', 'source': 'torrent', 'seeders': seeders, 'hash': hash, 'name': name, 'name_info': name_info, 'quality': quality,
							'language': 'en', 'url': url, 'info': info, 'direct': False, 'debridonly': True, 'size': dsize, 'package': package}
				if self.search_series: item.update({'last_season': last_season})
				elif episode_start: item.update({'episode_start': episode_start, 'episode_end': episode_end}) # for partial season packs
				self._results_append(item)
			except:
				source_utils.scraper_error('knaben')
