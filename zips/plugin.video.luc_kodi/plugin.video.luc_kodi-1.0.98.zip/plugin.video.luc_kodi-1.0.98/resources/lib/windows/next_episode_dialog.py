# -*- coding: utf-8 -*-
"""
	luc_kodi Add-on

	Dialogo de siguiente episodio (PlayNext).

	v1.0.98 -- issue #2 de GitHub. Hasta la 1.0.97 el dialogo solo salia con
	la reproduccion ya parada y, al agotarse la cuenta atras, se cerraba SIEMPRE
	como "Not Now": el ajuste "Default action on timeout" no se leia en ningun
	sitio (solo lo usaba el popup heredado playnext.xml, que ya nadie abre).
	Con el valor por defecto "Play Next" el usuario veia "Closes in 0s" y se
	quedaba sin siguiente episodio.

	Ahora hay dos modos:
	  - overlay=True: el dialogo sale DURANTE los creditos, encima del video
	    (sin fondo negro ni fanart). La cuenta atras sigue al reloj del video,
	    se congela si el usuario pausa y, al llegar a cero, aplica la accion
	    elegida en los ajustes: siguiente episodio, parar, o pausar y esperar.
	  - overlay=False: el dialogo de siempre, con la reproduccion ya parada.
	    La accion por defecto solo se aplica si el episodio llego a su final
	    (natural_end); si el usuario paro a mano, la cuenta atras solo cierra.
"""

import xbmc
from resources.lib.modules.control import addonFanart
from resources.lib.windows.base import BaseDialog

monitor = xbmc.Monitor()

RESULT_CANCEL       = 0
RESULT_AUTOPLAY     = 1
RESULT_CHOOSE_SRC   = 2
RESULT_STOP         = 3   # v1.0.98: parar la reproduccion y no seguir
_AUTOCLOSE_SECS     = 30

# Indices del enum playnext.default.action (Kodi guarda el INDICE).
ACTION_PLAY_NEXT    = 0
ACTION_STOP         = 1
ACTION_WAIT         = 2

_CTRL_AUTOPLAY      = 3021
_CTRL_NOT_NOW       = 3022
_CTRL_CHOOSE_SRC    = 3023

_ACTION_STOP        = 13
_PAUSE_ACTIONS      = (12, 79, 229)   # ACTION_PAUSE, ACTION_PLAYER_PLAY, ACTION_PLAYER_PLAYPAUSE

_NUM = '[COLOR FF00FA9A][B]%d[/B][/COLOR]'


class NextEpisodeDialog(BaseDialog):
	def __init__(self, *args, **kwargs):
		BaseDialog.__init__(self, args)
		self.show_title = kwargs.get('show_title', '')
		self.ep_label   = kwargs.get('ep_label', '')
		self.fanart     = kwargs.get('fanart', '') or addonFanart()
		self.clearlogo  = kwargs.get('clearlogo', '')
		self.thumb      = kwargs.get('thumb', '')
		self.overlay    = bool(kwargs.get('overlay', False))
		self.natural_end = bool(kwargs.get('natural_end', False))
		self.running_path = kwargs.get('running_path', '') or ''
		try: self.countdown = int(kwargs.get('countdown', _AUTOCLOSE_SECS))
		except (TypeError, ValueError): self.countdown = _AUTOCLOSE_SECS
		try: self.timeout_action = int(kwargs.get('timeout_action', ACTION_PLAY_NEXT))
		except (TypeError, ValueError): self.timeout_action = ACTION_PLAY_NEXT
		if self.timeout_action not in (ACTION_PLAY_NEXT, ACTION_STOP, ACTION_WAIT):
			self.timeout_action = ACTION_PLAY_NEXT
		self.player     = xbmc.Player()
		self.result     = RESULT_CANCEL
		self.closed     = False
		self.paused_by_us = False

	def onInit(self):
		self.setProperty('luc_kodi.show_title', self.show_title)
		self.setProperty('luc_kodi.ep_label',   self.ep_label)
		self.setProperty('luc_kodi.fanart',     self.fanart)
		self.setProperty('luc_kodi.clearlogo',  self.clearlogo)
		self.setProperty('luc_kodi.thumb',      self.thumb)
		self.setProperty('luc_kodi.next_ep_overlay', 'true' if self.overlay else '')
		# Con "Play Next" el foco va a Auto-Play: OK en el mando = verlo ya.
		try:
			if self._effective_action() == ACTION_PLAY_NEXT: self.setFocusId(_CTRL_AUTOPLAY)
			else: self.setFocusId(_CTRL_NOT_NOW)
		except Exception: pass
		self._run_countdown()

	def run(self):
		self.doModal()
		self.clearProperties()
		return self.result

	def _effective_action(self):
		"""Tras una parada MANUAL la cuenta atras solo cierra: el usuario ya ha
		dicho que queria parar, no se le arranca otro episodio a sus espaldas."""
		if not self.overlay and not self.natural_end:
			return ACTION_STOP
		return self.timeout_action

	def _doClose(self, result=RESULT_CANCEL):
		if self.closed:
			return
		self.result = result
		self.closed = True
		self.close()

	def _resume_if_we_paused(self):
		if self.paused_by_us:
			self.paused_by_us = False
			try:
				if self.player.isPlayingVideo() and xbmc.getCondVisibility('Player.Paused'):
					self.player.pause()
			except Exception: pass

	def onAction(self, action):
		try: action_id = action.getId()
		except AttributeError: action_id = action
		if self.overlay and action_id == _ACTION_STOP:
			self._doClose(RESULT_STOP)
		elif self.overlay and action_id in _PAUSE_ACTIONS:
			try: self.player.pause()
			except Exception: pass
		elif action_id in self.closing_actions:
			self._resume_if_we_paused()
			self._doClose(RESULT_CANCEL)

	def onClick(self, control_id):
		if   control_id == _CTRL_AUTOPLAY:    self._doClose(RESULT_AUTOPLAY)
		elif control_id == _CTRL_NOT_NOW:
			self._resume_if_we_paused()
			self._doClose(RESULT_CANCEL)
		elif control_id == _CTRL_CHOOSE_SRC:  self._doClose(RESULT_CHOOSE_SRC)

	def _video_state(self):
		"""('gone'|'other'|'playing', segundos_restantes o None, en_pausa)."""
		try:
			if not self.player.isPlayingVideo(): return 'gone', None, False
			if self.running_path and self.player.getPlayingFile() != self.running_path:
				return 'other', None, False
			remaining = None
			try:
				total = self.player.getTotalTime()
				if total: remaining = max(total - self.player.getTime(), 0)
			except Exception: pass
			return 'playing', remaining, bool(xbmc.getCondVisibility('Player.Paused'))
		except Exception:
			return 'gone', None, False

	def _set_text(self, countdown, waiting):
		self.setProperty('luc_kodi.next_ep_countdown', str(max(countdown, 0)))
		if waiting:
			text = 'Waiting for your choice'
		else:
			action = self._effective_action()
			if action == ACTION_PLAY_NEXT: text = 'Next episode in ' + _NUM + 's'
			elif action == ACTION_WAIT: text = 'Pauses in ' + _NUM + 's'
			elif self.overlay: text = 'Stops in ' + _NUM + 's'
			else: text = 'Closes in ' + _NUM + 's'
			text = text % max(countdown, 0)
		self.setProperty('luc_kodi.next_ep_countdown_text', text)

	def _run_countdown(self):
		countdown = self.countdown
		waiting = False
		while not self.closed and not monitor.abortRequested():
			frozen = False
			if self.overlay:
				state, remaining, paused = self._video_state()
				if state == 'other':
					self._doClose(RESULT_CANCEL)   # el usuario salto a otro video
					return
				if state == 'gone':
					# El video termino con el dialogo abierto: pasa a modo
					# post-stop y la accion por defecto se aplica ya.
					self.overlay = False
					self.natural_end = True
					self.setProperty('luc_kodi.next_ep_overlay', '')
					action = self._effective_action()
					if action == ACTION_PLAY_NEXT:
						self._doClose(RESULT_AUTOPLAY)
						return
					if action == ACTION_STOP:
						self._doClose(RESULT_CANCEL)
						return
					waiting = True
				else:
					if remaining is not None and not waiting:
						countdown = min(countdown, int(remaining))
					frozen = paused   # en pausa la cuenta no avanza
			if waiting:
				self._set_text(countdown, True)
				xbmc.sleep(500)
				continue
			if countdown < 0:
				action = self._effective_action()
				if action == ACTION_PLAY_NEXT:
					self._doClose(RESULT_AUTOPLAY)
				elif action == ACTION_STOP:
					self._doClose(RESULT_STOP if self.overlay else RESULT_CANCEL)
				else:
					# Pausar y esperar: el dialogo se queda hasta que se elija.
					if self.overlay:
						try:
							if not xbmc.getCondVisibility('Player.Paused'):
								self.player.pause()
								self.paused_by_us = True
						except Exception: pass
					waiting = True
				continue
			self._set_text(countdown, False)
			xbmc.sleep(1000)
			if not frozen:
				countdown -= 1
		if not self.closed:
			self._doClose(RESULT_CANCEL)
