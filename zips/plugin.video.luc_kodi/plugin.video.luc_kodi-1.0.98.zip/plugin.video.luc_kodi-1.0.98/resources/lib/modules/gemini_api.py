# -*- coding: utf-8 -*-
"""
	luc_kodi Add-on
	Gemini API client for AI-powered natural language search.

	v2 changes (debug version):
	- No module-level requests.Session / urllib3.Retry (some Android Kodi builds
	  fail silently on module import otherwise).
	- Manual cache via cache.cache_get/cache_insert (bypasses cache.get()'s
	  bare except that swallowed exceptions).
	- Diagnostic logging via xbmc.log(LOGERROR) which always shows regardless
	  of luc_kodi's debug.enabled setting. Search log for "[luc_kodi-gemini]".
	- Exposes last_error_message() so ai_search can display the real failure
	  reason to the user.

	v3 changes (2026-08, verified against ai.google.dev on 2026-08-16):
	- Model chain rebuilt around the models that are actually GA today.
	  gemini-3.1-flash-lite (the previous default) is DEPRECATED with an
	  announced shutdown of 2027-05-07 and gemini-3.5-flash-lite named as its
	  replacement.
	- temperature/top_p/top_k were deprecated API-wide on 2026-07-21. They are
	  accepted-and-ignored on the current 3.x models and Google states future
	  model generations return HTTP 400 for them. We now send temperature ONLY
	  to the 2.5 models that still honour it, and use a system instruction to
	  carry the determinism that temperature used to provide (Google's own
	  recommended replacement).
	- Request-shape degradation ladder: a HTTP 400 no longer kills the feature.
	  The same request is retried with progressively simpler payloads. This is
	  what makes the addon survive the NEXT parameter deprecation without
	  needing a release.
	- Whole-chain wall-clock budget so a bad day at Google cannot leave a Kodi
	  DialogBusy spinning for minutes.

	v4 changes (2026-09, verified against ai.google.dev on 2026-09-30):
	- gemini-3.8-flash (GA 2026-09-02) joins the chain. The heavier Flash models
	  now get an explicit thinkingLevel ("minimal" where the model accepts it,
	  "low" on 3.7/3.8, which reject "minimal"): their default is "medium", which
	  burns seconds of reasoning on a one-line intent extraction.
	- Since 2026-09-18 Google serves the 2.5 models only to projects that already
	  used them; every new key gets HTTP 404 "no longer available to new users".
	  2.5 Flash-Lite moved to the END of the chain, and a model that answers 404
	  on every key is skipped for the rest of the session.
	- A rejected key no longer stops the search: the next key is tried. Old
	  "AIza..." standard keys are being blocked (unrestricted ones since
	  2026-06-19) while new AI Studio keys are "AQ." auth keys, so a mix of one
	  dead and one good key is the normal state of a migrating user.
	- The Gemini-side refusal of a thinking level only drops the thinking level,
	  never the schema, and only for that model.
"""

import json
import hashlib
import time
import xbmc
from resources.lib.database import cache
from resources.lib.modules.control import setting as getSetting

base_url = 'https://generativelanguage.googleapis.com/v1beta'
# Default lead: gemini-3.5-flash-lite (GA 2026-07-21). For our use case — short
# prompt-to-intent translation, structured output, no agentic/tool use — the
# Lite line is the right tier: Google positions 3.5 Flash-Lite for low-latency,
# high-throughput execution and simple data extraction, its default thinking
# level is "minimal" (so no reasoning tokens are burned on a one-line query),
# and it is the named replacement for the deprecated 3.1 Flash-Lite.
default_model = 'gemini-3.5-flash-lite'
# Fallback chain used when the primary model fails on all keys with a
# model-generic error (429 quota, 404 model-not-found, 503 unavailable, or a
# 400 that survived the degradation ladder below).
# Rate limits are applied PER PROJECT, not per key, and each model has its own
# quota bucket — so cycling models multiplies available free requests just as
# cycling keys across separate Cloud projects does.
# Order: Lite tier first (best fit + cheapest + least thinking overhead for a
# classification task), then the heavier Flash tier as a quality backstop.
# REMOVED 2026-08-16:
#   - gemini-2.5-pro  (strictest free quota of the whole line, slowest, and the
#                      worst fit for a task that is pure intent extraction —
#                      it was a "last resort" that cost a full timeout to reach
#                      and then failed on quota anyway)
# NOT REMOVED: gemini-3.1-flash-lite is deprecated but stays as a fallback —
#   its shutdown is 2027-05-07 and existing installs still have it selected.
# CHANGED 2026-09-30:
#   - gemini-3.8-flash added (GA 2026-09-02, free tier available).
#   - gemini-2.5-flash-lite moved from 3rd to LAST: since 2026-09-18 Google only
#     serves the 2.5 line to projects that already used it, and a key created
#     now gets HTTP 404 "no longer available to new users". It stays for the
#     long-time users whose projects still have access.
fallback_models = (
	'gemini-3.5-flash-lite',       # GA 2026-07-21 — default; thinking "minimal", built for extraction
	'gemini-3.1-flash-lite',       # GA 2026-05-07 — DEPRECATED, shutdown 2027-05-07; kept for installs still on it
	'gemini-3.6-flash',            # GA 2026-07-21 — accepts thinking "minimal", the fastest of the Flash tier
	'gemini-3.8-flash',            # GA 2026-09-02 — newest Flash; thinking "low" (it rejects "minimal")
	'gemini-3.7-flash',            # GA 2026-08-13 — thinking "low" (it rejects "minimal")
	'gemini-3.5-flash',            # GA 2026-05-19 — legacy Flash, still stable
	'gemini-2.5-flash-lite',       # legacy — only answers for projects that used it before 2026-09-18
)

# Thinking level sent per model (generationConfig.thinkingConfig.thinkingLevel).
# The Flash models default to "medium", which on a TV means several seconds of
# reasoning before a one-line JSON answer. Levels from the table in
# ai.google.dev/gemini-api/docs/thinking (2026-09-25): 3.7 and 3.8 Flash accept
# only low/medium/high, the rest also accept "minimal". The Lite models already
# default to "minimal", so nothing is sent for them.
_thinking_levels = {
	'gemini-3.6-flash': 'minimal',
	'gemini-3.5-flash': 'minimal',
	'gemini-3.7-flash': 'low',
	'gemini-3.8-flash': 'low',
}
timeout = 25
# Wall-clock ceiling for one interpret_prompt() call across every model and key.
# Without this, a full chain of timeouts is 6 models x 3 keys x 25s = 7.5 minutes
# of DialogBusy on a TV.
total_budget = 45
empty_setting_check = (None, '', 'empty_setting')
cache_prefix = 'gemini_intent::'
cache_ttl_hours = 168  # 1 week per unique prompt
# Bump this whenever prompt_template or the request shape changes materially so
# old cache entries (generated by the previous prompt) are treated as stale.
#   v2 — few-shot examples
#   v3 — 2026-05-21: model chain migration (3.1 Flash-Lite leads, drop 2.0 Flash)
#   v4 — 2026-08-16: model chain migration (3.5 Flash-Lite leads), temperature
#        replaced by a system instruction — same prompt, different determinism
#        mechanism, so old and new responses are not directly comparable.
cache_version = 'v4'
log_tag = '[luc_kodi-gemini]'

# Last diagnostic message (for UI). Cleared on success.
_last_error = ''
# True when the last _call_gemini got 404 from every key (model withdrawn for them).
_last_all_not_found = False

# ──────────────────────────────────────────────────────────────────────
# Request profiles
# ──────────────────────────────────────────────────────────────────────
# Tried in order whenever Google rejects the SHAPE of the request (HTTP 400).
# Each step drops one thing the API may have stopped accepting. Google has now
# deprecated sampling parameters once (2026-07-21) and moved its documented
# structured-output surface to the Interactions API, so treating any single
# generationConfig field as permanent is exactly what breaks addons in the field.
#   0 FULL   — system instruction + JSON mime + JSON schema
#   1 SCHEMA — JSON mime + JSON schema
#   2 JSON   — JSON mime only (the prompt already says "Return ONLY JSON")
#   3 BARE   — no generationConfig at all; _parse_response strips ``` fences
PROFILE_FULL, PROFILE_SCHEMA, PROFILE_JSON, PROFILE_BARE = 0, 1, 2, 3
_MAX_PROFILE = PROFILE_BARE
# Lowest profile known to work in this Kodi session. Once a 400 has proved that
# a field is rejected, every later search in the same session starts below it
# instead of paying the failed round trip again.
_profile_floor = PROFILE_FULL
# Models whose thinkingLevel came back as a 400 in this session: they are asked
# again without it, but the rest of the request (schema, system instruction) is
# kept. Kept apart from _profile_floor because a level is model-specific.
_thinking_rejected = set()
# Models that answered 404 (withdrawn / "no longer available to new users") on
# every configured key: not worth a round trip per key for the rest of the session.
_unavailable_models = set()
# Keys Google refused (invalid, revoked, blocked standard key). Remembered by
# value, so a key the user replaces in settings is tried again automatically.
_rejected_keys = set()
_last_key_error = ''

# Models that still honour the sampling parameters. temperature/top_p/top_k were
# deprecated 2026-07-21; on the 3.x line they are accepted and silently ignored,
# and Google states future generations will return HTTP 400. Sending them buys
# nothing on 3.x and is a live risk, so they go only where they still do work.
_sampling_models = ('gemini-2.5-flash-lite', 'gemini-2.5-flash', 'gemini-2.5-pro')

# Replaces what temperature=0.2 used to do. Google's guidance after the
# deprecation is to steer determinism through instructions instead.
system_instruction = (
	'You are a deterministic parser, not a conversational assistant. '
	'For the same request you always return exactly the same JSON. '
	'You never explain, never apologise and never emit anything but the JSON object.'
)

response_schema = {
	'type': 'object',
	'properties': {
		'media_type': {
			'type': 'string',
			'enum': ['movie', 'tvshow']
		},
		'genres': {
			'type': 'array',
			'items': {'type': 'string'}
		},
		'keywords': {
			'type': 'array',
			'items': {'type': 'string'}
		},
		'people': {
			'type': 'array',
			'items': {'type': 'string'}
		},
		'tone_descriptors': {
			'type': 'array',
			'items': {'type': 'string'}
		},
		'example_titles': {
			'type': 'array',
			'items': {'type': 'string'}
		},
		'year_range': {
			'type': 'object',
			'properties': {
				'start': {'type': ['integer', 'null']},
				'end': {'type': ['integer', 'null']}
			},
			'required': ['start', 'end']
		},
		'spanish_language_preferred': {
			'type': 'boolean'
		},
		'exclude_terms': {
			'type': 'array',
			'items': {'type': 'string'}
		}
	},
	'required': ['media_type', 'genres', 'keywords', 'people', 'tone_descriptors', 'example_titles', 'year_range', 'spanish_language_preferred', 'exclude_terms']
}

prompt_template = '''Interpret this natural-language movie or TV discovery request for a Kodi addon.
The user may write in Spanish or English. Return ONLY JSON matching the provided schema.

Rules:
- Choose exactly one media_type: "movie" or "tvshow".
- The request is always about movies or TV shows.
- If the request is short or title-like, prefer direct title/franchise matches in example_titles.
- genres MUST be short canonical English labels (e.g. action, comedy, drama, sci-fi, thriller, romance, horror, documentary, animation, family) even if the user writes in Spanish.
- Be CONSERVATIVE with genres. Only include a genre if it is clearly implied by the request. When the request is thematic (e.g. "movies with sharks", "time travel movies", "films set in Rome"), prefer putting the theme in keywords and leaving genres empty or with a single broad genre.
- If the request mentions a specific actor, performer, director or creator, put that person in "people".
- Do not treat a named person as just a loose keyword when they are clearly intended as cast or creator guidance.
- keywords should be short specific English thematic terms (single words when possible), not full phrases.
- tone_descriptors should be short mood descriptors in English.
- example_titles should contain at most 3 titles using canonical titles when possible.
- Use null for unknown year_range values.
- Set spanish_language_preferred=true ONLY when the user explicitly asks for Spanish-language productions, mentions Spain or Latin America, or a Spanish/Latin American director. A prompt simply written in Spanish does NOT by itself imply this.
- Do not explain your reasoning.

Examples (for guidance, do NOT copy literally):

Request: "Movies with sharks"
→ { "media_type": "movie", "genres": [], "keywords": ["shark"], "people": [], "tone_descriptors": [], "example_titles": ["Jaws", "The Meg", "47 Meters Down"], "year_range": {"start": null, "end": null}, "spanish_language_preferred": false, "exclude_terms": [] }

Request: "romantic comedy"
→ { "media_type": "movie", "genres": ["comedy", "romance"], "keywords": [], "people": [], "tone_descriptors": ["lighthearted"], "example_titles": [], "year_range": {"start": null, "end": null}, "spanish_language_preferred": false, "exclude_terms": [] }

Request: "Tom Cruise action movies from the 90s"
→ { "media_type": "movie", "genres": ["action"], "keywords": [], "people": ["Tom Cruise"], "tone_descriptors": [], "example_titles": ["Mission: Impossible", "Top Gun"], "year_range": {"start": 1990, "end": 1999}, "spanish_language_preferred": false, "exclude_terms": [] }

Request: "peliculas espanolas de humor negro"
→ { "media_type": "movie", "genres": ["comedy"], "keywords": ["dark humor", "black comedy"], "people": [], "tone_descriptors": ["dark"], "example_titles": ["El dia de la bestia", "Comunidad"], "year_range": {"start": null, "end": null}, "spanish_language_preferred": true, "exclude_terms": [] }

Request: "time travel thrillers"
→ { "media_type": "movie", "genres": ["thriller"], "keywords": ["time travel"], "people": [], "tone_descriptors": ["mind-bending"], "example_titles": ["Primer", "Looper", "Predestination"], "year_range": {"start": null, "end": null}, "spanish_language_preferred": false, "exclude_terms": [] }

User request: %s'''

media_type_aliases = {
	'movie': 'movie', 'film': 'movie', 'pelicula': 'movie', 'peliculas': 'movie',
	'tv': 'tvshow', 'tv_show': 'tvshow', 'tvshow': 'tvshow', 'show': 'tvshow',
	'series': 'tvshow', 'serie': 'tvshow', 'television': 'tvshow'
}


# ──────────────────────────────────────────────────────────────────────
# Public API
# ──────────────────────────────────────────────────────────────────────

def last_error_message():
	"""Returns a short human-readable description of the most recent failure."""
	return _last_error


def gemini_api_keys():
	"""Return list of configured Gemini API keys (1-5), filtering empties and dups."""
	keys = []
	# v1.0.97: five keys. Each one only adds real quota if it lives in its own
	# Google project (rate limits are per project, not per key).
	for setting_id in ('gemini.api.key', 'gemini.api.key2', 'gemini.api.key3', 'gemini.api.key4', 'gemini.api.key5'):
		key = getSetting(setting_id, '')
		# v4: a key pasted from a phone keyboard often carries a trailing space
		# or newline, which Google answers with "API key not valid".
		try: key = key.strip()
		except Exception: pass
		if key in empty_setting_check or key in keys: continue
		keys.append(key)
	return keys


def _usable_keys():
	return [k for k in gemini_api_keys() if k not in _rejected_keys]


def has_gemini_keys():
	return bool(gemini_api_keys())


# Remap legacy / deprecated model strings stored in userdata settings to current
# equivalents. Triggered when an updating user has an older value selected that
# is no longer in the settings dropdown — without this they'd keep hitting a
# dead endpoint until they re-open settings and re-pick.
# Only SHUT DOWN models are remapped. gemini-3.1-flash-lite is deprecated but
# still served until 2027-05-07, so a user who picked it keeps it: silently
# changing a working choice is worse than leaving it until it actually breaks.
_legacy_model_map = {
	'gemini-2.0-flash':                'gemini-3.5-flash-lite',  # shut down 2026-06-01
	'gemini-2.0-flash-lite':           'gemini-3.5-flash-lite',  # shut down 2026-06-01
	'gemini-3-flash-preview':          'gemini-3.6-flash',       # Google's named replacement
	'gemini-3.1-flash-lite-preview':   'gemini-3.1-flash-lite',  # shut down 2026-05-25
	'gemini-3-pro-preview':            'gemini-3.6-flash',       # shut down 2026-03-09
	'gemini-2.5-pro':                  'gemini-3.5-flash-lite',  # dropped from the chain (see above)
}


def gemini_model():
	model = getSetting('gemini.model', '')
	if not model:
		return default_model
	# Auto-migrate legacy stored selections; users see the new dropdown values
	# from then on (Kodi re-saves the resolved value the next time they open settings).
	return _legacy_model_map.get(model, model)


def interpret_prompt(prompt):
	"""Public entry point. Returns normalized intent dict or None.
	Uses manual cache keyed on prompt (168h).
	Automatically falls back through the fallback_models chain when all keys
	hit a model-generic failure (independent quota buckets per model)."""
	global _last_error
	_last_error = ''

	if not prompt:
		_last_error = 'Empty prompt'
		return None
	if not has_gemini_keys():
		_last_error = 'No Gemini API keys configured'
		return None
	prompt = prompt.strip()
	if not prompt:
		_last_error = 'Empty prompt'
		return None

	# Cache is keyed on prompt only (not model) — once we've interpreted a
	# prompt successfully with ANY model, reuse it regardless of which model
	# produced it. Avoids re-hitting Gemini when the user retries the same query.
	cache_key = _make_cache_key(prompt)
	cached = _cache_load(cache_key)
	if cached is not None:
		_log('Cache hit for prompt: %s' % prompt[:60])
		return cached

	# Build the model chain: primary (from settings) first, then fallbacks,
	# deduplicated preserving order.
	primary = gemini_model()
	model_chain = [primary] + [m for m in fallback_models if m != primary]
	skipped = [m for m in model_chain if m in _unavailable_models]
	if skipped and len(skipped) < len(model_chain):
		model_chain = [m for m in model_chain if m not in _unavailable_models]
		_log('Skipping models unavailable to these keys this session: %s' % ', '.join(skipped))

	deadline = time.time() + total_budget
	last_err = 'Unknown error'
	for model in model_chain:
		if time.time() >= deadline:
			_log('Time budget (%ss) exhausted, stopping model chain' % total_budget, level=xbmc.LOGWARNING)
			# Keep whatever the API actually said. Running out of budget is how we
			# STOPPED, not why we failed — a chain of 503s that hits the ceiling
			# should still tell the user Gemini is overloaded, not "timeout".
			if last_err == 'Unknown error':
				last_err = 'BUDGET_EXHAUSTED'
			break
		_log('Calling Gemini for prompt: %s (model=%s)' % (prompt[:60], model))
		raw = _call_gemini(prompt, model, deadline)
		if raw:
			normalized = _normalize(raw)
			if normalized and normalized.get('media_type') in ('movie', 'tvshow'):
				_cache_save(cache_key, normalized)
				_log('Gemini success (model=%s). Intent: media_type=%s genres=%s people=%s' % (
					model,
					normalized.get('media_type'),
					normalized.get('genres'),
					normalized.get('people'),
				))
				return normalized
			_log('Gemini returned unusable payload, trying next model', level=xbmc.LOGWARNING)
			last_err = 'Gemini returned unusable payload'
			continue
		# _last_error was set by _call_gemini — capture and decide
		last_err = _last_error or last_err
		if _last_all_not_found:
			_unavailable_models.add(model)
		# An invalid key is not fixed by any other model, and walking the whole
		# chain would cost the user a minute before telling them what is wrong.
		# v4: _call_gemini already moved on to the next key; reaching here with a
		# key error means every configured key was refused.
		if _is_bad_key(last_err):
			_log('API key rejected — aborting model chain', level=xbmc.LOGERROR)
			break
		# Try the next model when the failure is generic-to-this-model and another
		# model in the chain may succeed:
		#   - 429 / RESOURCE_EXHAUSTED → quota exhausted on every key for this model
		#     (other models have independent quota buckets)
		#   - 404 / NOT_FOUND          → model not available to ANY of our projects yet
		#     (likely a rollout still in progress — fall back to a stable model)
		#   - 503 / UNAVAILABLE        → this model overloaded across all keys
		#     (sibling models may still be serving)
		#   - 400 / INVALID_ARGUMENT   → only reaches here after the whole request
		#     profile ladder failed, i.e. this model rejects something the others
		#     may well accept. Before v3 this aborted the chain outright, which is
		#     how a single deprecated field could take the feature down.
		retriable = (
			'HTTP 429' in last_err or 'RESOURCE_EXHAUSTED' in last_err or
			'HTTP 404' in last_err or 'NOT_FOUND'          in last_err or
			'HTTP 503' in last_err or 'UNAVAILABLE'        in last_err or
			'HTTP 400' in last_err or 'INVALID_ARGUMENT'   in last_err
		)
		if not retriable:
			_log('Non-retriable error — aborting model chain: %s' % last_err, level=xbmc.LOGERROR)
			break
		_log('Model %s exhausted on all keys (%s). Silently trying next model in chain.' % (
			model, last_err.split(':')[0]), level=xbmc.LOGWARNING)

	_last_error = _friendly_error(last_err)
	return None


def _is_bad_key(raw):
	raw = (raw or '').upper()
	return ('API_KEY_INVALID' in raw or 'API KEY NOT VALID' in raw or 'PERMISSION_DENIED' in raw or
			_is_blocked_key(raw) or 'UNAUTHENTICATED' in raw or 'HTTP 401' in raw)


def _is_blocked_key(raw):
	"""Standard 'AIza...' key refused by Google's key policy: unrestricted keys
	since 2026-06-19, dormant ones since 2026-05-07. The cure is not to wait but
	to create a new key, so it gets its own message."""
	raw = (raw or '').upper()
	return 'API_KEY_SERVICE_BLOCKED' in raw or 'UNRESTRICTED' in raw or 'STANDARD KEY' in raw


def _friendly_error(raw):
	"""Humanize known technical errors. Strings come from strings.po so the
	message follows the user's Kodi language — these used to be hardcoded
	Spanish, which every non-Spanish user got regardless of their settings."""
	from resources.lib.modules import control
	if not raw: return control.lang(40620)
	if 'HTTP 429' in raw or 'RESOURCE_EXHAUSTED' in raw:
		return control.lang(40617)
	if 'HTTP 503' in raw or 'UNAVAILABLE' in raw:
		return control.lang(40618)
	if 'BUDGET_EXHAUSTED' in raw or raw.startswith('Timeout'):
		return control.lang(40621)
	if _is_blocked_key(raw):
		return control.lang(40622)
	if _is_bad_key(raw):
		return control.lang(40619)
	if 'HTTP 400' in raw:
		return '%s %s' % (control.lang(40620), raw[:80])
	return raw[:120]


# ──────────────────────────────────────────────────────────────────────
# HTTP call (no session, no retry adapter — one request per key, in-loop)
# ──────────────────────────────────────────────────────────────────────

def _build_payload(prompt, model, profile):
	"""Assemble the generateContent body for a model at a given request profile.
	Returns None when the prompt cannot be formatted."""
	try:
		payload_text = prompt_template % prompt
	except Exception as e:
		_log('Prompt formatting failed: %s' % e, level=xbmc.LOGERROR)
		return None

	payload = {'contents': [{'role': 'user', 'parts': [{'text': payload_text}]}]}
	if profile == PROFILE_BARE:
		return payload

	generation_config = {'responseMimeType': 'application/json'}
	if profile <= PROFILE_SCHEMA:
		generation_config['responseJsonSchema'] = response_schema
	# Sampling parameters only where they still do something (see _sampling_models).
	if model in _sampling_models:
		generation_config['temperature'] = 0.2
	if _sends_thinking(model):
		generation_config['thinkingConfig'] = {'thinkingLevel': _thinking_levels[model]}
	payload['generationConfig'] = generation_config

	if profile == PROFILE_FULL:
		payload['systemInstruction'] = {'parts': [{'text': system_instruction}]}
	return payload


def _sends_thinking(model):
	return model in _thinking_levels and model not in _thinking_rejected


def _is_shape_rejection(err):
	"""True when a 400 looks like 'the API did not like this request body'
	rather than 'your key is wrong'. Only these are worth degrading for."""
	if err.get('status_code') != 400: return False
	if _is_bad_key('%s %s' % (err.get('status'), err.get('message'))): return False
	return True


def _call_gemini(prompt, model, deadline=None):
	global _last_error, _profile_floor, _last_all_not_found, _last_key_error
	_last_all_not_found = False
	try:
		import requests
	except Exception as e:
		_last_error = 'requests import failed: %s' % e
		_log(_last_error, level=xbmc.LOGERROR)
		return None

	api_keys = _usable_keys()
	if not api_keys:
		_last_error = _last_key_error or 'HTTP 400 (INVALID_ARGUMENT): API_KEY_INVALID - every configured key was rejected earlier in this session'
		return None
	url = '%s/models/%s:generateContent' % (base_url, model)

	last_err = 'Unknown error'
	not_found_keys = 0
	for idx, api_key in enumerate(api_keys, start=1):
		headers = {'x-goog-api-key': api_key, 'Content-Type': 'application/json'}
		profile = _profile_floor
		while profile <= _MAX_PROFILE:
			if deadline is not None and time.time() >= deadline:
				_last_error = last_err
				return None
			payload = _build_payload(prompt, model, profile)
			if payload is None:
				_last_error = 'Prompt formatting failed'
				return None
			try:
				body = json.dumps(payload)
			except Exception as e:
				_last_error = 'JSON serialization failed: %s' % e
				_log(_last_error, level=xbmc.LOGERROR)
				return None
			try:
				_log('POST attempt %d to %s (profile=%d)' % (idx, url, profile))
				response = requests.post(url, headers=headers, data=body, timeout=timeout)
			except requests.exceptions.SSLError as e:
				last_err = 'SSL error: %s' % e
				_log(last_err, level=xbmc.LOGERROR)
				break
			except requests.exceptions.ConnectionError as e:
				last_err = 'Connection error: %s' % e
				_log(last_err, level=xbmc.LOGERROR)
				break
			except requests.exceptions.Timeout as e:
				last_err = 'Timeout: %s' % e
				_log(last_err, level=xbmc.LOGERROR)
				break
			except Exception as e:
				last_err = '%s: %s' % (type(e).__name__, e)
				_log('Unexpected request failure: %s' % last_err, level=xbmc.LOGERROR)
				break

			if response.status_code == 200:
				try:
					data = response.json()
				except Exception as e:
					last_err = 'JSON decode failed: %s' % e
					_log(last_err, level=xbmc.LOGERROR)
					break
				parsed = _parse_response(data)
				if parsed:
					return parsed
				last_err = 'Unparseable Gemini 200 response'
				try: body_snip = response.text[:300]
				except Exception: body_snip = ''
				_log('%s. Raw snippet: %s' % (last_err, body_snip), level=xbmc.LOGWARNING)
				break

			# Non-200 — degrade the request, rotate the key, or stop
			err = _error_details(response)
			last_err = 'HTTP %d (%s): %s' % (err['status_code'], err['status'], err['message'])
			_log('Gemini error (key #%d, profile %d): %s' % (idx, profile, last_err), level=xbmc.LOGWARNING)
			if _is_shape_rejection(err) and profile < _MAX_PROFILE and _sends_thinking(model):
				# The thinking level is the newest, most model-specific field in
				# the body: drop it for this model first and keep the schema.
				_thinking_rejected.add(model)
				_log('Thinking level rejected by %s — retrying without it' % model, level=xbmc.LOGWARNING)
				continue
			if _is_shape_rejection(err) and profile < _MAX_PROFILE:
				# The body carried something this model will not accept. Drop the
				# most advanced piece and try the SAME key again. The floor is
				# remembered so the rest of the session skips the failed shape.
				profile += 1
				_profile_floor = max(_profile_floor, profile)
				_log('Request shape rejected — retrying at profile %d' % profile, level=xbmc.LOGWARNING)
				continue
			if _is_bad_key(last_err):
				# v4: this key is dead, not the request. Before, the whole search
				# stopped here and keys 2 and 3 were never tried.
				_rejected_keys.add(api_key)
				_last_key_error = last_err
				_log('Key #%d rejected by Google — trying the next key' % idx, level=xbmc.LOGWARNING)
				break
			if err['status_code'] == 404 or err['status'] == 'NOT_FOUND':
				not_found_keys += 1
			if not _should_try_next_key(err):
				_last_error = last_err
				return None  # Not a quota error — other keys won't help
			break  # Rotate to the next key at the current profile

	_last_all_not_found = bool(api_keys) and not_found_keys == len(api_keys)
	_last_error = last_err
	return None


def _error_details(response):
	status = ''
	message = ''
	try:
		data = response.json()
		err = data.get('error') or {}
		status = err.get('status') or ''
		message = err.get('message') or ''
	except Exception:
		try: message = response.text[:200]
		except Exception: message = ''
	return {'status_code': response.status_code, 'status': status, 'message': message}


def _should_try_next_key(error_details):
	"""Return True when the error is project-specific and another key (from a
	different Google Cloud project) might succeed for the same model.

	Retriable across keys:
	  - 429 / RESOURCE_EXHAUSTED   → daily/per-minute quota exhausted on this project
	  - 404 / NOT_FOUND            → model not exposed to this project (region rollout)
	  - 503 / UNAVAILABLE          → model serving capacity issue, may not affect every project
	"""
	if not error_details: return False
	status_code = error_details.get('status_code')
	status = error_details.get('status') or ''
	if status_code == 429 or status == 'RESOURCE_EXHAUSTED': return True
	if status_code == 404 or status == 'NOT_FOUND': return True
	if status_code == 503 or status == 'UNAVAILABLE': return True
	return False


def _parse_response(response):
	try:
		text = _extract_text(response)
		if not text: return None
		try:
			return json.loads(text)
		except Exception:
			text = text.replace('```json', '').replace('```', '').strip()
			return json.loads(text)
	except Exception:
		return None


def _extract_text(response):
	try:
		candidates = response.get('candidates') or []
		for candidate in candidates:
			content = candidate.get('content') or {}
			for part in content.get('parts', []):
				# Thinking models can return a reasoning part alongside the answer.
				# It is flagged with thought=True and is NOT the JSON we asked for.
				if part.get('thought'): continue
				text = part.get('text')
				if text: return text
	except Exception:
		pass
	return None


# ──────────────────────────────────────────────────────────────────────
# Manual cache (bypasses cache.get()'s silent except)
# ──────────────────────────────────────────────────────────────────────

def _make_cache_key(prompt):
	"""Cache key is per-prompt (not per-model) because an intent is an intent —
	once we've translated the prompt successfully, reuse it regardless of which
	model produced it. cache_version invalidates stale entries across prompt changes."""
	blob = ('%s||%s' % (cache_version, prompt)).encode('utf-8')
	return cache_prefix + hashlib.md5(blob).hexdigest()


def _cache_load(cache_key):
	"""Return cached dict or None. On any error returns None."""
	try:
		row = cache.cache_get(cache_key)
		if not row: return None
		from time import time as _time
		if (_time() - int(row['date'])) > (cache_ttl_hours * 3600):
			return None
		raw = row.get('value')
		if not raw: return None
		return json.loads(raw)
	except Exception as e:
		_log('Cache load failed (ignored): %s' % e, level=xbmc.LOGDEBUG)
		return None


def _cache_save(cache_key, payload):
	try:
		cache.cache_insert(cache_key, json.dumps(payload))
	except Exception as e:
		_log('Cache save failed (ignored): %s' % e, level=xbmc.LOGDEBUG)


# ──────────────────────────────────────────────────────────────────────
# Helpers
# ──────────────────────────────────────────────────────────────────────

def _normalize(data):
	def clean_list(value, limit):
		if not isinstance(value, list): return []
		results = []
		for item in value:
			try: item = str(item).strip()
			except Exception: continue
			if not item or item in results: continue
			results.append(item)
			if len(results) == limit: break
		return results
	def int_or_none(value):
		try: return int(value)
		except Exception: return None
	media_type = media_type_aliases.get(str(data.get('media_type', '')).strip().lower(), 'movie')
	year_range = data.get('year_range') or {}
	start_year = int_or_none(year_range.get('start'))
	end_year = int_or_none(year_range.get('end'))
	if all((start_year, end_year)) and start_year > end_year:
		start_year, end_year = end_year, start_year
	return {
		'media_type': media_type,
		'genres': clean_list(data.get('genres'), 5),
		'keywords': clean_list(data.get('keywords'), 5),
		'people': clean_list(data.get('people'), 4),
		'tone_descriptors': clean_list(data.get('tone_descriptors'), 5),
		'example_titles': clean_list(data.get('example_titles'), 3),
		'year_range': {'start': start_year, 'end': end_year},
		'spanish_language_preferred': bool(data.get('spanish_language_preferred', False)),
		'exclude_terms': clean_list(data.get('exclude_terms'), 5)
	}


def _log(message, level=xbmc.LOGINFO):
	"""Unconditional xbmc.log — visible regardless of luc_kodi's debug.enabled."""
	try:
		xbmc.log('%s %s' % (log_tag, message), level)
	except Exception:
		pass
