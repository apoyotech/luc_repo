# -*- coding: utf-8 -*-
"""
	luc_kodi Add-on
"""

from sys import exit as sysexit
from urllib.parse import quote_plus
from resources.lib.modules import control
from resources.lib.modules.context_hub import attach_cm # v2.0.09: modern panel or classic Kodi menu
from resources.lib.modules.trakt import getTraktCredentialsInfo, getTraktIndicatorsInfo
from resources.lib.modules.mdblist import getMDBListCredentialsInfo

getLS = control.lang
getSetting = control.setting
getMenuEnabled = control.getMenuEnabled

def getMenuEnabledDefaultOn(menu_title):
	# Igual que getMenuEnabled() pero un valor vacio cuenta como activado.
	# Necesario para ajustes nuevos: al actualizar, la clave aun no existe en
	# el settings.xml de userdata y getMenuEnabled() la leeria como 'false'.
	return getSetting(menu_title).strip() != 'false'
KODI_VERSION = control.getKodiVersion()


class Navigator:
	def __init__(self):
		self.artPath = control.artPath()
		self.iconLogos = getSetting('icon.logos') != 'Traditional'
		self.indexLabels = getSetting('index.labels') == 'true'
		self.traktCredentials = getTraktCredentialsInfo()
		self.traktIndicators = getTraktIndicatorsInfo()
		self.tmdbSessionID = getSetting('tmdb.session_id') != ''
		self.highlight_color = control.getHighlightColor()
		self.mdblistCredentials = getMDBListCredentialsInfo()
		# v1.0.87: se pregunta al modulo en vez de leer el ajuste a pelo. El token
		# vive primero en una window property y solo despues en settings.xml, asi
		# que un getSetting() directo no ve la sesion recien autorizada hasta que
		# Kodi vuelca el fichero, y la carpeta de PunchPlay no aparecia.
		try:
			from resources.lib.modules.punchplay import getPunchPlayCredentialsInfo
			self.punchplayCredentials = getPunchPlayCredentialsInfo()
		except Exception:
			self.punchplayCredentials = False
		# v1.0.99: quinto servicio, mismo motivo (token en window property).
		try:
			from resources.lib.modules.wetrakr import getWeTrakrCredentialsInfo
			self.wetrakrCredentials = getWeTrakrCredentialsInfo()
		except Exception:
			self.wetrakrCredentials = False

	def root(self):
		# v2.0.04: las entradas del menu principal van en negrita y dorado (fffdb515); Anime,
		# Descargas y Changelog usan sus propios textos para no pintar tambien los ajustes.
		# v2.0.04: iconos propios del menu principal (collage con esquinas redondeadas, como
		# Anime, y el logo de Trakt); los submenus siguen con movies.png / tvshows.png.
		self.addDirectoryItem(33046, 'movieNavigator', 'movies_main.png', 'DefaultMovies.png')
		self.addDirectoryItem(33047, 'tvNavigator', 'tvshows_main.png', 'DefaultTVShows.png')
		if getMenuEnabled('navi.anime'): self.addDirectoryItem(48014, 'anime_Navigator', 'anime.png', 'DefaultFolder.png')
		if getMenuEnabled('mylists.widget'):
			self.addDirectoryItem(32003, 'mymovieNavigator', 'trakt.png', 'DefaultVideoPlaylists.png')
			self.addDirectoryItem(32004, 'mytvNavigator', 'trakt.png', 'DefaultVideoPlaylists.png')
		if getMenuEnabled('navi.youtube'): self.addDirectoryItem('You Tube Videos', 'youtube', 'youtube.png', 'youtube.png')
		# v2.0.14: con el asistente, Search abre su propia ventana (Settings > Personal Assistant)
		if getSetting('assistant.search') != 'false': self.addDirectoryItem(32010, 'assistant_search', 'search.png', 'DefaultAddonsSearch.png', isFolder=False)
		else: self.addDirectoryItem(32010, 'tools_searchNavigator', 'search.png', 'DefaultAddonsSearch.png')
		self.addDirectoryItem(32008, 'tools_toolNavigator', 'tools.png', 'tools.png')
		downloads = True if getSetting('downloads') == 'true' and (len(control.listDir(getSetting('movie.download.path'))[0]) > 0 or len(control.listDir(getSetting('tv.download.path'))[0]) > 0) else False
		if downloads: self.addDirectoryItem(48016, 'downloadNavigator', 'downloads.png', 'DefaultFolder.png')
		if getMenuEnabled('navi.prem.services'): self.addDirectoryItem(40000, 'premiumNavigator', 'premium.png', 'DefaultFolder.png')
		# v2.0.04: navi.changelog no existia en ajustes y la entrada no salia nunca (y su
		# texto 32014 tampoco existia). News se quita: abria newsinfo.txt, que no existe.
		if getMenuEnabled('navi.changelog'): self.addDirectoryItem(48015, 'tools_ShowChangelog&name=luc_kodi', 'icon.png', 'DefaultAddonHelper.png', isFolder=False)
		self.endDirectory(is_root=True)

	def movies(self, lite=False):
		# For You (AI recommendations)
		self.addDirectoryItem(40110 if self.indexLabels else 40110, 'recoMovies', 'foryou_icon.png', 'DefaultMovies.png')
		if getMenuEnabled('navi.movie.trakt.popular'):
			self.addDirectoryItem(40519 if self.indexLabels else 40519, 'movies&url=traktpopular', 'trakt.png', 'DefaultMovies.png')
		# v2.0.04: TMDb Popular y Box Office tenian interruptor en ajustes pero no entrada.
		if getMenuEnabled('navi.movie.tmdb.popular'):
			self.addDirectoryItem(40518, 'tmdbmovies&url=tmdb_popular', 'tmdb.png', 'DefaultMovies.png')
		if getMenuEnabled('navi.movie.trakt.trending'):
			self.addDirectoryItem(40522 if self.indexLabels else 40522, 'movies&url=trakttrending', 'trakt.png', 'DefaultMovies.png')
		if getMenuEnabled('navi.movie.trakt.watchedweekly'):
			self.addDirectoryItem(40515 if self.indexLabels else 40514, 'movies&url=traktwatchedweekly', 'trakt.png', 'DefaultMovies.png')
		if getMenuEnabled('navi.movie.trakt.watchedmonthly'):
			self.addDirectoryItem(40517 if self.indexLabels else 40516, 'movies&url=traktwatchedmonthly', 'trakt.png', 'DefaultMovies.png')
		if getMenuEnabled('navi.movie.tmdb.nowplaying'):
			self.addDirectoryItem(40526 if self.indexLabels else 40526, 'tmdbmovies&url=tmdb_nowplaying', 'tmdb.png', 'DefaultMovies.png')
		if getMenuEnabled('navi.movie.trakt.anticipated'):
			self.addDirectoryItem(40525 if self.indexLabels else 40525, 'movies&url=traktanticipated', 'trakt.png', 'DefaultMovies.png')
		if getMenuEnabled('navi.movie.tmdb.upcoming'):
			self.addDirectoryItem(40527 if self.indexLabels else 40527, 'tmdbmovies&url=tmdb_upcoming', 'tmdb.png', 'DefaultMovies.png')
		if getMenuEnabled('navi.movie.tmdb.calendar'):
			self.addDirectoryItem(40254, 'movie_calendarNavigator', 'tmdb.png' if self.iconLogos else 'calendar.png', 'DefaultYear.png')
		if getMenuEnabled('navi.movie.tmdb.boxoffice'):
			self.addDirectoryItem(40520, 'tmdbmovies&url=tmdb_boxoffice', 'tmdb.png', 'DefaultMovies.png')
		if getMenuEnabled('navi.movie.trakt.boxoffice'):
			self.addDirectoryItem(40521 if self.indexLabels else 40521, 'movies&url=traktboxoffice', 'trakt.png', 'DefaultMovies.png')
		if getMenuEnabled('navi.movie.tmdb.toprated'):
			self.addDirectoryItem(40523 if self.indexLabels else 40523, 'tmdbmovies&url=tmdb_toprated', 'tmdb.png', 'DefaultMovies.png')
		# v2.0.04: Mas votadas, Oscar, Personas e Idiomas leian IMDb; ahora TMDb (y Wikidata los Oscar)
		if getMenuEnabled('navi.movie.tmdb.mostvoted'):
			self.addDirectoryItem(48009, 'tmdbmovies&url=tmdb_mostvoted', 'tmdb.png', 'DefaultMovies.png')
		if getMenuEnabled('navi.movie.oscars'):
			self.addDirectoryItem(32451 if self.indexLabels else 32452, 'movies&url=oscars', 'oscars.png', 'DefaultMovies.png')
			self.addDirectoryItem(32453 if self.indexLabels else 32454, 'movies&url=oscarsnominees', 'oscars.png', 'DefaultMovies.png')
		if getMenuEnabled('navi.movie.trakt.recommended'):
			self.addDirectoryItem(40524 if self.indexLabels else 40524, 'movies&url=traktrecommendations', 'trakt.png', 'DefaultMovies.png')
		# ── SIMKL public trending lists (no login required, client_id-only) ────
		if getMenuEnabled('navi.movie.simkl.trendingToday'):
			self.addDirectoryItem(45000, 'movies&url=simkltrendingtoday', 'simkl.png', 'DefaultMovies.png')
		if getMenuEnabled('navi.movie.simkl.trendingWeek'):
			self.addDirectoryItem(45001, 'movies&url=simkltrendingweek',  'simkl.png', 'DefaultMovies.png')
		if getMenuEnabled('navi.movie.simkl.trendingMonth'):
			self.addDirectoryItem(45002, 'movies&url=simkltrendingmonth', 'simkl.png', 'DefaultMovies.png')
		if getMenuEnabled('navi.movie.simkl.playback'):
			try:
				from resources.lib.modules import simkl
				if simkl.getSimklCredentialsInfo():
					self.addDirectoryItem(45014, 'moviesSimklProgress&url=simklplayback', 'simkl.png', 'DefaultInProgressShows.png', queue=True)
			except: pass
		if getMenuEnabled('navi.movie.tmdb.genres'):
			self.addDirectoryItem(32486 if self.indexLabels else 32455, 'movieGenres&url=tmdb_genre', 'tmdb.png' if self.iconLogos else 'genres.png', 'DefaultGenre.png')
		if getMenuEnabled('navi.movie.tmdb.years'):
			self.addDirectoryItem(32485 if self.indexLabels else 32457, 'movieYears&url=tmdb_year', 'tmdb.png' if self.iconLogos else 'calendar.png', 'DefaultYear.png')
		if getMenuEnabled('navi.movie.tmdb.certificates'):
			self.addDirectoryItem(32487 if self.indexLabels else 32463, 'movieCertificates&url=tmdb_certification', 'tmdb.png' if self.iconLogos else 'certificates.png', 'DefaultMovies.png')
		if getMenuEnabled('navi.movie.tmdb.people'):
			self.addDirectoryItem(48011, 'moviePersons', 'tmdb.png', 'DefaultActor.png')
		if getMenuEnabled('navi.movie.tmdb.languages'):
			self.addDirectoryItem(48012, 'movieLanguages', 'tmdb.png' if self.iconLogos else 'languages.png', 'DefaultAddonLanguage.png')
		if getMenuEnabled('navi.movie.tmdb.providers'):
			self.addDirectoryItem(40701 if self.indexLabels else 40700, 'movieProviders', 'tmdb.png' if self.iconLogos else 'networks.png', 'DefaultNetwork.png')
		if getMenuEnabled('navi.movie.collections'):
			self.addDirectoryItem(32000, 'collections_Navigator', 'boxsets.png', 'DefaultSets.png')
		if getMenuEnabled('navi.movie.trakt.popularList'):
			self.addDirectoryItem(32417, 'movies_PublicLists&url=trakt_popularLists', 'trakt.png', 'DefaultMovies.png')
		if getMenuEnabled('navi.movie.trakt.trendingList'):
			self.addDirectoryItem(32418, 'movies_PublicLists&url=trakt_trendingLists', 'trakt.png', 'DefaultMovies.png')
		if getMenuEnabled('navi.movie.trakt.searchList'):
			self.addDirectoryItem(32419, 'movies_SearchLists&media_type=movies', 'trakt.png', 'DefaultMovies.png', isFolder=False)
		if self.mdblistCredentials:
			# Carpeta MDBList: da acceso a Watchlist, My Lists, Top Lists, Search Lists,
			# Browse User e Import by URL. Sin esta entrada el submenu era inalcanzable
			# y el usuario no podia llegar nunca a sus propias listas.
			if getMenuEnabledDefaultOn('navi.movie.mdblist.folder'):
				self.addDirectoryItem(40210, 'mdblist_movieNavigator', 'mdblist.png', 'DefaultVideoPlaylists.png')
			if getMenuEnabled('navi.movie.mdblist.continue'):
				self.addDirectoryItem(40231, 'mdblist_continueMovies', 'mdblist.png', 'DefaultVideoPlaylists.png', queue=True)
			if getMenuEnabled('navi.movie.mdblist.topLists'):
				self.addDirectoryItem(40232, 'mdblist_movieTopListsPublic', 'mdblist.png', 'DefaultVideoPlaylists.png')
			if getMenuEnabled('navi.movie.mdblist.searchList'):
				self.addDirectoryItem(40233, 'mdblist_movieSearchListsPublic', 'mdblist.png', 'DefaultAddonsSearch.png', isFolder=False)
		if getMenuEnabled('navi.movie.punchplay.trending'):
			self.addDirectoryItem(46000, 'movies&url=punchplaytrending', 'punchplay.png', 'DefaultMovies.png')
		if getMenuEnabled('navi.movie.punchplay.popular'):
			self.addDirectoryItem(46001, 'movies&url=punchplaypopular', 'punchplay.png', 'DefaultMovies.png')
		if self.punchplayCredentials:
			if getMenuEnabledDefaultOn('navi.movie.punchplay.folder'):
				self.addDirectoryItem(46010, 'punchplay_movieNavigator', 'punchplay.png', 'DefaultVideoPlaylists.png')
		# v1.0.99 WeTrakr: tambien Trending y Popular solo con la cuenta asociada,
		# porque van con el token del usuario y asi no gastan la cuota diaria
		# compartida de la clave de la app.
		if self.wetrakrCredentials:
			if getMenuEnabledDefaultOn('navi.movie.wetrakr.trending'):
				self.addDirectoryItem(47000, 'movies&url=wetrakrtrending', 'wetrakr.png', 'DefaultMovies.png')
			if getMenuEnabled('navi.movie.wetrakr.popular'):
				self.addDirectoryItem(47001, 'movies&url=wetrakrpopular', 'wetrakr.png', 'DefaultMovies.png')
			if getMenuEnabledDefaultOn('navi.movie.wetrakr.folder'):
				self.addDirectoryItem(47010, 'wetrakr_movieNavigator', 'wetrakr.png', 'DefaultVideoPlaylists.png')
		if not lite:
			if getMenuEnabled('mylists.widget'): self.addDirectoryItem(32003, 'mymovieliteNavigator', 'trakt.png', 'DefaultMovies.png')
			self.addDirectoryItem(33042, 'movieSearch', 'trakt.png' if self.iconLogos else 'search.png', 'DefaultAddonsSearch.png')
		self.endDirectory()

	def mymovies(self, lite=False):
		self.accountCheck()
		self.addDirectoryItem(32039, 'movieUserlists', 'userlists.png', 'DefaultVideoPlaylists.png')
		if self.traktCredentials:
			if self.traktIndicators:
				self.addDirectoryItem(35308, 'moviesUnfinished&url=traktunfinished', 'trakt.png', 'trakt.png', queue=True)
				self.addDirectoryItem(32036, 'movies&url=trakthistory', 'trakt.png', 'trakt.png', queue=True)
			self.addDirectoryItem(32683, 'movies&url=traktwatchlist', 'trakt.png', 'trakt.png', queue=True, context=(32551, 'library_moviesToLibrary&url=traktwatchlist&name=traktwatchlist'))
			self.addDirectoryItem(32032, 'movies&url=traktcollection', 'trakt.png', 'trakt.png', queue=True, context=(32551, 'library_moviesToLibrary&url=traktcollection&name=traktcollection'))
			self.addDirectoryItem('My Liked Lists', 'movies_LikedLists', 'trakt.png', 'trakt.png', queue=True)
		self.endDirectory()

	def tvshows(self, lite=False):
		# For You (AI recommendations)
		self.addDirectoryItem(40111 if self.indexLabels else 40111, 'recoTV', 'foryou_icon.png', 'DefaultTVShows.png')
		if getMenuEnabled('navi.tv.trakt.trending'):
			self.addDirectoryItem(40522 if self.indexLabels else 40522, 'tvshows&url=trakttrending', 'trakt.png', 'DefaultTVShows.png')
		if getMenuEnabled('navi.originals'):
			self.addDirectoryItem(40077 if self.indexLabels else 40070, 'tvOriginals', 'tvmaze.png' if self.iconLogos else 'originals.png', 'DefaultNetwork.png')
		if getMenuEnabled('navi.tv.trakt.popular'):
			self.addDirectoryItem(40519 if self.indexLabels else 40519, 'tvshows&url=traktpopular', 'trakt.png', 'DefaultTVShows.png', queue=True)
		if getMenuEnabled('navi.tv.tmdb.popular'):
			self.addDirectoryItem(40518, 'tmdbTvshows&url=tmdb_popular', 'tmdb.png', 'DefaultTVShows.png')
		if getMenuEnabled('navi.tv.tmdb.toprated'):
			self.addDirectoryItem(40523 if self.indexLabels else 40523, 'tmdbTvshows&url=tmdb_toprated', 'tmdb.png', 'DefaultTVShows.png')
		if getMenuEnabled('navi.tv.tmdb.mostvoted'):
			self.addDirectoryItem(48009, 'tmdbTvshows&url=tmdb_mostvoted', 'tmdb.png', 'DefaultTVShows.png')
		if getMenuEnabled('navi.tv.trakt.recommended'):
			self.addDirectoryItem(40524 if self.indexLabels else 40524, 'tvshows&url=traktrecommendations', 'trakt.png', 'DefaultTVShows.png', queue=True)
		# ── SIMKL public trending lists (no login required, client_id-only) ────
		if getMenuEnabled('navi.tv.simkl.trendingToday'):
			self.addDirectoryItem(45010, 'tvshows&url=simkltrendingtoday', 'simkl.png', 'DefaultTVShows.png')
		if getMenuEnabled('navi.tv.simkl.trendingWeek'):
			self.addDirectoryItem(45011, 'tvshows&url=simkltrendingweek',  'simkl.png', 'DefaultTVShows.png')
		if getMenuEnabled('navi.tv.simkl.trendingMonth'):
			self.addDirectoryItem(45012, 'tvshows&url=simkltrendingmonth', 'simkl.png', 'DefaultTVShows.png')
		if getMenuEnabled('navi.tv.simkl.progress'):
			try:
				from resources.lib.modules import simkl
				if simkl.getSimklCredentialsInfo():
					self.addDirectoryItem(45013, 'calendar&url=simklprogress', 'simkl.png', 'DefaultTVShows.png', queue=True, context=(32072, 'episodes_clrProgressCache&url=simklprogress'))
			except: pass
		if getMenuEnabled('navi.tv.simkl.playback'):
			try:
				from resources.lib.modules import simkl
				if simkl.getSimklCredentialsInfo():
					self.addDirectoryItem(45015, 'episodesSimklProgress&url=simklplayback', 'simkl.png', 'DefaultInProgressShows.png', queue=True, context=(32072, 'episodes_clrProgressCache&url=simklplayback'))
			except: pass
		if getMenuEnabled('navi.tv.tmdb.genres'):
			self.addDirectoryItem(32486 if self.indexLabels else 32455, 'tvGenres&url=tmdb_genre', 'tmdb.png' if self.iconLogos else 'genres.png', 'DefaultGenre.png')
		if getMenuEnabled('navi.tv.tvmaze.networks'):
			self.addDirectoryItem(32468 if self.indexLabels else 32469, 'tvNetworks', 'tmdb.png' if self.iconLogos else 'networks.png', 'DefaultNetwork.png')
		if getMenuEnabled('navi.tv.tmdb.providers'):
			self.addDirectoryItem(40701 if self.indexLabels else 40700, 'tvProviders', 'tmdb.png' if self.iconLogos else 'networks.png', 'DefaultNetwork.png')
		# Sin certificados de series: discover/tv de TMDb no filtra por edades.
		if getMenuEnabled('navi.tv.tmdb.years'):
			self.addDirectoryItem(32485 if self.indexLabels else 32457, 'tvYears&url=tmdb_year', 'tmdb.png' if self.iconLogos else 'calendar.png', 'DefaultYear.png')
		if getMenuEnabled('navi.tv.tmdb.people'):
			self.addDirectoryItem(48011, 'tvPersons', 'tmdb.png', 'DefaultActor.png')
		if getMenuEnabled('navi.tv.tmdb.languages'):
			self.addDirectoryItem(48012, 'tvLanguages', 'tmdb.png' if self.iconLogos else 'languages.png', 'DefaultAddonLanguage.png')
		if getMenuEnabled('navi.tv.tmdb.airingtoday'):
			self.addDirectoryItem(40528 if self.indexLabels else 40528, 'tmdbTvshows&url=tmdb_airingtoday', 'tmdb.png', 'DefaultRecentlyAddedEpisodes.png')
		if getMenuEnabled('navi.tv.tmdb.ontv'):
			self.addDirectoryItem(40529 if self.indexLabels else 40529, 'tmdbTvshows&url=tmdb_ontheair', 'tmdb.png', 'DefaultRecentlyAddedEpisodes.png')
		if getMenuEnabled('navi.tv.tvmaze.calendar'):
			self.addDirectoryItem(32450 if self.indexLabels else 32027, 'calendars', 'tvmaze.png' if self.iconLogos else 'calendar.png', 'DefaultYear.png')
		if getMenuEnabled('navi.tv.tmdb.calendar'):
			self.addDirectoryItem(40258, 'tv_calendarNavigator', 'tmdb.png' if self.iconLogos else 'calendar.png', 'DefaultYear.png')
		if getMenuEnabled('navi.tv.trakt.popularList'):
			self.addDirectoryItem(32417, 'tv_PublicLists&url=trakt_popularLists', 'trakt.png', 'DefaultMovies.png')
		if getMenuEnabled('navi.tv.trakt.trendingList'):
			self.addDirectoryItem(32418, 'tv_PublicLists&url=trakt_trendingLists', 'trakt.png', 'DefaultMovies.png')
		if getMenuEnabled('navi.tv.trakt.searchList'):
			self.addDirectoryItem(32419, 'tv_SearchLists&media_type=shows', 'trakt.png', 'DefaultMovies.png', isFolder=False)
		if self.mdblistCredentials:
			# Ver comentario equivalente en movies(): sin esta entrada el submenu
			# mdblist_tv() (Watchlist / My Lists / ...) no tenia ningun enlace.
			if getMenuEnabledDefaultOn('navi.tv.mdblist.folder'):
				self.addDirectoryItem(40211, 'mdblist_tvNavigator', 'mdblist.png', 'DefaultVideoPlaylists.png')
			if getMenuEnabled('navi.tv.mdblist.continue'):
				self.addDirectoryItem(40234, 'mdblist_continueEpisodes', 'mdblist.png', 'DefaultVideoPlaylists.png', queue=True)
			if getMenuEnabled('navi.tv.mdblist.topLists'):
				self.addDirectoryItem(40235, 'mdblist_showTopListsPublic', 'mdblist.png', 'DefaultVideoPlaylists.png')
			if getMenuEnabled('navi.tv.mdblist.searchList'):
				self.addDirectoryItem(40236, 'mdblist_showSearchListsPublic', 'mdblist.png', 'DefaultAddonsSearch.png', isFolder=False)
		if getMenuEnabled('navi.tv.punchplay.trending'):
			self.addDirectoryItem(46002, 'tvshows&url=punchplaytrending', 'punchplay.png', 'DefaultTVShows.png')
		if getMenuEnabled('navi.tv.punchplay.popular'):
			self.addDirectoryItem(46003, 'tvshows&url=punchplaypopular', 'punchplay.png', 'DefaultTVShows.png')
		if self.punchplayCredentials:
			if getMenuEnabledDefaultOn('navi.tv.punchplay.folder'):
				self.addDirectoryItem(46011, 'punchplay_tvNavigator', 'punchplay.png', 'DefaultVideoPlaylists.png')
		if self.wetrakrCredentials:
			if getMenuEnabledDefaultOn('navi.tv.wetrakr.trending'):
				self.addDirectoryItem(47002, 'tvshows&url=wetrakrtrending', 'wetrakr.png', 'DefaultTVShows.png')
			if getMenuEnabled('navi.tv.wetrakr.popular'):
				self.addDirectoryItem(47003, 'tvshows&url=wetrakrpopular', 'wetrakr.png', 'DefaultTVShows.png')
			if getMenuEnabledDefaultOn('navi.tv.wetrakr.folder'):
				self.addDirectoryItem(47011, 'wetrakr_tvNavigator', 'wetrakr.png', 'DefaultVideoPlaylists.png')
		# v2.0.16 TVmaze: only with an account; followed shows are a Premium feature,
		# so a free account (premium level 0 already checked) does not get the entry.
		if getSetting('tvmaze.username') and getSetting('tvmaze.apikey') and getSetting('tvmaze.premium') != '0':
			if getMenuEnabledDefaultOn('navi.tv.tvmaze.followed'):
				self.addDirectoryItem(49026, 'tvmaze_Followed', 'tvmaze.png', 'DefaultVideoPlaylists.png')
		if not lite:
			if getMenuEnabled('mylists.widget'): self.addDirectoryItem(32004, 'mytvliteNavigator', 'trakt.png', 'DefaultTVShows.png')
			self.addDirectoryItem(33043, 'tvSearch', 'trakt.png' if self.iconLogos else 'search.png', 'DefaultAddonsSearch.png')
		self.endDirectory()

	def mytvshows(self, lite=False):
		self.accountCheck()
		self.addDirectoryItem(32040, 'tvUserlists', 'userlists.png', 'DefaultVideoPlaylists.png')
		if self.traktCredentials:
			if self.traktIndicators:
				self.addDirectoryItem(35308, 'episodesUnfinished&url=traktunfinished', 'trakt.png', 'trakt.png', queue=True)
				self.addDirectoryItem(32037, 'calendar&url=progress', 'trakt.png', 'trakt.png', queue=True)
				self.addDirectoryItem(32019, 'upcomingProgress&url=progress', 'trakt.png', 'trakt.png', queue=True)
				self.addDirectoryItem(32202, 'calendar&url=mycalendarRecent', 'trakt.png', 'trakt.png', queue=True)
				self.addDirectoryItem(32203, 'calendar&url=mycalendarUpcoming', 'trakt.png', 'trakt.png', queue=True)
				self.addDirectoryItem(32204, 'calendar&url=mycalendarPremiers', 'trakt.png', 'trakt.png', queue=True)
				self.addDirectoryItem(32036, 'calendar&url=trakthistory', 'trakt.png', 'trakt.png', queue=True)
			self.addDirectoryItem(32683, 'tvshows&url=traktwatchlist', 'trakt.png', 'trakt.png', context=(32551, 'library_tvshowsToLibrary&url=traktwatchlist&name=traktwatchlist'))
			self.addDirectoryItem(32032, 'tvshows&url=traktcollection', 'trakt.png', 'trakt.png', context=(32551, 'library_tvshowsToLibrary&url=traktcollection&name=traktcollection'))
			self.addDirectoryItem('My Liked Lists', 'shows_LikedLists', 'trakt.png', 'trakt.png', queue=True)
		self.endDirectory()

	def movie_calendar(self):
		self.addDirectoryItem(40255, 'tmdbmovies&url=tmdb_calendarTheaters', 'tmdb.png', 'DefaultMovies.png')
		self.addDirectoryItem(40256, 'tmdbmovies&url=tmdb_calendarSoon', 'tmdb.png', 'DefaultMovies.png')
		self.addDirectoryItem(40257, 'tmdbmovies&url=tmdb_calendarDigital', 'tmdb.png', 'DefaultMovies.png')
		self.addDirectoryItem(32818, 'library_premiereMovies', 'calendar.png', 'DefaultVideoPlaylists.png') # v2.0.13
		self.endDirectory()

	def tv_calendar(self):
		self.addDirectoryItem(40259, 'tmdbTvshows&url=tmdb_calendarPremieres', 'tmdb.png', 'DefaultTVShows.png')
		self.addDirectoryItem(40260, 'tmdbTvshows&url=tmdb_calendarNew', 'tmdb.png', 'DefaultTVShows.png')
		self.addDirectoryItem(32450 if self.indexLabels else 32027, 'calendars', 'tvmaze.png' if self.iconLogos else 'calendar.png', 'DefaultYear.png')
		self.addDirectoryItem(32700, 'library_premiereLists', 'calendar.png', 'DefaultVideoPlaylists.png') # v2.0.0
		self.endDirectory()

	def mdblist_movies(self):
		self.addDirectoryItem(40250, 'mdblist_calendarMovies', 'mdblist.png', 'DefaultYear.png', queue=True)
		self.addDirectoryItem(40212, 'mdblist_movieWatchlist', 'mdblist.png', 'DefaultVideoPlaylists.png', queue=True)
		self.addDirectoryItem(40213, 'mdblist_movieUserLists', 'mdblist.png', 'DefaultVideoPlaylists.png')
		self.addDirectoryItem(40261, 'mdblist_movieExternalLists', 'mdblist.png', 'DefaultVideoPlaylists.png')
		self.addDirectoryItem(40262, 'mdblist_movieLikedLists', 'mdblist.png', 'DefaultVideoPlaylists.png')
		self.addDirectoryItem(40214, 'mdblist_movieTopLists', 'mdblist.png', 'DefaultVideoPlaylists.png')
		self.addDirectoryItem(40215, 'mdblist_movieSearchLists', 'mdblist.png', 'DefaultAddonsSearch.png', isFolder=False)
		self.addDirectoryItem(40241, 'mdblist_browseUser', 'mdblist.png', 'DefaultVideoPlaylists.png', isFolder=False)
		self.addDirectoryItem(40243, 'mdblist_importByUrl&media_type=movie', 'mdblist.png', 'DefaultVideoPlaylists.png', isFolder=False)
		self.endDirectory()

	def mdblist_tv(self):
		self.addDirectoryItem(40251, 'mdblist_calendarUpcoming', 'mdblist.png', 'DefaultYear.png', queue=True)
		self.addDirectoryItem(40252, 'mdblist_calendarRecent', 'mdblist.png', 'DefaultYear.png', queue=True)
		self.addDirectoryItem(40216, 'mdblist_showWatchlist', 'mdblist.png', 'DefaultVideoPlaylists.png', queue=True)
		self.addDirectoryItem(40217, 'mdblist_showUserLists', 'mdblist.png', 'DefaultVideoPlaylists.png')
		self.addDirectoryItem(40261, 'mdblist_showExternalLists', 'mdblist.png', 'DefaultVideoPlaylists.png')
		self.addDirectoryItem(40262, 'mdblist_showLikedLists', 'mdblist.png', 'DefaultVideoPlaylists.png')
		self.addDirectoryItem(40218, 'mdblist_showTopLists', 'mdblist.png', 'DefaultVideoPlaylists.png')
		self.addDirectoryItem(40219, 'mdblist_showSearchLists', 'mdblist.png', 'DefaultAddonsSearch.png', isFolder=False)
		self.addDirectoryItem(40241, 'mdblist_browseUser', 'mdblist.png', 'DefaultVideoPlaylists.png', isFolder=False)
		self.addDirectoryItem(40243, 'mdblist_importByUrl&media_type=show', 'mdblist.png', 'DefaultVideoPlaylists.png', isFolder=False)
		self.endDirectory()

	def punchplay_movies(self):
		self.addDirectoryItem(46020, 'punchplay_movieWatchlist', 'punchplay.png', 'DefaultVideoPlaylists.png', queue=True)
		self.addDirectoryItem(46021, 'punchplay_movieUserLists', 'punchplay.png', 'DefaultVideoPlaylists.png')
		self.addDirectoryItem(46012, 'punchplay_continueMovies', 'punchplay.png', 'DefaultInProgressShows.png', queue=True)
		self.addDirectoryItem(46015, 'punchplay_movieCollection', 'punchplay.png', 'DefaultVideoPlaylists.png', queue=True)
		self.addDirectoryItem(46016, 'punchplay_movieFavourites', 'punchplay.png', 'DefaultVideoPlaylists.png', queue=True)
		self.addDirectoryItem(46017, 'punchplay_movieRatings', 'punchplay.png', 'DefaultVideoPlaylists.png', queue=True)
		self.addDirectoryItem(46026, 'punchplay_movieCommunityLists', 'punchplay.png', 'DefaultVideoPlaylists.png')
		self.addDirectoryItem(46027, 'punchplay_movieOpenByUrl', 'punchplay.png', 'DefaultVideoPlaylists.png', isFolder=False)
		self.addDirectoryItem(46022, 'punchplay_movieHistory', 'punchplay.png', 'DefaultVideoPlaylists.png', queue=True)
		self.endDirectory()

	def punchplay_tv(self):
		self.addDirectoryItem(46023, 'punchplay_showWatchlist', 'punchplay.png', 'DefaultVideoPlaylists.png', queue=True)
		self.addDirectoryItem(46024, 'punchplay_showUserLists', 'punchplay.png', 'DefaultVideoPlaylists.png')
		self.addDirectoryItem(46013, 'punchplay_continueEpisodes', 'punchplay.png', 'DefaultInProgressShows.png', queue=True)
		self.addDirectoryItem(46014, 'punchplay_showProgress', 'punchplay.png', 'DefaultTVShows.png', queue=True)
		self.addDirectoryItem(46015, 'punchplay_showCollection', 'punchplay.png', 'DefaultVideoPlaylists.png', queue=True)
		self.addDirectoryItem(46016, 'punchplay_showFavourites', 'punchplay.png', 'DefaultVideoPlaylists.png', queue=True)
		self.addDirectoryItem(46017, 'punchplay_showRatings', 'punchplay.png', 'DefaultVideoPlaylists.png', queue=True)
		self.addDirectoryItem(46025, 'punchplay_calendarEpisodes', 'punchplay.png', 'DefaultYear.png', queue=True)
		self.addDirectoryItem(46026, 'punchplay_showCommunityLists', 'punchplay.png', 'DefaultVideoPlaylists.png')
		self.addDirectoryItem(46027, 'punchplay_showOpenByUrl', 'punchplay.png', 'DefaultVideoPlaylists.png', isFolder=False)
		self.endDirectory()

	def wetrakr_movies(self):
		self.addDirectoryItem(47017, 'wetrakr_movieWatchlist', 'wetrakr.png', 'DefaultVideoPlaylists.png', queue=True)
		self.addDirectoryItem(47012, 'wetrakr_continueMovies', 'wetrakr.png', 'DefaultInProgressShows.png', queue=True)
		self.addDirectoryItem(47018, 'wetrakr_movieUserLists', 'wetrakr.png', 'DefaultVideoPlaylists.png')
		self.addDirectoryItem(47019, 'wetrakr_movieLikedLists', 'wetrakr.png', 'DefaultVideoPlaylists.png')
		self.addDirectoryItem(47020, 'wetrakr_movieFollowedLists', 'wetrakr.png', 'DefaultVideoPlaylists.png')
		self.addDirectoryItem(47015, 'wetrakr_movieFavorites', 'wetrakr.png', 'DefaultVideoPlaylists.png', queue=True)
		self.addDirectoryItem(47016, 'wetrakr_movieRatings', 'wetrakr.png', 'DefaultVideoPlaylists.png', queue=True)
		self.addDirectoryItem(47023, 'movies&url=wetrakrrecommended', 'wetrakr.png', 'DefaultMovies.png')
		self.addDirectoryItem(47024, 'movies&url=wetrakrtoprated', 'wetrakr.png', 'DefaultMovies.png')
		self.addDirectoryItem(47026, 'wetrakr_calendarMovies', 'wetrakr.png', 'DefaultYear.png', queue=True)
		self.addDirectoryItem(47021, 'wetrakr_movieTrendingLists', 'wetrakr.png', 'DefaultVideoPlaylists.png')
		self.addDirectoryItem(47022, 'wetrakr_movieHistory', 'wetrakr.png', 'DefaultVideoPlaylists.png', queue=True)
		self.endDirectory()

	def wetrakr_tv(self):
		self.addDirectoryItem(47017, 'wetrakr_showWatchlist', 'wetrakr.png', 'DefaultVideoPlaylists.png', queue=True)
		self.addDirectoryItem(47013, 'wetrakr_continueEpisodes', 'wetrakr.png', 'DefaultInProgressShows.png', queue=True)
		self.addDirectoryItem(47014, 'wetrakr_showProgress', 'wetrakr.png', 'DefaultTVShows.png', queue=True)
		self.addDirectoryItem(47025, 'wetrakr_calendarEpisodes', 'wetrakr.png', 'DefaultYear.png', queue=True)
		self.addDirectoryItem(47018, 'wetrakr_showUserLists', 'wetrakr.png', 'DefaultVideoPlaylists.png')
		self.addDirectoryItem(47019, 'wetrakr_showLikedLists', 'wetrakr.png', 'DefaultVideoPlaylists.png')
		self.addDirectoryItem(47020, 'wetrakr_showFollowedLists', 'wetrakr.png', 'DefaultVideoPlaylists.png')
		self.addDirectoryItem(47015, 'wetrakr_showFavorites', 'wetrakr.png', 'DefaultVideoPlaylists.png', queue=True)
		self.addDirectoryItem(47016, 'wetrakr_showRatings', 'wetrakr.png', 'DefaultVideoPlaylists.png', queue=True)
		self.addDirectoryItem(47027, 'wetrakr_showWatched', 'wetrakr.png', 'DefaultVideoPlaylists.png', queue=True)
		self.addDirectoryItem(47023, 'tvshows&url=wetrakrrecommended', 'wetrakr.png', 'DefaultTVShows.png')
		self.addDirectoryItem(47024, 'tvshows&url=wetrakrtoprated', 'wetrakr.png', 'DefaultTVShows.png')
		self.addDirectoryItem(47021, 'wetrakr_showTrendingLists', 'wetrakr.png', 'DefaultVideoPlaylists.png')
		self.endDirectory()

	def anime(self, lite=False):
		# v2.0.04: de TMDb (animacion japonesa). La busqueda por palabra clave de IMDb
		# usaba la maquetacion antigua de su web, que ya no existe.
		self.addDirectoryItem(32001, 'anime_Movies&url=tmdb_anime', 'movies.png', 'DefaultMovies.png')
		self.addDirectoryItem(32002, 'anime_TVshows&url=tmdb_anime', 'tvshows.png', 'DefaultTVShows.png')
		self.endDirectory()

	def traktSearchLists(self, media_type):
		k = control.keyboard('', getLS(32010))
		k.doModal()
		q = k.getText() if k.isConfirmed() else None
		if not q: return control.closeAll()
		page_limit = getSetting('page.item.limit')
		url = 'https://api.trakt.tv/search/list?limit=%s&page=1&query=' % page_limit + quote_plus(q)
		control.closeAll()
		if media_type == 'movies': control.execute('ActivateWindow(Videos,plugin://plugin.video.luc_kodi/?action=movies_PublicLists&url=%s,return)' % (quote_plus(url)))
		else: control.execute('ActivateWindow(Videos,plugin://plugin.video.luc_kodi/?action=tv_PublicLists&url=%s,return)' % (quote_plus(url)))

	def tools(self):
		if self.traktCredentials: self.addDirectoryItem(35057, 'tools_traktToolsNavigator', 'tools.png', 'DefaultAddonService.png', isFolder=True)
		self.addDirectoryItem(32510, 'cache_Navigator', 'tools.png', 'DefaultAddonService.png', isFolder=True)
		self.addDirectoryItem(400700, 'tools_updateCatalog', 'tools.png', 'DefaultAddonService.png', isFolder=False)
		self.addDirectoryItem(400875, 'tools_networkAudit', 'tools.png', 'DefaultAddonService.png', isFolder=False)
		self.addDirectoryItem(49201, 'tools_usenetReport', 'tools.png', 'DefaultAddonService.png', isFolder=False) # v2.0.25
		self.addDirectoryItem(32761, 'tools_credSync', 'tools.png', 'DefaultAddonService.png', isFolder=False) # v2.0.13
		self.addDirectoryItem(32523, 'tools_loggingNavigator', 'tools.png', 'DefaultAddonService.png')
		self.addDirectoryItem(32083, 'tools_cleanSettings', 'tools.png', 'DefaultAddonProgram.png', isFolder=False)
		#self.addDirectoryItem(32506, 'tools_contextluc_kodiSettings', 'icon.png', 'DefaultAddonProgram.png', isFolder=False)
		#-- Providers - 5
		#self.addDirectoryItem(32047, 'tools_openSettings&query=5.0', 'tools.png', 'DefaultAddonService.png', isFolder=False)
		#-- General - 0
		self.addDirectoryItem(32043, 'tools_openSettings&query=0.0', 'tools.png', 'DefaultAddonService.png', isFolder=False)
		#-- Navigation - 1
		#self.addDirectoryItem(32362, 'tools_openSettings&query=1.0', 'tools.png', 'DefaultAddonService.png', isFolder=False)
		#-- Playback - 4
		#self.addDirectoryItem(32045, 'tools_openSettings&query=4.0', 'tools.png', 'DefaultAddonService.png', isFolder=False)
		#-- Accounts - 8
		#self.addDirectoryItem(32044, 'tools_openSettings&query=9.0', 'tools.png', 'DefaultAddonService.png', isFolder=False)
		#-- Downloads - 11
		#self.addDirectoryItem(32048, 'tools_openSettings&query=11.0', 'tools.png', 'DefaultAddonService.png', isFolder=False)
		self.addDirectoryItem(32556, 'library_Navigator', 'tools.png', 'DefaultAddonService.png', isFolder=True)
		self.addDirectoryItem(32049, 'tools_viewsNavigator', 'tools.png', 'DefaultAddonService.png', isFolder=True)
		self.addDirectoryItem(32361, 'tools_resetViewTypes', 'tools.png', 'DefaultAddonService.png', isFolder=False)
		self.endDirectory()

	def traktTools(self):
		self.addDirectoryItem(35058, 'shows_traktHiddenManager', 'tools.png', 'DefaultAddonService.png', isFolder=False)
		self.addDirectoryItem(35059, 'movies_traktUnfinishedManager', 'tools.png', 'DefaultAddonService.png', isFolder=False)
		self.addDirectoryItem(35060, 'episodes_traktUnfinishedManager', 'tools.png', 'DefaultAddonService.png', isFolder=False)
		self.addDirectoryItem(35061, 'movies_traktWatchListManager', 'tools.png', 'DefaultAddonService.png', isFolder=False)
		self.addDirectoryItem(35062, 'shows_traktWatchListManager', 'tools.png', 'DefaultAddonService.png', isFolder=False)
		self.addDirectoryItem(35063, 'movies_traktCollectionManager', 'tools.png', 'DefaultAddonService.png', isFolder=False)
		self.addDirectoryItem(35064, 'shows_traktCollectionManager', 'tools.png', 'DefaultAddonService.png', isFolder=False)
		self.addDirectoryItem(35065, 'tools_traktLikedListManager', 'tools.png', 'DefaultAddonService.png', isFolder=False)
		self.addDirectoryItem(35066, 'tools_forceTraktSync', 'tools.png', 'DefaultAddonService.png', isFolder=False)
		self.endDirectory()

	def loggingNavigator(self):
		self.addDirectoryItem(32524, 'tools_viewLogFile&name=luc_kodi', 'tools.png', 'DefaultAddonProgram.png', isFolder=False)
#		self.addDirectoryItem(32525, 'tools_clearLogFile', 'tools.png', 'DefaultAddonProgram.png', isFolder=False)
		self.addDirectoryItem(32526, 'tools_ShowChangelog&name=luc_kodi', 'tools.png', 'DefaultAddonProgram.png', isFolder=False)
		self.addDirectoryItem(32527, 'tools_uploadLogFile&name=luc_kodi', 'tools.png', 'DefaultAddonProgram.png', isFolder=False)
#		self.addDirectoryItem(32530, 'tools_viewLogFile&name=jacksparrowscrapers', 'tools.png', 'DefaultAddonProgram.png', isFolder=False)
#		self.addDirectoryItem(32531, 'tools_ShowChangelog&name=jacksparrowscrapers', 'tools.png', 'DefaultAddonProgram.png', isFolder=False)
		self.addDirectoryItem(32532, 'tools_viewLogFile&name=Kodi', 'tools.png', 'DefaultAddonProgram.png', isFolder=False)
		self.addDirectoryItem(32198, 'tools_uploadLogFile&name=Kodi', 'tools.png', 'DefaultAddonProgram.png', isFolder=False)
		self.endDirectory()

	def cf(self):
		# v1.0.73 — el contador va EL PRIMERO de Cache Functions, antes de
		# cualquier borrado. Este es el menu al que el usuario llega de verdad
		# (Tools > Cache Functions); la entrada equivalente de settings.xml
		# esta en una pestaña que hay que ir a buscar. Y el orden importa:
		# mirar cuanto ocupa cada grupo antes de decidir que se suelta es la
		# secuencia util, no al reves.
		self.addDirectoryItem(400760, 'tools_cacheFootprint', 'tools.png', 'DefaultAddonService.png', isFolder=False)
		self.addDirectoryItem(400860, 'tools_maintenanceCleanNow', 'tools.png', 'DefaultAddonService.png', isFolder=False)
		self.addDirectoryItem(32610, 'cache_clearAll', 'tools.png', 'DefaultAddonService.png', isFolder=False)
		self.addDirectoryItem(32611, 'cache_clearSources', 'tools.png', 'DefaultAddonService.png', isFolder=False)
		self.addDirectoryItem(32612, 'cache_clearMeta', 'tools.png', 'DefaultAddonService.png', isFolder=False)
		self.addDirectoryItem(32613, 'cache_clearCache', 'tools.png', 'DefaultAddonService.png', isFolder=False)
		self.addDirectoryItem(32614, 'cache_clearSearch', 'tools.png', 'DefaultAddonService.png', isFolder=False)
		self.addDirectoryItem(32615, 'cache_clearBookmarks', 'tools.png', 'DefaultAddonService.png', isFolder=False)
		self.addDirectoryItem('Reset Feedback (For You)', 'cache_clearRecoFeedback', 'tools.png', 'DefaultAddonService.png', isFolder=False)
		self.endDirectory()

	def library(self): # -- Library - 9
		self.addDirectoryItem(32557, 'tools_openSettings&query=9.0', 'tools.png', 'DefaultAddonProgram.png', isFolder=False)
		self.addDirectoryItem(32558, 'library_update', 'library_update.png', 'DefaultAddonLibrary.png', isFolder=False)
		self.addDirectoryItem(32676, 'library_clean', 'library_update.png', 'DefaultAddonLibrary.png', isFolder=False)
		self.addDirectoryItem(32700, 'library_premiereLists', 'calendar.png', 'DefaultVideoPlaylists.png') # v2.0.0
		self.addDirectoryItem(32818, 'library_premiereMovies', 'calendar.png', 'DefaultVideoPlaylists.png') # v2.0.13
		self.addDirectoryItem(32559, getSetting('library.movie'), 'movies.png', 'DefaultMovies.png', isAction=False)
		self.addDirectoryItem(32560, getSetting('library.tv'), 'tvshows.png', 'DefaultTVShows.png', isAction=False)
		if self.traktCredentials:
			self.addDirectoryItem(32561, 'library_moviesToLibrary&url=traktcollection&name=traktcollection', 'trakt.png', 'DefaultMovies.png', isFolder=False)
			self.addDirectoryItem(32562, 'library_moviesToLibrary&url=traktwatchlist&name=traktwatchlist', 'trakt.png', 'DefaultMovies.png', isFolder=False)
			self.addDirectoryItem(32672, 'library_moviesListToLibrary&url=traktlists', 'trakt.png', 'DefaultMovies.png', isFolder=False)
			self.addDirectoryItem(32673, 'library_moviesListToLibrary&url=traktlikedlists', 'trakt.png', 'DefaultMovies.png', isFolder=False)
		if self.tmdbSessionID:
			self.addDirectoryItem('TMDb: Import Movie Watchlist...', 'library_moviesToLibrary&url=tmdb_watchlist&name=tmdb_watchlist', 'tmdb.png', 'DefaultMovies.png', isFolder=False)
			self.addDirectoryItem('TMDb: Import Movie Favorites...', 'library_moviesToLibrary&url=tmdb_favorites&name=tmdb_favorites', 'tmdb.png', 'DefaultMovies.png', isFolder=False)
			self.addDirectoryItem('TMDb: Import Movie User list...', 'library_moviesListToLibrary&url=tmdb_userlists', 'tmdb.png', 'DefaultMovies.png', isFolder=False)
		if self.traktCredentials:
			self.addDirectoryItem(32563, 'library_tvshowsToLibrary&url=traktcollection&name=traktcollection', 'trakt.png', 'DefaultTVShows.png', isFolder=False)
			self.addDirectoryItem(32564, 'library_tvshowsToLibrary&url=traktwatchlist&name=traktwatchlist', 'trakt.png', 'DefaultTVShows.png', isFolder=False)
			self.addDirectoryItem(32674, 'library_tvshowsListToLibrary&url=traktlists', 'trakt.png', 'DefaultMovies.png', isFolder=False)
			self.addDirectoryItem(32675, 'library_tvshowsListToLibrary&url=traktlikedlists', 'trakt.png', 'DefaultMovies.png', isFolder=False)
		if self.tmdbSessionID:
			self.addDirectoryItem('TMDb: Import TV Watchlist...', 'library_tvshowsToLibrary&url=tmdb_watchlist&name=tmdb_watchlist', 'tmdb.png', 'DefaultMovies.png', isFolder=False)
			self.addDirectoryItem('TMDb: Import TV Favorites...', 'library_tvshowsToLibrary&url=tmdb_favorites&name=tmdb_favorites', 'tmdb.png', 'DefaultMovies.png', isFolder=False)
			self.addDirectoryItem('TMDb: Import TV User list...', 'library_tvshowsListToLibrary&url=tmdb_userlists', 'tmdb.png', 'DefaultMovies.png', isFolder=False)
		self.endDirectory()

	def downloads(self):
		movie_downloads = getSetting('movie.download.path')
		tv_downloads = getSetting('tv.download.path')
		if len(control.listDir(movie_downloads)[0]) > 0: self.addDirectoryItem(32001, movie_downloads, 'movies.png', 'DefaultMovies.png', isAction=False)
		if len(control.listDir(tv_downloads)[0]) > 0: self.addDirectoryItem(32002, tv_downloads, 'tvshows.png', 'DefaultTVShows.png', isAction=False)
		self.endDirectory()

	def premium_services(self):
		self.addDirectoryItem('Debrid Hub', 'tools_debridHub', 'premium.png', 'premium.png')
		if getMenuEnabled('navi.realdebrid'): self.addDirectoryItem(40058, 'rd_ServiceNavigator', 'realdebrid.png', 'realdebrid.png')
		if getMenuEnabled('navi.premiumize'): self.addDirectoryItem(40057, 'pm_ServiceNavigator', 'premiumize.png', 'premiumize.png')
		if getMenuEnabled('navi.alldebrid'): self.addDirectoryItem(40059, 'ad_ServiceNavigator', 'alldebrid.png', 'alldebrid.png')
		# v2.0.20: la entrada de TorBox salia rotulada "Enable TorBox Menu" (32224 es
		# el rotulo del AJUSTE, no del menu).
		if getMenuEnabled('navi.torbox'): self.addDirectoryItem('TorBox', 'tb_ServiceNavigator', 'torbox.png', 'torbox.png')
		if getMenuEnabled('navi.offcloud'): self.addDirectoryItem(49109, 'oc_ServiceNavigator', 'offcloud.png', 'offcloud.png')
		self.endDirectory()

	def alldebrid_service(self):
		if getSetting('alldebrid.token'):
			self.addDirectoryItem('All-Debrid: Cloud Storage', 'ad_CloudStorage', 'alldebrid.png', 'DefaultAddonService.png')
			self.addDirectoryItem('All-Debrid: Transfers', 'ad_Transfers', 'alldebrid.png', 'DefaultAddonService.png')
			self.addDirectoryItem('All-Debrid: Account Info', 'ad_AccountInfo', 'alldebrid.png', 'DefaultAddonService.png', isFolder=False)
		else:
			self.addDirectoryItem('[I]Please visit My Accounts for setup[/I]', 'tools_openSettings&query=7.0', 'alldebrid.png', 'DefaultAddonService.png', isFolder=False)
		self.endDirectory()

	def torbox_service(self):
		# v1.0.52: estas dos entradas apuntaban a las acciones en_* (Easynews)
		# por un copy/paste heredado: "TorBox: Search" abría el buscador de
		# Easynews y "TorBox: Account Info" el diálogo de cuenta de Easynews.
		if getSetting('torbox.username'):
			self.addDirectoryItem('TorBox: Cloud Storage', 'tb_CloudStorage', 'torbox.png', 'DefaultAddonService.png')
			self.addDirectoryItem('TorBox: Account Info', 'tb_AccountInfo', 'torbox.png', 'DefaultAddonService.png', isFolder=False)
		else:
			self.addDirectoryItem('[I]Please visit My Accounts for setup[/I]', 'tools_openSettings&query=7.0', 'torbox.png', 'DefaultAddonService.png', isFolder=False)
		self.endDirectory()

	def offcloud_service(self):
		if getSetting('offcloud.token'):
			self.addDirectoryItem('Offcloud: Cloud Storage', 'oc_CloudStorage', 'offcloud.png', 'DefaultAddonService.png')
			self.addDirectoryItem('Offcloud: Account Info', 'oc_AccountInfo', 'offcloud.png', 'DefaultAddonService.png', isFolder=False)
		else:
			self.addDirectoryItem('[I]Please visit My Accounts for setup[/I]', 'tools_openSettings&query=7.0', 'offcloud.png', 'DefaultAddonService.png', isFolder=False)
		self.endDirectory()

	def easynews_service(self):
		# v1.0.52: el router llamaba a este método desde en_ServiceNavigator
		# pero no existía -> AttributeError. Ahora sí existe.
		if getSetting('easynews.username'):
			self.addDirectoryItem('Easynews: Search', 'en_Search', 'search.png', 'DefaultAddonsSearch.png')
			self.addDirectoryItem('Easynews: Account Info', 'en_AccountInfo', 'easynews.png', 'DefaultAddonService.png', isFolder=False)
		else:
			self.addDirectoryItem('[I]Please visit My Accounts for setup[/I]', 'tools_openSettings&query=7.0', 'easynews.png', 'DefaultAddonService.png', isFolder=False)
		self.endDirectory()

	def premiumize_service(self):
		if getSetting('premiumize.token'):
			self.addDirectoryItem('Premiumize: My Files', 'pm_MyFiles', 'premiumize.png', 'DefaultAddonService.png')
			self.addDirectoryItem('Premiumize: Transfers', 'pm_Transfers', 'premiumize.png', 'DefaultAddonService.png')
			self.addDirectoryItem('Premiumize: Account Info', 'pm_AccountInfo', 'premiumize.png', 'DefaultAddonService.png', isFolder=False)
		else:
			self.addDirectoryItem('[I]Please visit My Accounts for setup[/I]', 'tools_openSettings&query=7.0', 'premiumize.png', 'DefaultAddonService.png', isFolder=False)
		self.endDirectory()

	def realdebrid_service(self):
		if getSetting('realdebrid.token'):
			self.addDirectoryItem('Real-Debrid: Torrent Transfers', 'rd_UserTorrentsToListItem', 'realdebrid.png', 'DefaultAddonService.png')
			self.addDirectoryItem('Real-Debrid: My Downloads', 'rd_MyDownloads&query=1', 'realdebrid.png', 'DefaultAddonService.png')
			self.addDirectoryItem('Real-Debrid: Account Info', 'rd_AccountInfo', 'realdebrid.png', 'DefaultAddonService.png', isFolder=False )
		else:
			self.addDirectoryItem('[I]Please visit My Accounts for setup[/I]', 'tools_openSettings&query=7.0', 'realdebrid.png', 'DefaultAddonService.png', isFolder=False)
		self.endDirectory()

	def search(self):
		# AI Search (Gemini) — destacado al inicio del menú
		self.addDirectoryItem('[COLOR %s]%s[/COLOR]' % (self.highlight_color, getLS(40610)), 'aiSearch', 'search.png', 'DefaultAddonsSearch.png')
		self.addDirectoryItem('[COLOR %s]%s[/COLOR]' % (self.highlight_color, getLS(40615)), 'aiSearchMovies', 'movies.png', 'DefaultMovies.png')
		self.addDirectoryItem('[COLOR %s]%s[/COLOR]' % (self.highlight_color, getLS(40616)), 'aiSearchTvshows', 'tvshows.png', 'DefaultTVShows.png')
		self.addDirectoryItem(33042, 'movieSearch', 'trakt.png' if self.iconLogos else 'search.png', 'DefaultAddonsSearch.png')
		self.addDirectoryItem(33043, 'tvSearch', 'trakt.png' if self.iconLogos else 'search.png', 'DefaultAddonsSearch.png')
		# v2.0.04: busqueda de personas en TMDb (abre el teclado, por eso no es carpeta)
		self.addDirectoryItem(33044, 'moviePerson', 'tmdb.png' if self.iconLogos else 'people.png', 'DefaultActor.png', isFolder=False)
		self.addDirectoryItem(33045, 'tvPerson', 'tmdb.png' if self.iconLogos else 'people.png', 'DefaultActor.png', isFolder=False)
		self.endDirectory()

	def views(self):
		try:
			from sys import argv # some functions throw invalid handle -1 unless this is imported here.
			syshandle = int(argv[1])
			control.hide()
			items = [(getLS(32001), 'movies'), (getLS(32002), 'tvshows'), (getLS(32054), 'seasons'), (getLS(32326), 'episodes')]
			select = control.selectDialog([i[0] for i in items], getLS(32049))
			if select == -1: return
			content = items[select][1]
			title = getLS(32059)
			url = 'plugin://plugin.video.luc_kodi/?action=tools_addView&content=%s' % content
			poster, banner, fanart = control.addonPoster(), control.addonBanner(), control.addonFanart()
			item = control.item(label=title, offscreen=True)
			item.setInfo(type='video', infoLabels = {'title': title}) if KODI_VERSION < 20 else item.getVideoInfoTag().setTitle(title)
			item.setArt({'icon': poster, 'thumb': poster, 'poster': poster, 'fanart': fanart, 'banner': banner})
			control.addItem(handle=syshandle, url=url, listitem=item, isFolder=False)
			control.content(syshandle, content)
			control.directory(syshandle, cacheToDisc=True)
			from resources.lib.modules import views
			# force=False: esta pantalla existe para que el usuario ELIJA vista, asi
			# que no se le impone la rejilla encima (v1.0.81).
			views.setView(content, {}, force=False)
		except:
			from resources.lib.modules import log_utils
			log_utils.error()
			return

	def accountCheck(self):
		if not self.traktCredentials:
			control.hide()
			control.notification(message=32042, icon='WARNING')
			sysexit()

	def clearCacheAll(self):
		control.hide()
		if not control.yesnoDialog(getLS(32077), '', ''): return
		try:
			def cache_clear_all():
				try:
					from resources.lib.database import cache, providerscache, metacache, fanarttv_cache
					fanarttv_cache.cache_clear()
					providerscache.cache_clear_providers()
					metacache.cache_clear_meta()
					cache.cache_clear()
					# feedback NOT cleared here — it's persistent user data, not a cache
					return True
				except:
					from resources.lib.modules import log_utils
					log_utils.error()
			if cache_clear_all(): control.notification(message=32089)
			else: control.notification(message=33586)
		except:
			from resources.lib.modules import log_utils
			log_utils.error()

	def clearRecoFeedback(self):
		control.hide()
		if not control.yesnoDialog('Reset Feedback', 'All likes and Not Interested signals will be deleted.\nThe engine will learn from scratch.', ''): return
		try:
			from resources.lib.database import reco_feedback
			reco_feedback.clear_all()
			control.notification(title='For You', message='Feedback reset successfully')
		except:
			from resources.lib.modules import log_utils
			log_utils.error()

	def clearCacheProviders(self):
		control.hide()
		if not control.yesnoDialog(getLS(32056), '', ''): return
		try:
			from resources.lib.database import providerscache
			if providerscache.cache_clear_providers(): control.notification(message=32090)
			else: control.notification(message=33586)
		except:
			from resources.lib.modules import log_utils
			log_utils.error()

	def clearCacheMeta(self):
		control.hide()
		if not control.yesnoDialog(getLS(32076), '', ''): return
		try:
			from resources.lib.database import metacache
			if metacache.cache_clear_meta(): control.notification(message=32091)
			else: control.notification(message=33586)
		except:
			from resources.lib.modules import log_utils
			log_utils.error()

	def clearCache(self):
		control.hide()
		if not control.yesnoDialog(getLS(32056), '', ''): return
		try:
			from resources.lib.database import cache
			if cache.cache_clear(): control.notification(message=32092)
			else: control.notification(message=33586)
		except:
			from resources.lib.modules import log_utils
			log_utils.error()

	def clearMetaAndCache(self):
		control.hide()
		if not control.yesnoDialog(getLS(35531), '', ''): return
		try:
			def cache_clear_both():
				try:
					from resources.lib.database import cache, metacache
					metacache.cache_clear_meta()
					cache.cache_clear()
					return True
				except:
					from resources.lib.modules import log_utils
					log_utils.error()
			if cache_clear_both(): control.notification(message=35532)
			else: control.notification(message=33586)
		except:
			from resources.lib.modules import log_utils
			log_utils.error()

	def clearCacheSearch(self):
		control.hide()
		if not control.yesnoDialog(getLS(32056), '', ''): return
		try:
			from resources.lib.database import cache
			if cache.cache_clear_search(): control.notification(message=32093)
			else: control.notification(message=33586)
		except:
			from resources.lib.modules import log_utils
			log_utils.error()

	def clearCacheSearchPhrase(self, table, name):
		control.hide()
		if not control.yesnoDialog(getLS(32056), '', ''): return
		try:
			from resources.lib.database import cache
			if cache.cache_clear_SearchPhrase(table, name): control.notification(message=32094)
			else: control.notification(message=33586)
		except:
			from resources.lib.modules import log_utils
			log_utils.error()

	def clearBookmarks(self):
		control.hide()
		if not control.yesnoDialog(getLS(32056), '', ''): return
		try:
			from resources.lib.database import cache
			if cache.cache_clear_bookmarks(): control.notification(message=32100)
			else: control.notification(message=33586)
		except:
			from resources.lib.modules import log_utils
			log_utils.error()

	def clearBookmark(self, name, year):
		control.hide()
		if not control.yesnoDialog(getLS(32056), '', ''): return
		try:
			from resources.lib.database import cache
			if cache.cache_clear_bookmark(name, year): control.notification(title=name, message=32102)
			else: control.notification(message=33586)
		except:
			from resources.lib.modules import log_utils
			log_utils.error()

	def addDirectoryItem(self, name, query, poster, icon, context=None, queue=False, isAction=True, isFolder=True, isPlayable=False, isSearch=False, table=''):
		try:
			from sys import argv # some functions like ActivateWindow() throw invalid handle less this is imported here.
			if isinstance(name, int): name = getLS(name)
			url = 'plugin://plugin.video.luc_kodi/?action=%s' % query if isAction else query
			poster = control.joinPath(self.artPath, poster) if self.artPath else icon
			if not icon.startswith('Default'): icon = control.joinPath(self.artPath, icon)
			cm = []
			queueMenu = getLS(32065)
			if queue: cm.append((queueMenu, 'RunPlugin(plugin://plugin.video.luc_kodi/?action=playlist_QueueItem)'))
			if context: cm.append((getLS(context[0]), 'RunPlugin(plugin://plugin.video.luc_kodi/?action=%s)' % context[1]))
			if isSearch: cm.append(('Clear Search Phrase', 'RunPlugin(plugin://plugin.video.luc_kodi/?action=cache_clearSearchPhrase&source=%s&name=%s)' % (table, quote_plus(name))))
			cm.append(('[COLOR red]luc_kodi Settings[/COLOR]', 'RunPlugin(plugin://plugin.video.luc_kodi/?action=tools_openSettings)'))
			item = control.item(label=name, offscreen=True)
			attach_cm(item, cm)
			if isPlayable: item.setProperty('IsPlayable', 'true')
			item.setArt({'icon': icon, 'poster': poster, 'thumb': poster, 'fanart': control.addonFanart(), 'banner': poster})
			item.setInfo(type='video', infoLabels={'plot': name}) if KODI_VERSION < 20 else item.getVideoInfoTag().setPlot(name)
			control.addItem(handle=int(argv[1]), url=url, listitem=item, isFolder= isFolder)
		except:
			from resources.lib.modules import log_utils
			log_utils.error()

	def endDirectory(self, is_root=False):
		from sys import argv # some functions throw invalid handle -1 unless this is imported here.
		from resources.lib.modules import navstate; navstate.note_menu() # v2.0.09: Exit list
		syshandle = int(argv[1])
		if control.skin == 'skin.auramod': content = 'addons'
		else: content = ''
		control.content(syshandle, content) # some skins use their own thumb for things like "genres" when content type is set here
		control.directory(syshandle, cacheToDisc=True)
