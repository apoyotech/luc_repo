# -*- coding: utf-8 -*-
"""
	luc_kodi Add-on
"""

from resources.lib.modules import app_keys
from datetime import datetime, timedelta
from json import dumps as jsdumps
import re
from threading import Thread
from time import time as _now
from urllib.parse import quote_plus, urlencode, parse_qsl, urlparse, urlsplit
from resources.lib.database import cache, metacache, fanarttv_cache, traktsync
from resources.lib.indexers.tmdb import Movies as tmdb_indexer, logo_url
from resources.lib.indexers.fanarttv import FanartTv
from resources.lib.modules import cleangenre
from resources.lib.modules import control
from resources.lib.modules.context_hub import attach_cm # v2.0.09: modern panel or classic Kodi menu
from resources.lib.modules.premiere_movies import offer as premiere_offer # v2.0.13: Premiere Movies
from resources.lib.modules import lang_assist
from resources.lib.modules.playcount import getMovieIndicators, getMovieOverlay
from resources.lib.modules import tools
from resources.lib.modules import poster_rotator
from resources.lib.modules import badge_posters
from resources.lib.modules import trakt
from resources.lib.modules import simkl
from resources.lib.modules import views

getLS = control.lang
getSetting = control.setting
KODI_VERSION = control.getKodiVersion()
# v2.0.04: Anos, Generos, Certificados e Idiomas traen solo lo popular de TMDb
# (popularidad, con al menos estos votos), sin seguir el orden general de listas.
# Anos va del actual hacia atras hasta 1960.
YEAR_FIRST = 1960
POPULAR_MIN_VOTES_MOVIES = 100
# v2.0.08: Movies > Languages sin suelo de votos y, como TV Shows > Languages, solo con
# lo que esta en el catalogo por suscripcion de las grandes plataformas (EE. UU.): ahi
# salen en WEB-DL y los scrapers las encuentran. Con 100 votos se perdia mucho cine
# que no es en ingles, que se vota poco.
# Los mismos valores que en menus/tvshows.py (no se importa: cargaria todo ese modulo
# en cada lista de peliculas). Si se cambian alli, cambiarlos aqui.
LANG_STREAMING_PROVIDERS = '8|9|337|1899|15|350|386|2303|11|191|457|575|526|43|34|99|73|300|207|538'
LANG_STREAMING_MONETIZATION = 'flatrate|free|ads'
LANG_TOP_MIN_VOTES_MOVIES = 100 # Top rated: mismo suelo que el resto de listas de peliculas
LANG_STREAMING_REGION = 'US'


def _aborted():
	"""v2.0.31: Kodi pide abortar a un listado cuando el usuario sale antes de
	que termine (Back). Sin mirarlo, worker() seguia lanzando tandas de 40
	peticiones para una lista que ya nadie iba a ver, y Kodi acababa matando
	el script ("script didn't stop in 5 seconds", kodi.log del 11-nov-2026)."""
	try: return bool(control.monitor.abortRequested())
	except Exception: return False


class Movies:
	def __init__(self, notifications=True):
		self.list = []
		self.page_limit = getSetting('page.item.limit')
		self.search_page_limit = getSetting('search.page.limit')
		self.notifications = notifications
		# v1.0.81 — ganchos del precache de catalogo. Los menus NUNCA los ponen:
		# solo el servicio de catalogo, para que el enriquecido de estas listas
		# comparta el semaforo global de peticiones y respete el presupuesto de
		# tiempo de la pasada en segundo plano.
		self.precache_sem = None
		self.precache_deadline = None
		self.date_time = datetime.now()
		self.today_date = (self.date_time).strftime('%Y-%m-%d')
		self.hidecinema = getSetting('hidecinema') == 'true'
		self.trakt_user = getSetting('trakt.username').strip()
		self.traktCredentials = trakt.getTraktCredentialsInfo()
		self.lang = control.apiLanguage()['trakt']
		self.tmdb_key = getSetting('tmdb.api.key')
		if not self.tmdb_key: self.tmdb_key = app_keys.get('tmdb')
		self.tmdb_session_id = getSetting('tmdb.session_id')
		self.user = str(self.tmdb_key)
		# Auto-activar FanartTV en pantallas 4K (clearlogo, clearart, poster/fanart alternativos)
		# Si el usuario tiene FanartTV desactivado pero tiene pantalla 4K detectada, se activa
		# automáticamente para aprovechar el arte adicional en alta resolución.
		# is_4k_display() espera al flag con timeout corto — evita race en boot.
		from resources.lib.modules.gui_resolution import is_4k_display as _is_4k_display
		_is_4k = _is_4k_display()
		self.enable_fanarttv = getSetting('enable.fanarttv') == 'true' or _is_4k
		self.prefer_tmdbArt = getSetting('prefer.tmdbArt') == 'true'
		self.prefer_en_titles = getSetting('title.lang.en') == 'true'
		self.unairedcolor = control.getColor(getSetting('movie.unaired.identify'))
		self.highlight_color = control.getHighlightColor()
		self.tmdb_link = 'https://api.themoviedb.org'
		self.tmdb_popular_link = 'https://api.themoviedb.org/3/movie/popular?api_key=%s&language=en-US&region=US&page=1'
		self.tmdb_toprated_link = 'https://api.themoviedb.org/3/movie/top_rated?api_key=%s&page=1'
		self.tmdb_upcoming_link = 'https://api.themoviedb.org/3/discover/movie?api_key=%s&language=en-US&region=US&primary_release_date.gte=%s&with_release_type=3|2|1&sort_by=popularity.desc&page=1' % ('%s', (self.date_time + timedelta(days=1)).strftime('%Y-%m-%d'))
		self.tmdb_nowplaying_link = 'https://api.themoviedb.org/3/movie/now_playing?api_key=%s&language=en-US&region=US&page=1'
		self.tmdb_boxoffice_link = 'https://api.themoviedb.org/3/discover/movie?api_key=%s&language=en-US&region=US&sort_by=revenue.desc&page=1'
		self.tmdb_userlists_link = 'https://api.themoviedb.org/3/account/{account_id}/lists?api_key=%s&language=en-US&session_id=%s&page=1' % ('%s', self.tmdb_session_id) # used by library import only
		self.tmdb_genre_link = 'https://api.themoviedb.org/3/discover/movie?api_key=%s&language=en-US&region=US&primary_release_date.lte=%s&with_genres=%s&sort_by=popularity.desc&vote_count.gte=%s&page=1' % ('%s', self.today_date, '%s', POPULAR_MIN_VOTES_MOVIES)
		# v2.0.04: cada ano trae lo popular de ese ano (popularidad de TMDb con un
		# suelo de votos), no el orden general de listas: lo que de verdad merecio la pena.
		self.tmdb_year_link = 'https://api.themoviedb.org/3/discover/movie?api_key=%s&language=en-US&region=US&primary_release_date.lte=%s&certification_country=US&primary_release_year=%s&sort_by=popularity.desc&vote_count.gte=%s&page=1' % ('%s', self.today_date, '%s', POPULAR_MIN_VOTES_MOVIES)
		self.tmdb_certification_link = 'https://api.themoviedb.org/3/discover/movie?api_key=%s&language=en-US&region=US&primary_release_date.lte=%s&certification_country=US&certification=%s&sort_by=popularity.desc&vote_count.gte=%s&page=1' % ('%s', self.today_date, '%s', POPULAR_MIN_VOTES_MOVIES)
		self.tmdb_watchproviders_link = 'https://api.themoviedb.org/3/discover/movie?api_key=%s&language=en-US&region=US&watch_region=US&with_watch_providers=%s&sort_by=%s&vote_count.gte=100&page=1' % ('%s', '%s', self.tmdb_DiscoverSort())
		# --- Release calendar (global, NOT watchlist-based) ------------------
		# Lo mismo que hace el calendario de Trakt: ventana de fechas sobre el
		# catalogo entero. TMDb release types: 1 premiere, 2 limited, 3 theatrical,
		# 4 digital, 5 physical, 6 TV. El filtro region= ya descarta el ruido de
		# titulos sin estreno real en ese mercado.
		_cal = lambda days: (self.date_time + timedelta(days=days)).strftime('%Y-%m-%d')
		self.tmdb_calendarTheaters_link = 'https://api.themoviedb.org/3/discover/movie?api_key=%s&language=en-US&region=US&with_release_type=3|2&release_date.gte=%s&release_date.lte=%s&sort_by=popularity.desc&page=1' % ('%s', _cal(-45), self.today_date)
		self.tmdb_calendarSoon_link = 'https://api.themoviedb.org/3/discover/movie?api_key=%s&language=en-US&region=US&with_release_type=3|2&release_date.gte=%s&release_date.lte=%s&sort_by=popularity.desc&page=1' % ('%s', _cal(1), _cal(180))
		self.tmdb_calendarDigital_link = 'https://api.themoviedb.org/3/discover/movie?api_key=%s&language=en-US&region=US&with_release_type=4&release_date.gte=%s&release_date.lte=%s&sort_by=popularity.desc&page=1' % ('%s', _cal(-60), _cal(45))

		# v2.0.04: lo que leia paginas de IMDb sale ahora de TMDb, y los Oscar de
		# Wikidata (ver modules/awards.py). IMDb cambio su maquetado y el lector
		# viejo ya no encontraba nada.
		self.tmdb_mostvoted_link = 'https://api.themoviedb.org/3/discover/movie?api_key=%s&language=en-US&region=US&primary_release_date.lte=%s&sort_by=vote_count.desc&page=1' % ('%s', self.today_date)
		# v2.0.08: cada idioma abre un submenu con cuatro listas (language_menu)
		_lp = '&watch_region=%s&with_watch_providers=%s&with_watch_monetization_types=%s' % (LANG_STREAMING_REGION, LANG_STREAMING_PROVIDERS, LANG_STREAMING_MONETIZATION)
		_lb = 'https://api.themoviedb.org/3/discover/movie?api_key=%s&language=en-US'
		self.tmdb_language_link = _lb + '&primary_release_date.lte=%s&with_original_language=%s' % (self.today_date, '%s') + _lp + '&sort_by=popularity.desc&page=1'
		self.tmdb_language_new_link = _lb + '&primary_release_date.gte=%s&primary_release_date.lte=%s&with_original_language=%s' % ((self.date_time - timedelta(days=365)).strftime('%Y-%m-%d'), self.today_date, '%s') + _lp + '&sort_by=popularity.desc&page=1'
		self.tmdb_language_top_link = _lb + '&primary_release_date.lte=%s&with_original_language=%s' % (self.today_date, '%s') + _lp + '&sort_by=vote_average.desc&vote_count.gte=%s&page=1' % LANG_TOP_MIN_VOTES_MOVIES
		self.tmdb_language_all_link = _lb + '&primary_release_date.lte=%s&with_original_language=%s&sort_by=popularity.desc&page=1' % (self.today_date, '%s')
		# Filmografia: with_people cuenta reparto y equipo (actores y directores),
		# como hacia role= en IMDb. Solo lo ya estrenado, lo mas reciente primero.
		self.tmdb_person_link = 'https://api.themoviedb.org/3/discover/movie?api_key=%s&language=en-US&primary_release_date.lte=%s&with_people=%s&sort_by=primary_release_date.desc&page=1' % ('%s', self.today_date, '%s')
		self.tmdb_persons_link = 'https://api.themoviedb.org/3/search/person?api_key=%s&language=en-US&include_adult=false&page=1&query='
		self.tmdb_personlist_link = 'https://api.themoviedb.org/3/person/popular?api_key=%s&language=en-US&page=1'
		self.wikidata_link = 'https://query.wikidata.org'
		self.oscars_link = 'https://query.wikidata.org/sparql?award=winners&page=1'
		self.oscarsnominees_link = 'https://query.wikidata.org/sparql?award=nominees&page=1'
		# v2.0.04: Ocultar en cines. Antes solo lo hacian las listas de IMDb; ahora
		# las de TMDb que hacian lo mismo (populares, mas taquilleras, mas votadas,
		# generos, certificados e idiomas) dejan fuera lo estrenado en los ultimos
		# N meses (hidecinema.rollback). Estrenos, cartelera, calendario y anos no:
		# ahi lo reciente es justo lo que se busca.
		if self.hidecinema:
			try: _months = int(getSetting('hidecinema.rollback') or 6)
			except Exception: _months = 6
			_cut = (self.date_time - timedelta(days=_months * 30)).strftime('%Y-%m-%d')
			def _hide(link):
				if 'primary_release_date.lte=' in link: return re.sub(r'primary_release_date\.lte=[0-9-]+', 'primary_release_date.lte=%s' % _cut, link)
				return link.replace('&page=1', '&primary_release_date.lte=%s&page=1' % _cut)
			self.tmdb_popular_link = 'https://api.themoviedb.org/3/discover/movie?api_key=%s&language=en-US&region=US&sort_by=popularity.desc&primary_release_date.lte=%s&page=1' % ('%s', _cut)
			# v2.0.08: New on streaming no: lo que ya esta en plataformas ha salido de cines, y el corte lo dejaria casi vacio
			for _name in ('tmdb_boxoffice_link', 'tmdb_mostvoted_link', 'tmdb_genre_link', 'tmdb_certification_link', 'tmdb_language_link', 'tmdb_language_top_link', 'tmdb_language_all_link'):
				setattr(self, _name, _hide(getattr(self, _name)))
		self.tmdb_language_links = (self.tmdb_language_link, self.tmdb_language_new_link, self.tmdb_language_top_link, self.tmdb_language_all_link) # v2.0.08: tras el corte de cines
		self.tmdb_anime_link = 'https://api.themoviedb.org/3/discover/movie?api_key=%s&with_genres=16&with_original_language=ja&sort_by=popularity.desc&page=1'

		self.trakt_link = 'https://api.trakt.tv'
		self.search_link = 'https://api.trakt.tv/search/movie?limit=%s&page=1&query=' % self.search_page_limit
		self.traktlistsearch_link = 'https://api.trakt.tv/search/list?limit=%s&page=1&query=' % self.page_limit
		self.traktlists_link = 'https://api.trakt.tv/users/me/lists'
		self.traktlikedlists_link = 'https://api.trakt.tv/users/likes/lists?limit=1000000' # used by library import only
		self.traktwatchlist_link = 'https://api.trakt.tv/users/me/watchlist/movies?limit=%s&page=1' % self.page_limit # this is now a dummy link for pagination to work
		self.traktcollection_link = 'https://api.trakt.tv/users/me/collection/movies?limit=%s&page=1' % self.page_limit # this is now a dummy link for pagination to work
		self.trakthistory_link = 'https://api.trakt.tv/users/me/history/movies?limit=%s&page=1' % self.page_limit
		self.traktlist_link = 'https://api.trakt.tv/users/%s/lists/%s/items/movies?limit=%s&page=1' % ('%s', '%s', self.page_limit) # local pagination, limit and page used to advance, pulled from request
		self.traktunfinished_link = 'https://api.trakt.tv/sync/playback/movies?limit=40'
		self.traktanticipated_link = 'https://api.trakt.tv/movies/anticipated?limit=%s&page=1' % self.page_limit 
		self.trakttrending_link = 'https://api.trakt.tv/movies/trending?limit=%s&page=1' % self.page_limit
		self.traktwatchedweekly_link = 'https://api.trakt.tv/movies/watched/weekly?limit=%s&page=1' % self.page_limit
		self.traktwatchedmonthly_link = 'https://api.trakt.tv/movies/watched/monthly?limit=%s&page=1' % self.page_limit
		self.traktboxoffice_link = 'https://api.trakt.tv/movies/boxoffice' # Returns the top 10 grossing movies in the U.S. box office last weekend
		self.traktpopular_link = 'https://api.trakt.tv/movies/popular?limit=%s&page=1' % self.page_limit
		self.traktrecommendations_link = 'https://api.trakt.tv/recommendations/movies?limit=40'
		self.trakt_popularLists_link = 'https://api.trakt.tv/lists/popular?limit=%s&page=1' % self.page_limit
		self.trakt_trendingLists_link = 'https://api.trakt.tv/lists/trending?limit=%s&page=1' % self.page_limit

		# SIMKL public trending lists (no login required, client_id-only).
		# extended=tmdb gives us the tmdb id + title + year upfront so the
		# worker pipeline can resolve metadata without an extra round trip.
		self.simkl_link = 'https://api.simkl.com'
		self.simkldata_link = 'https://data.simkl.in'
		self.simkltrendingtoday_link = 'https://data.simkl.in/discover/trending/movies/today_100.json'
		self.simkltrendingweek_link  = 'https://data.simkl.in/discover/trending/movies/week_100.json'
		self.simkltrendingmonth_link = 'https://data.simkl.in/discover/trending/movies/month_100.json'
		# PunchPlay: catalogo PUBLICO, sin auth ni token (/api/public/v1).
		# `type` es 'movie' o 'show', los unicos kinds enrutables de PunchPlay.
		self.punchplay_link = 'https://punchplay.tv'
		self.punchplaytrending_link = 'https://punchplay.tv/api/public/v1/catalog/trending?type=movie'
		self.punchplaypopular_link = 'https://punchplay.tv/api/public/v1/catalog/discover?category=popular&type=movie'
		# v1.0.99 WeTrakr Discover. Van con el token del usuario (cuota suya).
		self.wetrakr_link = 'https://api.wetrakr.com'
		self.wetrakrtrending_link = 'https://api.wetrakr.com/discover/trending?filter_type=movie&limit=100'
		self.wetrakrpopular_link = 'https://api.wetrakr.com/discover/popular?filter_type=movie&limit=100'
		self.wetrakrtoprated_link = 'https://api.wetrakr.com/discover/toprated?filter_type=movie&limit=100'
		self.wetrakrrecommended_link = 'https://api.wetrakr.com/discover/recommended?filter_type=movie&limit=100'

	def get(self, url, idx=True, create_directory=True):
		self.list = []
		try:
			try: url = getattr(self, url + '_link')
			except Exception: pass
			try: u = urlparse(url).netloc.lower()
			except Exception: pass
			if u in self.trakt_link and '/users/' in url:
				try:
					isTraktHistory = (url.split('&page=')[0] in self.trakthistory_link)
					if '/users/me/' not in url: raise Exception()
					if '/collection/' in url: return self.traktCollection(url)
					if '/watchlist/' in url: return self.traktWatchlist(url)
					if trakt.getActivity() > cache.timeout(self.trakt_list, url, self.trakt_user):
						self.list = cache.get(self.trakt_list, 0, url, self.trakt_user)
					else: self.list = cache.get(self.trakt_list, 720, url, self.trakt_user)
				except Exception:
					self.list = self.trakt_userList(url)
				if isTraktHistory and self.list:
					for i in range(len(self.list)): self.list[i]['traktHistory'] = True
				if idx: self.worker()
				if not isTraktHistory: self.sort()
			elif u in self.trakt_link and self.search_link in url:
				self.list = cache.get(self.trakt_list, 6, url, self.trakt_user)
				if idx: self.worker()
			elif u in self.trakt_link and self._is_pooled(url):
				self.list = self.trakt_pooled(url) # v2.0.22: paginas llenas sin repetidos
				if idx: self.worker()
			elif u in self.trakt_link:
				self.list = cache.get(self.trakt_list, 24, url, self.trakt_user)
				if idx: self.worker()
			elif u in self.simkl_link or u in self.simkldata_link:
				# SIMKL trending: cache TTL matches the period — today=6h, week=24h, month=96h
				# '/today' casa con la URL vieja (/trending/today) y con el fichero (/movies/today_100.json)
				if '/today' in url:   _ttl = 6
				elif '/week' in url:  _ttl = 24
				elif '/month' in url: _ttl = 96
				else: _ttl = 24
				from resources.lib.modules import simkl as simkl_mod
				self.list = cache.get(simkl_mod.simkl_list, _ttl, url)
				if idx: self.worker()
			elif u in self.punchplay_link:
				# Trending se mueve a diario; discover/popular aguanta mas.
				_ttl = 6 if '/trending' in url else 24
				from resources.lib.modules import punchplay as punchplay_mod
				self.list = cache.get(punchplay_mod.punchplay_list, _ttl, url)
				if idx: self.worker()
			elif u in self.wetrakr_link:
				_ttl = 6 if ('/trending' in url or '/recommended' in url) else 24
				from resources.lib.modules import wetrakr as wetrakr_mod
				self.list = cache.get(wetrakr_mod.wetrakr_list, _ttl, url)
				if idx: self.worker()
			elif u in self.wikidata_link:
				self.list = self.awards_list(url)
				if idx: self.worker()
			if self.list is None: self.list = []
			if not (self.list and self.list[0].get('traktHistory')): self.dedupe(url) # v2.0.22: el historial si repite a proposito
			if idx and create_directory: self.movieDirectory(self.list)
			return self.list
		except Exception:
			from resources.lib.modules import log_utils
			log_utils.error()
			if not self.list:
				control.hide()
				if self.notifications: control.notification(title=32001, message=33049)

	# v2.0.22: Trakt Trending trae la misma pelicula varias veces (en la Shield
	# llego a salir una sola 8-9 veces en una pagina de 20). Quitar las repetidas
	# dejaba paginas de 7 o 9 titulos. Ahora se pide Trending a Trakt en paginas
	# de 100, se guarda una sola reserva de titulos UNICOS por lista (24 h, igual
	# que antes) y cada pagina del menu es un tramo de esa reserva: paginas
	# completas y sin repetir nada que ya salio en una pagina anterior.
	# La reserva crece por tramos (100, 200, 400...) y cada tramo continua el
	# anterior en vez de empezar de cero, asi el orden no cambia al avanzar.
	POOL_STEP = 100      # titulos unicos del primer tramo
	POOL_RAW_LIMIT = 100 # tamano de cada peticion a Trakt
	POOL_RAW_CAP = 40    # tope de peticiones por lista

	def _is_pooled(self, url):
		try: path = urlsplit(url).path.rstrip('/')
		except Exception: return False
		return path in ('/shows/trending', '/movies/trending') and 'limit=' in url

	def _pool_key(self, i):
		if i.get('tmdb'): return ('tmdb', str(i['tmdb']))
		if i.get('imdb'): return ('imdb', str(i['imdb']))
		if i.get('tvdb'): return ('tvdb', str(i['tvdb']))
		return ('title', '%s|%s' % ((i.get('tvshowtitle') or i.get('title') or '').lower(), i.get('year', '')))

	def _trakt_pool(self, base, target, user):
		"""Reserva de titulos unicos de una lista publica de Trakt (cacheada por
		cache.get). Devuelve {'items', 'raw', 'done'}: raw es la ultima pagina de
		Trakt leida y done que Trakt ya no tiene mas."""
		prev = None
		if target > self.POOL_STEP:
			prev = cache.get(self._trakt_pool, 24, base, target // 2, user)
		items = list(prev['items']) if prev else []
		raw = prev['raw'] if prev else 0
		done = prev['done'] if prev else False
		seen = set(self._pool_key(i) for i in items)
		sep = '&' if '?' in base else '?'
		while not done and len(items) < target and raw < self.POOL_RAW_CAP:
			raw += 1
			page = self.trakt_list('%s%spage=%d&limit=%d' % (base, sep, raw, self.POOL_RAW_LIMIT), user)
			if not page:
				if not items: return None # Trakt no contesta: no se guarda nada
				done = True
				break
			for i in page:
				key = self._pool_key(i)
				if key in seen: continue
				seen.add(key)
				i.pop('next', None)
				items.append(i)
		if raw >= self.POOL_RAW_CAP: done = True
		return {'items': items, 'raw': raw, 'done': done}

	def trakt_pooled(self, url):
		if ',return' in url: url = url.split(',return')[0]
		q = dict(parse_qsl(urlsplit(url).query))
		try: page = max(1, int(q.get('page', 1)))
		except Exception: page = 1
		try: limit = max(1, int(q.get('limit', self.page_limit)))
		except Exception: limit = 20
		extra = dict((k, v) for k, v in q.items() if k not in ('page', 'limit'))
		base = url.split('?')[0] + ('?' + urlencode(extra) if extra else '')
		target = self.POOL_STEP
		while target < page * limit: target *= 2
		pool = cache.get(self._trakt_pool, 24, base, target, self.trakt_user)
		if not pool or not pool.get('items'): return []
		items = pool['items']
		start = (page - 1) * limit
		chunk = [dict(i) for i in items[start:start + limit]]
		more = len(items) > start + limit or not pool.get('done')
		next = ''
		if chunk and more:
			nq = dict(extra) ; nq.update({'page': str(page + 1), 'limit': str(limit)})
			next = url.split('?')[0] + '?' + urlencode(nq).replace('%2C', ',')
		for i in chunk: i['next'] = next
		return chunk

	def dedupe(self, url=''):
		"""v2.0.22: deja una sola ficha por pelicula (mismo criterio que
		TVshows.dedupe). Trakt Trending puede traer el mismo titulo varias veces
		en una pagina y la cache de 24 h lo mantenia. La clave es un solo id por
		ficha (tmdb > imdb > titulo+ano). No se usa en el historial de Trakt,
		donde una pelicula vista dos veces sale dos veces a proposito."""
		if not self.list: return
		seen, out = set(), []
		for i in self.list:
			try:
				if i.get('tmdb'): key = ('tmdb', str(i['tmdb']))
				elif i.get('imdb'): key = ('imdb', str(i['imdb']))
				else: key = ('title', '%s|%s' % ((i.get('title') or '').lower(), i.get('year', '')))
			except Exception: key = None
			if key is not None:
				if key in seen: continue
				seen.add(key)
			out.append(i)
		dropped = len(self.list) - len(out)
		if dropped:
			from resources.lib.modules import log_utils
			log_utils.log('[luc_kodi] Movies: %s repeated movie(s) left out of %s' % (dropped, str(url).split('?')[0]), level=log_utils.LOGINFO)
			self.list = out

	def getTMDb(self, url, create_directory=True):
		self.list = []
		try:
			try: url = getattr(self, url + '_link')
			except Exception: pass
			try: u = urlparse(url).netloc.lower()
			except Exception: pass
			if u in self.tmdb_link and '/list/' in url:
				self.list = tmdb_indexer().tmdb_collections_list(url) # caching handled in list indexer
				self.sort()
			elif u in self.tmdb_link and '/list/' not in url:
				self.list = tmdb_indexer().tmdb_list(url) # caching handled in list indexer
			if self.list is None: self.list = []
			lang_assist.register(url, self.list, 'movie', self.tmdb_language_links) # v2.0.08: titulos de Languages para el ayudante langhelper
			if create_directory: self.movieDirectory(self.list)
			return self.list
		except Exception:
			from resources.lib.modules import log_utils
			log_utils.error()
			if not self.list:
				control.hide()
				if self.notifications: control.notification(title=32001, message=33049)

	def getTraktPublicLists(self, url, create_directory=True):
		self.list = []
		try:
			try: url = getattr(self, url + '_link')
			except Exception: pass
			if '/popular' in url:
				self.list = cache.get(self.trakt_public_list, 168, url)
			elif '/trending' in url:
				self.list = cache.get(self.trakt_public_list, 48, url)
			else:
				self.list = cache.get(self.trakt_public_list, 24, url)
			if self.list is None: self.list = []
			if create_directory: self.addDirectory(self.list)
			return self.list
		except Exception:
			from resources.lib.modules import log_utils
			log_utils.error()

	def unfinished(self, url, idx=True, create_directory=True):
		self.list = []
		try:
			self.list = traktsync.fetch_bookmarks(imdb='', ret_all=True, ret_type='movies')
			if idx: self.worker()
			self.list = sorted(self.list, key=lambda k: k['paused_at'], reverse=True)
			if self.list is None: self.list = []
			if create_directory: self.movieDirectory(self.list, unfinished=True, next=False)
			return self.list
		except Exception:
			from resources.lib.modules import log_utils
			log_utils.error()

	def simkl_progress(self, url, idx=True, create_directory=True):
		"""SIMKL "Mi Progreso" (películas). Sesiones de /sync/playback/movie
		con progreso entre 15% y <85%, ordenadas por pausa más reciente."""
		self.list = []
		try:
			self.list = simkl.getMoviesProgress()
			if not self.list: self.list = []
			if idx: self.worker()
			self.list = sorted(self.list, key=lambda k: k.get('paused_at') or '', reverse=True)
			if create_directory: self.movieDirectory(self.list, unfinished=True, next=False)
			return self.list
		except Exception:
			from resources.lib.modules import log_utils
			log_utils.error()

	def unfinishedManager(self):
		try:
			control.busy()
			list = self.unfinished(url='traktunfinished', create_directory=False)
			control.hide()
			# v2.0.03: sin nada en progreso, un aviso en vez de una ventana vacia
			if not list: return control.notification(title='Trakt Progress Manager', message=33049)
			from resources.lib.windows.traktmovieprogress_manager import TraktMovieProgressManagerXML
			window = TraktMovieProgressManagerXML('traktmovieprogress_manager.xml', control.addonPath(control.addonId()), results=list)
			selected_items = window.run()
			del window
			if selected_items:
				refresh = 'plugin.video.luc_kodi' in control.infoLabel('Container.PluginName')
				trakt.scrobbleResetItems(imdb_ids=selected_items, refresh=refresh, widgetRefresh=True)
		except Exception:
			from resources.lib.modules import log_utils
			log_utils.error()

	def collectionManager(self):
		try:
			control.busy()
			self.list = traktsync.fetch_collection('movies_collection')
			self.worker()
			self.sort()
			# self.list = sorted(self.list, key=lambda k: re.sub(r'(^the |^a |^an )', '', k['tvshowtitle'].lower()), reverse=False)
			control.hide()
			from resources.lib.windows.traktbasic_manager import TraktBasicManagerXML
			window = TraktBasicManagerXML('traktbasic_manager.xml', control.addonPath(control.addonId()), results=self.list)
			selected_items = window.run()
			del window
			if selected_items:
				# refresh = 'plugin.video.luc_kodi' in control.infoLabel('Container.PluginName')
				trakt.removeCollectionItems('movies', selected_items)
		except Exception:
			from resources.lib.modules import log_utils
			log_utils.error()
			control.hide()

	def watchlistManager(self):
		try:
			control.busy()
			self.list = traktsync.fetch_watch_list('movies_watchlist')
			self.worker()
			self.sort(type='movies.watchlist')
			# self.list = sorted(self.list, key=lambda k: re.sub(r'(^the |^a |^an )', '', k['tvshowtitle'].lower()), reverse=False)
			control.hide()
			from resources.lib.windows.traktbasic_manager import TraktBasicManagerXML
			window = TraktBasicManagerXML('traktbasic_manager.xml', control.addonPath(control.addonId()), results=self.list)
			selected_items = window.run()
			del window
			if selected_items:
				# refresh = 'plugin.video.luc_kodi' in control.infoLabel('Container.PluginName')
				trakt.removeWatchlistItems('movies', selected_items)
		except Exception:
			from resources.lib.modules import log_utils
			log_utils.error()
			control.hide()

	def likedListsManager(self):
		try:
			items = traktsync.fetch_liked_list('', True)
			from resources.lib.windows.traktlikedlist_manager import TraktLikedListManagerXML
			window = TraktLikedListManagerXML('traktlikedlist_manager.xml', control.addonPath(control.addonId()), results=items)
			selected_items = window.run()
			del window
			if selected_items:
				# refresh = 'plugin.video.luc_kodi' in control.infoLabel('Container.PluginName')
				trakt.remove_liked_lists(selected_items)
		except Exception:
			from resources.lib.modules import log_utils
			log_utils.error()

	def sort(self, type='movies'):
		try:
			if not self.list: return
			attribute = int(getSetting('sort.%s.type' % type))
			reverse = int(getSetting('sort.%s.order' % type)) == 1
			if attribute == 0: reverse = False # Sorting Order is not enabled when sort method is "Default"
			if attribute > 0:
				if attribute == 1:
					try: self.list = sorted(self.list, key=lambda k: re.sub(r'(^the |^a |^an )', '', k['title'].lower()), reverse=reverse)
					except Exception: self.list = sorted(self.list, key=lambda k: k['title'].lower(), reverse=reverse)
				elif attribute == 2: self.list = sorted(self.list, key=lambda k: float(k['rating']), reverse=reverse)
				elif attribute == 3: self.list = sorted(self.list, key=lambda k: int(str(k['votes']).replace(',', '')), reverse=reverse)
				elif attribute == 4:
					for i in range(len(self.list)):
						if 'premiered' not in self.list[i]: self.list[i]['premiered'] = ''
					self.list = sorted(self.list, key=lambda k: k['premiered'], reverse=reverse)
				elif attribute == 5:
					for i in range(len(self.list)):
						if 'added' not in self.list[i]: self.list[i]['added'] = ''
					self.list = sorted(self.list, key=lambda k: k['added'], reverse=reverse)
				elif attribute == 6:
					for i in range(len(self.list)):
						if 'lastplayed' not in self.list[i]: self.list[i]['lastplayed'] = ''
					self.list = sorted(self.list, key=lambda k: k['lastplayed'], reverse=reverse)
			elif reverse:
				self.list = list(reversed(self.list))
		except Exception:
			from resources.lib.modules import log_utils
			log_utils.error()

	def tmdb_DiscoverSort(self):
		sort = int(getSetting('sort.movies.type'))
		tmdb_sort = 'popularity' # default sort=0
		if sort == 1: tmdb_sort = 'title'
		elif sort == 2: tmdb_sort = 'vote_average'
		elif sort == 3: tmdb_sort = 'vote_count'
		elif sort in (4, 5, 6): tmdb_sort = 'primary_release_date'
		tmdb_sort_order = '.asc' if (int(getSetting('sort.movies.order')) == 0) else '.desc'
		sort_string = tmdb_sort + tmdb_sort_order
		if sort == 2: sort_string = sort_string + '&vote_count.gte=500'
		return sort_string

	def search(self):
		from resources.lib.menus import navigator
		navigator.Navigator().addDirectoryItem(getLS(32603) % self.highlight_color, 'movieSearchnew', 'search.png', 'DefaultAddonsSearch.png', isFolder=False)
		from sqlite3 import dbapi2 as database
		try:
			if not control.existsPath(control.dataPath): control.makeFile(control.dataPath)
			dbcon = database.connect(control.searchFile)
			dbcur = dbcon.cursor()
			dbcur.executescript('''CREATE TABLE IF NOT EXISTS movies (ID Integer PRIMARY KEY AUTOINCREMENT, term);''')
			dbcur.execute('''SELECT * FROM movies ORDER BY ID DESC''')
			dbcur.connection.commit()
			lst = []
			delete_option = False
			for (id, term) in sorted(dbcur.fetchall(), key=lambda k: re.sub(r'(^the |^a |^an )', '', k[1].lower()), reverse=False):
				if term not in str(lst):
					delete_option = True
					navigator.Navigator().addDirectoryItem(term, 'movieSearchterm&name=%s' % term, 'search.png', 'DefaultAddonsSearch.png', isSearch=True, table='movies')
					lst += [(term)]
		except Exception:
			from resources.lib.modules import log_utils
			log_utils.error()
		finally:
			try:
				dbcur.close()
			except Exception:
				pass
			try:
				dbcon.close()
			except Exception:
				pass
		if delete_option: navigator.Navigator().addDirectoryItem(32605, 'cache_clearSearch', 'tools.png', 'DefaultAddonService.png', isFolder=False)
		navigator.Navigator().endDirectory()

	def search_new(self):
		k = control.keyboard('', getLS(32010))
		k.doModal()
		q = k.getText() if k.isConfirmed() else None
		if not q: return control.closeAll()
		from sqlite3 import dbapi2 as database
		try:
			dbcon = database.connect(control.searchFile)
			dbcur = dbcon.cursor()
			dbcur.execute('''INSERT INTO movies VALUES (?,?)''', (None, q))
			dbcur.connection.commit()
		except Exception:
			from resources.lib.modules import log_utils
			log_utils.error()
		finally:
			try:
				dbcur.close()
			except Exception:
				pass
			try:
				dbcon.close()
			except Exception:
				pass
		url = self.search_link + quote_plus(q)
		control.closeAll()
		control.execute('ActivateWindow(Videos,plugin://plugin.video.luc_kodi/?action=movies&url=%s,return)' % (quote_plus(url)))

	def search_term(self, name):
		url = self.search_link + quote_plus(name)
		self.get(url)

	def person(self):
		k = control.keyboard('', getLS(32010))
		k.doModal()
		q = k.getText().strip() if k.isConfirmed() else None
		if not q: return control.closeAll()
		url = self.tmdb_persons_link + quote_plus(q)
		control.closeAll()
		control.execute('ActivateWindow(Videos,plugin://plugin.video.luc_kodi/?action=moviePersons&url=%s,return)' % (quote_plus(url)))

	def persons(self, url):
		if url is None: self.list = cache.get(self.tmdb_person_list, 24, self.tmdb_personlist_link, 3)
		else: self.list = cache.get(self.tmdb_person_list, 1, url, 1)
		if self.list is None: self.list = []
		if self.list:
			for i in range(0, len(self.list)): self.list[i].update({'content': 'actors', 'icon': 'DefaultActor.png', 'action': 'tmdbmovies'})
		self.addDirectory(self.list)
		return self.list

	def genres(self, url):
		try: url = getattr(self, url + '_link')
		except Exception: pass
		genres = [
			('Action', 'action', True, '28'), ('Adventure', 'adventure', True, '12'), ('Animation', 'animation', True, '16'),
			('Biography', 'biography', True), ('Comedy', 'comedy', True, '35'), ('Crime', 'crime', True, '80'),
			('Documentary', 'documentary', True, '99'), ('Drama', 'drama', True, '18'), ('Family', 'family', True, '10751'),
			('Fantasy', 'fantasy', True, '14'), ('Film-Noir', 'film-noir', True), ('History', 'history', True, '36'),
			('Horror', 'horror', True, '27'), ('Music', 'music', True, '10402'), ('Musical', 'musical', True),
			('Mystery', 'mystery', True, '9648'), ('Romance', 'romance', True, '10749'), ('Science Fiction', 'sci-fi', True, '878'),
			('Sport', 'sport', True), ('Thriller', 'thriller', True, '53'), ('War', 'war', True, '10752'), ('Western', 'western', True, '37')]
		for i in genres:
			if self.tmdb_link in url:
				try: self.list.append({'content': 'genres', 'name': cleangenre.lang(i[0], self.lang), 'url': url % ('%s', i[3]), 'image': control.genreArt(i[0]), 'icon': control.genreArt(i[0]), 'action': 'tmdbmovies'})
				except Exception: pass
		self.addDirectory(self.list)
		return self.list

	def watchproviders(self):
		use_jw = (getSetting('streaming.use_justwatch') == 'true')
		jw_map = {}
		if use_jw:
			try:
				from resources.lib.indexers.justwatch import TMDB_TO_JW_PACKAGE
				jw_map = TMDB_TO_JW_PACKAGE
			except Exception: use_jw = False
		watchproviders = tmdb_indexer().get_watchproviders()
		for i in watchproviders:
			if use_jw:
				# i[1] can be '337' or '337|390' — take the first id for the JW lookup
				try: tmdb_pid = int(str(i[1]).split('|')[0])
				except Exception: tmdb_pid = None
				jw_code = jw_map.get(tmdb_pid) if tmdb_pid else None
				if not jw_code: continue  # no JW mapping → skip this provider in JW mode
				self.list.append({'content': 'studios', 'name': i[0], 'url': jw_code, 'image': i[2], 'icon': i[2], 'action': 'movieJustWatch'})
			else:
				url = self.tmdb_watchproviders_link % ('%s', i[1])
				# 4th tuple element (optional) = watch_region for providers with no US
				# presence (e.g. SkyShowtime). Swap the hardcoded US region in the link.
				region = i[3] if len(i) > 3 and i[3] else 'US'
				if region != 'US':
					url = url.replace('region=US&watch_region=US', 'region=%s&watch_region=%s' % (region, region))
				self.list.append({'content': 'studios', 'name': i[0], 'url': url, 'image': i[2], 'icon': i[2], 'action': 'tmdbmovies'})
		self.addDirectory(self.list)
		return self.list

	def getJustWatch(self, jw_package_code, create_directory=True):
		self.list = []
		try:
			self.list = tmdb_indexer().jw_list(jw_package_code)
			if self.list is None: self.list = []
			if create_directory: self.movieDirectory(self.list)
			return self.list
		except Exception:
			from resources.lib.modules import log_utils
			log_utils.error()
			if not self.list:
				control.hide()
				if self.notifications: control.notification(title=32001, message=33049)

	def languages(self):
		# v2.0.04: fuera bosnio, bulgaro, croata, macedonio, serbio y esloveno (muy poco catalogo),
		# y persa, panyabi, hebreo, hungaro, griego, ucraniano e islandes (casi nada con fuentes en cache)
		languages = [('Arabic', 'ar'), ('Chinese', 'zh'), ('Dutch', 'nl'),
			('English', 'en'), ('Finnish', 'fi'), ('French', 'fr'), ('German', 'de'), ('Hindi ', 'hi'),
			('Italian', 'it'), ('Japanese', 'ja'), ('Korean', 'ko'), ('Norwegian', 'no'), ('Polish', 'pl'), ('Portuguese', 'pt'), ('Romanian', 'ro'),
			('Russian', 'ru'), ('Spanish', 'es'), ('Swedish', 'sv'), ('Turkish', 'tr')]
		for i in languages:
			self.list.append({'content': 'countries', 'name': str(i[0]), 'url': self.tmdb_language_link % ('%s', i[1]), 'image': control.flagArt(i[1]), 'icon': control.flagArt(i[1]), 'action': 'movieLanguageMenu'})
		self.addDirectory(self.list)
		return self.list

	def language_menu(self, url):
		"""v2.0.08: submenu de un idioma. url es su lista Popular, de la que se saca el
		codigo. Popular, New y Top rated son de las plataformas; Everything no."""
		m = re.search(r'with_original_language=([a-z]{2})', url or '')
		if not m: return self.addDirectory([])
		code = m.group(1)
		for label, link in ((40102, self.tmdb_language_link), (40103, self.tmdb_language_new_link), (40104, self.tmdb_language_top_link), (40105, self.tmdb_language_all_link)):
			self.list.append({'content': 'countries', 'name': getLS(label), 'url': link % ('%s', code), 'image': control.flagArt(code), 'icon': control.flagArt(code), 'action': 'tmdbmovies'})
		self.addDirectory(self.list)
		return self.list

	def certifications(self, url):
		try: url = getattr(self, url + '_link')
		except Exception: pass
		certificates = [
			('General Audience (G)', 'US%3AG', 'G'),
			('Parental Guidance (PG)', 'US%3APG', 'PG'),
			('Parental Caution (PG-13)', 'US%3APG-13', 'PG-13'),
			('Parental Restriction (R)', 'US%3AR', 'R'),
			('Mature Audience (NC-17)', 'US%3ANC-17', 'NC-17')]
		for i in certificates:
			if self.tmdb_link in url: self.list.append({'content': 'tags', 'name': str(i[0]), 'url': url % ('%s', i[2]), 'image': 'certificates.png', 'icon': 'certificates.png', 'action': 'tmdbmovies'})
		self.addDirectory(self.list)
		return self.list

	def years(self, url):
		try: url = getattr(self, url + '_link')
		except Exception: pass
		year = (self.date_time.strftime('%Y'))
		for i in range(int(year), YEAR_FIRST - 1, -1): # v2.0.04: hasta 1960
			if self.tmdb_link in url: self.list.append({'content': 'years', 'name': str(i), 'url': url % ('%s', str(i)), 'image': 'calendar.png', 'icon': 'DefaultYear.png', 'action': 'tmdbmovies'})
		self.addDirectory(self.list)
		return self.list

	def moviesListToLibrary(self, url):
		url = getattr(self, url + '_link')
		u = urlparse(url).netloc.lower()
		try:
			control.hide()
			# if u in self.tmdb_link: items = tmdb_indexer.TMDb().userlists(url)
			if u in self.tmdb_link: items = tmdb_indexer().userlists(url)
			elif u in self.trakt_link:
				if url in self.traktlikedlists_link:
					items = self.traktLikedLists()
				else: items = self.trakt_user_lists(url, self.trakt_user)
			items = [(i['name'], i['url']) for i in items]
			message = 32663
			if 'themoviedb' in url: message = 32681
			select = control.selectDialog([i[0] for i in items], getLS(message))
			list_name = items[select][0]
			if select == -1: return
			link = items[select][1]
			link = link.split('&sort_by')[0]
			link = link.split('?limit=')[0]
			from resources.lib.modules import library
			library.libmovies().range(link, list_name)
		except Exception:
			from resources.lib.modules import log_utils
			log_utils.error()

	def userlists(self):
		userlists = []
		try:
			if not self.traktCredentials: raise Exception()
			activity = trakt.getActivity()
			self.list = [] ; lists = []
			try:
				if activity > cache.timeout(self.trakt_user_lists, self.traktlists_link, self.trakt_user): raise Exception()
				lists += cache.get(self.trakt_user_lists, 720, self.traktlists_link, self.trakt_user)
			except Exception:
				lists += cache.get(self.trakt_user_lists, 0, self.traktlists_link, self.trakt_user)
			userlists += lists
		except Exception: pass
		try:
			if self.tmdb_session_id == '': raise Exception()
			self.list = []
			url = self.tmdb_link + '/3/account/{account_id}/lists?api_key=%s&language=en-US&session_id=%s&page=1' % ('%s', self.tmdb_session_id)
			# lists = cache.get(tmdb_indexer.TMDb().userlists, 0, url)
			lists = cache.get(tmdb_indexer().userlists, 0, url)
			for i in range(len(lists)): lists[i].update({'image': 'tmdb.png', 'icon': 'DefaultVideoPlaylists.png', 'action': 'tmdbmovies'})
			userlists += lists
		except Exception: pass
		self.list = []
		for i in range(len(userlists)): # Filter the user's own lists that were
			contains = False
			adapted = userlists[i]['url'].replace('/me/', '/%s/' % self.trakt_user)
			for j in range(len(self.list)):
				if adapted == self.list[j]['url'].replace('/me/', '/%s/' % self.trakt_user):
					contains = True
					break
			if not contains: self.list.append(userlists[i])
		if self.tmdb_session_id != '': # TMDb Favorites
			url = self.tmdb_link + '/3/account/{account_id}/favorite/movies?api_key=%s&session_id=%s&sort_by=created_at.asc&page=1' % ('%s', self.tmdb_session_id) 
			self.list.insert(0, {'name': getLS(32026), 'url': url, 'image': 'tmdb.png', 'icon': 'DefaultVideoPlaylists.png', 'action': 'tmdbmovies'})
		if self.tmdb_session_id != '': # TMDb Watchlist
			url = self.tmdb_link + '/3/account/{account_id}/watchlist/movies?api_key=%s&session_id=%s&sort_by=created_at.asc&page=1' % ('%s', self.tmdb_session_id)
			self.list.insert(0, {'name': getLS(32033), 'url': url, 'image': 'tmdb.png', 'icon': 'DefaultVideoPlaylists.png', 'action': 'tmdbmovies'})
		self.addDirectory(self.list, queue=True)
		return self.list

	def traktCollection(self, url, create_directory=True):
		self.list = []
		try:
			q = dict(parse_qsl(urlsplit(url).query))
			index = int(q['page']) - 1
			self.list = traktsync.fetch_collection('movies_collection')
			self.sort() # sort before local pagination
			if getSetting('trakt.paginate.lists') == 'true' and self.list:
				paginated_ids = [self.list[x:x + int(self.page_limit)] for x in range(0, len(self.list), int(self.page_limit))]
				self.list = paginated_ids[index]
			try:
				if int(q['limit']) != len(self.list): raise Exception()
				q.update({'page': str(int(q['page']) + 1)})
				q = (urlencode(q)).replace('%2C', ',')
				next = url.replace('?' + urlparse(url).query, '') + '?' + q
			except Exception: next = ''
			for i in range(len(self.list)): self.list[i]['next'] = next
			self.worker()
			if self.list is None: self.list = []
			if create_directory: self.movieDirectory(self.list)
			return self.list
		except Exception:
			from resources.lib.modules import log_utils
			log_utils.error()

	def traktWatchlist(self, url, create_directory=True):
		self.list = []
		try:
			q = dict(parse_qsl(urlsplit(url).query))
			index = int(q['page']) - 1
			self.list = traktsync.fetch_watch_list('movies_watchlist')
			# 2026 self-heal: si la tabla local esta vacia pero hay credenciales
			# Trakt, el marcador last_watchlisted_at quedo envenenado por una
			# sync fallida (cambio de API 30-jun-2026) y el servicio nunca
			# reintenta. Forzamos una sync inline con backoff de 10 min.
			if not self.list and trakt.getTraktCredentialsInfo():
				import time as _t
				_prop = 'luc_kodi.watchlist_selfheal.movies_watchlist'
				_last = control.homeWindow.getProperty(_prop)
				if not _last or (int(_t.time()) - int(_last)) > 600:
					control.homeWindow.setProperty(_prop, str(int(_t.time())))
					trakt.sync_watch_list(forced=True)
					self.list = traktsync.fetch_watch_list('movies_watchlist')
			self.sort(type='movies.watchlist') # sort before local pagination
			if getSetting('trakt.paginate.lists') == 'true' and self.list:
				paginated_ids = [self.list[x:x + int(self.page_limit)] for x in range(0, len(self.list), int(self.page_limit))]
				self.list = paginated_ids[index]
			try:
				if int(q['limit']) != len(self.list): raise Exception()
				q.update({'page': str(int(q['page']) + 1)})
				q = (urlencode(q)).replace('%2C', ',')
				next = url.replace('?' + urlparse(url).query, '') + '?' + q
			except Exception: next = ''
			for i in range(len(self.list)): self.list[i]['next'] = next
			self.worker()
			if self.list is None: self.list = []
			if create_directory: self.movieDirectory(self.list)
			return self.list
		except Exception:
			from resources.lib.modules import log_utils
			log_utils.error()

	def traktLikedLists(self):
		items = traktsync.fetch_liked_list('', True)
		for item in items:
			try:
				if item['content_type'] == 'shows': continue
				list_name = item['list_name']
				list_owner = item['list_owner']
				list_owner_slug = item['list_owner_slug']
				list_id = item['trakt_id']
				list_url = self.traktlist_link % (list_owner_slug, list_id)
				next = ''
				label = '%s - [COLOR %s]%s[/COLOR]' % (list_name, self.highlight_color, list_owner)
				self.list.append({'name': label, 'list_type': 'traktPulicList', 'url': list_url, 'list_owner': list_owner, 'list_name': list_name, 'list_id': list_id, 'context': list_url, 'next': next, 'image': 'trakt.png', 'icon': 'DefaultVideoPlaylists.png', 'action': 'movies'})
			except Exception:
				from resources.lib.modules import log_utils
				log_utils.error()
		self.list = sorted(self.list, key=lambda k: re.sub(r'(^the |^a |^an )', '', k['name'].lower()))
		self.addDirectory(self.list, queue=True)
		return self.list

	def trakt_list(self, url, user):
		self.list = []
		if ',return' in url: url = url.split(',return')[0]
		# v1.0.95: sin limit= (importar watchlist/coleccion/listas a la
		# biblioteca, boxoffice) se recorren todas las paginas; en los
		# endpoints sin paginar el helper hace una sola peticion.
		if 'limit=' not in url: items = trakt.getTraktAsJsonPaginated(url, page_size=250, apply_sort=True)
		else: items = trakt.getTraktAsJson(url)
		if not items: return
		try:
			q = dict(parse_qsl(urlsplit(url).query))
			if int(q['limit']) != len(items): raise Exception()
			q.update({'page': str(int(q['page']) + 1)})
			q = (urlencode(q)).replace('%2C', ',')
			next = url.replace('?' + urlparse(url).query, '') + '?' + q
		except Exception: next = ''
		for item in items: # rating and votes via TMDb, or I must use "extended=full" and it slows down
			try:
				values = {}
				values['next'] = next 
				values['added'] = item.get('listed_at', '')
				values['paused_at'] = item.get('paused_at', '') # for unfinished
				try: values['progress'] = item['progress']
				except Exception: values['progress'] = ''
				try: values['lastplayed'] = item['watched_at'] # for history
				except Exception: values['lastplayed'] = ''
				movie = item.get('movie') or item
				values['title'] = movie.get('title')
				values['originaltitle'] = values['title']
				values['year'] = str(movie.get('year', '')) if movie.get('year') else ''
				ids = movie.get('ids', {})
				values['imdb'] = str(ids.get('imdb', '')) if ids.get('imdb') else ''
				values['tmdb'] = str(ids.get('tmdb', '')) if ids.get('tmdb') else ''
				values['tvdb'] = ''
				self.list.append(values)
			except Exception:
				from resources.lib.modules import log_utils
				log_utils.error()
		return self.list

	def trakt_userList(self, url, create_directory=True):
		self.list = []
		q = dict(parse_qsl(urlsplit(url).query))
		index = int(q['page']) - 1
		def userList_allItems(url):
			# v1.0.95 (issue #1): la URL llegaba sin limit/page y getTraktAsJson
			# no pagina: Trakt devolvia solo la primera pagina de la lista.
			items = trakt.getTraktAsJsonPaginated(url, page_size=250, apply_sort=True)
			if not items: return
			for item in items:
				try:
					values = {}
					values['added'] = item.get('listed_at', '')
					movie = item.get('movie')
					if not movie: continue
					values['title'] = movie.get('title')
					values['originaltitle'] = values['title']
					try: values['premiered'] = movie.get('released', '')[:10]
					except Exception: values['premiered'] = ''
					values['year'] = str(movie.get('year', '')) if movie.get('year') else ''
					if not values['year']:
						try: values['year'] = str(values['premiered'][:4])
						except Exception: values['year'] = ''
					ids = movie.get('ids', {})
					values['imdb'] = str(ids.get('imdb', '')) if ids.get('imdb') else ''
					values['tmdb'] = str(ids.get('tmdb', '')) if ids.get('tmdb') else ''
					values['rating'] = movie.get('rating')
					values['votes'] = movie.get('votes')
					self.list.append(values)
				except Exception:
					from resources.lib.modules import log_utils
					log_utils.error()
			return self.list
		self.list = cache.get(userList_allItems, 48, url.split('?')[0] + '?extended=full')
		if not self.list: return
		self.sort() # sort before local pagination
		total_pages = 1
		if getSetting('trakt.paginate.lists') == 'true':
			paginated_ids = [self.list[x:x + int(self.page_limit)] for x in range(0, len(self.list), int(self.page_limit))]
			total_pages = len(paginated_ids)
			self.list = paginated_ids[index]
		try:
			if int(q['limit']) != len(self.list): raise Exception()
			if int(q['page']) == total_pages: raise Exception()
			q.update({'page': str(int(q['page']) + 1)})
			q = (urlencode(q)).replace('%2C', ',')
			next = url.replace('?' + urlparse(url).query, '') + '?' + q
		except Exception: next = ''
		for i in range(len(self.list)): self.list[i]['next'] = next
		self.worker()
		if self.list is None: self.list = []
		if create_directory: self.movieDirectory(self.list)
		return self.list

	def trakt_user_lists(self, url, user):
		items = traktsync.fetch_user_lists('', True)
		for item in items:
			try:
				if item['content_type'] == 'shows': continue
				list_name = item['list_name']
				list_owner = item['list_owner']
				list_owner_slug = item['list_owner_slug']
				list_id = item['trakt_id']
				list_url = self.traktlist_link % (list_owner_slug, list_id)
				next = ''
				label = '%s - [COLOR %s]%s[/COLOR]' % (list_name, self.highlight_color, list_owner)
				self.list.append({'name': label, 'url': list_url, 'list_owner': list_owner, 'list_name': list_name, 'list_id': list_id, 'context': list_url, 'next': next, 'image': 'trakt.png', 'icon': 'DefaultVideoPlaylists.png', 'action': 'movies'})
			except Exception:
				from resources.lib.modules import log_utils
				log_utils.error()
		self.list = sorted(self.list, key=lambda k: re.sub(r'(^the |^a |^an )', '', k['name'].lower()))
		return self.list

	def trakt_public_list(self, url):
		# v2.0.03: sin respuesta de Trakt (red caida, 5xx) getTrakt devuelve None;
		# antes eso dejaba 'items' sin definir y fallaba tambien la cache.
		items = []
		try:
			response = trakt.getTrakt(url)
			if response is not None: items = response.json() or []
		except Exception:
			from resources.lib.modules import log_utils
			log_utils.error()
		try:
			q = dict(parse_qsl(urlsplit(url).query))
			if int(q['limit']) != len(items): raise Exception()
			q.update({'page': str(int(q['page']) + 1)})
			q = (urlencode(q)).replace('%2C', ',')
			next = url.replace('?' + urlparse(url).query, '') + '?' + q
		except Exception: next = ''

		for item in items:
			try:
				if item.get('type', '') == 'officiallist': continue #seems bugy so until Justin replies hold off
				list_item = item.get('list', {})
				list_name = list_item.get('name', '')
				list_id = list_item.get('ids', {}).get('trakt', '')
				list_owner = list_item.get('user', {}).get('username', '')
				list_owner_slug = list_item.get('user', {}).get('ids', {}).get('slug', '')
				if any(list_item.get('privacy', '') == value for value in ('private', 'friends')): continue
				list_url = self.traktlist_link % (list_owner_slug, list_id)
				list_content = traktsync.fetch_public_list(list_id)
				if not list_content: pass
				else: 
					if list_content.get('content_type', '') == 'shows': continue
				label = '%s - [COLOR %s]%s[/COLOR]' % (list_name, self.highlight_color, list_owner)
				self.list.append({'name': label, 'list_type': 'traktPulicList', 'url': list_url, 'list_owner': list_owner, 'list_name': list_name, 'list_id': list_id, 'context': list_url, 'next': next, 'image': 'trakt.png', 'icon': 'trakt.png', 'action': 'movies'})
			except Exception:
				from resources.lib.modules import log_utils
				log_utils.error()
		return self.list

	def awards_list(self, url):
		"""v2.0.04: Oscar a la mejor pelicula (ganadoras o nominadas) desde
		Wikidata, por paginas del tamano de las demas listas. Solo lleva el id
		de TMDb: titulo, ano y arte los pone TMDb en worker()."""
		from resources.lib.modules import awards
		q = dict(parse_qsl(urlsplit(url).query))
		kind = 'nominees' if q.get('award') == 'nominees' else 'winners'
		page_no = q.get('page', '1')
		full = cache.get(awards.best_picture, 168, kind)
		chunk, more = awards.page(full, page_no, self.page_limit)
		next = ''
		if more: next = re.sub(r'([?&])page=\d+', lambda m: '%spage=%d' % (m.group(1), int(page_no) + 1), url)
		return [{'tmdb': tmdb, 'imdb': '', 'tvdb': '', 'next': next} for tmdb, year in chunk]

	def tmdb_person_list(self, url, pages=1):
		"""v2.0.04: personas de TMDb (busqueda o populares). Cada una abre su
		filmografia (tmdb_person_link)."""
		return [{'name': name, 'url': self.tmdb_person_link % ('%s', pid), 'image': photo or 'people.png'}
			for pid, name, photo in tmdb_indexer().people(url, pages)]

	def worker(self):
		try:
			if not self.list: return
			self.meta = []
			total = len(self.list)
			_start = _now()
			for i in range(0, total): self.list[i].update({'metacache': False})
			self.list = metacache.fetch(self.list, self.lang, self.user, mediatype='movie')
			_cached = sum(1 for i in self.list if i.get('metacache'))
			_stopped = False
			for r in range(0, total, 40):
				if _aborted():
					_stopped = True
					break
				threads = []
				append = threads.append
				for i in range(r, r + 40):
					if i < total: append(Thread(target=self.super_info, args=(i,)))
				[i.start() for i in threads]
				[i.join() for i in threads]
			if self.meta: metacache.insert(self.meta)
			self.list = [i for i in self.list if i.get('tmdb') or i.get('imdb')]
			from resources.lib.modules import log_utils
			log_utils.log('worker: %d items, %d from metacache, %.1fs%s' % (total, _cached, _now() - _start,
				' (stopped: Kodi asked the list to close)' if _stopped or _aborted() else ''), __name__, log_utils.LOGDEBUG)
		except Exception:
			from resources.lib.modules import log_utils
			log_utils.error()

	def super_info(self, i):
		# Envoltura del precache (v1.0.81). Sin semaforo ni deadline se comporta
		# exactamente igual que antes.
		if self.precache_deadline and _now() > self.precache_deadline: return
		if _aborted(): return
		if self.precache_sem is None: return self._super_info(i)
		self.precache_sem.acquire()
		try: return self._super_info(i)
		finally: self.precache_sem.release()

	def _super_info(self, i):
		try:
			if self.list[i]['metacache']: return
			imdb, tmdb = self.list[i].get('imdb', ''), self.list[i].get('tmdb', '')
#### -- Missing id's lookup -- ####
			if not tmdb and imdb:
				try:
					# result = cache.get(tmdb_indexer.Movies().IdLookup, 96, imdb)
					result = cache.get(tmdb_indexer().IdLookup, 96, imdb)
					tmdb = str(result.get('id', '')) if result.get('id') else ''
				except Exception: tmdb = ''
			if not tmdb and imdb:
				trakt_ids = trakt.IdLookup('imdb', imdb, 'movie') # "trakt.IDLookup()" caches item
				if trakt_ids: tmdb = str(trakt_ids.get('tmdb', '')) if trakt_ids.get('tmdb') else ''
			if not tmdb and not imdb:
				try:
					results = trakt.SearchMovie(title=quote_plus(self.list[i]['title']), year=self.list[i]['year'], fields='title', full=False) # "trakt.SearchMovie()" caches item
					if results[0]['movie']['title'] != self.list[i]['title'] or results[0]['movie']['year'] != self.list[i]['year']: return
					ids = results[0].get('movie', {}).get('ids', {})
					if not tmdb: tmdb = str(ids.get('tmdb', '')) if ids.get('tmdb') else ''
					if not imdb: imdb = str(ids.get('imdb', '')) if ids.get('imdb') else ''
				except Exception: pass
#################################
			if not tmdb: return
			# movie_meta = tmdb_indexer.Movies().get_movie_meta(tmdb)
			if _aborted(): return # Kodi closed the list: skip the TMDb request
			movie_meta = tmdb_indexer().get_movie_meta(tmdb)
			if not movie_meta or '404:NOT FOUND' in movie_meta: return # trakt search turns up alot of junk with wrong tmdb_id's causing 404's
			values = {}
			values.update(movie_meta)
			if 'rating' in self.list[i] and self.list[i]['rating']: values['rating'] = self.list[i]['rating'] # prefer imdb,trakt rating and votes if set
			if 'votes' in self.list[i] and self.list[i]['votes']: values['votes'] = self.list[i]['votes']
			if 'year' in self.list[i] and self.list[i]['year'] != values.get('year'): values['year'] = self.list[i]['year']
			if not imdb: imdb = values.get('imdb', '')
			if not values.get('imdb'): values['imdb'] = imdb
			if not values.get('tmdb'): values['tmdb'] = tmdb
			if self.lang != 'en':
				try:
					if 'available_translations' in self.list[i] and self.lang not in self.list[i]['available_translations']: raise Exception()
					trans_item = trakt.getMovieTranslation(imdb, self.lang, full=True)
					if trans_item:
						if trans_item.get('title') and not self.prefer_en_titles: values['title'] = trans_item.get('title') # con títulos EN activos solo se traduce la sinopsis
						if trans_item.get('overview'): values['plot'] =trans_item.get('overview')
				except Exception:
					from resources.lib.modules import log_utils
					log_utils.error()
			if self.enable_fanarttv:
				extended_art = fanarttv_cache.get(FanartTv().get_movie_art, 336, imdb, tmdb)
				if extended_art: values.update(extended_art)
			values = dict((k, v) for k, v in iter(values.items()) if v is not None and v != '') # remove empty keys so .update() doesn't over-write good meta with empty values.
			self.list[i].update(values)
			meta = {'imdb': imdb, 'tmdb': tmdb, 'tvdb': '', 'lang': self.lang, 'user': self.user, 'item': values}
			self.meta.append(meta)
		except Exception:
			from resources.lib.modules import log_utils
			log_utils.error()

	def movieDirectory(self, items, unfinished=False, next=True):
		from sys import argv # some functions like ActivateWindow() throw invalid handle less this is imported here.
		from resources.lib.modules import navstate; navstate.note_list() # v2.0.09: Exit list
		if not items: # with reuselanguageinvoker on an empty directory must be loaded, do not use sys.exit()
			control.hide()
			if control.in_videos_window(): control.notification(title=32001, message=33049) # v2.0.28: no toast on a home widget
		from resources.lib.modules.player import Bookmarks
		sysaddon, syshandle = 'plugin://plugin.video.luc_kodi/', int(argv[1])
		play_mode = getSetting('play.mode')
		rescrape_useDefault = getSetting('rescrape.default') == 'true'
		rescrape_method = getSetting('rescrape.default2')
		is_widget = 'plugin' not in control.infoLabel('Container.PluginName')
		settingFanart = getSetting('fanart') == 'true'
		addonPoster, addonFanart, addonBanner = control.missingPoster(), control.missingFanart(), control.addonBanner() # v2.0.04: aviso si falta el arte
		indicators = getMovieIndicators() # refresh not needed now due to service sync
		if play_mode == '1': playbackMenu = getLS(32063)
		else: playbackMenu = getLS(32064)
		if trakt.getTraktIndicatorsInfo(): watchedMenu, unwatchedMenu = getLS(32068), getLS(32069)
		else: watchedMenu, unwatchedMenu = getLS(32066), getLS(32067)
		playlistManagerMenu, queueMenu = getLS(35522), getLS(32065)
		traktManagerMenu, addToLibrary = getLS(32070), getLS(32551)
		nextMenu, clearSourcesMenu = getLS(32053), getLS(32611)
		rescrapeMenu, findSimilarMenu = getLS(32185), getLS(32184)
		from resources.lib.modules import skin_props # v2.0.28: lo que el skin puede leer de cada item
		page_ratings = skin_props.PageRatings(items, 'movie')
		from resources.lib.modules import home_badges, skin_ratings # v2.0.28
		page_badges = home_badges.PageBadges(items, 'movie', on=getattr(self, 'home_row', False))
		fen_prefill = skin_ratings.FentasticPrefill()
		for i in items:
			try:
				imdb, tmdb, title, year = i.get('imdb', ''), i.get('tmdb', ''), i['title'], i.get('year', '')
				trailer, runtime = i.get('trailer'), i.get('duration')
				label = '%s (%s)' % (title, year)
				try: labelProgress = label + '[COLOR %s]  [%s][/COLOR]' % (self.highlight_color, str(round(float(i['progress']), 1)) + '%')
				except Exception: labelProgress = label
				try:
					if int(re.sub(r'[^0-9]', '', str(i['premiered']))) > int(re.sub(r'[^0-9]', '', str(self.today_date))): 
						labelProgress = '[COLOR %s][I]%s[/I][/COLOR]' % (self.unairedcolor, labelProgress)
				except Exception: pass
				if i.get('traktHistory') is True: # uses Trakt lastplayed
					try:
						air_datetime = tools.convert_time(stringTime=i.get('lastplayed', ''), zoneFrom='utc', zoneTo='local', formatInput='%Y-%m-%dT%H:%M:%S.000Z', formatOutput='%b %d %Y %I:%M %p', remove_zeroes=True)
						labelProgress = labelProgress + '[COLOR %s]  [%s][/COLOR]' % (self.highlight_color, air_datetime)
					except Exception: pass
				if i.get('mdb_calendar_date'): # MDBList calendar: release date + type
					try:
						from datetime import datetime as _dt
						rel = _dt.strptime(i['mdb_calendar_date'], '%Y-%m-%d').strftime('%b %d %Y')
						kind = 'Digital' if i.get('mdb_calendar_kind') == 'digital' else 'Cinema'
						labelProgress = labelProgress + '[COLOR %s]  [%s · %s][/COLOR]' % (self.highlight_color, rel, kind)
					except Exception: pass
				sysname, systitle = quote_plus(label), quote_plus(title)
				meta = dict((k, v) for k, v in iter(i.items()) if v is not None and v != '')
				meta.update({'code': imdb, 'imdbnumber': imdb, 'mediatype': 'movie', 'tag': [imdb, tmdb]})
				try: meta.update({'genre': cleangenre.lang(meta['genre'], self.lang)})
				except Exception: pass

				if self.prefer_tmdbArt:
					poster = meta.get('poster3') or meta.get('poster') or meta.get('poster2') or addonPoster
					clearlogo = logo_url(meta.get('tmdblogo')) or meta.get('clearlogo', '')
				else:
					poster = meta.get('poster2') or meta.get('poster3') or meta.get('poster') or addonPoster
					clearlogo = meta.get('clearlogo') or logo_url(meta.get('tmdblogo', ''))
				poster = poster_rotator.rotate(meta, poster) # rotación de pósters TMDb (si está activada)
				fanart = ''
				if settingFanart:
					if self.prefer_tmdbArt: fanart = meta.get('fanart3') or meta.get('fanart') or meta.get('fanart2') or addonFanart
					else: fanart = meta.get('fanart2') or meta.get('fanart3') or meta.get('fanart') or addonFanart
				landscape = meta.get('landscape') or fanart
				thumb = meta.get('thumb') or poster or landscape
				icon = meta.get('icon') or poster
				banner = meta.get('banner3') or meta.get('banner2') or meta.get('banner') or addonBanner
				art = {}
				art.update({'icon': icon, 'thumb': thumb, 'banner': banner, 'poster': poster, 'fanart': fanart, 'landscape': landscape, 'clearlogo': clearlogo,
								'clearart': meta.get('clearart', ''), 'discart': meta.get('discart', ''), 'keyart': meta.get('keyart', '')})
				art = badge_posters.apply(art, meta, 'movie') # v2.0.35: posters with badges (solo el arte; meta['poster'] queda limpio)
				for k in ('metacache', 'meta_light', 'poster2', 'poster3', 'posters_all', 'posters_clean', 'fanart2', 'fanart3', 'banner2', 'banner3', 'trailer'): meta.pop(k, None)
				meta.update({'poster': poster, 'fanart': fanart, 'banner': banner})
				sysmeta, sysart = quote_plus(jsdumps(meta)), quote_plus(jsdumps(art))
				url = '%s?action=play_Item&title=%s&year=%s&imdb=%s&tmdb=%s&meta=%s' % (sysaddon, systitle, year, imdb, tmdb, sysmeta)
				sysurl = quote_plus(url)
####-Context Menu and Overlays-####
				cm = []
				try:
					watched = getMovieOverlay(indicators, imdb) == '5'
					if self.traktCredentials:
						cm.append((traktManagerMenu, 'RunPlugin(%s?action=tools_traktManager&name=%s&imdb=%s&watched=%s&unfinished=%s)' % (sysaddon, sysname, imdb, watched, unfinished)))
					from resources.lib.modules.mdblist import getMDBListCredentialsInfo as _mdb_ok
					if _mdb_ok() and imdb:
						cm.append((getLS(40220), 'RunPlugin(%s?action=mdblist_Manager&name=%s&imdb=%s&media_type=movie)' % (sysaddon, sysname, imdb)))
					try: # v1.0.91: SIMKL (valoraciones y listas)
						from resources.lib.modules.simkl import getSimklCredentialsInfo as _simkl_ok
						if _simkl_ok() and imdb:
							cm.append((getLS(400843), 'RunPlugin(%s?action=simklManager&name=%s&imdb=%s&media_type=movie)' % (sysaddon, sysname, imdb)))
					except Exception: pass
					try: # v1.0.99: WeTrakr Manager
						if getattr(self, '_wt_ok', None) is None:
							from resources.lib.modules.wetrakr import getWeTrakrCredentialsInfo as _wt_ok
							self._wt_ok = _wt_ok()
						if self._wt_ok and (imdb or tmdb):
							cm.append((getLS(47050), 'RunPlugin(%s?action=wetrakr_Manager&name=%s&imdb=%s&tmdb=%s&media_type=movie&unfinished=%s)' % (sysaddon, sysname, imdb, tmdb, unfinished)))
					except Exception: pass
					try: # v2.0.09: PunchPlay Manager
						if getattr(self, '_pp_ok', None) is None:
							from resources.lib.modules.punchplay import getPunchPlayCredentialsInfo as _pp_ok
							self._pp_ok = _pp_ok()
						if self._pp_ok and (imdb or tmdb):
							cm.append((getLS(46060), 'RunPlugin(%s?action=punchplay_Manager&name=%s&imdb=%s&tmdb=%s&media_type=movie)' % (sysaddon, sysname, imdb, tmdb)))
					except Exception: pass
					if watched:
						cm.append((unwatchedMenu, 'RunPlugin(%s?action=playcount_Movie&name=%s&imdb=%s&query=4)' % (sysaddon, sysname, imdb)))
						meta.update({'playcount': 1, 'overlay': 5})
						# meta.update({'lastplayed': trakt.watchedMoviesTime(imdb)}) # no skin support
					else:
						cm.append((watchedMenu, 'RunPlugin(%s?action=playcount_Movie&name=%s&imdb=%s&query=5)' % (sysaddon, sysname, imdb)))
						meta.update({'playcount': 0, 'overlay': 4})
				except Exception: pass
				cm.append((playlistManagerMenu, 'RunPlugin(%s?action=playlist_Manager&name=%s&url=%s&meta=%s&art=%s)' % (sysaddon, sysname, sysurl, sysmeta, sysart)))
				# v1.0.44: tráiler keyless — usa el id de TMDb ya presente en meta['trailer'] si existe
				cm.append(('Play Trailer', 'PlayMedia(%s?action=play_Trailer&type=movie&name=%s&year=%s&imdb=%s&tmdb=%s&url=%s)' % (sysaddon, sysname, year, imdb, tmdb, quote_plus(trailer) if trailer else '')))
				cm.append((queueMenu, 'RunPlugin(%s?action=playlist_QueueItem&name=%s)' % (sysaddon, sysname)))
				cm.append((addToLibrary, 'RunPlugin(%s?action=library_movieToLibrary&name=%s&title=%s&year=%s&imdb=%s&tmdb=%s)' % (sysaddon, sysname, systitle, year, imdb, tmdb)))
				if premiere_offer(i.get('premiered')): # v2.0.13: Premiere Movies
					cm.append((getLS(32819), 'RunPlugin(%s?action=library_premiereMovieAdd&title=%s&year=%s&imdb=%s&tmdb=%s)' % (sysaddon, systitle, year, imdb, tmdb)))
				cm.append((findSimilarMenu, 'Container.Update(%s?action=movies&url=%s)' % (sysaddon, quote_plus('https://api.trakt.tv/movies/%s/related?limit=20&page=1,return' % imdb))))
				if i.get('belongs_to_collection', ''):
					cm.append(('Browse Collection', 'Container.Update(%s?action=collections&url=%s)' % (
							sysaddon, quote_plus('https://api.themoviedb.org/3/collection/%s?api_key=%s&page=1,return' % (i['belongs_to_collection']['id'], self.tmdb_key)))))
				cm.append((playbackMenu, 'RunPlugin(%s?action=alterSources&url=%s&meta=%s)' % (sysaddon, sysurl, sysmeta)))
				if not rescrape_useDefault:
					cm.append(('Rescrape Options...', 'PlayMedia(%s?action=rescrapeMenu&title=%s&year=%s&imdb=%s&tmdb=%s&meta=%s)' % (sysaddon, systitle, year, imdb, tmdb, sysmeta)))
				else:
					if rescrape_method == '0':
						cm.append((rescrapeMenu, 'PlayMedia(%s?action=play_Item&title=%s&year=%s&imdb=%s&tmdb=%s&meta=%s&rescrape=true&select=1)' % (sysaddon, systitle, year, imdb, tmdb, sysmeta)))
					if rescrape_method == '1':
						cm.append((rescrapeMenu, 'PlayMedia(%s?action=play_Item&title=%s&year=%s&imdb=%s&tmdb=%s&meta=%s&rescrape=true&select=0)' % (sysaddon, systitle, year, imdb, tmdb, sysmeta)))
					if rescrape_method == '2':
						cm.append((rescrapeMenu, 'PlayMedia(%s?action=play_Item&title=%s&year=%s&imdb=%s&tmdb=%s&meta=%s&rescrape=true&all_providers=true&select=1)' % (sysaddon, systitle, year, imdb, tmdb, sysmeta)))
					if rescrape_method == '3':
						cm.append((rescrapeMenu, 'PlayMedia(%s?action=play_Item&title=%s&year=%s&imdb=%s&tmdb=%s&meta=%s&rescrape=true&all_providers=true&select=0)' % (sysaddon, systitle, year, imdb, tmdb, sysmeta)))
				cm.append((clearSourcesMenu, 'RunPlugin(%s?action=cache_clearSources)' % sysaddon))
				cm.append(('[COLOR red]luc_kodi Settings[/COLOR]', 'RunPlugin(%s?action=tools_openSettings)' % sysaddon))
				# ── Feedback explícito (solo visible en listas de recomendaciones) ──
				fb_tmdb = i.get('_fb_tmdb', '')
				if fb_tmdb:
					fb_mt     = quote_plus(i.get('_fb_media_type', 'movie'))
					fb_genres = quote_plus(i.get('_fb_genres', ''))
					fb_title  = quote_plus(i.get('title', ''))
					cm.insert(0, ('[COLOR limegreen][B]More like this[/B][/COLOR]',  'RunPlugin(%s?action=reco_feedback&signal=1&tmdb=%s&title=%s&media_type=%s&genres=%s)'  % (sysaddon, fb_tmdb, fb_title, fb_mt, fb_genres)))
					cm.insert(1, ('[COLOR red][B]Not interested[/B][/COLOR]', 'RunPlugin(%s?action=reco_feedback&signal=-1&tmdb=%s&title=%s&media_type=%s&genres=%s)' % (sysaddon, fb_tmdb, fb_title, fb_mt, fb_genres)))
####################################
				if trailer: meta.update({'trailer': trailer}) # removed temp so it's not passed to CM items, only infoLabels for skin
				else: meta.update({'trailer': '%s?action=play_Trailer&type=%s&name=%s&year=%s&imdb=%s' % (sysaddon, 'movie', sysname, year, imdb)})
				item = control.item(label=labelProgress, offscreen=True)
				item.setArt({k: v for k, v in art.items() if v is not None})  # Kodi 22 avisa por cada None
				item.setProperty('IsPlayable', 'true')
				if is_widget: item.setProperty('isluc_kodi_widget', 'true')
				if self.unairedcolor not in labelProgress:
					resumetime = Bookmarks().get(name=label, imdb=imdb, tmdb=tmdb, year=str(year), runtime=runtime, ck=True)
					# "Mi Progreso" (SIMKL playback): respaldo si aún no hay bookmark
					# local. runtime aquí está en segundos.
					try:
						if (not resumetime or float(resumetime) == 0) and i.get('progress') and runtime:
							resumetime = round(float(runtime) * float(i['progress']) / 100.0, 2)
					except Exception: pass
					# item.setProperty('TotalTime', str(meta['duration'])) # Adding this property causes the Kodi bookmark CM items to be added
					item.setProperty('ResumeTime', str(resumetime)) if KODI_VERSION < 20 else item.getVideoInfoTag().setResumePoint(float(resumetime))
					try:
						watched_percent = round(float(resumetime) / float(runtime) * 100, 1) # resumetime and runtime are both in seconds
						item.setProperty('PercentPlayed', str(watched_percent))
					except Exception: pass
				_r = page_ratings.get(i)
				skin_props.decorate(item, meta, _r, premiered=i.get('premiered'))
				fen_prefill.add(imdb, _r)
				page_badges.apply(meta, i)
				control.infoTagger(item, meta)
				attach_cm(item, cm)
				control.addItem(handle=syshandle, url=url, listitem=item, isFolder=False)
			except Exception:
				from resources.lib.modules import log_utils
				log_utils.error()
		fen_prefill.flush() # v2.0.28: cache del ayudante de FENtastic, de una vez
		if next:
			try:
				if not items: raise Exception()
				url = items[0]['next']
				if not url: raise Exception()
				url_params = dict(parse_qsl(urlsplit(url).query))
				page = '  [I](%s)[/I]' % url_params.get('page')
				if 'None' in page: page = page.split('  [I]')[0]
				nextMenu = '[COLOR skyblue]' + nextMenu + page + '[/COLOR]'
				u = urlparse(url).netloc.lower()
				if u not in self.tmdb_link: url = '%s?action=moviePage&url=%s' % (sysaddon, quote_plus(url))
				elif u in self.tmdb_link: url = '%s?action=tmdbmoviePage&url=%s' % (sysaddon, quote_plus(url))
				item = control.item(label=nextMenu, offscreen=True)
				icon = control.addonNext()
				item.setArt({'icon': icon, 'thumb': icon, 'poster': icon, 'banner': icon})
				item.setProperty ('SpecialSort', 'bottom')
				control.addItem(handle=syshandle, url=url, listitem=item, isFolder=True)
			except Exception:
				from resources.lib.modules import log_utils
				log_utils.error()
		badge_posters.flush() # v2.0.35: el servicio pide ya al servidor todos los posters de esta pagina
		control.content(syshandle, 'movies')
		control.directory(syshandle, cacheToDisc=True)
		if control.in_videos_window(): control.sleep(200)
		views.setView('movies', {'skin.estuary': 500, 'skin.confluence': 500})

	def addDirectory(self, items, queue=False):
		from sys import argv # some functions like ActivateWindow() throw invalid handle less this is imported here.
		from resources.lib.modules import navstate; navstate.note_menu() # v2.0.09: Exit list
		if not items: # with reuselanguageinvoker on an empty directory must be loaded, do not use sys.exit()
			content = '' ; control.hide()
			if control.in_videos_window(): control.notification(title=32001, message=33049) # v2.0.28: no toast on a home widget
		sysaddon, syshandle = 'plugin://plugin.video.luc_kodi/', int(argv[1])
		addonThumb = control.addonThumb()
		artPath = control.artPath()
		queueMenu, playRandom, addToLibrary = getLS(32065), getLS(32535), getLS(32551)
		likeMenu, unlikeMenu = getLS(32186), getLS(32187)
		for i in items:
			try:
				content = i.get('content', '')
				name = i['name']
				if i['image'].startswith('http'): poster = i['image']
				elif artPath: poster = control.joinPath(artPath, i['image'])
				else: poster = addonThumb
				if content == 'genres':
					icon = control.joinPath(control.genreIconPath(), i['icon']) or 'DefaultFolder.png'
					poster = control.joinPath(control.genrePosterPath(), i['image']) or addonThumb
				else:
					icon = i['icon']
					if icon.startswith('http'): pass
					elif not icon.startswith('Default'): icon = control.joinPath(artPath, icon)
				url = '%s?action=%s' % (sysaddon, i['action'])
				try: url += '&url=%s' % quote_plus(i['url'])
				except Exception: pass
				cm = []
				if (i.get('list_type', '') == 'traktPulicList') and self.traktCredentials:
					liked = traktsync.fetch_liked_list(i['list_id'])
					if not liked:
						cm.append((likeMenu, 'RunPlugin(%s?action=tools_likeList&list_owner=%s&list_name=%s&list_id=%s)' % (sysaddon, quote_plus(i['list_owner']), quote_plus(i['list_name']), i['list_id'])))
					else:
						name = '[COLOR %s][Liked][/COLOR] %s' % (self.highlight_color, name)
						cm.append((unlikeMenu, 'RunPlugin(%s?action=tools_unlikeList&list_owner=%s&list_name=%s&list_id=%s)' % (sysaddon, quote_plus(i['list_owner']), quote_plus(i['list_name']), i['list_id'])))
				cm.append((playRandom, 'RunPlugin(%s?action=play_Random&rtype=movie&url=%s)' % (sysaddon, quote_plus(i['url']))))
				if queue: cm.append((queueMenu, 'RunPlugin(%s?action=playlist_QueueItem)' % sysaddon))
				try:
					if getSetting('library.service.update') == 'true':
						cm.append((addToLibrary, 'RunPlugin(%s?action=library_moviesToLibrary&url=%s&name=%s)' % (sysaddon, quote_plus(i['context']), name)))
				except Exception: pass
				cm.append(('[COLOR red]luc_kodi Settings[/COLOR]', 'RunPlugin(%s?action=tools_openSettings)' % sysaddon))
				item = control.item(label=name, offscreen=True)
				item.setArt({'icon': icon, 'poster': poster, 'thumb': poster, 'fanart': control.addonFanart(), 'banner': poster})
				item.setInfo(type='video', infoLabels={'plot': name}) if KODI_VERSION < 20 else item.getVideoInfoTag().setPlot(name)
				attach_cm(item, cm)
				control.addItem(handle=syshandle, url=url, listitem=item, isFolder=True)
			except Exception:
				from resources.lib.modules import log_utils
				log_utils.error()
		try:
			if not items: raise Exception()
			url = items[0].get('next', '')
			if url == '': raise Exception()
			url_params = dict(parse_qsl(urlsplit(url).query))
			nextMenu = getLS(32053)
			page = '  [I](%s)[/I]' % url_params.get('page')
			nextMenu = '[COLOR skyblue]' + nextMenu + page + '[/COLOR]'
			icon = control.addonNext()
			url = '%s?action=movies_PublicLists&url=%s' % (sysaddon, quote_plus(url))
			item = control.item(label=nextMenu, offscreen=True)
			item.setArt({'icon': icon, 'thumb': icon, 'poster': icon, 'banner': icon})
			item.setProperty ('SpecialSort', 'bottom')
			control.addItem(handle=syshandle, url=url, listitem=item, isFolder=True)
		except Exception:
			from resources.lib.modules import log_utils
			log_utils.error()

		skin = control.skin
		if skin == 'skin.arctic.horizon': pass
		elif skin in ('skin.estuary', 'skin.aeon.nox.silvo'): content = ''
		elif skin == 'skin.auramod':
			if content not in ('actors', 'genres'): content = 'addons'
			else: content = ''
		control.content(syshandle, content) # some skins use their own thumb for things like "genres" when content type is set here
		control.directory(syshandle, cacheToDisc=True)
