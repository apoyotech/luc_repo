# -*- coding: utf-8 -*-
"""
	luc_kodi Add-on
"""

from json import dumps as jsdumps, loads as jsloads
import os.path
import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs
import xml.etree.ElementTree as ET
from resources.lib.modules.kodi_objects import Lazy, LazyProgress

# v2.0.14: the Kodi objects below are made when first used and released at the
# end of every run (modules/kodi_objects.py). Made at import and kept for ever,
# Kodi found them alive when it stopped the interpreter and wrote "has left
# several classes in memory" after every playback. They are used exactly as
# before; a Kodi call that needs the object itself takes ._real().
addon = xbmcaddon.Addon
AddonID = xbmcaddon.Addon().getAddonInfo('id')
_addon = Lazy(xbmcaddon.Addon, 'Addon')

def addonInfo(key):
	return _addon.getAddonInfo(key)

def getLangString(language_id):
	return _addon.getLocalizedString(language_id)

dialog = Lazy(xbmcgui.Dialog, 'Dialog')
numeric_input = xbmcgui.INPUT_NUMERIC
getCurrentDialogId = xbmcgui.getCurrentWindowDialogId()
getCurrentWindowId = xbmcgui.getCurrentWindowId()
homeWindow = Lazy(lambda: xbmcgui.Window(10000), 'Window(10000)')
playerWindow = Lazy(lambda: xbmcgui.Window(12005), 'Window(12005)')
item = xbmcgui.ListItem
progressDialog = LazyProgress(xbmcgui.DialogProgress, 'DialogProgress')
progressDialogBG = LazyProgress(xbmcgui.DialogProgressBG, 'DialogProgressBG')

addItem = xbmcplugin.addDirectoryItem
content = xbmcplugin.setContent
directory = xbmcplugin.endOfDirectory
property = xbmcplugin.setProperty
resolve_url = xbmcplugin.setResolvedUrl

def resolve(handle, succeeded, listitem, meta=None):
	"""Wrapper around xbmcplugin.setResolvedUrl.

	meta is accepted for backwards compatibility but is not used.
	"""
	return resolve_url(handle, succeeded, listitem)

sortMethod = xbmcplugin.addSortMethod

condVisibility = xbmc.getCondVisibility
execute = xbmc.executebuiltin
infoLabel = xbmc.getInfoLabel
jsonrpc = xbmc.executeJSONRPC
keyboard = xbmc.Keyboard
log = xbmc.log
monitor_class = xbmc.Monitor
monitor = Lazy(xbmc.Monitor, 'Monitor')
player = Lazy(xbmc.Player, 'Player')
player2 = xbmc.Player
playlist = Lazy(lambda: xbmc.PlayList(xbmc.PLAYLIST_VIDEO), 'PlayList')
skin = xbmc.getSkinDir()

deleteDir = xbmcvfs.rmdir
deleteFile = xbmcvfs.delete
existsPath = xbmcvfs.exists
legalFilename = xbmcvfs.makeLegalFilename
listDir = xbmcvfs.listdir
makeFile = xbmcvfs.mkdir
makeDirs = xbmcvfs.mkdirs
openFile = xbmcvfs.File
transPath = xbmcvfs.translatePath

joinPath = os.path.join
isfilePath = os.path.isfile
absPath = os.path.abspath

SETTINGS_PATH = transPath(joinPath(addonInfo('path'), 'resources', 'settings.xml'))
try: dataPath = transPath(addonInfo('profile')).decode('utf-8')
except: dataPath = transPath(addonInfo('profile'))
settingsFile = joinPath(dataPath, 'settings.xml')
viewsFile = joinPath(dataPath, 'views.db')
bookmarksFile = joinPath(dataPath, 'bookmarks.db')
providercacheFile = joinPath(dataPath, 'providers.db')
metacacheFile = joinPath(dataPath, 'metadata.db')
searchFile = joinPath(dataPath, 'search.db')
libcacheFile = joinPath(dataPath, 'library.db')
cacheFile = joinPath(dataPath, 'cache.db')
traktSyncFile = joinPath(dataPath, 'traktsync.db')
simklSyncFile = joinPath(dataPath, 'simklsync.db')
fanarttvCacheFile = joinPath(dataPath, 'fanarttv.db')
watchedcacheFile = joinPath(dataPath, 'watched.db')
subsFile         = joinPath(dataPath, 'substitute.db')
subtitlesPath    = joinPath(dataPath, 'subtitles')
trailer = 'plugin://plugin.video.luc_kodi/?action=play_Trailer&url=%s' # v1.0.44: keyless — antes plugin.video.youtube
KODI_VERSION = int(xbmc.getInfoLabel("System.BuildVersion")[:2])

def getKodiVersion(full=False):
	if full: return xbmc.getInfoLabel("System.BuildVersion")
	else: return int(xbmc.getInfoLabel("System.BuildVersion")[:2])

def setting(id, fallback=None):
	# Lee del dict cacheado en la window property. make_settings_dict() lo rellena
	# desde el settings.xml de userdata (incluye TODOS los valores reales del
	# usuario, credenciales incluidas), y el SettingsMonitor (service.py) lo
	# regenera vía onSettingsChanged() cada vez que el usuario cambia un ajuste.
	# Por eso el dict es la fuente de verdad y NO re-consultamos xbmcaddon por
	# cada setting.
	#
	# PERF (v1.0.38): la versión anterior re-consultaba xbmcaddon.Addon().getSetting()
	# para CUALQUIER setting vacío — en Android eso fuerza un parseo del settings.xml
	# en "formato antiguo". Bajo el precache, decenas de hilos leyendo settings
	# vacíos/ausentes (db.maintenance.lastrun, poster.rotation.lastclean,
	# el antiguo marcador de torboxnews, y credenciales que el plugin deja vacías a propósito
	# para usar su fallback hardcoded, p.ej. tmdb.api.key) disparaban ~1000 parseos
	# del XML y añadían ~8s al arranque. Con el dict como única fuente, ese coste
	# desaparece y los getSetting() vacíos devuelven '' al instante (el código que
	# llama ya aplica su propio fallback: `key = getSetting(x) or HARDCODED`).
	try: settings_dict = jsloads(homeWindow.getProperty('luc_kodi_settings'))
	except: settings_dict = make_settings_dict()
	if settings_dict is None: settings_dict = settings_fallback(id)
	if id in settings_dict:
		value = settings_dict.get(id, '')
	else:
		# Setting ausente del settings.xml (p.ej. Kodi no escribió el default en
		# algunas plataformas como iOS, o es un marcador interno aún sin valor).
		# Lo resolvemos UNA vez vía xbmcaddon y lo cacheamos en el dict para no
		# repetir. Solo persistimos la property si hay valor real que cachear:
		# para '' no reescribimos (evita que múltiples hilos se pisen la property
		# en bucle durante el precache).
		try: value = xbmcaddon.Addon().getSetting(id)
		except: value = ''
		if value != '':
			try:
				settings_dict[id] = value
				homeWindow.setProperty('luc_kodi_settings', jsdumps(settings_dict))
			except: pass
	if fallback is None: return value
	if value == '': return fallback
	return value

def settings_fallback(id):
	return {id: xbmcaddon.Addon().getSetting(id)}


def setSetting(id, value):
	# v1.0.74: invalidar el dict cacheado. setting() lee de la window property
	# 'luc_kodi_settings' y NO de xbmcaddon, asi que escribir sin limpiarla
	# dejaba al propio addon leyendo el valor viejo el resto de la sesion. Se
	# veia en dos sitios: el janitor semanal escribia su marca de ultima pasada
	# y seguia leyendo la sembrada vacia, con lo que se creia vencido cada hora;
	# y el aviso de pantalla por debajo del minimo podia salir dos veces. La
	# regla ya existia en el proyecto —simkl.py y badges_config.py limpian a
	# mano tras cada escritura— y aqui simplemente deja de haber que acordarse.
	#
	# v2.0.34: en vez de borrar el dict, se le pone el valor nuevo. Borrado, la
	# siguiente lectura lo rehacia desde el settings.xml de disco, y con los
	# Ajustes abiertos (de ahi salen las asociaciones) Kodi aun no lo ha escrito:
	# el token recien guardado desaparecia en cuanto se guardaba otro ajuste
	# detras, como el usuario. Si no se puede actualizar, se borra como antes.
	xbmcaddon.Addon().setSetting(id, value)
	if not remember_settings({id: value}):
		try: homeWindow.clearProperty('luc_kodi_settings')
		except: pass

def saved_state(id, value):
	# v2.0.34: para el log de las asociaciones. 'yes' si el addon ya lee el valor,
	# 'when Settings close' si Kodi lo tiene en la ventana de Ajustes abierta (lo
	# escribe al cerrarla) y 'NO' si se ha perdido. Llamar ANTES de remember_settings.
	try:
		if setting(id) == value: return 'yes'
		if condVisibility('Window.IsVisible(addonsettings)'): return 'when Settings close'
	except Exception: pass
	return 'NO'

def remember_settings(values):
	# v2.0.34: pone valores recien guardados en el dict cacheado. Con los Ajustes
	# abiertos (las asociaciones se lanzan desde ahi), Kodi deja setSetting en el
	# dialogo y no escribe el settings.xml hasta cerrarlo; el dict rehecho desde
	# disco seguia sin el token y el addon veia la cuenta sin asociar el resto
	# de esa llamada. Al cerrar los Ajustes Kodi guarda y onSettingsChanged
	# rehace el dict con lo mismo, asi que esto solo adelanta lo que ya viene.
	try:
		try: settings_dict = jsloads(homeWindow.getProperty('luc_kodi_settings'))
		except Exception: settings_dict = None
		if not isinstance(settings_dict, dict): settings_dict = make_settings_dict()
		if not isinstance(settings_dict, dict): return False
		settings_dict.update(dict((k, '' if v is None else str(v)) for k, v in values.items()))
		homeWindow.setProperty('luc_kodi_settings', jsdumps(settings_dict))
		return True
	except Exception: return False

# Marcadores internos (no visibles, sin valor por defecto útil) que distintos
# servicios consultan en bucle. Sembrarlos vacíos en el dict evita el coste de
# xbmcaddon.getSetting() repetido. Ampliar esta lista si se añaden más marcadores.
_INTERNAL_EMPTY_KEYS = (
	'poster.rotation.lastclean',
	'db.maintenance.lastrun',
	'maint.pending',
	'maint.migrated',
)

def make_settings_dict(): # service runs upon a setting change
	try:
		root = ET.parse(settingsFile).getroot()
		settings_dict = {}
		for item in root:
			dict_item = {}
			setting_id = item.get('id')
			setting_value = item.text
			if setting_value is None: setting_value = ''
			dict_item = {setting_id: setting_value}
			settings_dict.update(dict_item)
		# PERF (v1.0.38): siembra claves internas que el código lee pero que Kodi
		# puede no haber escrito aún al settings.xml de userdata (marcadores de
		# último-run, migraciones, etc.). Sin esto caen en la rama 'else' de
		# setting() y cada lectura fuerza un xbmcaddon.getSetting() lento (parseo
		# del XML en formato antiguo). Sembradas como '' entran al dict y se
		# resuelven al instante. Si más tarde Kodi/el usuario les da valor real,
		# onSettingsChanged regenera el dict y el valor correcto prevalece.
		for _k in _INTERNAL_EMPTY_KEYS:
			if _k not in settings_dict: settings_dict[_k] = ''
		homeWindow.setProperty('luc_kodi_settings', jsdumps(settings_dict))
		refresh_playAction()
		refresh_libPath()
		return settings_dict
	except: return None

def openSettings(query=None, id=None):
	"""query 'c.f': abre los ajustes en la categoria c (0 = la primera).
	v2.0.13: los botones de categoria son -200 + c desde Kodi 21 (Omega) y -100 + c
	hasta Kodi 20; el -100 fijo de antes no existe en 21+ y Kodi apuntaba un error
	('Control -100 ... can't') en cada apertura. Solo se enfoca la categoria: el
	numero de un ajuste dentro de ella cambia con los separadores y los ocultos y
	enfocar uno que no existe es otro error; la f se ignora."""
	id = id or addonInfo('id')
	try:
		hide()
		if id == addonInfo('id'):
			# v2.0.38: always luc_kodi's own Settings window; Kodi's dialog for this
			# add-on only holds the button that opens it, so nothing to focus there
			from resources.lib.modules import settings_ui
			try: c = int(str(query or '0').split('.')[0])
			except Exception: c = 0
			if not settings_ui.open_window(c): execute('Addon.OpenSettings(%s)' % id)
			return
		execute('Addon.OpenSettings(%s)' % id)
		if not query: return
		c = int(str(query).split('.')[0])
		if c <= 0: return  # se abre ya en la primera
		for _ in range(30):  # hasta 3 s a que el dialogo de ajustes este abierto
			if xbmcgui.getCurrentWindowDialogId() == 10140: break
			xbmc.sleep(100)
		execute('SetFocus(%i)' % ((-200 if KODI_VERSION >= 21 else -100) + c))
	except:
		from resources.lib.modules import log_utils
		log_utils.error()

def lang(language_id):
	return str(getLangString(language_id))

def sleep(time):  # Modified `sleep`(in milli secs) that honors a user exit request
	while time > 0 and not monitor.abortRequested():
		xbmc.sleep(min(100, time))
		time = time - 100

def getCurrentViewId():
	win = xbmcgui.Window(xbmcgui.getCurrentWindowId())
	return str(win.getFocusId())

def getluc_kodiVersion():
	return xbmcaddon.Addon('plugin.video.luc_kodi').getAddonInfo('version')

def addonVersion(addon):
	return xbmcaddon.Addon(addon).getAddonInfo('version')

def addonId():
	return addonInfo('id')

def addonName():
	return addonInfo('name')

def addonPath(addon):
	try: addonID = xbmcaddon.Addon(addon)
	except: addonID = None
	if addonID is None: return ''
	else:
		try: return transPath(addonID.getAddonInfo('path').decode('utf-8'))
		except: return transPath(addonID.getAddonInfo('path'))

def artPath():
	theme = appearance()
	return joinPath(xbmcaddon.Addon('plugin.video.luc_kodi').getAddonInfo('path'), 'resources', 'media', theme)

def genreIconPath():
	# v2.0.04: genre_media nunca venia en el addon. Los rotulos de cada genero
	# viven ahora junto al resto del arte (media/<tema>/genres/<genero>.png) y
	# valen de icono y de poster.
	return joinPath(artPath(), 'genres')

def genrePosterPath():
	return genreIconPath()

def genreArt(name):
	"""'Science Fiction' -> 'science-fiction.png', 'Talk-Show' -> 'talk-show.png'."""
	import re
	return re.sub(r'[^a-z0-9]+', '-', (name or '').lower()).strip('-') + '.png'

def flagArt(code):
	"""Bandera del idioma (codigo ISO 639-1 de TMDb), relativa a artPath()."""
	return 'flags/%s.png' % (code or '').strip().lower()

def appearance():
	theme = setting('appearance.1').lower()
	return theme

def addonIcon():
	theme = appearance()
	art = artPath()
	if not (art is None and theme in ('-', '')): return joinPath(art, 'icon.png')
	return addonInfo('icon')

def _themeArt(art, filename, fallback='icon.png'):
	# Un tema puede no traer todos los ficheros (poster.png falta en el tema por
	# defecto): devolver la ruta a ciegas hacia Kodi a ensuciar el log con
	# "GetImageHash - unable to stat url ..." una vez por cada item de la lista.
	path = joinPath(art, filename)
	if existsPath(path): return path
	alt = joinPath(art, fallback)
	return alt if existsPath(alt) else None

def addonThumb():
	theme = appearance()
	art = artPath()
	if not (art is None and theme in ('-', '')):
		if (path := _themeArt(art, 'poster.png')): return path
	if theme == '-': return 'DefaultFolder.png'
	return addonInfo('icon')

def addonPoster():
	theme = appearance()
	art = artPath()
	if not (art is None and theme in ('-', '')):
		if (path := _themeArt(art, 'poster.png')): return path
	return 'DefaultVideo.png'

def addonFanart():
	theme = appearance()
	art = artPath()
	if not (art is None and theme in ('-', '')): return joinPath(art, 'fanart.jpg')
	return addonInfo('fanart')

def missingPoster():
	"""v2.0.04: poster para un contenido que aun no lo tiene. Es el fondo del
	plugin con un aviso discreto abajo a la derecha ("Poster not available yet")
	en vez del icono de luc_kodi, que estirado a 2:3 quedaba deformado."""
	art = artPath()
	if art:
		path = _themeArt(art, 'poster_missing.png', 'poster.png')
		if path: return path
	return addonPoster()

def missingFanart():
	"""v2.0.04: fanart para un contenido que aun no lo tiene ("Fanart not
	available yet"). El fondo general de menus sigue siendo addonFanart()."""
	art = artPath()
	if art:
		path = _themeArt(art, 'fanart_missing.jpg', 'fanart.jpg')
		if path: return path
	return addonFanart()

def addonBanner():
	theme = appearance()
	art = artPath()
	if not (art is None and theme in ('-', '')): return joinPath(art, 'banner.png')
	return 'DefaultVideo.png'

def addonNext():
	theme = appearance()
	art = artPath()
	if not (art is None and theme in ('-', '')): return joinPath(art, 'next.png')
	return 'DefaultVideo.png'

####################################################
# --- Dialogs
####################################################
_NOTIF_GROUP = 'luc_kodi.notif.group.'


def _notif_ticket(group):
	"""v2.0.37: the newest notification of a group; any older one still waiting
	(or on screen) gives way to it."""
	import time as _t
	t = '%.4f' % _t.time()
	homeWindow.setProperty(_NOTIF_GROUP + group, t)
	return t


def notification_drop(group):
	"""v2.0.37: notifications of `group` still waiting or on screen go away.
	Called when the source that plays is found, so the steps that led to it are
	not shown over the video (kodi.log 17-nov-2026)."""
	try: _notif_ticket(group)
	except Exception: pass


def notification(title=None, message=None, icon=None, time=3000, sound=None, group=None):
	"""
	Unified notification for the entire plugin.
	Renders a custom XML window (top-center, phone-style slide-from-top, colored
	text, plugin icon) in a background thread so the caller is never blocked.
	Falls back to the standard Kodi notification if the XML window fails.

	title   -> Line 1 (green  #ff00fa9a) -- defaults to 'luc_kodi'
	message -> Line 2 (golden #fffdb515)
	icon    -> path, or 'INFO'/'WARNING'/'ERROR' sentinel
	time    -> display duration in ms (converted to seconds for the XML window)
	sound   -> kept for callers; the XML window plays no sound
	group   -> v2.0.37: progress steps of one task (e.g. 'usenet.chain'). Only
	           the newest of a group is shown, the one on screen closes when a
	           newer one arrives, and none is shown once a video is playing.
	"""
	# Resolve title / message strings
	if title == 'default' or title is None: title = addonName()
	if isinstance(title, int): heading = lang(title)
	else: heading = str(title)
	if isinstance(message, int): body = lang(message)
	else: body = str(message)

	# Resolve icon -- custom paths are passed through; sentinels fall back to plugin icon
	if not icon or icon == 'default': icon_path = addonIcon()
	elif icon in ('INFO', 'WARNING', 'ERROR'): icon_path = addonIcon()
	else: icon_path = icon

	duration_secs = max(2, int(time) // 1000)

	# v2.0.27. MEASURED (kodi.log 5-nov-2026, Star Trek TNG 3x04, Stargate
	# 3x14): get() of the subtitles runs up to three times at the start of a
	# video (service, player and keep-alive) and each run showed the same
	# notification. The same text within its own display time is shown once.
	try:
		import time as _t
		_key, _now = '%s\n%s' % (heading, body), _t.time()
		_last = homeWindow.getProperty('luc_kodi.notif.last')
		if _last:
			_k, _sep, _when = _last.rpartition('\t')
			if _k == _key and _now - float(_when or 0) < duration_secs + 2:
				return
		homeWindow.setProperty('luc_kodi.notif.last', '%s\t%.2f' % (_key, _now))
	except Exception:
		pass

	still = None
	if group:
		try:
			_ticket = _notif_ticket(group)
			def _still():
				return (homeWindow.getProperty(_NOTIF_GROUP + group) == _ticket
						and not condVisibility('Player.HasVideo'))
			still = _still
		except Exception:
			still = None

	def _show():
		try:
			from resources.lib.windows.display_welcome import DisplayWelcomeXML
			win = DisplayWelcomeXML(
				'display_welcome.xml',
				addonPath('plugin.video.luc_kodi'),
				'Default',
				line1=heading,
				line2=body,
				icon=icon_path,
				duration=duration_secs
			)
			win.show_and_close(duration=duration_secs, still=still)
			del win
		except Exception:
			from resources.lib.modules import log_utils
			log_utils.error()

	import threading
	threading.Thread(target=_show, daemon=True).start()

def yesnoDialog(line1, line2, line3, heading=None, nolabel='', yeslabel=''):
	heading = heading or addonInfo('name')
	message = '%s[CR]%s[CR]%s' % (line1, line2, line3)
	return dialog.yesno(heading, message, nolabel, yeslabel)

def yesnocustomDialog(line1, line2, line3, heading=None, customlabel='', nolabel='', yeslabel=''):
	heading = heading or addonInfo('name')
	message = '%s[CR]%s[CR]%s' % (line1, line2, line3)
	return dialog.yesnocustom(heading, message, customlabel, nolabel, yeslabel)

def selectDialog(list, heading=None):
	heading = heading or addonInfo('name')
	return dialog.select(heading, list)

def multiselectDialog(list, heading=None, preselect=None):
	heading = heading or addonInfo('name')
	# Devuelve una lista de índices marcados, o None si se cancela.
	try: return dialog.multiselect(heading, list, preselect=preselect or [])
	except TypeError: return dialog.multiselect(heading, list)

def okDialog(title=None, message=None):
	if title == 'default' or title is None: title = addonName()
	if isinstance(title, int): heading = lang(title)
	else: heading = str(title)
	if isinstance(message, int): body = lang(message)
	else: body = str(message)
	return dialog.ok(heading, body)

def context(items=None, labels=None):
	if items:
		labels = [i[0] for i in items]
		choice = dialog.contextmenu(labels)
		if choice >= 0: return items[choice][1]()
		else: return False
	else: return dialog.contextmenu(labels)

####################################################
# --- Built-in
####################################################
def busy():
	return execute('ActivateWindow(busydialognocancel)')

def hide():
	execute('Dialog.Close(busydialog)')
	execute('Dialog.Close(busydialognocancel)')

def closeAll():
	return execute('Dialog.Close(all,true)')

def closeOk():
	return execute('Dialog.Close(okdialog,true)')

def refresh():
	return execute('Container.Refresh')

def queueItem():
	return execute('Action(Queue)') # seems broken in 19 for show and season level, works fine in 18

def refreshRepos():
	return execute('UpdateAddonRepos')
########################

def cancelPlayback():
	from sys import argv
	try:
		playlist.clear()
	except:
		pass
	try:
		resolve(int(argv[1]), False, item(offscreen=True))
	except:
		pass
	try:
		closeOk()
	except:
		pass
	return

def apiLanguage(ret_name=None):
	langDict = {'Bulgarian': 'bg', 'Chinese': 'zh', 'Croatian': 'hr', 'Czech': 'cs', 'Danish': 'da', 'Dutch': 'nl', 'English': 'en', 'Finnish': 'fi',
					'French': 'fr', 'German': 'de', 'Greek': 'el', 'Hebrew': 'he', 'Hungarian': 'hu', 'Italian': 'it', 'Japanese': 'ja', 'Korean': 'ko',
					'Norwegian': 'no', 'Polish': 'pl', 'Portuguese': 'pt', 'Romanian': 'ro', 'Russian': 'ru', 'Serbian': 'sr', 'Slovak': 'sk',
					'Slovenian': 'sl', 'Spanish': 'es', 'Swedish': 'sv', 'Thai': 'th', 'Turkish': 'tr', 'Ukrainian': 'uk'}
	trakt = ('bg', 'cs', 'da', 'de', 'el', 'en', 'es', 'fi', 'fr', 'he', 'hr', 'hu', 'it', 'ja', 'ko', 'nl', 'no', 'pl', 'pt', 'ro', 'ru', 'sk', 'sl', 'sr', 'sv', 'th', 'tr', 'uk', 'zh')
	tvdb = ('en', 'sv', 'no', 'da', 'fi', 'nl', 'de', 'it', 'es', 'fr', 'pl', 'hu', 'el', 'tr', 'ru', 'he', 'ja', 'pt', 'zh', 'cs', 'sl', 'hr', 'ko')
	youtube = ('gv', 'gu', 'gd', 'ga', 'gn', 'gl', 'ty', 'tw', 'tt', 'tr', 'ts', 'tn', 'to', 'tl', 'tk', 'th', 'ti', 'tg', 'te', 'ta', 'de', 'da', 'dz', 'dv', 'qu', 'zh', 'za', 'zu',
					'wa', 'wo', 'jv', 'ja', 'ch', 'co', 'ca', 'ce', 'cy', 'cs', 'cr', 'cv', 'cu', 'ps', 'pt', 'pa', 'pi', 'pl', 'mg', 'ml', 'mn', 'mi', 'mh', 'mk', 'mt', 'ms',
					'mr', 'my', 've', 'vi', 'is', 'iu', 'it', 'vo', 'ii', 'ik', 'io', 'ia', 'ie', 'id', 'ig', 'fr', 'fy', 'fa', 'ff', 'fi', 'fj', 'fo', 'ss', 'sr', 'sq', 'sw', 'sv', 'su', 'st', 'sk',
					'si', 'so', 'sn', 'sm', 'sl', 'sc', 'sa', 'sg', 'se', 'sd', 'lg', 'lb', 'la', 'ln', 'lo', 'li', 'lv', 'lt', 'lu', 'yi', 'yo', 'el', 'eo', 'en', 'ee', 'eu', 'et', 'es', 'ru',
					'rw', 'rm', 'rn', 'ro', 'be', 'bg', 'ba', 'bm', 'bn', 'bo', 'bh', 'bi', 'br', 'bs', 'om', 'oj', 'oc', 'os', 'or', 'xh', 'hz', 'hy', 'hr', 'ht', 'hu', 'hi', 'ho',
					'ha', 'he', 'uz', 'ur', 'uk', 'ug', 'aa', 'ab', 'ae', 'af', 'ak', 'am', 'an', 'as', 'ar', 'av', 'ay', 'az', 'nl', 'nn', 'no', 'na', 'nb', 'nd', 'ne', 'ng',
					'ny', 'nr', 'nv', 'ka', 'kg', 'kk', 'kj', 'ki', 'ko', 'kn', 'km', 'kl', 'ks', 'kr', 'kw', 'kv', 'ku', 'ky')
	tmdb = ('bg', 'cs', 'da', 'de', 'el', 'en', 'es', 'fi', 'fr', 'he', 'hr', 'hu', 'it', 'ja', 'ko', 'nl', 'no', 'pl', 'pt', 'ro', 'ru', 'sk', 'sl', 'sr', 'sv', 'th', 'tr', 'uk', 'zh')
	name = None
	name = setting('api.language')
	if not name: name = 'AUTO'
	if name[-1].isupper():
		try: name = xbmc.getLanguage(xbmc.ENGLISH_NAME).split(' ')[0]
		except: pass
	try: name = langDict[name]
	except: name = 'en'
	lang = {'trakt': name} if name in trakt else {'trakt': 'en'}
	lang['tvdb'] = name if name in tvdb else 'en'
	lang['youtube'] = name if name in youtube else 'en'
	lang['tmdb'] = name if name in tmdb else 'en'
	if ret_name:
		lang['trakt'] = [i[0] for i in iter(langDict.items()) if i[1] == lang['trakt']][0]
		lang['tvdb'] = [i[0] for i in iter(langDict.items()) if i[1] == lang['tvdb']][0]
		lang['youtube'] = [i[0] for i in iter(langDict.items()) if i[1] == lang['youtube']][0]
		lang['tmdb'] = [i[0] for i in iter(langDict.items()) if i[1] == lang['tmdb']][0]
	return lang

def mpaCountry():
# Countries with Content Rating System
	countryDict = {'Australia': 'AU', 'Austria': 'AT', 'Brazil': 'BR', 'Bulgaria': 'BG', 'Canada': 'CA', 'China': 'CN', 'Denmark': 'DK', 'Estonia': 'EE',
						'Finland': 'FI', 'France': 'FR', 'Germany': 'DE', 'Greece': 'GR', 'Hungary': 'HU', 'Hong Kong SAR China': 'HK', 'India': 'IN',
						'Indonesia': 'ID', 'Ireland': 'IE', 'Italy': 'IT', 'Japan': 'JP', 'Kazakhstan': 'KZ', 'Latvia': 'LV', 'Lithuania': 'LT', 'Malaysia': 'MY',
						'Mexico': 'MX', 'Netherlands': 'NL', 'New Zealand': 'NZ', 'Norway': 'NO', 'Philippines': 'PH', 'Poland': 'PL', 'Portugal': 'PT',
						'Romania': 'RO', 'Russia': 'RU', 'Saudi Arabia': 'SA', 'Singapore': 'SG', 'Slovakia': 'SK', 'South Africa': 'ZA', 'South Korea': 'KR',
						'Spain': 'ES', 'Sweden': 'SE', 'Switzerland': 'CH', 'Taiwan': 'TW', 'Thailand': 'TH', 'Turkey': 'TR', 'Ukraine': 'UA',
						'United Arab Emirates': 'AE', 'United Kingdom': 'GB', 'United States': 'US', 'Vietnam': 'VN'}
	return countryDict[setting('mpa.country')]

def autoTraktSubscription(tvshowtitle, year, imdb, tvdb): #---start adding TMDb to params
	from resources.lib.modules import library
	library.libtvshows().add(tvshowtitle, year, imdb, tvdb)

def getColor(n):
	colorChart = ('cyan', 'darkgoldenrod', 'orange', 'mediumspringgreen', 'magenta', 'deeppink', 'red', 'gold', 'yellow',
						'yellowgreen', 'limegreen', 'lime', 'lawngreen', 'whitesmoke', 'white', 'nocolor')
	if not n: n = '8'
	color = colorChart[int(n)]
	return color

def getHighlightColor():
	return getColor(setting('highlight.color'))

def getSourceHighlightColor():
	return getColor(setting('sources.highlight.color'))


def getDebridHighlightColor(debrid_abv):
	"""Return a HEX color for a Debrid service abbreviation (RD/PM/AD/TB/etc).
	Falls back to the global source highlight color when unknown.

	v1.0.84: the six hand-written hex values are gone. The hue still belongs
	to each service, but the SURFACE role (this is the card tint, not text)
	decides luminosity and saturation, so the tint can never end up competing
	with the ink painted on top of it. See modules/color_norm.py."""
	from resources.lib.modules import color_norm
	return color_norm.surface(debrid_abv) or getSourceHighlightColor()
def getMenuEnabled(menu_title):
	is_enabled = setting(menu_title).strip()
	if (is_enabled == '' or is_enabled == 'false'): return False
	return True

def in_videos_window():
	"""v2.0.28: True when a list is being drawn in Kodi's Videos window. False when a
	skin draws it as a widget on its home screen (or any other window): there the
	plugin must not force a view, pop 'no results' toasts or touch the playlist."""
	try: return bool(condVisibility('Window.IsActive(10025)'))
	except Exception: return True

def trigger_widget_refresh():
	import time
	timestr = time.strftime("%Y%m%d%H%M%S", time.gmtime())
	homeWindow.setProperty("widgetreload", timestr)
	homeWindow.setProperty('widgetreload-episodes', timestr)
	homeWindow.setProperty('widgetreload-movies', timestr)
	# execute('UpdateLibrary(video,/fake/path/to/force/refresh/on/home)') # make sure this is ok coupled with above

def refresh_playAction(): # for luc_kodi global CM play actions
	autoPlay = 'true' if setting('play.mode') == '1' else ''
	homeWindow.setProperty('luc_kodi.autoPlay.enabled', autoPlay)

def refresh_contextStyle(): # v2.0.09: luc_kodi context panel / Exit list global CM entries
	try:
		from resources.lib.modules import context_hub
		context_hub.refresh_properties()
	except: pass

def refresh_libPath(): # for luc_kodi global CM library actions
	homeWindow.setProperty('luc_kodi.movieLib.path', transPath(setting('library.movie')))
	homeWindow.setProperty('luc_kodi.tvLib.path', transPath(setting('library.tv')))

def refresh_debugReversed(): # called from service "onSettingsChanged" to clear luc_kodi.log if setting to reverse has been changed
	if homeWindow.getProperty('luc_kodidebug.reversed') != setting('debug.reversed'):
		homeWindow.setProperty('luc_kodi.debug.reversed', setting('debug.reversed'))
#		execute('RunPlugin(plugin://plugin.video.luc_kodi/?action=tools_clearLogFile)')

def metadataClean(metadata):
	if not metadata: return metadata
	allowed = ('genre', 'country', 'year', 'episode', 'season', 'sortepisode', 'sortseason', 'episodeguide', 'showlink',
					'top250', 'setid', 'tracknumber', 'rating', 'userrating', 'watched', 'playcount', 'overlay', 'cast', 'castandrole',
					'director', 'mpaa', 'plot', 'plotoutline', 'title', 'originaltitle', 'sorttitle', 'duration', 'studio', 'tagline', 'writer',
					'tvshowtitle', 'premiered', 'status', 'set', 'setoverview', 'tag', 'imdbnumber', 'code', 'aired', 'credits', 'lastplayed',
					'album', 'artist', 'votes', 'path', 'trailer', 'dateadded', 'mediatype', 'dbid')
	return {k: v for k, v in iter(metadata.items()) if k in allowed}

def infoTagger(item, meta=None):
	if not meta: return
	meta_get = meta.get
	unique_ids = {i: val for i in ('imdb', 'tmdb', 'tvdb') if (val := meta_get(i))}
	if isinstance(votes := meta_get('votes', 0), str):
		votes = int(votes) if (votes := votes.replace(',', '')).isdecimal() else 0
	if KODI_VERSION < 20:
		item.setUniqueIDs(unique_ids)
		item.setCast(meta_get('castandart', []))
		legacy = metadataClean(meta)
		# TMDb sends the collection as belongs_to_collection; metadataClean
		# only lets 'set' through, so the name never reached Kodi and skins
		# showed nothing where they display the saga.
		if (collection := meta_get('belongs_to_collection')) and isinstance(collection, dict):
			if collection.get('name'): legacy['set'] = collection['name']
		# Genres arrive slash separated ('Animation / Adventure / Comedy').
		if isinstance(legacy.get('genre'), str) and ' / ' in legacy['genre']:
			legacy['genre'] = [g.strip() for g in legacy['genre'].split('/') if g.strip()]
		item.setInfo(type='video', infoLabels=legacy)
	else:
		infotag_dict = {'country_codes': 'setCountries',
						'duration': 'setDuration',
						'imdbnumber': 'setIMDBNumber',
						'mediatype': 'setMediaType',
						'mpaa': 'setMpaa',
						'originaltitle': 'setOriginalTitle',
						'playcount': 'setPlaycount',
						'plot': 'setPlot',
						'premiered': 'setPremiered',
						'status': 'setTvShowStatus',
						'tag': 'setTags',
						'tagline': 'setTagLine',
						'title': 'setTitle',
						'trailer': 'setTrailer',
						'tvshowtitle': 'setTvShowTitle',
						'episode': 'setEpisode',
						'season': 'setSeason',
						'year': 'setYear',
						'rating': 'setRating',
						'votes': 'setVotes',
						'director': 'setDirectors',
						'genre': 'setGenres',
						'studio': 'setStudios',
						'writer': 'setWriters'}
		infotag = item.getVideoInfoTag()
		infotag.setUniqueIDs(unique_ids)
		infotag.setCast([xbmc.Actor(**actor) for actor in meta_get('castandart', [])])
		for key in infotag_dict:
			if not key in meta or not (arg := meta[key]): continue
			if   key in {'director', 'genre', 'studio', 'writer'}:
				# Some sources give a list already; the rest use ', ' OR ' / '.
				# Genres in particular arrive as 'Animation / Adventure / Comedy',
				# which a ', ' split turns into one genre with slashes inside it.
				if isinstance(arg, (list, tuple)): arg = list(arg)
				elif ' / ' in arg: arg = [a.strip() for a in arg.split('/') if a.strip()]
				else: arg = arg.split(', ')
			elif key in {'episode', 'season', 'year'}: arg = int(arg)
			elif key == 'rating':
				try: arg = float(arg)
				except (TypeError, ValueError): continue # 'None'/'N/A' de fuentes externas
			elif key == 'votes': arg = votes
			func = getattr(infotag, infotag_dict[key])
			func(arg)

		# control.py imports log_utils lazily everywhere to avoid a circular
		# import; the same applies here.
		from resources.lib.modules import log_utils

		# Collection: skins that show which saga a film belongs to had nothing
		# to read, because the name sits inside belongs_to_collection.
		try:
			if (collection := meta_get('belongs_to_collection')) and isinstance(collection, dict):
				if collection.get('name'): infotag.setSet(collection['name'])
		except Exception: log_utils.error()

		# Rating with its source attached, so a skin asking for
		# VideoPlayer.Rating(tmdb) finds it. setRating() alone leaves it
		# anonymous and those skins come up empty.
		# v2.0.28: plus IMDb, Trakt, Rotten Tomatoes and Metacritic when the list
		# already had them saved (skin_props.decorate leaves them in luc_ratings),
		# for skins that read ListItem.Rating(imdb) and the like. setRatings()
		# replaces the whole set, so they go in the same call; TMDb stays default.
		ratings_set = {}
		try:
			if (rating := meta_get('rating')) not in (None, '', 'None', 'N/A'):
				ratings_set['tmdb'] = (float(rating), int(votes))
		except (TypeError, ValueError): pass
		except Exception: log_utils.error()
		try:
			if (extra := meta_get('luc_ratings')):
				from resources.lib.modules.skin_props import kodi_ratings
				for k, v in kodi_ratings(extra).items(): ratings_set.setdefault(k, v)
		except Exception: log_utils.error()
		try:
			if ratings_set:
				infotag.setRatings(ratings_set, defaultrating='tmdb' if 'tmdb' in ratings_set else next(iter(ratings_set)))
		except Exception: log_utils.error()

		try:
			if (outline := meta_get('plotoutline') or meta_get('tagline')): infotag.setPlotOutline(outline)
		except Exception: log_utils.error()
def setVideoLabels(item, labels=None):
	"""v2.0.23: ListItem.setInfo() esta obsoleto desde Kodi 20 y en Kodi 21/22
	deja un aviso en kodi.log por CADA item (las carpetas de debrid y el menu
	de YouTube llenaban el log). Aqui se usa setInfo solo en Kodi 19 y, del 20
	en adelante, el InfoTagVideo via infoTagger(). Con etiquetas vacias basta
	con pedir el tag para que el item quede marcado como video."""
	labels = labels if isinstance(labels, dict) else {}
	if KODI_VERSION < 20:
		item.setInfo(type='video', infoLabels=labels)
	elif labels:
		infoTagger(item, labels)
	else:
		item.getVideoInfoTag()
