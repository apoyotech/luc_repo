# -*- coding: utf-8 -*-
"""
	luc_kodi Add-on
	v2.0.37 -- Play an NZB file you already have (idea and decision of Lucian,
	17-nov-2026). Three ways in, one way out:

	  1. Movies / TV Shows > Play an NZB (v2.0.37, 19-nov-2026: antes en
	     Ajustes > Usenet): Kodi's file browser (device storage, USB, a
	     network share), the phone, and the NZBs played lately.
	  2. Kodi's context menu on any .nzb / .nzb.gz seen in the file manager.
	  3. From the phone: the same local page with QR and one-time code as the
	     setup wizards; pick the file or paste its text and it plays on the TV.

	Then it is exactly an NZB from the indexer: it is copied to the engine's
	folder (the original is never touched), the password of a locked 7z comes
	from <meta type="password">, the title is looked up on TMDb for artwork,
	Trakt scrobble and resume, and the Easynews engine plays it. The NZB never
	leaves the device: only the article ids go to Easynews, as always.
"""

import gzip
import hashlib
import os
import re
import socket
import threading
import time

from resources.lib.modules import control
from resources.lib.modules import log_utils
from resources.lib.modules import usenet_core as core

MAX_NZB = 200 * 1024 * 1024   # v2.0.37: un disco entero de 300 GB trae un NZB de 84 MB (Gladiator de COASTER)
NOT_PLAYABLE = 'This NZB cannot be played in luc_kodi'   # aviso corto (Lucian, 17-nov-2026)
_RE_ADULT = re.compile(r'(?i)(?:^|[ ._\-\[(])(xxx|porn\w*|onlyfans|brazzers|bangbros|realitykings|naughtyamerica|'
					   r'vixen|blacked|tushy|evilangel|pornhub|xvideos|hentai|milf|nubiles|metart|teamskeet|mofos|'
					   r'digitalplayground|fakehub)(?:[ ._\-\])]|$)')


def adult_filter_on():
	"""Settings > Usenet > Adult Content Filter (encendido por defecto)."""
	return (control.setting('easynews.moderation') or 'true') == 'true'


def is_adult(name, raw=None):
	"""Categoria XXX del NZB o un nombre de adultos. Razonable, no infalible."""
	cat = (core.nzb_meta(raw, 'category') or '') if raw is not None else ''
	return bool(re.search(r'(?i)\b(xxx|adult|porn)', cat)) or bool(_RE_ADULT.search(name or ''))


def _not_playable(key, why):
	log_utils.log('USENET: local NZB %s: not played: %s' % (key[:8], why), level=log_utils.LOGINFO)
	control.notification(message=NOT_PLAYABLE)        # un NZB de un remux de 90 GB ronda 4 MB
HEADING = 'luc_kodi — Play an NZB'
RECENT_MAX = 12                        # NZBs en 'Played lately'
RECENT_BYTES = 300 * 1024 * 1024       # y no mas de esto entre todos (van en .gz)
_PORT = 48251
_TIMEOUT = 300
_RE_YEAR = re.compile(r'(?<!\d)(19[2-9]\d|20[0-4]\d)(?!\d)')
_RE_SEASON = re.compile(r'(?i)(?:^|[ ._\-\[(])s(\d{1,2})(?:[ ._\-\])]|$)')
_RE_CUT = re.compile(r'(?i)[ ._\-\[(](?:s\d{1,2}(?:e\d{1,3})?|\d{1,2}x\d{2,3}|2160p|1080p|720p|480p|4k|uhd|web|bluray|remux|hdtv|complete)(?:[ ._\-\])]|$)')


# ------------------------------------------------------------ el fichero ----
def validate(raw):
	"""(bytes listos para el motor, ficheros, clave) o ValueError con el motivo."""
	if not raw:
		raise ValueError('the file is empty')
	if len(raw) > MAX_NZB:
		raise ValueError('the file is too big for an NZB (%d MB)' % (len(raw) // 1048576))
	plain = raw
	if raw[:2] == b'\x1f\x8b':
		try:
			plain = gzip.decompress(raw)
		except Exception:
			raise ValueError('the .gz file is damaged')
	if b'<nzb' not in plain[:65536]:
		raise ValueError('this is not an NZB file')
	try:
		files = core.parse_nzb(plain)
	except Exception as e:
		raise ValueError('the NZB cannot be read (%s)' % type(e).__name__)
	if not files:
		raise ValueError('the NZB lists no files')
	media, _kind = core.pick_media(files)
	if not media and not core.content_kind([(f.get('name'), f.get('bytes')) for f in files])[0]:
		raise ValueError('the NZB has no video or archive inside')
	key = hashlib.md5(b'local|' + plain).hexdigest()
	return gzip.compress(plain, 6), files, key


def release_name(raw, fallback=''):
	"""El nombre del release: <meta type="name">, el del fichero o el del video."""
	try:
		plain = gzip.decompress(raw) if raw[:2] == b'\x1f\x8b' else raw
		head = plain[:plain.find(b'<file')] if b'<file' in plain else plain[:65536]
		m = re.search(rb'<meta[^>]*type=["\']name["\'][^>]*>([^<]+)</meta>', head, re.I)
		if m:
			import html
			name = html.unescape(m.group(1).decode('utf-8', 'replace')).strip()
			# v2.0.37 (Gladiator COMPLETE.UHD.BLURAY de COASTER, 19-nov-2026): el indexer
			# puso de nombre el asunto de un volumen ('[004/411] - "I2420720053I.part003.rar"
			# yEnc'); eso no es el nombre del release, el del fichero NZB si
			if name and not _subject_like(name): return name
	except Exception:
		pass
	base = os.path.basename(fallback or '').strip()
	for ext in ('.gz', '.nzb'):
		if base.lower().endswith(ext): base = base[:-len(ext)]
	base = re.sub(r'_\d{1,2}$', '', base)      # 'Nombre_1.nzb': la segunda copia bajada
	return base


_RE_SUBJECT = re.compile(r'(?i)\byEnc\b|^\s*\[?\d{1,5}/\d{1,5}\]|\.(?:part\d+\.rar|r\d\d|\d{3}|7z|par2)"?\s*$')


def _subject_like(name):
	"""Un asunto de Usenet o el nombre de un volumen, no el de un release."""
	return bool(_RE_SUBJECT.search(name or ''))


def guess(name):
	"""{'title', 'year', 'season', 'episode', 'pack'} de un nombre de release.
	El ano es el ULTIMO que aparece antes de la calidad: 'Blade Runner 2049
	(2017)' es la de 2017 y su titulo lleva el 2049."""
	n = (name or '').strip()
	pairs = sorted(core.episode_pairs(n))
	m = _RE_CUT.search(n)
	end = m.start() if m else len(n)
	years = [y for y in _RE_YEAR.finditer(n[:end + 6]) if y.start() > 0]
	year = None
	if years:
		y = years[-1]
		year = int(y.group(1))
		end = min(end, y.start())
	title = re.sub(r'[._]+', ' ', n[:end]).strip(' -[](')
	season = episode = None
	if pairs:
		season, episode = pairs[0]
	else:
		ms = _RE_SEASON.search(n)
		if ms: season = int(ms.group(1))
	return {'title': title, 'year': year, 'season': season, 'episode': episode,
			'pack': bool(season is not None and episode is None) or len(pairs) > 1}


def pack_episodes(files):
	"""Episodios que nombran los ficheros del NZB, en orden."""
	eps = set()
	for f in files:
		if core.classify(f.get('name')) in ('par2', 'extra'): continue
		# v2.0.39: un fichero de nombre ofuscado no nombra ningun episodio
		if _obfuscated(re.sub(r'(?i)(\.(?:part\d+|r\d\d|z\d\d|\d{3}|7z|rar|zip|mkv|mp4|avi|ts|m2ts|iso))+$', '', f.get('name') or '')): continue
		eps.update(core.episode_pairs(f.get('name')))
	return sorted(eps)


# ------------------------------------------------------------------ TMDb ----
def _norm(t):
	import unicodedata
	t = unicodedata.normalize('NFKD', t or '').encode('ascii', 'ignore').decode('ascii').lower()
	return re.sub(r'[^a-z0-9]+', '', t.replace('&', 'and'))


def match_tmdb(g):
	"""meta para play_source, o {} si no hay coincidencia segura (mejor sin ficha
	que con la de otra pelicula: el scrobble de Trakt iria a la equivocada)."""
	try:
		from resources.lib.modules.assistant_search import _tmdb_get
	except Exception:
		return {}
	tv = g.get('season') is not None
	try:
		params = {'query': g['title']}
		if g.get('year') and not tv: params['year'] = g['year']
		res = (_tmdb_get('/search/tv' if tv else '/search/movie', **params) or {}).get('results') or []
	except Exception:
		return {}
	want = _norm(g['title'])
	best = None
	for r in res[:10]:
		names = [r.get('name'), r.get('original_name')] if tv else [r.get('title'), r.get('original_title')]
		if want not in [_norm(x) for x in names if x]:
			continue
		date = (r.get('first_air_date') if tv else r.get('release_date')) or ''
		y = int(date[:4]) if date[:4].isdigit() else None
		if not tv and g.get('year') and y and abs(y - g['year']) > 1:
			continue
		best = r
		break
	if not best:
		return {}
	img = 'https://image.tmdb.org/t/p/%s%s'
	meta = {'tmdb': str(best.get('id')), 'plot': best.get('overview') or '',
			'poster': img % ('w500', best['poster_path']) if best.get('poster_path') else '',
			'fanart': img % ('w1280', best['backdrop_path']) if best.get('backdrop_path') else ''}
	try:
		if tv:
			d = _tmdb_get('/tv/%s' % best['id'], append_to_response='external_ids')
			ext = d.get('external_ids') or {}
			meta.update({'mediatype': 'episode', 'tvshowtitle': d.get('name') or g['title'],
						 'title': d.get('name') or g['title'], 'imdb': ext.get('imdb_id') or '',
						 'tvdb': str(ext.get('tvdb_id') or ''),
						 'year': (d.get('first_air_date') or '')[:4]})
		else:
			d = _tmdb_get('/movie/%s' % best['id'], append_to_response='external_ids')
			meta.update({'mediatype': 'movie', 'title': d.get('title') or g['title'],
						 'imdb': d.get('imdb_id') or (d.get('external_ids') or {}).get('imdb_id') or '',
						 'year': (d.get('release_date') or '')[:4],
						 'duration': int(d.get('runtime') or 0) * 60 or None})
	except Exception:
		return {}
	return meta


# ---------------------------------------------------------------- reproducir
def _weak(name):
	"""Un nombre que no dice nada (el de por defecto o uno ofuscado)."""
	n = (name or '').strip()
	if not n or n.upper() == 'NZB' or _subject_like(n):
		return True
	return bool(re.match(r'^[A-Za-z0-9]{20,}$', n)) and not re.search(r'[ ._-]', n)


def _obfuscated(name):
	"""v2.0.39: un nombre ofuscado (20+ letras y cifras al azar, sin separadores).
	Lo que parezca un episodio dentro (un 'S1E31' o '1x31' de pura casualidad)
	no lo es."""
	n = (name or '').strip()
	return bool(re.match(r'^[A-Za-z0-9]{20,}$', n))


def _inner_name(ue, key):
	"""El nombre del video dentro del archivo, de la sesion ya abierta (al momento)."""
	try:
		import json
		port = ue._service_port()
		info = json.loads(ue._local_get(port, '/prepare/%s' % key, timeout=10).decode('utf-8'))
		return info.get('inner') or info.get('name') or ''
	except Exception:
		return ''


def _ok(msg):
	try: control.okDialog(title=HEADING, message=msg)
	except Exception: pass


def play_raw(raw, label=''):
	"""Reproduce un NZB recibido en bytes. True si arranco el video."""
	from resources.lib.modules import usenet_easynews as ue
	# v2.0.37: este camino no pasa por la sonda; lo que publico la sonda de la
	# pelicula anterior no es de esta (kodi.log 19-nov-2026: Gladiator salia en
	# PLAYSTATS con el bitrate de un episodio de Chicago Med visto 50 s antes)
	try:
		from resources.lib.modules import audio_probe
		audio_probe.clear_expect()
	except Exception:
		pass
	try:
		data, files, key = validate(raw)
	except ValueError as e:
		_ok('[COLOR ffff6666]%s[/COLOR]' % str(e).capitalize())
		return False
	if not ue.enabled():
		_ok('Playing an NZB needs your Easynews account.\n\n'
			'Add it in Settings > Usenet > Easynews account, with "1. Easynews" switched on.')
		return False
	name = release_name(data, label) or (core.pick_media(files)[0] or files[0] or {}).get('name') or 'NZB'
	# v2.0.37 (Lucian, 17-nov-2026): solo peliculas y TV; lo demas se avisa
	kind, sample = core.content_kind([(f.get('name'), f.get('bytes')) for f in files
									  if core.classify(f.get('name')) != 'par2'
									  and core.ext_of(f.get('name')) not in ('nfo', 'sfv', 'srr', 'nzb', 'txt', 'url')])
	if kind in core.NOT_VIDEO:
		_not_playable(key, 'it holds %s (%s)' % (kind, sample))
		return False
	# v2.0.37 (Lucian, 17-nov-2026): con el filtro de adultos encendido no se
	# reproduce contenido para adultos
	if adult_filter_on() and is_adult(name, data):
		_not_playable(key, 'adult content and the Adult Content Filter is on')
		return False
	g = guess(name)
	if _obfuscated(name):
		# v2.0.39 (simulacion de la 2.0.39, 1 de cada 60): un nombre al azar puede
		# traer un 'S1E31' de casualidad; con el, la pelicula se buscaba en TMDb como
		# serie y se quedaba sin ficha. El episodio lo dice el nombre de dentro.
		g.update({'season': None, 'episode': None, 'pack': False})
	season, episode = g['season'], g['episode']
	package = False
	eps = pack_episodes(files)
	if g['pack'] or len(eps) > 1:
		package = True
		if eps:
			labels = ['S%02dE%02d' % se for se in eps]
			k = control.selectDialog(labels, heading='%s — which episode?' % (g['title'] or name))
			if k < 0: return False
			season, episode = eps[k]
		else:
			s = control.dialog.numeric(0, 'Season', str(season or 1))
			if not s: return False
			e = control.dialog.numeric(0, 'Episode', '1')
			if not e: return False
			season, episode = int(s), int(e)
	path = os.path.join(ue.nzb_dir(), '%s.nzb' % key)
	try:
		with open(path + '.part', 'wb') as f:
			f.write(data)
		os.replace(path + '.part', path)
	except Exception as e:
		_ok('[COLOR ffff6666]Could not copy the NZB (%s)[/COLOR]' % type(e).__name__)
		return False
	log_utils.log('USENET: local NZB %s: %s (%d files%s)' % (key[:8], name, len(files),
				  ', password inside' if core.nzb_password(data) else ''), level=log_utils.LOGINFO)
	g['season'], g['episode'] = season, episode
	bg = control.progressDialogBG
	bg.create(HEADING, name[:60])
	try:
		bg.update(20, 'Looking up the title...')
		meta = match_tmdb(g) if g.get('title') and not _weak(name) else {}
		bg.update(50, 'Opening the release on Easynews...')
		item = {'url': '', 'hash': key, 'name': name, 'package': package, 'provider': 'newznab',
				'source': 'usenet', 'debrid': 'Easynews', 'local': True}
		url, why = ue.resolve(item, runtime=meta.get('duration'), season=season, episode=episode)
		if url and not meta:
			# v2.0.37 (kodi.log del 17-nov-2026, Four Rooms desde el movil): sin nombre
			# util fuera, el del video dentro del 7z sirve para la ficha
			inner = _inner_name(ue, key)
			if inner and _weak(name):
				name = re.sub(r'\.(mkv|mp4|avi|ts|m2ts)$', '', inner, flags=re.I)
				name = re.sub(r'(?i)^(?:ISO - )?(.*?)\s+-\s+\d{5}\.mpls$', r'\1', name)   # disco: su carpeta
				g2 = guess(name)
				if g2.get('title'):
					if not package and season is None and episode is None:
						season, episode = g2['season'], g2['episode']  # v2.0.39: el episodio, del nombre de dentro
					g2['season'], g2['episode'] = season, episode
					g = g2
			if g.get('title') and not _weak(name):
				bg.update(80, 'Looking up the title...')
				meta = match_tmdb(g)
	finally:
		try: bg.close()
		except Exception: pass
	log_utils.log('USENET: local NZB %s: TMDb %s' % (key[:8], ('%s (tmdb %s, imdb %s)' % (meta.get('title') or meta.get('tvshowtitle'),
				  meta.get('tmdb'), meta.get('imdb') or '-')) if meta.get('tmdb') else 'no sure match for "%s" %s' % (g.get('title'), g.get('year') or '')),
				  level=log_utils.LOGINFO)
	if not url and str(why).startswith('this NZB holds'):
		_not_playable(key, why)
		return False
	if not url:
		log_utils.log('USENET: local NZB %s did not play: %s' % (key[:8], why), level=log_utils.LOGINFO)
		_ok('This NZB cannot be played in luc_kodi:\n[COLOR ffff6666]%s[/COLOR]' % why)
		return False
	title = meta.get('tvshowtitle') or meta.get('title') or g['title'] or name
	if season is not None and episode is not None:
		meta.update({'mediatype': 'episode', 'tvshowtitle': title, 'season': season, 'episode': episode})
	else:
		meta.setdefault('mediatype', 'movie'); meta.setdefault('title', title)
	remember_recent(key, data, {'name': name, 'title': title, 'year': str(meta.get('year') or g.get('year') or ''),
								'mediatype': meta.get('mediatype'), 'season': season, 'episode': episode,
								'package': package, 'poster': meta.get('poster') or '',
								'fanart': meta.get('fanart') or '', 'plot': meta.get('plot') or ''})
	try:
		from resources.lib.modules import release_info
		release_info.remember({'name': name, 'provider': 'NZB file', 'url': name})
	except Exception:
		pass
	from resources.lib.modules import player
	player.Player().play_source(title, meta.get('year') or g.get('year') or '', season, episode,
								meta.get('imdb') or '', meta.get('tmdb') or '', meta.get('tvdb') or '',
								url, meta, debridPackCall=True)
	return True


# ------------------------------------------------ 'Played lately' (recientes)
# v2.0.37 (Lucian, 19-nov-2026): Play an NZB tiene su categoria en Movies y TV
# Shows, y en ella los ultimos NZB reproducidos, para volver a abrirlos sin
# buscar el fichero (y con la lista del disco y el indice ya guardados, al
# momento). Se guarda una copia comprimida: el NZB del movil no esta en el
# aparato y el del USB puede no estar enchufado.
def _recent_dir():
	from resources.lib.modules import usenet_easynews as ue
	d = os.path.join(ue._usenet_dir(), 'recent')
	if not os.path.isdir(d):
		os.makedirs(d)
	return d


def _recent_index():
	return os.path.join(_recent_dir(), 'recent.json')


def _recent_save(items):
	import json
	path = _recent_index()
	with open(path + '.part', 'w') as f:
		json.dump(items, f)
	os.replace(path + '.part', path)


def recent_list():
	"""Los NZB reproducidos hace poco, el ultimo primero."""
	import json
	try:
		with open(_recent_index()) as f:
			items = json.load(f)
		d = _recent_dir()
		return [e for e in items if isinstance(e, dict) and e.get('key')
				and os.path.isfile(os.path.join(d, '%s.nzb.gz' % e['key']))]
	except Exception:
		return []


def remember_recent(key, data, entry):
	"""Pone el NZB el primero de la lista (data ya va en .gz, de validate)."""
	try:
		d = _recent_dir()
		path = os.path.join(d, '%s.nzb.gz' % key)
		if not os.path.isfile(path):
			with open(path + '.part', 'wb') as f:
				f.write(data)
			os.replace(path + '.part', path)
		entry = dict(entry, key=key, when=int(time.time()), bytes=len(data))
		items = [entry] + [e for e in recent_list() if e.get('key') != key]
		keep, total = [], 0
		for e in items:
			total += int(e.get('bytes') or 0)
			if len(keep) < RECENT_MAX and (not keep or total <= RECENT_BYTES):
				keep.append(e)
		_recent_save(keep)
		mine = set('%s.nzb.gz' % e['key'] for e in keep) | {'recent.json'}
		for n in os.listdir(d):
			if n not in mine:
				try: os.remove(os.path.join(d, n))
				except OSError: pass
	except Exception:
		log_utils.error()


def recent_is_tv(e):
	"""Un episodio (o un pack de temporada), no una pelicula."""
	if (e.get('mediatype') or '') in ('episode', 'tvshow', 'season'):
		return True
	if (e.get('mediatype') or '') == 'movie':
		return False
	return e.get('season') not in (None, '')


_TAG_EDITION = (('extended', 'Extended'), ('directors.cut', "Director's Cut"), ('imax', 'IMAX'),
				('remastered', 'Remastered'), ('theatrical', 'Theatrical'), ('collectors', "Collector's"),
				('uncut', 'Uncut'), ('special.edition', 'Special Edition'), ('criterion', 'Criterion'))


def release_tag(name):
	"""Lo que distingue un release de otro de la misma pelicula, corto:
	'2160p · Extended · Blu-ray disc · COASTER'."""
	n = '.%s.' % re.sub(r'[^a-z0-9]+', '.', (name or '').lower()).strip('.')
	parts = []
	m = re.search(r'\.(2160p|1080p|720p|480p|4k)\.', n)
	if m: parts.append('2160p' if m.group(1) == '4k' else m.group(1))
	elif '.uhd.' in n: parts.append('2160p')
	for k, label in _TAG_EDITION:
		if '.%s.' % k in n:
			parts.append(label); break
	if re.search(r'\.(complete|full)\.(uhd\.)?blu\.?ray\.|\.bdmv\.|\.disc\.?\d|\.iso\.', n):
		parts.append('Blu-ray disc')
	elif '.remux.' in n:
		parts.append('Remux')
	elif re.search(r'\.web\.?(dl|rip)?\.', n):
		parts.append('WEB')
	elif re.search(r'\.blu\.?ray\.|\.bdrip\.', n):
		parts.append('Blu-ray')
	g = re.search(r'-([A-Za-z0-9]{2,20})(?:-(?:asrequested|obfuscated|rakuv\w*))*$', (name or '').strip(), re.I)
	if g and not g.group(1).isdigit() and g.group(1).lower() not in ('asrequested', 'obfuscated', 'postbot', 'repost'):
		parts.append(g.group(1))
	return '  ·  '.join(parts)


def forget_recent(key):
	items = recent_list()
	_recent_save([e for e in items if e.get('key') != key])
	try: os.remove(os.path.join(_recent_dir(), '%s.nzb.gz' % key))
	except OSError: pass


def play_recent(key):
	"""Play an NZB > Played lately > un NZB."""
	entry = next((e for e in recent_list() if e.get('key') == key), None)
	if not entry:
		_ok('This NZB is no longer in the list.')
		return
	try:
		with open(os.path.join(_recent_dir(), '%s.nzb.gz' % key), 'rb') as f:
			raw = f.read()
	except Exception as e:
		_ok('[COLOR ffff6666]Could not read the saved NZB (%s)[/COLOR]' % type(e).__name__)
		return
	play_raw(raw, (entry.get('name') or 'NZB') + '.nzb')


def play_file(path=None):
	"""Movies / TV Shows > Play an NZB > From this device, o el menu contextual (path dado)."""
	if not path:
		path = control.dialog.browse(1, 'Pick an NZB file', 'files', '.nzb|.gz')
		if not path:
			return
	try:
		import xbmcvfs
		f = xbmcvfs.File(path)
		try:
			raw = bytes(f.readBytes(MAX_NZB + 1))
		finally:
			f.close()
	except Exception:
		try:
			with open(path, 'rb') as fh:
				raw = fh.read(MAX_NZB + 1)
		except Exception as e:
			_ok('[COLOR ffff6666]Could not read %s (%s)[/COLOR]' % (os.path.basename(path), type(e).__name__))
			return
	play_raw(raw, path)


# --------------------------------------------------- desde el movil (QR) ----
_HTML_FORM = u"""<!doctype html>
<html><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Play an NZB on Kodi</title>
<style>
  body { font-family:-apple-system,system-ui,sans-serif; background:#141414; color:#eee; margin:0; padding:24px; }
  h1 { color:#00fa9a; margin:0 0 8px 0; font-size:22px; }
  p  { color:#aaa; line-height:1.5; margin:8px 0; }
  label { display:block; margin:18px 0 6px 0; color:#ccc; font-weight:bold; }
  input[type=file] { width:100%; color:#eee; }
  textarea { width:100%; box-sizing:border-box; height:160px; background:#1e1e1e; color:#fff;
             border:1px solid #333; border-radius:8px; padding:10px; font-family:monospace; font-size:12px; }
  button { background:#00fa9a; color:#000; border:0; border-radius:8px; padding:14px 28px; font-size:16px;
           font-weight:bold; margin-top:18px; cursor:pointer; width:100%; }
  .hint { color:#666; font-size:12px; margin-top:4px; }
  .or { text-align:center; color:#666; margin:14px 0 0 0; }
</style></head>
<body>
<h1>Play an NZB on Kodi</h1>
<p>Pick an NZB file saved on this phone or computer, or paste its text. Kodi plays it at once with your
Easynews account. The file goes only to your Kodi, on your own network.</p>
<form method="post" action="/" enctype="multipart/form-data">
  <label for="f">NZB file</label>
  <input id="f" type="file" name="nzbfile" accept=".nzb,.gz,application/x-nzb">
  <div class="hint">.nzb or .nzb.gz, up to 200 MB.</div>
  <p class="or">or</p>
  <label for="t">Paste the NZB text</label>
  <textarea id="t" name="nzbtext" placeholder="&lt;?xml version=&quot;1.0&quot; ...&gt;&#10;&lt;nzb ...&gt;"></textarea>
  <button type="submit">Play on Kodi</button>
</form>
</body></html>
"""

_HTML_OK = u"""<!doctype html><html><head><meta charset="utf-8"><title>Sent</title>
<meta name="viewport" content="width=device-width,initial-scale=1">
<style>body{font-family:system-ui;background:#141414;color:#00fa9a;text-align:center;padding:60px 20px}
h1{font-size:28px}p{color:#aaa}</style></head><body><h1>&check; Sent to Kodi</h1><p>%s</p>
<p>You can close this page and go back to Kodi.</p></body></html>
"""

_HTML_BAD = u"""<!doctype html><html><head><meta charset="utf-8"><title>Not an NZB</title>
<meta name="viewport" content="width=device-width,initial-scale=1">
<style>body{font-family:system-ui;background:#141414;color:#ff6666;text-align:center;padding:60px 20px}
h1{font-size:26px}p{color:#aaa}a{color:#00fa9a}</style></head><body><h1>Could not use it</h1><p>%s</p>
<p><a href="/">Try again</a></p></body></html>
"""


def parse_multipart(body, ctype):
	"""{nombre del campo: bytes} de un formulario multipart/form-data."""
	m = re.search(r'boundary="?([^";]+)"?', ctype or '', re.I)
	if not m:
		return {}
	sep = b'--' + m.group(1).encode('latin-1')
	out = {}
	for part in body.split(sep)[1:]:
		if part[:2] == b'--':
			break
		head, _, val = part.partition(b'\r\n\r\n')
		nm = re.search(rb'name="([^"]*)"', head)
		if not nm:
			continue
		if val.endswith(b'\r\n'):
			val = val[:-2]
		out[nm.group(1).decode('latin-1')] = val
	return out


def multipart_filename(body, field='nzbfile'):
	"""El nombre del fichero que subio el movil (filename= del campo), o ''."""
	m = re.search(rb'name="' + field.encode() + rb'";\s*filename="([^"]*)"', body[:65536])
	return os.path.basename(m.group(1).decode('utf-8', 'replace').replace('\\', '/')) if m else ''


def _form_value(body, ctype):
	"""Los bytes del NZB que mando la pagina (fichero o texto pegado)."""
	if 'multipart/form-data' in (ctype or '').lower():
		fields = parse_multipart(body, ctype)
		return fields.get('nzbfile') or fields.get('nzbtext') or b''
	from urllib.parse import unquote_plus
	for kv in body.split(b'&'):
		if kv.startswith(b'nzbtext='):
			return unquote_plus(kv[8:].decode('utf-8', 'replace')).encode('utf-8')
	return b''


class _PhoneServer(object):
	"""Como el de los asistentes (mismo codigo de un solo uso), con subida de
	ficheros de hasta 200 MB. Termina al recibir un NZB valido o al expirar."""

	def __init__(self, port):
		self.port, self.result, self.sock = port, None, None
		self._stop, self._thread, self._conns = False, None, set()

	def start(self):
		self.sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
		self.sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
		self.sock.bind(('', self.port))
		self.sock.listen(16)
		self.sock.settimeout(1.0)
		self._thread = threading.Thread(target=self._loop, daemon=True)
		self._thread.start()

	def stop(self):
		self._stop = True
		for c in list(self._conns):
			try: c.shutdown(socket.SHUT_RDWR)
			except Exception: pass
		try: self.sock.close()
		except Exception: pass

	def is_alive(self):
		return self._thread is not None and self._thread.is_alive()

	def _loop(self):
		from resources.lib.modules import wizard_pairing
		t0 = time.time()
		while not self._stop and time.time() - t0 < _TIMEOUT and self.result is None:
			try:
				conn, addr = self.sock.accept()
			except socket.timeout:
				continue
			except Exception:
				return
			wizard_pairing.knock(self, addr)
			threading.Thread(target=self._safe, args=(conn,), daemon=True).start()

	def _safe(self, conn):
		self._conns.add(conn)
		try: self._handle(conn)
		except Exception: pass
		finally:
			self._conns.discard(conn)
			try: conn.close()
			except Exception: pass

	def _handle(self, conn):
		from resources.lib.modules import wizard_pairing
		conn.settimeout(_TIMEOUT)
		if not wizard_pairing.sniff(self, conn):
			return
		data = b''
		while b'\r\n\r\n' not in data and len(data) < 65536:
			chunk = conn.recv(4096)
			if not chunk: break
			data += chunk
		if not data:
			return
		conn.settimeout(30.0)
		try: self.seen = conn.getpeername()[0]
		except Exception: pass
		head, _, body = data.partition(b'\r\n\r\n')
		headline = head.split(b'\r\n', 1)[0]
		if not wizard_pairing.gate(self, conn, headline):
			return
		if not headline.startswith(b'POST'):
			return self._send(conn, 200, 'OK', _HTML_FORM)
		clen, ctype = 0, ''
		for line in head.split(b'\r\n')[1:]:
			k, _, v = line.partition(b':')
			if k.strip().lower() == b'content-length':
				try: clen = int(v.strip())
				except ValueError: clen = 0
			elif k.strip().lower() == b'content-type':
				ctype = v.strip().decode('latin-1')
		if clen > MAX_NZB + 65536:
			return self._send(conn, 413, 'Too Large', _HTML_BAD % 'That file is too big for an NZB.')
		buf = bytearray(body)      # v2.0.37: hasta 200 MB, sin copiar en cada trozo
		while len(buf) < clen:
			chunk = conn.recv(min(1048576, clen - len(buf)))
			if not chunk: break
			buf += chunk
		body = bytes(buf)
		raw = _form_value(body, ctype).strip()
		try:
			_data, files, _key = validate(raw)
		except ValueError as e:
			return self._send(conn, 400, 'Bad Request', _HTML_BAD % str(e).capitalize())
		fname = multipart_filename(body) if 'multipart' in ctype.lower() else ''
		name = release_name(raw, fname) or 'NZB'
		self.result = (raw, name)
		self._send(conn, 200, 'OK', _HTML_OK % ('%s (%d files)' % (name, len(files))))

	def _send(self, conn, status, reason, body):
		from resources.lib.modules import wizard_pairing
		b = wizard_pairing.scope(self, body).encode('utf-8')
		head = ('HTTP/1.1 %d %s\r\nContent-Type: text/html; charset=utf-8\r\nContent-Length: %d\r\n'
				'Cache-Control: no-store\r\nConnection: close\r\n\r\n') % (status, reason, len(b))
		try: conn.sendall(head.encode('latin-1') + b)
		except Exception: pass


def _free_port():
	for port in range(_PORT, _PORT + 20):
		try:
			s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
			s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
			s.bind(('', port)); s.close()
			return port
		except Exception:
			continue
	return None


def play_from_phone():
	"""Movies / TV Shows > Play an NZB > From your phone or computer: pagina local con QR."""
	from resources.lib.modules import usenet_easynews as ue
	from resources.lib.modules import wizard_pairing
	from resources.lib.modules.newznab_wizard import _get_local_ip
	if not ue.enabled():
		_ok('Playing an NZB needs your Easynews account.\n\n'
			'Add it in Settings > Usenet > Easynews account, with "1. Easynews" switched on.')
		return
	port = _free_port()
	if port is None:
		_ok('Could not open a local port for the page.')
		return
	srv = _PhoneServer(port)
	try:
		srv.start()
	except Exception as e:
		_ok('Could not start the local page:\n%s' % e)
		return
	url = wizard_pairing.address(srv, _get_local_ip(), port)
	outcome = wizard_pairing.wait(srv, url, 'NZB playback', _TIMEOUT, 'the NZB file (pick it or paste it)')
	srv.stop()
	if outcome == 'cancelled' or srv.result is None:
		return
	raw, name = srv.result
	log_utils.log('USENET: NZB received from %s: %s' % (getattr(srv, 'seen', '?'), name), level=log_utils.LOGINFO)
	play_raw(raw, name)
