# -*- coding: utf-8 -*-
"""
	luc_kodi Add-on — Audio probe (v1.0.89)

	Nivel 2 de la sonda de audio: que pistas de audio hay DE VERDAD dentro del
	fichero que se va a reproducir, leidas de su cabecera antes de entregarlo
	al reproductor.

	Como funciona
	─────────────
	Un MKV describe todas sus pistas en el elemento Tracks, que mkvmerge y
	compania escriben al principio del fichero, antes del primer Cluster de
	video. Ahi va, por pista: tipo, codec, canales, idioma ISO 639-2, idioma
	BCP-47 (mkvmerge 50 en adelante, que es el unico sitio donde castellano y
	latino se distinguen por norma: es-ES frente a es-419), nombre libre y las
	marcas de pista por defecto y de comentario.

	El pre-flight ya descarga los primeros megas del enlace resuelto para medir
	la linea. La sonda se queda con los 2 primeros MB de esa misma descarga y
	los lee: CERO peticiones extra para el caso normal. Si el pre-flight esta
	apagado, pide ella sola 1 MB con Range.

	Casos raros que tambien cubre, con UNA peticion corta mas:
	  - MKV con Tracks mas alla de la cabecera descargada (se sigue la
	    SeekHead, que dice en que byte esta).
	  - MP4 con el indice (moov) al final: la cabecera del bloque de datos
	    (mdat) dice su tamano, y el moov empieza justo detras.

	v2.0.03: de la misma cabecera sale tambien el perfil de Dolby Vision. El
	TrackEntry del video (MKV) o su entrada de muestra (MP4) llevan el
	registro de configuracion de DV, que dice el perfil, la capa mejorada y
	la compatibilidad de la base (8.1 = HDR10, 8.4 = HLG) tal cual son en el
	fichero, sin depender de como lo escribiera quien lo empaqueto.

	Nada de esto puede romper la reproduccion: cualquier fallo deja un
	resultado 'unknown' y el flujo sigue como si el modulo no existiera.

	Parser propio en Python puro, sin dependencias: Kodi no trae ffprobe ni
	libmediainfo accesibles desde un addon.

	Lo leido se guarda por hash (y episodio) en source_ranker.db, tabla
	audio_tracks, para que la lista de fuentes pueda mostrar las pistas reales
	la proxima vez que aparezca ese torrent.
"""

import re
import ssl
import struct
import urllib.request as urllib2
from time import time as _now
from urllib.parse import parse_qsl

from resources.lib.modules import audio_langs
from resources.lib.modules import log_utils
from resources.lib.modules.control import setting as getSetting

# Cuanto de la descarga del pre-flight se conserva para leer la cabecera. En
# los MKV reales Tracks cae dentro de los primeros 10-100 KB; 2 MB deja margen
# para ficheros con adjuntos o capitulos gordos delante.
HEAD_KEEP = 2 * 1024 * 1024
# Lo que se pide cuando no hay descarga del pre-flight que aprovechar.
_OWN_HEAD = 1024 * 1024
# Lectura de un Tracks alejado (localizado por la SeekHead).
_SEEK_READ = 512 * 1024
# Tope del moov de un MP4. Una pelicula larga lo tiene de 2-8 MB por las
# tablas de muestras; por encima no compensa la espera.
_MOOV_MAX = 8 * 1024 * 1024
_TIMEOUT = 6
_NON_HTTP = ('plugin://', 'special://', 'magnet:', 'rtmp://', 'rtsp://', 'file://')

# Filas guardadas como maximo; se podan las mas viejas.
_DB_MAX_ROWS = 3000

# ── IDs EBML (Matroska) ────────────────────────────────────────────────────
EBML_HEADER = 0x1A45DFA3
SEGMENT = 0x18538067
SEEKHEAD = 0x114D9B74
SEEK = 0x4DBB
SEEK_ID = 0x53AB
SEEK_POS = 0x53AC
TRACKS = 0x1654AE6B
TRACK_ENTRY = 0xAE
CLUSTER = 0x1F43B675
T_NUMBER = 0xD7
T_TYPE = 0x83
T_DEFAULT = 0x88
T_FORCED = 0x55AA
T_HEARING = 0x55AB
T_VISUAL = 0x55AC
T_ORIGINAL = 0x55AE
T_COMMENTARY = 0x55AF
T_NAME = 0x536E
T_LANG = 0x22B59C
T_LANG_BCP = 0x22B59D
T_CODEC = 0x86
T_AUDIO = 0xE1
A_CHANNELS = 0x9F
# v2.0.03. Dolby Vision. mkvmerge, MakeMKV y ffmpeg escriben la configuracion
# de DV dentro del propio TrackEntry del video, en un BlockAdditionMapping
# cuyo tipo es 'dvcC' (perfiles hasta 7), 'dvvC' (8 a 10) o 'dvwC' (mas de
# 10), y cuyo ExtraData es el DOVIDecoderConfigurationRecord. Viaja en la
# misma cabecera que ya se descarga para el audio: cero peticiones extra.
T_BLKADD_MAP = 0x41E4
BA_TYPE = 0x41E7
BA_EXTRA = 0x41ED
_DOVI_TYPES = (0x64766343, 0x64767643, 0x64767743)  # dvcC, dvvC, dvwC
_DOVI_BOXES = ('dvcC', 'dvvC', 'dvwC')
# v2.0.03. Duracion real del fichero: Segment > Info > Duration, en unidades
# de TimestampScale (por defecto 1 ms). Junto al tamano exacto del fichero da
# el bitrate medio de verdad, el que de verdad tiene que aguantar la linea.
INFO = 0x1549A966
I_SCALE = 0x2AD7B1
I_DURATION = 0x4489
# v2.0.03. Bitrate de cada pista, el mismo reparto que Kodi 22 ensena en
# directo (video por un lado, audio por otro) pero leido antes de reproducir.
# mkvmerge escribe por pista las etiquetas de estadisticas BPS,
# NUMBER_OF_BYTES y DURATION en el elemento Tags, que deja AL FINAL del
# fichero (detras de los Cues) y apunta en la SeekHead del principio.
T_UID = 0x73C5
TAGS = 0x1254C367
TAG = 0x7373
TAG_TARGETS = 0x63C0
TAG_TRACK_UID = 0x63C5
SIMPLE_TAG = 0x67C8
TAG_NAME = 0x45A3
TAG_STRING = 0x4487
_TAGS_READ = 128 * 1024

_MKV_CODECS = (
	('A_EAC3', 'DD+'), ('A_AC3', 'DD'), ('A_TRUEHD', 'TRUE HD'), ('A_MLP', 'TRUE HD'),
	('A_DTS/LOSSLESS', 'DTS-HD MA'), ('A_DTS/EXPRESS', 'DTS-HD'), ('A_DTS', 'DTS'),
	('A_AAC', 'AAC'), ('A_OPUS', 'OPUS'), ('A_FLAC', 'FLAC'), ('A_VORBIS', 'VORBIS'),
	('A_MPEG/L3', 'MP3'), ('A_MPEG/L2', 'MP2'), ('A_PCM', 'PCM'), ('A_ALAC', 'ALAC'))
_MP4_CODECS = {
	'mp4a': 'AAC', 'ac-3': 'DD', 'ec-3': 'DD+', 'Opus': 'OPUS', 'fLaC': 'FLAC', 'dtsc': 'DTS',
	'dtsh': 'DTS-HD', 'dtsl': 'DTS-HD MA', 'dtse': 'DTS-HD', 'mlpa': 'TRUE HD', 'alac': 'ALAC',
	'.mp3': 'MP3', 'lpcm': 'PCM', 'sowt': 'PCM', 'twos': 'PCM'}
_LAYOUT = {1: '1.0', 2: '2.0', 3: '2.1', 6: '5.1', 7: '6.1', 8: '7.1'}

# Pistas que se reconocen por el nombre cuando el idioma es solo 'spa'.
_LAT_NAME = re.compile(r'latin|latam|mexic|hispanoam|es-?419|\blat\b', re.I)
_CAST_NAME = re.compile(r'castell|castil|espa[nñ]a|\bspain\b|europe|es-?es\b|\bcast\b', re.I)
_BR_NAME = re.compile(r'bra[sz]il|pt-?br', re.I)
_FRCA_NAME = re.compile(r'qu[eé]bec|canad|\bvfq\b|fr-?ca', re.I)
_COMMENT_NAME = re.compile(r'comment|comentario|commento|kommentar', re.I)
_AD_NAME = re.compile(r'descri|audio ?desc|\bad\b', re.I)


# ── ajustes ────────────────────────────────────────────────────────────────

def enabled():
	try:
		return getSetting('audio.probe.enabled') == 'true'
	except Exception:
		return False


def notify_mode():
	"""0 = mostrar las pistas, 1 = solo si falta el preferido, 2 = nunca.
	select de Kodi: devuelve el INDICE."""
	try:
		return int(getSetting('audio.probe.notify') or '0')
	except Exception:
		return 0


# ── lectura EBML ───────────────────────────────────────────────────────────

def _vint(buf, pos, keep_marker):
	"""Entero de longitud variable. Devuelve (valor, nueva_pos) o (None, pos)
	si no hay bytes suficientes. keep_marker=True para IDs (el ID incluye el
	bit de longitud), False para tamanos. Un tamano con todos los bits a 1 es
	'desconocido' y vuelve como -1."""
	if pos >= len(buf):
		return None, pos
	b = buf[pos]
	if b == 0:
		return None, pos
	length = 1
	mask = 0x80
	while not (b & mask):
		mask >>= 1
		length += 1
	if pos + length > len(buf):
		return None, pos
	val = b if keep_marker else (b & (mask - 1))
	all_ones = (b & (mask - 1)) == (mask - 1)
	for i in range(1, length):
		nb = buf[pos + i]
		val = (val << 8) | nb
		if nb != 0xFF:
			all_ones = False
	if not keep_marker and all_ones:
		return -1, pos + length
	return val, pos + length


def _elements(buf, start, end):
	"""Recorre los hijos de un elemento: (id, pos_datos, tamano). Se para en
	cuanto los bytes no alcanzan."""
	pos = start
	end = min(end, len(buf))
	while pos < end:
		eid, p = _vint(buf, pos, True)
		if eid is None:
			return
		size, p = _vint(buf, p, False)
		if size is None:
			return
		yield eid, p, size
		if size < 0:
			return
		pos = p + size


def _uint(buf, pos, size):
	v = 0
	for i in range(size):
		v = (v << 8) | buf[pos + i]
	return v


def _str(buf, pos, size):
	return bytes(buf[pos:pos + size]).split(b'\x00', 1)[0].decode('utf-8', 'ignore').strip()


def parse_dovi(rec):
	"""v2.0.03. DOVIDecoderConfigurationRecord (el contenido de dvcC/dvvC/dvwC)
	→ dict, o None si no da para leerlo. Disposicion de bits la de la
	especificacion de Dolby, la misma que lee ffmpeg en dovi_isom.c:

	  8 version mayor | 8 version menor | 7 perfil | 6 nivel | 1 RPU | 1 EL |
	  1 BL | 4 compatibilidad de la capa base | ...

	La compatibilidad es lo que el nombre del release llama '.1' o '.4': 1 es
	base HDR10, 2 base SDR, 4 base HLG, 6 base de Blu-ray UHD, 0 ninguna."""
	try:
		rec = bytes(rec or b'')
		if len(rec) < 4:
			return None
		bits = (rec[2] << 8) | rec[3]
		d = {'major': rec[0], 'minor': rec[1],
			'profile': (bits >> 9) & 0x7F, 'level': (bits >> 3) & 0x3F,
			'rpu': bool((bits >> 2) & 1), 'el': bool((bits >> 1) & 1), 'bl': bool(bits & 1),
			'compat': ((rec[4] >> 4) & 0x0F) if len(rec) >= 5 else 0}
		# Un registro a ceros no es ningun perfil: mejor nada que un DV-P0.
		if not (d['rpu'] or d['el'] or d['bl']):
			return None
		return d
	except Exception:
		return None


def dv_token(d):
	"""Registro leido → el mismo token que escribe la lectura del nombre
	(source_utils.dv_profile), para que la lista hable un solo idioma. El
	subperfil solo existe en los perfiles 8 y 10."""
	try:
		if not d:
			return ''
		p, c = int(d.get('profile')), int(d.get('compat') or 0)
		if p in (8, 10) and c in (1, 2, 4, 6):
			return 'DV-P%d.%d' % (p, c)
		return 'DV-P%d' % p
	except Exception:
		return ''


def _parse_block_mapping(buf, start, end):
	"""BlockAdditionMapping de un TrackEntry → registro DV o None."""
	btype, extra = None, None
	for eid, p, size in _elements(buf, start, end):
		if size < 0 or p + size > len(buf):
			break
		if eid == BA_TYPE: btype = _uint(buf, p, size)
		elif eid == BA_EXTRA: extra = bytes(buf[p:p + size])
	if btype in _DOVI_TYPES and extra:
		return parse_dovi(extra)
	return None


def _parse_track_entry(buf, start, end):
	t = {'type': 0, 'default': True, 'forced': False, 'commentary': False, 'ad': False,
	     'name': '', 'lang': 'eng', 'bcp': '', 'codec_id': '', 'channels': 0, 'dovi': None}
	for eid, p, size in _elements(buf, start, end):
		if size < 0 or p + size > len(buf):
			break
		if eid == T_TYPE: t['type'] = _uint(buf, p, size)
		elif eid == T_DEFAULT: t['default'] = bool(_uint(buf, p, size))
		elif eid == T_FORCED: t['forced'] = bool(_uint(buf, p, size))
		elif eid == T_COMMENTARY: t['commentary'] = bool(_uint(buf, p, size))
		elif eid == T_VISUAL: t['ad'] = bool(_uint(buf, p, size))
		elif eid == T_NAME: t['name'] = _str(buf, p, size)
		elif eid == T_LANG: t['lang'] = _str(buf, p, size) or 'eng'
		elif eid == T_LANG_BCP: t['bcp'] = _str(buf, p, size)
		elif eid == T_CODEC: t['codec_id'] = _str(buf, p, size)
		elif eid == T_UID: t['uid'] = _uint(buf, p, size)
		elif eid == T_AUDIO:
			for aid, ap, asz in _elements(buf, p, p + size):
				if asz < 0 or ap + asz > len(buf):
					break
				if aid == A_CHANNELS:
					t['channels'] = _uint(buf, ap, asz)
		elif eid == T_BLKADD_MAP and not t['dovi']:
			t['dovi'] = _parse_block_mapping(buf, p, p + size)
	return t


def _parse_tracks_body(buf, start, end):
	tracks = []
	for eid, p, size in _elements(buf, start, end):
		if size < 0 or p + size > len(buf):
			break
		if eid == TRACK_ENTRY:
			tracks.append(_parse_track_entry(buf, p, p + size))
	return tracks


def parse_mkv(buf):
	"""Devuelve {'tracks': [...]} si encontro Tracks, {'need': (offset, len)}
	si Tracks esta mas alla de lo descargado, o {} si no es un MKV legible."""
	try:
		eid, p = _vint(buf, 0, True)
		if eid != EBML_HEADER:
			return {}
		size, p = _vint(buf, p, False)
		if size is None or size < 0:
			return {}
		p += size
		eid, p = _vint(buf, p, True)
		if eid != SEGMENT:
			return {}
		size, seg_data = _vint(buf, p, False)
		if size is None:
			return {}
		seg_end = len(buf) if size < 0 else seg_data + size
		tracks_at = None
		found, duration = None, None
		tags, tags_at = None, None
		for eid, dp, sz in _elements(buf, seg_data, seg_end):
			if eid == INFO and sz >= 0 and dp + sz <= len(buf):
				duration = _parse_info(buf, dp, dp + sz)
			# v2.0.03: Tags dentro de la cabecera (ffmpeg los deja aqui).
			if eid == TAGS and sz >= 0 and dp + sz <= len(buf):
				tags = _parse_tags_body(buf, dp, dp + sz)
			if eid == TRACKS:
				if sz >= 0 and dp + sz <= len(buf):
					# v2.0.03: no se sale aun. Info suele ir delante, pero si
					# va detras se sigue mirando hasta el primer Cluster; y
					# v2.0.03: Tags tambien puede venir detras.
					found = _parse_tracks_body(buf, dp, dp + sz)
					continue
				# Empieza dentro pero no cabe: se pide desde su cabecera.
				return {'need': (_header_start(buf, seg_data, TRACKS), max(sz, 0) + 64), 'duration': duration,
					'tags': tags, 'tags_at': tags_at}
			if eid == SEEKHEAD and sz >= 0 and dp + sz <= len(buf):
				for sid, sp, ssz in _elements(buf, dp, dp + sz):
					if sid != SEEK or ssz < 0:
						continue
					target, where = None, None
					for kid, kp, ksz in _elements(buf, sp, sp + ssz):
						if ksz < 0 or kp + ksz > len(buf):
							break
						if kid == SEEK_ID:
							target = _uint(buf, kp, ksz)
						elif kid == SEEK_POS:
							where = _uint(buf, kp, ksz)
					if target == TRACKS and where is not None:
						tracks_at = seg_data + where
					elif target == TAGS and where is not None:
						tags_at = seg_data + where
			if eid == CLUSTER or sz < 0:
				break
		if tags is not None:
			tags_at = None  # ya leidos aqui, no hay que ir a buscarlos
		if found is not None:
			return {'tracks': found, 'duration': duration, 'tags': tags, 'tags_at': tags_at}
		if tracks_at is not None:
			return {'need': (tracks_at, _SEEK_READ), 'duration': duration, 'tags': tags, 'tags_at': tags_at}
		return {}
	except Exception:
		return {}


def _parse_tags_body(buf, start, end):
	"""v2.0.03. Hijos de Tags → {track_uid: {'BPS': '...', ...}}. Solo las
	etiquetas de estadisticas, que son las que dicen bytes y bitrate."""
	out = {}
	try:
		for eid, p, size in _elements(buf, start, end):
			if size < 0 or p + size > len(buf):
				break
			if eid != TAG:
				continue
			uids, vals = [], {}
			for tid, tp, tsz in _elements(buf, p, p + size):
				if tsz < 0 or tp + tsz > len(buf):
					break
				if tid == TAG_TARGETS:
					for gid, gp, gsz in _elements(buf, tp, tp + tsz):
						if gsz >= 0 and gp + gsz <= len(buf) and gid == TAG_TRACK_UID:
							uids.append(_uint(buf, gp, gsz))
				elif tid == SIMPLE_TAG:
					name = val = None
					for sid, sp, ssz in _elements(buf, tp, tp + tsz):
						if ssz < 0 or sp + ssz > len(buf):
							break
						if sid == TAG_NAME: name = _str(buf, sp, ssz).upper()
						elif sid == TAG_STRING: val = _str(buf, sp, ssz)
					if name in ('BPS', 'NUMBER_OF_BYTES', 'DURATION') and val:
						vals[name] = val
			for u in uids:
				if vals:
					out.setdefault(u, {}).update(vals)
	except Exception:
		pass
	return out


def parse_tags_element(buf):
	"""v2.0.03. Buffer que EMPIEZA en la cabecera de un Tags."""
	try:
		eid, p = _vint(buf, 0, True)
		if eid != TAGS:
			return {}
		size, p = _vint(buf, p, False)
		if size is None:
			return {}
		end = len(buf) if size < 0 else min(len(buf), p + size)
		return _parse_tags_body(buf, p, end)
	except Exception:
		return {}


def _tag_seconds(text):
	"""'01:58:03.123456789' → segundos."""
	try:
		h, m, sec = str(text).strip().split(':')
		return int(h) * 3600 + int(m) * 60 + float(sec)
	except Exception:
		return None


def _tag_bps(vals):
	"""Bitrate de una pista desde sus estadisticas: BPS si esta, si no
	NUMBER_OF_BYTES entre DURATION."""
	try:
		if vals.get('BPS') and str(vals['BPS']).strip().isdigit():
			return int(vals['BPS'])
		nb, d = vals.get('NUMBER_OF_BYTES'), _tag_seconds(vals.get('DURATION'))
		if nb and str(nb).strip().isdigit() and d and d > 0:
			return int(int(nb) * 8 / d)
	except Exception:
		pass
	return None


def apply_tags(tracks, tags):
	"""Cuelga 'bps' de cada pista cuyo UID aparece en las estadisticas."""
	if not tags:
		return tracks
	for t in tracks or ():
		vals = tags.get(t.get('uid'))
		if vals:
			b = _tag_bps(vals)
			if b:
				t['bps'] = b
	return tracks


def _parse_info(buf, start, end):
	"""v2.0.03. Segment > Info → duracion en segundos, o None."""
	try:
		scale, dur = 1000000, None
		for eid, p, size in _elements(buf, start, end):
			if size < 0 or p + size > len(buf):
				break
			if eid == I_SCALE and size:
				scale = _uint(buf, p, size) or 1000000
			elif eid == I_DURATION and size in (4, 8):
				dur = struct.unpack('>f' if size == 4 else '>d', bytes(buf[p:p + size]))[0]
		if dur and dur > 0:
			return dur * scale / 1e9
	except Exception:
		pass
	return None


def _header_start(buf, seg_data, wanted):
	"""Offset de la cabecera del hijo `wanted` del Segment."""
	pos = seg_data
	for eid, dp, sz in _elements(buf, seg_data, len(buf)):
		if eid == wanted:
			return pos
		if sz < 0:
			break
		pos = dp + sz
	return seg_data


def parse_tracks_element(buf):
	"""Lee un buffer que EMPIEZA en la cabecera de un elemento Tracks."""
	try:
		eid, p = _vint(buf, 0, True)
		if eid != TRACKS:
			return []
		size, p = _vint(buf, p, False)
		if size is None:
			return []
		end = len(buf) if size < 0 else min(len(buf), p + size)
		return _parse_tracks_body(buf, p, end)
	except Exception:
		return []


# ── lectura MP4 ────────────────────────────────────────────────────────────

def _boxes(buf, start, end):
	pos = start
	end = min(end, len(buf))
	while pos + 8 <= end:
		size, btype = struct.unpack('>I4s', bytes(buf[pos:pos + 8]))
		hdr = 8
		if size == 1:
			if pos + 16 > len(buf):
				return
			size = struct.unpack('>Q', bytes(buf[pos + 8:pos + 16]))[0]
			hdr = 16
		elif size == 0:
			size = end - pos
		if size < hdr:
			return
		yield btype.decode('latin-1'), pos, pos + hdr, pos + size
		pos += size


def _mp4_lang(packed):
	if not packed or packed == 0x7FFF:
		return 'und'
	return ''.join(chr(((packed >> s) & 0x1F) + 0x60) for s in (10, 5, 0))


# v2.0.03. Una VisualSampleEntry lleva 78 bytes fijos tras su cabecera de 8
# (ISO 14496-12, 12.1.3) antes de sus cajas hijas, que es donde va dvcC/dvvC.
_VISUAL_ENTRY_FIXED = 8 + 78
_VIDEO_ENTRIES = ('dvh1', 'dvhe', 'hvc1', 'hev1', 'avc1', 'avc3', 'dvav', 'dva1', 'av01', 'dav1', 'encv')


def _sample_entry_dovi(buf, entry):
	"""Busca dvcC/dvvC/dvwC entre las hijas de la entrada de muestra que
	empieza en `entry` (su campo de tamano)."""
	try:
		if entry + _VISUAL_ENTRY_FIXED > len(buf):
			return None
		size = _uint(buf, entry, 4)
		end = min(entry + size, len(buf)) if size >= _VISUAL_ENTRY_FIXED else len(buf)
		for ct, cpos, cdp, cend in _boxes(buf, entry + _VISUAL_ENTRY_FIXED, end):
			if ct in _DOVI_BOXES and cend <= len(buf):
				return parse_dovi(buf[cdp:cend])
	except Exception:
		pass
	return None


def _parse_trak(buf, start, end):
	t = {'type': 0, 'default': True, 'forced': False, 'commentary': False, 'ad': False,
	     'name': '', 'lang': 'und', 'bcp': '', 'codec_id': '', 'channels': 0, 'dovi': None}
	for btype, bpos, dpos, bend in _boxes(buf, start, end):
		if btype == 'tkhd' and dpos + 4 <= len(buf):
			flags = _uint(buf, dpos + 1, 3)
			t['default'] = bool(flags & 1)
		elif btype == 'mdia':
			for mt, mpos, mdp, mend in _boxes(buf, dpos, bend):
				if mt == 'mdhd' and mdp + 1 <= len(buf):
					off = mdp + (32 if buf[mdp] == 1 else 20)
					if off + 2 <= len(buf):
						t['lang'] = _mp4_lang(_uint(buf, off, 2))
					# v2.0.03: escala y duracion de la pista, para su bitrate.
					try:
						if buf[mdp] == 1 and mdp + 32 <= len(buf):
							t['_ts'], t['_dur'] = _uint(buf, mdp + 20, 4), _uint(buf, mdp + 24, 8)
						elif mdp + 20 <= len(buf):
							t['_ts'], t['_dur'] = _uint(buf, mdp + 12, 4), _uint(buf, mdp + 16, 4)
					except Exception:
						pass
				elif mt == 'elng':
					t['bcp'] = _str(buf, mdp + 4, mend - mdp - 4)
				elif mt == 'hdlr' and mdp + 24 <= len(buf):
					handler = bytes(buf[mdp + 8:mdp + 12]).decode('latin-1')
					t['type'] = {'vide': 1, 'soun': 2, 'subt': 17, 'sbtl': 17, 'text': 17}.get(handler, 0)
					t['name'] = _str(buf, mdp + 24, mend - mdp - 24)
				elif mt == 'minf':
					for nt, npos, ndp, nend in _boxes(buf, mdp, mend):
						if nt != 'stbl':
							continue
						for st, spos, sdp, send in _boxes(buf, ndp, nend):
							if st == 'stsz' and send <= len(buf):
								t['_bytes'] = _stsz_total(buf, sdp, send)
								continue
							if st != 'stsd' or sdp + 16 > len(buf):
								continue
							entry = sdp + 8
							fmt = bytes(buf[entry + 4:entry + 8]).decode('latin-1')
							t['codec_id'] = fmt
							if fmt not in ('ac-3', 'ec-3') and entry + 26 <= len(buf):
								t['channels'] = _uint(buf, entry + 24, 2)
							# v2.0.03. Por el codigo de la entrada y no por el
							# hdlr, que puede venir detras de minf.
							if not t['dovi'] and fmt in _VIDEO_ENTRIES:
								t['dovi'] = _sample_entry_dovi(buf, entry)
	# v2.0.03: bitrate exacto de la pista = sus bytes (tabla stsz) entre su
	# duracion (mdhd). En un MP4 sale gratis: todo esta ya en el moov.
	try:
		if t.get('_bytes') and t.get('_ts') and t.get('_dur'):
			secs = float(t['_dur']) / t['_ts']
			if secs >= 1:
				t['bps'] = int(t['_bytes'] * 8 / secs)
	except Exception:
		pass
	return t


def _stsz_total(buf, start, end):
	"""Suma de los tamanos de todas las muestras de una pista (caja stsz)."""
	try:
		if start + 12 > len(buf):
			return 0
		size, count = _uint(buf, start + 4, 4), _uint(buf, start + 8, 4)
		if size:
			return size * count
		first, last = start + 12, min(end, start + 12 + 4 * count, len(buf))
		n = (last - first) // 4
		if n <= 0:
			return 0
		return sum(struct.unpack('>%dI' % n, bytes(buf[first:first + 4 * n])))
	except Exception:
		return 0


def _mvhd_duration(buf, start, end):
	"""v2.0.03. moov > mvhd → duracion en segundos, o None. Un MP4
	fragmentado deja aqui 0 y se queda sin cifra: mejor nada que un invento."""
	try:
		for btype, bpos, dpos, bend in _boxes(buf, start, end):
			if btype != 'mvhd' or bend > len(buf):
				continue
			if buf[dpos] == 1:
				scale, dur = _uint(buf, dpos + 20, 4), _uint(buf, dpos + 24, 8)
				bad = 0xFFFFFFFFFFFFFFFF
			else:
				scale, dur = _uint(buf, dpos + 12, 4), _uint(buf, dpos + 16, 4)
				bad = 0xFFFFFFFF
			if scale and dur and dur != bad:
				return float(dur) / scale
			return None
	except Exception:
		pass
	return None


def parse_mp4(buf, base=0):
	"""{'tracks': [...]} si el moov esta en el buffer, {'need': (off, len)} si
	esta detras del mdat, {} si no es MP4."""
	try:
		if len(buf) < 12 or bytes(buf[4:8]) not in (b'ftyp', b'moov', b'free', b'skip', b'wide'):
			return {}
		after_mdat = None
		for btype, bpos, dpos, bend in _boxes(buf, 0, len(buf) + (1 << 62)):
			if btype == 'moov':
				if bend <= len(buf):
					tracks = [_parse_trak(buf, d, e) for bt, bp, d, e in _boxes(buf, dpos, bend) if bt == 'trak']
					return {'tracks': tracks, 'duration': _mvhd_duration(buf, dpos, bend)}
				return {'need': (base + bpos, min(bend - bpos, _MOOV_MAX))}
			if btype == 'mdat':
				after_mdat = base + bend
			if bend > len(buf):
				break
		if after_mdat is not None:
			return {'need': (after_mdat, 64 * 1024), 'probe_moov': True}
		return {}
	except Exception:
		return {}


def parse_moov_at(buf):
	"""Buffer que EMPIEZA en la cabecera de un box. Si es el moov y esta
	entero, lo lee; si es el moov y falta, dice cuanto pedir."""
	try:
		for btype, bpos, dpos, bend in _boxes(buf, 0, 1 << 62):
			if btype == 'moov':
				if bend <= len(buf):
					return {'tracks': [_parse_trak(buf, d, e) for bt, bp, d, e in _boxes(buf, dpos, bend) if bt == 'trak'],
						'duration': _mvhd_duration(buf, dpos, bend)}
				# Longitud a pedir contando desde el principio del buffer.
				return {'more': bend}
			# Relleno entre el mdat y el moov: se salta si cabe entero.
			if btype in ('free', 'skip', 'wide', 'uuid') and bend <= len(buf):
				continue
			return {}
		return {}
	except Exception:
		return {}


# ── red ────────────────────────────────────────────────────────────────────

def total_size(resp):
	"""v2.0.03. Tamano exacto del fichero segun el servidor, o 0.

	Con Range la respuesta es 206 y Content-Range trae el total detras de la
	barra ('bytes 0-1048575/48318382080'). Un 200 manda el fichero entero y su
	Content-Length es el total. Es el tamano del fichero que se va a
	reproducir, no el del torrent ni el del pack que anuncia el scraper."""
	try:
		cr = resp.headers.get('Content-Range') or ''
		if '/' in cr:
			tail = cr.rsplit('/', 1)[1].strip()
			if tail.isdigit():
				return int(tail)
		code = int(resp.getcode() or 200)
		if code == 200:
			cl = resp.headers.get('Content-Length') or ''
			if str(cl).strip().isdigit():
				return int(cl)
	except Exception:
		pass
	return 0


def real_mbps(file_bytes, seconds):
	"""v2.0.03. Bitrate medio REAL del fichero, en Mbps: tamano exacto entre
	duracion real. Es la media de todas las pistas juntas, que es lo que baja
	por la linea. Fuera de lo creible (duraciones de menos de 30 s, cifras
	por encima de 1000 Mbps) devuelve None antes que una cifra rara."""
	try:
		b, d = float(file_bytes or 0), float(seconds or 0)
		if b <= 0 or d < 30:
			return None
		mbps = b * 8.0 / d / 1000000.0
		if not (0.05 <= mbps <= 1000.0):
			return None
		return round(mbps, 1)
	except Exception:
		return None


def duration_from_head(head):
	"""v2.0.03. Duracion leida de la cabecera ya descargada, sin red. La usa
	el pre-flight para su veredicto. None si no esta en esos bytes (MP4 con
	el indice al final): entonces el veredicto sigue con la estimacion."""
	try:
		if not head:
			return None
		d = parse_mkv(head).get('duration')
		if d is None:
			d = parse_mp4(head).get('duration')
		return d
	except Exception:
		return None


def _fetch(url, start, length, info=None):
	"""GET con Range. Devuelve bytes o b''. Respeta la sintaxis de cabeceras
	de Kodi (url|H=V), como el pre-flight. v2.0.03: con `info` (dict) apunta
	ahi el tamano total del fichero."""
	resp = None
	try:
		clean_url, hdrs = url, {}
		if '|' in url:
			clean_url, qs = url.split('|', 1)
			try:
				hdrs.update(dict(parse_qsl(qs)))
			except Exception:
				pass
		hdrs.setdefault('User-Agent', 'Mozilla/5.0')
		hdrs['Range'] = 'bytes=%d-%d' % (start, start + length - 1)
		req = urllib2.Request(clean_url, headers=hdrs)
		try:
			ctx = ssl._create_unverified_context()
		except Exception:
			ctx = None
		resp = urllib2.urlopen(req, timeout=_TIMEOUT, context=ctx)
		code = int(resp.getcode() or 200)
		if info is not None:
			info['total'] = total_size(resp)
		# Un servidor que ignora Range y devuelve 200 manda el fichero desde
		# el byte 0: solo vale si lo que se pedia era justo el principio.
		if code == 200 and start > 0:
			return b''
		out = bytearray()
		t0 = _now()
		while len(out) < length and (_now() - t0) < _TIMEOUT:
			chunk = resp.read(min(256 * 1024, length - len(out)))
			if not chunk:
				break
			out += chunk
		return bytes(out)
	except Exception:
		return b''
	finally:
		try:
			if resp is not None:
				resp.close()
		except Exception:
			pass


# ── de pistas crudas a codigos ─────────────────────────────────────────────

def _codec_label(codec_id):
	if not codec_id:
		return ''
	for prefix, label in _MKV_CODECS:
		if codec_id.startswith(prefix):
			return label
	return _MP4_CODECS.get(codec_id, codec_id.replace('A_', ''))


UNTAGGED = 'UND'  # v1.0.91: pistas de audio sin idioma declarado


def track_code(t):
	"""Codigo de fila de una pista (CAST, LAT, ES, EN...) o None."""
	name = t.get('name') or ''
	code = None
	if t.get('bcp'):
		code = audio_langs.bcp_to_code(t['bcp'])
	if not code:
		lang = (t.get('lang') or '').lower()
		if lang and lang not in ('und', 'mis', 'zxx', 'mul'):
			code = audio_langs.ISO3.get(lang) or audio_langs.ISO2.get(lang)
	if not code and name:
		# Sin idioma declarado: el nombre ('Castellano', 'English') lo dice.
		found, _m = audio_langs.from_name_info(name.lower())
		code = found[0] if found else None
	if code == 'ES' and name:
		if _LAT_NAME.search(name): code = 'LAT'
		elif _CAST_NAME.search(name): code = 'CAST'
	elif code == 'PT' and name and _BR_NAME.search(name):
		code = 'PT-BR'
	elif code == 'FR' and name and _FRCA_NAME.search(name):
		code = 'FR-CA'
	return code


def summarize(tracks):
	"""Pistas crudas → resultado legible."""
	audio, subs = [], []
	for t in tracks or ():
		if t.get('type') == 2:
			name = t.get('name') or ''
			commentary = bool(t.get('commentary')) or bool(_COMMENT_NAME.search(name))
			ad = bool(t.get('ad')) or (bool(_AD_NAME.search(name)) and not commentary)
			audio.append({
				'code': track_code(t), 'codec': _codec_label(t.get('codec_id')),
				'channels': _LAYOUT.get(t.get('channels') or 0, str(t.get('channels') or '')),
				'name': name[:40], 'default': bool(t.get('default')),
				'commentary': commentary, 'ad': ad,
				# v2.0.03: bitrate de la pista, si el fichero lo dice.
				'kbps': int(round(t['bps'] / 1000.0)) if t.get('bps') else None})
		elif t.get('type') == 17:
			c = track_code(t)
			if c and c not in subs:
				subs.append(c)
	langs = []
	for a in audio:
		if a['code'] and not a['commentary'] and not a['ad'] and a['code'] not in langs:
			langs.append(a['code'])
	if 'ES' in langs and ('CAST' in langs or 'LAT' in langs):
		# Tres pistas 'spa' de las que dos tienen nombre: la tercera sigue
		# siendo espanol sin variante, y asi se queda. Solo se quita si es la
		# MISMA informacion, o sea si no hay ninguna pista ES propia.
		if not any(a['code'] == 'ES' and not a['commentary'] and not a['ad'] for a in audio):
			langs.remove('ES')
	# v2.0.03. Dolby Vision: el registro de la primera pista de video que lo
	# lleve. Su AUSENCIA no dice nada: hay remuxes viejos con DV dentro del
	# flujo y sin el registro en la cabecera, asi que no se apunta 'sin DV'.
	dv, dv_rec = '', None
	for t in tracks or ():
		if t.get('type') == 1 and t.get('dovi'):
			dv_rec = t['dovi']
			dv = dv_token(dv_rec)
			break
	# v2.0.03. Bitrate del video (todas sus pistas: un P7 de doble pista
	# suma las dos) y del audio que sonara: la pista por defecto, o la
	# primera si ninguna lo es. Es el reparto que Kodi 22 ensena en directo.
	video_bps = sum(t.get('bps') or 0 for t in tracks or () if t.get('type') == 1)
	play = [a for a in audio if a.get('default') and not a.get('commentary')] or audio
	return {'audio': audio, 'langs': langs, 'subs': subs, 'dv': dv, 'dv_rec': dv_rec,
		'video_mbps': round(video_bps / 1e6, 1) if video_bps else None,
		'audio_kbps': play[0].get('kbps') if play else None}


# ── orquestacion ───────────────────────────────────────────────────────────

def read(url, head=None, file_bytes=None):
	"""Lee las pistas del enlace. Devuelve dict con 'container', 'audio',
	'langs', 'subs', 'reason' y 'requests' (peticiones extra hechas).
	v2.0.03: tambien 'duration' (s), 'file_bytes' y 'mbps', el bitrate medio
	real. file_bytes lo trae el pre-flight; sin el, sale de la propia peticion."""
	out = {'container': '', 'audio': [], 'langs': [], 'subs': [], 'dv': '', 'dv_rec': None,
		'duration': None, 'file_bytes': int(file_bytes or 0), 'mbps': None,
		'reason': '', 'requests': 0}
	try:
		if not url or str(url).lower().startswith(_NON_HTTP):
			out['reason'] = 'not_http'
			return out
		if not head:
			_info = {}
			head = _fetch(url, 0, _OWN_HEAD, _info)
			out['requests'] += 1
			if not out['file_bytes']:
				out['file_bytes'] = int(_info.get('total') or 0)
		if not head:
			out['reason'] = 'no_data'
			return out
		if head[:7] == b'#EXTM3U':
			out['reason'] = 'hls'
			return out
		res = parse_mkv(head)
		if res:
			out['container'] = 'mkv'
			_set_rate(out, res.get('duration'))
			if 'need' in res:
				off, ln = res['need']
				extra = _fetch_fill(out, url, off, ln)
				out['requests'] += 1
				tracks = parse_tracks_element(extra)
			else:
				tracks = res.get('tracks') or []
			# v2.0.03: estadisticas por pista. Si van en la cabecera se usan
			# ya; si van al final (mkvmerge) se apunta donde, y after_resolve
			# las lee en segundo plano cuando el video ya esta sonando.
			if res.get('tags'):
				apply_tags(tracks, res['tags'])
			elif res.get('tags_at'):
				out['tags_at'] = res['tags_at']
				out['_tracks'] = tracks
		else:
			res = parse_mp4(head)
			if not res:
				out['reason'] = 'unknown_container'
				return out
			out['container'] = 'mp4'
			tracks = res.get('tracks')
			_set_rate(out, res.get('duration'))
			if tracks is None and 'need' in res:
				off, ln = res['need']
				extra = _fetch_fill(out, url, off, ln)
				out['requests'] += 1
				moov = parse_moov_at(extra)
				if 'more' in moov and moov['more'] <= _MOOV_MAX:
					extra = _fetch_fill(out, url, off, moov['more'])
					out['requests'] += 1
					moov = parse_moov_at(extra)
				tracks = moov.get('tracks') or []
				_set_rate(out, moov.get('duration'))
		if not tracks:
			out['reason'] = 'no_tracks'
			return out
		out.update(summarize(tracks))
		if not out['audio']:
			out['reason'] = 'no_audio'
		return out
	except Exception:
		out['reason'] = 'error'
		return out


def _set_rate(out, duration):
	"""v2.0.03. Apunta duracion y bitrate real en cuanto hay duracion."""
	if duration and not out.get('duration'):
		out['duration'] = round(float(duration), 1)
	if out.get('duration') and not out.get('mbps'):
		out['mbps'] = real_mbps(out.get('file_bytes'), out['duration'])


def _fetch_fill(out, url, start, length):
	"""_fetch que, si aun no se sabe el tamano del fichero, lo toma de esta
	respuesta y recalcula el bitrate."""
	info = {}
	data = _fetch(url, start, length, info)
	if not out.get('file_bytes') and info.get('total'):
		out['file_bytes'] = int(info['total'])
		_set_rate(out, None)
	return data


def describe(result):
	"""Linea del log. Sin URL."""
	try:
		parts = []
		for a in result.get('audio') or ():
			bits = [a.get('code') or '?']
			if a.get('codec'): bits.append(a['codec'])
			if a.get('channels'): bits.append(a['channels'])
			if a.get('kbps'): bits.append('%dkbps' % a['kbps'])
			if a.get('name'): bits.append('"%s"' % a['name'])
			if a.get('default'): bits.append('default')
			if a.get('commentary'): bits.append('commentary')
			if a.get('ad'): bits.append('audio-description')
			parts.append(' '.join(bits))
		rate = ''
		if result.get('video_mbps'):
			rate += ' video=%.1f Mbps' % result['video_mbps']
		if result.get('duration'):
			rate = ' bitrate=%s duration=%ds size=%s' % (
				('%.1f Mbps' % result['mbps']) if result.get('mbps') else 'n/a',
				int(result['duration']),
				('%.2fGB' % (result['file_bytes'] / 1073741824.0)) if result.get('file_bytes') else 'n/a')
		return '[AUDIOPROBE] container=%s tracks=%d requests=%d audio=[%s] subs=[%s]%s%s%s' % (
			result.get('container') or '?', len(result.get('audio') or ()), result.get('requests') or 0,
			' | '.join(parts), ','.join(result.get('subs') or ()), _describe_dv(result), rate,
			(' (%s)' % result['reason']) if result.get('reason') else '')
	except Exception:
		return '[AUDIOPROBE] (unprintable result)'


def _describe_dv(result):
	"""v2.0.03. ' video=[DV-P8.1 L06 BL+RPU v1.0]' o '' si no hay registro."""
	try:
		d = result.get('dv_rec')
		if not d or not result.get('dv'):
			return ''
		layers = '+'.join(n for n, on in (('BL', d.get('bl')), ('EL', d.get('el')), ('RPU', d.get('rpu'))) if on)
		return ' video=[%s L%02d %s v%d.%d]' % (result['dv'], int(d.get('level') or 0), layers,
			int(d.get('major') or 0), int(d.get('minor') or 0))
	except Exception:
		return ''


def key_for(item, meta):
	"""Clave de cache: hash, mas el episodio cuando lo hay. Un pack tiene un
	hash para muchos ficheros y cada uno puede traer pistas distintas."""
	try:
		h = str((item or {}).get('hash') or '').lower().strip()
		if not h or len(h) < 32:
			return None
		meta = meta or {}
		season, episode = meta.get('season'), meta.get('episode')
		if season not in (None, '') and episode not in (None, ''):
			return '%s:s%02de%02d' % (h, int(season), int(episode))
		return h
	except Exception:
		return None


def after_resolve(url, item, meta, head=None, file_bytes=None):
	"""Punto de entrada desde sources.py, con el enlace ya resuelto y el
	pre-flight ya pasado. Lee, registra, guarda y devuelve el resultado.
	v2.0.03: file_bytes es el tamano exacto que el pre-flight leyo del
	servidor; con la duracion de la cabecera da el bitrate real."""
	result = read(url, head, file_bytes)
	try:
		log_utils.log(describe(result), level=log_utils.LOGINFO)
	except Exception:
		pass
	if result.get('langs'):
		store(key_for(item, meta), result)
	elif result.get('audio'):
		# v1.0.91: hay pistas de audio pero ninguna dice su idioma (MP4 de
		# YTS: 'und'). Se guarda la marca UND para que la lista deje de
		# ensenar lo que declaraban las banderas (que eran subtitulos) y
		# diga la verdad: audio sin idioma declarado.
		store(key_for(item, meta), dict(result, langs=[UNTAGGED]))
	key = key_for(item, meta)
	if result.get('dv') or result.get('mbps') or result.get('video_mbps'):
		# v2.0.03. Perfil DV, bitrate real del fichero y el de
		# cada pista: a la cache, para que la lista los ensene la proxima vez.
		update_facts(key, dv=result.get('dv') or None, mbps=result.get('mbps'),
			video_mbps=result.get('video_mbps'), audio_kbps=result.get('audio_kbps'))
	# v2.0.03. Lo que la sonda sabe del fichero queda a mano del monitor de
	# Kodi 22 (playback_stats), que lo compara con lo que mide en directo.
	publish_expect(key, result)
	if result.get('tags_at') and result.get('_tracks'):
		start_late_tags(url, key, result)
	if result.get('dv'):
		# La linea de info de esta misma reproduccion, que
		# release_info.remember() ya monto con lo que decia el nombre antes
		# de resolver, pasa a decir lo que hay en el fichero.
		try:
			from resources.lib.modules import release_info
			release_info.override_dv(result['dv'])
		except Exception:
			pass
	return result


# ── v2.0.03: estadisticas del final del fichero, en segundo plano ──────────

EXPECT_PROP = 'luc_kodi.probe.expect'
_LATE_TAGS_DELAY = 8  # segundos: que el reproductor llene antes su cache


def publish_expect(key, result):
	try:
		import json
		from resources.lib.modules import control
		control.homeWindow.setProperty(EXPECT_PROP, json.dumps({
			'key': key or '', 'mbps': result.get('mbps'),
			'video_mbps': result.get('video_mbps'), 'audio_kbps': result.get('audio_kbps'),
			'ts': int(_now())}))
	except Exception:
		pass


def read_expect():
	try:
		import json
		from resources.lib.modules import control
		return json.loads(control.homeWindow.getProperty(EXPECT_PROP) or '{}')
	except Exception:
		return {}


def late_tags(url, key, result, delay=_LATE_TAGS_DELAY):
	"""mkvmerge deja las estadisticas por pista al final del fichero. Pedirlas
	antes de reproducir costaria una peticion mas en el momento en que el
	usuario espera, y el reparto video/audio no decide nada: es un dato. Se
	piden con el video ya sonando, tras dejar al reproductor llenar su cache.
	Una peticion de como mucho 128 KB."""
	try:
		if delay:
			from resources.lib.modules import control
			if control.monitor.waitForAbort(delay):
				return None
		data = _fetch(url, result['tags_at'], _TAGS_READ)
		tags = parse_tags_element(data)
		if not tags:
			log_utils.log('[AUDIOPROBE] tags: none at the end of the file', level=log_utils.LOGINFO)
			return None
		tracks = apply_tags(result.get('_tracks') or [], tags)
		s2 = summarize(tracks)
		parts = ['%s %dkbps' % (a.get('code') or '?', a['kbps']) for a in s2['audio'] if a.get('kbps')]
		log_utils.log('[AUDIOPROBE] tags: video=%s audio=[%s]' % (
			('%.1f Mbps' % s2['video_mbps']) if s2.get('video_mbps') else 'n/a', ' | '.join(parts)),
			level=log_utils.LOGINFO)
		update_facts(key, video_mbps=s2.get('video_mbps'), audio_kbps=s2.get('audio_kbps'))
		exp = read_expect()
		if exp.get('key') == (key or ''):
			exp.update(video_mbps=s2.get('video_mbps'), audio_kbps=s2.get('audio_kbps'))
			import json
			from resources.lib.modules import control
			control.homeWindow.setProperty(EXPECT_PROP, json.dumps(exp))
		return s2
	except Exception:
		return None


def start_late_tags(url, key, result):
	try:
		import threading
		th = threading.Thread(target=late_tags, args=(url, key, result))
		th.daemon = True
		th.start()
	except Exception:
		pass


def announce(result, autoplay_label=False):
	"""Aviso al usuario. Con autoplay_label=True no notifica: devuelve el
	texto para colgarlo de la ventana de autoplay, que ya se esta mostrando.
	El aviso de 'falta tu idioma' sale siempre que el modo no sea 'nunca'."""
	try:
		langs = result.get('langs') or []
		# v2.0.03. El perfil de Dolby Vision leido del fichero va en el mismo
		# aviso, detras de los idiomas: es la otra cosa que el nombre puede
		# decir mal y que solo la cabecera confirma.
		dv = result.get('dv') or ''
		# v2.0.03. El bitrate medio real, la cifra que de verdad pide el
		# fichero. Va siempre detras: es el dato tecnico, no el de idioma.
		mbps = result.get('mbps')
		rate = (control_lang_rate(mbps)) if mbps else ''
		if not langs and not dv and not rate:
			return ''
		mode = notify_mode()
		if mode == 2:
			return ''
		from resources.lib.modules import control
		pref = audio_langs.preferred()
		text = ' [B]\u00b7[/B] '.join(audio_langs.ordered(langs, pref))
		for extra in (dv, rate):
			if extra:
				text = ('%s  |  %s' % (text, extra)) if text else extra
		title = control.lang(400925) if (dv or rate) else control.lang(400809)
		# Solo se avisa cuando NINGUNA pista puede ser la pedida. Una pista
		# 'spa' sin variante cuando se pide castellano no se da por buena,
		# pero tampoco se denuncia: puede serlo y no hay forma de saberlo.
		missing = bool(pref) and bool(langs) and not any(audio_langs.matches(c, pref) for c in langs)
		if missing:
			control.notification(
				title=title,
				message=(control.lang(400810) % _pref_label()) + '  ' + text,
				icon='WARNING', time=6000)
			return text if autoplay_label else ''
		if autoplay_label:
			return text if mode == 0 else ''
		if mode == 0:
			control.notification(title=title, message=text, time=4000)
		return ''
	except Exception:
		return ''


def fmt_mbps(mbps):
	"""'58' o '4.7'. Entero desde 10 Mbps, donde el decimal no cambia ninguna
	decision; por debajo, con uno, porque entre 0 y 9 el entero se come la
	cifra (un 720p de 2,6 Mbps no es un '2')."""
	try:
		v = float(mbps)
		return ('%d' % int(v)) if v >= 10 else ('%.1f' % v)
	except Exception:
		return ''


def control_lang_rate(mbps):
	"""'58 Mbps average'."""
	try:
		from resources.lib.modules import control
		return control.lang(400926) % fmt_mbps(mbps)
	except Exception:
		return ''


def _pref_label():
	"""El nombre del idioma preferido tal como sale en los ajustes."""
	try:
		from resources.lib.modules import control
		idx = int(getSetting('audio.langs.preferred') or '0')
		return control.lang(audio_langs.PREFERRED_LABEL_BASE + idx)
	except Exception:
		return ''


# ── cache en source_ranker.db ──────────────────────────────────────────────

def _connect():
	from resources.lib.database import source_ranker
	con = source_ranker._connect()
	con.execute('''
		CREATE TABLE IF NOT EXISTS audio_tracks (
			key     TEXT PRIMARY KEY,
			langs   TEXT NOT NULL,
			detail  TEXT,
			ts      INTEGER NOT NULL
		)
	''')
	return con


def store(key, result):
	if not key:
		return
	con = None
	try:
		con = _connect()
		con.execute('INSERT OR REPLACE INTO audio_tracks (key, langs, detail, ts) VALUES (?, ?, ?, ?)',
			(key, ','.join(result.get('langs') or ()), describe(result)[:500], int(_now())))
		con.execute('DELETE FROM audio_tracks WHERE key NOT IN '
			'(SELECT key FROM audio_tracks ORDER BY ts DESC LIMIT ?)', (_DB_MAX_ROWS,))
		con.commit()
	except Exception:
		log_utils.error()
	finally:
		try:
			if con is not None: con.close()
		except Exception:
			pass


def known(keys):
	"""{clave: [codigos]} de las que ya se sondearon. Una sola consulta para
	toda la lista de fuentes."""
	found = {}
	keys = [k for k in set(keys or ()) if k]
	if not keys:
		return found
	con = None
	try:
		con = _connect()
		for i in range(0, len(keys), 500):
			chunk = keys[i:i + 500]
			q = 'SELECT key, langs FROM audio_tracks WHERE key IN (%s)' % ','.join('?' * len(chunk))
			for row in con.execute(q, chunk).fetchall():
				found[row[0]] = [c for c in (row[1] or '').split(',') if c]
	except Exception:
		pass
	finally:
		try:
			if con is not None: con.close()
		except Exception:
			pass
	return found


# v2.0.03. Lo leido del fichero que no es audio (perfil Dolby Vision,
# bitrate real, bitrate por pista y lo medido en directo por Kodi 22), en su
# propia tabla: audio_tracks ya existe en las bases de los usuarios con su
# forma, y CREATE TABLE IF NOT EXISTS no le anade columnas. Por lo mismo, si
# video_tracks ya existe con menos columnas, cada una que falte se anade aqui
# en vez de dar por hecha su forma.
_FACT_COLS = (('mbps', 'REAL'), ('video_mbps', 'REAL'), ('audio_kbps', 'REAL'),
	('live_video_mbps', 'REAL'), ('live_audio_kbps', 'REAL'),
	('live_low_queue', 'REAL'), ('live_samples', 'INTEGER'))


def _connect_dv():
	con = _connect()
	con.execute('''
		CREATE TABLE IF NOT EXISTS video_tracks (
			key     TEXT PRIMARY KEY,
			dv      TEXT NOT NULL,
			mbps    REAL,
			ts      INTEGER NOT NULL
		)
	''')
	try:
		cols = [r[1] for r in con.execute('PRAGMA table_info(video_tracks)').fetchall()]
		for name, kind in _FACT_COLS:
			if name not in cols:
				con.execute('ALTER TABLE video_tracks ADD COLUMN %s %s' % (name, kind))
	except Exception:
		pass
	return con


def store_facts(key, token, mbps=None):
	update_facts(key, dv=token or None, mbps=mbps)


def update_facts(key, **vals):
	"""Escribe solo las columnas que llegan con valor: lo que ya se sabia de
	esa clave (el DV de una reproduccion, el directo de otra) se conserva."""
	vals = dict((k, v) for k, v in vals.items() if v not in (None, '') and
		(k == 'dv' or k in dict(_FACT_COLS)))
	if not key or not vals:
		return
	con = None
	try:
		con = _connect_dv()
		now = int(_now())
		con.execute("INSERT OR IGNORE INTO video_tracks (key, dv, ts) VALUES (?, '', ?)", (key, now))
		cols = sorted(vals)
		con.execute('UPDATE video_tracks SET %s, ts = ? WHERE key = ?' % ', '.join('%s = ?' % c for c in cols),
			[vals[c] for c in cols] + [now, key])
		con.execute('DELETE FROM video_tracks WHERE key NOT IN '
			'(SELECT key FROM video_tracks ORDER BY ts DESC LIMIT ?)', (_DB_MAX_ROWS,))
		con.commit()
	except Exception:
		log_utils.error()
	finally:
		try:
			if con is not None: con.close()
		except Exception:
			pass


def known_dv(keys):
	"""{clave: 'DV-P8.1'} de las ya sondeadas con registro DV."""
	return dict((k, v['dv']) for k, v in known_facts(keys).items() if v.get('dv'))


def known_facts(keys):
	"""{clave: {'dv': 'DV-P8.1' o '', 'mbps': 58.2 o None}} de las ya
	sondeadas. Una consulta para toda la lista."""
	found = {}
	keys = [k for k in set(keys or ()) if k]
	if not keys:
		return found
	con = None
	try:
		con = _connect_dv()
		for i in range(0, len(keys), 500):
			chunk = keys[i:i + 500]
			q = ('SELECT key, dv, mbps, video_mbps, audio_kbps, live_video_mbps, live_audio_kbps '
				'FROM video_tracks WHERE key IN (%s)' % ','.join('?' * len(chunk)))
			for row in con.execute(q, chunk).fetchall():
				found[row[0]] = {'dv': row[1] or '', 'mbps': row[2], 'video_mbps': row[3],
					'audio_kbps': row[4], 'live_video_mbps': row[5], 'live_audio_kbps': row[6]}
	except Exception:
		pass
	finally:
		try:
			if con is not None: con.close()
		except Exception:
			pass
	return found


def forget_all():
	con = None
	try:
		con = _connect()
		con.execute('DELETE FROM audio_tracks')
		try:
			con.execute('DELETE FROM video_tracks')
		except Exception:
			pass  # la tabla nace con el primer DV leido
		con.commit()
	except Exception:
		pass
	finally:
		try:
			if con is not None: con.close()
		except Exception:
			pass
