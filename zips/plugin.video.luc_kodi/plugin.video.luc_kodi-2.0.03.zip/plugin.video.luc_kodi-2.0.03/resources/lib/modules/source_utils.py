# -*- coding: utf-8 -*-
"""
	luc_kodi Add-on
"""

import re
from urllib.parse import unquote, unquote_plus

VIDEO_3D = ('.3d.', '.sbs.', '.hsbs', 'sidebyside', 'side.by.side', 'stereoscopic', '.tab.', '.htab.', 'topandbottom', 'top.and.bottom')

DOLBY_VISION = ('dolby.vision', 'dolbyvision', '.dovi.', '.dv.')
HDR = ('2160p.uhd.bluray', '2160p.uhd.blu.ray', '2160p.bluray.hevc.truehd', '2160p.blu.ray.hevc.truehd',
			'2160p.bluray.hevc.dts.hd.ma', '2160p.blu.ray.hevc.dts.hd.ma', '.hdr.', 'hdr10', 'hdr.10',
			'uhd.bluray.2160p', 'uhd.blu.ray.2160p')
HDR_true = ('.hdr.', 'hdr10', 'hdr.10')
HLG = ('.hlg.', '.hlg10.')

# v1.0.83. AV1 no estaba aqui, aunque el badge source/AV1.png existe, el skin
# lo busca en luc_kodi.extra_info y source_ranker.py tiene una feature
# 'codec:AV1'. O sea que todo el arbol sabia leer un token que nadie emitia:
# solo llegaba cuando el scraper lo habia inyectado por get_extra_tags().
CODEC_AV1 = ('.av1.', '.av01', 'av1.')
CODEC_H264 = ('avc', 'h264', 'h.264', 'x264', 'x.264')
CODEC_H265 = ('h265', 'h.265', 'hevc', 'x265', 'x.265')
CODEC_XVID = ('xvid', '.x.vid')
CODEC_DIVX = ('divx', 'div2', 'div3', 'div4')
CODEC_MPEG = ('.mpg', '.mp2', '.mpeg', '.mpe', '.mpv', '.mp4', '.m4p', '.m4v', 'msmpeg', 'mpegurl')
CODEC_MKV = ('.mkv', 'matroska')
REMUX = ('remux', 'bdremux')

BLURAY = ('bluray', 'blu.ray', 'bdrip', 'bd.rip', '.brrip.', 'br.rip')
DVD = ('dvdrip', 'dvd.rip')
WEB = ('.web.', 'webdl', 'web.dl', 'webrip', 'web.rip')
HDRIP = ('.hdrip', '.hd.rip')
SCR = ('scr.', 'screener')
HC = ('.hc', 'korsub', 'kor.sub')

# Perfil y capa de Dolby Vision. Solo se consultan con DOLBY-VISION ya
# detectado: 'p5'/'p7'/'p8' son dos caracteres y salen sueltos en nombres de
# grupo y en numeraciones. FEL y MEL solo existen dentro de DV.
#
# v2.0.03. El perfil se lee con dv_profile(), que es el UNICO sitio donde
# vive esta regla: get_extra_tags() de jacksparrow la importa de aqui, para
# que los dos caminos no puedan volver a decir cosas distintas del mismo
# nombre. Las tuplas DV_P7/DV_P8/DV_P5 que habia aqui encajaban '.p8.' dentro
# de 'p8.1' y tiraban el '.1': un DV P8.1 salia como DV-P8 a secas.
#
# Subperfiles: solo el perfil 8 los tiene, y los dice el campo
# bl_signal_compatibility_id del RPU, no la cadena de codec. 8.1 es base
# HDR10, 8.4 base HLG (8.2, base SDR, no se ve en releases). En 'dvhe.08.06'
# el 06 es el NIVEL, no el subperfil, asi que de la cadena de codec solo sale
# P8.
DV_CODEC = (('dvhe.07', 'dvh1.07', '7'), ('dvhe.08', 'dvh1.08', '8'), ('dvhe.05', 'dvh1.05', '5'))
# Con la marca delante y la P: '.p8.', '.p8.1.', '.p81.', '.dvp8.1.',
# '.profile.8.1.'. El subperfil solo se acepta detras de un 8.
#
# Lo que viene DETRAS del numero decide si es perfil o es audio: una cifra
# suelta ('.1.', '.0.') es un recuento de canales. 'DV.P8.2.0' es P8 con
# audio 2.0, no un P8.2, y 'p5.1'/'p7.1' no son ningun perfil. Una cifra larga
# si vale ('P8.1.2160p' es 8.1 seguido de la resolucion).
#
# 8.2 (base SDR) no se lee: no aparece en releases y 'P8.2.0' lo inventaba.
DV_PROFILE_P = re.compile(r'\.(?:dv|dovi)?(?:p|profile\.?)(?:(8)(?:\.?([14])(?=\.(?!\d\.)))?(?=\.)|([57])(?=\.(?!\d\.)))')
# Sin P, el numero pegado a la marca: '.dv.8.1.', '.dv8.1.', '.dovi.8.1.',
# '.dolby.vision.8.1.'. Misma regla de lo que viene detras: '.dv.5.1.' y
# '.dv.7.1.' son canales de audio, no perfiles. 8.1 no es ninguna disposicion
# de altavoces, asi que con el 8 no hay esa ambiguedad.
DV_PROFILE_BARE = re.compile(r'\.(?:dv|dovi|vision)\.?(?:(8)(?:\.([14])(?=\.(?!\d\.)))?(?=\.)|([57])(?=\.(?!\d\.)))')
# La marca y el perfil escritos de corrido ('DV8.1', 'DVP8.1', 'DVP7') son a la
# vez la marca de DV: sin esto '.dv.' no aparece y el fichero ni siquiera se
# reconocia como Dolby Vision.
DV_FUSED = re.compile(r'\.(?:dv|dovi)p?(?:8(?:\.?[14])?\.|[57]\.(?!\d\.))')
DV_FEL = ('.fel.', 'bl.el.rpu', 'blelrpu')
DV_MEL = ('.mel.',)
BITDEPTH_10 = ('.10bit.', '.10.bit.')
# Se exige 'fps' pegado al numero: '2160p' lleva un '60' dentro.
FPS_60 = ('.60fps.', '.60.fps.')
FPS_50 = ('.50fps.', '.50.fps.')

DOLBY_TRUEHD = ('true.hd', 'truehd')
# v1.0.83: 'ddpa' anadido. Es DD+ con Atmos escrito de corrido, y salia en
# una fila real de TORRENTGALAXY ('DDPA.5.1') donde el codec no se reconocia
# y el recuento de canales se quedaba huerfano en la linea.
DOLBY_DIGITALPLUS = ('dolby.digital.plus', 'dolbydigital.plus', 'dolbydigitalplus', 'dd.plus.', 'ddplus', '.ddp.', 'ddp2', 'ddp5', 'ddp7', 'ddpa', 'eac3', '.e.ac3')
DOLBY_DIGITALEX = ('.dd.ex.', 'ddex', 'dolby.ex.', 'dolby.digital.ex.', 'dolbydigital.ex.')
DOLBYDIGITAL = ('dd2.', 'dd5', 'dd7', 'dolbyd.', 'dolby.digital', 'dolbydigital', '.ac3', '.ac.3.', '.dd.')

DTSX = ('dts.x.', 'dtsx')
DTS_HDMA = ('hd.ma', 'hdma')
DTS_HD = ('dts.hd.', 'dtshd')

AUDIO_8CH = ('ch8.', '8ch.', '7.1ch', '7.1.')
AUDIO_7CH = ('ch7.', '7ch.', '6.1ch', '6.1.')
AUDIO_6CH = ('ch6.', '6ch.', '5.1ch', '5.1.')
AUDIO_2CH = ('ch2', '2ch', '2.0ch', '2.0.', 'audio.2.0.', 'stereo')

MULTI_LANG = ('dual.audio', 'dual.yg', 'multi')
LANG = ('arabic', 'bgaudio', 'castellano', 'chinese', 'dutch', 'finnish', 'french', 'german', 'greek', 'hebrew', 'italian', 'latino', 'polish',
				'portuguese', 'russian', 'spanish', 'tamil', 'telugu', 'truefrench', 'truespanish', 'turkish')
ABV_LANG = ('.ara.', '.ces.', '.chi.', '.chs.', '.cze.', '.dan.', '.de.', '.deu.', '.dut.', '.ell.', '.es.', '.esl.', '.esp.', '.fi.', '.fin.', '.fr.', '.fra.', '.fre.', '.frn.', '.gai.', '.ger.', '.gle.', '.gre.',
				'.gtm.', '.he.', '.heb.', '.hi.', '.hin.', '.hun.', '.hindi.', '.ind.', '.iri.', '.it.', '.ita.', '.ja.', '.jap.', '.jpn.', '.ko.', '.kor.', '.lat.', '.nl.', '.lit.', '.nld.', '.nor.', '.pl.', '.pol.',
				'.pt.', '.por.', '.ru.', '.rus.', '.som.', '.spa.', '.sv.', '.sve.', '.swe.', '.tha.', '.tr.', '.tur.', '.uae.', '.uk.', '.ukr.', '.vi.', '.vie.', '.zh.', '.zho.')
SUBS = ('subita', 'subfrench', 'subspanish', 'subtitula', 'swesub', 'nl.subs')
ADS = ('1xbet', 'betwin')

def seas_ep_filter(season, episode, release_title, split=False):
	try:
		release_title = re.sub(r'[^A-Za-z0-9-]+', '.', unquote(release_title).replace('\'', '')).replace('&', 'and').replace('%', '.percent').lower()
		season = str(season)
		season_fill = season.zfill(2)
		episode = str(episode)
		episode_fill = episode.zfill(2)
		int_episode = int(episode)

		string1 = r'(s<<S>>[.-]?e[p]?[.-]?<<E>>[.-])'
		string2 = r'(season[.-]?<<S>>[.-]?episode[.-]?<<E>>[.-])|' \
						r'([s]?<<S>>[x.]<<E>>[.-])'
		string3 = r'(s<<S>>e<<E1>>[.-]?e?<<E2>>[.-])'
		string4 = r'([.-]<<S>>[.-]?<<E>>[.-])'
		string5 = r'(episode[.-]?<<E>>[.-])'
		string6 = r'([.-]e[p]?[.-]?<<E>>[.-])'

		string_list = []
		append = string_list.append
		append(string1.replace('<<S>>', season_fill).replace('<<E>>', episode_fill))
		append(string1.replace('<<S>>', season).replace('<<E>>', episode_fill))
		append(string1.replace('<<S>>', season_fill).replace('<<E>>', episode))
		append(string1.replace('<<S>>', season).replace('<<E>>', episode))
		append(string2.replace('<<S>>', season_fill).replace('<<E>>', episode_fill))
		append(string2.replace('<<S>>', season).replace('<<E>>', episode_fill))
		append(string2.replace('<<S>>', season_fill).replace('<<E>>', episode))
		append(string2.replace('<<S>>', season).replace('<<E>>', episode))
		append(string3.replace('<<S>>', season_fill).replace('<<E1>>', str(int_episode-1).zfill(2)).replace('<<E2>>', episode_fill))
		append(string3.replace('<<S>>', season_fill).replace('<<E1>>', episode_fill).replace('<<E2>>', str(int_episode+1).zfill(2)))
		append(string4.replace('<<S>>', season_fill).replace('<<E>>', episode_fill))
		append(string4.replace('<<S>>', season).replace('<<E>>', episode_fill))
		append(string5.replace('<<E>>', episode_fill))
		append(string5.replace('<<E>>', episode))
		append(string6.replace('<<E>>', episode_fill))

		final_string = '|'.join(string_list)
		reg_pattern = re.compile(final_string)
		if split: return release_title.split(re.search(reg_pattern, release_title).group(), 1)[1]
		else: return bool(re.search(reg_pattern, release_title))
	except:
		from resources.lib.modules import log_utils
		log_utils.error()
		return None

def extras_filter():
	return ('sample', 'extra', 'deleted', 'unused', 'footage', 'inside', 'blooper', 'making.of', 'feature', 'featurette', 'behind.the.scenes', 'trailer')

def is_archive_part(path):
	"""v1.0.54: True si el fichero es una PARTE de un archivo multivolumen.
	Las listas invalid_extensions solo cubrian '.rar' y '.zip', asi que las
	partes numeradas (.z01/.z03, .r00, .part1.rar, .001) pasaban el filtro y,
	al ser enormes, ganaban el max(size) de la seleccion de fichero: el
	reproductor recibia un trozo de archivo y Kodi respondia "Playback not
	supported" (visto en kodi.log con un .z03 de un COMPLETE UHD BLURAY).
	Nada de esto es reproducible en streaming: hay que descomprimirlo antes."""
	try:
		low = str(path or '').lower().split('?')[0].split('|')[0]
		# .z01..z99 / .r00..r99 / .7z.001 / .part01.rar / .001..999
		return bool(re.search(r'\.(z\d{2}|r\d{2}|part\d+\.rar|\d{3})$', low))
	except: return False

def supported_video_extensions():
	try:
		from xbmc import getSupportedMedia
		supported_video_extensions = getSupportedMedia('video').split('|')
		return [i for i in supported_video_extensions if i != '' and i != '.zip']
	except:
		from resources.lib.modules import log_utils
		log_utils.error()

def is_dv_fused(fmt):
	"""v2.0.03. True si el nombre escribe la marca de DV pegada al perfil
	('DV8.1', 'DVP8.1', 'DVP7'): ahi no hay '.dv.' que encontrar."""
	try: return bool(fmt) and bool(DV_FUSED.search(fmt))
	except Exception: return False

def dv_profile(fmt):
	"""v2.0.03. Perfil de Dolby Vision que declara el nombre, como token:
	'DV-P5', 'DV-P7', 'DV-P8', 'DV-P8.1', 'DV-P8.4', o '' si no
	declara ninguno. fmt va en minusculas, con puntos de separador y acotado
	('.x.y.'), que es como llega name_info. Solo se llama con DV ya detectado.

	Un P8 sin subperfil escrito se completa SOLO cuando el mismo nombre
	declara tambien la base: P8 + HDR10 es 8.1 por definicion (un P8 de una
	sola capa con base HDR10 no puede ser otra cosa) y P8 + HLG es 8.4. Son
	dos cosas que el nombre dice, no una suposicion. Lo que NO se hace es
	sacar un 8.1 de un 'DV HDR10' sin perfil: asi se escribe tambien un P7 de
	doble capa, y ahi el nombre no da para distinguirlos."""
	try:
		if not fmt: return ''
		prof = sub = ''
		for codec_he, codec_h1, p in DV_CODEC:
			if codec_he in fmt or codec_h1 in fmt:
				prof = p
				break
		m = DV_PROFILE_P.search(fmt) or DV_PROFILE_BARE.search(fmt)
		if m:
			m_prof = m.group(1) or m.group(3)
			if not prof: prof = m_prof
			if prof == m_prof == '8': sub = m.group(2) or ''
		if not prof: return ''
		if prof == '8' and not sub:
			if any(value in fmt for value in HDR_true): sub = '1'
			elif any(value in fmt for value in HLG): sub = '4'
		return ('DV-P%s.%s' % (prof, sub)) if sub else ('DV-P%s' % prof)
	except Exception:
		return ''

def merge_real_dv(parts, token):
	"""v2.0.03. Reescribe una lista de tokens de fila con el perfil de Dolby
	Vision LEIDO del fichero por la sonda (audio_probe), que manda sobre lo
	que declaraba el nombre. La comparten la lista de fuentes y la linea de
	info del reproductor, para que las dos digan lo mismo.

	  - El perfil del nombre se sustituye por el real.
	  - Si el nombre no decia DV, o decia SDR, el fichero manda: entra
	    DOLBY-VISION y sale SDR.
	  - FEL y MEL son capas mejoradas: con un perfil leido que no es 7 no
	    pueden existir, y se quitan aunque el nombre las prometiera.
	  - Un perfil x.1 (8.1, 10.1) tiene base HDR10: entra HDR si faltaba. Un
	    perfil 5 no tiene base compatible: un HDR del nombre seria mentira.
	"""
	try:
		out = [str(p).strip() for p in (parts or ()) if str(p).strip()]
		if not token:
			return out
		up = lambda p: p.upper()
		prof = token[4:].split('.', 1)[0]
		out = [p for p in out if not up(p).startswith('DV-P')]
		if prof != '7':
			out = [p for p in out if up(p) not in ('DV-FEL', 'DV-MEL')]
		out = [p for p in out if up(p) != 'SDR']
		if prof == '5':
			out = [p for p in out if up(p) not in ('HDR', 'HDR10', 'HDR10+')]
		if not any(up(p) in ('DOLBY-VISION', 'DV') for p in out):
			out.insert(0, 'DOLBY-VISION')
		dv_at = [i for i, p in enumerate(out) if up(p) in ('DOLBY-VISION', 'DV')][0]
		if token.endswith('.1') and not any(up(p) in ('HDR', 'HDR10', 'HDR10+') for p in out):
			out.insert(dv_at, 'HDR')
			dv_at += 1
		# Detras de DV y del HDR que lo acompane, el orden de getFileType().
		at = dv_at + 1
		while at < len(out) and up(out[at]) in ('HDR', 'HDR10', 'HDR10+'):
			at += 1
		out.insert(at, token)
		return out
	except Exception:
		return [str(p).strip() for p in (parts or ()) if str(p).strip()]

def getFileType(name_info=None, url=None):
	try:
		file_type = ''
		if name_info: fmt = name_info
		elif url: fmt = url_strip(url)
		if not fmt: return file_type

		if any(value in fmt for value in VIDEO_3D):  file_type += ' 3D /'

		if '.sdr' in fmt: file_type += ' SDR /'
		elif any(value in fmt for value in DOLBY_VISION) or is_dv_fused(fmt): file_type += ' DOLBY-VISION /'
		elif any(value in fmt for value in HDR): file_type += ' HDR /'
		elif all(i in fmt for i in ('2160p', 'remux')): file_type += ' HDR /'
		if ' DOLBY-VISION ' in file_type:
			# v1.0.83. El perfil y la capa, cuando el nombre los declara. Esto
			# lee lo declarado y nada mas: FEL vive en el RPU del fichero y no
			# hay forma de confirmarlo ni desmentirlo antes de reproducir.
			dv_prof = dv_profile(fmt)
			# for hybrid DV and HDR sources. v2.0.03: un 8.1 declarado ES base
			# HDR10 aunque el nombre no escriba HDR, y un aparato sin DV lo
			# reproduce como HDR10. Sin el HDR, 'remove.dolby.vision' lo
			# quitaba de la lista como si solo sirviera con Dolby Vision.
			if any(value in fmt for value in HDR_true) or dv_prof == 'DV-P8.1': file_type += ' HDR /'
			if dv_prof: file_type += ' %s /' % dv_prof
			if any(value in fmt for value in DV_FEL): file_type += ' DV-FEL /'
			elif any(value in fmt for value in DV_MEL): file_type += ' DV-MEL /'
			elif '.hybrid.' in fmt: file_type += ' DV-HYBRID /'

		if any(value in fmt for value in CODEC_AV1): file_type += ' AV1 /'
		elif any(value in fmt for value in CODEC_H264): file_type += ' AVC /'
		elif any(value in fmt for value in CODEC_H265): file_type += ' HEVC /'
		elif any(i in file_type for i in (' HDR ', ' DOLBY-VISION ')): file_type += ' HEVC /'
		elif any(value in fmt for value in CODEC_XVID): file_type += ' XVID /'
		elif any(value in fmt for value in CODEC_DIVX): file_type += ' DIVX /'

		if '.wmv' in fmt: file_type += ' WMV /'
		elif any(value in fmt for value in CODEC_MPEG): file_type += ' MPEG /'
		elif '.avi' in fmt: file_type += ' AVI /'
		elif any(value in fmt for value in CODEC_MKV): file_type += ' MKV /'

		if any(value in fmt for value in BITDEPTH_10): file_type += ' 10BIT /'

		if any(value in fmt for value in FPS_60): file_type += ' 60FPS /'
		elif any(value in fmt for value in FPS_50): file_type += ' 50FPS /'
		elif '.hfr.' in fmt: file_type += ' HFR /'

		if any(value in fmt for value in REMUX): file_type += ' REMUX /'

		if any(value in fmt for value in BLURAY): file_type += ' BLURAY /'
		elif any(i in fmt for i in DVD): file_type += ' DVD /'
		elif any(value in fmt for value in WEB): file_type += ' WEB /'
		elif 'hdtv' in fmt: file_type += ' HDTV /'
		elif 'pdtv' in fmt: file_type += ' PDTV /'
		elif any(value in fmt for value in SCR): file_type += ' SCR /'
		elif any(value in fmt for value in HDRIP): file_type += ' HDRIP /'

		# 'ddpa' lleva la A de Atmos dentro, asi que la declara igual que si
		# el nombre pusiera 'atmos' con todas sus letras.
		if 'atmos' in fmt or 'ddpa' in fmt: file_type += ' ATMOS /'
		if any(value in fmt for value in DOLBY_TRUEHD): file_type += ' DOLBY-TRUEHD /'
		if any(value in fmt for value in DOLBY_DIGITALPLUS): file_type += ' DD+ /'
		elif any(value in fmt for value in DOLBYDIGITAL): file_type += ' DOLBYDIGITAL /'
		elif any(value in fmt for value in DOLBY_DIGITALEX): file_type += ' DD-EX /'

		if 'aac' in fmt: file_type += ' AAC /'
		elif 'mp3' in fmt: file_type += ' MP3 /'
		elif 'flac' in fmt: file_type += ' FLAC /'
		# elif 'opus' in fmt and not fmt.endswith('opus.'): file_type += ' OPUS /' #OPUS also a group titles endswith

		if any(value in fmt for value in DTSX): file_type += ' DTS-X /'
		elif any(value in fmt for value in DTS_HDMA): file_type += ' DTS-HD MA /'
		elif any(value in fmt for value in DTS_HD): file_type += ' DTS-HD /'
		elif '.dts' in fmt: file_type += ' DTS /'

		if any(value in fmt for value in AUDIO_8CH): file_type += ' 8CH /'
		elif any(value in fmt for value in AUDIO_7CH): file_type += ' 7CH /'
		elif any(value in fmt for value in AUDIO_6CH): file_type += ' 6CH /'
		elif any(value in fmt for value in AUDIO_2CH): file_type += ' 2CH /'

		if any(value in fmt for value in HC): file_type += ' HC /'

		if any(value in fmt for value in MULTI_LANG): file_type += ' MULTI-LANG /'
		elif any(value in fmt for value in LANG) and any(value in fmt for value in ('.eng.', '.en.', 'english')): file_type += ' MULTI-LANG /'
		elif any(value in fmt for value in ABV_LANG) and any(value in fmt for value in ('.eng.', '.en.', 'english')):file_type += ' MULTI-LANG /'

		if any(value in fmt for value in ADS): file_type += ' ADS /'
		if any(value in fmt for value in SUBS):
			if file_type != '': file_type += ' WITH SUBS'
			else: file_type = 'SUBS'
		file_type = file_type.rstrip('/') # leave trailing space for cases like " HDR " vs. " HDRIP "
		return file_type
	except:
		from resources.lib.modules import log_utils
		log_utils.error()
		return ''

def url_strip(url):
	try:
		url = unquote_plus(url)
		if 'magnet:' in url: url = url.split('&dn=')[1]
		url = url.lower().replace("'", "").lstrip('.').rstrip('.')
		fmt = re.sub(r'[^a-z0-9]+', '.', url)
		fmt = '.%s.' % fmt
		fmt = re.sub(r'(.+)((?:19|20)[0-9]{2}|season.\d+|s[0-3]{1}[0-9]{1}|e\d+|complete)(.complete\.|.episode\.\d+\.|.episodes\.\d+\.\d+\.|.series|.extras|.ep\.\d+\.|.\d{1,2}\.|-|\.|\s)', '', fmt) # new for pack files
		if '.http' in fmt: fmt = None
		if fmt == '': return None
		else: return '.%s' % fmt
	except:
		from resources.lib.modules import log_utils
		log_utils.error()
		return None

def aliases_check(title, aliases):
	fixed_aliases = []
	try:
		bad_aliases = {'Dexter': ['Dexter: New Blood',], 'Titans': ['Teen Titans',]}
		if title in bad_aliases:
			for i in aliases:
				if i.get('title') not in bad_aliases.get(title): fixed_aliases.append(i)
			aliases = fixed_aliases
		if title == 'Gomorrah': aliases.append({'title': 'Gomorra', 'country': ''})
		if title == 'Daredevil': aliases.append({'title': "Marvel's Daredevil", 'country': 'us'})
	except:
		from resources.lib.modules import log_utils
		log_utils.error()
	return aliases

def tvshow_reboots():
	reboots = {
		"Adam-12": ["1990"], "Battlestar Galactica": ["2004"], "Charlie's Angels": ["2011"], "Charmed": ["2018"], "Dynasty": ["2017"], "Fantasy Island": ["2021"],
		"The Flash": ["2014"], "The Fugitive": ["2000", "2020"], "Ghostwriter": ["2019"], "Gossip Girl": ["2021"], "Hawaii Five-0": ["2010"],
		"Ironside": ["2013"], "Kojak": ["2005"], "Kung Fu": ["2021"], "Lost in Space": ["2018"], "MacGyver": ["2016"], "Magnum P.I.": ["2018"], "Nancy Drew": ["2019"],
		"The Odd Couple": ["2015"], "One Day at a Time": ["2017"], "The Outer Limits": ["1995"], "Party of Five": ["2020"], "Perry Mason": ["2020"], "S.W.A.T.": ["2017"],
		"The Twilight Zone": ["1985", "2002", "2019"], "The Untouchables": ["1993"], "V": ["2009"], "The Wonder Years": ["2021"]}
	return reboots

def copy2clip(txt):
	from sys import platform
	if platform == "win32":
		try:
			from subprocess import check_call
			# cmd = "echo " + txt.strip() + "|clip"
			cmd = "echo " + txt.replace('&', '^&').strip() + "|clip" # "&" is a command seperator
			return check_call(cmd, shell=True)
		except:
			from resources.lib.modules import log_utils
			log_utils.error('Windows: Failure to copy to clipboard')
	elif platform == "darwin":
		try:
			from subprocess import check_call
			cmd = "echo " + txt.strip() + "|pbcopy"
			return check_call(cmd, shell=True)
		except:
			from resources.lib.modules import log_utils
			log_utils.error('Mac: Failure to copy to clipboard')
	elif platform == "linux":
		try:
			from subprocess import Popen, PIPE
			p = Popen(["xsel", "-pi"], stdin=PIPE)
			p.communicate(input=txt)
		except:
			from resources.lib.modules import log_utils
			log_utils.error('Linux: Failure to copy to clipboard')


# ---------------------------------------------------------------------
# v1.0.90 — Release group (inspirado en _extract_release_group de TMDb Movies)
# ---------------------------------------------------------------------
# Lo usa binge.py para que el siguiente episodio salga, si se puede, del
# mismo grupo que el anterior (mismo encode, misma mezcla de audio, mismo
# doblaje). Casos que cubre, por orden:
#   ...-GRUPO.mkv       sufijo con guion (el caso normal)
#   ...[GRUPO].mkv      grupo entre corchetes al final
#   ...x265.GRUPO       grupo tras el ultimo punto
# Se descarta basura que aparece en esas posiciones (codecs, resoluciones,
# idiomas, "dual", "remux"...). Si no hay certeza, devuelve ''.
_RG_JUNK = frozenset((
	'x264', 'x265', 'h264', 'h265', 'hevc', 'avc', 'av1', 'xvid', 'divx', 'mkv', 'mp4', 'avi',
	'1080p', '720p', '2160p', '480p', '4k', 'uhd', 'hdr', 'hdr10', 'dv', 'sdr', 'web', 'webdl',
	'webrip', 'bluray', 'remux', 'bdrip', 'hdtv', 'dual', 'multi', 'audio', 'subs', 'sub', 'eng',
	'spa', 'esp', 'lat', 'cast', 'castellano', 'latino', 'spanish', 'english', 'ita', 'fre', 'ger',
	'aac', 'ac3', 'eac3', 'dts', 'ddp', 'ddp5', 'truehd', 'atmos', 'flac', 'opus', 'proper',
	'repack', 'internal', 'extended', 'unrated', 'complete', 'season', 'rip', 'dl', 'ts', 'nf',
	'amzn', 'dsnp', 'hmax', 'atvp', 'www', 'com', 'org', 'net', 'rarbg', 'eztv', 'yts', 'none'))


def release_group(name):
	try:
		if not name: return ''
		n = unquote(str(name)).strip()
		n = re.sub(r'(?i)\.(mkv|mp4|avi|ts|m2ts|webm|m4v)$', '', n)
		n = re.sub(r'\s+', ' ', n).strip(' .-_')
		m = re.search(r'-\s?([A-Za-z0-9@_]{2,15})\s*(?:\[[^\]]*\])?$', n)
		if not m:
			m = re.search(r'\[([A-Za-z0-9_]{2,15})\]$', n)
		if not m:
			m = re.search(r'\.([A-Za-z][A-Za-z0-9_]{1,14})$', n)
			# tras un punto solo cuenta si el nombre tiene pinta de release
			if m and not re.search(r'(?i)(19|20)\d{2}|\d{3,4}p|s\d{1,2}e\d{1,3}', n):
				m = None
		if not m: return ''
		grp = m.group(1)
		if grp.lower() in _RG_JUNK or not re.search(r'[A-Za-z]', grp): return ''
		if re.match(r'(?i)^(s\d{1,2}e\d{1,3}|\d{3,4}p|v\d+)$', grp): return ''
		if re.match(r'^[0-9A-Fa-f]{8}$', grp) and re.search(r'\d', grp): return '' # CRC32 de anime, no es grupo
		return grp.upper()
	except Exception:
		return ''
