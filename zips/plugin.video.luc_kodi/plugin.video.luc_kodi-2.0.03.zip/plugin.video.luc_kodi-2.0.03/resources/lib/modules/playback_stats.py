# -*- coding: utf-8 -*-
"""
	luc_kodi Add-on — Live playback stats (v2.0.03)

	Kodi 22 publica por primera vez lo que de verdad entra al reproductor:

	  Player.Process(videolivebitrate)  '51.8 Mb/s'  bits/s del video que
	                                                 entra al decodificador,
	                                                 recalculado cada 2 s
	  Player.Process(audiolivebitrate)  '640 kb/s'   lo mismo del audio que
	                                                 suena
	  Player.Process(videoqueuelevel)   '0'..'99'    lo lleno que esta la cola
	                                                 del decodificador de video

	(xbmc/guilib/guiinfo/PlayerGUIInfo.cpp en la rama master.) Kodi 21 no
	tiene ninguno de los tres: en un Kodi 21 este modulo no hace nada.

	Que hace con ellos: los muestrea mientras el video suena, descarta lo que
	no es reproduccion normal (pausa, cache llenandose, los segundos despues
	de arrancar o de un salto) y al terminar deja UNA linea en el log con la
	media en directo al lado de lo que la sonda leyo del fichero antes de
	reproducir. Lo guarda en la misma cache que la sonda.

	No avisa de nada. Un pico es algo que pasa y la cache de Kodi lo absorbe;
	esto es un dato, no una alarma.

	Las cifras de Kodi van en unidades binarias: el video se divide entre
	1048576 y el audio entre 1024 antes de escribirse. Aqui se deshace para
	que salgan en Mbps y kbps decimales, los mismos que usa la sonda.
"""

import re
import threading
from time import time

import xbmc

from resources.lib.modules import control
from resources.lib.modules import log_utils

_SAMPLE_EVERY = 2.0      # Kodi recalcula su cifra cada 2 s; muestrear mas es leer lo mismo
_SETTLE = 20.0           # segundos de reproduccion normal antes de empezar a contar
_MIN_SAMPLES = 15        # medio minuto de muestras como minimo para dar una media
_LOW_QUEUE = 5           # cola de video por debajo de esto = el decodificador va justo
_EXPECT_MAX_AGE = 300    # lo que publico la sonda vale para ESTE arranque, no para el anterior

_active_lock = threading.Lock()
_active_path = [None]


def supported():
	"""Kodi 22 en adelante."""
	try:
		return int(control.getKodiVersion()) >= 22
	except Exception:
		return False


def enabled():
	try:
		from resources.lib.modules import audio_probe
		return supported() and audio_probe.enabled()
	except Exception:
		return False


def start(player):
	"""Punto de entrada desde player.keepAlive(). No bloquea."""
	if not enabled():
		return
	try:
		mon = _LiveMonitor(player)
		mon.daemon = True
		mon.start()
	except Exception:
		log_utils.error()


# ── lectura de las etiquetas de Kodi 22 ────────────────────────────────────

_NUM = re.compile(r'\d[\d.,   ]*')


def parse_video(label):
	"""'51.8 Mb/s' → 54.3 (Mbps decimales). Kodi lo escribe con '{:.1f}', que
	no depende del idioma, pero se acepta tambien la coma por si un build lo
	localiza."""
	try:
		m = _NUM.search(label or '')
		if not m:
			return None
		raw = m.group(0).strip().replace(' ', '').replace(' ', '').replace(' ', '')
		if raw.count(',') == 1 and '.' not in raw:
			raw = raw.replace(',', '.')
		raw = raw.replace(',', '')
		v = float(raw)
		return round(v * 1048576 / 1e6, 2)
	except Exception:
		return None


def parse_audio(label):
	"""'1,509 kb/s' / '1.509 kb/s' / '640 kb/s' → kbps decimales. Kodi lo
	escribe como ENTERO con el separador de miles del idioma del sistema
	(StringUtils::FormatNumber), asi que todo lo que no es cifra sobra."""
	try:
		m = _NUM.search(label or '')
		if not m:
			return None
		digits = re.sub(r'\D', '', m.group(0))
		if not digits:
			return None
		return round(int(digits) * 1024 / 1000.0, 1)
	except Exception:
		return None


def parse_level(label):
	try:
		v = int(str(label or '').strip())
		return v if 0 <= v <= 100 else None
	except Exception:
		return None


def summarize(samples):
	"""Muestras [(video_mbps, audio_kbps, queue)] → resumen. Media y mediana
	del video (la mediana dice lo tipico; la media, lo que ha pasado por la
	linea), media del audio y que parte del tiempo fue la cola justa."""
	vids = [v for v, a, q in samples if v]
	auds = [a for v, a, q in samples if a]
	ques = [q for v, a, q in samples if q is not None]
	out = {'samples': len(samples), 'video_mbps': None, 'video_median': None,
		'audio_kbps': None, 'low_queue': None, 'min_queue': None}
	if vids:
		out['video_mbps'] = round(sum(vids) / len(vids), 1)
		srt = sorted(vids)
		out['video_median'] = round(srt[len(srt) // 2], 1)
	if auds:
		out['audio_kbps'] = round(sum(auds) / len(auds))
	if ques:
		out['low_queue'] = round(sum(1 for q in ques if q < _LOW_QUEUE) / float(len(ques)), 3)
		out['min_queue'] = min(ques)
	return out


def describe(stats, expect):
	"""La linea del log. La sonda al lado del directo: si las dos dicen lo
	mismo, la lectura de la cabecera queda confirmada."""
	def _f(v, fmt):
		return (fmt % v) if v else 'n/a'
	return ('[PLAYSTATS] kodi=%s samples=%d video=%s (median %s, file %s) audio=%s (file %s) '
			'file_avg=%s queue=low %s/min %s' % (
		control.getKodiVersion(), stats.get('samples') or 0,
		_f(stats.get('video_mbps'), '%.1f Mbps'), _f(stats.get('video_median'), '%.1f'),
		_f((expect or {}).get('video_mbps'), '%.1f'),
		_f(stats.get('audio_kbps'), '%d kbps'), _f((expect or {}).get('audio_kbps'), '%d'),
		_f((expect or {}).get('mbps'), '%.1f Mbps'),
		('%d%%' % int(round(stats['low_queue'] * 100))) if stats.get('low_queue') is not None else 'n/a',
		('%d%%' % stats['min_queue']) if stats.get('min_queue') is not None else 'n/a'))


# ── el hilo ────────────────────────────────────────────────────────────────

class _LiveMonitor(threading.Thread):
	def __init__(self, player):
		threading.Thread.__init__(self)
		self.player = player
		self.running_path = ''
		self.samples = []
		self.key = ''

	def _info(self, name):
		try:
			return xbmc.getInfoLabel('Player.Process(%s)' % name)
		except Exception:
			return ''

	def _cond(self, cond):
		try:
			return bool(xbmc.getCondVisibility(cond))
		except Exception:
			return False

	def _same_file(self):
		try:
			return self.player.isPlayingVideo() and self.player.getPlayingFile() == self.running_path
		except Exception:
			return False

	def _wait_for_clock(self):
		previous, deadline = None, time() + 60
		while not control.monitor.abortRequested() and time() < deadline:
			try:
				if self.player.isPlayingVideo():
					current = self.player.getTime()
					if previous is not None and current > previous + 0.1:
						self.running_path = self.player.getPlayingFile()
						return True
					previous = current
			except Exception:
				previous = None
			if control.monitor.waitForAbort(0.5):
				return False
		return False

	def run(self):
		try:
			with _active_lock:
				if _active_path[0] == '__starting__':
					return
				_active_path[0] = '__starting__'
			try:
				self._run_inner()
			finally:
				with _active_lock:
					_active_path[0] = None
		except Exception:
			log_utils.error()

	def _run_inner(self):
		if not self._wait_for_clock():
			return
		with _active_lock:
			_active_path[0] = self.running_path
		# Lo que la sonda leyo de ESTE fichero. Si esta reproduccion no paso
		# por la sonda (biblioteca, otro camino), lo publicado es de la
		# anterior y no se usa: se mide igual, pero sin clave ni comparacion.
		from resources.lib.modules import audio_probe
		exp = audio_probe.read_expect()
		self.key = exp.get('key') if (time() - float(exp.get('ts') or 0)) < _EXPECT_MAX_AGE else ''
		settle_until = time() + _SETTLE
		last_wall, last_pos = time(), None
		while self._same_file():
			if control.monitor.waitForAbort(_SAMPLE_EVERY):
				break
			if not self._same_file():
				break
			now = time()
			try:
				pos = self.player.getTime()
			except Exception:
				pos = None
			# Pausa, cache rellenandose o un salto: lo que mide Kodi en ese
			# rato no es la reproduccion normal. Se espera a que se asiente.
			jumped = (pos is not None and last_pos is not None and
				abs((pos - last_pos) - (now - last_wall)) > 4.0)
			if self._cond('Player.Paused') or self._cond('Player.Caching') or jumped:
				settle_until = now + _SETTLE / 2
			last_wall, last_pos = now, pos
			if now < settle_until:
				continue
			v = parse_video(self._info('videolivebitrate'))
			a = parse_audio(self._info('audiolivebitrate'))
			q = parse_level(self._info('videoqueuelevel'))
			if v or a:
				self.samples.append((v, a, q))
		self._finish()

	def _finish(self):
		if len(self.samples) < _MIN_SAMPLES:
			log_utils.log('[PLAYSTATS] kodi=%s samples=%d (too short to report)' % (
				control.getKodiVersion(), len(self.samples)), level=log_utils.LOGINFO)
			return
		from resources.lib.modules import audio_probe
		stats = summarize(self.samples)
		key = getattr(self, 'key', '')
		# Se relee: las estadisticas del final del fichero llegan en segundo
		# plano y pueden haberse sumado mientras sonaba.
		expect = audio_probe.read_expect() if key else {}
		if expect.get('key') != key:
			expect = {}
		log_utils.log(describe(stats, expect), level=log_utils.LOGINFO)
		if key:
			audio_probe.update_facts(key, live_video_mbps=stats.get('video_mbps'),
				live_audio_kbps=stats.get('audio_kbps'), live_low_queue=stats.get('low_queue'),
				live_samples=stats.get('samples'))
