# -*- coding: utf-8 -*-
"""
	luc_kodi Add-on — Episodes left in Continue Watching (v2.0.03)

	Cuantos episodios EMITIDOS te quedan de una serie, contados desde el de la
	tarjeta (incluido) hasta el ultimo que ha salido. Es lo que ensena Nuvio en
	su Continue Watching ("12" sobre MobLand) y aqui va escrito en la propia
	linea de la tarjeta, para que se vea en cualquier skin.

	Una sola regla para todos los servicios (Trakt, SIMKL, MDBList, PunchPlay,
	WeTrakr y lo visto en local). No se cuentan huecos hacia atras: SIMKL
	devuelve visionados no contiguos (vistos 4x03, 4x06 y 4x07) y contar los
	huecos diria que faltan las temporadas 1 a 3 enteras. La tarjeta ya es el
	siguiente al episodio mas avanzado, asi que se cuenta desde ella, que es
	lo que Nuvio llama "Up Next From Furthest Episode".

	Los datos son de TMDb: episodios por temporada ('counts') y el ultimo
	emitido ('last_episode_to_air'). Las listas de progreso ya los traen; las
	de "en curso" no, y para esas se lee la ficha de la serie de la cache de
	96 h, en paralelo y una sola vez por serie. Los especiales (temporada 0)
	no cuentan, y un episodio anunciado no suma hasta que se emite.
"""

from threading import Thread

from resources.lib.modules import control

_LEFT = 400927        # '%d left'
_UP_TO_DATE = 400928  # 'Up to date'


def enabled():
	try:
		return control.setting('continue.episodes.left') != 'false'
	except Exception:
		return True


def aired_left(season, episode, counts, last_aired):
	"""Episodios emitidos desde (season, episode) incluido hasta el ultimo
	emitido. 0 si la tarjeta todavia no se ha emitido. None si los datos no
	dan para contarlo sin inventar."""
	try:
		s, e = int(season), int(episode)
		if s < 1 or e < 1 or not last_aired:
			return None
		ls, le = int(last_aired.get('season_number') or 0), int(last_aired.get('episode_number') or 0)
		if ls < 1 or le < 1:
			return None
		if (s, e) > (ls, le):
			return 0
		per = {}
		for k, v in (counts or {}).items():
			try:
				per[int(k)] = int(v)
			except (TypeError, ValueError):
				continue
		total = 0
		for sn in range(s, ls + 1):
			aired = le if sn == ls else per.get(sn)
			if aired is None:
				return None
			total += aired
		total -= (e - 1)
		# La tarjeta esta emitida, asi que como minimo queda ella. Menos que
		# eso es que la numeracion de TMDb no casa con la del servicio (anime
		# con numeracion absoluta, temporadas partidas): mejor no decir nada.
		if total < 1:
			return None
		return total
	except Exception:
		return None


def text(n):
	"""'12 left' / 'Up to date' / ''."""
	try:
		if n is None:
			return ''
		if n == 0:
			return control.lang(_UP_TO_DATE)
		return control.lang(_LEFT) % n
	except Exception:
		return ''


def _show_meta(tmdb):
	try:
		from resources.lib.database import cache
		from resources.lib.indexers.tmdb import TVshows as tmdb_indexer
		return cache.get(tmdb_indexer().get_showSeasons_meta, 96, tmdb) or {}
	except Exception:
		return {}


def for_items(items):
	"""{(tmdb, season, episode): n} para toda la lista. Las series que ya
	traen sus datos se cuentan directamente; las que no, se leen en paralelo,
	una vez por serie."""
	out, data, missing = {}, {}, []
	for i in items or ():
		try:
			tmdb = str(i.get('tmdb') or '')
			if not tmdb or tmdb in data:
				continue
			if i.get('counts') and i.get('last_episode_to_air'):
				data[tmdb] = (i['counts'], i['last_episode_to_air'])
			elif tmdb not in missing:
				missing.append(tmdb)
		except Exception:
			continue
	fetched = {}

	def _get(t):
		m = _show_meta(t)
		if m and m.get('counts') and m.get('last_episode_to_air'):
			fetched[t] = (m['counts'], m['last_episode_to_air'])

	threads = [Thread(target=_get, args=(t,)) for t in missing]
	for th in threads:
		th.start()
	for th in threads:
		th.join()
	data.update(fetched)
	for i in items or ():
		try:
			tmdb = str(i.get('tmdb') or '')
			if tmdb not in data:
				continue
			counts, last = data[tmdb]
			out[(tmdb, str(i.get('season')), str(i.get('episode')))] = aired_left(
				i.get('season'), i.get('episode'), counts, last)
		except Exception:
			continue
	return out


def lookup(left_map, i):
	try:
		return left_map.get((str(i.get('tmdb') or ''), str(i.get('season')), str(i.get('episode'))))
	except Exception:
		return None
