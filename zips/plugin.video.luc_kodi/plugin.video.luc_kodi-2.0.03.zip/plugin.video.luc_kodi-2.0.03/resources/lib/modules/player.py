# -*- coding: utf-8 -*-
"""
	luc_kodi Add-on
"""

from resources.lib.modules import app_keys
from hashlib import md5
from json import dumps as jsdumps, loads as jsloads
from sys import argv, exit as sysexit
from sqlite3 import dbapi2 as database
from time import time
import threading
import xbmc
from resources.lib.database.cache import clear_local_bookmarks
from resources.lib.database.metacache import fetch as fetch_metacache
from resources.lib.database.traktsync import fetch_bookmarks
from resources.lib.modules import control
from resources.lib.modules import log_utils
from resources.lib.modules import playcount
from resources.lib.modules import trakt
from resources.lib.modules import simkl
from resources.lib.modules import mdblist
from resources.lib.modules import punchplay
from resources.lib.modules import wetrakr
from resources.lib.modules import opensubs
from difflib import SequenceMatcher
from resources.lib.modules.source_utils import seas_ep_filter
from urllib.request import urlopen, Request
from urllib.parse import unquote
import fnmatch
import os
LOGINFO = 1
getLS = control.lang
getSetting = control.setting
homeWindow = control.homeWindow
playerWindow = control.playerWindow
KODI_VERSION = control.getKodiVersion()



def _detect_mime(url):
	"""Return a MIME type hint for a stream URL so Kodi does not re-probe on seek."""
	try:
		clean = (url or '').lower().split('?')[0].split('|')[0]
		if clean.endswith('.mkv'):  return 'video/x-matroska'
		if clean.endswith('.mp4'):  return 'video/mp4'
		if clean.endswith('.avi'):  return 'video/x-msvideo'
		if clean.endswith('.ts'):   return 'video/mp2t'
		if clean.endswith('.m3u8'): return 'application/x-mpegURL'
		if clean.endswith('.mpd'):  return 'application/dash+xml'
	except Exception:
		pass
	return 'video/x-matroska'  # mkv is the most common container from Debrid


def _add_stream_headers(url):
	"""No-op pass-through.

	Previous versions appended `Accept-Ranges=bytes&Connection=keep-alive` to
	HTTPS Debrid URLs, but: (a) Accept-Ranges is a *response* header — sending
	it as a request is meaningless and some strict servers reject it; (b)
	Connection=keep-alive is already the HTTP/1.1 default. Real seek
	optimisation is achieved by setContentLookup(False) + setMimeType() in
	play_source(), so this helper is kept only for call-site compatibility.
	"""
	return url


class Player(xbmc.Player):
	def __init__(self):
		xbmc.Player.__init__(self)
		self.play_next_triggered = False
		self.preScrape_triggered = False
		self.playbackStopped_triggered = False
		self.playback_resumed = False
		self.onPlayBackStopped_ran = False
		self.media_type = None
		self.DBID = None
		self.offset = '0'
		self.media_length = 0
		self.current_time = 0
		self.meta = {}
		self.enable_playnext = getSetting('enable.playnext') == 'true'
		self.ended_naturally = False  # set by onPlayBackEnded → always show next-ep dialog
		self.playnext_time = 60  # fixed — playnext.time setting removed in v0.0.92
		# v1.0.98 (issue #2): PlayNext durante los creditos, una vez por episodio.
		self.playnext_overlay_done = False  # el popup ya salio (o no habia siguiente)
		self.playnext_choice = None         # '1' Auto-Play / '0' Choose Source elegido en el popup
		self.playnext_declined = False      # Not Now / Stop en el popup: sin siguiente ni dialogo post-stop
		self.playnext_target = None         # (temporada, episodio) que ofrecio el popup
		self.credits_at = None              # inicio de los creditos segun TheIntroDB (segundos)
		self.credits_checked = False
		self.traktCredentials = trakt.getTraktCredentialsInfo()
		# v1.0.18: cache SIMKL creds the same way Trakt does, to avoid checking on every event.
		self.simklCredentials = simkl.getSimklCredentialsInfo()
		# v1.0.37: MDBList scrobbling now lives in-plugin too (no external service).
		self.mdblistCredentials = mdblist.getMDBListScrobbleInfo()
		# v1.0.86: cuarto servicio de tracking, autonomo como los otros tres.
		self.punchplayCredentials = punchplay.getPunchPlayScrobbleInfo()
		# v1.0.99: quinto servicio de tracking, autonomo como los otros cuatro.
		self.wetrakrCredentials = wetrakr.getWeTrakrScrobbleInfo()
		self.subtitletime = None

	def play_source(self, title, year, season, episode, imdb, tmdb, tvdb, url, meta, debridPackCall=False):
		try:
			from sys import argv # some functions like ActivateWindow() throw invalid handle less this is imported here.
			if not url: raise Exception
			self.media_type = 'movie' if season is None or episode is None else 'episode'
			self.title, self.year = title, str(year)
			if self.media_type == 'movie':
				self.name, self.season, self.episode = '%s (%s)' % (title, self.year), None, None
			elif self.media_type == 'episode':
				self.name, self.season, self.episode = '%s S%02dE%02d' % (title, int(season), int(episode)), '%01d' % int(season), '%01d' % int(episode)
			self.imdb, self.tmdb, self.tvdb = imdb or '', tmdb or '', tvdb or ''

			self.ids = {'imdb': self.imdb, 'tmdb': self.tmdb, 'tvdb': self.tvdb}
## - compare meta received to database and use largest(eventually switch to a request to fetch missing db meta for item)
			self.imdb_user = getSetting('imdb.user').replace('ur', '')
			self.tmdb_key = getSetting('tmdb.api.key')
			if not self.tmdb_key: self.tmdb_key = app_keys.get('tmdb')
			if self.media_type == 'episode': self.user = str(self.imdb_user)
			else: self.user = str(self.tmdb_key)
			self.lang = control.apiLanguage()['tvdb']
			meta1 = dict((k, v) for k, v in iter(meta.items()) if v is not None and v != '') if meta else None
			meta2 = fetch_metacache([{'imdb': self.imdb, 'tmdb': self.tmdb, 'tvdb': self.tvdb}], self.lang, self.user)[0]
			if meta2 != self.ids: meta2 = dict((k, v) for k, v in iter(meta2.items()) if v is not None and v != '')
			if meta1 is not None:
				try:
					if len(meta2) > len(meta1):
						meta2.update(meta1)
						meta = meta2
					else: meta = meta1
				except: log_utils.error()
			else: meta = meta2 if meta2 != self.ids else meta1
##################
			self.poster = meta.get('poster') if meta else ''
			self.fanart = meta.get('fanart') if meta else ''
			self.meta = meta
			poster, thumb, season_poster, fanart, banner, clearart, clearlogo, discart, meta = self.getMeta(meta)
			self.offset = Bookmarks().get(name=self.name, imdb=imdb, tmdb=tmdb, tvdb=tvdb, season=season, episode=episode, year=self.year, runtime=meta.get('duration') if meta else 0)

			if self.offset == '-1':
				log_utils.log('User requested playback cancel', level=log_utils.LOGDEBUG)
				control.notification(message=32328)
				return control.cancelPlayback()

						# URL validity check (optional)
			try:
				if getSetting('validate.source.urls') == 'true':
					from resources.lib.modules import urlcheck
					if not urlcheck.check_url_validity(url):
						log_utils.log('Rejected invalid URL (player.play_source): %s' % url, level=log_utils.LOGWARNING)
						return control.cancelPlayback()
			except Exception:
				pass

			# ── Stream optimizations (instant seek / no re-probe) ──────────────
			url = _add_stream_headers(url)
			# ───────────────────────────────────────────────────────────────────
			item = control.item(path=url)
			if self.media_type == 'episode':
				item.setArt({'tvshow.clearart': clearart, 'tvshow.clearlogo': clearlogo, 'tvshow.discart': discart, 'thumb': thumb, 'tvshow.poster': season_poster, 'season.poster': season_poster, 'tvshow.fanart': fanart})
			else:
				item.setArt({'clearart': clearart, 'clearlogo': clearlogo, 'discart': discart, 'thumb': thumb, 'poster': poster, 'fanart': fanart})
			control.infoTagger(item, self.meta)
			# Optional: put the scores and what the release claims at the head
			# of the synopsis, the one field every skin draws during playback.
			# Off by default.
			try:
				from resources.lib.modules import release_info
				release_info.announce()
				release_info.attach_to_plot(item, self.meta)
				release_info.forget()
			except Exception:
				log_utils.error()
			item.setProperty('IsPlayable', 'true')
			item.setContentLookup(False)                  # no re-probe on seek
			item.setMimeType(_detect_mime(url))           # Kodi knows format instantly
			# Save playback metadata for SubtitlePlayer BEFORE resolve() — script dies after resolve()
			homeWindow.setProperty('luc_kodi.sub.title', self.title or '')
			homeWindow.setProperty('luc_kodi.sub.year', self.year or '')
			homeWindow.setProperty('luc_kodi.sub.imdb', self.imdb or '')
			homeWindow.setProperty('luc_kodi.sub.season', self.season or '')
			homeWindow.setProperty('luc_kodi.sub.episode', self.episode or '')
			_next_ep_direct = homeWindow.getProperty('luc_kodi.next_ep_direct') == 'true'
			_bingie_direct = homeWindow.getProperty('luc_kodi.bingie_direct') == 'true'
			# NO borrar next_ep_direct aquí — onAVStarted lo borrará cuando el video arranque (evita FALLBACK doble búsqueda)
			if debridPackCall or _next_ep_direct or _bingie_direct:
				# debridPack, next-episode-dialog y Bingie UI usan player.play() directo.
				# Bingie lanza la reproducción con RunPlugin desde una ventana custom,
				# por lo que argv[1] es un handle inválido y setResolvedUrl() no haría nada.
				homeWindow.clearProperty('luc_kodi.bingie_direct')
				control.player.play(url, item)
			else:
				control.resolve(int(argv[1]), True, item, self.meta)
			homeWindow.setProperty('script.trakt.ids', jsdumps(self.ids))
			self.keepAlive()
			homeWindow.clearProperty('script.trakt.ids')
		except:
			log_utils.error()
			return control.cancelPlayback()

	def getMeta(self, meta):
		try:
			if not meta or ('videodb' in control.infoLabel('ListItem.FolderPath')): raise Exception()
			poster = meta.get('poster3') or meta.get('poster2') or meta.get('poster') #poster2 and poster3 may not be passed anymore
			thumb = meta.get('thumb')
			thumb = thumb or poster or control.addonThumb()
			season_poster = meta.get('season_poster') or poster
			fanart = meta.get('fanart')
			banner = meta.get('banner')
			clearart = meta.get('clearart')
			clearlogo = meta.get('clearlogo')
			discart = meta.get('discart')
			if 'mediatype' not in meta:
				meta.update({'mediatype': 'episode' if self.episode else 'movie'})
				if self.episode: meta.update({'tvshowtitle': self.title, 'season': self.season, 'episode': self.episode})
			return (poster, thumb, season_poster, fanart, banner, clearart, clearlogo, discart, meta)
		except: log_utils.error()
		try:
			def cleanLibArt(art):
				from urllib.parse import unquote
				if not art: return ''
				art = unquote(art.replace('image://', ''))
				if art.endswith('/'): art = art[:-1]
				return art
			def sourcesDirMeta(metadata): # pass player minimal meta needed from lib pull
				if not metadata: return metadata
				allowed = ['mediatype', 'imdb', 'tmdb', 'tvdb', 'poster', 'season_poster', 'fanart', 'banner', 'clearart', 'clearlogo', 'discart', 'thumb', 'title', 'tvshowtitle', 'year', 'premiered', 'rating', 'plot', 'duration', 'mpaa', 'season', 'episode', 'castandrole']
				return {k: v for k, v in iter(metadata.items()) if k in allowed}
			poster, thumb, season_poster, fanart, banner, clearart, clearlogo, discart, meta = '', '', '', '', '', '', '', '', {'title': self.name}
			if self.media_type != 'movie': raise Exception()
			# do not add IMDBNUMBER as tmdb scraper puts their id in the key value
			meta = control.jsonrpc('{"jsonrpc": "2.0", "method": "VideoLibrary.GetMovies", "params": {"filter":{"or": [{"field": "year", "operator": "is", "value": "%s"}, {"field": "year", "operator": "is", "value": "%s"}, {"field": "year", "operator": "is", "value": "%s"}]}, "properties" : ["title", "originaltitle", "uniqueid", "year", "premiered", "genre", "studio", "country", "runtime", "rating", "votes", "mpaa", "director", "writer", "cast", "plot", "plotoutline", "tagline", "thumbnail", "art", "file"]}, "id": 1}' % (self.year, str(int(self.year) + 1), str(int(self.year) - 1)))
			meta = jsloads(meta)['result']['movies']
			meta = [i for i in meta if (i.get('uniqueid', []).get('imdb', '') == self.imdb) or (i.get('uniqueid', []).get('unknown', '') == self.imdb)] # scraper now using "unknown"
			if meta: meta = meta[0]
			else: raise Exception()
			if 'mediatype' not in meta: meta.update({'mediatype': 'movie'})
			if 'duration' not in meta: meta.update({'duration': meta.get('runtime')}) # Trakt scrobble resume needs this for lib playback
			if 'castandrole' not in meta: meta.update({'castandrole': [(i['name'], i['role']) for i in meta.get('cast')]})
			thumb = cleanLibArt(meta.get('art').get('thumb', ''))
			poster = cleanLibArt(meta.get('art').get('poster', '')) or self.poster
			fanart = cleanLibArt(meta.get('art').get('fanart', '')) or self.fanart
			banner = cleanLibArt(meta.get('art').get('banner', '')) # not sure this is even used by player
			clearart = cleanLibArt(meta.get('art').get('clearart', ''))
			clearlogo = cleanLibArt(meta.get('art').get('clearlogo', ''))
			discart = cleanLibArt(meta.get('art').get('discart'))
			if 'plugin' not in control.infoLabel('Container.PluginName'):
				self.DBID = meta.get('movieid')
			meta = sourcesDirMeta(meta)
			return (poster, thumb, '', fanart, banner, clearart, clearlogo, discart, meta)
		except: log_utils.error()
		try:
			if self.media_type != 'episode': raise Exception()
			# do not add IMDBNUMBER as tmdb scraper puts their id in the key value
			show_meta = control.jsonrpc('{"jsonrpc": "2.0", "method": "VideoLibrary.GetTVShows", "params": {"filter":{"or": [{"field": "year", "operator": "is", "value": "%s"}, {"field": "year", "operator": "is", "value": "%s"}, {"field": "year", "operator": "is", "value": "%s"}]}, "properties" : ["title", "originaltitle", "uniqueid", "mpaa", "year", "genre", "runtime", "thumbnail", "file"]}, "id": 1}' % (self.year, str(int(self.year)+1), str(int(self.year)-1)))
			show_meta = jsloads(show_meta)['result']['tvshows']
			show_meta = [i for i in show_meta if i['uniqueid']['imdb'] == self.imdb]
			show_meta = [i for i in show_meta if (i.get('uniqueid', []).get('imdb', '') == self.imdb) or (i.get('uniqueid', []).get('unknown', '') == self.imdb)] # scraper now using "unknown"
			if show_meta: show_meta = show_meta[0]
			else: raise Exception()
			tvshowid = show_meta['tvshowid']
			meta = control.jsonrpc('{"jsonrpc": "2.0", "method": "VideoLibrary.GetEpisodes", "params":{"tvshowid": %d, "filter":{"and": [{"field": "season", "operator": "is", "value": "%s"}, {"field": "episode", "operator": "is", "value": "%s"}]}, "properties": ["showtitle", "title", "season", "episode", "firstaired", "runtime", "rating", "director", "writer", "cast", "plot", "thumbnail", "art", "file"]}, "id": 1}' % (tvshowid, self.season, self.episode))
			meta = jsloads(meta)['result']['episodes']
			if meta: meta = meta[0]
			else: raise Exception()
			if 'mediatype' not in meta: meta.update({'mediatype': 'episode'})
			if 'tvshowtitle' not in meta: meta.update({'tvshowtitle': meta.get('showtitle')})
			if 'castandrole' not in meta: meta.update({'castandrole': [(i['name'], i['role']) for i in meta.get('cast')]})
			if 'genre' not in meta: meta.update({'genre': show_meta.get('genre')})
			if 'duration' not in meta: meta.update({'duration': meta.get('runtime')}) # Trakt scrobble resume needs this for lib playback but Kodi lib returns "0" for shows or episodes
			if 'mpaa' not in meta: meta.update({'mpaa': show_meta.get('mpaa')})
			if 'premiered' not in meta: meta.update({'premiered': meta.get('firstaired')})
			if 'year' not in meta: meta.update({'year': show_meta.get('year')}) # shows year not year episode aired
			thumb = cleanLibArt(meta.get('art').get('thumb', ''))
			season_poster = poster = cleanLibArt(meta.get('art').get('season.poster', '')) or self.poster
			fanart = cleanLibArt(meta.get('art').get('tvshow.fanart', '')) or self.poster
			banner = cleanLibArt(meta.get('art').get('tvshow.banner', '')) # not sure this is even used by player
			clearart = cleanLibArt(meta.get('art').get('tvshow.clearart', ''))
			clearlogo = cleanLibArt(meta.get('art').get('tvshow.clearlogo', ''))
			discart = cleanLibArt(meta.get('art').get('discart'))
			if 'plugin' not in control.infoLabel('Container.PluginName'):
				self.DBID = meta.get('episodeid')
			meta = sourcesDirMeta(meta)
			return (poster, thumb, season_poster, fanart, banner, clearart, clearlogo, discart, meta)
		except:
			log_utils.error()
			return (poster, thumb, season_poster, fanart, banner, clearart, clearlogo, discart, meta)

	def getWatchedPercent(self):
		if self.isPlayback():
			try:
				position = self.getTime()
				if position != 0: self.current_time = position
				total_length = self.getTotalTime()
				if total_length != 0: self.media_length = total_length
			except: pass
		current_position = self.current_time
		total_length = self.media_length
		watched_percent = 0
		if int(total_length) != 0:
			try:
				watched_percent = float(current_position) / float(total_length) * 100
				if watched_percent > 100: watched_percent = 100
			except: log_utils.error()
		return watched_percent

	def getRemainingTime(self):
		remaining_time = 0
		if self.isPlayback():
			try:
				current_position = self.getTime()
				remaining_time = int(self.media_length) - int(current_position)
			except: pass
		return remaining_time

	def keepAlive(self):
		pname = '%s.player.overlay' % control.addonInfo('id')
		homeWindow.clearProperty(pname)
		for i in range(0, 500):
			if self.isPlayback():
				control.closeAll()
				break
			xbmc.sleep(200)

		# ── Subtitles: invoke here because onAVStarted callbacks are unreliable
		# with reuseLanguageInvoker=true on Android (Kodi cannot dispatch callbacks
		# to a thread blocked in xbmc.sleep). Called once, right after the video
		# is confirmed playing — exactly as Umbrella does in its onAVStarted.
		try:
			import xbmcaddon as _xa
			_subs_enabled = _xa.Addon('plugin.video.luc_kodi').getSetting('subtitles')
		except:
			_subs_enabled = getSetting('subtitles')
		control.log('[ luc_kodi ] keepAlive subtitles setting: "%s"' % _subs_enabled, LOGINFO)

		if _subs_enabled == 'true':
			control.log('[ luc_kodi ] keepAlive — calling Subtitles().get()', LOGINFO)

			try:
				Subtitles().get(self.title, self.year, self.imdb, self.season, self.episode)
			except:
				log_utils.error()

		# ── Skip Intro / Recap / Preview (TheIntroDB) ──────────────────
		# Hilo daemon: consulta timestamps comunitarios por TMDb/IMDb id y
		# muestra la píldora "Skip Intro" (o auto-salta). Se lanza ANTES del
		# sleep(5000) para llegar a tiempo a recaps/previews que empiezan en
		# el segundo 0. El hilo espera él mismo a que el reloj avance y
		# captura su propio running_path; muere solo al parar o cambiar de
		# archivo, así que no interfiere con playlist_skip ni con playnext.
		try:
			from resources.lib.modules import skip_intro
			skip_intro.start(self)
		except:
			log_utils.error()

		# v2.0.03 — Kodi 22: bitrate en directo y cola del decodificador,
		# comparados al terminar con lo que la sonda leyo del fichero. En
		# Kodi 21 no arranca. Mismo patron de hilo que Skip Intro.
		try:
			from resources.lib.modules import playback_stats
			playback_stats.start(self)
		except:
			log_utils.error()

		xbmc.sleep(5000)
		playlist_skip = False
		try: running_path = self.getPlayingFile() # original video that playlist playback started with
		except: running_path = ''

		if playerWindow.getProperty('luc_kodi.playlistStart_position'): pass
		else:
			if control.playlist.size() > 1: playerWindow.setProperty('luc_kodi.playlistStart_position', str(control.playlist.getposition()))

		# Periodic SIMKL resume-point save: SIMKL no recibe el resume si Kodi
		# pasa al siguiente o se cierra de golpe (solo se guarda en onPlayBackStopped).
		# Enviamos /scrobble/pause cada _simkl_pause_interval segundos mientras se
		# reproduce, así el punto queda guardado pase lo que pase. Autónomo: solo SIMKL.
		_simkl_scrobble_on = (self.simklCredentials and getSetting('simkl.scrobble') == 'true')
		# v1.0.88: 90 s con AUTH V1, 300 s con AUTH V2 (cuota diaria por usuario,
		# 500 peticiones en el plan Free). Ver simkl.scrobble_keepalive_seconds().
		try: _simkl_pause_interval = simkl.scrobble_keepalive_seconds()
		except Exception: _simkl_pause_interval = 90
		_simkl_last_pause = time()

		# v1.0.79 Trakt: NO lleva pausa periodica, a proposito. En SIMKL y
		# MDBList mandar /scrobble/pause cada N segundos es gratis, pero en
		# Trakt "pause" es un estado PUBLICO: la web pasaria de "viendo ahora"
		# a "en pausa" al primer tick y se quedaria asi el resto de la
		# pelicula, tirando por tierra el directo que da /scrobble/start (que,
		# segun la API, no necesita reenvio: caduca solo al agotarse el tiempo
		# restante). La red de seguridad va donde de verdad se perdia la
		# sesion: al salir del bucle sin un onPlayBackStopped -- salto al
		# siguiente de la lista o apagado de Kodi -- y en la pausa real del
		# usuario (onPlayBackPaused).
		_trakt_scrobble_on = (self.traktCredentials and getSetting('trakt.scrobble') == 'true')

		# v1.0.37: igual que SIMKL, MDBList guarda el resume periódicamente
		# (/scrobble/pause) para no perderlo si Kodi salta de episodio o se
		# cierra de golpe. Intervalo configurable (mdblist.interval.seconds).
		_mdblist_scrobble_on = (self.mdblistCredentials and getSetting('mdblist.event.interval') != 'false')
		try:
			_mdblist_pause_interval = int(getSetting('mdblist.interval.seconds') or 60)
		except Exception:
			_mdblist_pause_interval = 60
		if _mdblist_pause_interval < 30:
			_mdblist_pause_interval = 30
		_mdblist_last_pause = time()

		# v1.0.86 PunchPlay: el latido periodico manda `progress`, NO `pause`.
		# PunchPlay tiene cinco acciones de playback y `pause` es un evento
		# REAL del usuario, no un keep-alive: mandarlo cada minuto dejaria la
		# cuenta marcada en pausa toda la pelicula (el mismo problema por el
		# que Trakt no lleva pausa periodica) y, segun su documentacion, un
		# pause sin sesion activa responde 409. `progress` actualiza la
		# posicion sin tocar el estado, que es justo lo que hace falta aqui.
		_punchplay_scrobble_on = self.punchplayCredentials
		try:
			_punchplay_interval = int(getSetting('punchplay.interval.seconds') or 60)
		except Exception:
			_punchplay_interval = 60
		if _punchplay_interval < 30:
			_punchplay_interval = 30
		_punchplay_last_beat = time()

		# v1.0.99 WeTrakr: el latido es un `start` repetido, que en su API solo
		# mueve el progreso (es como recibe un salto). Mantiene la barra de
		# "viendo ahora" y el punto de resume al dia si Kodi se cierra de golpe.
		_wetrakr_scrobble_on = self.wetrakrCredentials
		try:
			_wetrakr_interval = int(getSetting('wetrakr.interval.seconds') or 120)
		except Exception:
			_wetrakr_interval = 120
		if _wetrakr_interval < 60:
			_wetrakr_interval = 60
		_wetrakr_last_beat = time()

		while self.isPlayingVideo() and not control.monitor.abortRequested():
			try:
				if running_path != self.getPlayingFile(): # will not match if user hits "Next" so break from keepAlive()
					playlist_skip = True
					break

				try:
					self.current_time = self.getTime()
					self.media_length = self.getTotalTime()
				except: pass
				watcher = (self.getWatchedPercent() >= 85)
				property = homeWindow.getProperty(pname)

				# ── Guardado periódico de progreso en SIMKL (resume) ──────────
				# Rango de "a medias": desde el 5% (no el 15%) hasta el 80%.
				# El suelo del 15% no cuadraba con la propia sección "Mi
				# Progreso", que lista desde PROGRESS_MIN_PCT = 5: dejar un
				# episodio de 50 min al minuto 5 (10%) no guardaba resume
				# periódico y solo se salvaba si onPlayBackStopped llegaba a
				# dispararse. El guard de >180 s ya filtra el toque accidental.
				if _simkl_scrobble_on:
					try:
						_now = time()
						if (_now - _simkl_last_pause) >= _simkl_pause_interval and self.media_length:
							_pct = (self.current_time / self.media_length) * 100
							if 5 <= _pct < 80 and int(self.current_time) > 180:
								simkl.scrobblePause(imdb=self.imdb, tmdb=self.tmdb, tvdb=self.tvdb,
													season=self.season, episode=self.episode, watched_percent=_pct)
							_simkl_last_pause = _now
					except: pass

				# ── Guardado periódico de progreso en MDBList (resume) ────────
				# v1.0.37: mismo criterio que SIMKL. Rango 5%-80% desde 1.0.59
				# (MDBList lista sus sesiones pausadas desde progress > 0).
				# IMPORTANTE: bloque INDEPENDIENTE de SIMKL (MDBList autónomo).
				if _mdblist_scrobble_on:
					try:
						_now = time()
						if (_now - _mdblist_last_pause) >= _mdblist_pause_interval and self.media_length:
							_pct = (self.current_time / self.media_length) * 100
							if 5 <= _pct < 80 and int(self.current_time) > 180:
								mdblist.scrobblePause(imdb=self.imdb, tmdb=self.tmdb, tvdb=self.tvdb,
														season=self.season, episode=self.episode, watched_percent=_pct)
							_mdblist_last_pause = _now
					except: pass

				# ── Latido periodico de PunchPlay (progress) ──────────────────
				# Mismo suelo de 5% y guard de >180 s que SIMKL y MDBList, por
				# coherencia entre los cuatro servicios. Sin techo del 80%: en
				# PunchPlay el progreso alto no marca visto por si solo (eso lo
				# decide el `stop` con su watched_threshold), asi que seguir
				# latiendo hasta el final mantiene la barra de la web al dia.
				if _punchplay_scrobble_on:
					try:
						_now = time()
						if (_now - _punchplay_last_beat) >= _punchplay_interval and self.media_length:
							_pct = (self.current_time / self.media_length) * 100
							if _pct >= 5 and int(self.current_time) > 180:
								punchplay.scrobbleProgress(
									imdb=self.imdb, tmdb=self.tmdb, tvdb=self.tvdb,
									season=self.season, episode=self.episode,
									watched_percent=_pct, title=self.title, year=self.year,
									duration=self.media_length, position=self.current_time)
							_punchplay_last_beat = _now
					except: pass

				# ── Latido periodico de WeTrakr (start = mover progreso) ──────
				# Sin techo: por encima del 80% el start NO marca visto (eso solo
				# lo hace el stop), asi que se puede seguir latiendo hasta el final.
				if _wetrakr_scrobble_on:
					try:
						_now = time()
						if (_now - _wetrakr_last_beat) >= _wetrakr_interval and self.media_length:
							_pct = (self.current_time / self.media_length) * 100
							if 1 <= _pct < 100:
								wetrakr.scrobbleProgress(
									imdb=self.imdb, tmdb=self.tmdb, tvdb=self.tvdb,
									season=self.season, episode=self.episode,
									watched_percent=_pct, title=self.title, year=self.year)
							_wetrakr_last_beat = _now
					except: pass

				if self.media_type == 'movie':
					try:
						if watcher and property != '5':
							homeWindow.setProperty(pname, '5')
							playcount.markMovieDuringPlayback(self.imdb, '5')
					except: pass
					xbmc.sleep(2000)

				elif self.media_type == 'episode':
					try:
						if watcher and property != '5':
							homeWindow.setProperty(pname, '5')
							playcount.markEpisodeDuringPlayback(self.imdb, self.tvdb, self.season, self.episode, '5')
						# Pre-scrape / PlayNext popup removed — replaced by post-stop on-demand dialog
						# v1.0.91 (M2): pre-carga silenciosa de las fuentes del siguiente
						# episodio al pasar del 70%, para que Auto-Play del dialogo sea
						# inmediato. Una sola vez por episodio y en hilo daemon.
						if (not self.preScrape_triggered and self.enable_playnext and self.media_length
								and self.getWatchedPercent() >= 70):
							self.preScrape_triggered = True
							threading.Thread(target=self._prescrape_next_silent, daemon=True).start()
						# v1.0.98 (issue #2): inicio de los creditos (TheIntroDB), una
						# vez por episodio y en hilo, cuando ya va por la mitad.
						if (not self.credits_checked and self.enable_playnext and self.media_length
								and getSetting('playnext.credits') != 'false'
								and self.getWatchedPercent() >= 50):
							self.credits_checked = True
							threading.Thread(target=self._load_credits_mark, daemon=True).start()
						# v1.0.98 (issue #2): el popup sale ENCIMA de los creditos,
						# no con la reproduccion ya parada.
						if self._playnext_due():
							self._show_next_episode_overlay()
					except: log_utils.error()
					xbmc.sleep(1000)

			except:
				log_utils.error()
				xbmc.sleep(1000)
		homeWindow.clearProperty(pname)

		# v1.0.79 Trakt: el bucle puede terminar sin que llegue nunca un
		# onPlayBackStopped. Pasa en dos caminos reales: el usuario salta al
		# siguiente de la lista (playlist_skip rompe el while) y Kodi se esta
		# apagando (abortRequested). En ambos Trakt no recibia absolutamente
		# nada y el punto de reproduccion se perdia. Aqui se manda la pausa con
		# el ultimo progreso conocido, que es lo que alimenta Continue Watching
		# en trakt.tv.
		if _trakt_scrobble_on and (playlist_skip or control.monitor.abortRequested()):
			try:
				if self.media_length:
					_pct = (self.current_time / self.media_length) * 100
					if 1 <= _pct < 85 and int(self.current_time) > 60:
						trakt.scrobblePause(imdb=self.imdb, tmdb=self.tmdb, tvdb=self.tvdb,
											season=self.season, episode=self.episode, watched_percent=_pct)
			except: log_utils.error()

		# v1.0.86 PunchPlay: misma red de seguridad, pero se manda `stop`, no
		# `pause`. En PunchPlay un stop incompleto NO marca visto: crea
		# progreso reanudable, que es exactamente el estado correcto cuando el
		# usuario salta al siguiente episodio o Kodi se esta apagando. Ademas
		# cierra la sesion, y sin cerrarla el siguiente arranque reutilizaria
		# un playback_session_id que el backend ya considera viejo.
		if _punchplay_scrobble_on and (playlist_skip or control.monitor.abortRequested()):
			try:
				if self.media_length:
					_pct = (self.current_time / self.media_length) * 100
					if _pct >= 1 and int(self.current_time) > 60:
						punchplay.scrobbleStop(
							imdb=self.imdb, tmdb=self.tmdb, tvdb=self.tvdb,
							season=self.season, episode=self.episode, watched_percent=_pct,
							title=self.title, year=self.year,
							duration=self.media_length, position=self.current_time)
			except: log_utils.error()

		# v1.0.99 WeTrakr: misma red de seguridad que PunchPlay. Un `stop` por
		# debajo del 80% deja la sesion en pausa reanudable y por encima marca
		# visto: lo decide el servidor, que es lo correcto al saltar al
		# siguiente de la lista o al apagarse Kodi.
		if _wetrakr_scrobble_on and (playlist_skip or control.monitor.abortRequested()):
			try:
				if self.media_length:
					_pct = (self.current_time / self.media_length) * 100
					if _pct >= 1 and int(self.current_time) > 60:
						wetrakr.scrobbleStop(
							imdb=self.imdb, tmdb=self.tmdb, tvdb=self.tvdb,
							season=self.season, episode=self.episode, watched_percent=_pct,
							title=self.title, year=self.year)
			except: log_utils.error()

		if playlist_skip: pass
		else:
			# # self.onPlayBackEnded() # check, kodi may at times not issue "onPlayBackEnded" callback
			# if self.media_length - self.current_time > 60: # kodi may at times not issue "onPlayBackStopped" callback
			if (int(self.current_time) > 180 and (self.getWatchedPercent() < 85)): # kodi may at times not issue "onPlayBackStopped" callback
				self.playbackStopped_triggered = True
				self.onPlayBackStopped()
			# ── POST-STOP: Next Episode On-Demand Dialog ──────────────────────────────
			# Conditions to show the dialog:
			#   A) video ended naturally (onPlayBackEnded fired)          — always eligible
			#   B) user stopped manually after >=85% watched             — eligible
			#   C) stream had no duration (media_length=0) but ran >60s  — eligible (can't compute %)
			_watched_ok = (
				self.ended_naturally                                          # A
				or self.getWatchedPercent() >= 85                            # B
				or (self.media_length == 0 and int(self.current_time) > 60)  # C: stream sin duración
			)
			if self.playnext_choice is not None and self.playnext_target:
				# v1.0.98: ya se eligio en el popup de los creditos; se lanza sin
				# volver a preguntar.
				try:
					self._launch_next_episode(self.playnext_target[0], self.playnext_target[1], self.playnext_choice)
				except:
					log_utils.error()
			elif (self.media_type == 'episode'
					and self.enable_playnext
					and _watched_ok
					and not self.playnext_declined
					and not self.playnext_overlay_done
					and self.season is not None
					and self.episode is not None):
				try:
					# Final natural: lo avisa onPlayBackEnded o, como ese callback
					# no siempre llega en Android, el ultimo tiempo leido a <=10 s
					# del final. Tras una parada manual la cuenta atras solo cierra.
					_natural = bool(self.ended_naturally or (self.media_length
						and (self.media_length - self.current_time) <= 10))
					self._show_next_episode_dialog(natural_end=_natural)
				except:
					log_utils.error()
			# ─────────────────────────────────────────────────────────────────────────

	def _prescrape_next_silent(self):
		"""v1.0.91 (M2): scrape del siguiente episodio en segundo plano.
		Los argumentos se construyen EXACTAMENTE como llegan desde el dialogo
		de siguiente episodio (URL plugin:// -> parse_qsl, que convierte los
		vacios en None), porque la clave de providerscache se calcula con
		str() de esos nueve argumentos: si no coinciden, la pre-carga no sirve.
		No corre en aparatos de poca memoria ni si el siguiente no se ha
		emitido."""
		try:
			if getSetting('playnext.prescrape') == 'false': return
			from resources.lib.modules import device_profile, next_episode
			if device_profile.is_low(): return
			state, n_season, n_ep = next_episode.resolve(self.tmdb, self.season, self.episode)
			if state != next_episode.AIRED: return
			def _q(v):
				v = '' if v is None else str(v)
				return v if v else None
			show = _q(self.title or '')
			args = (show, _q(self.year or ''), _q(self.imdb or ''), _q(self.tmdb or ''), _q(self.tvdb or ''),
					str(n_season), str(n_ep), show, None)
			next_meta = dict(self.meta) if self.meta else {}
			for _k in ('thumb', 'plot', 'premiered', 'landscape'):
				next_meta.pop(_k, None)
			next_meta.update({'season': str(n_season), 'episode': str(n_ep), 'mediatype': 'episode', 'title': self.title or ''})
			from resources.lib.modules import sources as _sources
			from resources.lib.database import providerscache as _pc
			_t0 = time()
			items = _pc.get(_sources.Sources().getSources, 48, *(args + (next_meta, True)))
			log_utils.log('[ luc_kodi ] prescrape: S%02dE%02d ready, %d sources in %.1fs'
						  % (int(n_season), int(n_ep), len(items or []), time() - _t0), level=log_utils.LOGINFO)
		except:
			log_utils.error()

	def _playnext_action(self):
		"""Indice de playnext.default.action: 0 Play next, 1 Stop, 2 Pause and wait."""
		try: action = int(getSetting('playnext.default.action') or '0')
		except (TypeError, ValueError): action = 0
		return action if action in (0, 1, 2) else 0

	def _playnext_lead(self):
		"""Segundos antes del final a los que sale el popup (10-120, def. 30)."""
		try: lead = int(float(getSetting('playnext.lead') or 30))
		except (TypeError, ValueError): lead = 30
		return min(max(lead, 10), 120)

	def _load_credits_mark(self):
		"""v1.0.98: inicio de los creditos segun TheIntroDB. Se descarta si
		despues de los creditos hay mas episodio (escena post-creditos), si los
		creditos durarian mas de 10 minutos o si empiezan antes de la mitad:
		en esos casos manda la regla de los segundos antes del final."""
		try:
			length = float(self.media_length or 0)
			if length <= 0: return
			from resources.lib.modules import skip_intro
			seg = skip_intro.credits_segment(self.imdb, self.tmdb, self.season, self.episode, int(length * 1000))
			if not seg: return
			start, end = seg
			if end is not None and (length - end) > 30:
				control.log('[ luc_kodi ] playnext: credits end %.0fs before the end (post-credits scene), ignored' % (length - end), LOGINFO)
				return
			if start < length * 0.5 or (length - start) > 600 or (length - start) < 5:
				control.log('[ luc_kodi ] playnext: credits at %.0fs of %.0fs look wrong, ignored' % (start, length), LOGINFO)
				return
			self.credits_at = start
			control.log('[ luc_kodi ] playnext: credits start at %.0fs (%.0fs before the end)' % (start, length - start), LOGINFO)
		except:
			log_utils.error()

	def _playnext_due(self):
		"""True cuando toca sacar el popup: creditos empezados (TheIntroDB) o
		dentro de los ultimos N segundos. Nunca antes del 85%, el mismo umbral
		que marca el episodio como visto, para que pasar al siguiente desde el
		popup siempre cuente como visto en Kodi, Trakt, SIMKL, MDBList y
		PunchPlay."""
		if self.playnext_overlay_done or not self.enable_playnext: return False
		if self.media_type != 'episode' or self.season is None or self.episode is None: return False
		length = float(self.media_length or 0)
		if length < 120: return False
		remaining = length - float(self.current_time or 0)
		if remaining <= 0: return False
		if self.getWatchedPercent() < 85: return False
		if self.credits_at and self.current_time >= self.credits_at: return True
		return remaining <= self._playnext_lead()

	def _next_episode_target(self):
		"""(temporada, episodio) del siguiente que se puede ver, o None."""
		from resources.lib.modules import next_episode as _nextep
		_ne_state, next_season, next_ep = _nextep.resolve(self.tmdb, self.season, self.episode)
		if _ne_state in (_nextep.UNAIRED, _nextep.ENDED):
			control.log('[ luc_kodi ] next episode: none to offer after S%02dE%02d (%s)' % (int(self.season), int(self.episode), _ne_state), LOGINFO)
			return None
		return int(next_season), int(next_ep)

	def _next_dialog(self, next_season, next_ep, **kwargs):
		from resources.lib.windows.next_episode_dialog import NextEpisodeDialog
		# Pasar landscape/thumb del episodio actual como contexto visual del diálogo.
		# self.meta tiene los datos del ep que acaba de terminar — el landscape
		# es el still del episodio actual, útil como fondo del card en 2160p.
		meta = self.meta or {}
		_ep_thumb = meta.get('landscape', '') or meta.get('thumb', '')
		dialog = NextEpisodeDialog(
			'next_episode_dialog.xml',
			control.addonPath(control.addonId()),
			show_title=self.title or '',
			ep_label='S%02dE%02d' % (next_season, next_ep),
			fanart=meta.get('fanart', ''),
			clearlogo=meta.get('clearlogo', ''),
			thumb=_ep_thumb,
			timeout_action=self._playnext_action(),
			**kwargs
		)
		ret = dialog.run()
		del dialog
		return ret

	def _show_next_episode_overlay(self):
		"""v1.0.98 (issue #2): popup de siguiente episodio sobre los creditos.
		La cuenta atras sigue al video; al llegar a cero aplica
		playnext.default.action. Con Auto-Play o Choose Source se para el
		episodio actual (ya marcado como visto, ver _playnext_due) y el bloque
		post-stop de keepAlive lanza el siguiente sin volver a preguntar."""
		self.playnext_overlay_done = True
		try:
			target = self._next_episode_target()
			if not target: return
			remaining = float(self.media_length) - float(self.current_time)
			countdown = int(max(min(remaining, self._playnext_lead()), 1))
			try: running_path = self.getPlayingFile()
			except: running_path = ''
			control.log('[ luc_kodi ] playnext: popup %.0fs before the end (%s), countdown %ds, action %d'
						  % (remaining, 'credits' if (self.credits_at and self.current_time >= self.credits_at) else 'lead time',
							 countdown, self._playnext_action()), LOGINFO)
			ret = self._next_dialog(target[0], target[1], overlay=True, countdown=countdown, running_path=running_path)
			control.log('[ luc_kodi ] playnext: popup result %s' % ret, LOGINFO)
			if ret in (1, 2):
				self.playnext_choice = '1' if ret == 1 else '0'
				self.playnext_target = target
			else:
				self.playnext_declined = True
			if ret in (1, 2, 3) and self.isPlayingVideo():
				self.stop()
		except:
			log_utils.error()

	def _show_next_episode_dialog(self, natural_end=True):
		"""
		Post-stop on-demand next-episode dialog.
		Sale cuando el popup de los creditos no llego a mostrarse (parada
		manual pasado el 85%, video sin duracion). Si el usuario confirma,
		se lanza el siguiente con RunPlugin.
		"""
		try:
			# v1.0.90: el siguiente se decide con los datos de temporada de TMDb
			# (fin de temporada -> T+1 E01; sin emitir o fin de serie -> nada).
			target = self._next_episode_target()
			if not target: return
			ret = self._next_dialog(target[0], target[1], overlay=False, natural_end=natural_end, countdown=30)
			# ret: 1=Auto-Play, 2=Choose Source, 0=Not Now/timeout
			if ret not in (1, 2):
				return
			self._launch_next_episode(target[0], target[1], '1' if ret == 1 else '0')
		except:
			log_utils.error()

	def _launch_next_episode(self, next_season, next_ep, select):
		"""Lanza el siguiente episodio. select: '1' Auto-Play, '0' Choose Source."""
		try:
			show_title  = self.title or ''
			# Build meta for the next episode (strip per-episode fields)
			next_meta = dict(self.meta) if self.meta else {}
			next_meta['season']    = str(next_season)
			next_meta['episode']   = str(next_ep)
			next_meta['mediatype'] = 'episode'
			# v1.0.18 FIX: strip per-episode fields BUT preserve 'title' as the show
			# title. Previously 'title' was popped entirely, leaving meta['title']=None,
			# which propagated to sources.sourcesResolve -> torbox.resolve_magnet ->
			# title.lower() AttributeError -> every E02 magnet failed -> "no streams".
			# Other debrids (RD/AD/PM) don't call title.lower() so they didn't expose
			# this. We don't know the next episode's real title yet, so we use the
			# show title as a safe placeholder — it's what the URL `&title=` arg
			# already passes downstream.
			for _k in ('thumb', 'plot', 'premiered', 'landscape'):
				next_meta.pop(_k, None)
			next_meta['title'] = show_title

			# Usar RunPlugin con handle=-1 es correcto para lanzar sin bloquear.
			# play_source() detecta next_ep_direct=true y usa control.player.play()
			# en vez de setResolvedUrl, evitando el error de handle inválido.
			# La playlist se limpia aquí primero para evitar "skipping unplayable item".
			from json import dumps as jsdumps
			from urllib.parse import quote_plus
			control.playlist.clear()  # limpiar playlist antes de lanzar siguiente ep
			homeWindow.setProperty('luc_kodi.next_ep_direct', 'true')
			sysmeta  = quote_plus(jsdumps(next_meta))
			systitle = quote_plus(show_title)
			plugin_url = (
				'plugin://plugin.video.luc_kodi/?action=play_Item'
				'&title=%s&year=%s&imdb=%s&tmdb=%s&tvdb=%s'
				'&season=%s&episode=%s&tvshowtitle=%s&premiered=&meta=%s&select=%s'
			) % (
				systitle, self.year or '',
				self.imdb or '', self.tmdb or '', self.tvdb or '',
				next_season, next_ep, systitle, sysmeta, select
			)
			control.log('[ luc_kodi ] playnext: launching S%02dE%02d (%s)' % (int(next_season), int(next_ep), 'auto-play' if select == '1' else 'choose source'), LOGINFO)
			xbmc.executebuiltin('RunPlugin(%s)' % plugin_url)
		except:
			log_utils.error()

	def _queue_next_ep_if_needed(self):
		"""Daisy-chain: add the next episode to the playlist after the current one starts.
		Called once per episode from keepAlive(). This lets PlayNext (popup + prescrape)
		work correctly without interfering with setResolvedUrl for the current episode.

		Logic: only add when we are at the LAST position in the playlist, so we don't
		duplicate items and correctly extend the chain episode by episode.
		"""
		try:
			if not self.enable_playnext or self.media_type != 'episode':
				return
			pos  = control.playlist.getposition()
			size = control.playlist.size()
			# Already has a queued next item → nothing to do
			if size > 0 and pos < (size - 1):
				return
			from json import dumps as jsdumps
			from urllib.parse import quote_plus
			# v1.0.90: el siguiente se decide con los datos de temporada de TMDb
			# (fin de temporada -> T+1 E01; sin emitir o fin de serie -> nada).
			from resources.lib.modules import next_episode as _nextep
			_ne_state, next_season, next_ep = _nextep.resolve(self.tmdb, self.season, self.episode)
			if _ne_state in (_nextep.UNAIRED, _nextep.ENDED):
				log_utils.log('[ luc_kodi ] next episode: none to offer after S%02dE%02d (%s)' % (int(self.season), int(self.episode), _ne_state), level=log_utils.LOGINFO)
				return
			# Build minimal meta for the next episode (show-level info + updated S/E).
			# The accurate episode title / premiered come from the prescrape path;
			# here we only need enough for the PlayNext popup to identify the episode.
			next_meta = dict(self.meta) if self.meta else {}
			next_meta['season']    = str(next_season)
			next_meta['episode']   = str(next_ep)
			next_meta['mediatype'] = 'episode'
			# v1.0.18 FIX: see _show_next_episode_dialog — don't pop 'title' (was leaving
			# meta['title']=None which broke torbox.resolve_magnet). Use show title.
			for _k in ('thumb', 'plot', 'premiered', 'landscape'):
				next_meta.pop(_k, None)
			next_meta['title'] = self.title or ''
			title_str      = self.title or ''
			systvshowtitle = quote_plus(title_str)
			sysmeta        = quote_plus(jsdumps(next_meta))
			next_url = (
				'plugin://plugin.video.luc_kodi/?action=play_Item'
				'&title=%s&year=%s&imdb=%s&tmdb=%s&tvdb=%s'
				'&season=%s&episode=%s&tvshowtitle=%s&premiered=&meta=%s&select=1'
			) % (
				systvshowtitle, self.year or '',
				self.imdb or '', self.tmdb or '', self.tvdb or '',
				next_season, next_ep, systvshowtitle, sysmeta
			)
			li = control.item(label='%s S%02dE%02d' % (title_str, next_season, next_ep), offscreen=True)
			li.setProperty('IsPlayable', 'true')
			control.playlist.add(url=next_url, listitem=li)
			# Also store URL in playerWindow so PlayNextXML can call it directly
			# (needed because setResolvedUrl playback is NOT playlist-based)
			playerWindow.setProperty('luc_kodi.nextEpisode_playUrl', next_url)
			log_utils.log(
				'[ plugin.video.luc_kodi ] PlayNext: queued S%02dE%02d to playlist (pos=%d size=%d→%d)'
				% (next_season, next_ep, pos, size, control.playlist.size()),
				level=log_utils.LOGDEBUG
			)
		except:
			log_utils.error()

	def isPlayingFile(self):
		try:
			return not self.getPlayingFile().startswith('plugin://')
		except:
			return False

	def isPlayback(self):
		# Kodi often starts playback where isPlaying() is true and isPlayingVideo() is false, since the video loading is still in progress, whereas the play is already started.
		return self.isPlaying() and self.isPlayingVideo() and self.getTime() >= 0

	def libForPlayback(self):
		if self.DBID is None: return
		try:
			if self.media_type == 'movie':
				rpc = '{"jsonrpc": "2.0", "method": "VideoLibrary.SetMovieDetails", "params": {"movieid": %s, "playcount": 1 }, "id": 1 }' % str(self.DBID)
			elif self.media_type == 'episode':
				rpc = '{"jsonrpc": "2.0", "method": "VideoLibrary.SetEpisodeDetails", "params": {"episodeid": %s, "playcount": 1 }, "id": 1 }' % str(self.DBID)
			control.jsonrpc(rpc)
		except: log_utils.error()

### Kodi player callback methods ###
	def onAVStarted(self): # Kodi docs suggests "Use onAVStarted() instead of onPlayBackStarted() as of v18"
		# Limpiar el flag next_ep_direct ahora que el video arrancó de verdad.
		# No lo limpiamos antes para que el FALLBACK del ep anterior no dispare una 2ª búsqueda.
		homeWindow.clearProperty('luc_kodi.next_ep_direct')
		for i in range(0, 500):
			if self.isPlayback():
				control.closeAll()
				break
			else: control.sleep(200)
		# MDBList Continue Watching: if Bookmarks().get() returned '0', check our
		# window property for a direct resume override (set by mdblist_menus.py)
		if self.offset == '0':
			try:
				_mdb_key = 'mdblist.resume.%s.%s.%s' % (
					self.imdb or self.tmdb or '',
					self.season or '0',
					self.episode or '0',
				)
				_mdb_sec = homeWindow.getProperty(_mdb_key)
				if _mdb_sec:
					self.offset = str(float(_mdb_sec))
					homeWindow.clearProperty(_mdb_key)
			except: pass
		if self.offset != '0' and self.playback_resumed is False:
			control.sleep(200)
			if getSetting('trakt.scrobble') == 'true' and getSetting('resume.source') == '1': # re-adjust the resume point since dialog is based on meta runtime vs. getTotalTime() and inaccurate
				try:
					total_time = self.getTotalTime()
					progress = float(fetch_bookmarks(self.imdb, self.tmdb, self.tvdb, self.season, self.episode))
					self.offset = (progress / 100) * total_time
				except: pass
			# seekTime() needs a real number. Bookmarks().get() returns the offset
			# as a STRING, and unless the trakt-resume branch above converted it,
			# passing a str raised "TypeError: must be real number, not str" — the
			# seek failed and playback always restarted from the beginning. Coerce
			# to float defensively so resume works in every path.
			try:
				_seek = float(self.offset)
			except (TypeError, ValueError):
				_seek = 0
			if _seek > 0:
				self.seekTime(_seek)
			self.playback_resumed = True
		
		# v1.0.79 TRAKT: aqui se llamaba a scrobbleReset(), que hace un
		# DELETE /sync/playback/{id} -- borraba el punto de resume en Trakt
		# nada mas arrancar y no escribia NADA a cambio, asi que parar antes
		# del suelo de set_scrobble dejaba la sesion perdida por completo.
		# /scrobble/start hace ese mismo borrado por si solo Y ademas pone el
		# estado "viendo ahora" en trakt.tv, que es lo que faltaba: hasta ahora
		# el addon solo hablaba con Trakt AL PARAR. Se manda el progreso real
		# de arranque (resume incluido) para que la barra de la web salga bien.
		if self.traktCredentials and getSetting('trakt.scrobble') == 'true':
			try:
				_start_pct = 0
				try:
					_total = self.getTotalTime()
					if _total: _start_pct = (float(self.offset) / _total) * 100
				except Exception: _start_pct = 0
				control.log('[ luc_kodi ] onAVStarted — calling trakt.scrobbleStart()', LOGINFO)
				trakt.scrobbleStart(imdb=self.imdb, tmdb=self.tmdb, tvdb=self.tvdb,
									season=self.season, episode=self.episode, watched_percent=_start_pct)
			except Exception: log_utils.error()
		# v1.0.21 SIMKL: fire /scrobble/start so the user's "Watching now" shows up,
		# and an optional /scrobble/checkin if the user enabled the fire-and-forget fallback.
		# Same pattern Umbrella uses (its onAVStarted line 651). Works when the Player
		# instance is kept alive by keepAlive() — sources.py playItem now properly
		# routes through play_source for both auto and manual source selection paths.
		_simkl_scrobble_setting = getSetting('simkl.scrobble')
		if self.simklCredentials and (_simkl_scrobble_setting == 'true'):
			try:
				control.log('[ luc_kodi ] onAVStarted — calling simkl.scrobbleStart()', LOGINFO)
				simkl.scrobbleStart(imdb=self.imdb, tmdb=self.tmdb, tvdb=self.tvdb,
									season=self.season, episode=self.episode, watched_percent=0)
				if getSetting('simkl.scrobble.checkin') == 'true':
					simkl.scrobbleCheckin(imdb=self.imdb, tmdb=self.tmdb, tvdb=self.tvdb,
										  season=self.season, episode=self.episode)
			except Exception:
				log_utils.error()
		# v1.0.37: MDBList /scrobble/start para que aparezca "viendo ahora"
		# y se cree la sesión de resume. INDEPENDIENTE de SIMKL (MDBList autónomo).
		if self.mdblistCredentials and getSetting('mdblist.event.start') != 'false':
			try:
				control.log('[ luc_kodi ] onAVStarted — calling mdblist.scrobbleStart()', LOGINFO)
				mdblist.scrobbleStart(imdb=self.imdb, tmdb=self.tmdb, tvdb=self.tvdb,
									  season=self.season, episode=self.episode, watched_percent=0)
			except Exception:
				log_utils.error()
		# v1.0.86 PunchPlay: /playback/start abre la sesion y pone el estado
		# "viendo ahora". Se manda el progreso REAL de arranque (el resume
		# incluido) para que la barra de la web salga bien desde el primer
		# evento, igual que se hace con Trakt desde la v1.0.79.
		if self.punchplayCredentials:
			try:
				_pp_pct = 0
				try:
					_pp_total = self.getTotalTime()
					if _pp_total: _pp_pct = (float(self.offset) / _pp_total) * 100
				except Exception: _pp_pct = 0
				control.log('[ luc_kodi ] onAVStarted — calling punchplay.scrobbleStart()', LOGINFO)
				punchplay.scrobbleStart(imdb=self.imdb, tmdb=self.tmdb, tvdb=self.tvdb,
										season=self.season, episode=self.episode,
										watched_percent=_pp_pct, title=self.title, year=self.year,
										duration=self.getTotalTime(), position=self.offset)
			except Exception:
				log_utils.error()
		# v1.0.99 WeTrakr: /scrobble/start pone "viendo ahora" con el progreso
		# real de arranque (resume incluido). La respuesta trae el episodio que
		# WeTrakr resolvio; si no coincide, wetrakr.py cancela la sesion.
		if self.wetrakrCredentials:
			try:
				_wt_pct = 0
				try:
					_wt_total = self.getTotalTime()
					if _wt_total: _wt_pct = (float(self.offset) / _wt_total) * 100
				except Exception: _wt_pct = 0
				control.log('[ luc_kodi ] onAVStarted — calling wetrakr.scrobbleStart()', LOGINFO)
				wetrakr.scrobbleStart(imdb=self.imdb, tmdb=self.tmdb, tvdb=self.tvdb,
									  season=self.season, episode=self.episode,
									  watched_percent=_wt_pct, title=self.title, year=self.year)
			except Exception:
				log_utils.error()
		# Double-check via xbmcaddon direct API in case settings cache isn't updated yet
		try:
			import xbmcaddon as _xa
			_subs_enabled = _xa.Addon('plugin.video.luc_kodi').getSetting('subtitles')
		except:
			_subs_enabled = getSetting('subtitles')
		control.log('[ luc_kodi ] subtitles setting value: "%s"' % _subs_enabled, LOGINFO)

		if _subs_enabled == 'true':
			control.log('[ luc_kodi ] subtitles enabled — calling Subtitles().get()', LOGINFO)

			try:
				Subtitles().get(self.title, self.year, self.imdb, self.season, self.episode)
			except:
				log_utils.error()
		xbmc.log('[ plugin.video.luc_kodi ] onAVStarted callback', LOGINFO)
		control.log('[ plugin.video.luc_kodi ] onAVStarted callback', LOGINFO)


	def _live_percent(self):
		"""Progreso actual en %, leido del reproductor y no del ultimo tick del
		bucle (que puede llevar hasta 2 s de retraso)."""
		try:
			total = self.getTotalTime() or self.media_length
			cur = self.getTime()
			if not total: return None, 0
			return (cur / total) * 100, cur
		except Exception:
			if not self.media_length: return None, 0
			return (self.current_time / self.media_length) * 100, self.current_time


	def onPlayBackPaused(self):
		# v1.0.86 PunchPlay: va PRIMERO y en su propio try porque el bloque de
		# Trakt de abajo empieza con un `return` cuando Trakt esta apagado.
		# Colocarlo despues lo dejaria colgando de que el usuario use Trakt, y
		# los cuatro servicios de tracking son independientes entre si.
		# Aqui `pause` es un evento REAL del usuario, que es exactamente para
		# lo que PunchPlay tiene la accion.
		try:
			if self.punchplayCredentials:
				_pct, _cur = self._live_percent()
				if _pct is not None and 1 <= _pct < 100 and int(_cur) > 60:
					punchplay.scrobblePause(
						imdb=self.imdb, tmdb=self.tmdb, tvdb=self.tvdb,
						season=self.season, episode=self.episode, watched_percent=_pct,
						title=self.title, year=self.year,
						duration=self.media_length, position=_cur)
		except: log_utils.error()
		# v1.0.99 WeTrakr: pausa real del usuario, antes del bloque de Trakt por
		# el mismo motivo que PunchPlay (ese bloque sale con return).
		try:
			if self.wetrakrCredentials:
				_pct, _cur = self._live_percent()
				if _pct is not None and 1 <= _pct < 100 and int(_cur) > 60:
					wetrakr.scrobblePause(
						imdb=self.imdb, tmdb=self.tmdb, tvdb=self.tvdb,
						season=self.season, episode=self.episode, watched_percent=_pct,
						title=self.title, year=self.year)
		except: log_utils.error()
		# v1.0.79: el addon no reaccionaba a una pausa real en NINGUN servicio.
		# Es el momento exacto que describe la API de Trakt y donde mas
		# sesiones se abandonan, asi que aqui se guarda el punto en
		# /sync/playback sin depender de que llegue luego un onPlayBackStopped.
		try:
			if not (self.traktCredentials and getSetting('trakt.scrobble') == 'true'): return
			_pct, _cur = self._live_percent()
			if _pct is None: return
			if 1 <= _pct < 85 and int(_cur) > 60:
				trakt.scrobblePause(imdb=self.imdb, tmdb=self.tmdb, tvdb=self.tvdb,
									season=self.season, episode=self.episode, watched_percent=_pct)
		except: log_utils.error()
		control.log('[ plugin.video.luc_kodi ] onPlayBackPaused callback', LOGINFO)


	def onPlayBackResumed(self):
		# v1.0.86 PunchPlay: mismo motivo de orden que en onPlayBackPaused.
		# PunchPlay tiene accion `resume` propia, asi que no hay que reutilizar
		# `start` para des-pausar como se hace con Trakt: un `start` nuevo
		# abriria sesion nueva y el backend trataria lo anterior como una
		# sesion cerrada.
		try:
			if self.punchplayCredentials:
				_pct, _cur = self._live_percent()
				if _pct is not None:
					punchplay.scrobbleResume(
						imdb=self.imdb, tmdb=self.tmdb, tvdb=self.tvdb,
						season=self.season, episode=self.episode, watched_percent=_pct,
						title=self.title, year=self.year,
						duration=self.media_length, position=_cur)
		except: log_utils.error()
		# v1.0.99 WeTrakr: no tiene `resume`; lo documentado es volver a `start`.
		try:
			if self.wetrakrCredentials:
				_pct, _cur = self._live_percent()
				if _pct is not None:
					wetrakr.scrobbleResume(
						imdb=self.imdb, tmdb=self.tmdb, tvdb=self.tvdb,
						season=self.season, episode=self.episode, watched_percent=_pct,
						title=self.title, year=self.year)
		except: log_utils.error()
		# Al reanudar, /scrobble/start devuelve el estado "viendo ahora" con el
		# progreso correcto. Es el uso documentado: start sirve tanto para
		# arrancar como para des-pausar.
		try:
			if not (self.traktCredentials and getSetting('trakt.scrobble') == 'true'): return
			_pct, _cur = self._live_percent()
			if _pct is None: return
			trakt.scrobbleStart(imdb=self.imdb, tmdb=self.tmdb, tvdb=self.tvdb,
								season=self.season, episode=self.episode, watched_percent=_pct)
		except: log_utils.error()
		control.log('[ plugin.video.luc_kodi ] onPlayBackResumed callback', LOGINFO)


	def onPlayBackSeek(self, time, seekOffset):
		seekOffset /= 1000

	def onPlayBackSeekChapter(self, chapter):
		control.log('[ plugin.video.luc_kodi ] onPlayBackSeekChapter callback', LOGINFO)


	def onQueueNextItem(self):
		control.log('[ plugin.video.luc_kodi ] onQueueNextItem callback', LOGINFO)


	def _cleanup_pm_nzb(self):
		# Auto-borrado del NZB reproducido desde la nube de Premiumize (si procede).
		try:
			from resources.lib.debrid.premiumize import Premiumize
			Premiumize.cleanup_nzb_transfer()
		except: pass

	def onPlayBackStopped(self):
		try:
			self._cleanup_pm_nzb()
			playerWindow.clearProperty('luc_kodi.preResolved_nextUrl')
			playerWindow.clearProperty('luc_kodi.playlistStart_position')
			playerWindow.clearProperty('luc_kodi.nextEpisode_playUrl')
			playerWindow.clearProperty('luc_kodi.playnext_showing')
			clear_local_bookmarks() # clear all luc_kodi bookmarks from kodi database

			if not self.onPlayBackStopped_ran or (self.playbackStopped_triggered and not self.onPlayBackStopped_ran): # Kodi callback unreliable and often not issued
				self.onPlayBackStopped_ran = True
				self.playbackStopped_triggered = False
				Bookmarks().reset(self.current_time, self.media_length, self.name, self.year)
				# v1.0.18: call set_scrobble if EITHER Trakt or SIMKL is enabled with creds.
				if ((self.traktCredentials and getSetting('trakt.scrobble') == 'true') or
					(self.simklCredentials and getSetting('simkl.scrobble') == 'true') or
					(self.mdblistCredentials and getSetting('mdblist.scrobble') == 'true') or
					self.punchplayCredentials or self.wetrakrCredentials):
					Bookmarks().set_scrobble(self.current_time, self.media_length, self.media_type, self.imdb, self.tmdb, self.tvdb, self.season, self.episode)
				watcher = self.getWatchedPercent()
				seekable = (int(self.current_time) > 180 and (watcher < 85))
				if watcher >= 85: self.libForPlayback() # only write playcount to local lib

				if getSetting('crefresh') == 'true' and seekable:
					control.log('[ plugin.video.luc_kodi ] container.refresh issued', LOGINFO)

					control.refresh() #not all skins refresh after playback stopped
				control.playlist.clear()
				# control.trigger_widget_refresh() # skinshortcuts handles widget refresh
				xbmc.log('[ plugin.video.luc_kodi ] onPlayBackStopped callback', LOGINFO)
				control.log('[ plugin.video.luc_kodi ] onPlayBackStopped callback', LOGINFO)

		except: log_utils.error()

	def onPlayBackEnded(self):
		self.ended_naturally = True  # video reached the natural end
		self._cleanup_pm_nzb()
		Bookmarks().reset(self.current_time, self.media_length, self.name, self.year)
		self.libForPlayback()
		# Natural end of playback: Kodi may not fire onPlayBackStopped here, so notify Trakt/SIMKL
		# explicitly. set_scrobble at >=85% (Trakt) or >=80% (SIMKL) calls /scrobble/stop -> watched indicator syncs.
		if ((self.traktCredentials and getSetting('trakt.scrobble') == 'true') or
			(self.simklCredentials and getSetting('simkl.scrobble') == 'true') or
			(self.mdblistCredentials and getSetting('mdblist.scrobble') == 'true') or
			self.punchplayCredentials or self.wetrakrCredentials):
			try:
				Bookmarks().set_scrobble(self.current_time, self.media_length, self.media_type, self.imdb, self.tmdb, self.tvdb, self.season, self.episode)
			except: log_utils.error()
		playerWindow.clearProperty('luc_kodi.nextEpisode_playUrl')
		playerWindow.clearProperty('luc_kodi.playnext_showing')
		# Only clear playlist when we are genuinely at the last item (not when size==1 from daisy-chain)
		if control.playlist.getposition() == control.playlist.size() and control.playlist.size() > 0:
			control.playlist.clear()
		xbmc.log('[ plugin.video.luc_kodi ] onPlayBackEnded callback', LOGINFO)
		control.log('[ plugin.video.luc_kodi ] onPlayBackEnded callback', LOGINFO)


	def onPlayBackError(self):
		self._cleanup_pm_nzb()
		playerWindow.clearProperty('luc_kodi.preResolved_nextUrl')
		playerWindow.clearProperty('luc_kodi.playlistStart_position')
		playerWindow.clearProperty('luc_kodi.nextEpisode_playUrl')

		Bookmarks().reset(self.current_time, self.media_length, self.name, self.year)
		log_utils.error()
		xbmc.log('[ plugin.video.luc_kodi ] onPlayBackError callback', LOGINFO)
		control.log('[ plugin.video.luc_kodi ] onPlayBackError callback', LOGINFO)

		sysexit(1)
##############################

def _score_subtitle(sub, year):
    """
    Puntúa un candidato de OpenSubtitles para una película (0-100).

    Criterios (de mayor a menor peso):
      1. Popularidad reciente  – new_download_count       (0-40 pts)
      2. Calidad valorada      – ratings × sqrt(votes)    (0-20 pts)
      3. Fuente fiable         – from_trusted             (+15 pts)
      4. Traducción humana     – no ai, no machine        (+15 pts)
      5. Año en el nombre      – coincidencia con year    (+5 pts)
      6. Sin HI                – hearing_impaired=False   (+5 pts)
    """
    score = 0.0

    # 1. Popularidad (normalizada a 40 pts, cap en 50.000 descargas)
    downloads = min(sub.get('downloads', 0), 50000)
    score += (downloads / 50000.0) * 40.0

    # 2. Calidad: ratings (0-10) × sqrt(votes), normalizado a 20 pts
    ratings = sub.get('ratings', 0.0)
    votes   = sub.get('votes', 0)
    if ratings > 0 and votes > 0:
        import math
        quality = ratings * math.sqrt(votes)
        score += min(quality / 25.0, 20.0)   # 25 = 10*sqrt(6.25) ~ umbral razonable

    # 3. Fuente fiable
    if sub.get('trusted'):
        score += 15.0

    # 4. Traducción humana (penalizar IA y machine)
    if not sub.get('ai') and not sub.get('machine'):
        score += 15.0

    # 5. Año coincide en el nombre del fichero
    if year and str(year) in (sub.get('fileName') or ''):
        score += 5.0

    # 6. Sin subtítulos para sordos (leve preferencia)
    if not sub.get('hi'):
        score += 5.0

    return score


class Subtitles:
	"""
	Gestiona la descarga y aplicación automática de subtítulos desde OpenSubtitles.com.
	Se instancia desde Player.keepAlive() al inicio de la reproducción.
	También calcula el tiempo de PlayNext basándose en la última línea del .srt.
	"""
	def __init__(self):
		self.debuglog        = control.setting('debug.level') == '1'
		self.playnext_method = '0'  # fixed — playnext.method setting removed in v0.0.92

	def get(self, title, year, imdb, season, episode):
		try:
			import re
		except:
			return log_utils.error()

		# ── Global guard: prevent simultaneous subtitle lookups across ALL
		# callers (keepAlive, onAVStarted, SubtitlePlayer) which run in
		# different threads/processes but share homeWindow properties.
		_FLAG = 'luc_kodi.subtitles.running'
		if homeWindow.getProperty(_FLAG) == 'true':
			control.log('[ luc_kodi ] Subtitles.get() — already running, skipping duplicate call', LOGINFO)
			return
		homeWindow.setProperty(_FLAG, 'true')

		try:
			control.log('[ luc_kodi ] Subtitles.get() START — title:%s imdb:%s season:%s ep:%s' % (title, imdb, season, episode), LOGINFO)

			quality = ['bluray', 'hdrip', 'brrip', 'bdrip', 'dvdrip', 'webrip', 'hdtv']
			langs = [getSetting('subtitles.lang.1'), getSetting('subtitles.lang.2')]
			control.log('[ luc_kodi ] Subtitles langs: %s' % langs, LOGINFO)


			# ¿El stream ya tiene el idioma deseado?
			try:    subLang = xbmc.Player().getSubtitles()
			except: subLang = ''
			if subLang == 'gre': subLang = 'ell'
			control.log('[ luc_kodi ] Current stream subLang: "%s"' % subLang, LOGINFO)

			# Solo salir si el idioma coincide Y el fichero de subtítulos existe en disco.
			# Si no existe (ej: reanudación tras salir), hay que volver a descargar.
			if subLang == langs[0]:
				try:
					lang_code = xbmc.convertLanguage(langs[0], xbmc.ISO_639_1)
				except:
					lang_code = langs[0]
				srt_path = control.joinPath(control.subtitlesPath, 'TemporarySubs.%s.srt' % lang_code)
				srt_exists = control.existsPath(srt_path)
				control.log('[ luc_kodi ] Subtitles: srt_exists=%s path=%s' % (srt_exists, srt_path), LOGINFO)
				if srt_exists:
					if getSetting('subtitles.notification') == 'true':
						if Player().isPlayback():
							control.sleep(1000)
							control.notification(message=getLS(32393) % subLang.upper(), time=5000)
					return log_utils.log(getLS(32393) % subLang.upper(), level=log_utils.LOGDEBUG)
				# Fichero no existe → reanudación: continuar con descarga

			# ¿Hay subtítulos embebidos disponibles?
			try:
				subLangs = xbmc.Player().getAvailableSubtitleStreams()
				if 'gre' in subLangs: subLangs[subLangs.index('gre')] = 'ell'
				subLang = [i for i in subLangs if i == langs[0]][0]
			except: subLangs = subLang = ''
			control.log('[ luc_kodi ] Available subtitle streams: %s' % subLangs, LOGINFO)

			if subLangs and subLang == langs[0]:
				control.sleep(1000)
				xbmc.Player().setSubtitleStream(subLangs.index(subLang))
				if getSetting('subtitles.notification') == 'true':
					if Player().isPlayback():
						control.sleep(1000)
						control.notification(message=getLS(32394) % subLang.upper(), time=5000)
				return log_utils.log(getLS(32394) % subLang.upper(), level=log_utils.LOGDEBUG)

			# Autenticar en OpenSubtitles
			control.log('[ luc_kodi ] Attempting OpenSubs auth...', LOGINFO)

			_user = control.setting('opensubsusername')
			_pass = control.setting('opensubspassword')
			control.log('[ luc_kodi ] OpenSubs user: "%s" pass_set: %s' % (_user, bool(_pass)), LOGINFO)

			if opensubs.Opensubs().auth():
				control.log('[ luc_kodi ] OpenSubs auth OK.', LOGINFO)

			else:
				control.log('[ luc_kodi ] OpenSubs auth FAILED.', LOGINFO)

				return control.notification(message=getLS(40509), time=5000)

			# Buscar subtítulos
			if not (season is None or episode is None):
				result = opensubs.Opensubs().getSubs(title, imdb, year, season, episode)
				control.log('[ luc_kodi ] Subtitles.get() episode: results=%s' % len(result), LOGINFO)
				fmt = ['hdtv']
			else:
				result = opensubs.Opensubs().getSubs(title, imdb, year, season, episode)
				control.log('[ luc_kodi ] Subtitles.get() movie: lang1 results=%s' % len(result), LOGINFO)
				if not result:
					# Fallback: try secondary language
					lang2 = getSetting('subtitles.lang.2')
					if lang2:
						control.log('[ luc_kodi ] Subtitles.get() movie: no lang1 results, trying lang2=%s' % lang2, LOGINFO)
						result = opensubs.Opensubs().getSubs(title, imdb, year, season, episode, lang_override=lang2)
						control.log('[ luc_kodi ] Subtitles.get() movie: lang2 results=%s' % len(result), LOGINFO)
				try:    vidPath = xbmc.Player().getPlayingFile()
				except: vidPath = ''
				fmt = re.split(r'\.|\\(|\\)|\\[|\\]|\\s|\\-', vidPath)
				fmt = [i.lower() for i in fmt if i is not None]
				fmt = [i for i in fmt if i in quality]

			# Selección de subtítulo
			try:    vidPath = xbmc.Player().getPlayingFile()
			except: vidPath = ''
			pFileName = unquote(os.path.basename(vidPath))
			pFileName = os.path.splitext(pFileName)[0]
			control.log('[ luc_kodi ] Subtitles pFileName="%s" results=%s' % (pFileName, len(result) if result else 0), LOGINFO)
			matches = []
			if result:
				if season:
					# TV Shows: SequenceMatcher contra nombre de fichero del stream
					for j in result:
						if not j.get('fileName'):
							continue
						if seas_ep_filter(season, episode, j['fileName']):
							seq = SequenceMatcher(None, pFileName.lower(), j['fileName'].lower())
							matches.append({'fileName': j['fileName'], 'fileID': j['fileID'], 'ratio': seq.ratio()})
					matches.sort(key=lambda i: i['ratio'], reverse=True)
				else:
					# Movies: scoring multi-criterio con metadatos de OpenSubtitles
					for j in result:
						if not j.get('fileName'):
							continue
						score = _score_subtitle(j, year)
						matches.append({'fileName': j['fileName'], 'fileID': j['fileID'], 'ratio': score})
						control.log('[ luc_kodi ] Subtitles score=%.1f  file=%s' % (score, j['fileName']), LOGINFO)
					matches.sort(key=lambda i: i['ratio'], reverse=True)
			filter = matches
			if not filter:
				if getSetting('subtitles.notification') == 'true':
					return control.notification(message=getLS(32395))
				return None

			try:    lang = xbmc.convertLanguage(getSetting('subtitles.lang.1'), xbmc.ISO_639_1)
			except: lang = getSetting('subtitles.lang.1')

			filename = filter[0]['fileName']
			control.log('[ luc_kodi ] Subtitles: subtítulo seleccionado="%s" fileID=%s' % (filename, filter[0]['fileID']), LOGINFO)

			try:
				downloadURL, downloadFileName = opensubs.Opensubs().downloadSubs(filter[0]['fileID'], filter[0]['fileName'])
				control.log('[ luc_kodi ] Subtitles: downloadURL=%s' % downloadURL, LOGINFO)
			except Exception as e:
				control.log('[ luc_kodi ] Subtitles: downloadSubs EXCEPTION: %s' % str(e), LOGINFO)
				return

			if not control.existsPath(control.subtitlesPath): control.makeFile(control.subtitlesPath)
			download_path = control.subtitlesPath

			def find(pattern, path):
				result = []
				for root, dirs, files in os.walk(path):
					for name in files:
						if fnmatch.fnmatch(name, pattern):
							result.append(os.path.join(root, name))
				return result

			def download_opensubs(downloadURL, downloadFileName):
				control.log('[ luc_kodi ] Descargando .srt desde OpenSubs.', LOGINFO)

				reqqqq = Request(downloadURL, headers={'User-Agent': 'Magic Browser'})
				http_response = urlopen(reqqqq)
				response = http_response.read().decode('utf-8')
				srtFile = os.path.join(download_path, downloadFileName + '.srt')
				with open(srtFile, 'w') as file:
					file.write(response)

			from resources.lib.modules import tools
			tools.delete_all_subs()
			try:
				download_opensubs(downloadURL, downloadFileName)
			except Exception as e:
				control.log('[ luc_kodi ] Subtitles: download_opensubs EXCEPTION: %s' % str(e), LOGINFO)

			subtitles = find('*.srt', download_path)
			control.log('[ luc_kodi ] Subtitles: srt files found=%s' % len(subtitles), LOGINFO)
			subtitle_matches = []
			if len(subtitles) > 1:
				if season:
					for count, i in enumerate(subtitles):
						sFileName = unquote(os.path.basename(i))
						sFileName = os.path.splitext(sFileName)[0]
						if seas_ep_filter(season, episode, sFileName.lower()):
							seq = SequenceMatcher(None, pFileName.lower(), sFileName.lower())
							subtitle_matches.append({'fullPath': subtitles[count], 'matchRatio': seq.ratio()})
				else:
					for count, i in enumerate(subtitles):
						sFileName = unquote(os.path.basename(i))
						sFileName = os.path.splitext(sFileName)[0]
						seq = SequenceMatcher(None, pFileName.lower(), sFileName.lower())
						subtitle_matches.append({'fullPath': subtitles[count], 'matchRatio': seq.ratio()})
				subtitle_matches.sort(key=lambda i: i['matchRatio'], reverse=True)
				subtitles = subtitle_matches[0]['fullPath']
			else:
				subtitles = subtitles[0]

			xbmc.sleep(1000)
			tempFileName = control.joinPath(download_path, 'TemporarySubs.%s.srt' % lang)
			with open(subtitles, 'r') as f:
				content = f.read()
			with open(tempFileName, 'w') as f1:
				f1.write(content)

			xbmc.Player().setSubtitles(tempFileName)

			if getSetting('subtitles.notification') == 'true':
				if Player().isPlayback():
					control.sleep(500)
					control.notification(title=filename, message=getLS(40506) % lang.upper())

			# Calcular tiempo de PlayNext por subtítulos (método 2)
			if self.playnext_method == '2' and getSetting('enable.playnext') == 'true' and Player().subtitletime is None:
				times = []
				pattern = r'(\d{2}:\d{2}:\d{2},d{3}$)|(\d{2}:\d{2}:\d{2})'
				with control.openFile(subtitles) as file:
					text = file.read()
					times = re.findall(pattern, text)
					times = times[len(times) - 4][-1]
					file.close()
				if len(times) > 0:
					total_time = Player().media_length
					h, m, s = str(times).split(':')
					totalSeconds = int(h) * 3600 + int(m) * 60 + int(s)
					Player().subtitletime = int(total_time) - int(totalSeconds)
				else:
					Player().subtitletime = 'default'
		except:
			log_utils.error()
		finally:
			# Libera SIEMPRE el guard global puesto al inicio de get(), tanto en
			# éxito como en error. Sin esto el flag quedaba en 'true' de forma
			# permanente y todas las llamadas posteriores salían por el guard
			# ("already running, skipping"), dejando los subtítulos automáticos
			# inoperativos hasta reiniciar Kodi.
			homeWindow.clearProperty(_FLAG)

	def downloadForPlayNext(self, title, year, imdb, season, episode, media_length):
		"""
		Descarga (o reutiliza) el subtítulo para determinar cuándo lanzar el popup
		de PlayNext basándose en la última línea del .srt.
		Devuelve segundos antes del final, 'default', o None.
		"""
		try:
			try:    import re
			except: return log_utils.error()
			try:    lang = xbmc.convertLanguage(getSetting('subtitles.lang.1'), xbmc.ISO_639_1)
			except: lang = getSetting('subtitles.lang.1')
			if not control.existsPath(control.subtitlesPath): control.makeFile(control.subtitlesPath)
			download_path = control.subtitlesPath

			# Primero intentar reutilizar caché
			try:
				tempFileName = control.joinPath(download_path, 'TemporarySubs.%s.srt' % lang)
				if os.path.isfile(tempFileName):
					control.log('[ luc_kodi ] Subtítulo en caché encontrado para PlayNext.', LOGINFO)

					xbmc.sleep(1000)
					times = []
					pattern = r'(\d{2}:\d{2}:\d{2},d{3}$)|(\d{2}:\d{2}:\d{2})'
					with control.openFile(tempFileName) as file:
						text = file.read()
						times = re.findall(pattern, text)
						times = times[len(times) - 4][-1]
						file.close()
					if len(times) > 0:
						h, m, s = str(times).split(':')
						totalSeconds = int(h) * 3600 + int(m) * 60 + int(s)
						return int(media_length) - int(totalSeconds)
					else:
						control.log('[ luc_kodi ] Tiempo de subtítulo no encontrado, devolviendo default.', LOGINFO)

						return 'default'
			except:
				log_utils.error()
				return 'default'

			# Si no hay caché, descargar nuevo
			try:
				if not opensubs.Opensubs().auth():
					control.log('[ luc_kodi ] OpenSubs no autorizado para PlayNext. Devolviendo default.', LOGINFO)

					return 'default'
				if not (season is None or episode is None):
					result = opensubs.Opensubs().getSubs(title, imdb, year, season, episode)
					if not result:
						control.log('[ luc_kodi ] Sin resultados OpenSubs PlayNext: %s S%sE%s' % (title, season, episode), LOGINFO)

						return 'default'
				else:
					result = opensubs.Opensubs().getSubs(title, imdb, year, season, episode)
					if not result: return None

				try:    vidPath = xbmc.Player().getPlayingFile()
				except: vidPath = ''
				pFileName = unquote(os.path.basename(vidPath))
				pFileName = os.path.splitext(pFileName)[0]
				matches = []
				if result:
					for j in result:
						if season:
							if seas_ep_filter(season, episode, j['fileName']):
								seq = SequenceMatcher(None, pFileName.lower(), j['fileName'].lower())
								matches.append({'fileName': j['fileName'], 'fileID': j['fileID'], 'ratio': seq.ratio()})
						else:
							seq = SequenceMatcher(None, pFileName.lower(), j['fileName'].lower())
							matches.append({'fileName': j['fileName'], 'fileID': j['fileID'], 'ratio': seq.ratio()})
				matches.sort(key=lambda i: i['ratio'], reverse=True)
				if not matches: return None

				try:    lang = xbmc.convertLanguage(getSetting('subtitles.lang.1'), xbmc.ISO_639_1)
				except: lang = getSetting('subtitles.lang.1')

				downloadURL, downloadFileName = opensubs.Opensubs().downloadSubs(matches[0]['fileID'], matches[0]['fileName'])

				def find(pattern, path):
					result = []
					for root, dirs, files in os.walk(path):
						for name in files:
							if fnmatch.fnmatch(name, pattern):
								result.append(os.path.join(root, name))
					return result

				def download_opensubs(downloadURL, downloadFileName):
					reqqqq = Request(downloadURL, headers={'User-Agent': 'Magic Browser'})
					response = urlopen(reqqqq).read().decode('utf-8')
					srtFile = os.path.join(download_path, downloadFileName + '.srt')
					with open(srtFile, 'w') as file:
						file.write(response)

				from resources.lib.modules import tools
				tools.delete_all_subs()
				download_opensubs(downloadURL, downloadFileName)

				subtitles = find('*.srt', control.transPath(download_path))
				subtitle_matches = []
				if len(subtitles) > 1:
					if season:
						for count, i in enumerate(subtitles):
							sFileName = os.path.splitext(unquote(os.path.basename(i)))[0]
							if seas_ep_filter(season, episode, sFileName.lower()):
								seq = SequenceMatcher(None, pFileName.lower(), sFileName.lower())
								subtitle_matches.append({'fullPath': subtitles[count], 'matchRatio': seq.ratio()})
					else:
						for count, i in enumerate(subtitles):
							sFileName = os.path.splitext(unquote(os.path.basename(i)))[0]
							seq = SequenceMatcher(None, pFileName.lower(), sFileName.lower())
							subtitle_matches.append({'fullPath': subtitles[count], 'matchRatio': seq.ratio()})
					subtitle_matches.sort(key=lambda i: i['matchRatio'], reverse=True)
					subtitles = subtitle_matches[0]['fullPath']
				else:
					subtitles = subtitles[0]

				xbmc.sleep(1000)
				tempFileName2 = control.joinPath(download_path, 'TemporarySubs2.%s.srt' % lang)
				with open(subtitles, 'r') as f:
					content = f.read()
				with open(tempFileName2, 'a') as f1:
					f1.write(content)
				xbmc.sleep(1000)

				times = []
				pattern = r'(\d{2}:\d{2}:\d{2},d{3}$)|(\d{2}:\d{2}:\d{2})'
				with control.openFile(tempFileName2) as file:
					text = file.read()
					times = re.findall(pattern, text)
					times = times[len(times) - 4][-1]
					file.close()

				if len(times) > 0:
					h, m, s = str(times).split(':')
					totalSeconds = int(h) * 3600 + int(m) * 60 + int(s)
					playnextTime = int(media_length) - int(totalSeconds)
				else:
					playnextTime = 'default'
				control.log('[ luc_kodi ] PlayNext subtítulos: %s seg.' % playnextTime, LOGINFO)

				return playnextTime
			except:
				log_utils.error()
				return 'default'
		except Exception as e:
			control.log('[ luc_kodi ] Subtitles.downloadForPlayNext() OUTER EXCEPTION: %s' % str(e), LOGINFO)
			return 'default'

##############################

class PlayNext(xbmc.Player):
	def __init__(self):
		super(PlayNext, self).__init__()
		self.enable_playnext = getSetting('enable.playnext') == 'true'
		self.stillwatching_count = 3  # fixed — stillwatching.count setting removed in v0.0.92
		self.playing_file = None

	def display_xml(self):
		# Mutex: prevent the popup from being opened twice simultaneously
		if playerWindow.getProperty('luc_kodi.playnext_showing') == 'true':
			return
		try:
			self.playing_file = self.getPlayingFile()
		except:
			log_utils.error("Kodi did not return a playing file, killing playnext xml's")
			return
		has_playlist = (control.playlist.size() > 0 and control.playlist.getposition() != (control.playlist.size() - 1))
		if not has_playlist:
			return
		if self.isStill_watching(): target = self.show_stillwatching_xml
		elif self.enable_playnext: target = self.show_playnext_xml
		else: return
		if self.playing_file != self.getPlayingFile(): return
		if not self.isPlayingVideo(): return
		if control.getCurrentWindowId != 12005: return
		playerWindow.setProperty('luc_kodi.playnext_showing', 'true')
		try:
			target()
		finally:
			playerWindow.clearProperty('luc_kodi.playnext_showing')

	def isStill_watching(self):
		# still_watching = float(control.playlist.getposition() + 1) / self.stillwatching_count # this does not work if you start playback on a divisible position with "stillwatching_count"
		playlistStart_position = int(playerWindow.getProperty('luc_kodi.playlistStart_position') or 0)
		if playlistStart_position: still_watching = float(control.playlist.getposition() - playlistStart_position + 1) / self.stillwatching_count
		else: still_watching = float(control.playlist.getposition() + 1) / self.stillwatching_count
		if still_watching == 0: return False
		return still_watching.is_integer()

	def getNext_meta(self):
		try:
			from urllib.parse import parse_qsl
			current_position = control.playlist.getposition()
			next_url = control.playlist[current_position + 1].getPath()
			# next_url=videodb://tvshows/titles/16/2/571?season=2&tvshowid=16 # library playback returns this
			params = dict(parse_qsl(next_url.replace('?', '')))
			next_meta = jsloads(params.get('meta')) if params.get('meta') else '' # not available for library playback
			return next_meta
		except:
			log_utils.error()
			return ''

	def show_playnext_xml(self):
		try:
			next_meta = self.getNext_meta()
			if not next_meta: raise Exception()
			from resources.lib.windows.playnext import PlayNextXML
			window = PlayNextXML('playnext.xml', control.addonPath(control.addonId()), meta=next_meta)
			window.run()
			del window
			self.play_next_triggered = True
		except:
			log_utils.error()
			self.play_next_triggered = True

	def show_stillwatching_xml(self):
		try:
			next_meta = self.getNext_meta()
			if not next_meta: raise Exception()
			from resources.lib.windows.playnext_stillwatching import StillWatchingXML
			window = StillWatchingXML('playnext_stillwatching.xml', control.addonPath(control.addonId()), meta=next_meta)
			window.run()
			del window
			self.play_next_triggered = True
		except:
			log_utils.error()
			self.play_next_triggered = True

	def prescrapeNext(self):
		try:
			if control.playlist.size() > 0 and control.playlist.getposition() != (control.playlist.size() - 1):
				from resources.lib.modules import sources
				from resources.lib.database import providerscache
				next_meta=self.getNext_meta()
				if not next_meta: raise Exception()
				title = next_meta.get('title')
				year = next_meta.get('year')
				imdb = next_meta.get('imdb')
				tmdb = next_meta.get('tmdb')
				tvdb = next_meta.get('tvdb')
				season = next_meta.get('season')
				episode = next_meta.get('episode')
				tvshowtitle = next_meta.get('tvshowtitle')
				premiered = next_meta.get('premiered')
				next_sources = providerscache.get(sources.Sources().getSources, 48, title, year, imdb, tmdb, tvdb, str(season), str(episode), tvshowtitle, premiered, next_meta, True)
				if not self.isPlayingVideo():
					return playerWindow.clearProperty('luc_kodi.preResolved_nextUrl')
				sources.Sources().preResolve(next_sources, next_meta)
			else:
				playerWindow.clearProperty('luc_kodi.preResolved_nextUrl')
		except:
			log_utils.error()
			playerWindow.clearProperty('luc_kodi.preResolved_nextUrl')



class Bookmarks:
	def get(self, name, imdb=None, tmdb=None, tvdb=None, season=None, episode=None, year='0', runtime=None, ck=False):
		offset = '0'
		scrobbble = 'Local Bookmark'
		if getSetting('bookmarks') != 'true': return offset
		if getSetting('trakt.scrobble') == 'true' and getSetting('resume.source') == '1':
			scrobbble = 'Trakt Scrobble'
			try:
				if not runtime or runtime == 'None': return offset # TMDB sometimes return None as string. duration pulled from kodi library if missing from meta
				progress = float(fetch_bookmarks(imdb, tmdb, tvdb, season, episode))
				offset = (progress / 100) * runtime # runtime vs. media_length can differ resulting in 10-30sec difference using Trakt scrobble, meta providers report runtime in full minutes
				seekable = (2 <= progress <= 85)
				if not seekable: return '0'
			except:
				log_utils.error()
				return '0'
		else:
			try:
				dbcon = database.connect(control.bookmarksFile)
				dbcur = dbcon.cursor()
				dbcur.execute('''CREATE TABLE IF NOT EXISTS bookmark (idFile TEXT, timeInSeconds TEXT, Name TEXT, year TEXT, UNIQUE(idFile));''')
				if not year or year == 'None': return offset
				years = [str(year), str(int(year)+1), str(int(year)-1)]
				# v1.0.54: consulta parametrizada. El título iba interpolado a pelo
				# ("...Name=\"%s\"...") y cualquier título con comillas dobles
				# (p.ej. entradas TMDb con el título entrecomillado) rompía el SQL:
				# OperationalError near "...": syntax error, y el punto de
				# reanudación se perdía para ese título.
				match = dbcur.execute('''SELECT * FROM bookmark WHERE Name=? AND year IN (?, ?, ?)''', (name, years[0], years[1], years[2])).fetchone() # helps fix random cases where trakt and imdb, or tvdb, differ by a year for eps
			except:
				log_utils.error()
				return offset
			finally:
				try:
					dbcur.close()
				except Exception:
					pass
				try:
					dbcon.close()
				except Exception:
					pass
			if not match: return offset
			offset = str(match[1])
		if ck: return offset
		minutes, seconds = divmod(float(offset), 60)
		hours, minutes = divmod(minutes, 60)
		label = '%02d:%02d:%02d' % (hours, minutes, seconds)
		label = getLS(32502) % label
		if getSetting('bookmarks.auto') == 'false':
			select = control.yesnocustomDialog(label, scrobbble, '', str(name), 'Cancel Playback', getLS(32503), getLS(32501))
			if select == 1: offset = '0'
			elif select == -1 or select == 2: offset = '-1'
		return offset

	def reset(self, current_time, media_length, name, year='0'):
		try:
			clear_local_bookmarks() # clear all luc_kodi bookmarks from kodi database
			if getSetting('bookmarks') != 'true' or media_length == 0 or current_time == 0: return
			timeInSeconds = str(current_time)
			seekable = (int(current_time) > 180 and (current_time / media_length) < .85)
			idFile = md5()
			try: [idFile.update(str(i)) for i in name]
			except: [idFile.update(str(i).encode('utf-8')) for i in name]
			try: [idFile.update(str(i)) for i in year]
			except: [idFile.update(str(i).encode('utf-8')) for i in year]
			idFile = str(idFile.hexdigest())
			control.makeFile(control.dataPath)
			dbcon = database.connect(control.bookmarksFile)
			dbcur = dbcon.cursor()
			dbcur.execute('''CREATE TABLE IF NOT EXISTS bookmark (idFile TEXT, timeInSeconds TEXT, Name TEXT, year TEXT, UNIQUE(idFile));''')
			# v1.0.99: un item sin ano ('', 'None') tumbaba todo el guardado del
			# punto de resume con ValueError en int(year).
			try: years = [str(year), str(int(year) + 1), str(int(year) - 1)]
			except (TypeError, ValueError): years = [str(year)] * 3
			# v1.0.54: parametrizada por el mismo motivo que el SELECT de get():
			# títulos con comillas dobles rompían el DELETE y el marcador viejo
			# nunca se limpiaba antes de insertar el nuevo.
			dbcur.execute('''DELETE FROM bookmark WHERE Name=? AND year IN (?, ?, ?)''', (name, years[0], years[1], years[2])) #helps fix random cases where trakt and imdb, or tvdb, differ by a year for eps
			if seekable:
				dbcur.execute('''INSERT INTO bookmark Values (?, ?, ?, ?)''', (idFile, timeInSeconds, name, year))
				minutes, seconds = divmod(float(timeInSeconds), 60)
				hours, minutes = divmod(minutes, 60)
				label = ('%02d:%02d:%02d' % (hours, minutes, seconds))
				message = getLS(32660)
				control.notification(title=name, message=message + '(' + label + ')')
			dbcur.connection.commit()
			try: dbcur.close ; dbcon.close()
			except: pass
		except:
			log_utils.error()

	def set_scrobble(self, current_time, media_length, media_type, imdb='', tmdb='', tvdb='', season='', episode=''):
		try:
			if media_length == 0:
				return
			percent = float((current_time / media_length)) * 100
			seekable = (int(current_time) > 180 and (percent < 85))
			# TRAKT: solo si Trakt tiene credenciales Y su scrobble está activo.
			# NOTA: set_scrobble está en la clase Bookmarks (no Player), así que
			# NO existe self.traktCredentials aquí — hay que consultar la función
			# directamente. Antes esto petaba con AttributeError y abortaba TODO
			# el scrobble (incluido SIMKL) antes de llegar a la parte de SIMKL.
			_trakt_on = (trakt.getTraktCredentialsInfo() and getSetting('trakt.scrobble') == 'true')
			if _trakt_on:
				try:
					if seekable:
						trakt.scrobbleMovie(imdb, tmdb, percent) if media_type == 'movie' else trakt.scrobbleEpisode(imdb, tmdb, tvdb, season, episode, percent)
					if percent >= 85:
						trakt.scrobbleStop(imdb=imdb, tmdb=tmdb, tvdb=tvdb, season=season, episode=episode, watched_percent=percent)
				except Exception:
					log_utils.error()  # un fallo de Trakt NO debe propagarse ni romper SIMKL

			# v1.0.18 SIMKL: branches MUTUALLY EXCLUSIVE per SIMKL docs.
			# - >=80% on stop event = /scrobble/stop (auto-marks watched)
			# - <80% but >3 min played = /scrobble/pause (saves resume point)
			# - else (very short interrupt) = no call
			# IMPORTANT: don't fire both pause AND stop on the same set_scrobble
			# call — the 5s local cooldown would suppress whichever runs second,
			# leading to a watched item being saved as merely a resume point.
			if getSetting('simkl.scrobble') == 'true':
				try:
					from resources.lib.modules import simkl as _simkl
					if _simkl.getSimklCredentialsInfo():
						if percent >= 80:
							_simkl.scrobbleStop(imdb=imdb, tmdb=tmdb, tvdb=tvdb,
												season=season, episode=episode, watched_percent=percent)
						elif int(current_time) > 180:
							_simkl.scrobblePause(imdb=imdb, tmdb=tmdb, tvdb=tvdb,
												 season=season, episode=episode, watched_percent=percent)
				except Exception:
					log_utils.error()

			# v1.0.37 MDBList: ramas mutuamente excluyentes igual que SIMKL.
			#  >=80% en stop = /scrobble/stop (marca visto)
			#  <80% pero >3 min = /scrobble/pause (guarda resume)
			if getSetting('mdblist.scrobble') == 'true':
				try:
					from resources.lib.modules import mdblist as _mdblist
					if _mdblist.getMDBListScrobbleInfo():
						if percent >= 80:
							_mdblist.scrobbleStop(imdb=imdb, tmdb=tmdb, tvdb=tvdb,
												  season=season, episode=episode, watched_percent=percent)
						elif int(current_time) > 180:
							_mdblist.scrobblePause(imdb=imdb, tmdb=tmdb, tvdb=tvdb,
												   season=season, episode=episode, watched_percent=percent)
				except Exception:
					log_utils.error()

			# v1.0.86 PunchPlay: UNA sola llamada, siempre /playback/stop.
			# A diferencia de SIMKL y MDBList aqui NO hacen falta dos ramas
			# excluyentes: el propio servidor decide si el stop crea un visto
			# o solo guarda progreso, comparando con el watched_threshold que
			# se manda en el cuerpo. Partirlo en stop/pause por nuestra cuenta
			# duplicaria esa logica y la dejaria desincronizada del ajuste.
			# Sin suelo de tiempo: un stop temprano se guarda como progreso
			# incompleto, que es justo lo que alimenta Continue Watching.
			if getSetting('punchplay.scrobble') == 'true':
				try:
					from resources.lib.modules import punchplay as _punchplay
					if _punchplay.getPunchPlayScrobbleInfo():
						_punchplay.scrobbleStop(imdb=imdb, tmdb=tmdb, tvdb=tvdb,
												season=season, episode=episode,
												watched_percent=percent,
												duration=media_length, position=current_time)
				except Exception:
					log_utils.error()

			# v1.0.99 WeTrakr: UNA sola llamada, siempre /scrobble/stop. El
			# servidor decide: >= 80% marca visto, por debajo guarda la pausa
			# reanudable. Un stop por encima del 80% vale aunque no hubiera start.
			if getSetting('wetrakr.scrobble') == 'true':
				try:
					from resources.lib.modules import wetrakr as _wetrakr
					if _wetrakr.getWeTrakrScrobbleInfo() and (percent >= 80 or int(current_time) > 60):
						_wetrakr.scrobbleStop(imdb=imdb, tmdb=tmdb, tvdb=tvdb,
											  season=season, episode=episode, watched_percent=percent)
				except Exception:
					log_utils.error()
		except:
			log_utils.error()