# -*- coding: utf-8 -*-
"""
	luc_kodi Add-on
"""
from ast import literal_eval

from time import time
from sqlite3 import dbapi2 as db
from resources.lib.modules.control import existsPath, dataPath, makeFile, metacacheFile


def fetch(items, lang='en', user=''):
	try:
		dbcon = get_connection()
		dbcur = get_connection_cursor(dbcon)
		ck_table = dbcur.execute('''SELECT * FROM sqlite_master WHERE type='table' AND name='meta';''').fetchone()
		if not ck_table:
			dbcur.execute('''CREATE TABLE IF NOT EXISTS meta (imdb TEXT, tmdb TEXT, tvdb TEXT, lang TEXT, user TEXT, item TEXT, time TEXT,
			UNIQUE(imdb, tmdb, tvdb, lang, user));''')
			dbcur.connection.commit()
			try:
				dbcur.close()
			except Exception:
				pass
			try:
				dbcon.close()
			except Exception:
				pass
			return items
		t2 = int(time())
	except:
		from resources.lib.modules import log_utils
		log_utils.error()
	for i in range(0, len(items)):
		try:
			try: # First lookup by TVDb and IMDb, since there are some incorrect shows on Trakt that have the same IMDb ID, but different TVDb IDs (eg: Gotham, Supergirl).
				match = dbcur.execute('''SELECT * FROM meta WHERE (imdb=? AND tvdb=? AND lang=? AND user=? AND NOT imdb='' AND NOT tvdb='')''',
					(items[i].get('imdb', ''), items[i].get('tvdb', ''), lang, user)).fetchone()
				t1 = int(match[6])
			except:
				try: # Lookup both IMDb and TMDb for more accurate match.
					match = dbcur.execute('''SELECT * FROM meta WHERE (imdb=? AND tmdb=? AND lang=? AND user=? AND not imdb='' AND NOT tmdb='')''',
						(items[i].get('imdb', ''), items[i].get('tmdb', ''), lang, user)).fetchone()
					t1 = int(match[6])
				except:
					try: # Last resort single ID lookup.
						match = dbcur.execute('''SELECT * FROM meta WHERE (imdb=? AND lang=? AND user=? AND NOT imdb='') OR (tmdb=? AND lang=? AND user=? AND NOT tmdb='') OR (tvdb=? AND lang=? AND user=? AND NOT tvdb='')''',
							(items[i].get('imdb', ''), lang, user, items[i].get('tmdb', ''), lang, user, items[i].get('tvdb', ''), lang, user)).fetchone()
						t1 = int(match[6])
					except: pass
			if match:
				update = (abs(t2 - t1) / 3600) >= 720 # 30 days? for airing shows this is to much.
				if update: continue
				item = literal_eval(match[5])

				# v1.0.64 -- LA COMPROBACION DE FRESCURA NO PUEDE TIRAR LA CACHE.
				# Antes esto iba suelto dentro del try grande de mas abajo: en
				# cuanto algo aqui lanzaba (y lanzaba: cache_existing() devuelve
				# None por diseno cuando Trakt no esta sincronizado, y luego se
				# iteraba -> TypeError: 'NoneType' object is not iterable), el
				# except de fuera se lo tragaba y se saltaba el
				# items[i].update(item) del final. Resultado: el acierto de
				# cache se DESCARTABA y la ficha se volvia a pedir a TMDb.
				# Por eso la metacache "no iba bien" aunque el error pareciera
				# inofensivo en el log.
				# Ahora esto vive en su propio try: si falla, se registra y se
				# usa igualmente la metadata cacheada, que es lo correcto.
				_stale = False
				try:
					if item.get('mediatype') == 'tvshow':
						status = (item.get('status') or '').lower()
						if not any(value in status for value in ('ended', 'canceled')):
							from resources.lib.modules.cleandate import timestamp_from_string
							# `or {}` en vez de default: la clave puede EXISTIR con
							# valor None, y entonces .get() sobre None reventaba.
							_next = (item.get('next_episode_to_air') or {}).get('air_date', '') or ''
							next_episode_to_air = timestamp_from_string(_next)
							if not next_episode_to_air:
								_stale = (abs(t2 - t1) / 3600) >= 168 # 7 days for returning shows with None for next_episode_to_air
							else:
								if next_episode_to_air+(18*3600) <= t2 and (abs(t2 - t1) / 3600) >= 1: # refresh meta when next_episode_to_air is less than or equal to system date, every 1hr starting at 6pm till it flips
									from resources.lib.database.traktsync import cache_existing
									from resources.lib.modules.trakt import syncTVShows
									imdb = item.get('imdb', '')
									indicators = cache_existing(syncTVShows) or []
									watching = [i[0] for i in indicators if i and i[0] == imdb]
									if watching:
										from resources.lib.modules.trakt import cachesyncSeasons
										cachesyncSeasons(imdb) # refreshes only shows you are "watching"
									_stale = True
				except:
					from resources.lib.modules import log_utils
					log_utils.error()
				if _stale: continue

				item = dict((k, v) for k, v in iter(item.items()) if v is not None and v != '')
				items[i].update(item)
				items[i].update({'metacache': True})
		except:
			from resources.lib.modules import log_utils
			log_utils.error()
	try: dbcur.close() ; dbcon.close()
	except: pass
	return items

def insert(meta):
	try:
		dbcon = get_connection()
		dbcur = get_connection_cursor(dbcon)
		dbcur.execute('''CREATE TABLE IF NOT EXISTS meta (imdb TEXT, tmdb TEXT, tvdb TEXT, lang TEXT, user TEXT, item TEXT, time TEXT,
		UNIQUE(imdb, tmdb, tvdb, lang, user));''')
		t = int(time())
		for m in meta:
			if "user" not in m: m["user"] = ''
			if "lang" not in m: m["lang"] = 'en'
			i = repr(m['item'])
			try: dbcur.execute('''INSERT OR REPLACE INTO meta Values (?, ?, ?, ?, ?, ?, ?)''', (m.get('imdb', ''), m.get('tmdb', ''), m.get('tvdb', ''), m['lang'], m['user'], i, t))
			except: pass
		dbcur.connection.commit()
	except:
		from resources.lib.modules import log_utils
		log_utils.error()
	finally:
		try:
			dbcur.close()
		except Exception:
			pass
		try:
			dbcon.close()
		except Exception:
			pass
def fetch_light(limit=20):
	"""v1.0.80 — Devuelve metas guardadas en modo LIGERO (sin el bloque images de
	TMDb, así que sin clearlogo ni pósters alternativos) para que el servicio las
	complete en segundo plano.

	Devuelve (filas, pendientes) donde cada fila es
	(tmdb, mediatype, lang, user). `lang`/`user` se devuelven para que el INSERT
	OR REPLACE del refresco caiga sobre ESA fila y no cree una nueva si el idioma
	del addon ha cambiado desde que se guardó.

	La marca es la clave 'meta_light' dentro del repr() del dict, así que el
	filtro barato es un LIKE; el literal_eval solo se paga en las `limit` filas
	que se van a refrescar."""
	rows = [] ; pending = 0
	try:
		dbcon = get_connection()
		dbcur = get_connection_cursor(dbcon)
		ck_table = dbcur.execute('''SELECT * FROM sqlite_master WHERE type='table' AND name='meta';''').fetchone()
		if not ck_table: return rows, 0
		pending = dbcur.execute('''SELECT COUNT(*) FROM meta WHERE item LIKE '%meta_light%' ''').fetchone()[0]
		if not pending: return rows, 0
		# Las más antiguas primero: son las que más lejos quedan de su TTL.
		found = dbcur.execute('''SELECT tmdb, item, lang, user FROM meta WHERE item LIKE '%meta_light%' ORDER BY time ASC LIMIT ?''', (int(limit),)).fetchall()
		for tmdb, item, lang, user in found:
			if not tmdb: continue
			try: mediatype = literal_eval(item).get('mediatype', 'movie')
			except: mediatype = 'movie'
			rows.append((str(tmdb), mediatype, lang, user))
	except:
		from resources.lib.modules import log_utils
		log_utils.error()
	finally:
		try: dbcur.close()
		except Exception: pass
		try: dbcon.close()
		except Exception: pass
	return rows, pending

def remove_by_ids(tmdb_ids):
	"""Borrado SELECTIVO de metas por tmdb id (no toca el resto de la caché).
	Lo usa el precache de arranque para forzar frescura real SOLO de los títulos
	visibles (página 1) sin destruir las ~miles de metas restantes del catálogo,
	que seguirían su TTL normal de 30 días. Devuelve nº de filas eliminadas.

	`tmdb_ids`: iterable de strings/ints. Vacío => no-op (devuelve 0)."""
	ids = [str(i) for i in tmdb_ids if i not in (None, '', 'None')]
	if not ids: return 0
	removed = 0
	try:
		dbcon = get_connection()
		dbcur = get_connection_cursor(dbcon)
		ck_table = dbcur.execute('''SELECT * FROM sqlite_master WHERE type='table' AND name='meta';''').fetchone()
		if not ck_table: return 0
		# Trocear para no superar el límite de variables de SQLite (999) ni montar
		# un IN gigante. 500 ids por lote sobra para una página (~20 títulos).
		for off in range(0, len(ids), 500):
			chunk = ids[off:off+500]
			placeholders = ','.join('?' * len(chunk))
			dbcur.execute('DELETE FROM meta WHERE tmdb IN (%s)' % placeholders, chunk)
			removed += dbcur.rowcount if dbcur.rowcount and dbcur.rowcount > 0 else 0
		dbcur.connection.commit()
	except:
		from resources.lib.modules import log_utils
		log_utils.error()
	finally:
		try: dbcur.close()
		except Exception: pass
		try: dbcon.close()
		except Exception: pass
	return removed

def cache_clear_meta():
	cleared = False
	try:
		dbcon = get_connection()
		dbcur = get_connection_cursor(dbcon)
		dbcur.execute('''DROP TABLE IF EXISTS meta''')
		dbcur.execute('''VACUUM''')
		dbcur.connection.commit()
		cleared = True
	except:
		from resources.lib.modules import log_utils
		log_utils.error()
		cleared = False
	finally:
		try:
			dbcur.close()
		except Exception:
			pass
		try:
			dbcon.close()
		except Exception:
			pass
	return cleared

def get_connection():
	if not existsPath(dataPath): makeFile(dataPath)
	dbcon = db.connect(metacacheFile, timeout=60) # added timeout 3/23/21 for concurrency with threads
	dbcon.execute('''PRAGMA journal_mode = OFF''')
	dbcon.execute('''PRAGMA synchronous = OFF''')
	dbcon.execute('''PRAGMA temp_store = memory''')
	dbcon.execute('''PRAGMA mmap_size = 268435456''')
	# dbcon.row_factory = _dict_factory # not needed for metacache
	return dbcon

def get_connection_cursor(dbcon):
	dbcur = dbcon.cursor()
	return dbcur