
"""
	jacksparrowscrapers Project
"""

import base64
import requests
from urllib.parse import urlparse
from resources.lib.jacksparrow import source_utils
from resources.lib.jacksparrow.control import setting as getSetting


class source:
	timeout = 7
	priority = 1
	pack_capable = False # packs parsed in sources function
	hasMovies = True
	hasEpisodes = True
	def _manifest_info(self, manifest_url):
		if not manifest_url: return None
		try:
			if '://' not in manifest_url:
				manifest_url = 'https://%s' % manifest_url
			parsed = urlparse(manifest_url)
			if not parsed.scheme or not parsed.netloc: return None
			path = parsed.path or ''
			if path.endswith('/manifest.json'):
				path = path[:-len('/manifest.json')]
			marker = '/stremio/'
			marker_index = path.find(marker)
			if marker_index == -1:
				base_path = path.rstrip('/')
				base_url = '%s://%s%s' % (parsed.scheme, parsed.netloc, base_path)
				return {'base_url': base_url.rstrip('/'), 'uuid': None, 'password': None}
			base_path = path[:marker_index]
			base_url = '%s://%s%s' % (parsed.scheme, parsed.netloc, base_path)
			remaining = path[marker_index + len(marker):].lstrip('/')
			parts = [p for p in remaining.split('/') if p]
			uuid = password = None
			if len(parts) >= 2 and parts[0] != 'u':
				uuid, password = parts[0], parts[1]
			return {'base_url': base_url.rstrip('/'), 'uuid': uuid, 'password': password}
		except:
			return None
	def __init__(self):
		self.language = ['en']
		self.authorization = None
		manifest_url = getSetting('aiostreams.manifest_url', '').strip()
		manifest = self._manifest_info(manifest_url) if manifest_url else None
		if manifest and manifest.get('base_url'):
			self.base_link = manifest['base_url']
			if manifest.get('uuid') and manifest.get('password'):
				credentials = '%s:%s' % (manifest['uuid'], manifest['password'])
				basic = base64.b64encode(credentials.encode('utf-8')).decode('utf-8')
				self.authorization = 'Basic %s' % basic
		else:
			instance = int(getSetting('aiostreams.url', '0'))
			custom_link = getSetting('aiostreams.custom_url', '').strip()
			base_links = (
				"https://aiostreams.stremio.ru",
				"https://aiostreamsfortheweebs.midnightignite.me"
			)
			if instance == 2 and custom_link:
				self.base_link = custom_link.rstrip('/')
			else:
				self.base_link = base_links[instance] if 0 <= instance < len(base_links) else base_links[0]
		self.movieSearch_link = '/api/v1/search'
		self.tvSearch_link = '/api/v1/search'
		self.min_seeders = 0
		self.prefer_debrid = getSetting('aiostreams.prefer_debrid', 'true') == 'true'

	def sources(self, data, hostDict):
		sources = []
		if not data: return sources
		sources_append = sources.append
		try:
			title = data['tvshowtitle'] if 'tvshowtitle' in data else data['title']
			title = title.replace('&', 'and').replace('Special Victims Unit', 'SVU').replace('/', ' ')
			aliases = data['aliases']
			episode_title = data['title'] if 'tvshowtitle' in data else None
			total_seasons = data['total_seasons'] if 'tvshowtitle' in data else None
			year = data['year']
			imdb = data['imdb']
			if 'tvshowtitle' in data:
				season = data['season']
				episode = data['episode']
				hdlr = 'S%02dE%02d' % (int(season), int(episode))
				url = '%s%s' % (self.base_link, self.tvSearch_link)
				params = {'type': 'series', 'id': '%s:%s:%s' % (imdb, season, episode)}
			else:
				hdlr = year
				url = '%s%s' % (self.base_link, self.movieSearch_link)
				params = {'type': 'movie', 'id': '%s' % imdb}
			# log_utils.log('url = %s' % url)
			if 'timeout' in data: self.timeout = int(data['timeout'])
			results = requests.get(url, params=params, headers=self._headers(), timeout=self.timeout)
			files = results.json()['data']['results']
			undesirables = source_utils.get_undesirables()
			check_foreign_audio = source_utils.check_foreign_audio()
		except:
			source_utils.scraper_error('AIOSTREAMS')
			return sources

		for file in files:
			try:
				package, episode_start = None, 0
				direct_url = file.get('url')
				use_direct = bool(direct_url) and not direct_url.lower().startswith('magnet:')
				source_type = file.get('type') or 'direct'
				tracker = (file.get('indexer') or file.get('addon') or 'usenet') if source_type == 'usenet' else None
				hash = file.get('infoHash')
				if self.prefer_debrid and hash:
					use_direct = False
				hash = None if use_direct else hash
				file_title = (file['folderName'] or file['filename']).replace('┈➤', '\n').split('\n')

				name = source_utils.clean_name(file_title[0])

				if not source_utils.check_title(title, aliases, name, hdlr, year):
					if total_seasons is None: continue
					valid, last_season = source_utils.filter_show_pack(title, aliases, imdb, year, season, name, total_seasons)
					if not valid:
						valid, episode_start, episode_end = source_utils.filter_season_pack(title, aliases, year, season, name)
						if not valid: continue
						else: package = 'season'
					else: package = 'show'
				name_info = source_utils.info_from_name(name, title, year, hdlr, episode_title)
				if source_utils.remove_lang(name_info, check_foreign_audio): continue
				if undesirables and source_utils.remove_undesirables(name_info, undesirables): continue

				if use_direct:
					url = direct_url
				else:
					url = 'magnet:?xt=urn:btih:%s&dn=%s' % (hash, name)

				try:
					seeders = file['seeders']
					if self.min_seeders > seeders: continue
				except: seeders = 0

				quality, info = source_utils.get_release_quality(name_info, url)
				try:
					size = f"{float(file['size']) / 1073741824:.2f} GB"
					dsize, isize = source_utils._size(size)
					info.insert(0, isize)
				except: dsize = 0
				info = ' | '.join(info)

				if use_direct:
					item = {
						'source': source_type, 'language': 'en', 'direct': True, 'debridonly': False,
						'provider': 'aiostreams', 'url': url, 'name': name, 'name_info': name_info,
						'quality': quality, 'info': info, 'size': dsize, 'seeders': seeders,
						'aiostreams_direct': True, 'debrid': 'aiostreams'
					}
					if tracker:
						item['tracker'] = tracker
				else:
					item = {
						'source': 'torrent', 'language': 'en', 'direct': False, 'debridonly': True,
						'provider': 'aiostreams', 'hash': hash, 'url': url, 'name': name, 'name_info': name_info,
						'quality': quality, 'info': info, 'size': dsize, 'seeders': seeders
					}
				if package: item['package'] = package
				if package == 'show': item.update({'last_season': last_season})
				if episode_start: item.update({'episode_start': episode_start, 'episode_end': episode_end}) # for partial season packs
				sources_append(item)
			except:
				source_utils.scraper_error('AIOSTREAMS')
		return sources

	def _headers(self):
		if self.authorization:
			return {'Authorization': self.authorization}
		return {'x-aiostreams-user-data': (
			'ewogICJwcmVzZXRzIjogWwogICAgewogICAgICAidHlwZSI6ICJ0b3JyZW50aW8iLAogICAgICAiaW5z'
			'dGFuY2VJZCI6ICJlN2IiLAogICAgICAiZW5hYmxlZCI6IGZhbHNlLAogICAgICAib3B0aW9ucyI6IHsK'
			'ICAgICAgICAibmFtZSI6ICJUb3JyZW50aW8iLAogICAgICAgICJ0aW1lb3V0IjogNjUwMCwKICAgICAg'
			'ICAicmVzb3VyY2VzIjogWwogICAgICAgICAgInN0cmVhbSIsCiAgICAgICAgICAiY2F0YWxvZyIsCiAg'
			'ICAgICAgICAibWV0YSIKICAgICAgICBdLAogICAgICAgICJwcm92aWRlcnMiOiBbXSwKICAgICAgICAi'
			'dXNlTXVsdGlwbGVJbnN0YW5jZXMiOiBmYWxzZQogICAgICB9CiAgICB9LAogICAgewogICAgICAidHlw'
			'ZSI6ICJjb21ldCIsCiAgICAgICJpbnN0YW5jZUlkIjogImY3YiIsCiAgICAgICJlbmFibGVkIjogdHJ1'
			'ZSwKICAgICAgIm9wdGlvbnMiOiB7CiAgICAgICAgIm5hbWUiOiAiQ29tZXQiLAogICAgICAgICJ0aW1l'
			'b3V0IjogNjUwMCwKICAgICAgICAicmVzb3VyY2VzIjogWwogICAgICAgICAgInN0cmVhbSIKICAgICAg'
			'ICBdLAogICAgICAgICJpbmNsdWRlUDJQIjogdHJ1ZSwKICAgICAgICAicmVtb3ZlVHJhc2giOiBmYWxz'
			'ZQogICAgICB9CiAgICB9LAogICAgewogICAgICAidHlwZSI6ICJtZWRpYWZ1c2lvbiIsCiAgICAgICJp'
			'bnN0YW5jZUlkIjogIjQ1MCIsCiAgICAgICJlbmFibGVkIjogdHJ1ZSwKICAgICAgIm9wdGlvbnMiOiB7'
			'CiAgICAgICAgIm5hbWUiOiAiTWVkaWFGdXNpb24iLAogICAgICAgICJ0aW1lb3V0IjogNjUwMCwKICAg'
			'ICAgICAicmVzb3VyY2VzIjogWwogICAgICAgICAgInN0cmVhbSIsCiAgICAgICAgICAiY2F0YWxvZyIs'
			'CiAgICAgICAgICAibWV0YSIKICAgICAgICBdLAogICAgICAgICJ1c2VDYWNoZWRSZXN1bHRzT25seSI6'
			'IHRydWUsCiAgICAgICAgImVuYWJsZVdhdGNobGlzdENhdGFsb2dzIjogZmFsc2UsCiAgICAgICAgImRv'
			'd25sb2FkVmlhQnJvd3NlciI6IGZhbHNlLAogICAgICAgICJjb250cmlidXRvclN0cmVhbXMiOiBmYWxz'
			'ZSwKICAgICAgICAiY2VydGlmaWNhdGlvbkxldmVsc0ZpbHRlciI6IFtdLAogICAgICAgICJudWRpdHlG'
			'aWx0ZXIiOiBbXQogICAgICB9CiAgICB9LAogICAgewogICAgICAidHlwZSI6ICJzdHJlbXRocnVUb3J6'
			'IiwKICAgICAgImluc3RhbmNlSWQiOiAiYWVkIiwKICAgICAgImVuYWJsZWQiOiB0cnVlLAogICAgICAi'
			'b3B0aW9ucyI6IHsKICAgICAgICAibmFtZSI6ICJTdHJlbVRocnUgVG9yeiIsCiAgICAgICAgInRpbWVv'
			'dXQiOiA2NTAwLAogICAgICAgICJyZXNvdXJjZXMiOiBbCiAgICAgICAgICAic3RyZWFtIgogICAgICAg'
			'IF0sCiAgICAgICAgImluY2x1ZGVQMlAiOiBmYWxzZSwKICAgICAgICAidXNlTXVsdGlwbGVJbnN0YW5j'
			'ZXMiOiBmYWxzZQogICAgICB9CiAgICB9LAogICAgewogICAgICAidHlwZSI6ICJ0b3JyZW50cy1kYiIs'
			'CiAgICAgICJpbnN0YW5jZUlkIjogImRkMiIsCiAgICAgICJlbmFibGVkIjogdHJ1ZSwKICAgICAgIm9w'
			'dGlvbnMiOiB7CiAgICAgICAgIm5hbWUiOiAiVG9ycmVudHNEQiIsCiAgICAgICAgInRpbWVvdXQiOiA2'
			'NTAwLAogICAgICAgICJyZXNvdXJjZXMiOiBbCiAgICAgICAgICAic3RyZWFtIiwKICAgICAgICAgICJj'
			'YXRhbG9nIiwKICAgICAgICAgICJtZXRhIgogICAgICAgIF0sCiAgICAgICAgInByb3ZpZGVycyI6IFsK'
			'ICAgICAgICAgICJ5dHMiLAogICAgICAgICAgIjEzMzd4IiwKICAgICAgICAgICJ0b3JyZW50Y3N2IiwK'
			'ICAgICAgICAgICIxbG91IiwKICAgICAgICAgICJueWFhIiwKICAgICAgICAgICJza3RvcnJlbnQiLAog'
			'ICAgICAgICAgIjF0YW1pbGJsYXN0ZXJzIiwKICAgICAgICAgICJsaW1ldG9ycmVudCIsCiAgICAgICAg'
			'ICAiMXRhbWlsbXYiLAogICAgICAgICAgInJhcmdiIiwKICAgICAgICAgICJrbmFiZW4iLAogICAgICAg'
			'ICAgInRoZXBpcmF0ZWJheSIsCiAgICAgICAgICAia2lja2Fzc3RvcnJlbnRzIiwKICAgICAgICAgICJh'
			'bmltZXRvc2hvIiwKICAgICAgICAgICJleHRyZW1seW10b3JyZW50cyIsCiAgICAgICAgICAieWdndG9y'
			'cmVudCIsCiAgICAgICAgICAidG9reW90b3NobyIsCiAgICAgICAgICAicnV0b3IiLAogICAgICAgICAg'
			'InJ1dHJhY2tlciIsCiAgICAgICAgICAidG9ycmVudDkiLAogICAgICAgICAgImlsY29yc2Fyb25lcm8i'
			'LAogICAgICAgICAgIm1hbnVhbCIKICAgICAgICBdLAogICAgICAgICJpbmNsdWRlUDJQIjogZmFsc2Us'
			'CiAgICAgICAgInVzZU11bHRpcGxlSW5zdGFuY2VzIjogZmFsc2UKICAgICAgfQogICAgfQogIF0sCiAg'
			'ImZvcm1hdHRlciI6IHsKICAgICJpZCI6ICJ0b3JyZW50aW8iLAogICAgImRlZmluaXRpb24iOiB7CiAg'
			'ICAgICJuYW1lIjogIiIsCiAgICAgICJkZXNjcmlwdGlvbiI6ICIiCiAgICB9CiAgfSwKICAic29ydENy'
			'aXRlcmlhIjogewogICAgImdsb2JhbCI6IFtdCiAgfQp9'
		)}
