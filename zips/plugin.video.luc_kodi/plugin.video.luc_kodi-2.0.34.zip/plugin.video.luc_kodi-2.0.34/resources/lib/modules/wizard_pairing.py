# -*- coding: utf-8 -*-
"""
	luc_kodi Add-on
	wizard_pairing.py (v2.0.30) - how the setup wizards meet the phone or PC.

	Before, each wizard showed its address in a text dialog (OK to go on) and then
	waited behind a small progress bar in a corner. The address had to be typed by
	hand, and nothing on the TV said whether the phone had reached Kodi at all.

	Now every wizard uses the sign-in window of the accounts (modules/device_auth.py):
	a QR made on the device that opens the page straight away, the address in large
	type, the time left, and a status line that changes as soon as the phone opens
	the page ("Page open on 192.168.1.40"). Back or Cancel stops the wizard at once.
	If the window cannot be opened, device_auth falls back to the classic dialog.
"""

import socket
import time

from resources.lib.modules import control
from resources.lib.modules import log_utils


def wait(srv, url, name, timeout, what='your details'):
	"""Show the pairing window until the page sends its form, the user cancels or
	the time runs out. Returns 'done', 'cancelled' or 'timeout'. The caller still
	reads srv.result and stops the server."""
	port = str(url).rsplit(':', 1)[-1]
	from resources.lib.modules import device_auth
	handle = device_auth.start(
		'wizard', url, expires_in=timeout, keep_scheme=True,
		title='Set up %s' % name,
		sub='Fill in %s on your phone or computer' % what,
		status='Waiting for the page to be opened...',
		hint='Same Wi-Fi as this device (not a guest network, no VPN on the phone). '
			 'On this same device: http://127.0.0.1:%s' % port,
		logo=_icon())
	t0, seen, stage = time.time(), None, ''
	outcome = 'timeout'
	try:
		while time.time() - t0 < timeout:
			if srv.result is not None:
				outcome = 'done'
				break
			if not srv.is_alive():
				break
			if handle.iscanceled():
				outcome = 'cancelled'
				break
			try:
				if control.monitor.abortRequested():   # Kodi closing: never keep it waiting
					outcome = 'cancelled'
					break
			except Exception: pass
			peer = getattr(srv, 'seen', None)
			if peer and peer != seen:
				seen = peer
				handle.set_status('Page open on %s: fill it in and press Save' % peer)
			elif not seen:
				# v2.0.25: what reached Kodi so far, so the TV says where it gets stuck
				tls, knock = getattr(srv, 'tls', None), getattr(srv, 'knock', None)
				if tls and stage != 'tls':
					stage = 'tls'
					handle.set_status('The browser on %s asked for https: open %s (with http://)' % (tls, url))
				elif knock and stage not in ('tls', 'knock'):
					stage = 'knock'
					handle.set_status('%s reached this device. Waiting for the page...' % knock)
				elif not knock and not stage and time.time() - t0 > 25:
					stage = 'nothing'
					handle.set_status('Nothing has reached this device yet. Same Wi-Fi, no VPN; on Android allow the browser "Nearby devices" (local network)')
			control.sleep(250)
	finally:
		handle.close()
	# v2.0.34: Guardar en el movil y Atras casi a la vez: el formulario ya ha
	# llegado (o llega en un instante) y no se pierde
	if outcome != 'done' and (seen or getattr(srv, 'seen', None) or getattr(srv, 'result', None) is not None):
		for _ in range(4): # 1 s como mucho, y solo si la pagina llego a abrirse
			if getattr(srv, 'result', None) is not None:
				outcome = 'done'
				break
			if outcome == 'timeout' and not srv.is_alive(): break
			control.sleep(250)
	log_utils.log('%s setup wizard: %s; page opened from %s; https asked by %s; connections from %s'
				  % (name, outcome, seen or 'nobody', getattr(srv, 'tls', None) or 'nobody', getattr(srv, 'knock', None) or 'nobody'),
				  level=log_utils.LOGINFO)
	return outcome


def _icon():
	try: return control.addonIcon()
	except Exception: return ''


# --------------------------------------------------- the wizard servers -----
def knock(srv, addr):
	"""A connection reached the wizard (it may still send nothing: Chrome opens
	spare ones while the address is typed)."""
	try:
		if getattr(srv, 'knock', None) != addr[0]:
			srv.knock = addr[0]
			log_utils.log('setup wizard: connection from %s' % addr[0], level=log_utils.LOGINFO)
	except Exception: pass


def sniff(srv, conn):
	"""False when the connection is not plain HTTP and must be closed now.
	A browser that tries https first sends a TLS handshake (first byte 0x16): the
	wizard has no certificate, so it is closed at once and the browser falls back
	to http instead of waiting on a connection that never answers."""
	try:
		head = conn.recv(1, socket.MSG_PEEK)
	except Exception:
		return False
	if not head:
		return False
	if head[:1] == b'\x16':
		try: peer = conn.getpeername()[0]
		except Exception: peer = '?'
		srv.tls = peer
		try:
			conn.settimeout(1.0)
			conn.recv(16384)                                   # the hello, so the close is clean
			conn.sendall(b'\x15\x03\x01\x00\x02\x02\x28')   # TLS alert: handshake_failure
		except Exception: pass
		log_utils.log('setup wizard: %s asked for https (TLS); closed so the browser uses http' % peer, level=log_utils.LOGINFO)
		return False
	return True


# ------------------------------------------------ one-time code (v2.0.30) ----
# Every wizard address carries a short random code (http://192.168.1.40:48230/
# k7m2qx), so the page only opens from the QR or the address on the TV. Anything
# else on the network that finds the port gets a 403 and no form: some pages
# show what is already saved (the AIOStreams instance, for example).
CODE_CHARS = 'abcdefghjkmnpqrstuvwxyz23456789'   # no 0/o or 1/l/i: easy to type
CODE_LEN = 6

_HTML_WRONG = (b'<!doctype html><html><head><meta charset="utf-8">'
	b'<meta name="viewport" content="width=device-width,initial-scale=1"><title>luc_kodi</title></head>'
	b'<body style="font-family:system-ui,sans-serif;background:#141414;color:#eee;padding:40px 24px">'
	b'<h1 style="color:#00fa9a;font-size:22px">luc_kodi</h1>'
	b'<p style="color:#aaa;line-height:1.5">Open the full address shown on the TV, or scan its QR code.</p></body></html>')


def new_code():
	import random
	rnd = random.SystemRandom()
	return ''.join(rnd.choice(CODE_CHARS) for _ in range(CODE_LEN))


def address(srv, ip, port):
	"""The address the TV shows and the QR opens. Gives the server its code."""
	if not getattr(srv, 'code', None): srv.code = new_code()
	return 'http://%s:%d/%s' % (ip, port, srv.code)


def path_of(headline):
	"""'/k7m2qx' from b'GET /k7m2qx?x=1 HTTP/1.1', without slashes or query."""
	try:
		path = headline.split(b' ')[1].decode('latin-1')
	except Exception:
		return ''
	return path.split('?', 1)[0].split('#', 1)[0].strip('/')


def gate(srv, conn, headline):
	"""True when the request carries this wizard's code. Otherwise it answers
	itself (403 page, or 404 for the browser's favicon) and returns False. A
	server without a code yet lets nothing through."""
	code = getattr(srv, 'code', None)
	path = path_of(headline)
	if code and path == code:
		try: srv._seen_ok = conn.getpeername()[0]
		except Exception: pass
		return True
	# the status line on the TV only follows visits that came with the code
	srv.seen = getattr(srv, '_seen_ok', None)
	if path == 'favicon.ico':
		status, body = b'404 Not Found', b''
	else:
		status, body = b'403 Forbidden', _HTML_WRONG
		try: peer = conn.getpeername()[0]
		except Exception: peer = '?'
		log_utils.log('setup wizard: %s opened the page without the code (403)' % peer, level=log_utils.LOGINFO)
	try:
		conn.sendall(b'HTTP/1.1 ' + status + b'\r\nContent-Type: text/html; charset=utf-8\r\nContent-Length: '
			+ str(len(body)).encode('ascii') + b'\r\nCache-Control: no-store\r\nConnection: close\r\n\r\n' + body)
	except Exception: pass
	return False


def scope(srv, body):
	"""The wizard pages post to "/" and link back to "/": with the code they go
	to "/<code>", or the phone would land on the 403 page."""
	code = getattr(srv, 'code', None)
	if not code or not body: return body
	return body.replace('action="/"', 'action="/%s"' % code).replace('href="/"', 'href="/%s"' % code)
