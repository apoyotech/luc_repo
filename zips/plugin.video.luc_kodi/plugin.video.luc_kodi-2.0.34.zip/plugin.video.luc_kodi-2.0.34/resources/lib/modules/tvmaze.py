# -*- coding: utf-8 -*-
"""
	luc_kodi Add-on
	tvmaze.py (v2.0.16) - TVmaze, alongside TMDb and TheTVDB.

	1. Public API (no key, nothing to sign in):
	   - tells daily and talk shows apart (show type and weekly schedule), so
	     the scrapers also search them by air date, the way their releases are
	     named ("Show.2026.10.20.1080p");
	   - gives the TVmaze episode behind a TMDb season and episode, checked
	     against the air date, for the account features below.
	2. The user's own TVmaze account (username + API key, empty by default):
	   - sign in with the TVmaze email (TVmaze sends a confirmation link, and
	     the same link is in the QR), or type the username and API key from
	     the TVmaze dashboard;
	   - mark episodes as watched when 85% has been played (free accounts too);
	   - TVmaze Followed Shows and Follow / Unfollow (Premium accounts).

	Data: TVmaze.com, CC BY-SA 4.0. Rate limit: about 20 calls every 10 s per
	address, so every answer that does not change often is cached.
"""

import re
import time
import requests
from resources.lib.database import cache
from resources.lib.modules import control
from resources.lib.modules import log_utils
from resources.lib.modules.control import setting as getSetting

API = 'https://api.tvmaze.com'
_TIMEOUT = 6
_PAIR_SECONDS = 900   # how long the sign-in window waits for the confirmation
_POLL_SECONDS = 10    # TVmaze asks for one poll every 10 seconds
# show types whose episodes are released by air date
DAILY_TYPES = ('talk show', 'news', 'variety', 'game show', 'panel show')
PREMIUM_NAMES = {0: 49019, 1: 49020, 2: 49021, 3: 49022}


def getLS(i):
	return control.lang(i)

def _log(msg, level=log_utils.LOGDEBUG):
	log_utils.log('TVMAZE: %s' % msg, level=level)

def _ua():
	try: version = control.getluc_kodiVersion()
	except Exception: version = '2'
	return 'luc_kodi/%s (Kodi add-on plugin.video.luc_kodi)' % version

def _request(method, path, params=None, json=None, auth=None):
	"""One call to TVmaze; one retry after a short pause on HTTP 429.
	Returns the response, or None when TVmaze could not be reached."""
	for attempt in (1, 2):
		try:
			r = requests.request(method, API + path, params=params, json=json, auth=auth, timeout=_TIMEOUT,
								headers={'User-Agent': _ua(), 'Accept': 'application/json'})
		except Exception as e:
			_log('%s %s failed: %s' % (method, path, e.__class__.__name__), log_utils.LOGWARNING)
			return None
		if r.status_code == 429 and attempt == 1:
			time.sleep(2)
			continue
		return r
	return r

def _json(r):
	try: return r.json()
	except Exception: return None

def air_date(value):
	m = re.match(r'^\s*((?:19|20)\d{2})[.-](\d{1,2})[.-](\d{1,2})', str(value or ''))
	if not m: return ''
	return '%04d-%02d-%02d' % (int(m.group(1)), int(m.group(2)), int(m.group(3)))

def _same_name(a, b):
	a = re.sub(r'[^a-z0-9]', '', str(a or '').lower())
	b = re.sub(r'[^a-z0-9]', '', str(b or '').lower())
	return bool(a) and a == b

# ------------------------------------------------------------- public API

def show_lookup(tvdb, imdb):
	"""TVmaze show for a TheTVDB or IMDb id (cached 30 days by the callers).
	'404:NOT FOUND' when TVmaze does not have it, so that is cached too."""
	tvdb, imdb = str(tvdb or '').strip(), str(imdb or '').strip()
	asked = False
	for key, value in (('thetvdb', tvdb if tvdb.isdigit() and tvdb != '0' else ''), ('imdb', imdb if imdb.startswith('tt') else '')):
		if not value: continue
		asked = True
		r = _request('GET', '/lookup/shows', {key: value}) # a match answers with a redirect to the show
		if r is None: return None
		if r.status_code == 200:
			j = _json(r) or {}
			if not j.get('id'): continue
			return {'id': int(j['id']), 'name': j.get('name') or '', 'type': str(j.get('type') or ''),
					'days': len((j.get('schedule') or {}).get('days') or [])}
		if r.status_code != 404:
			_log('lookup %s=%s: HTTP %s' % (key, value, r.status_code), log_utils.LOGINFO)
			return None
	return '404:NOT FOUND' if asked else None

def episode_by_number(show_id, season, episode):
	r = _request('GET', '/shows/%d/episodebynumber' % int(show_id), {'season': int(season), 'number': int(episode)})
	if r is None: return None
	if r.status_code == 200:
		j = _json(r) or {}
		if j.get('id'): return {'id': int(j['id']), 'name': j.get('name') or '', 'airdate': air_date(j.get('airdate'))}
	if r.status_code == 404: return '404:NOT FOUND'
	return None

def episodes_by_date(show_id, date):
	r = _request('GET', '/shows/%d/episodesbydate' % int(show_id), {'date': date})
	if r is None: return None
	if r.status_code == 200:
		return [{'id': int(j['id']), 'name': j.get('name') or ''} for j in (_json(r) or []) if isinstance(j, dict) and j.get('id')]
	if r.status_code == 404: return '404:NOT FOUND'
	return None

def _show(imdb, tvdb):
	show = cache.get(show_lookup, 720, str(tvdb or ''), str(imdb or ''))
	return show if isinstance(show, dict) else None

def is_daily(show):
	if not show: return False
	return show.get('type', '').lower() in DAILY_TYPES or int(show.get('days') or 0) >= 5

def air_info(imdb, tvdb, season, episode, premiered, title=''):
	"""Extra keys for the scrapers' data dict, or {}.
	air_date_search: the show is a daily or talk show, search it by date too.
	premiered: the TVmaze air date, only when TMDb gave none and TVmaze has
	the same episode under the same name (a daily show numbered differently
	on the two sites must never borrow another day's date)."""
	try:
		if getSetting('tvmaze.airdates') == 'false': return {}
		if int(season) < 1 or int(episode) < 1: return {}
		show = _show(imdb, tvdb)
		if not show: return {}
		extra = {}
		if is_daily(show): extra['air_date_search'] = True
		if not air_date(premiered):
			ep = cache.get(episode_by_number, 168, show['id'], int(season), int(episode))
			if isinstance(ep, dict) and ep.get('airdate') and _same_name(ep.get('name'), title):
				extra['premiered'] = ep['airdate']
		if extra: _log('S%02dE%02d of %s -> %s' % (int(season), int(episode), show.get('name'), extra))
		return extra
	except Exception:
		log_utils.error()
		return {}

def resolve_episode(imdb, tvdb, season, episode, premiered='', title=''):
	"""TVmaze episode id for a TMDb season/episode. The number is taken when
	its air date agrees (or no date is known); otherwise the episode aired on
	that date, by name when that day has several."""
	show = _show(imdb, tvdb)
	if not show: return None, None
	date = air_date(premiered)
	ep = cache.get(episode_by_number, 168, show['id'], int(season), int(episode))
	ep = ep if isinstance(ep, dict) else None
	if ep and (not date or ep.get('airdate') == date): return show, ep['id']
	if date:
		day = cache.get(episodes_by_date, 168, show['id'], date)
		if isinstance(day, list) and day:
			if len(day) == 1: return show, day[0]['id']
			for d in day:
				if _same_name(d.get('name'), title): return show, d['id']
	return show, (ep['id'] if ep else None)

# ---------------------------------------------------------- user account

def _creds():
	user = (getSetting('tvmaze.username') or '').strip()
	key = (getSetting('tvmaze.apikey') or '').strip()
	return (user, key) if user and key else None

def getTVmazeCredentialsInfo():
	return bool(_creds())

def getTVmazeScrobbleInfo():
	return getSetting('tvmaze.scrobble') == 'true' and getTVmazeCredentialsInfo()

def _user(method, path, params=None, json=None):
	creds = _creds()
	if not creds: return None
	return _request(method, '/v1' + path, params=params, json=json, auth=creds)

def validate():
	"""Premium level (0 none, 1 Bronze, 2 Silver, 3 Gold), -1 when the username
	or key is refused, None when TVmaze could not be reached."""
	r = _user('GET', '/auth/validate')
	if r is None: return None
	if r.status_code == 200:
		try: level = int((_json(r) or {}).get('premium') or 0)
		except Exception: level = 0
		control.setSetting('tvmaze.premium', str(level))
		return level
	if r.status_code in (401, 403): return -1
	return None

def premium_level():
	try: return int(getSetting('tvmaze.premium'))
	except Exception: pass
	level = validate()
	return level if level is not None else 0

def auth():
	"""Sign in with the TVmaze email: TVmaze emails a confirmation link (the
	same one is in the QR), and luc_kodi receives the username and API key."""
	try:
		email = (control.dialog.input(getLS(49008)) or '').strip()
		if not email: return
		r = _request('POST', '/v1/auth/start', json={'email': email, 'email_confirmation': True})
		if r is None: return control.notification(title='TVmaze', message=49035)
		if r.status_code == 404: return control.okDialog('TVmaze', getLS(49012))
		if r.status_code == 401: return control.okDialog('TVmaze', getLS(49013))
		if r.status_code == 429: return control.okDialog('TVmaze', getLS(49014))
		j = _json(r) or {}
		token, url = j.get('token'), j.get('confirm_url') or 'https://www.tvmaze.com'
		if r.status_code != 200 or not token:
			_log('auth/start: HTTP %s' % r.status_code, log_utils.LOGWARNING)
			return control.notification(title='TVmaze', message=49035)
		from resources.lib.modules import device_auth
		handle = device_auth.start('tvmaze', url=url, code='', qr_data=url, expires_in=_PAIR_SECONDS)
		try: handle.set_status(getLS(49009))
		except Exception: pass
		result, wait, deadline = None, _POLL_SECONDS, time.time() + _PAIR_SECONDS
		try:
			while time.time() < deadline:
				cancelled = False
				for _ in range(wait * 10):
					if handle.iscanceled():
						cancelled = True
						break
					control.sleep(100)
				if cancelled:
					# v2.0.34: confirmado en el correo y Atras antes del siguiente sondeo
					p = _request('POST', '/v1/auth/poll', json={'token': token})
					if p is not None and p.status_code == 200: result = _json(p) or {}
					_log('window closed; last check: %s' % ('signed in' if result else 'not confirmed yet, cancelled'), log_utils.LOGINFO)
					if not result: return
					break
				p = _request('POST', '/v1/auth/poll', json={'token': token})
				if p is None or p.status_code == 403: continue # not confirmed yet
				if p.status_code == 429:
					wait = min(wait + 5, 30)
					continue
				if p.status_code == 200: result = _json(p) or {}
				break # 200, or 404: the request expired or was already answered
		finally:
			handle.close()
		if not result or not result.get('apikey'):
			return control.okDialog('TVmaze', getLS(49011))
		control.setSetting('tvmaze.username', str(result.get('username') or ''))
		control.setSetting('tvmaze.apikey', str(result['apikey']))
		control.setSetting('tvmaze.premium', '')
		control.remember_settings({'tvmaze.username': str(result.get('username') or ''), 'tvmaze.apikey': str(result['apikey']), 'tvmaze.premium': ''})
		validate()
		control.notification(title='TVmaze', message=getLS(49010) % (result.get('username') or ''))
		_log('signed in', log_utils.LOGINFO)
	except Exception:
		log_utils.error()

def deauth():
	try:
		if not control.yesnoDialog(getLS(49015), '', '', 'TVmaze'): return
		for k in ('tvmaze.username', 'tvmaze.apikey', 'tvmaze.premium'): control.setSetting(k, '')
		control.notification(title='TVmaze', message=49016)
	except Exception:
		log_utils.error()

def account_info_to_dialog():
	try:
		if not _creds(): return control.okDialog('TVmaze', getLS(49017))
		level = validate()
		if level is None: return control.okDialog('TVmaze', getLS(49035))
		if level < 0: return control.okDialog('TVmaze', getLS(49017))
		scrobble = getLS(49023) if getSetting('tvmaze.scrobble') == 'true' else getLS(49024)
		control.okDialog('TVmaze', getLS(49018) % (_creds()[0], getLS(PREMIUM_NAMES.get(level, 49019)), scrobble))
	except Exception:
		log_utils.error()

def _notify(message):
	if getSetting('tvmaze.scrobble.notify') == 'true':
		control.notification(title='TVmaze', message=message)

def mark_watched(imdb, tvdb, season, episode, title='', premiered='', force=False):
	"""Mark one episode as watched on TVmaze. Called by the player at 85%
	(in its own thread) and by the TVmaze Manager (force=True)."""
	try:
		if not (force and getTVmazeCredentialsInfo()) and not getTVmazeScrobbleInfo(): return False
		show, ep_id = resolve_episode(imdb, tvdb, season, episode, premiered, title)
		if not show or not ep_id:
			_log('S%sE%s: not found on TVmaze (imdb %s, tvdb %s)' % (season, episode, imdb, tvdb), log_utils.LOGINFO)
			if force: control.notification(title='TVmaze', message=49034)
			return False
		r = _user('PUT', '/scrobble/episodes/%d' % ep_id, json={'marked_at': int(time.time()), 'type': 0})
		if r is not None and r.status_code == 200:
			_log('episode %s of %s marked as watched' % (ep_id, show.get('name')), log_utils.LOGINFO)
			if force: control.notification(title='TVmaze', message=49025)
			else: _notify(getLS(49025))
			return True
		_log('mark %s: %s' % (ep_id, 'no answer' if r is None else 'HTTP %s' % r.status_code), log_utils.LOGWARNING)
		if r is not None and r.status_code in (401, 403) and force: control.okDialog('TVmaze', getLS(49017))
		elif force: control.notification(title='TVmaze', message=49035)
	except Exception:
		log_utils.error()
	return False

def followed_shows():
	"""Followed shows as list items, 'premium' when the account cannot use
	them, or None when TVmaze could not be reached."""
	r = _user('GET', '/user/follows/shows', {'embed': 'show'})
	if r is None: return None
	if r.status_code in (401, 403): return 'premium'
	if r.status_code != 200: return None
	items = []
	for f in _json(r) or []:
		try:
			s = (f.get('_embedded') or {}).get('show') or {}
			ext = s.get('externals') or {}
			name = s.get('name') or ''
			if not name: continue
			items.append({'title': name, 'tvshowtitle': name, 'originaltitle': name, 'year': str(s.get('premiered') or '')[:4],
						'imdb': str(ext.get('imdb') or ''), 'tvdb': str(ext.get('thetvdb') or ''), 'tmdb': ''})
		except Exception: continue
	return items

def followed_directory():
	"""TV Shows > TVmaze Followed Shows. The directory is always loaded, also
	when it ends up empty (reuselanguageinvoker)."""
	items = []
	try:
		result = followed_shows() if getTVmazeCredentialsInfo() else []
		if result == 'premium':
			control.okDialog('TVmaze', getLS(49033))
		elif result is None:
			control.notification(title='TVmaze', message=49035)
		else: items = result
	except Exception:
		log_utils.error()
	from resources.lib.menus.tvshows import TVshows
	tv = TVshows()
	tv.list = items
	if tv.list: tv.worker()
	control.hide()
	tv.tvshowDirectory(tv.list)

def manager(name, imdb='', tvdb='', season=None, episode=None, media_type='show'):
	"""Context menu: follow / unfollow the show, and mark an episode as watched."""
	try:
		if not _creds(): return control.okDialog('TVmaze', getLS(49017))
		show = _show(imdb, tvdb)
		if not show: return control.notification(title='TVmaze', message=49034)
		labels, actions = [], []
		if media_type == 'episode' and season and episode:
			labels.append(getLS(49030)); actions.append('watched')
		state = None
		if premium_level() > 0:
			r = _user('GET', '/user/follows/shows/%d' % show['id'])
			if r is not None and r.status_code in (200, 404): state = r.status_code == 200
		if state is True: labels.append(getLS(49029)); actions.append('unfollow')
		elif state is False: labels.append(getLS(49028)); actions.append('follow')
		if not labels: return control.okDialog('TVmaze', getLS(49033))
		from resources.lib.modules import menu_panel
		choice = menu_panel.select(labels, heading='%s - %s' % (getLS(49027), show.get('name') or name), service='tvmaze')
		if choice < 0: return
		act = actions[choice]
		if act == 'watched': return mark_watched(imdb, tvdb, season, episode, force=True)
		r = _user('PUT' if act == 'follow' else 'DELETE', '/user/follows/shows/%d' % show['id'])
		if r is not None and r.status_code == 200:
			control.notification(title='TVmaze', message=49031 if act == 'follow' else 49032)
		else:
			_log('%s %s: %s' % (act, show['id'], 'no answer' if r is None else 'HTTP %s' % r.status_code), log_utils.LOGWARNING)
			control.notification(title='TVmaze', message=49035)
	except Exception:
		log_utils.error()

def route(action, params):
	if action == 'tvmaze_Authorize': auth()
	elif action == 'tvmaze_Deauthorize': deauth()
	elif action == 'tvmaze_AccountInfo': account_info_to_dialog()
	elif action == 'tvmaze_Followed': followed_directory()
	elif action == 'tvmaze_Manager':
		manager(params.get('name', ''), imdb=params.get('imdb', ''), tvdb=params.get('tvdb', ''),
				season=params.get('season'), episode=params.get('episode'), media_type=params.get('media_type', 'show'))
