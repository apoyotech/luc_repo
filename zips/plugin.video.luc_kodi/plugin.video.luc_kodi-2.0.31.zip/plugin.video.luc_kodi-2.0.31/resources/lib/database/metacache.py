# -*- coding: utf-8 -*-
"""
	luc_kodi Add-on
"""
from ast import literal_eval

from time import time
from sqlite3 import dbapi2 as db
from resources.lib.modules.control import existsPath, dataPath, makeFile, metacacheFile


def _recent(premiered, days=365):
	"""v2.0.28: True si el estreno es de hace menos de un ano (o futuro)."""
	try:
		import datetime
		y, m, d = str(premiered)[:10].split('-')
		return (datetime.date.today() - datetime.date(int(y), int(m), int(d))).days < days
	except Exception: return False


def fetch(items, lang='en', user='', mediatype=None):
	try:
		dbcon = get_connection()
		dbcur = get_connection_cursor(dbcon)
		ck_table = dbcur.execute('''SELECT * FROM sqlite_master WHERE type='table' AND name='meta';''').fetchone()
		if not ck_table:
			dbcur.execute('''CREATE TABLE IF NOT EXISTS meta (imdb TEXT, tmdb TEXT, tvdb TEXT, lang TEXT, user TEXT, item TEXT, time TEXT,
			UNIQUE(imdb, tmdb, tvdb, lang, user));''')
			dbcur.connection.commit()
			try:
				dbcur.close()
			except Exception:
				pass
			try:
				dbcon.close()
			except Exception:
				pass
			return items
		t2 = int(time())
	except:
		from resources.lib.modules import log_utils
		log_utils.error()
	_broken = []
	for i in range(0, len(items)):
		try:
			# v2.0.22 -- UNA FICHA NUNCA PUEDE LLEVARSE LOS METADATOS DE OTRA.
			# Antes se probaban tres consultas (imdb+tvdb, imdb+tmdb y, al final,
			# CUALQUIER id suelto) y se aceptaba la primera fila que saliera, sin
			# mirar si su tmdb era el de la ficha. En la Shield eso hacia que
			# series distintas de Trakt salieran todas como Tracker o Friday the
			# 13th: la fila casaba por un id y traia el tmdb, el poster y los
			# episodios de otra serie. Y como la tabla es comun a peliculas y
			# series, el ultimo recurso por tmdb podia casar ademas una pelicula
			# con el mismo numero.
			# Ahora se leen todas las filas candidatas y se queda la que mejor
			# encaje, con tres reglas:
			#   1. si la ficha trae tmdb, la fila debe tener ESE tmdb;
			#   2. si se sabe el tipo (pelicula/serie), la fila debe ser de ese tipo;
			#   3. una fila cuyo contenido dice otro tmdb que su columna esta rota:
			#      se descarta y se borra, y la ficha se pide de nuevo a TMDb.
			# El orden de preferencia es el de siempre (imdb+tvdb, luego imdb+tmdb).
			match = None ; item = None ; t1 = 0
			want_imdb = str(items[i].get('imdb') or '')
			want_tmdb = str(items[i].get('tmdb') or '')
			want_tvdb = str(items[i].get('tvdb') or '')
			if want_imdb or want_tmdb or want_tvdb:
				rows = dbcur.execute('''SELECT * FROM meta WHERE lang=? AND user=? AND ((imdb=? AND NOT imdb='') OR (tmdb=? AND NOT tmdb='') OR (tvdb=? AND NOT tvdb=''))''',
					(lang, user, want_imdb, want_tmdb, want_tvdb)).fetchall()
				def _rank(r):
					r_imdb, r_tmdb, r_tvdb = str(r[0] or ''), str(r[1] or ''), str(r[2] or '')
					same_imdb = bool(want_imdb) and r_imdb == want_imdb
					same_tvdb = bool(want_tvdb) and r_tvdb == want_tvdb
					same_tmdb = bool(want_tmdb) and r_tmdb == want_tmdb
					try: _t = int(r[6])
					except: _t = 0
					return (same_imdb and same_tvdb, same_imdb and same_tmdb, same_tmdb, same_imdb, same_tvdb, _t)
				for r in sorted(rows, key=_rank, reverse=True):
					r_imdb, r_tmdb = str(r[0] or ''), str(r[1] or '')
					if want_tmdb and r_tmdb and r_tmdb != want_tmdb: continue # regla 1
					if want_tmdb and not r_tmdb and not ((want_imdb and r_imdb == want_imdb) or (want_tvdb and str(r[2] or '') == want_tvdb)): continue
					if want_imdb and r_imdb and r_imdb != want_imdb and not want_tmdb: continue
					try: cand = literal_eval(r[5])
					except: cand = None
					if not isinstance(cand, dict):
						_broken.append(r) ; continue
					c_tmdb = str(cand.get('tmdb') or '')
					if r_tmdb and c_tmdb and c_tmdb != r_tmdb: # regla 3
						_broken.append(r) ; continue
					if want_tmdb and c_tmdb and c_tmdb != want_tmdb: continue
					if mediatype and cand.get('mediatype') and cand.get('mediatype') != mediatype: continue # regla 2
					match, item = r, cand
					try: t1 = int(r[6])
					except: t1 = 0
					break
			if match:
				update = (abs(t2 - t1) / 3600) >= 720 # 30 days? for airing shows this is to much.
				if update: continue

				# v2.0.23 -- UNA FICHA SIN POSTER NO SE GUARDA 30 DIAS.
				# Los estrenos entran en Trending antes de que nadie suba su poster
				# a TMDb. La ficha se guardaba asi, sin poster, y la cache la daba
				# por buena durante 30 dias: aunque TMDb ya tuviera el poster, el
				# plugin seguia pintando "Poster not available yet" (el fanart, que
				# suele subirse antes, si salia). Ahora una pelicula o serie sin
				# poster caduca a las 6 horas y se vuelve a pedir a TMDb; si TMDb
				# sigue sin tenerlo, el coste es una peticion cada 6 horas solo
				# para esas fichas.
				if item.get('mediatype') in ('movie', 'tvshow') and not item.get('poster') \
						and (abs(t2 - t1) / 3600) >= 6:
					continue

				# v2.0.28 -- FICHAS DE PELICULA RECIENTES SIN PRODUCTORA.
				# Desde la v2.0.28 la ficha guarda la productora (la usa
				# home_badges.py para el logo de la Home). Las fichas guardadas
				# antes no la tienen y seguirian asi hasta 30 dias. Una pelicula
				# del ultimo ano sin la marca 'badges_v' (la pone tmdb.py; los
				# campos vacios se borran al guardar) se vuelve a pedir una vez.
				if item.get('mediatype') == 'movie' and not item.get('badges_v') and _recent(item.get('premiered')):
					continue

				# v1.0.64 -- LA COMPROBACION DE FRESCURA NO PUEDE TIRAR LA CACHE.
				# Antes esto iba suelto dentro del try grande de mas abajo: en
				# cuanto algo aqui lanzaba (y lanzaba: cache_existing() devuelve
				# None por diseno cuando Trakt no esta sincronizado, y luego se
				# iteraba -> TypeError: 'NoneType' object is not iterable), el
				# except de fuera se lo tragaba y se saltaba el
				# items[i].update(item) del final. Resultado: el acierto de
				# cache se DESCARTABA y la ficha se volvia a pedir a TMDb.
				# Por eso la metacache "no iba bien" aunque el error pareciera
				# inofensivo en el log.
				# Ahora esto vive en su propio try: si falla, se registra y se
				# usa igualmente la metadata cacheada, que es lo correcto.
				_stale = False
				try:
					if item.get('mediatype') == 'tvshow':
						status = (item.get('status') or '').lower()
						if not any(value in status for value in ('ended', 'canceled')):
							from resources.lib.modules.cleandate import timestamp_from_string
							# `or {}` en vez de default: la clave puede EXISTIR con
							# valor None, y entonces .get() sobre None reventaba.
							_next = (item.get('next_episode_to_air') or {}).get('air_date', '') or ''
							next_episode_to_air = timestamp_from_string(_next)
							if not next_episode_to_air:
								_stale = (abs(t2 - t1) / 3600) >= 168 # 7 days for returning shows with None for next_episode_to_air
							else:
								if next_episode_to_air+(18*3600) <= t2 and (abs(t2 - t1) / 3600) >= 1: # refresh meta when next_episode_to_air is less than or equal to system date, every 1hr starting at 6pm till it flips
									from resources.lib.database.traktsync import cache_existing
									from resources.lib.modules.trakt import syncTVShows
									imdb = item.get('imdb', '')
									indicators = cache_existing(syncTVShows) or []
									watching = [i[0] for i in indicators if i and i[0] == imdb]
									if watching:
										from resources.lib.modules.trakt import cachesyncSeasons
										cachesyncSeasons(imdb) # refreshes only shows you are "watching"
									_stale = True
				except:
					from resources.lib.modules import log_utils
					log_utils.error()
				if _stale: continue

				item = dict((k, v) for k, v in iter(item.items()) if v is not None and v != '')
				items[i].update(item)
				items[i].update({'metacache': True})
		except:
			from resources.lib.modules import log_utils
			log_utils.error()
	if _broken: # v2.0.22: filas con el contenido de otra ficha (ver arriba)
		try:
			seen = set()
			for r in _broken:
				k = tuple(r[:5])
				if k in seen: continue
				seen.add(k)
				dbcur.execute('''DELETE FROM meta WHERE imdb=? AND tmdb=? AND tvdb=? AND lang=? AND user=?''', k)
			dbcur.connection.commit()
			from resources.lib.modules import log_utils
			log_utils.log('[luc_kodi] metacache: %s broken row(s) removed' % len(seen), level=log_utils.LOGINFO)
		except:
			from resources.lib.modules import log_utils
			log_utils.error()
	try: dbcur.close() ; dbcon.close()
	except: pass
	return items

def insert(meta):
	try:
		dbcon = get_connection()
		dbcur = get_connection_cursor(dbcon)
		dbcur.execute('''CREATE TABLE IF NOT EXISTS meta (imdb TEXT, tmdb TEXT, tvdb TEXT, lang TEXT, user TEXT, item TEXT, time TEXT,
		UNIQUE(imdb, tmdb, tvdb, lang, user));''')
		t = int(time())
		for m in meta:
			if "user" not in m: m["user"] = ''
			if "lang" not in m: m["lang"] = 'en'
			i = repr(m['item'])
			try: dbcur.execute('''INSERT OR REPLACE INTO meta Values (?, ?, ?, ?, ?, ?, ?)''', (m.get('imdb', ''), m.get('tmdb', ''), m.get('tvdb', ''), m['lang'], m['user'], i, t))
			except: pass
		dbcur.connection.commit()
	except:
		from resources.lib.modules import log_utils
		log_utils.error()
	finally:
		try:
			dbcur.close()
		except Exception:
			pass
		try:
			dbcon.close()
		except Exception:
			pass
def fetch_light(limit=20):
	"""v1.0.80 — Devuelve metas guardadas en modo LIGERO (sin el bloque images de
	TMDb, así que sin clearlogo ni pósters alternativos) para que el servicio las
	complete en segundo plano.

	Devuelve (filas, pendientes) donde cada fila es
	(tmdb, mediatype, lang, user). `lang`/`user` se devuelven para que el INSERT
	OR REPLACE del refresco caiga sobre ESA fila y no cree una nueva si el idioma
	del addon ha cambiado desde que se guardó.

	La marca es la clave 'meta_light' dentro del repr() del dict, así que el
	filtro barato es un LIKE; el literal_eval solo se paga en las `limit` filas
	que se van a refrescar."""
	rows = [] ; pending = 0
	try:
		dbcon = get_connection()
		dbcur = get_connection_cursor(dbcon)
		ck_table = dbcur.execute('''SELECT * FROM sqlite_master WHERE type='table' AND name='meta';''').fetchone()
		if not ck_table: return rows, 0
		pending = dbcur.execute('''SELECT COUNT(*) FROM meta WHERE item LIKE '%meta_light%' ''').fetchone()[0]
		if not pending: return rows, 0
		# Las más antiguas primero: son las que más lejos quedan de su TTL.
		found = dbcur.execute('''SELECT tmdb, item, lang, user FROM meta WHERE item LIKE '%meta_light%' ORDER BY time ASC LIMIT ?''', (int(limit),)).fetchall()
		for tmdb, item, lang, user in found:
			if not tmdb: continue
			try: mediatype = literal_eval(item).get('mediatype', 'movie')
			except: mediatype = 'movie'
			rows.append((str(tmdb), mediatype, lang, user))
	except:
		from resources.lib.modules import log_utils
		log_utils.error()
	finally:
		try: dbcur.close()
		except Exception: pass
		try: dbcon.close()
		except Exception: pass
	return rows, pending

def remove_by_ids(tmdb_ids):
	"""Borrado SELECTIVO de metas por tmdb id (no toca el resto de la caché).
	Lo usa el precache de arranque para forzar frescura real SOLO de los títulos
	visibles (página 1) sin destruir las ~miles de metas restantes del catálogo,
	que seguirían su TTL normal de 30 días. Devuelve nº de filas eliminadas.

	`tmdb_ids`: iterable de strings/ints. Vacío => no-op (devuelve 0)."""
	ids = [str(i) for i in tmdb_ids if i not in (None, '', 'None')]
	if not ids: return 0
	removed = 0
	try:
		dbcon = get_connection()
		dbcur = get_connection_cursor(dbcon)
		ck_table = dbcur.execute('''SELECT * FROM sqlite_master WHERE type='table' AND name='meta';''').fetchone()
		if not ck_table: return 0
		# Trocear para no superar el límite de variables de SQLite (999) ni montar
		# un IN gigante. 500 ids por lote sobra para una página (~20 títulos).
		for off in range(0, len(ids), 500):
			chunk = ids[off:off+500]
			placeholders = ','.join('?' * len(chunk))
			dbcur.execute('DELETE FROM meta WHERE tmdb IN (%s)' % placeholders, chunk)
			removed += dbcur.rowcount if dbcur.rowcount and dbcur.rowcount > 0 else 0
		dbcur.connection.commit()
	except:
		from resources.lib.modules import log_utils
		log_utils.error()
	finally:
		try: dbcur.close()
		except Exception: pass
		try: dbcon.close()
		except Exception: pass
	return removed

def cache_clear_meta():
	cleared = False
	try:
		dbcon = get_connection()
		dbcur = get_connection_cursor(dbcon)
		dbcur.execute('''DROP TABLE IF EXISTS meta''')
		global _INDEXES_DONE
		_INDEXES_DONE = False # los indices caen con la tabla
		dbcur.execute('''VACUUM''')
		dbcur.connection.commit()
		cleared = True
	except:
		from resources.lib.modules import log_utils
		log_utils.error()
		cleared = False
	finally:
		try:
			dbcur.close()
		except Exception:
			pass
		try:
			dbcon.close()
		except Exception:
			pass
	return cleared

def get_connection():
	if not existsPath(dataPath): makeFile(dataPath)
	dbcon = db.connect(metacacheFile, timeout=60) # added timeout 3/23/21 for concurrency with threads
	dbcon.execute('''PRAGMA journal_mode = OFF''')
	dbcon.execute('''PRAGMA synchronous = OFF''')
	dbcon.execute('''PRAGMA temp_store = memory''')
	dbcon.execute('''PRAGMA mmap_size = 268435456''')
	# dbcon.row_factory = _dict_factory # not needed for metacache
	_ensure_indexes(dbcon)
	return dbcon

# v1.0.90 -- INDICES PARA EL "ULTIMO RECURSO" DE fetch().
# La tercera consulta de fetch() es un OR entre imdb, tmdb y tvdb. El unico
# indice era el implicito de UNIQUE(imdb, tmdb, tvdb, lang, user), que solo
# sirve cuando se busca por imdb, asi que SQLite recorria la tabla ENTERA
# (EXPLAIN QUERY PLAN: "SCAN meta"). Y esa consulta corre siempre que un
# titulo no esta en cache: en cada titulo nuevo de cada pagina. Con estos dos
# indices el plan pasa a "MULTI-INDEX OR" (medido: 2,45 ms -> 0,005 ms por
# fallo con 20.000 filas en memoria; en disco y en Android, mas).
# Se crean una sola vez por proceso; si la tabla aun no existe se reintenta
# en la siguiente conexion.
_INDEXES_DONE = False

def _ensure_indexes(dbcon):
	global _INDEXES_DONE
	if _INDEXES_DONE: return
	try:
		dbcon.execute('''CREATE INDEX IF NOT EXISTS meta_tmdb ON meta (tmdb, lang, user)''')
		dbcon.execute('''CREATE INDEX IF NOT EXISTS meta_tvdb ON meta (tvdb, lang, user)''')
		dbcon.commit()
		_INDEXES_DONE = True
	except Exception:
		pass

def get_connection_cursor(dbcon):
	dbcur = dbcon.cursor()
	return dbcur