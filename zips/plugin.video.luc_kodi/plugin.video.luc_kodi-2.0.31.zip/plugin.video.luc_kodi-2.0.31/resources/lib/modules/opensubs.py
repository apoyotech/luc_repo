# -*- coding: utf-8 -*-
"""
	luc_kodi Add-on
	OpenSubtitles v1 API integration
	---
	How it works:
	  1. The user registers a FREE account at https://www.opensubtitles.com
	     (free tier = 5 subtitle downloads/day per user account)
	  2. User enters username and password in Settings → Subtitles
	  3. On first use, the addon logs in and stores the JWT token automatically
	  4. From then on the stored JWT is reused (refreshed only when expired)
"""

from resources.lib.modules import app_keys
import requests
from resources.lib.modules import control
from resources.lib.modules import log_utils
import xbmc


base_url = 'https://api.opensubtitles.com/api/v1'
api_key  = app_keys.get('opensubs')
version  = control.getluc_kodiVersion()


class Opensubs():
	def __init__(self):
		self.username   = control.setting('opensubsusername')
		self.password   = control.setting('opensubspassword')
		self.jwt_token  = control.setting('opensubstoken')
		self.headers = {
			'Content-Type': 'application/json',
			'Api-Key': api_key,
			'User-Agent': 'luc_kodi v' + version
		}
		self.highlight_color = control.setting('highlight.color')

	def auth(self):
		"""
		Authenticate against OpenSubtitles.
		Returns True if auth is valid or successfully refreshed, False otherwise.
		"""
		url = base_url + '/login'
		# v1.0.63: el nombre de usuario iba entero al log en cada intento, sin
		# condicion de debug. No es la contrasena, pero es un identificador
		# personal que acaba en kodi.log y que el exportador saneado no puede
		# tachar (no es un secreto, es un dato). Se registra solo si hay usuario.
		xbmc.log('[ luc_kodi ] opensubs.auth() — has_user=%s has_token=%s'
		         % (bool(self.username), bool(self.jwt_token)), xbmc.LOGINFO)
		if not self.username or not self.password:
			xbmc.log('[ luc_kodi ] opensubs.auth() — ABORT: username or password empty', xbmc.LOGINFO)
			return False
		data = {
			'username': self.username,
			'password': self.password,
		}
		if self.jwt_token:
			# Validate existing token
			url_info = base_url + '/infos/user'
			headers2 = {
				'Content-Type': 'application/json',
				'Api-Key': api_key,
				'Authorization': self.jwt_token,
				'User-Agent': 'luc_kodi v' + version
			}
			response = requests.get(url_info, headers=headers2, timeout=20)
			xbmc.log('[ luc_kodi ] opensubs.auth() token check: status=%s' % response.status_code, xbmc.LOGINFO)
			if response.status_code == 200:
				return True
			else:
				# Token expired – get a new one
				response2 = requests.post(url, headers=self.headers, json=data, timeout=20)
				xbmc.log('[ luc_kodi ] opensubs.auth() re-login: status=%s' % response2.status_code, xbmc.LOGINFO)
				if response2.status_code == 200:
					control.setSetting('opensubstoken', response2.json().get('token'))
					return True
				else:
					return False
		else:
			# First login
			xbmc.log('[ luc_kodi ] opensubs.auth() — first login attempt', xbmc.LOGINFO)
			response = requests.post(url, headers=self.headers, json=data, timeout=20)
			xbmc.log('[ luc_kodi ] opensubs.auth() first login: status=%s' % response.status_code, xbmc.LOGINFO)
			response = response.json()
			token = response.get('token')
			xbmc.log('[ luc_kodi ] opensubs.auth() first login: has_token=%s' % bool(token), xbmc.LOGINFO)
			control.setSetting('opensubstoken', token)
			return True

	def getSubs(self, title, imdb, year, season=None, episode=None, lang_override=None, lang_codes=None, moviehash=None):
		"""
		Search for subtitle files on OpenSubtitles.
		Returns a list of dicts: [{'fileName': str, 'fileID': int}, ...]
		lang_codes (v2.0.27): OpenSubtitles codes as a list, for the source
		languages of a Gemini translation (several in one request).
		moviehash (v2.0.27): the hash of the file playing (movie_hash()). The
		results stay the same, but the ones uploaded for that exact file come
		back with moviehash_match, which luc_kodi puts first: same file, same
		timing.
		"""
		try:
			# v2.0.04: los codigos de OpenSubtitles (sub_langs.os_codes). Con
			# convertLanguage salian 'pt' y 'zh', que su API no tiene.
			from resources.lib.modules import sub_langs
			if lang_codes:
				# Su API pide los codigos en orden alfabetico (ver sub_langs.os_codes).
				language = ','.join(sorted(set(lang_codes)))
			else:
				language = sub_langs.os_codes(lang_override or control.setting('subtitles.lang.1'))
			if season:
				url = base_url + '/subtitles?imdb_id=%s&season_number=%s&episode_number=%s&languages=%s' % (imdb, season, episode, language)
			else:
				url = base_url + '/subtitles?imdb_id=%s&languages=%s' % (imdb, language)
			if moviehash:
				url += '&moviehash=%s' % moviehash
			xbmc.log('[ luc_kodi ] OpenSubs Searching: IMDB:%s Season:%s Episode:%s Language:%s URL:%s' % (imdb, season, episode, language, url), xbmc.LOGINFO)
			return self._query(url, language, moviehash)
		except:
			log_utils.error()
			return []

	def findOther(self, imdb, language, moviehash=None, episode_title=None):
		"""v2.0.27: subtitles of this series whatever episode number they were
		uploaded under: the ones for this exact file (hash only) and the ones
		named with this episode title (query within the series). language: the
		OpenSubtitles codes, comma separated."""
		from urllib.parse import quote
		out, seen = [], set()
		urls = []
		if moviehash:
			urls.append(base_url + '/subtitles?languages=%s&moviehash=%s' % (language, moviehash))
		parent = str(imdb or '').lower().replace('tt', '').lstrip('0')
		if episode_title and parent.isdigit():
			urls.append(base_url + '/subtitles?languages=%s&parent_imdb_id=%s&query=%s' % (language, parent, quote(episode_title)))
		for url in urls:
			xbmc.log('[ luc_kodi ] OpenSubs Searching (other numbering): URL:%s' % url, xbmc.LOGINFO)
			by_hash = 'moviehash=' in url
			for r in self._query(url, language, moviehash if by_hash else None):
				# From the hash search only what OpenSubtitles marks as this file.
				if r['fileID'] not in seen and (r['hash_match'] or not by_hash):
					seen.add(r['fileID'])
					out.append(r)
		return out

	def _query(self, url, language, moviehash=None):
		try:
			headers = {
				'Content-Type': 'application/json',
				'Api-Key': api_key,
				'Authorization': self.jwt_token,
				'User-Agent': 'luc_kodi v' + version
			}
			response = requests.get(url, headers=headers, timeout=20)
			xbmc.log('[ luc_kodi ] OpenSubs Search response: status=%s' % response.status_code, xbmc.LOGINFO)
			response = response.json()
			response = response['data']
			results = []
			for count, x in enumerate(response):
				try:
					attrs    = response[count]['attributes']
					fileName = attrs.get('files')[0].get('file_name')
					fileID   = attrs.get('files')[0].get('file_id')
					results.append({
						'fileName':         fileName,
						'fileID':           fileID,
						'downloads':        attrs.get('new_download_count', 0) or 0,
						'ratings':          float(attrs.get('ratings', 0) or 0),
						'votes':            int(attrs.get('votes', 0) or 0),
						'trusted':          bool(attrs.get('from_trusted', False)),
						'ai':               bool(attrs.get('ai_translated', False)),
						'machine':          bool(attrs.get('machine_translated', False)),
						'hi':               bool(attrs.get('hearing_impaired', False)),
						'release':          attrs.get('release', '') or '',
						'fps':              float(attrs.get('fps', 0) or 0),
						'language':         attrs.get('language', '') or '',
						'hash_match':       bool(attrs.get('moviehash_match', False)),
					})
				except:
					log_utils.error()
			xbmc.log('[ luc_kodi ] OpenSubs getSubs: found %s results for lang=%s%s' % (len(results), language,
					 (', %d for this exact file' % sum(1 for r in results if r['hash_match'])) if moviehash else ''), xbmc.LOGINFO)
			return results
		except:
			log_utils.error()
			return []

	def downloadSubs(self, fileID, fileName):
		"""
		Request the download link for a subtitle file.
		Returns (download_url, file_name) or (None, None) on failure.
		"""
		try:
			url = base_url + '/download'
			headers = {
				'Content-Type': 'application/json',
				'Api-Key': api_key,
				'Authorization': self.jwt_token,
				'User-Agent': 'luc_kodi v' + version
			}
			data = {'file_id': fileID}
			response = requests.post(url, headers=headers, json=data, timeout=20)
			response = response.json()
			link = response.get('link')
			xbmc.log('[ luc_kodi ] OpenSubs download link: %s  file: %s' % (link, fileName), xbmc.LOGINFO)
			return link, fileName
		except Exception as e:
			xbmc.log('[ luc_kodi ] downloadSubs EXCEPTION: %s' % str(e), xbmc.LOGINFO)
			return None, None

	def getAccountStatus(self):
		"""
		Test credentials and show download quota info in a dialog.
		Called from Settings → Subtitles → Check Account.
		"""
		try:
			url = base_url + '/login'
			if not self.username or not self.password:
				return control.okDialog(title=40503, message='Please enter your OpenSubtitles username and password.')
			data = {
				'username': self.username,
				'password': self.password,
			}
			headers = {
				'Content-Type': 'application/json',
				'Api-Key': api_key,
				'User-Agent': 'luc_kodi v' + version
			}
			response = requests.post(url, headers=headers, json=data, timeout=20)
			response = response.json()
			responseUser  = response.get('user')
			responseToken = response.get('token')
			username      = self.username
			a_downloads   = responseUser.get('allowed_downloads')
			control.setSetting('opensubstoken', responseToken)
			control.openSettings('13.0', 'plugin.video.luc_kodi')
			return control.okDialog(title=40503, message=control.getLangString(40508) % (username, a_downloads))
		except:
			log_utils.error()
			return control.okDialog(title=40503, message='Error checking OpenSubtitles. Please verify your username and password.')

	def revokeAccess(self):
		"""
		Clear stored OpenSubtitles credentials and token.
		Called from Settings → Subtitles → Revoke Token.
		"""
		try:
			control.homeWindow.setProperty('luc_kodi.updateSettings', 'false')
			control.setSetting('opensubsusername', '')
			control.setSetting('opensubspassword', '')
			control.homeWindow.setProperty('luc_kodi.updateSettings', 'true')
			control.setSetting('opensubstoken', '')
			self.jwt_token = ''
			control.openSettings('13.0', 'plugin.video.luc_kodi')
		except:
			log_utils.error()


# ──────────────────────────────────────────────────────────────────────
# v2.0.27: OpenSubtitles hash of the file playing
# ──────────────────────────────────────────────────────────────────────
# A subtitle made for another release of the same episode goes out of sync
# wherever the two differ (a 40 s "previously on", a longer intro, ad breaks
# cut differently): Lucian noticed it after Skip Intro. OpenSubtitles knows
# which subtitles were uploaded for each exact file by this hash: the file size
# plus the 64-bit little-endian sum of its first and last 64 KB. Only those
# 128 KB are read, with HTTP Range, from the debrid link or the local Usenet
# server; nothing else of the video is downloaded.

_HASH_CHUNK = 65536


def _split_kodi_url(url):
	"""'https://x/y|User-Agent=..&Cookie=..' -> ('https://x/y', {headers})."""
	from urllib.parse import unquote_plus
	if '|' not in url:
		return url, {}
	base, opts = url.split('|', 1)
	headers = {}
	for part in opts.split('&'):
		if '=' in part:
			k, v = part.split('=', 1)
			headers[unquote_plus(k)] = unquote_plus(v)
	return base, headers


def _range(url, headers, start, end, timeout):
	"""(bytes, total size or None) of [start, end] with one Range request."""
	h = dict(headers)
	h['Range'] = 'bytes=%d-%d' % (start, end)
	r = requests.get(url, headers=h, timeout=timeout, stream=True)
	try:
		if r.status_code not in (200, 206):
			return None, None
		total = None
		cr = r.headers.get('Content-Range') or ''
		if '/' in cr and cr.rsplit('/', 1)[1].strip().isdigit():
			total = int(cr.rsplit('/', 1)[1])
		elif r.status_code == 200 and (r.headers.get('Content-Length') or '').isdigit():
			total = int(r.headers['Content-Length'])
			if start: return None, None      # no Range support: the start of the file, not the tail
		data = b''
		for chunk in r.iter_content(16384):
			data += chunk
			if len(data) >= end - start + 1:
				break
		return data[:end - start + 1], total
	finally:
		r.close()


def _sum64(data):
	import struct
	n = len(data) // 8
	return sum(struct.unpack('<%dQ' % n, data[:n * 8]))


def movie_hash(url, timeout=8):
	"""16-hex-digit OpenSubtitles hash of the file at `url` (http(s) link or
	local path), or None. Never raises; nothing of the URL is logged (debrid
	links carry tokens)."""
	try:
		if not url:
			return None
		if '://' not in url:
			import os
			if not os.path.isfile(url):
				return None
			size = os.path.getsize(url)
			if size < 2 * _HASH_CHUNK:
				return None
			with open(url, 'rb') as f:
				head = f.read(_HASH_CHUNK)
				f.seek(size - _HASH_CHUNK)
				tail = f.read(_HASH_CHUNK)
		else:
			if not url.lower().startswith(('http://', 'https://')):
				return None
			base, headers = _split_kodi_url(url)
			head, size = _range(base, headers, 0, _HASH_CHUNK - 1, timeout)
			if not head or not size or size < 2 * _HASH_CHUNK or len(head) < _HASH_CHUNK:
				return None
			tail, _ = _range(base, headers, size - _HASH_CHUNK, size - 1, timeout)
			if not tail or len(tail) < _HASH_CHUNK:
				return None
		h = (size + _sum64(head) + _sum64(tail)) & 0xFFFFFFFFFFFFFFFF
		return '%016x' % h
	except Exception as e:
		xbmc.log('[ luc_kodi ] OpenSubs hash not computed: %s' % type(e).__name__, xbmc.LOGINFO)
		return None
