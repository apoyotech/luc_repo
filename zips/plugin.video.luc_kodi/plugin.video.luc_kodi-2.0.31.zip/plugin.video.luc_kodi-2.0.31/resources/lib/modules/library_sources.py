# -*- coding: utf-8 -*-
"""
	luc_kod Add-on
"""

import xml.etree.ElementTree as ET
from resources.lib.modules.control import transPath, existsPath


def add_source(source_name, source_path, source_content, source_thumbnail, type='video'):
	xml_file = transPath('special://profile/sources.xml')
	if not existsPath(xml_file):
		with open(xml_file, 'w') as f:
			f.write(
'''
<sources>
	<programs>
		<default pathversion="1"/>
	</programs>
	<video>
		<default pathversion="1"/>
	</video>
	<music>
		<default pathversion="1"/>
	</music>
	<pictures>
		<default pathversion="1"/>
	</pictures>
	<files>
		<default pathversion="1"/>
	</files>
	<games>
		<default pathversion="1"/>
	</games>
</sources>
''')
	existing_source = _get_source_attr(xml_file, source_name, 'path', type=type)
	if existing_source and existing_source != source_path and source_content != '':
		_remove_source_content(existing_source)
	if _add_source_xml(xml_file, source_name, source_path, source_thumbnail, type=type) and source_content != '':
		_remove_source_content(source_path) # Added to also rid any remains because manual delete sources and kodi leaves behind a record in MyVideos*.db
		_set_source_content(source_content)
	elif source_content != '':
		# La fuente ya estaba en sources.xml: solo se corrige la fila de la base si
		# sigue apuntando a un scraper retirado que ya no esta instalado.
		_repair_legacy_scraper(source_path, source_content)

def _add_source_xml(xml_file, name, path, thumbnail, type='video'):
	tree = ET.parse(xml_file)
	root = tree.getroot()
	sources = root.find(type)
	existing_source = None
	for source in sources.findall('source'):
		xml_name = source.find('name').text
		xml_path = source.find('path').text
		if source.find('thumbnail') is not None:
			xml_thumbnail = source.find('thumbnail').text
		else:
			xml_thumbnail = ''
		if xml_name == name or xml_path == path:
			existing_source = source
			break
	if existing_source is not None:
		xml_name = source.find('name').text
		xml_path = source.find('path').text
		if source.find('thumbnail') is not None:
			xml_thumbnail = source.find('thumbnail').text
		else:
			xml_thumbnail = ''
		if xml_name == name and xml_path == path and xml_thumbnail == thumbnail:
			return False
		elif xml_name == name:
			source.find('path').text = path
			source.find('thumbnail').text = thumbnail
		elif xml_path == path:
			source.find('name').text = name
			source.find('thumbnail').text = thumbnail
		else:
			source.find('path').text = path
			source.find('name').text = name
	else:
		new_source = ET.SubElement(sources, 'source')
		new_name = ET.SubElement(new_source, 'name')
		new_name.text = name
		new_path = ET.SubElement(new_source, 'path')
		new_thumbnail = ET.SubElement(new_source, 'thumbnail')
		new_allowsharing = ET.SubElement(new_source, 'allowsharing')
		new_path.attrib['pathversion'] = '1'
		new_thumbnail.attrib['pathversion'] = '1'
		new_path.text = path
		new_thumbnail.text = thumbnail
		new_allowsharing.text = 'true'
	_indent_xml(root)
	tree.write(xml_file)
	return True

def _indent_xml(elem, level=0):
	i = '\n' + level*'\t'
	if len(elem):
		if not elem.text or not elem.text.strip():
			elem.text = i + '\t'
		if not elem.tail or not elem.tail.strip():
			elem.tail = i
		for elem in elem:
			_indent_xml(elem, level+1)
		if not elem.tail or not elem.tail.strip():
			elem.tail = i
	else:
		if level and (not elem.tail or not elem.tail.strip()):
			elem.tail = i

def _get_source_attr(xml_file, name, attr, type='video'):
	tree = ET.parse(xml_file)
	root = tree.getroot()
	sources = root.find(type)
	for source in sources.findall('source'):
		xml_name = source.find('name').text
		if xml_name == name:
			return source.find(attr).text
	return None

# Columnas de la tabla path que rellena el plugin, en este orden.
_PATH_COLUMNS = ('strPath', 'strContent', 'strScraper', 'strHash', 'scanRecursive', 'useFolderNames',
	'strSettings', 'noUpdate', 'exclude', 'dateAdded', 'idParentPath')

# Scrapers XML retirados que Kodi ya no trae, con el tipo de contenido al que servian.
_LEGACY_SCRAPERS = {'metadata.themoviedb.org': 'movies', 'metadata.tvdb.com': 'tvshows'}

def _db_execute(db_name, command, params=()):
	databaseFile = _get_database(db_name)
	if not databaseFile: return False
	from sqlite3 import dbapi2
	dbcon = dbapi2.connect(databaseFile)
	try:
		dbcur = dbcon.cursor()
		dbcur.execute(command, params)
		dbcon.commit()
		dbcur.close()
	finally:
		dbcon.close()
	return True

def _db_query(db_name, command, params=()):
	databaseFile = _get_database(db_name)
	if not databaseFile: return []
	from sqlite3 import dbapi2
	dbcon = dbapi2.connect(databaseFile)
	try:
		return dbcon.execute(command, params).fetchall()
	finally:
		dbcon.close()

def _get_database(db_name):
	"""Base de Kodi que casa con el patron (p. ej. MyVideos*.db). Si hay varias
	(cada version mayor de Kodi deja la anterior: 131 de Kodi 21, 149 de la RC1
	de Kodi 22, 150 de la RC2...), la de numero mas alto, que es la que usa Kodi.
	glob() no garantiza ningun orden, asi que el [-1] de antes podia escoger
	una base muerta."""
	import re
	from glob import glob
	path_db = 'special://profile/Database/%s' % db_name
	filelist = glob(transPath(path_db))
	if not filelist: return None
	def _num(f):
		m = re.search(r'(\d+)\.db$', f)
		return int(m.group(1)) if m else -1
	return max(filelist, key=_num)

def _like_escape(text):
	return text.replace('\\', '\\\\').replace('%', '\\%').replace('_', '\\_')

def _remove_source_content(path):
	q = "DELETE FROM path WHERE strPath LIKE ? ESCAPE '\\'"
	return _db_execute('MyVideos*.db', q, ('%' + _like_escape(path) + '%',))

def _set_source_content(content):
	"""content: tupla con los valores de _PATH_COLUMNS. Se insertan como
	parametros, asi una ruta con comillas o apostrofes no rompe la consulta."""
	q = 'INSERT OR REPLACE INTO path (%s) VALUES (%s)' % (','.join(_PATH_COLUMNS), ','.join('?' * len(_PATH_COLUMNS)))
	return _db_execute('MyVideos*.db', q, tuple(content))

def _repair_legacy_scraper(path, content):
	try:
		from resources.lib.modules.control import condVisibility
		rows = _db_query('MyVideos*.db', 'SELECT idPath, strScraper FROM path WHERE strPath = ?', (path,))
		for id_path, scraper in rows:
			if _LEGACY_SCRAPERS.get(scraper or '') != content[1]: continue
			if condVisibility('System.HasAddon(%s)' % scraper): continue
			_db_execute('MyVideos*.db', 'UPDATE path SET strScraper = ?, strSettings = ? WHERE idPath = ?', (content[2], content[6], id_path))
	except Exception:
		from resources.lib.modules import log_utils
		log_utils.error()
