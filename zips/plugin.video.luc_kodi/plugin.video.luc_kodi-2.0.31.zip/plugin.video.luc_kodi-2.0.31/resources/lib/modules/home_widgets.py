# -*- coding: utf-8 -*-
"""
	luc_kodi Add-on — modules/home_widgets.py (v2.0.28)

	Las doce filas de la Home (seis por seccion) de luc_kodi, con una ruta corta y fija cada una:

	  plugin://plugin.video.luc_kodi/?action=homewidget&id=movie.netflix

	El skin guarda esa ruta y nada mas. Por dentro abre exactamente la misma
	lista que el menu (Movies > Trending, Movies > Streaming > Netflix, TV shows
	> Networks > Netflix...), con la misma URL y por tanto la misma cache que
	calienta el precache. Si cambia el orden de TMDb o cualquier otro ajuste, la
	ruta del skin sigue valiendo: lo que cambia es la lista que hay detras.

	Movies toma las plataformas de Streaming (el catalogo de cada una) y TV shows
	de Networks (sus series propias), por decision del autor.
"""

import sys

from resources.lib.modules import control
from resources.lib.modules import log_utils

BASE = 'plugin://plugin.video.luc_kodi/?action=homewidget&id=%s'
# v2.0.28: a donde llevan las entradas Movies y TV Shows del menu del skin
MOVIES_MENU = 'plugin://plugin.video.luc_kodi/?action=movieNavigator'
TV_MENU = 'plugin://plugin.video.luc_kodi/?action=tvNavigator'

# (id, tipo, etiqueta, fuente, clave)
#   fuente 'trakt'    -> Movies().get / TVshows().get con la lista de Trakt
#   fuente 'provider' -> plataforma de Movies > Streaming, por su nombre curado
#   fuente 'network'  -> cadena de TV shows > Networks, por su nombre curado
# v2.0.28: de nuevo seis filas por seccion (Trending, Popular y cuatro
# plataformas); HBO Max y Paramount+ salen de la Home por decision del autor.
WIDGETS = (
	('movie.trending', 'movie', 'Trending', 'trakt', 'trakttrending'),
	('movie.popular', 'movie', 'Popular', 'trakt', 'traktpopular'),
	('movie.netflix', 'movie', 'Netflix', 'provider', 'Netflix'),
	('movie.primevideo', 'movie', 'Prime Video', 'provider', 'Amazon Prime Video'),
	('movie.appletv', 'movie', 'Apple TV+', 'provider', 'Apple TV+'),
	('movie.disneyplus', 'movie', 'Disney+', 'provider', 'Disney+'),
	('tv.trending', 'tvshow', 'Trending', 'trakt', 'trakttrending'),
	('tv.popular', 'tvshow', 'Popular', 'trakt', 'traktpopular'),
	('tv.netflix', 'tvshow', 'Netflix', 'network', 'Netflix'),
	('tv.primevideo', 'tvshow', 'Prime Video', 'network', 'Prime Video'),
	('tv.appletv', 'tvshow', 'Apple TV+', 'network', 'Apple TV+'),
	('tv.disneyplus', 'tvshow', 'Disney+', 'network', 'Disney+'),
)

# v2.0.28: el estilo propio de luc_kodi en los nombres que pone en la Home del
# skin (filas y accesos de plataforma). Las entradas Movies y TV Shows del menu
# principal no lo llevan: ahi manda el estilo del skin.
LABEL_STYLE = '[B][COLOR fffdb515]%s[/COLOR][/B]'


def styled(label):
	return LABEL_STYLE % label


# v2.0.28: nombre presente pero invisible, para las fichas que ya muestran el logo.
LABEL_HIDDEN = '[COLOR 00ffffff]%s[/COLOR]'


def hidden(label):
	return LABEL_HIDDEN % label


# v2.0.28: cada fila de la Home se guarda ya montada (lista + metadatos). Un
# widget la sirve al momento aunque tenga horas; si pasa de ROW_FRESH se pide al
# servicio que la renueve en segundo plano y la siguiente vez ya sale nueva.
ROW_FRESH = 3 * 3600
REFRESH_PROP = 'luc_kodi.home.refresh'
# v2.0.29: una fila que no se pudo renovar (sin red, TMDb o Trakt sin contestar)
# no se vuelve a intentar hasta pasado este rato.
RETRY_AFTER = 15 * 60
_FAILED = {}            # id -> cuando fallo (vive en el servicio)

# v2.0.28: el logo de cada plataforma, de la carpeta logos del propio plugin (los
# mismos de Movies > Streaming y TV shows > Networks), por su nombre de fichero.
_LOGO_NAMES = {'Netflix': 'Netflix', 'Prime Video': 'Amazon Prime Video', 'Apple TV+': 'Apple TV+',
	'Disney+': 'Disney+'}
_BY_ID = dict((w[0], w) for w in WIDGETS)


def path(wid):
	return BASE % wid


def rows(mediatype):
	"""[(id, etiqueta, ruta)] de una seccion, en el orden de la Home."""
	return [(w[0], w[2], path(w[0])) for w in WIDGETS if w[1] == mediatype]


def platforms(mediatype):
	"""Solo las cuatro plataformas (para los submenus de los skins)."""
	return [(w[0], w[2], path(w[0])) for w in WIDGETS if w[1] == mediatype and w[3] != 'trakt']


def logo(label):
	"""Ruta special:// del logo de una plataforma, para el icono de los accesos
	directos que crea la Home en el skin. '' si no esta en la carpeta."""
	try:
		import os
		import xbmcvfs
		from resources.lib.indexers.tmdb import local_logo
		from resources.lib.modules.control import artPath, joinPath
		rel = local_logo(_LOGO_NAMES.get(label, label), None)
		if not rel: return ''
		full = joinPath(artPath(), rel)
		home = xbmcvfs.translatePath('special://home/')
		if full.startswith(home): return 'special://home/' + full[len(home):].replace(os.sep, '/')
		return full
	except Exception:
		return ''


def _provider(name):
	"""(provider_id, region) de la tabla curada de Movies > Streaming."""
	from resources.lib.indexers.tmdb import Movies as TMDbMovies
	for n, pid, region in TMDbMovies().watchproviders_curated():
		if n == name: return pid, region or 'US'
	return None, None


def _network(name):
	from resources.lib.indexers.tmdb import TVshows as TMDbTVshows
	for n, nid, _logo in TMDbTVshows().get_networks():
		if n == name: return str(nid)
	return None


def movie_provider_url(menu, name):
	"""La misma URL que construyen Movies > Streaming y el precache."""
	pid, region = _provider(name)
	if not pid: return None
	url = menu.tmdb_watchproviders_link % ('%s', pid)
	if region != 'US':
		url = url.replace('region=US&watch_region=US', 'region=%s&watch_region=%s' % (region, region))
	return url


def _menu(mediatype):
	if mediatype == 'movie':
		from resources.lib.menus.movies import Movies
		return Movies()
	from resources.lib.menus.tvshows import TVshows
	return TVshows()


def _row_list(wid):
	"""La fila ya montada: la misma lista y los mismos metadatos que abre el
	menu, sin pintarla. Es lo que se guarda en la cache (cache.get)."""
	w = _BY_ID.get(wid or '')
	if not w: return None
	_wid, mediatype, _label, source, key = w
	menu = _menu(mediatype)
	if source == 'trakt': return menu.get(key, create_directory=False) or None
	if mediatype == 'movie':
		url = movie_provider_url(menu, key)
	else:
		nid = _network(key)
		url = menu.tmdb_networks_link % ('%s', nid) if nid else None
	if not url:
		log_utils.log('homewidget: %s not found in the curated lists' % wid)
		return None
	return menu.getTMDb(url, create_directory=False) or None


def row_items(wid):
	"""Lo guardado, tenga la edad que tenga; si no hay nada, se monta ahora."""
	import time
	from resources.lib.database import cache
	items = cache.cache_existing(_row_list, wid)
	if items:
		if time.time() - cache.timeout(_row_list, wid) > ROW_FRESH:
			control.homeWindow.setProperty(REFRESH_PROP, 'true')
		return items
	return cache.get(_row_list, ROW_FRESH // 3600, wid)


def refresh_rows():
	"""Desde el servicio: vuelve a montar las filas que ya se han usado y
	tienen mas de ROW_FRESH. Una a una, en segundo plano."""
	import time
	from resources.lib.database import cache
	done = []
	for wid, *_rest in WIDGETS:
		try:
			stamp = cache.timeout(_row_list, wid)
			if not stamp or time.time() - stamp <= ROW_FRESH: continue
			if time.time() - _FAILED.get(wid, 0) < RETRY_AFTER: continue
			cache.get(_row_list, 0, wid)
			# v2.0.29: renovada solo si su fecha ha avanzado. Sin red, cache.get
			# devuelve la fila vieja sin tocar su fecha: antes contaba como
			# renovada, se pedia a Nimbus que la recargara, seguia vieja, volvia a
			# pedir renovacion y asi cada minuto mientras durara el corte.
			if cache.timeout(_row_list, wid) > stamp:
				done.append(wid); _FAILED.pop(wid, None)
			else: _FAILED[wid] = time.time()
		except Exception: log_utils.error()
	control.homeWindow.clearProperty(REFRESH_PROP)
	if done:
		log_utils.log('luc_kodi Home: %d rows refreshed in the background' % len(done))
		reload_skin_rows(done)
	return len(done)


# v2.0.28: Nimbus Plus pone en cada fila de un addon una marca
# (Window(Home).Property(nimbus.widget_reload.<list_id>)) que forma parte de su
# ruta: si cambia, Kodi vuelve a pedir la fila. Es lo que hace su "Refresh
# widgets". luc_kodi la cambia solo en las filas que acaba de renovar, y la Home
# se pone al dia sin recargar el skin. En los demas skins no hace nada.
NIMBUS_LIST_BASE = {'movie': 19010, 'tvshow': 22010}


def _nimbus_list_ids(wids):
	import os
	import sqlite3
	import xbmc
	import xbmcvfs
	if (xbmc.getSkinDir() or '').lower() != 'skin.nimbus': return []
	try:
		with open(xbmcvfs.translatePath('special://skin/xml/script-nimbus-widget_movies.xml'), encoding='utf-8') as f:
			if 'nimbus.widget_reload.' not in f.read(): return [] # el Nimbus oficial no la tiene
	except Exception: return []
	db = xbmcvfs.translatePath('special://profile/addon_data/script.nimbus.helper/cpath_cache.db')
	if not os.path.isfile(db): return []
	want = dict((path(w), w) for w in wids)
	out = []
	con = sqlite3.connect(db, timeout=5)
	try:
		for setting, cpath in con.execute("SELECT cpath_setting, cpath_path FROM custom_paths WHERE cpath_setting LIKE 'movie.widget.%' OR cpath_setting LIKE 'tvshow.widget.%'"):
			if cpath not in want: continue
			media, _w, slot = setting.split('.')
			if slot.isdigit(): out.append(NIMBUS_LIST_BASE[media] + int(slot))
	finally:
		con.close()
	return sorted(out)


def reload_skin_rows(wids):
	try:
		import time
		ids = _nimbus_list_ids(wids)
		if not ids: return 0
		token = str(int(time.time() * 1000))
		for list_id in ids: control.homeWindow.setProperty('nimbus.widget_reload.%d' % list_id, token)
		log_utils.log('luc_kodi Home: asked Nimbus to reload rows %s' % ids)
		return len(ids)
	except Exception:
		log_utils.error()
		return 0


def run(wid):
	w = _BY_ID.get(wid or '')
	items = row_items(wid) if w else None
	if not items:
		if not w: log_utils.log('homewidget: unknown id %s' % wid)
		control.directory(int(sys.argv[1]), cacheToDisc=False)
		return
	menu = _menu(w[1])
	# v2.0.28: fila de la Home (home_badges.py: calidad y logo en Nimbus / FENtastic)
	menu.home_row = True
	if w[3] in ('provider', 'network'): # v2.0.28: series tambien
		for i in items:
			if isinstance(i, dict): i['luc_home_studio'] = w[2]
	if w[1] == 'movie': menu.movieDirectory(items)
	else: menu.tvshowDirectory(items)


def sync_precache():
	"""Las cuatro plataformas y cadenas de la Home pasan al nivel rapido del
	precache (si caben: el limite sigue siendo el de Ajustes) y se encienden sus
	interruptores, para que las filas carguen al instante. No quita nada de lo
	que el usuario ya habia marcado. Devuelve cuantas se han anadido."""
	from resources.lib.modules.catalog_updater import (S_PRE_STREAM, S_PRE_STREAM_IDS,
		S_PRE_NET, S_PRE_NET_IDS, MAX_PRECACHE_PLATFORMS)
	added = 0
	try:
		cur = [i for i in (control.setting(S_PRE_STREAM_IDS) or '').split(',') if i.strip()]
		for w in WIDGETS:
			if w[3] != 'provider': continue
			pid, region = _provider(w[4])
			key = '%s:%s' % (pid, region) if pid else None
			if key and key not in cur and len(cur) < MAX_PRECACHE_PLATFORMS:
				cur.append(key); added += 1
		control.setSetting(S_PRE_STREAM_IDS, ','.join(cur))
		if cur: control.setSetting(S_PRE_STREAM, 'true')
	except Exception: log_utils.error()
	try:
		from resources.lib.indexers.tmdb import canonical_network_ids
		cur = [i for i in canonical_network_ids((control.setting(S_PRE_NET_IDS) or '').split(',')) if i]
		for w in WIDGETS:
			if w[3] != 'network': continue
			nid = _network(w[4])
			if nid and nid not in cur and len(cur) < MAX_PRECACHE_PLATFORMS:
				cur.append(nid); added += 1
		control.setSetting(S_PRE_NET_IDS, ','.join(cur))
		if cur: control.setSetting(S_PRE_NET, 'true')
	except Exception: log_utils.error()
	return added
