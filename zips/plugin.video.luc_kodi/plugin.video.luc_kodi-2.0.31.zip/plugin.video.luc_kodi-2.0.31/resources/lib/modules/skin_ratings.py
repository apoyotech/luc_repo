# -*- coding: utf-8 -*-
"""
	luc_kodi Add-on — modules/skin_ratings.py (v2.0.28)

	Las notas de luc_kodi en la fila (o panel) de valoraciones de Nimbus,
	Nimbus Plus, FENtastic y FENtastic Plus, sin clave de MDbList.

	Esa fila la rellena el ayudante de cada skin con MDbList, y el skin solo la
	dibuja si hay una clave de MDbList. Sin clave no se ve ninguna nota, aunque
	luc_kodi ya las tenga: TMDb sale del propio item y Trakt del endpoint
	publico con la clave del addon, sin pedir nada al usuario. Con una clave de
	OMDb en luc_kodi salen ademas IMDb, Rotten Tomatoes y Metacritic (la misma
	cascada de ratings.py que usan la ventana de fuentes y el reproductor).

	Nimbus / Nimbus Plus (script.nimbus.helper)
	  - Apply marca Skin.String(valid_api_key) con 'luc_kodi' (el ayudante pone
	    'true' cuando la clave es suya). El skin solo mira que no este vacio; el
	    campo de la clave sigue diciendo "Enter key". Sin clave de MDbList el
	    ayudante esta parado, asi que no hay nadie mas escribiendo la fila.
	  - Si los seis huecos estaban en "none" se ponen IMDb, RT, Metacritic,
	    Trakt y TMDb.
	  - Propiedades en Window(Home): nimbus.tmdbRating, nimbus.traktRating...

	FENtastic / FENtastic Plus (script.fentastic.helper)
	  - El skin dibuja el panel si Skin.String(mdblist_api_key) no esta vacio, y
	    el ayudante usa ese texto como clave. Apply escribe 'luc_kodi' ahi
	    (decision de Lucian, 8-nov-2026).
	  - Para que el ayudante no pregunte a MDbList por los titulos de luc_kodi,
	    su cache (ratings_cache.db y fentastic.cachedRatings.<imdb>) se rellena
	    antes con nuestras notas: al montar cada pagina y al enfocar. Los
	    titulos que no son de luc_kodi (los de la biblioteca) si le hacen
	    preguntar con la marca, MDbList la rechaza y el ayudante guarda la
	    respuesta vacia 7 dias.
	  - FENtastic no tiene hueco para Trakt: va en el de popularidad de IMDb
	    (fentastic.popularRating) con el icono de Trakt de luc_kodi. El hueco
	    de valoracion del publico de RT queda vacio.
	  - Propiedades en la ventana activa (como el ayudante): fentastic.*.

	Los dos
	  - Solo los items de luc_kodi: en cualquier otro item la fila se vacia.
	  - Si el usuario pone su propia clave de MDbList, el ayudante vuelve a
	    mandar y este bucle se aparta. Restore lo deja todo como estaba.
	  - Lo primero que se pinta sale del propio item (lo que ya estaba en la
	    cache). Si falta algo, tras medio segundo quieto en el item se pide en
	    segundo plano, con la cache de 24 h (Trakt) y 48 h (OMDb) de ratings.py.
"""

import json
import threading

from resources.lib.modules import control
from resources.lib.modules import log_utils

MARK = 'luc_kodi'          # lo que escribe Apply en la clave / marca del skin
NIMBUS_KEYS = ('tmdbRating', 'tmdbImage', 'traktRating', 'traktImage', 'imdbRating', 'imdbImage',
	'tomatoMeter', 'tomatoImage', 'metascore', 'metascoreImage')
FEN_KEYS = ('metascore', 'metascoreImage', 'tomatoMeter', 'tomatoImage', 'tomatoUserMeter', 'tomatoUserImage',
	'imdbRating', 'imdbImage', 'popularRating', 'popularImage', 'tmdbRating', 'tmdbImage')
SLOTS = ('imdb', 'rtc', 'metacritic', 'trakt', 'tmdb', 'none')
_NIMBUS_IMG = 'special://home/addons/skin.nimbus/resources/rating_images/%s.png'
_FEN_IMG = 'special://home/addons/skin.fentastic/resources/rating_images/%s.png'
_FEN_TRAKT = 'special://home/addons/plugin.video.luc_kodi/resources/skins/Default/media/ratings/rating_trakt.png'
_FEN_DB = 'special://profile/addon_data/script.fentastic.helper/ratings_cache.db'
_POLL = 0.25               # como los ayudantes (0.2 s)
_SETTLE = 0.5              # quieto en el item antes de pedir a la red
_IDLE = 3.0                # fuera de estos skins, o con la fila en manos del ayudante
_VISIBLE = ('Window.IsVisible(videos) | Window.IsVisible(home) | Window.IsVisible(11121) | '
	'Window.IsActive(movieinformation)')
_ADDON_PATH = 'plugin://plugin.video.luc_kodi/'


def _label(name):
	return control.infoLabel(name) or ''


def _skin():
	try:
		import xbmc
		return xbmc.getSkinDir()
	except Exception: return ''


def active():
	"""'skin.nimbus' / 'skin.fentastic' si la fila es de luc_kodi; '' si no."""
	skin = _skin()
	if skin == 'skin.nimbus':
		ok = _label('Skin.String(valid_api_key)') == MARK and not _label('Skin.String(mdblist_api_key)')
	elif skin == 'skin.fentastic':
		ok = _label('Skin.String(mdblist_api_key)') == MARK
	else: ok = False
	return skin if ok else ''


def _num(value):
	try: return float(str(value).replace('%', '').strip())
	except (TypeError, ValueError): return None


def _parts(r):
	"""Lo comun a los dos skins: (tmdb, trakt, imdb, rt, metacritic) como numeros o None."""
	r = r or {}
	imdb = _num(r.get('imdb')) if r.get('imdb_source') in (None, '', 'imdb') else None
	mc = _num(r.get('metacritic') or (r.get('imdb') if r.get('imdb_source') == 'metacritic' else ''))
	return _num(r.get('tmdb')), _num(r.get('trakt')), imdb, _num(r.get('rt')), mc


def nimbus_values(r):
	"""Las notas de ratings.fetch() con los nombres y la escala de Nimbus
	(los de su ayudante): TMDb, Trakt e IMDb sobre 10, RT y Metacritic sobre
	100, y la imagen de cada casa. Lo que no hay va vacio, para que el skin lo oculte."""
	out = dict((k, '') for k in NIMBUS_KEYS)
	tmdb, trakt, imdb, rt, mc = _parts(r)

	def put(value_key, image_key, value, image):
		out[value_key], out[image_key] = value, _NIMBUS_IMG % image
	if tmdb: put('tmdbRating', 'tmdbImage', '%.1f' % tmdb, 'tmdb')
	if trakt: put('traktRating', 'traktImage', '%.1f' % trakt, 'trakt')
	if imdb: put('imdbRating', 'imdbImage', '%.1f' % imdb, 'imdb')
	if rt: put('tomatoMeter', 'tomatoImage', '%d' % rt, 'rtfresh' if rt > 59 else 'rtrotten')
	if mc: put('metascore', 'metascoreImage', '%d' % mc, 'metacritic')
	return out


def fentastic_values(r):
	"""Lo mismo con los nombres y umbrales del ayudante de FENtastic (RT
	certificado por encima de 74). Trakt va en el hueco de popularidad."""
	out = dict((k, '') for k in FEN_KEYS)
	tmdb, trakt, imdb, rt, mc = _parts(r)

	def put(value_key, image_key, value, image):
		out[value_key], out[image_key] = value, image
	if tmdb: put('tmdbRating', 'tmdbImage', '%.1f' % tmdb, _FEN_IMG % 'tmdb')
	if trakt: put('popularRating', 'popularImage', '%.1f' % trakt, _FEN_TRAKT)
	if imdb: put('imdbRating', 'imdbImage', '%.1f' % imdb, _FEN_IMG % 'imdb')
	if rt: put('tomatoMeter', 'tomatoImage', '%d' % rt, _FEN_IMG % ('rtcertified' if rt > 74 else 'rtfresh' if rt > 59 else 'rtrotten'))
	if mc: put('metascore', 'metascoreImage', '%d' % mc, _FEN_IMG % 'metacritic')
	return out


def values_for(skin, r):
	return fentastic_values(r) if skin == 'skin.fentastic' else nimbus_values(r)


# ─────────────── la cache del ayudante de FENtastic ───────────────
def _fen_db():
	import sqlite3
	path = control.transPath(_FEN_DB)
	control.makeFile(control.transPath('special://profile/addon_data/script.fentastic.helper/'))
	con = sqlite3.connect(path, timeout=10)
	con.execute('CREATE TABLE IF NOT EXISTS ratings (imdb_id TEXT PRIMARY KEY, ratings TEXT, last_updated TIMESTAMP)')
	return con


def fentastic_store(rows):
	"""[(imdb, values)] a ratings_cache.db del ayudante, con su formato (fecha
	con microsegundos: su lector la exige)."""
	rows = [(i, v) for i, v in rows if i and str(i).startswith('tt')]
	if not rows: return
	try:
		import datetime
		now = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S.%f')
		con = _fen_db()
		try:
			con.executemany('INSERT OR REPLACE INTO ratings (imdb_id, ratings, last_updated) VALUES (?, ?, ?)',
				[(i, json.dumps(v), now) for i, v in rows])
			con.commit()
		finally: con.close()
	except Exception:
		log_utils.error()


class FentasticPrefill:
	"""Al montar una pagina: las notas de cada titulo a la cache del ayudante,
	de una vez, para que no le pregunte a MDbList con la marca. No hace nada
	fuera de FENtastic o sin la marca."""

	def __init__(self):
		self.on = active() == 'skin.fentastic'
		self.rows = []

	def add(self, imdb, r):
		if self.on and imdb: self.rows.append((imdb, fentastic_values(r)))

	def flush(self):
		if self.rows: fentastic_store(self.rows)
		self.rows = []


# ─────────────── el bucle del servicio ───────────────
def _from_item():
	"""Lo que ya trae el item enfocado (skin_props.decorate), sin red."""
	p = lambda k: _label('ListItem.Property(luc_kodi.rating.%s)' % k)
	return {'tmdb': p('tmdb') or _label('ListItem.Rating'), 'trakt': p('trakt'), 'imdb': p('imdb'),
		'rt': p('rt'), 'metacritic': p('metacritic')}


def _wants_network(r):
	if not r.get('trakt'): return True
	if (control.setting('omdb.apikey') or '').strip():
		return not (r.get('imdb') and r.get('rt') and r.get('metacritic'))
	return False


def _focused():
	"""(clave, meta) del item enfocado si es de luc_kodi; (None, None) si no."""
	path = _label('ListItem.FileNameAndPath') or _label('ListItem.Path')
	ours = path.startswith(_ADDON_PATH) or bool(_label('ListItem.Property(luc_kodi.rating.tmdb)'))
	imdb = _label('ListItem.IMDBNumber')
	if not ours or not imdb.startswith('tt'): return None, None
	dbtype = _label('ListItem.DBType').lower()
	mediatype = {'movie': 'movie', 'episode': 'episode'}.get(dbtype, 'tvshow')
	meta = {'imdb': imdb, 'mediatype': mediatype, 'rating': _from_item()['tmdb'],
		'season': _label('ListItem.Season'), 'episode': _label('ListItem.Episode')}
	key = imdb if mediatype != 'episode' else '%s:%s:%s' % (imdb, meta['season'], meta['episode'])
	return key, meta


def _window(wid):
	"""v2.0.29: la ventana por su numero, recien pedida y para usarla en el
	momento. Un xbmcgui.Window de una ventana existente apunta directamente a la
	ventana de Kodi: si se guarda y el skin se recarga (o la ventana es una de las
	propias del skin, como la 11121 de FENtastic, que Kodi destruye y vuelve a
	crear), el objeto guardado apunta a memoria liberada y escribir en el tumba
	Kodi sin traza de Python. None si esa ventana ya no existe."""
	if wid == 10000: return control.homeWindow
	try:
		import xbmcgui
		return xbmcgui.Window(wid)
	except Exception:
		return None


class _Publisher:
	"""Escribe las propiedades del skin, solo las que cambian.
	v2.0.29: guarda el NUMERO de la ventana, nunca el objeto (ver _window)."""

	def __init__(self):
		self.skin = self.wid = None
		self.shown = None

	def _target(self, skin):
		if skin == 'skin.fentastic':
			import xbmcgui
			return xbmcgui.getCurrentWindowId(), 'fentastic.', FEN_KEYS
		return 10000, 'nimbus.', NIMBUS_KEYS

	def show(self, skin, values, imdb=None):
		wid, prefix, keys = self._target(skin)
		if wid != self.wid or skin != self.skin: self.clear(); self.shown = None
		self.skin, self.wid = skin, wid
		window = _window(wid)
		if window is None:
			self.shown = None
			return
		if values != self.shown:
			for k in keys:
				v = values.get(k, '')
				if not self.shown or self.shown.get(k) != v: window.setProperty(prefix + k, v)
			self.shown = dict(values)
		if skin == 'skin.fentastic' and imdb:
			window.setProperty('fentastic.cachedRatings.%s' % imdb, json.dumps(values))

	def clear(self):
		if self.shown is None or self.wid is None: return
		prefix, keys = ('fentastic.', FEN_KEYS) if self.skin == 'skin.fentastic' else ('nimbus.', NIMBUS_KEYS)
		self.shown = None
		window = _window(self.wid)
		if window is None: return
		for k in keys: window.setProperty(prefix + k, '')


def service_loop():
	monitor = control.monitor
	pub = _Publisher()
	current = fetched = None
	since = 0.0
	lock = threading.Lock()
	result = {}

	def fetch(key, meta):
		try:
			from resources.lib.modules import ratings
			r = ratings.fetch(meta, live=True)
			with lock: result[key] = r
		except Exception:
			log_utils.error()

	while not monitor.abortRequested():
		skin = active()
		if not skin:
			pub.clear(); current = None
			if monitor.waitForAbort(_IDLE): return
			continue
		if not control.condVisibility(_VISIBLE):
			if monitor.waitForAbort(1): return
			continue
		try:
			key, meta = _focused()
			imdb = meta['imdb'] if meta else None
			if key is None:
				pub.clear(); current = None
			elif key != current:
				current, fetched, since = key, None, 0.0
				pub.show(skin, values_for(skin, _from_item()), imdb)
			else:
				with lock: got = result.pop(key, None)
				if got is not None:
					merged = _from_item()
					for k, v in got.items():
						if v and not merged.get(k): merged[k] = v
					if got.get('imdb_source'): merged['imdb_source'] = got['imdb_source']
					values = values_for(skin, merged)
					pub.show(skin, values, imdb)
					if skin == 'skin.fentastic' and meta['mediatype'] != 'episode': fentastic_store([(imdb, values)])
				elif fetched != key:
					since += _POLL
					if since >= _SETTLE:
						fetched = key
						if _wants_network(_from_item()):
							threading.Thread(target=fetch, args=(key, meta), daemon=True).start()
		except Exception:
			log_utils.error()
		if monitor.waitForAbort(_POLL): return


# ───────────────────────── Apply / Restore de la Home ─────────────────────────
def setup_state(skin):
	"""Lo que Apply va a tocar, como esta ahora (para Restore)."""
	if skin == 'skin.fentastic': return {'mdblist_api_key': _label('Skin.String(mdblist_api_key)')}
	out = {'valid_api_key': _label('Skin.String(valid_api_key)')}
	for n in range(1, 7): out['RatingSlot%d' % n] = _label('Skin.String(RatingSlot%d)' % n)
	return out


def can_take_over(skin):
	"""Solo cuando la fila esta apagada por falta de clave de MDbList."""
	key = _label('Skin.String(mdblist_api_key)')
	if skin == 'skin.fentastic': return key in ('', MARK)
	if skin == 'skin.nimbus': return not key and _label('Skin.String(valid_api_key)') in ('', MARK)
	return False


def take_over(skin):
	import xbmc
	if skin == 'skin.fentastic':
		xbmc.executebuiltin('Skin.SetString(mdblist_api_key,%s)' % MARK)
		return
	xbmc.executebuiltin('Skin.SetString(valid_api_key,%s)' % MARK)
	slots = [_label('Skin.String(RatingSlot%d)' % n) for n in range(1, 7)]
	if all(s in ('', 'none') for s in slots):
		for n, s in enumerate(SLOTS, 1): xbmc.executebuiltin('Skin.SetString(RatingSlot%d,%s)' % (n, s))


def ours_now(name):
	"""Restore: la clave / marca solo se devuelve si sigue siendo la nuestra
	(si el usuario ha puesto la suya, es del ayudante)."""
	return _label('Skin.String(%s)' % name) == MARK
