# -*- coding: utf-8 -*-
"""
	luc_kodi Add-on
	keys_wizard.py (v2.0.30) - Gemini and OMDb keys from the phone or PC.

	A Gemini key is made in Google AI Studio and an OMDb key arrives by e-mail:
	both are on the phone, and typing 39 characters with the remote is the hard
	part. Same way as the MDBList and Newznab wizards: a small page served by
	Kodi on the home network, opened with the QR of the pairing window
	(modules/wizard_pairing.py), and "type it here" as the fallback.

	What is different here:
	- The address carries a short one-time code (/k7m2qx), the same gate as every
	  setup wizard since v2.0.30 (wizard_pairing.gate). Anything else on the
	  network that opens the port gets "open the address shown on the TV".
	- The page never shows the keys already saved, not even masked: it only says
	  how many slots are in use. Keys travel one way, phone -> Kodi.
	- Every key is checked before it is saved, with calls that spend no quota
	  (Gemini: list one model; OMDb: one title). Keys that do not work are not
	  saved, and the page and the TV say why.
	- Gemini has five slots (gemini_api.py rotates them in order). With keys
	  already saved the user chooses: add to the free slots (default) or replace
	  them all. Nothing is removed unless at least one new key works.

	Entry points (router): tools_geminiWizard -> run('gemini'),
	tools_omdbWizard -> run('omdb').
"""

import socket
import threading
import time

from resources.lib.modules import control
from resources.lib.modules import log_utils

_LISTEN_PORT = 48250
_HTTP_TIMEOUT = 300
_IDLE_WAIT = 300
_CHECK_TIMEOUT = 12

GEMINI_IDS = ('gemini.api.key', 'gemini.api.key2', 'gemini.api.key3', 'gemini.api.key4', 'gemini.api.key5')
OMDB_IDS = ('omdb.apikey',)

SERVICES = {
	'gemini': {
		'name': 'Gemini', 'ids': GEMINI_IDS,
		'get_url': 'https://aistudio.google.com/apikey', 'get_short': 'aistudio.google.com/apikey',
		'how': 'Sign in with your Google account, press <b>Create API key</b> and copy it. '
			'Each key only adds free quota if it is in its own Google project.',
		'what': 'your Gemini API keys',
		'uses': 'AI Search, the natural search of the assistant and subtitle translation',
	},
	'omdb': {
		'name': 'OMDb', 'ids': OMDB_IDS,
		'get_url': 'https://www.omdbapi.com/apikey.aspx', 'get_short': 'omdbapi.com/apikey.aspx',
		'how': 'Choose <b>FREE</b>, enter your e-mail and open the activation link OMDb sends you. '
			'The key is in that same e-mail.',
		'what': 'your OMDb API key',
		'uses': 'the IMDb, Rotten Tomatoes and Metacritic ratings',
	},
}


# ───────────────────────── claves ─────────────────────────
def clean(raw):
	"""Lo que llega de un teclado de movil: espacios, saltos de linea, comillas."""
	key = ''.join(str(raw or '').split())
	return key.strip('"\'')


def mask(key):
	key = str(key or '')
	if len(key) <= 10: return '*' * len(key)
	return '%s...%s' % (key[:4], key[-4:])


def saved(service):
	out = []
	for sid in SERVICES[service]['ids']:
		out.append(clean(control.setting(sid) or ''))
	return out


def _req(url, **kw):
	import requests
	timeout = kw.pop('timeout', _CHECK_TIMEOUT)
	headers = kw.pop('headers', {}) or {}
	headers.setdefault('User-Agent', 'luc_kodi v%s' % control.addonInfo('version'))
	return requests.get(url, headers=headers, timeout=timeout, **kw)


# Resultado de una comprobacion: (estado, texto). Estados: 'ok' (se guarda),
# 'limit' (vale, pero sin cuota ahora: se guarda), 'bad' (no se guarda),
# 'net' (no se pudo comprobar: no se guarda).
def check_gemini(key):
	try:
		r = _req('https://generativelanguage.googleapis.com/v1beta/models', params={'pageSize': 1}, headers={'x-goog-api-key': key})
	except Exception:
		return 'net', 'Google could not be reached. Check the internet connection of Kodi and try again.'
	if r.status_code == 200: return 'ok', 'Works'
	if r.status_code == 429: return 'limit', 'Works, but its free quota is used up for now. It is saved and comes back on its own.'
	raw = ''
	try: raw = r.text or ''
	except Exception: pass
	try:
		from resources.lib.modules import gemini_api
		if gemini_api._is_blocked_key(raw):
			return 'bad', 'Google blocks this key (old standard key). Create a new key in AI Studio.'
	except Exception: pass
	up = raw.upper()
	if 'API_KEY_INVALID' in up or 'API KEY NOT VALID' in up or r.status_code == 400:
		return 'bad', 'Not a valid Gemini key. Copy it again from AI Studio, all of it.'
	if r.status_code in (401, 403):
		return 'bad', 'Google refused this key (HTTP %d). Check that the Gemini API is enabled for its project.' % r.status_code
	return 'net', 'Google answered HTTP %d. Try again in a moment.' % r.status_code


def check_omdb(key):
	try:
		r = _req('https://www.omdbapi.com/', params={'i': 'tt0468569', 'apikey': key})
	except Exception:
		return 'net', 'OMDb could not be reached. Check the internet connection of Kodi and try again.'
	data = {}
	try: data = r.json() or {}
	except Exception: pass
	if str(data.get('Response')) == 'True': return 'ok', 'Works'
	err = str(data.get('Error') or '')
	low = err.lower()
	if 'limit' in low: return 'limit', 'Works, but today\'s 1,000 requests are used up. It is saved and works again tomorrow.'
	if 'activat' in low: return 'bad', 'This key is not active yet: open the activation link in the OMDb e-mail first.'
	if 'key' in low or r.status_code == 401: return 'bad', 'Not a valid OMDb key. Copy it again from the OMDb e-mail.'
	return 'net', 'OMDb answered HTTP %d. Try again in a moment.' % r.status_code


CHECKS = {'gemini': check_gemini, 'omdb': check_omdb}


def check_all(service, keys):
	"""[(clave, estado, texto)] sin repetidas y en el orden en que llegan."""
	out, seen = [], set()
	for key in keys:
		key = clean(key)
		if not key or key in seen: continue
		seen.add(key)
		state, text = CHECKS[service](key)
		out.append((key, state, text))
	return out


def plan(service, results, replace=False):
	"""Que queda en cada casilla. Devuelve (casillas, no_caben). Con replace, las
	nuevas que valen van primero y el resto se vacia; si no vale ninguna, no se
	toca nada."""
	good = [k for k, state, _t in results if state in ('ok', 'limit')]
	slots = saved(service)
	if not good: return slots, []
	if replace or len(slots) == 1:
		new = good[:len(slots)]
		return new + [''] * (len(slots) - len(new)), good[len(slots):]
	left = []
	for key in good:
		if key in slots: continue # ya estaba
		try: slots[slots.index('')] = key
		except ValueError: left.append(key)
	return slots, left


def save(service, slots):
	try:
		for sid, value in zip(SERVICES[service]['ids'], slots):
			control.setSetting(sid, value)
		try: control.homeWindow.clearProperty('luc_kodi_settings')
		except Exception: pass
		return True
	except Exception:
		log_utils.error()
		return False


# ───────────────────────── pagina del movil ─────────────────────────
def _esc(text):
	from xml.sax.saxutils import escape
	return escape(str(text or ''), {'"': '&quot;'})


_STYLE = u"""<style>
body{font-family:-apple-system,system-ui,sans-serif;background:#141414;color:#eee;margin:0;padding:24px;max-width:640px}
h1{color:#00fa9a;margin:0 0 8px 0;font-size:22px} p{color:#aaa;line-height:1.5;margin:8px 0}
a{color:#fdb515} b{color:#eee}
.step{color:#fdb515;font-weight:bold}
input[type=text]{width:100%;box-sizing:border-box;background:#1e1e1e;color:#fff;border:1px solid #333;border-radius:8px;padding:14px;font-family:monospace;font-size:15px;margin:6px 0}
label.opt{display:block;color:#ccc;margin:6px 0}
button{background:#00fa9a;color:#000;border:0;border-radius:8px;padding:14px 28px;font-size:16px;font-weight:bold;margin-top:14px;cursor:pointer;width:100%}
.hint{color:#666;font-size:12px}
.ok{color:#00fa9a} .bad{color:#ff6666} .warn{color:#fdb515}
li{margin:8px 0;color:#ccc} code{color:#fdb515}
</style>"""


def form_html(service, code, note=''):
	cfg = SERVICES[service]
	used = len([k for k in saved(service) if k])
	n = len(cfg['ids'])
	fields = []
	for i in range(n):
		ph = 'key %d' % (i + 1) if n > 1 else 'your %s API key' % cfg['name']
		if n > 1 and i: ph += ' (optional)'
		fields.append(u'<input type="text" name="key" autocomplete="off" autocapitalize="off" spellcheck="false" placeholder="%s"%s>'
			% (ph, ' autofocus' if not i else ''))
	if used and n > 1:
		mode = (u'<p>This device already has <b>%d of %d</b> keys (they are not shown here).</p>'
			u'<label class="opt"><input type="radio" name="mode" value="add" checked> Add them to the free slots</label>'
			u'<label class="opt"><input type="radio" name="mode" value="replace"> Replace all my keys with these</label>') % (used, n)
	elif used:
		mode = u'<p>This device already has a key (it is not shown here). A new key that works replaces it.</p>'
	else:
		mode = ''
	return (u"""<!doctype html><html><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1"><title>%(name)s keys for luc_kodi</title>%(style)s</head><body>
<h1>%(name)s &mdash; paste your key%(plural)s</h1>
<p>luc_kodi uses it for %(uses)s.</p>
%(note)s
<p><span class="step">1)</span> Get it here: <a href="%(url)s" target="_blank" rel="noopener">%(short)s</a>. %(how)s</p>
<p><span class="step">2)</span> Paste it below and press <b>Check and save</b>.%(more)s</p>
<form method="post" action="/%(code)s">%(fields)s%(mode)s
<div class="hint">On a phone: long-press inside the box and choose Paste.</div>
<button type="submit">Check and save</button></form>
</body></html>""") % {'name': cfg['name'], 'style': _STYLE, 'plural': 's' if n > 1 else '', 'uses': cfg['uses'], 'note': note,
		'url': cfg['get_url'], 'short': cfg['get_short'], 'how': cfg['how'], 'code': code, 'fields': ''.join(fields), 'mode': mode,
		'more': ' Up to %d keys, one per box.' % n if n > 1 else ''}


def _result_lines(results):
	cls = {'ok': 'ok', 'limit': 'warn', 'bad': 'bad', 'net': 'bad'}
	return u''.join(u'<li><code>%s</code> <span class="%s">%s</span></li>' % (_esc(mask(k)), cls[s], _esc(t)) for k, s, t in results)


def done_html(service, results, left):
	extra = ''
	if left: extra = u'<p class="warn">%d working key(s) did not fit: all %d slots are in use. Use "Replace all my keys" to change them.</p>' % (len(left), len(SERVICES[service]['ids']))
	return (u"""<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Saved</title>%s</head><body><h1>&check; Saved in luc_kodi</h1><ul>%s</ul>%s
<p>You can close this page and go back to Kodi.</p></body></html>""") % (_STYLE, _result_lines(results), extra)


def retry_note(results):
	if not results: return u'<p class="bad">No key was received. Paste at least one.</p>'
	return u'<p class="bad">Nothing was saved:</p><ul>%s</ul>' % _result_lines(results)


# ───────────────────────── servidor local ─────────────────────────
def new_code():
	from resources.lib.modules import wizard_pairing # v2.0.30: el codigo comun de los asistentes
	return wizard_pairing.new_code()


def _parse_form(body):
	from urllib.parse import parse_qs
	data = parse_qs(body.decode('utf-8', errors='replace'), keep_blank_values=True)
	return data.get('key', []), (data.get('mode') or ['add'])[0]


class _Server(object):
	def __init__(self, service, port, code):
		self.service, self.port, self.code = service, port, code
		self.result = None # (resultados, casillas, no_caben)
		self.sock, self._stop, self._thread = None, False, None
		self._lock = threading.Lock()

	def start(self):
		self.sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
		self.sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
		self.sock.bind(('', self.port))
		self.sock.listen(16)
		self.sock.settimeout(1.0)
		self._thread = threading.Thread(target=self._loop)
		self._thread.daemon = True
		self._thread.start()

	def stop(self):
		self._stop = True
		for c in list(self.__dict__.get('_conns', ())):
			try: c.shutdown(socket.SHUT_RDWR)
			except Exception: pass
		try: self.sock.close()
		except Exception: pass

	def is_alive(self):
		return self._thread is not None and self._thread.is_alive()

	def _loop(self):
		t0 = time.time()
		from resources.lib.modules import wizard_pairing
		while not self._stop and time.time() - t0 < _HTTP_TIMEOUT:
			try:
				conn, addr = self.sock.accept()
				wizard_pairing.knock(self, addr)
			except socket.timeout:
				if self.result is not None: return
				continue
			except Exception:
				return
			t = threading.Thread(target=self._handle_safe, args=(conn,))
			t.daemon = True
			t.start()
			if self.result is not None: return

	def _handle_safe(self, conn):
		conns = self.__dict__.setdefault('_conns', set())
		conns.add(conn)
		try:
			self._handle(conn)
		except Exception:
			log_utils.error('keys_wizard: ')
			try: self._send(conn, 500, u'<!doctype html><body style="background:#141414;color:#ff6666;font-family:system-ui;padding:40px">Wizard error. Try again.</body>')
			except Exception: pass
		finally:
			conns.discard(conn)
			try: conn.close()
			except Exception: pass

	def _handle(self, conn):
		conn.settimeout(_IDLE_WAIT)
		from resources.lib.modules import wizard_pairing
		if not wizard_pairing.sniff(self, conn): return
		data = b''
		while b'\r\n\r\n' not in data and len(data) < 65536:
			chunk = conn.recv(4096)
			if not chunk: break
			data += chunk
		conn.settimeout(15.0)
		if not data: return
		head, _, body = data.partition(b'\r\n\r\n')
		headline = head.split(b'\r\n', 1)[0]
		if not wizard_pairing.gate(self, conn, headline): return # v2.0.30: la puerta comun
		method = headline.split(b' ', 1)[0]
		try: self.seen = conn.getpeername()[0] # la ventana de la tele dice que el movil llego
		except Exception: pass
		if method != b'POST': return self._send(conn, 200, form_html(self.service, self.code))
		clen = 0
		for line in head.split(b'\r\n')[1:]:
			if line.lower().startswith(b'content-length:'):
				try: clen = int(line.split(b':', 1)[1].strip())
				except Exception: clen = 0
		clen = min(clen, 65536)
		while len(body) < clen:
			chunk = conn.recv(min(65536, clen - len(body)))
			if not chunk: break
			body += chunk
		keys, mode = _parse_form(body)
		with self._lock: # dos envios a la vez no se pisan
			if self.result is not None:
				return self._send(conn, 200, done_html(self.service, self.result[0], self.result[2]))
			results = check_all(self.service, keys)
			slots, left = plan(self.service, results, replace=(mode == 'replace'))
			if not any(s in ('ok', 'limit') for _k, s, _t in results):
				return self._send(conn, 200, form_html(self.service, self.code, retry_note(results)))
			if not save(self.service, slots):
				return self._send(conn, 200, form_html(self.service, self.code, u'<p class="bad">Kodi could not write the settings. Try again.</p>'))
			self.result = (results, slots, left)
		self._send(conn, 200, done_html(self.service, results, left))

	@staticmethod
	def _send(conn, status, body):
		reason = {200: 'OK', 403: 'Forbidden', 404: 'Not Found', 500: 'Internal Server Error'}.get(status, 'OK')
		body_b = body.encode('utf-8')
		head = ('HTTP/1.1 %d %s\r\nContent-Type: text/html; charset=utf-8\r\nContent-Length: %d\r\n'
			'Cache-Control: no-store\r\nReferrer-Policy: no-referrer\r\nConnection: close\r\n\r\n') % (status, reason, len(body_b))
		try: conn.sendall(head.encode('utf-8') + body_b)
		except Exception: pass


def _local_ip():
	try:
		s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
		s.settimeout(1.0)
		s.connect(('8.8.8.8', 53)) # UDP: no se envia nada
		ip = s.getsockname()[0]
		s.close()
		return ip
	except Exception:
		return '127.0.0.1'


def _free_port():
	for port in range(_LISTEN_PORT, _LISTEN_PORT + 20):
		try:
			s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
			s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
			s.bind(('', port))
			s.close()
			return port
		except Exception:
			continue
	return None


# ───────────────────────── en la tele ─────────────────────────
def _summary(service, results, left):
	col = {'ok': 'ff00fa9a', 'limit': 'fffdb515', 'bad': 'ffff6666', 'net': 'ffff6666'}
	lines = ['[COLOR %s]%s[/COLOR]  %s' % (col[s], mask(k), t) for k, s, t in results]
	if left: lines.append('[COLOR fffdb515]%d working key(s) did not fit: all slots are in use.[/COLOR]' % len(left))
	return '[CR]'.join(lines)


def _title(service, tail):
	return '%s Setup - %s' % (SERVICES[service]['name'], tail)


def _method_local(service):
	port = _free_port()
	if port is None:
		control.dialog.ok(_title(service, 'error'), 'Could not open a local port for the setup page.[CR]Use "Type or paste it here" instead.')
		return False
	from resources.lib.modules import wizard_pairing
	code = new_code()
	srv = _Server(service, port, code)
	try:
		srv.start()
	except Exception as e:
		control.dialog.ok(_title(service, 'error'), 'Could not start the setup page:[CR]%s[CR][CR]Use "Type or paste it here" instead.' % e)
		return False
	url = wizard_pairing.address(srv, _local_ip(), port)
	outcome = wizard_pairing.wait(srv, url, SERVICES[service]['name'], _HTTP_TIMEOUT, SERVICES[service]['what'])
	srv.stop()
	if outcome == 'cancelled': return False
	if srv.result is None:
		control.dialog.ok(_title(service, 'cancelled'), 'No working key was received (time is up).[CR]You can try again or type it here.')
		return False
	results, _slots, left = srv.result
	control.dialog.ok(_title(service, 'done'), _summary(service, results, left))
	log_utils.log('%s setup wizard: %d key(s) checked, %d saved' % (SERVICES[service]['name'], len(results),
		len([1 for _k, s, _t in results if s in ('ok', 'limit')]) - len(left)), level=log_utils.LOGINFO)
	return True


def _method_manual(service):
	cfg = SERVICES[service]
	pasted = control.dialog.input('Paste your %s API key' % cfg['name'], type=0)
	if not pasted: return False
	results = check_all(service, [pasted])
	if not results: return False
	replace = False
	if len(cfg['ids']) > 1 and results[0][1] in ('ok', 'limit') and all(saved(service)):
		replace = bool(control.dialog.yesno(_title(service, 'all slots in use'),
			'All %d slots already have a key.[CR]Replace them all with this one?' % len(cfg['ids']), nolabel='Cancel', yeslabel='Replace'))
		if not replace: return False
	slots, left = plan(service, results, replace=replace)
	if results[0][1] not in ('ok', 'limit'):
		control.dialog.ok(_title(service, 'not saved'), _summary(service, results, []))
		return False
	if not save(service, slots):
		control.dialog.ok(_title(service, 'error'), 'Could not write the settings.')
		return False
	control.dialog.ok(_title(service, 'done'), _summary(service, results, left))
	return True


def run(service='gemini'):
	if service not in SERVICES: return False
	cfg = SERVICES[service]
	used = len([k for k in saved(service) if k])
	have = (' This device already has %d of %d keys.' % (used, len(cfg['ids'])) if len(cfg['ids']) > 1 else ' This device already has a key.') if used else ''
	intro = ('luc_kodi uses a free %s key for %s.%s[CR][CR]Make it on your phone or computer and paste it there: '
		'no typing on the TV. Every key is checked before it is saved.[CR][CR][COLOR fffdb515]Get your key:[/COLOR] %s') % (
		cfg['name'], cfg['uses'], have, cfg['get_short'])
	if not control.dialog.yesno(_title(service, 'overview'), intro, nolabel='Cancel', yeslabel='Continue'): return False
	choice = control.dialog.select(_title(service, 'how do you want to enter it?'), [
		'[COLOR ff00fa9a]Scan a QR / use a browser[/COLOR]  (recommended, no keyboard)',
		'Type or paste it here with the Kodi keyboard'])
	if choice == -1: return False
	return _method_local(service) if choice == 0 else _method_manual(service)
