# -*- coding: utf-8 -*-
"""
	luc_kodi Add-on — modules/home_badges.py (v2.0.28)

	Logo del estudio / plataforma / cadena en las filas de la luc_kodi Home.

	FENtastic y FENtastic Plus pintan en la Home, abajo a la derecha, el logo de
	ListItem.Studio (resource.images.studios.white, o .coloured si "Disable
	color studio logos" esta apagado). luc_kodi solo rellena ese dato en los
	items de sus filas:
	  - Filas de plataforma: la plataforma (Netflix, Prime Video, Apple TV+,
	    Disney+), en peliculas y series.
	  - Series: la cadena que ya trae el metadato.
	  - Resto de peliculas: la productora con logo en TMDb (studio_name, que
	    tmdb.py guarda desde la v2.0.28).

	Nimbus y Nimbus Plus no tienen logos (su include MediaFlags esta comentado):
	ahi solo se quita el estudio repetido de las filas de plataforma (v2.0.28).

	SIN ICONO DE CALIDAD. Las pruebas de la v2.0.28 ponian 4K / 1080p / 720p
	(1080p cuando el titulo ya estaba en digital, la real cuando luc_kodi ya
	habia buscado fuentes). Casi siempre salia 1080p, y un titulo suele existir
	a la vez en 4K, 1080p y 720p: el icono daba una sola calidad cuando hay
	varias. Decision de Lucian (8-nov-2026): si no se puede dar la informacion
	correcta, mejor no darla. Se quitan el icono, la lectura de las fuentes ya buscadas y la
	fecha digital de la ficha.
"""

from resources.lib.modules import log_utils

SKINS = ('skin.nimbus', 'skin.fentastic')


def _skin():
	try:
		import xbmc
		return xbmc.getSkinDir()
	except Exception: return ''


class PageBadges:
	"""Se monta antes del bucle de una fila de la Home y se pide por item."""

	def __init__(self, items, mediatype, on=True):
		self.mediatype = mediatype
		skin = _skin() if on else ''
		self.on = skin in SKINS
		self.nimbus = skin == 'skin.nimbus'

	def apply(self, meta, i):
		"""Rellena meta['studio'] (antes de infoTagger)."""
		if not self.on: return
		if self.nimbus:
			# v2.0.28: Nimbus / Nimbus Plus no tienen logo de estudio; el estudio
			# solo sale como texto en la linea de info. En una fila de plataforma
			# repetia el nombre que ya da nuestro titulo naranja, asi que ahi se
			# quita, tambien en series (su cadena suele ser la misma plataforma).
			# En el resto de filas no se anade nada.
			if i.get('luc_home_studio'): meta['studio'] = ''
			return
		try:
			studio = i.get('luc_home_studio') or (meta.get('studio') if self.mediatype == 'tvshow' else meta.get('studio_name'))
			if studio: meta['studio'] = studio
		except Exception:
			log_utils.error()
