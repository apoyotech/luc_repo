# -*- coding: utf-8 -*-
"""
	luc_kodi Add-on — sub_sync.py (v2.0.27)

	Automatic subtitle sync against the file being played.

	THE IDEA (as in Dex Hub's AutoSync; this is luc_kodi's own code). Kodi does
	not let an add-on read the TEXT of a subtitle track inside the video, but a
	Matroska file says WHEN each of its subtitle lines starts: the index of
	the file (Cues) usually has an entry per subtitle line. The index sits in a
	few MB at the start or the end of the file, so it is read with a handful of
	HTTP Range requests, without downloading the video.

	Those start times are the reference: they are the timing of THIS release.
	An external subtitle (OpenSubtitles, SubtitleCat or a Gemini translation)
	made for another release is shifted, and stretched when the frame rate
	differs (23.976 / 24 / 25 fps), until its lines fall on the reference.
	Only the timings change; the text stays as it was.

	MP4 (v2.0.27). An MP4 has no Cues, but its index (the 'moov' box, at the
	start or at the end of the file) lists every sample of every track with
	its duration (stts) and size (stsz). In a text subtitle track (mov_text /
	tx3g, WebVTT) the gaps between lines are empty samples, so the samples
	with text are exactly the subtitle lines and their start times follow
	from the durations. Fragmented MP4 (index spread over 'moof' boxes) is
	not read.

	WHEN IT DOES NOTHING
	  - no subtitle track inside the file, or one with no index entries
	    (CAM rips, some MP4/TS files): there is nothing to sync against;
	  - the subtitle already matches (it was made for this release);
	  - no shift clearly better than the current timing: a doubtful fit is
	    never applied.
"""

import bisect
import re
import time

import xbmc

LOG_TAG = '[luc_kodi-subsync]'
MB = 1024 * 1024
HEAD_BYTES = 512 * 1024
MAX_ELEMENT = 16 * MB          # Cues of a long film are well under this
BUDGET = 20                    # seconds for reading the index
WINDOW_MS = 90000              # largest shift looked for (an intro, a recap)
TOLERANCE_MS = 400
SCALES = (1.0, 25.0 / 23.976, 23.976 / 25.0, 25.0 / 24.0, 24.0 / 25.0, 24.0 / 23.976, 23.976 / 24.0)
MIN_SCORE = 0.40               # share of lines that must land on the reference
MIN_MARGIN = 0.15              # ...this much above the best wrong shift
MIN_GAIN = 0.10                # ...and this much better than leaving it alone
PIECES_BELOW = 0.88            # one shift fitting less than this: try it in parts
PIECES_SCORE = 0.60            # in parts: share of lines that must land
PIECES_MARGIN = 0.25           # ...above the best wrong shift (parts have more freedom)
PIECES_GAIN = 0.15             # ...and this much better than one shift
PIECES_MIRROR = 0.20           # ...and than the same subtitle played backwards

ID_EBML, ID_SEGMENT, ID_SEEKHEAD, ID_SEEK, ID_SEEKID, ID_SEEKPOS = 0x1A45DFA3, 0x18538067, 0x114D9B74, 0x4DBB, 0x53AB, 0x53AC
ID_INFO, ID_TIMESCALE = 0x1549A966, 0x2AD7B1
ID_TRACKS, ID_TRACKENTRY, ID_TRACKNUMBER, ID_TRACKTYPE, ID_CODEC = 0x1654AE6B, 0xAE, 0xD7, 0x83, 0x86
ID_LANG, ID_LANG_BCP47, ID_NAME, ID_FORCED = 0x22B59C, 0x22B59D, 0x536E, 0x55AA
ID_CUES, ID_CUEPOINT, ID_CUETIME, ID_CUETRACKPOS, ID_CUETRACK = 0x1C53BB6B, 0xBB, 0xB3, 0xB7, 0xF7
ID_CLUSTER = 0x1F43B675
TYPE_SUBTITLE = 17


# ──────────────────────────────────────────────────────────────────────
# EBML
# ──────────────────────────────────────────────────────────────────────

def _vint(buf, pos, keep_marker):
	"""(value, length) of an EBML variable-length integer, or (None, 0)."""
	if pos >= len(buf):
		return None, 0
	first = buf[pos]
	mask, length = 0x80, 1
	while length <= 8 and not (first & mask):
		mask >>= 1
		length += 1
	if length > 8 or pos + length > len(buf):
		return None, 0
	value = first if keep_marker else first & (mask - 1)
	for b in buf[pos + 1:pos + length]:
		value = (value << 8) | b
	if not keep_marker and value == (1 << (7 * length)) - 1:
		value = -1                         # unknown size
	return value, length


def _elements(buf, start=0, end=None):
	"""Yields (id, data_start, data_end) of the elements in buf[start:end]."""
	end = len(buf) if end is None else min(end, len(buf))
	pos = start
	while pos < end:
		eid, il = _vint(buf, pos, True)
		if eid is None:
			return
		size, sl = _vint(buf, pos + il, False)
		if size is None:
			return
		ds = pos + il + sl
		de = end if size < 0 else ds + size
		yield eid, ds, de
		if size < 0 or de <= pos:
			return
		pos = de


def _uint(buf, s, e):
	v = 0
	for b in buf[s:e]:
		v = (v << 8) | b
	return v


# ──────────────────────────────────────────────────────────────────────
# Reading the file
# ──────────────────────────────────────────────────────────────────────

class _Reader(object):
	def __init__(self, url, deadline):
		self.deadline = deadline
		self.requests = 0
		self.local = '://' not in url
		if self.local:
			self.path = url
		else:
			from resources.lib.modules.opensubs import _split_kodi_url
			self.url, self.headers = _split_kodi_url(url)

	def read(self, start, length):
		if time.time() >= self.deadline or self.requests >= 8:
			return b''
		self.requests += 1
		if self.local:
			with open(self.path, 'rb') as f:
				f.seek(start)
				return f.read(length)
		import requests
		h = dict(self.headers)
		h['Range'] = 'bytes=%d-%d' % (start, start + length - 1)
		r = requests.get(self.url, headers=h, stream=True, timeout=max(2, min(10, self.deadline - time.time())))
		try:
			if r.status_code != 206:
				return b''                   # no Range: not worth reading a whole film
			out = bytearray()
			for chunk in r.iter_content(65536):
				out += chunk
				if len(out) >= length or time.time() >= self.deadline:
					break
			return bytes(out[:length])
		finally:
			r.close()

	def element(self, pos, limit):
		"""Bytes of the element at absolute `pos` (header included) and the
		offset of its data inside them, or (None, 0)."""
		head = self.read(pos, 16)
		eid, il = _vint(head, 0, True)
		size, sl = _vint(head, il or 0, False)
		if eid is None or size is None or size < 0 or size > limit:
			return None, 0, None
		data = self.read(pos, il + sl + size)
		if len(data) < il + sl + size:
			return None, 0, None
		return data, il + sl, eid


def reference(url):
	"""Start times (ms, sorted) of the best subtitle track inside the file, and
	a description for the log. ([], reason) when there is none."""
	if not url or url.lower().startswith(('plugin://', 'special://', 'pvr://')):
		return [], 'not a file'
	if '://' in url and not url.lower().startswith(('http://', 'https://')):
		return [], 'not http'
	t0 = time.time()
	try:
		rd = _Reader(url, t0 + BUDGET)
		head = rd.read(0, HEAD_BYTES)
		if head[4:8] == b'ftyp':
			return _mp4_reference(rd, head, t0)
		if not head.startswith(b'\x1a\x45\xdf\xa3'):
			return [], 'neither Matroska nor MP4'
		seg_start = None
		for eid, ds, de in _elements(head):
			if eid == ID_SEGMENT:
				seg_start = ds
				break
		if seg_start is None:
			return [], 'no segment'
		where, info, tracks, cues = {}, None, None, None
		pos = seg_start
		while pos < len(head):
			eid, il = _vint(head, pos, True)
			size, sl = _vint(head, pos + il, False) if eid is not None else (None, 0)
			if eid is None or size is None:
				break
			ds = pos + il + sl
			de = ds + size if size >= 0 else len(head)
			if eid == ID_CLUSTER:
				break
			if de > len(head):
				# Starts inside what was read but goes on: read it by itself.
				if eid in (ID_INFO, ID_TRACKS, ID_CUES):
					where.setdefault(eid, pos)
				break
			if eid == ID_SEEKHEAD:
				for sid, s1, e1 in _elements(head, ds, de):
					if sid != ID_SEEK:
						continue
					target = spos = None
					for fid, s2, e2 in _elements(head, s1, e1):
						if fid == ID_SEEKID:
							target = _uint(head, s2, e2)
						elif fid == ID_SEEKPOS:
							spos = _uint(head, s2, e2)
					if target and spos is not None:
						where.setdefault(target, seg_start + spos)
			elif eid == ID_INFO:
				info = (head, ds, de)
			elif eid == ID_TRACKS:
				tracks = (head, ds, de)
			elif eid == ID_CUES:
				cues = (head, ds, de)
			pos = de
		scale = 1000000
		if info is None and ID_INFO in where:
			data, off, _e = rd.element(where[ID_INFO], 1 * MB)
			if data: info = (data, off, len(data))
		if info:
			for eid, s, e in _elements(*info):
				if eid == ID_TIMESCALE:
					scale = _uint(info[0], s, e) or 1000000
		if tracks is None and ID_TRACKS in where:
			data, off, _e = rd.element(where[ID_TRACKS], 4 * MB)
			if data: tracks = (data, off, len(data))
		if not tracks:
			return [], 'no track list'
		subs = _subtitle_tracks(tracks)
		if not subs:
			return [], 'no subtitle track inside the file'
		if cues is None:
			if ID_CUES not in where:
				return [], 'no index (Cues) in the file'
			data, off, _e = rd.element(where[ID_CUES], MAX_ELEMENT)
			if not data:
				return [], 'index (Cues) not readable in time'
			cues = (data, off, len(data))
		per_track = _cue_times(cues, set(subs), scale)
		best, best_n = None, 0
		for num, info_t in subs.items():
			n = len(per_track.get(num, ()))
			if info_t['forced']:
				n = n // 4                      # signs only: last resort
			if _is_pgs(info_t['codec']):
				n = n // 2                      # two entries per line, and a text track is exact
			if n > best_n:
				best, best_n = num, n
		if not best or len(per_track.get(best, ())) < 50:
			return [], 'subtitle tracks have no index entries (%s)' % ', '.join(
				'%s:%d' % (subs[k]['lang'] or '?', len(per_track.get(k, ()))) for k in subs)
		t = subs[best]
		times = _Ref(sorted(set(per_track[best])))
		times.ends = _is_pgs(t['codec'])
		return times, '%s track "%s" (%s), %d lines, %d requests, %.1fs' % (
			t['lang'] or '?', t['name'], t['codec'], len(times), rd.requests, time.time() - t0)
	except Exception as e:
		return [], 'error: %s' % type(e).__name__


_COMMENTARY = re.compile(r'(?i)comment|coment|kommentar')


class _Ref(list):
	"""Reference times. ends=True: the track also marks where each line goes
	away (Blu-ray PGS keeps a 'clear' picture after every line, and the index
	lists both), so starts and ends of the subtitle are matched against it."""
	ends = False


def _is_pgs(codec):
	return (codec or '').upper().startswith('S_HDMV/PGS')


# ──────────────────────────────────────────────────────────────────────
# MP4
# ──────────────────────────────────────────────────────────────────────

def _boxes(buf, start=0, end=None):
	"""Yields (type, data_start, data_end) of the boxes in buf[start:end]."""
	import struct
	end = len(buf) if end is None else min(end, len(buf))
	pos = start
	while pos + 8 <= end:
		size, typ = struct.unpack('>I4s', buf[pos:pos + 8])
		hdr = 8
		if size == 1:
			if pos + 16 > end: return
			size = struct.unpack('>Q', buf[pos + 8:pos + 16])[0]
			hdr = 16
		elif size == 0:
			size = end - pos
		if size < hdr:
			return
		yield typ, pos + hdr, pos + size
		pos += size


def _child(buf, s, e, *path):
	for name in path:
		for typ, ds, de in _boxes(buf, s, e):
			if typ == name:
				s, e = ds, de
				break
		else:
			return None
	return s, e


def _mp4_reference(rd, head, t0):
	import struct
	# Find 'moov' among the top-level boxes: in what was read, or by jumping
	# from box header to box header past the media data.
	pos, moov = 0, None
	while True:
		if pos + 16 <= len(head):
			hb = head[pos:pos + 16]
		else:
			hb = rd.read(pos, 16)
		if len(hb) < 8:
			break
		size, typ = struct.unpack('>I4s', hb[:8])
		hdr = 8
		if size == 1 and len(hb) >= 16:
			size, hdr = struct.unpack('>Q', hb[8:16])[0], 16
		if size < hdr:
			break
		if typ == b'moof':
			return [], 'fragmented MP4 (index not in one place)'
		if typ == b'moov':
			if size > MAX_ELEMENT:
				return [], 'MP4 index too large'
			moov = head[pos:pos + size] if pos + size <= len(head) else rd.read(pos, size)
			if len(moov) < size:
				return [], 'MP4 index not readable in time'
			break
		pos += size
	if moov is None:
		return [], 'no MP4 index (moov)'
	movie_scale = 1000
	mv = _child(moov, 8, len(moov), b'mvhd')
	if mv:
		v = moov[mv[0]]
		movie_scale = struct.unpack('>I', moov[mv[0] + (20 if v == 1 else 12):mv[0] + (24 if v == 1 else 16)])[0] or 1000
	best = None
	for typ, ts, te in _boxes(moov, 8, len(moov)):
		if typ != b'trak':
			continue
		hd = _child(moov, ts, te, b'mdia', b'hdlr')
		if not hd or moov[hd[0] + 8:hd[0] + 12] not in (b'sbtl', b'text', b'subt'):
			continue
		md = _child(moov, ts, te, b'mdia', b'mdhd')
		stbl = _child(moov, ts, te, b'mdia', b'minf', b'stbl')
		if not md or not stbl:
			continue
		v = moov[md[0]]
		o = md[0] + (20 if v == 1 else 12)
		scale = struct.unpack('>I', moov[o:o + 4])[0] or 1000
		lo = o + (12 if v == 1 else 8)
		lang_bits = struct.unpack('>H', moov[lo:lo + 2])[0]
		lang = ''.join(chr(((lang_bits >> sh) & 31) + 0x60) for sh in (10, 5, 0)).strip('`')
		stsd = _child(moov, stbl[0], stbl[1], b'stsd')
		codec = moov[stsd[0] + 12:stsd[0] + 16].decode('ascii', 'replace') if stsd else '?'
		empty = 8 if codec == 'wvtt' else 2          # an empty sample: gap between lines
		stts = _child(moov, stbl[0], stbl[1], b'stts')
		stsz = _child(moov, stbl[0], stbl[1], b'stsz')
		if not stts or not stsz:
			continue
		n = struct.unpack('>I', moov[stts[0] + 4:stts[0] + 8])[0]
		durs = []
		for k in range(n):
			c, d = struct.unpack('>II', moov[stts[0] + 8 + 8 * k:stts[0] + 16 + 8 * k])
			durs.extend([d] * c)
		fixed, count = struct.unpack('>II', moov[stsz[0] + 4:stsz[0] + 12])
		sizes = [fixed] * count if fixed else list(struct.unpack('>%dI' % count, moov[stsz[0] + 12:stsz[0] + 12 + 4 * count]))
		# Edit list: an empty edit delays the track; a media time skips its start.
		shift_ms = 0.0
		el = _child(moov, ts, te, b'edts', b'elst')
		if el:
			ev = moov[el[0]]
			ne = struct.unpack('>I', moov[el[0] + 4:el[0] + 8])[0]
			p = el[0] + 8
			for _k in range(min(ne, 4)):
				if ev == 1:
					segd, mt = struct.unpack('>Qq', moov[p:p + 16]); p += 20
				else:
					segd, mt = struct.unpack('>Ii', moov[p:p + 8]); p += 12
				if mt == -1:
					shift_ms += segd * 1000.0 / movie_scale
				else:
					shift_ms -= mt * 1000.0 / scale
					break
		times, t = [], 0
		for d, sz in zip(durs, sizes):
			if sz > empty:
				times.append(int(round(t * 1000.0 / scale + shift_ms)))
			t += d
		forced = False
		if best is None or (len(times) > len(best[0])):
			best = (times, lang, codec, forced)
	if not best:
		return [], 'no subtitle track inside the file'
	times, lang, codec, _f = best
	if len(times) < 50:
		return [], 'subtitle track too short (%d lines)' % len(times)
	return sorted(set(times)), '%s MP4 track (%s), %d lines, %d requests, %.1fs' % (
		lang or '?', codec, len(times), rd.requests, time.time() - t0)


def _subtitle_tracks(tracks):
	buf, s, e = tracks
	out = {}
	for eid, ds, de in _elements(buf, s, e):
		if eid != ID_TRACKENTRY:
			continue
		t = {'num': None, 'type': None, 'codec': '', 'lang': '', 'name': '', 'forced': False}
		for fid, s2, e2 in _elements(buf, ds, de):
			if fid == ID_TRACKNUMBER: t['num'] = _uint(buf, s2, e2)
			elif fid == ID_TRACKTYPE: t['type'] = _uint(buf, s2, e2)
			elif fid == ID_CODEC: t['codec'] = buf[s2:e2].decode('ascii', 'replace').strip('\x00')
			elif fid in (ID_LANG, ID_LANG_BCP47): t['lang'] = t['lang'] or buf[s2:e2].decode('ascii', 'replace').strip('\x00')
			elif fid == ID_NAME: t['name'] = buf[s2:e2].decode('utf-8', 'replace').strip('\x00')
			elif fid == ID_FORCED: t['forced'] = bool(_uint(buf, s2, e2))
		if 'forced' in t['name'].lower() or 'forzad' in t['name'].lower():
			t['forced'] = True
		# v2.0.27. MEASURED (kodi.log 5-nov-2026, The Godfather): the track with
		# the most lines was "Commentary by writer/director Francis Ford
		# Coppola": what the director says over the film, not its dialogue.
		if _COMMENTARY.search(t['name']):
			continue
		if t['type'] == TYPE_SUBTITLE and t['num']:
			out[t['num']] = t
	return out


def _cue_times(cues, wanted, scale):
	buf, s, e = cues
	out = {}
	for eid, ds, de in _elements(buf, s, e):
		if eid != ID_CUEPOINT:
			continue
		ctime, tracks = None, []
		for fid, s2, e2 in _elements(buf, ds, de):
			if fid == ID_CUETIME:
				ctime = _uint(buf, s2, e2)
			elif fid == ID_CUETRACKPOS:
				for gid, s3, e3 in _elements(buf, s2, e2):
					if gid == ID_CUETRACK:
						tracks.append(_uint(buf, s3, e3))
		if ctime is None:
			continue
		ms = ctime * scale // 1000000
		for tr in tracks:
			if tr in wanted:
				out.setdefault(tr, []).append(ms)
	return out


# ──────────────────────────────────────────────────────────────────────
# Fitting
# ──────────────────────────────────────────────────────────────────────

_TIME = re.compile(r'(\d{1,2}):(\d{2}):(\d{2})[,.](\d{1,3})\s*-->\s*(\d{1,2}):(\d{2}):(\d{2})[,.](\d{1,3})')


def _ms(h, m, s, f):
	return ((int(h) * 60 + int(m)) * 60 + int(s)) * 1000 + int((f + '00')[:3])


def starts_of(srt):
	return [_ms(*m.groups()[:4]) for m in _TIME.finditer(srt or '')]


def points_of(srt):
	"""Starts and ends; an end that touches the next start counts once."""
	cues = [(_ms(*m.groups()[:4]), _ms(*m.groups()[4:])) for m in _TIME.finditer(srt or '')]
	starts = sorted(a for a, _b in cues)
	pts = set(starts)
	for _a, b in cues:
		i = bisect.bisect_left(starts, b - 150)
		if i < len(starts) and abs(starts[i] - b) <= 150:
			continue
		pts.add(b)
	return sorted(pts)


def _score(ref, starts, scale, off, tol=TOLERANCE_MS):
	if not starts:
		return 0.0
	hit = 0
	for s in starts:
		x = s * scale + off
		i = bisect.bisect_left(ref, x)
		if (i < len(ref) and abs(ref[i] - x) <= tol) or (i > 0 and abs(ref[i - 1] - x) <= tol):
			hit += 1
	return hit / float(len(starts))


def fit(ref, starts):
	"""(scale, offset ms, score, score without changes)."""
	base = _score(ref, starts, 1.0, 0)
	if len(ref) < 50 or len(starts) < 50:
		return 1.0, 0, base, base
	step = max(1, len(starts) // 400)
	sample = starts[::step]
	best = (1.0, 0, base)
	for scale in SCALES:
		votes = {}
		for s in sample:
			x = s * scale
			lo = bisect.bisect_left(ref, x - WINDOW_MS)
			hi = bisect.bisect_right(ref, x + WINDOW_MS)
			for r in ref[lo:hi]:
				b = int(round((r - x) / 100.0))
				votes[b] = votes.get(b, 0) + 1
		if not votes:
			continue
		# A shift of one bin either side counts for the same offset.
		top = max(votes, key=lambda b: votes.get(b - 1, 0) + votes[b] + votes.get(b + 1, 0))
		off = top * 100
		# Refine: median of the remaining error of the lines that land.
		errs = []
		for s in sample:
			x = s * scale + off
			i = bisect.bisect_left(ref, x)
			cands = [ref[j] - x for j in (i - 1, i) if 0 <= j < len(ref)]
			if cands:
				d = min(cands, key=abs)
				if abs(d) <= TOLERANCE_MS:
					errs.append(d)
		if errs:
			errs.sort()
			off += errs[len(errs) // 2]
		sc = _score(ref, starts, scale, off)
		# A speed change only when it clearly does better than none: over a
		# whole episode a wrong one drifts seconds by the end.
		if sc > best[2] + (0.03 if scale != 1.0 and best[0] == 1.0 and best[2] > base else 0):
			best = (scale, off, sc)
	return best[0], int(round(best[1])), best[2], base


def _fmt(ms):
	ms = max(0, int(round(ms)))
	h, r = divmod(ms, 3600000)
	m, r = divmod(r, 60000)
	s, f = divmod(r, 1000)
	return '%02d:%02d:%02d,%03d' % (h, m, s, f)


def apply(srt, scale, off):
	def sub(m):
		g = m.groups()
		a = _ms(*g[:4]) * scale + off
		b = _ms(*g[4:]) * scale + off
		return '%s --> %s' % (_fmt(a), _fmt(b))
	return _TIME.sub(sub, srt)


# ──────────────────────────────────────────────────────────────────────
# Fitting in parts (v2.0.27)
# ──────────────────────────────────────────────────────────────────────
# MEASURED (kodi.log 4/5-nov-2026, Columbo 4K Remaster, subtitles made for
# the 1989-1991 releases): one shift fits only 45-51% of the lines. A
# remaster or another broadcast is cut differently (a scene longer, a
# commercial-break fade shorter), so the subtitle is right in one stretch
# and a second or two off in the next. Each stretch gets its own shift.
PIECE_LINES = 40         # lines of a local window
PIECE_STEP = 10          # a window every this many lines
PIECE_HIT = 0.60         # share of a window that must land: chance stays well below
MAX_PIECES = 5           # more is noise being fitted, not a different cut (v2.0.27)
PIECE_SAME_MS = 400      # windows this close are the same stretch


def _median(v):
	v = sorted(v)
	return v[len(v) // 2]


def _local(ref, xs):
	"""(offset, share of xs that land) of one window; (None, 0) if none."""
	votes = {}
	for x in xs:
		lo = bisect.bisect_left(ref, x - WINDOW_MS)
		hi = bisect.bisect_right(ref, x + WINDOW_MS)
		for r in ref[lo:hi]:
			b = int(round((r - x) / 100.0))
			votes[b] = votes.get(b, 0) + 1
	if not votes:
		return None, 0.0
	top = max(votes, key=lambda b: votes.get(b - 1, 0) + votes[b] + votes.get(b + 1, 0))
	off = top * 100
	errs = [d for d in (_nearest(ref, x + off) for x in xs) if d is not None]
	if errs:
		off += _median(errs)
	hit = sum(1 for x in xs if _nearest(ref, x + off) is not None)
	return off, hit / float(len(xs))


def _nearest(ref, x, tol=TOLERANCE_MS):
	i = bisect.bisect_left(ref, x)
	best = None
	for j in (i - 1, i):
		if 0 <= j < len(ref):
			d = ref[j] - x
			if abs(d) <= tol and (best is None or abs(d) < abs(best)):
				best = d
	return best


def _fit_pieces_windows(ref, pts, scale):
	"""([(from ms in the subtitle, offset)], score, [share per part]) or None
	when the subtitle is not made of two or more clearly fitting stretches."""
	xs = [p * scale for p in pts]
	n, half = len(xs), PIECE_LINES // 2
	if n < 3 * PIECE_LINES or len(ref) < 50:
		return None
	samples = []
	for c in range(half, n - half + 1, PIECE_STEP):
		off, rate = _local(ref, xs[c - half:c + half])
		samples.append((c, off if rate >= PIECE_HIT else None))
	runs = []                                   # [first centre, last centre, offsets]
	for c, off in samples:
		if off is None:
			continue
		if runs and abs(off - _median(runs[-1][2])) <= PIECE_SAME_MS and c - runs[-1][1] <= 4 * PIECE_STEP:
			runs[-1][1] = c
			runs[-1][2].append(off)
		else:
			runs.append([c, c, [off]])
	runs = [r for r in runs if len(r[2]) >= 3]  # a stretch: 60 lines at least
	merged = []
	for r in runs:
		if merged and abs(_median(r[2]) - _median(merged[-1][2])) <= PIECE_SAME_MS:
			merged[-1][1] = r[1]
			merged[-1][2].extend(r[2])
		else:
			merged.append(r)
	if not 2 <= len(merged) <= MAX_PIECES:
		return None
	offs = [_median(r[2]) for r in merged]
	hit_with = [[_nearest(ref, x + o) is not None for x in xs] for o in offs]
	# Where each stretch ends: the line between two stretches that lands the most.
	cuts = [0]
	for k in range(len(merged) - 1):
		a, b = max(cuts[-1], merged[k][1] - half), min(n, merged[k + 1][0] + half)
		best_j, best_h = a, -1
		h = sum(hit_with[k + 1][a:b])
		for j in range(a, b + 1):
			if h > best_h:
				best_j, best_h = j, h
			if j < b:
				h += hit_with[k][j] - hit_with[k + 1][j]
		cuts.append(best_j)
	cuts.append(n)
	pieces, rates, hits = [], [], 0
	for k, o in enumerate(offs):
		seg = xs[cuts[k]:cuts[k + 1]]
		if not seg:
			return None
		errs = [d for d in (_nearest(ref, x + o) for x in seg) if d is not None]
		if errs:
			o += _median(errs)
		h = sum(1 for x in seg if _nearest(ref, x + o) is not None)
		pieces.append((pts[cuts[k]] if k else 0, int(round(o))))
		rates.append(h / float(len(seg)))
		hits += h
	return pieces, hits / float(n), rates


# v2.0.27: the cut points the way alass finds them (Kaegi's "Automatic
# Language-Agnostic Subtitle Synchronization", the split-penalty search):
# instead of grouping 40-line windows and guessing where one stretch ends,
# every line gets the shift that lands it, and a change of shift costs a
# fixed number of lines. The best path through the whole subtitle (dynamic
# programming, Viterbi) gives the stretches and the exact line where each
# one starts, in one pass. Shifts tried: the ones the windows found.
SPLIT_PENALTY = 8        # lines a new stretch must win to be worth a cut
MIN_PIECE = 15           # a stretch shorter than this joins its neighbour
CAND_HIT = 0.45          # a window this good proposes its shift


def _candidates(ref, xs):
	half, offs = PIECE_LINES // 2, []
	for c in range(half, len(xs) - half + 1, PIECE_STEP // 2):
		off, rate = _local(ref, xs[c - half:c + half])
		if off is not None and rate >= CAND_HIT:
			offs.append(off)
	offs.sort()
	groups = []
	for o in offs:
		if groups and o - groups[-1][-1] <= 120:
			groups[-1].append(o)
		else:
			groups.append([o])
	groups.sort(key=len, reverse=True)
	return [_median(g) for g in groups[:24]]


def fit_pieces(ref, pts, scale):
	"""([(from ms in the subtitle, offset)], score, [share per part]) or None
	when the subtitle is not made of two or more clearly fitting stretches.
	Both searches run and the one that lands more lines wins (on a tie, the
	one with fewer stretches): measured on 60 cut subtitles, the alass-style
	path finds short stretches and their exact cut lines better (99.6% of
	lines on the right shift against 97.5%), the windows separate two close
	shifts in a sloppy subtitle better."""
	a = _fit_pieces_path(ref, pts, scale)
	b = _fit_pieces_windows(ref, pts, scale)
	if not a or not b:
		return a or b
	return max((a, b), key=lambda r: (round(r[1], 3), -len(r[0])))


def _fit_pieces_path(ref, pts, scale):
	xs = [p * scale for p in pts]
	n = len(xs)
	if n < 3 * PIECE_LINES or len(ref) < 50:
		return None
	cands = _candidates(ref, xs)
	if len(cands) < 2:
		return None
	K = len(cands)
	# Landing of every line at every shift: 1 on the reference, a little less
	# when only near it, so that the path prefers the closer shift.
	land = []
	for o in cands:
		row = []
		for x in xs:
			d = _nearest(ref, x + o)
			row.append(0.0 if d is None else 1.0 - 0.25 * abs(d) / TOLERANCE_MS)
		land.append(row)
	score = [land[k][0] for k in range(K)]
	back = []
	for i in range(1, n):
		best_k = max(range(K), key=lambda k: score[k])
		best_v = score[best_k] - SPLIT_PENALTY
		step, new = [], []
		for k in range(K):
			if score[k] >= best_v:
				new.append(score[k] + land[k][i])
				step.append(k)
			else:
				new.append(best_v + land[k][i])
				step.append(best_k)
		score = new
		back.append(step)
	k = max(range(K), key=lambda j: score[j])
	path = [k]
	for step in reversed(back):
		k = step[k]
		path.append(k)
	path.reverse()
	# Stretches; a short one joins the neighbour that lands more of its lines.
	runs = []
	for i, k in enumerate(path):
		if runs and runs[-1][2] == k:
			runs[-1][1] = i + 1
		else:
			runs.append([i, i + 1, k])
	changed = True
	while changed and len(runs) > 1:
		changed = False
		for j, (a, b, k) in enumerate(runs):
			if b - a >= MIN_PIECE:
				continue
			opts = [m for m in (j - 1, j + 1) if 0 <= m < len(runs)]
			m = max(opts, key=lambda m: sum(land[runs[m][2]][a:b]))
			if m < j:
				runs[m][1] = b
			else:
				runs[m][0] = a
			del runs[j]
			changed = True
			break
	merged = []
	for r in runs:
		if merged and abs(cands[merged[-1][2]] - cands[r[2]]) <= PIECE_SAME_MS:
			merged[-1][1] = r[1]
		else:
			merged.append(list(r))
	if not 2 <= len(merged) <= MAX_PIECES:
		return None
	pieces, rates, hits = [], [], 0
	for a, b, k in merged:
		seg, o = xs[a:b], cands[k]
		errs = [d for d in (_nearest(ref, x + o) for x in seg) if d is not None]
		if errs:
			o += _median(errs)
		h = sum(1 for x in seg if _nearest(ref, x + o) is not None)
		pieces.append((pts[a] if a else 0, int(round(o))))
		rates.append(h / float(len(seg)))
		hits += h
	return pieces, hits / float(n), rates


def apply_pieces(srt, scale, pieces):
	froms = [f for f, _o in pieces]

	def sub(m):
		g = m.groups()
		a0 = _ms(*g[:4])
		off = pieces[max(0, bisect.bisect_right(froms, a0) - 1)][1]
		return '%s --> %s' % (_fmt(a0 * scale + off), _fmt(_ms(*g[4:]) * scale + off))
	return _TIME.sub(sub, srt)


def _null(ref, pts, scale, off):
	"""Best score among shifts at least 5 s away from the fit."""
	step = max(1, len(pts) // 400)
	sample = pts[::step]
	top = 0.0
	for k in range(1, 13):
		for sign in (1, -1):
			o = off + sign * k * 7300
			top = max(top, _score(ref, sample, scale, o))
	return top


def sync(srt, ref):
	"""(new text or None, log line). None when nothing should change."""
	starts = starts_of(srt)
	if not ref:
		return None, 'no reference'
	both = getattr(ref, 'ends', False)
	pts = points_of(srt) if both else starts
	scale, off, score, base = fit(ref, pts)
	desc = 'fit %.0f%% of %d lines%s (was %.0f%%), shift %+.2fs%s' % (
		score * 100, len(starts), ', starts and ends' if both else '', base * 100, off / 1000.0,
		'' if scale == 1.0 else ', speed x%.4f' % scale)
	# What WRONG shifts score against this reference: with dense dialogue a
	# good share of lines lands near some reference line anyway. The fit must
	# stand clearly above all of them.
	null = _null(ref, pts, scale, off)
	desc += ', wrong shifts %.0f%%' % (null * 100)
	good = (score >= max(MIN_SCORE, null + MIN_MARGIN) and score - base >= MIN_GAIN
			and not (scale == 1.0 and abs(off) < 150))
	if score < PIECES_BELOW:
		pc = fit_pieces(ref, pts, scale)
		if pc:
			pieces, pscore, rates = pc
			pdesc = '; in %d parts %s: %.0f%%' % (len(pieces), ', '.join(
				'%+.2fs from %s' % (o / 1000.0, _fmt(f)[:8]) for f, o in pieces), pscore * 100)
			# v2.0.27 (idea of Dex Hub's DexAlign): the same subtitle played
			# backwards has the same rhythm but no relation to the video; what
			# fitting in parts scores with it is what the extra freedom buys by
			# itself. The real fit must clear it by a wide margin.
			end = pts[-1] + pts[0]
			mc = fit_pieces(ref, sorted(end - x for x in pts), scale)
			mirror = mc[1] if mc else 0.0
			pdesc += ' (mirrored %.0f%%)' % (mirror * 100)
			if (pscore >= max(PIECES_SCORE, null + PIECES_MARGIN) and pscore >= max(score, base) + min(PIECES_GAIN, (1.0 - max(score, base)) * 0.6)
					and min(rates) >= PIECE_HIT - 0.05 and pscore - mirror >= PIECES_MIRROR):
				return apply_pieces(srt, scale, pieces), desc + pdesc + ' - applied'
			desc += pdesc
	if not good:
		return None, desc + (' - already in sync' if base >= max(MIN_SCORE, null + MIN_MARGIN) else ' - no reliable fit, left as it was')
	return apply(srt, scale, off), desc + ' - applied'


def shift_label(desc):
	"""What the notification shows: '+1.20s', or '+0.80s / +3.21s / +2.12s'
	when the subtitle was moved in parts."""
	if ' parts ' in desc:
		part = desc.split(' parts ', 1)[1].split(': ', 1)[0]
		return ' / '.join(re.findall(r'[+-]\d+\.\d+s', part))
	return desc.split('shift ', 1)[1].split(' ', 1)[0].rstrip(',')


def log(message, level=xbmc.LOGINFO):
	try: xbmc.log('%s %s' % (LOG_TAG, message), level)
	except Exception: pass
