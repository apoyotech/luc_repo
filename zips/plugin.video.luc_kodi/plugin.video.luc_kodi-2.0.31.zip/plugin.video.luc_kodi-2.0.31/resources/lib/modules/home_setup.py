# -*- coding: utf-8 -*-
"""
	luc_kodi Add-on — modules/home_setup.py (v2.0.30)

	Tools > luc_kodi Home: monta en la Home del skin las filas de luc_kodi con un
	solo clic, guardando antes lo que habia para poder volver atras.

	Movies y TV shows reciben seis filas cada uno (Trending, Popular, Netflix,
	Prime Video, Apple TV+ y Disney+, ver home_widgets.py) y, en Estuary MOD V2,
	las cuatro plataformas, con su logo, como accesos directos debajo de la
	entrada, que es como estan montadas las builds del autor.

	v2.0.28: solo los skins donde la idea encaja, por decision del autor. Cada
	uno guarda su Home a su manera y aqui solo se escribe en el formato que lee
	el propio skin (o su ayudante), comprobado contra su codigo:

	  Nimbus, FENtastic   su ayudante: tabla custom_paths de cpath_cache.db y
	  (y sus forks Plus)  remake_all_cpaths para regenerar el XML. Los forks
	                      Plus usan los mismos ids (skin.nimbus, skin.fentastic)
	  Estuary MOD V2      script.skinshortcuts 2.x: propiedades widgetPath.1-6 de
	                      las entradas movies/tvshows del menu principal

	Estuary MOD V2 para Kodi 22 usa skinshortcuts 3, y Estuary oficial no deja
	poner widgets propios en su Home: en esos, y en cualquier otro skin, las
	filas se anaden a mano desde el selector de widgets del skin, en Tools >
	luc_kodi Home > Movie rows / TV show rows.

	v2.0.28: luc_kodi manda en la Home. Las entradas Movies y TV Shows del menu
	principal llevan a los menus de luc_kodi, y el resto de entradas propias del
	skin (Music, Live TV, Radio, Pictures, Weather...) se ocultan con el
	interruptor que trae el propio skin, sin borrarlas. Se quedan Settings, Power
	y Search para que el usuario siempre tenga salida. Restore lo devuelve todo.

	v2.0.30: Add-ons tampoco se oculta, por decision del autor: da acceso a los
	addons instalados desde la Home del skin. En Nimbus y FENtastic (y sus Plus)
	es la entrada id=addons, que cuelga de HomeMenuNoProgramsButton; en Estuary
	MOD V2 es la entrada con defaultID addons (rama Omega del skin).

	La copia de seguridad vive en addon_data/plugin.video.luc_kodi/home_backup/
	<skin>/ y no se pisa: si se aplica dos veces, la que se restaura es la Home
	de antes de la primera vez.
"""

import json
import os
import shutil
import time

import xbmc
import xbmcvfs

from resources.lib.modules import control
from resources.lib.modules import log_utils
from resources.lib.modules import home_widgets
from resources.lib.modules import skin_ratings

getLS = control.lang

SS_DATA = 'special://profile/addon_data/script.skinshortcuts/'
SS_MASTER = 'special://masterprofile/addon_data/script.skinshortcuts/'


def _tp(path):
	return xbmcvfs.translatePath(path)


def _backup_root():
	return os.path.join(control.dataPath, 'home_backup')


def _skin():
	return xbmc.getSkinDir() or ''


def _skin_name(skin):
	try:
		import xbmcaddon
		return xbmcaddon.Addon(skin).getAddonInfo('name') or skin
	except Exception:
		return skin


def _has_addon(addon_id):
	return bool(xbmc.getCondVisibility('System.HasAddon(%s)' % addon_id))


# ───────────────────────── copia de seguridad ─────────────────────────
class Backup:
	"""Guarda los ficheros que se van a tocar tal y como estaban (o que no
	existian) y los devuelve a su sitio."""

	def __init__(self, skin):
		self.dir = os.path.join(_backup_root(), skin)
		self.manifest = os.path.join(self.dir, 'manifest.json')

	def exists(self):
		return os.path.isfile(self.manifest)

	def save(self, paths, extra=None):
		"""La primera copia es la que vale: lo ya guardado no se pisa. v2.0.28: si
		una version nueva toca un fichero mas (asi paso con Arctic Fuse 3),
		ese se anade a la copia que ya habia, tal y como esta ahora."""
		try:
			os.makedirs(self.dir, exist_ok=True)
			data = self.load() if self.exists() else {'date': time.strftime('%Y-%m-%d %H:%M'), 'files': {}, 'extra': {}}
			old_extra = data.setdefault('extra', {})
			for k, v in (extra or {}).items(): # lo de antes de la primera vez manda
				if isinstance(v, dict) and isinstance(old_extra.get(k), dict):
					for kk, vv in v.items(): old_extra[k].setdefault(kk, vv) # v2.0.28: un interruptor nuevo se suma
				else: old_extra.setdefault(k, v)
			files = data.setdefault('files', {})
			n = len(files)
			for path in paths:
				if path in files: continue
				if os.path.isfile(path):
					name = 'f%02d_%s' % (n, os.path.basename(path))
					shutil.copyfile(path, os.path.join(self.dir, name))
					files[path] = name
				else:
					files[path] = None
				n += 1
			with open(self.manifest, 'w', encoding='utf-8') as f:
				json.dump(data, f, indent=2)
			return True
		except Exception:
			log_utils.error()
			return False

	def load(self):
		with open(self.manifest, encoding='utf-8') as f:
			return json.load(f)

	def restore_files(self):
		data = self.load()
		for path, name in data.get('files', {}).items():
			try:
				if name: shutil.copyfile(os.path.join(self.dir, name), path)
				elif os.path.isfile(path): os.remove(path)
			except Exception:
				log_utils.error()
		return data

	def clear(self):
		shutil.rmtree(self.dir, ignore_errors=True)


# ───────────────────────── FENtastic / Nimbus ─────────────────────────
class CPathHelper:
	"""FENtastic y Nimbus (y FENtastic Plus / Nimbus Plus): mismo ayudante
	(cpath_maker.py) con otro nombre."""
	submenu = False

	# v2.0.28: entradas propias del skin que se ocultan (Skin.SetBool del skin)
	HIDE = ('Music', 'MusicVideo', 'TV', 'Radio', 'Games', 'Pictures', 'Videos', 'Fav', 'Weather',
		'Custom1', 'Custom2', 'Custom3', 'Custom4', 'Custom5', 'Custom6', 'Custom7', 'Custom8', 'Custom9', 'Custom10')
	# v2.0.28: Custom4-6 son de FENtastic Plus y Custom4-10 de Nimbus Plus; _hide()
	# deja solo los que tiene el skin instalado.
	# v2.0.30: 'Programs' es la entrada Add-ons de estos skins (id=addons): se
	# muestra, y se vuelve a encender si una Apply anterior la habia ocultado.
	SHOW = ('Movies', 'TVShows', 'Programs')

	def __init__(self, skin, helper, name):
		self.skin, self.needs, self.name = skin, helper, name
		self.db = _tp('special://profile/addon_data/%s/cpath_cache.db' % helper)

	def paths(self):
		return [self.db]

	@staticmethod
	def _bool(name):
		return 'HomeMenuNo%sButton' % name

	def _hide(self):
		"""v2.0.28: solo los interruptores que tiene este skin. Si no se puede leer su Home.xml, todos: un interruptor
		que el skin no usa no hace nada."""
		try:
			with open(_tp('special://skin/xml/Home.xml'), encoding='utf-8') as f: home = f.read()
		except Exception: return self.HIDE
		return tuple(n for n in self.HIDE if self._bool(n) in home)

	# v2.0.28: Nimbus Plus pasa cada fila de un addon por su "puente" (Skin
	# Settings > Load add-on widgets separately), que arranca luc_kodi desde cero
	# en cada fila. Con la Home de luc_kodi se apaga: las filas van directas a
	# luc_kodi, como en FENtastic y Estuary. Restore lo deja como estaba.
	BRIDGE_OFF = 'Widgets.DisableBridge'

	def _has_bridge(self):
		try:
			with open(_tp('special://skin/xml/Variables.xml'), encoding='utf-8') as f:
				return 'NimbusWidgetBridgeVar' in f.read()
		except Exception: return False

	def _switches(self):
		names = [self._bool(n) for n in self._hide() + self.SHOW]
		if self._has_bridge(): names.append(self.BRIDGE_OFF)
		return names

	# v2.0.28: Nimbus y Nimbus Plus reproducen solos el trailer del item enfocado
	# (Skin Settings > Trailers > Auto) con ListItem.Trailer, que luc_kodi ya
	# rellena. Apply ofrece encenderlo; Restore lo deja como estaba.
	TRAILER_SETTING, TRAILER_AUTO = 'trailerSetting', '2'
	trailers = False # lo decide el usuario en apply()

	def offers_trailers(self):
		"""True si el skin tiene trailers automaticos y aun no estan encendidos."""
		try:
			with open(_tp('special://skin/xml/SkinSettings.xml'), encoding='utf-8') as f:
				if self.TRAILER_SETTING not in f.read(): return False
		except Exception: return False
		return xbmc.getInfoLabel('Skin.String(%s)' % self.TRAILER_SETTING) != self.TRAILER_AUTO

	def state(self):
		"""Como estan ahora los interruptores, para devolverlos al restaurar."""
		out = {'bools': dict((b, bool(xbmc.getCondVisibility('Skin.HasSetting(%s)' % b))) for b in self._switches())}
		if self._color_studio(): out['bools'][self.COLOR_STUDIO] = False # v2.0.28
		if self._no_line_title(): out['bools'][self.LINE_TITLE_OFF] = False # v2.0.28
		if self._no_label_ratings(): out['bools'][self.LABEL_RATINGS_OFF] = False # v2.0.28
		strings = {}
		if self.trailers: strings[self.TRAILER_SETTING] = xbmc.getInfoLabel('Skin.String(%s)' % self.TRAILER_SETTING)
		if self._ratings(): strings.update(skin_ratings.setup_state(self.skin))
		if strings: out['strings'] = strings
		return out

	# v2.0.28: FENtastic pinta el logo del estudio con resource.images.studios.white
	# salvo que "Disable color studio logos" este apagado (Disable.ColorStudio,
	# nombre al reves). Con solo el pack de color instalado no se veia ningun
	# logo: Apply cambia a color, y Restore lo devuelve.
	COLOR_STUDIO = 'Disable.ColorStudio'

	def _color_studio(self):
		if getattr(self, '_color_ok', None) is None:
			has = lambda a: bool(xbmc.getCondVisibility('System.AddonIsEnabled(%s)' % a))
			self._color_ok = self.skin == 'skin.fentastic' and has('resource.images.studios.coloured') \
				and not has('resource.images.studios.white') \
				and not xbmc.getCondVisibility('Skin.HasSetting(%s)' % self.COLOR_STUDIO)
		return self._color_ok

	# v2.0.28: en Nimbus / Nimbus Plus la linea de info de la Home repetia el
	# titulo ("Movies > Prime Video | Drawn Together") que ya sale arriba en
	# grande (clearlogo o texto). Apply apaga "Show item title in InfoLine"
	# (Disable.WidgetInfoLineTitle) y deja solo el titulo naranja de la fila;
	# Restore lo vuelve a encender. Es un ajuste del skin entero.
	LINE_TITLE_OFF = 'Disable.WidgetInfoLineTitle'

	def _no_line_title(self):
		if getattr(self, '_line_ok', None) is None:
			self._line_ok = self.skin == 'skin.nimbus' \
				and not xbmc.getCondVisibility('Skin.HasSetting(%s)' % self.LINE_TITLE_OFF)
		return self._line_ok

	# v2.0.28: FENtastic / FENtastic Plus repetian en la cabecera de la fila las
	# notas que ya salen en el panel de la izquierda. Apply apaga "Enable ratings
	# for widget labels" (Disable.WidgetLabelRatings). Restore lo vuelve a encender.
	# El titulo que el skin pega detras ("Netflix | UNABOMBER") NO se puede
	# quitar: sale de un parametro fijo de Includes_Home.xml (label_focus) que el
	# ayudante no deja cambiar. Un [COLOR] transparente sin cerrar no sirve: Kodi
	# lo pinta como texto (probado en las pruebas de la v2.0.28).
	LABEL_RATINGS_OFF = 'Disable.WidgetLabelRatings'

	def _no_label_ratings(self):
		if getattr(self, '_label_ok', None) is None:
			self._label_ok = self.skin == 'skin.fentastic' \
				and not xbmc.getCondVisibility('Skin.HasSetting(%s)' % self.LABEL_RATINGS_OFF)
		return self._label_ok

	# v2.0.28: la fila de notas de Nimbus y FENtastic (y sus Plus) sin
	# clave de MDbList (ver skin_ratings.py). Se decide una vez por Apply.
	def _ratings(self):
		if getattr(self, '_ratings_ok', None) is None:
			self._ratings_ok = skin_ratings.can_take_over(self.skin)
		return self._ratings_ok

	def _rows(self):
		out = [('movie.main_menu', home_widgets.MOVIES_MENU, 'Movies', '', ''),
			('tvshow.main_menu', home_widgets.TV_MENU, 'TV Shows', '', '')]
		for mediatype, prefix in (('movie', 'movie.widget'), ('tvshow', 'tvshow.widget')):
			for n, (_id, label, path) in enumerate(home_widgets.rows(mediatype), 1):
				out.append(('%s.%d' % (prefix, n), path, home_widgets.styled(label), 'WidgetListPoster', '%s | Poster' % label))
		return out

	def apply(self):
		import sqlite3
		os.makedirs(os.path.dirname(self.db), exist_ok=True)
		con = sqlite3.connect(self.db, timeout=20)
		try:
			con.execute('CREATE TABLE IF NOT EXISTS custom_paths (cpath_setting text unique, cpath_path text, cpath_header text, cpath_type text, cpath_label text)')
			con.execute("DELETE FROM custom_paths WHERE cpath_setting LIKE 'movie.widget.%' OR cpath_setting LIKE 'tvshow.widget.%' OR cpath_setting IN ('movie.main_menu', 'tvshow.main_menu')")
			con.executemany('INSERT OR REPLACE INTO custom_paths VALUES (?, ?, ?, ?, ?)', self._rows())
			con.commit()
		finally:
			con.close()
		for n in self._hide(): xbmc.executebuiltin('Skin.SetBool(%s)' % self._bool(n))
		for n in self.SHOW: xbmc.executebuiltin('Skin.Reset(%s)' % self._bool(n))
		if self._has_bridge(): xbmc.executebuiltin('Skin.SetBool(%s)' % self.BRIDGE_OFF)
		if self.trailers: xbmc.executebuiltin('Skin.SetString(%s,%s)' % (self.TRAILER_SETTING, self.TRAILER_AUTO))
		if self._ratings(): skin_ratings.take_over(self.skin)
		if self._color_studio(): xbmc.executebuiltin('Skin.SetBool(%s)' % self.COLOR_STUDIO)
		if self._no_line_title(): xbmc.executebuiltin('Skin.SetBool(%s)' % self.LINE_TITLE_OFF)
		if self._no_label_ratings(): xbmc.executebuiltin('Skin.SetBool(%s)' % self.LABEL_RATINGS_OFF)
		self._remake()

	def _remake(self):
		# Regenera los XML de widgets y recarga el skin (y avisa con su propio dialogo).
		xbmc.executebuiltin('RunScript(%s,mode=remake_all_cpaths)' % self.needs)

	def restore(self, backup):
		data = backup.restore_files()
		for name, on in (data.get('extra', {}).get('bools') or {}).items():
			xbmc.executebuiltin(('Skin.SetBool(%s)' if on else 'Skin.Reset(%s)') % name)
		for name, value in (data.get('extra', {}).get('strings') or {}).items():
			# v2.0.28: si el usuario ha puesto su clave de MDbList, la marca ya es del ayudante
			if name in ('valid_api_key', 'mdblist_api_key') and not skin_ratings.ours_now(name): continue
			xbmc.executebuiltin('Skin.SetString(%s,%s)' % (name, value) if value else 'Skin.Reset(%s)' % name)
		self._remake()


# ───────────────────────── script.skinshortcuts 2.x ─────────────────────────
def _slug(text):
	import re
	return re.sub(r'-+', '-', re.sub(r'[^a-z0-9]+', '-', text.lower())).strip('-')


class SkinShortcuts:
	"""Estuary MOD V2 (Omega): las filas van en propiedades (widgetPath.1-6) de
	las entradas movies/tvshows del menu principal."""
	needs = 'script.skinshortcuts'
	submenu = True
	LABELIDS = (('movie', 'movies'), ('tvshow', 'tvshows'))
	MANAGED = ('widget', 'widgetName', 'widgetPath', 'widgetTarget', 'widgetType', 'widgetAspect', 'widgetStyle')

	def __init__(self, skin, name, slots, extra_props=None, base_widget=None, logo_only=False, hide_flags=(), set_strings=None):
		self.skin, self.name = skin, name
		# v2.0.28: interruptores del skin que Apply enciende para ocultar datos
		# de la barra de info (Estuary MOD V2: duracion, hora de fin, fecha de
		# estreno y fecha anadida; quedan la nota y la calificacion por edades).
		# Restore los devuelve como estaban.
		self.hide_flags = tuple(hide_flags)
		# v2.0.28: textos del skin que Apply cambia (Estuary MOD V2: el color de
		# la barra de info, al naranja de luc_kodi). Restore los devuelve.
		self.set_strings = dict(set_strings or {})
		# v2.0.28: Estuary MOD V2 pinta los accesos de plataforma como fichas con
		# el logo; ahi el nombre sobra. Se guarda con alfa 00 (invisible), no
		# vacio: skinshortcuts saca el labelID del nombre y trata una etiqueta
		# vacia como fin de lista.
		self.logo_only = logo_only
		self.slots = slots # sufijos de las filas: ('.1', ..., '.6')
		self.extra_props = extra_props or {} # {nombre: valor} por fila
		self.base_widget = base_widget # Estuary MOD V2: widget=PersonalWidgetList

	def _overrides(self):
		try:
			with open(_tp('special://skin/shortcuts/overrides.xml'), encoding='utf-8') as f: return f.read()
		except Exception: return ''

	def _shared(self, sublevel=False):
		ov = self._overrides()
		if '<doNotShareMenu' in ov: return False
		if sublevel and '<doNotShareLevels' in ov: return False
		try:
			import xbmcaddon
			return xbmcaddon.Addon('script.skinshortcuts').getSetting('shared_menu') != 'false'
		except Exception: return True

	def _data_file(self, group, sublevel=False):
		name = _slug(group)
		if not self._shared(sublevel): name = '%s-%s' % (self.skin, name)
		return os.path.join(_tp(SS_DATA), '%s.DATA.xml' % name)

	def _props_file(self):
		return os.path.join(_tp(SS_DATA), '%s.properties' % self.skin)

	def _hash_file(self):
		return os.path.join(_tp(SS_MASTER), '%s.hash' % self.skin)

	KEEP = ('settings', 'power', 'search', 'system') # siempre visibles: la salida del usuario
	# v2.0.30: entradas del skin que se quedan visibles; si una Apply anterior
	# las desactivo, se reactivan. Add-ons: defaultID addons, etiqueta 24001.
	SHOW = ('addons',)
	SHOW_LABELS = ('24001', '$localize[24001]')

	def paths(self):
		out = [self._props_file(), self._data_file('mainmenu')]
		for _m, lid in self.LABELIDS:
			out.append(self._data_file(lid))
		return out

	def _label(self, label, art):
		if self.logo_only and art: return home_widgets.hidden(label)
		return home_widgets.styled(label)

	def _shortcut_xml(self, rows):
		from xml.sax.saxutils import escape
		parts = ['<?xml version="1.0" encoding="UTF-8"?>', '<shortcuts>']
		for _id, label, path in rows:
			art = home_widgets.logo(label) # v2.0.28: el logo de la plataforma, si es una
			parts.append('\t<shortcut>\n\t\t<defaultID>%s</defaultID>\n\t\t<label>%s</label>\n\t\t<label2>luc_kodi</label2>\n\t\t<icon>%s</icon>\n\t\t%s\n\t\t<action>%s</action>\n\t</shortcut>'
				% (escape(_slug('luc_kodi ' + _id)), escape(self._label(label, art)), escape(art or 'DefaultVideo.png'),
				'<thumb>%s</thumb>' % escape(art) if art else '<thumb />', escape('ActivateWindow(Videos,%s,return)' % path)))
		parts.append('</shortcuts>')
		return '\n'.join(parts) + '\n'

	def _write_props(self):
		path = self._props_file()
		data = []
		if os.path.isfile(path):
			with open(path, encoding='utf-8') as f: raw = f.read()
			try: data = json.loads(raw)
			except Exception:
				import ast
				try: data = ast.literal_eval(raw)
				except Exception: data = []
		ours = set(lid for _m, lid in self.LABELIDS)

		def managed(prop):
			base = prop.split('.')[0]
			return base in self.MANAGED
		data = [e for e in data if not (isinstance(e, (list, tuple)) and len(e) >= 4 and e[0] == 'mainmenu' and e[1] in ours and managed(e[2]))]
		for mediatype, lid in self.LABELIDS:
			if self.base_widget: data.append(['mainmenu', lid, 'widget', self.base_widget])
			for suffix, (_id, label, wpath) in zip(self.slots, home_widgets.rows(mediatype)):
				data += [['mainmenu', lid, 'widget' + suffix, 'Addon'],
					['mainmenu', lid, 'widgetName' + suffix, home_widgets.styled(label)],
					['mainmenu', lid, 'widgetType' + suffix, 'movies' if mediatype == 'movie' else 'tvshows'],
					['mainmenu', lid, 'widgetTarget' + suffix, 'videos'],
					['mainmenu', lid, 'widgetPath' + suffix, wpath]]
				for k, v in self.extra_props.items():
					data.append(['mainmenu', lid, k + suffix, v])
		os.makedirs(os.path.dirname(path), exist_ok=True)
		with open(path, 'w', encoding='utf-8') as f: json.dump(data, f, indent=4)

	def _mainmenu(self):
		"""v2.0.28: el menu principal del usuario (o el del skin) con Movies y TV
		Shows llevando a luc_kodi y el resto desactivado con <disabled>, que es como
		lo guarda el propio editor de skinshortcuts. No se borra nada."""
		import xml.etree.ElementTree as ET
		src = None
		for path in (self._data_file('mainmenu'), _tp('special://skin/shortcuts/mainmenu.DATA.xml')):
			if os.path.isfile(path): src = path; break
		if not src: return None
		root = ET.parse(src).getroot()  # nosec B314: el mainmenu local del skin o de skinshortcuts, no datos de la red
		seen = set()
		target = {'movies': home_widgets.MOVIES_MENU, 'tvshows': home_widgets.TV_MENU}
		for sc in root.findall('shortcut'):
			lid = (sc.findtext('defaultID') or _slug(sc.findtext('label') or '')).lower()
			dis = sc.find('disabled')
			if lid in target and lid not in seen:
				seen.add(lid)
				act = sc.find('action')
				if act is None: act = ET.SubElement(sc, 'action')
				act.text = 'ActivateWindow(Videos,%s,return)' % target[lid]
				vis = sc.find('visible')
				if vis is not None: sc.remove(vis) # las variantes del skin (con o sin biblioteca) ya no aplican
				if dis is not None: sc.remove(dis)
			elif lid in self.KEEP:
				continue
			elif lid in self.SHOW or (sc.findtext('label') or '').strip().lower() in self.SHOW_LABELS: # v2.0.30
				if dis is not None: sc.remove(dis)
			elif dis is None:
				ET.SubElement(sc, 'disabled').text = 'True'
		return ET.tostring(root, encoding='unicode')

	def _flags_to_set(self):
		return [b for b in self.hide_flags if not xbmc.getCondVisibility('Skin.HasSetting(%s)' % b)]

	def state(self):
		"""v2.0.28: los interruptores que Apply va a encender (estaban apagados)."""
		out = {'bools': dict((b, False) for b in self._flags_to_set())}
		if self.set_strings:
			out['strings'] = dict((k, xbmc.getInfoLabel('Skin.String(%s)' % k)) for k in self.set_strings)
		return out

	def apply(self):
		for b in self._flags_to_set(): xbmc.executebuiltin('Skin.SetBool(%s)' % b) # v2.0.28
		for k, v in self.set_strings.items(): xbmc.executebuiltin('Skin.SetString(%s,%s)' % (k, v)) # v2.0.28
		os.makedirs(_tp(SS_DATA), exist_ok=True)
		menu = self._mainmenu()
		if menu:
			with open(self._data_file('mainmenu'), 'w', encoding='utf-8') as f:
				f.write('<?xml version="1.0" encoding="UTF-8"?>\n' + menu + '\n')
		for mediatype, lid in self.LABELIDS:
			with open(self._data_file(lid), 'w', encoding='utf-8') as f:
				f.write(self._shortcut_xml(home_widgets.platforms(mediatype)))
		self._write_props()
		self._rebuild()

	def _rebuild(self):
		# Sin hash, skinshortcuts rehace el menu la proxima vez que se abre la Home.
		try:
			if os.path.isfile(self._hash_file()): os.remove(self._hash_file())
		except Exception: log_utils.error()
		xbmc.executebuiltin('ReloadSkin()')

	def restore(self, backup):
		data = backup.restore_files() or {}
		for name, on in (data.get('extra', {}) or {}).get('bools', {}).items(): # v2.0.28
			xbmc.executebuiltin(('Skin.SetBool(%s)' if on else 'Skin.Reset(%s)') % name)
		for name, value in ((data.get('extra', {}) or {}).get('strings') or {}).items(): # v2.0.28
			xbmc.executebuiltin('Skin.SetString(%s,%s)' % (name, value) if value else 'Skin.Reset(%s)' % name)
		self._rebuild()

	def has_main_entries(self):
		"""Las filas van a las entradas Movies y TV Shows del menu principal. Si
		el usuario las quito, no hay donde ponerlas y hay que decirlo."""
		for path in (self._data_file('mainmenu'), _tp('special://skin/shortcuts/mainmenu.DATA.xml')):
			if os.path.isfile(path):
				try:
					with open(path, encoding='utf-8') as f: txt = f.read().lower()
				except Exception: continue
				return '>movies<' in txt and '>tvshows<' in txt or ('342' in txt and '20343' in txt)
		return True


# ───────────────────────── deteccion ─────────────────────────
def writer_for(skin):
	"""v2.0.28: Nimbus, FENtastic (oficiales y forks Plus, mismos ids) y Estuary
	MOD V2 para Kodi 21. Cualquier otro skin: None."""
	s = skin.lower()
	if s == 'skin.fentastic': return CPathHelper(skin, 'script.fentastic.helper', _skin_name(skin))
	if s == 'skin.nimbus': return CPathHelper(skin, 'script.nimbus.helper', _skin_name(skin))
	if s == 'skin.estuary.modv2':
		# La rama de Kodi 22 usa skinshortcuts 3 (otro formato): no.
		try:
			import xbmcaddon
			if xbmcaddon.Addon('script.skinshortcuts').getAddonInfo('version').startswith('3'): return None
		except Exception: pass
		return SkinShortcuts(skin, 'Estuary MOD V2', tuple('.%d' % n for n in range(1, len(home_widgets.rows('movie')) + 1)),
			extra_props={'widgetAspect': '31338'}, base_widget='PersonalWidgetList', logo_only=True,
			hide_flags=('show_mediadurationflag', 'show_mediaendtimeflag', 'show_dateairedflag', 'show_dateaddedflag'),
			set_strings={'MediaFlagsColor': 'fffdb515'})
	return None


# ───────────────────────── Tools > luc_kodi Home ─────────────────────────
def menu():
	from resources.lib.menus.navigator import Navigator
	nav = Navigator()
	skin = _skin()
	w = writer_for(skin)
	label = getLS(401110) % (w.name if w else _skin_name(skin))
	nav.addDirectoryItem(label, 'homeSetupApply', 'tools.png', 'DefaultAddonService.png', isFolder=False)
	if Backup(skin).exists():
		nav.addDirectoryItem(401111, 'homeSetupRestore', 'tools.png', 'DefaultAddonService.png', isFolder=False)
	nav.addDirectoryItem(401112, 'homeWidgetsList&type=movie', 'movies.png', 'DefaultMovies.png')
	nav.addDirectoryItem(401113, 'homeWidgetsList&type=tvshow', 'tvshows.png', 'DefaultTVShows.png')
	nav.endDirectory()


def rows_folder(mediatype):
	"""Las seis rutas como carpetas, para el selector de widgets de cualquier skin."""
	from resources.lib.menus.navigator import Navigator
	nav = Navigator()
	icon = 'DefaultMovies.png' if mediatype == 'movie' else 'DefaultTVShows.png'
	for _id, label, path in home_widgets.rows(mediatype if mediatype in ('movie', 'tvshow') else 'movie'):
		nav.addDirectoryItem(label, path, icon, icon, isAction=False)
	nav.endDirectory()


def apply():
	skin = _skin()
	w = writer_for(skin)
	dialog = control.dialog
	if not w:
		dialog.ok('luc_kodi Home', getLS(401117) % _skin_name(skin))
		return
	if not _has_addon(w.needs):
		dialog.ok('luc_kodi Home', getLS(401120) % (w.name, w.needs))
		return
	if isinstance(w, SkinShortcuts) and not w.has_main_entries():
		dialog.ok('luc_kodi Home', getLS(401121) % w.name)
		return
	msg = getLS(401114)
	if w.submenu: msg = '%s[CR][CR]%s' % (msg, getLS(401122))
	if getattr(w, '_ratings', None) and w._ratings(): # v2.0.28
		msg = '%s[CR][CR]%s' % (msg, getLS(401128 if w.skin == 'skin.fentastic' else 401127))
	if not dialog.yesno('luc_kodi Home', msg): return
	if hasattr(w, 'offers_trailers') and w.offers_trailers():
		w.trailers = bool(dialog.yesno('luc_kodi Home', getLS(401126) % w.name)) # v2.0.28
	backup = Backup(skin)
	extra = w.state() if hasattr(w, 'state') else None
	if not backup.save(w.paths(), extra):
		dialog.ok('luc_kodi Home', getLS(401123))
		return
	try:
		w.apply()
	except Exception:
		log_utils.error()
		dialog.ok('luc_kodi Home', getLS(401123))
		return
	added = home_widgets.sync_precache()
	log_utils.log('luc_kodi Home applied to %s (%d platforms added to the fast precache)' % (skin, added))
	control.notification(title='luc_kodi Home', message=getLS(401116) % w.name)


def restore():
	skin = _skin()
	w = writer_for(skin)
	backup = Backup(skin)
	if not w or not backup.exists():
		control.dialog.ok('luc_kodi Home', getLS(401118))
		return
	if not control.dialog.yesno('luc_kodi Home', getLS(401124) % backup.load().get('date', '')): return
	try:
		w.restore(backup)
		backup.clear()
	except Exception:
		log_utils.error()
		control.dialog.ok('luc_kodi Home', getLS(401123))
		return
	control.notification(title='luc_kodi Home', message=getLS(401119))
