# -*- coding: utf-8 -*-
"""
	luc_kodi Add-on — sub_translate.py (v2.0.27)

	Natural subtitle translation with Gemini.

	When neither the file nor OpenSubtitles has a subtitle in the language the
	user picked (Settings > Subtitles > Preferred language), luc_kodi takes a
	subtitle that does exist in another language (English first, then the
	secondary language, then the languages of the subtitle tracks inside the
	file) and has Gemini translate it.

	WHY NOT LINE BY LINE. A subtitle line is often half a sentence. Classic
	machine translation (what sites like SubtitleCat publish) translates every
	line on its own, so the halves stop fitting together and the tone between
	characters changes from line to line. Here the lines go in blocks of about
	a hundred, with the lines just before as context, and the model is told to
	keep each line where it was so the timing never moves.

	SPEED (v2.0.27, measured on a kodi.log of 4-nov-2026). With JSON
	answers and blocks of 100 lines an episode of 644 lines took 62 s, and two
	others were stopped by the user before the end. The answer is now plain
	rows "id|text" (half the output tokens of JSON, and output is what takes
	time), blocks are 50 lines and up to five go out at once.

	KEYS IN ORDER. All requests go to key 1 until Google says it has no
	quota left (429); then key 2, and so on. Never two keys for the same
	work, and never a second language before the first one has failed.

	WHAT NEVER CHANGES. Timings and the number of lines: only the text is sent,
	each line with its id, and the answer must bring back every id. A block that
	comes back short, untranslated or broken is split in two and asked again; if
	it still fails the whole translation is dropped (never a half-translated
	file) and the player goes on as before.

	THE GEMINI KEYS. The same keys and model chain as Gemini search
	(gemini_api.py), but with its own request loop: the search keeps its state
	in module globals, which is fine for one query at a time but not for the
	parallel blocks of a translation. The knowledge is shared (keys Google
	refused, models that answered 404 on every key), the request state is not.

	CACHE. Every translation is kept as an .srt in the profile folder
	(subs_translated/), keyed on the OpenSubtitles file and the target language:
	watching the same episode again costs no download and no Gemini request.
	The newest 40 are kept.
"""

import hashlib
import json
import os
import re
import threading
import time

import xbmc

from resources.lib.modules import control
from resources.lib.modules import gemini_api as gapi
from resources.lib.modules import sub_langs

LOG_TAG = '[luc_kodi-subtr]'
# Bump when the prompt or the output format changes: old cached files are
# simply not found any more and get pruned with the rest.
PROMPT_VERSION = 't2'

CHUNK_CUES = 50         # lines per request
CHUNK_CHARS = 3000      # ...or fewer when the lines are long
CONTEXT_CUES = 3        # lines before the block, sent as context only
MIN_SPLIT = 8           # a failing block smaller than this is not split again
MAX_WORKERS = 5         # one request in flight per key, at most five
EMPTY_MODELS = 2        # models tried when Google answers with no text
REQUEST_TIMEOUT = 25     # a block of 50 lines takes 3-8 s; past this the model is stuck
TOTAL_BUDGET = 300      # seconds for a whole film; the coordinator checks it
CACHE_KEEP = 40

cache_dir = control.joinPath(control.dataPath, 'subs_translated')

# Lowest request profile that worked in this session (same idea as the ladder
# in gemini_api): 0 = system instruction + safety settings + thinking level,
# 1 = safety settings only, 2 = bare. Once Google refused a shape, later
# blocks skip it.
_profile_floor = 0
_lock = threading.Lock()

system_instruction = (
	'You are a professional film and TV subtitler translating subtitles. '
	'You write natural, idiomatic dialogue a native speaker would say, short enough to read on screen. '
	'You return only the numbered rows you were asked for.'
)

# MEASURED (kodi.log 4-nov-2026, "Hooked" S01E03): Google answered 200 with no
# text at all for an ordinary drama, on every half of the block: the prompt was
# blocked by the default safety filters. Subtitles are fiction (crime, insults,
# violence, sex scenes), so the filters go to BLOCK_NONE, the documented
# setting for applications that handle such content themselves.
safety_settings = [{'category': c, 'threshold': 'BLOCK_NONE'} for c in (
	'HARM_CATEGORY_HARASSMENT', 'HARM_CATEGORY_HATE_SPEECH',
	'HARM_CATEGORY_SEXUALLY_EXPLICIT', 'HARM_CATEGORY_DANGEROUS_CONTENT')]

BR = '<br>'   # a line break inside one subtitle, on the wire

prompt_template = '''Translate the subtitle lines below from %(src)s into %(dst)s.%(variant)s
They belong to: %(title)s. Use the title only as context.

Each row is "<id>|<text>". %(br)s marks a line break inside one subtitle.

Rules:
- Answer with exactly one row "<id>|<translation>" for EVERY id below, the same ids, in the same order, and nothing else: no heading, no notes, no code fences.
- Never merge, split, drop or reorder rows: the timing of each line is fixed. If a sentence runs over several rows, translate it so the pieces still read naturally one after another.
- Translate the meaning the way a native subtitler would, not word by word. Keep each line about as short as the original.
- Keep the speaker's register: formal or informal address stays consistent between the same characters.
- Keep %(br)s and formatting tags such as <i>, </i>, <b>, <font ...> and {\\an8} exactly where they are.
- Keep names of people and places; use the usual name in %(dst)s only when one exists.
- Translate sound and speaker tags like [door slams], (laughs) or "JOHN:".
%(context)s
Rows to translate:
%(lines)s'''

# What the model is told about the target, beyond its name. Castilian and
# Latin American Spanish are separate languages in luc_kodi (sub_langs).
_TARGET_NAMES = {
	'Spanish (Spain)': ('Spanish', ' Use the Spanish of Spain (Castilian): vosotros, and the vocabulary of Spain.'),
	'Spanish (Latin America)': ('Spanish', ' Use neutral Latin American Spanish: ustedes (never vosotros) and vocabulary understood across Latin America.'),
	'Portuguese(Brazil)': ('Brazilian Portuguese', ''),
	'Portuguese': ('European Portuguese', ''),
	'Chinese': ('Simplified Chinese', ''),
}

# OpenSubtitles language code -> English name, from sub_langs (pt-br, zh-cn...).
_OS_NAME = {}
for _name, _codes in sub_langs._OS.items():
	for _c in _codes.split(','):
		_OS_NAME.setdefault(_c, _name)
_OS_NAME.update({'es': 'Spanish', 'sp': 'Spanish', 'ea': 'Spanish', 'pt-br': 'Brazilian Portuguese',
	'pt-pt': 'Portuguese', 'zh-cn': 'Chinese', 'zh-tw': 'Traditional Chinese', 'ze': 'Chinese'})


# ──────────────────────────────────────────────────────────────────────
# Public API
# ──────────────────────────────────────────────────────────────────────

def enabled():
	"""On in settings and at least one Gemini key."""
	return control.setting('subtitles.translate') != 'false' and gapi.has_gemini_keys()


def source_name(os_code):
	return _OS_NAME.get((os_code or '').lower(), os_code or 'the original language')


# Language names for the notifications when Kodi runs in Spanish (the add-on
# only ships English and Spanish strings, so every other UI keeps English).
# MEASURED (kodi.log 4-nov-2026): the Spanish notice read "desde English".
_ES_NAMES = {
	'Afrikaans': 'afrikáans', 'Albanian': 'albanés', 'Arabic': 'árabe', 'Armenian': 'armenio', 'Basque': 'euskera',
	'Bengali': 'bengalí', 'Bosnian': 'bosnio', 'Breton': 'bretón', 'Bulgarian': 'búlgaro', 'Burmese': 'birmano',
	'Catalan': 'catalán', 'Chinese': 'chino', 'Simplified Chinese': 'chino simplificado', 'Traditional Chinese': 'chino tradicional',
	'Croatian': 'croata', 'Czech': 'checo', 'Danish': 'danés', 'Dutch': 'neerlandés', 'English': 'inglés',
	'Esperanto': 'esperanto', 'Estonian': 'estonio', 'Finnish': 'finés', 'French': 'francés', 'Galician': 'gallego',
	'Georgian': 'georgiano', 'German': 'alemán', 'Greek': 'griego', 'Hebrew': 'hebreo', 'Hindi': 'hindi',
	'Hungarian': 'húngaro', 'Icelandic': 'islandés', 'Indonesian': 'indonesio', 'Italian': 'italiano',
	'Japanese': 'japonés', 'Kazakh': 'kazajo', 'Khmer': 'jemer', 'Korean': 'coreano', 'Latvian': 'letón',
	'Lithuanian': 'lituano', 'Luxembourgish': 'luxemburgués', 'Macedonian': 'macedonio', 'Malay': 'malayo',
	'Malayalam': 'malayalam', 'Manipuri': 'manipurí', 'Mongolian': 'mongol', 'Montenegrin': 'montenegrino',
	'Norwegian': 'noruego', 'Occitan': 'occitano', 'Persian': 'persa', 'Polish': 'polaco', 'Portuguese': 'portugués',
	'European Portuguese': 'portugués de Portugal', 'Brazilian Portuguese': 'portugués de Brasil', 'Portuguese(Brazil)': 'portugués de Brasil',
	'Romanian': 'rumano', 'Russian': 'ruso', 'Serbian': 'serbio', 'Sinhalese': 'cingalés', 'Slovak': 'eslovaco',
	'Slovenian': 'esloveno', 'Spanish': 'español', 'Spanish (Spain)': 'español de España',
	'Spanish (Latin America)': 'español latino', 'Swahili': 'suajili', 'Swedish': 'sueco', 'Syriac': 'siríaco',
	'Tagalog': 'tagalo', 'Tamil': 'tamil', 'Telugu': 'telugu', 'Thai': 'tailandés', 'Turkish': 'turco',
	'Ukrainian': 'ucraniano', 'Urdu': 'urdu'}


def _ui_spanish():
	try: return (xbmc.getLanguage(xbmc.ENGLISH_NAME) or '').startswith('Spanish')
	except Exception: return False


def display_target(setting_value):
	"""Target language as the notification shows it: 'Spanish (Spain)' in an
	English Kodi, 'español de España' in a Spanish one."""
	if _ui_spanish(): return _ES_NAMES.get(setting_value, setting_value)
	return setting_value


def display_source(os_code):
	name = source_name(os_code)
	if _ui_spanish(): return _ES_NAMES.get(name, name)
	return name


def source_codes(target_setting, second_setting='', stream_langs=()):
	"""OpenSubtitles codes to look for a source subtitle in, best first.

	English first: almost every release has it, it is what new releases are
	subtitled in first, and it is the language Gemini translates from best.
	Then the secondary language, then the languages of the subtitle tracks
	inside the file (a French WEB-DL usually has French subtitles uploaded
	for that same release). Never the target language itself, in any variant.
	Returns (ordered list of codes, set of target codes)."""
	tbase = sub_langs.split(target_setting)[0]
	exclude = set(sub_langs.os_codes(tbase).split(',')) | set(sub_langs.os_codes(target_setting).split(','))
	names = ['English']
	if second_setting: names.append(second_setting)
	for lang in stream_langs or ():
		try: name = xbmc.convertLanguage(lang, xbmc.ENGLISH_NAME)
		except Exception: name = ''
		if name: names.append(name)
	codes = []
	for name in names:
		for code in sub_langs.os_codes(name).split(','):
			code = code.strip().lower()
			# os_codes falls back to convertLanguage: a 2-3 letter code or nothing.
			if code and code not in exclude and code not in codes and re.match(r'^[a-z]{2,3}(-[a-z]{2})?$', code):
				codes.append(code)
	return codes[:6], exclude


def cache_key(file_id, target_setting):
	blob = ('%s|%s|os:%s' % (PROMPT_VERSION, target_setting, file_id)).encode('utf-8')
	return hashlib.md5(blob).hexdigest()


def cached(key):
	"""Text of a translation made before, or None."""
	path = os.path.join(cache_dir, key + '.srt')
	try:
		if os.path.isfile(path):
			with open(path, 'r', encoding='utf-8') as f:
				text = f.read()
			os.utime(path, None)   # recently used: survives the pruning
			return text or None
	except Exception as e:
		_log('Cache read failed (ignored): %s' % e)
	return None


def store(key, text):
	try:
		if not os.path.isdir(cache_dir): os.makedirs(cache_dir)
		with open(os.path.join(cache_dir, key + '.srt'), 'w', encoding='utf-8') as f:
			f.write(text)
		_prune()
	except Exception as e:
		_log('Cache write failed (ignored): %s' % e)


def clear_cache(notify=True):
	"""Settings > Subtitles > Delete translated subtitles."""
	n = 0
	try:
		if os.path.isdir(cache_dir):
			for name in os.listdir(cache_dir):
				try:
					os.remove(os.path.join(cache_dir, name)); n += 1
				except Exception: pass
	except Exception: pass
	if notify:
		control.notification(message=control.lang(40545) % n)
	return n


def translate(srt_text, src_code, target_setting, title='', should_continue=None):
	"""Translate a whole .srt. Returns (translated text, None) or (None, reason).

	should_continue: called between blocks; returning False (playback stopped
	or changed file) cancels the translation."""
	cues = parse_srt(srt_text)
	if not cues:
		_log('Source subtitle unreadable, it starts with %r' % (srt_text or '')[:160], level=xbmc.LOGWARNING)
		return None, UNREADABLE
	work = [c for c in cues if _needs_translation(c['text'])]
	if not work:
		_log('Source subtitle has %d lines and no words, it starts with %r' % (len(cues), (srt_text or '')[:160]), level=xbmc.LOGWARNING)
		return None, NOTHING
	dst, variant = _TARGET_NAMES.get(target_setting, (target_setting, ''))
	src = source_name(src_code)
	keys = gapi._usable_keys()
	if not keys:
		return None, gapi._friendly_error('API_KEY_INVALID')

	chunks = _chunk(work)
	_log('Translating %d lines (%d blocks) %s -> %s%s, %d key(s), %d at a time' % (
		len(work), len(chunks), src, dst, ' (%s)' % target_setting if variant else '', len(keys),
		max(2, min(MAX_WORKERS, len(keys)))))
	# Requests in flight: one per key (up to five) so the blocks of one title
	# never wait on a single project's per-minute quota for long, but all of
	# them go to the FIRST key that has quota; see _request.
	started = time.time()
	deadline = started + TOTAL_BUDGET
	ctx = {'src': src, 'dst': dst, 'variant': variant, 'title': title or 'a film or TV episode',
		   'kept': 0, 'kept_max': max(3, len(work) // 100)}
	by_index = dict((c['n'], c) for c in work)

	results = {}
	errors = []
	pending = list(enumerate(chunks))
	workers = max(2, min(MAX_WORKERS, len(keys)))
	cancelled = [False]

	def worker():
		while True:
			with _lock:
				if not pending or cancelled[0] or errors: return
				pos, block = pending.pop(0)
			out, err = _translate_block(block, by_index, ctx, deadline)
			with _lock:
				if out is None: errors.append(err or 'Unknown error')
				else: results.update(out)

	# Daemon threads: on cancel the coordinator returns at once instead of
	# waiting for a request already in flight (up to REQUEST_TIMEOUT).
	threads = [threading.Thread(target=worker) for _ in range(min(workers, len(chunks)))]
	for t in threads:
		t.daemon = True
		t.start()
	monitor = xbmc.Monitor()
	while any(t.is_alive() for t in threads):
		if monitor.waitForAbort(0.5) or (should_continue and not should_continue()):
			with _lock: cancelled[0] = True
			break

	if cancelled[0]:
		_log('Cancelled: playback stopped or changed')
		return None, 'Cancelled'
	if errors:
		_log('Failed after %.1fs: %s' % (time.time() - started, errors[0]), level=xbmc.LOGWARNING)
		return None, gapi._friendly_error(errors[0])
	for c in work:
		c['text'] = results[c['n']]
	wrapped, longer = _fit_reading(cues, set(c['n'] for c in work))
	_log('Done in %.1fs: %d lines%s' % (time.time() - started, len(work),
		(' (%d long lines wrapped, %d shown longer to be read)' % (wrapped, longer)) if (wrapped or longer) else ''))
	return build_srt(cues), None


# ──────────────────────────────────────────────────────────────────────
# SRT
# ──────────────────────────────────────────────────────────────────────

_TIMING = re.compile(r'^\s*(\d{1,2}:\d{2}:\d{2}(?:[,.]\d{1,3})?)\s*-->\s*(\d{1,2}:\d{2}:\d{2}(?:[,.]\d{1,3})?)(.*)$')


def _stamp(t):
	"""00:00:01.5 -> 00:00:01,500; 0:00:01 -> 00:00:01,000."""
	hms, _sep, ms = t.replace('.', ',').partition(',')
	h, m, sec = hms.split(':')
	return '%02d:%s:%s,%s' % (int(h), m, sec, (ms + '000')[:3])


def parse_srt(text):
	"""[{'n': 1, 'timing': '00:00:01,000 --> 00:00:02,000', 'text': 'Hi'}].
	Tolerates a BOM, CRLF, missing index lines and stray blank lines."""
	if not text: return []
	text = text.lstrip('﻿').replace('\r\n', '\n').replace('\r', '\n')
	cues = []
	lines = text.split('\n')
	i = 0
	while i < len(lines):
		m = _TIMING.match(lines[i])
		if not m:
			i += 1
			continue
		timing = '%s --> %s%s' % (_stamp(m.group(1)), _stamp(m.group(2)), m.group(3).rstrip())
		i += 1
		body = []
		while i < len(lines) and lines[i].strip() != '':
			# A missing blank line before the next cue: stop at its index+timing.
			if _TIMING.match(lines[i]) or (lines[i].strip().isdigit() and i + 1 < len(lines) and _TIMING.match(lines[i + 1])):
				break
			body.append(lines[i].rstrip())
			i += 1
		cues.append({'n': len(cues) + 1, 'timing': timing, 'text': '\n'.join(body)})
	return cues


LINE_MAX = 42          # characters per line, the usual subtitle limit
READ_CPS = 17          # characters per second a viewer reads
READ_MAX_MS = 7000


def _ms_of(t):
	h, m, rest = t.split(':')
	sec, ms = rest.split(',')
	return ((int(h) * 60 + int(m)) * 60 + int(sec)) * 1000 + int(ms)


def _stamp_ms(ms):
	h, r = divmod(int(ms), 3600000)
	m, r = divmod(r, 60000)
	sec, ms = divmod(r, 1000)
	return '%02d:%02d:%02d,%03d' % (h, m, sec, ms)


def _fit_reading(cues, translated):
	"""v2.0.27 (ideas of SubStudio, the Gemini SRT translator for Kodi): a
	translation is usually longer than the English it comes from (Spanish
	and Romanian ~20%). A single line now longer than LINE_MAX is split in
	two at the space nearest its middle, and a line that cannot be read at
	READ_CPS in the time it is on screen stays longer, never into the next
	line and never more than READ_MAX_MS. Starts never move: the sync is
	untouched. (wrapped, longer)."""
	wrapped = longer = 0
	for i, c in enumerate(cues):
		if c['n'] not in translated:
			continue
		text = c['text']
		if '\n' not in text and len(text) > LINE_MAX and not re.search(r'[<{]', text) and not text.lstrip().startswith('-'):
			mid = len(text) // 2
			spaces = [k for k, ch in enumerate(text) if ch == ' ']
			if spaces:
				k = min(spaces, key=lambda k: abs(k - mid))
				if 0 < k < len(text) - 1:
					c['text'] = text[:k] + '\n' + text[k + 1:]
					wrapped += 1
		try:
			a, rest = c['timing'].split(' --> ', 1)
			b, tail = rest[:12], rest[12:]
			start, end = _ms_of(a), _ms_of(b)
		except Exception:
			continue
		chars = len(re.sub(r'<[^>]*>|\{[^}]*\}|\n', '', c['text']))
		need = max(1000, int(chars * 1000.0 / READ_CPS))
		if end - start >= need:
			continue
		limit = start + min(need, READ_MAX_MS)
		if i + 1 < len(cues):
			try:
				nxt = _ms_of(cues[i + 1]['timing'].split(' --> ', 1)[0])
				if nxt > start:
					limit = min(limit, nxt - 80)
			except Exception:
				pass
		if limit > end:
			c['timing'] = '%s --> %s%s' % (a, _stamp_ms(limit), tail)
			longer += 1
	return wrapped, longer


def _norm_line(t):
	return re.sub(r'\s+', ' ', re.sub(r'<[^>]*>|\{[^}]*\}', '', t or '')).strip().lower()


def dedupe_srt(text):
	"""v2.0.27. MEASURED (screenshot 5-nov-2026, Alchemy of Souls 2x08 in
	Romanian): the same two lines of a song were on screen twice, one block
	above the other. Some subtitles carry a line twice at the same time (the
	lyrics once as dialogue and once as a sign, or inside one cue), and a
	translation makes the two copies identical. A cue that repeats itself
	keeps one copy, and a cue with the same text as one still on screen is
	merged into it. Lines merely said twice in a row are left alone: they
	do not overlap. (text, merged)."""
	cues = parse_srt(text)
	if not cues:
		return text, 0
	merged, out, alive = 0, [], {}
	for c in cues:
		lines = c['text'].split('\n')
		half = len(lines) // 2
		if len(lines) >= 2 and len(lines) % 2 == 0 and \
				[_norm_line(x) for x in lines[:half]] == [_norm_line(x) for x in lines[half:]] and _norm_line(lines[0]):
			c['text'] = '\n'.join(lines[:half])
			merged += 1
		try:
			a, rest = c['timing'].split(' --> ', 1)
			start, end = _ms_of(a), _ms_of(rest[:12])
		except Exception:
			out.append(c)
			continue
		key = _norm_line(c['text'].replace('\n', ' '))
		prev = alive.get(key)
		if key and prev is not None and start <= prev['end'] + 100:
			if end > prev['end']:
				p_a, p_rest = prev['cue']['timing'].split(' --> ', 1)
				prev['cue']['timing'] = '%s --> %s%s' % (p_a, _stamp_ms(end), p_rest[12:])
				prev['end'] = end
			merged += 1
			continue
		alive[key] = {'cue': c, 'end': end}
		out.append(c)
	if not merged:
		return text, 0
	return build_srt(out), merged


def build_srt(cues):
	out = []
	for k, c in enumerate(cues, start=1):
		out.append('%d\n%s\n%s\n' % (k, c['timing'], c['text']))
	return '\n'.join(out)


def _needs_translation(text):
	"""False for empty lines, music notes, numbers or tags only."""
	plain = re.sub(r'<[^>]*>|\{[^}]*\}', '', text or '')
	return bool(re.search(r'[^\W\d_]', plain, re.UNICODE))


def _chunk(cues):
	chunks, cur, size = [], [], 0
	for c in cues:
		ln = len(c['text'])
		if cur and (len(cur) >= CHUNK_CUES or size + ln > CHUNK_CHARS):
			chunks.append(cur)
			cur, size = [], 0
		cur.append(c)
		size += ln
	if cur: chunks.append(cur)
	return chunks


# ──────────────────────────────────────────────────────────────────────
# One block
# ──────────────────────────────────────────────────────────────────────

UNREADABLE = 'Empty or unreadable subtitle'
NOTHING = 'Nothing to translate'
MAX_DEPTH = 4          # re-asks of the same lines before giving up on them


def _keep(ctx, out, missing, err, why):
	"""Lines Gemini never sent back stay in the original language, as long as
	they are few: at most 1% of the film (3 lines at least). More than that
	is a failure: never a half-translated file."""
	with _lock:
		if ctx['kept'] + len(missing) > ctx['kept_max']:
			return None, err
		ctx['kept'] += len(missing)
	_log('%d line(s) %s: kept in the original language (%s)' % (len(missing), why, ' / '.join(
		'#%d "%s"' % (c['n'], c['text'].replace('\n', ' ')[:60]) for c in missing[:3])), level=xbmc.LOGWARNING)
	out = dict(out)
	out.update((c['n'], c['text']) for c in missing)
	return out, None


def _translate_block(block, by_index, ctx, deadline, depth=0, echo_ok=False):
	"""{cue n: translated text} for every cue of the block, or (None, reason).

	v2.0.27. MEASURED (kodi.log 4-nov-2026, "The American Dream", 1427 lines):
	Gemini sent blocks back with some rows missing (1 of 50, 40 of 50...), the
	block was split, split again, and when 11 of 13 rows were still missing
	the whole film was thrown away. Now every row that came back is kept and
	only the missing ones are asked again (split in two when nothing at all
	came back); see _keep for the few that never come."""
	out, missing, err = _ask_block(block, by_index, ctx, deadline, echo_ok)
	if not missing:
		return out, None
	if not _is_content_error(err) or time.time() >= deadline:
		return None, err                   # quota, keys, network, time: not fixed by re-asking
	blocked = 'blocked:' in (err or '')
	# v2.0.27: PROHIBITED_CONTENT, a filter BLOCK_NONE does not turn off. A
	# blocked block is split down to 3 lines; what Google still refuses stays
	# in the original language (a refused scene, not a lost film).
	if blocked and len(missing) <= 3:
		_log('Google refuses %d line(s) (%s): kept in the original language' % (len(missing), err), level=xbmc.LOGWARNING)
		out.update((c['n'], c['text']) for c in missing)
		return out, None
	if depth >= MAX_DEPTH:
		return _keep(ctx, out, missing, err, 'never came back from Gemini')
	if out:
		_log('Block of %d lines: %d came back, asking again for the %d missing' % (len(block), len(out), len(missing)))
		parts = [missing]
	else:
		_log('Block of %d line%s failed (%s) - asking again%s' % (len(block), '' if len(block) == 1 else 's', err,
			' in two halves' if len(missing) > 1 else ''))
		half = max(1, len(missing) // 2)
		parts = [missing[:half], missing[half:]] if len(missing) > 1 else [missing]
	partial = echo_ok or bool(out)
	for part in parts:
		# Lines left out of an answer that translated the rest: asked again on
		# their own, one sent back unchanged is a name, not a lazy answer.
		res, err2 = _translate_block(part, by_index, ctx, deadline, depth + 1, partial)
		if res is None:
			if not _is_content_error(err2):
				return None, err2
			res, err2 = _keep(ctx, {}, part, err2, 'never came back from Gemini')
			if res is None:
				return None, err2
		out.update(res)
	return out, None


def _is_content_error(err):
	"""The answer arrived but was unusable (cut short, ids missing, not
	translated). Quota, key and network errors are not fixed by splitting."""
	return (err or '').startswith('BAD_ANSWER')


def _row(text):
	return (text or '').replace('\r', '').replace('\n', BR)


def _ask_block(block, by_index, ctx, deadline, echo_ok=False):
	first = block[0]['n']
	before = [by_index[n] for n in range(first - CONTEXT_CUES, first) if n in by_index]
	context = ''
	if before:
		context = '\nThe lines just before (context only, do NOT return them):\n%s\n' % '\n'.join(
			_row(c['text']) for c in before)
	lines = '\n'.join('%d|%s' % (c['n'], _row(c['text'])) for c in block)
	text = prompt_template % dict(ctx, context=context, lines=lines, br=BR)

	rows, err = _request(text, deadline)
	if rows is None:
		return {}, list(block), err
	return _check_answer(rows, block, echo_ok)


_ROW = re.compile(r'^\s*(\d+)\s*[|:]\s?(.*)$')


def parse_rows(text):
	"""{id: text} from an answer made of "id|text" rows. Tolerates code fences,
	blank lines and a stray heading; '<br>' goes back to a line break."""
	got = {}
	for line in (text or '').replace('\r', '').split('\n'):
		m = _ROW.match(line)
		if not m: continue
		t = m.group(2).strip()
		t = re.sub(r'\s*<br\s*/?>\s*', '\n', t, flags=re.I)
		got.setdefault(int(m.group(1)), t)
	return got


def _check_answer(got, block, echo_ok=False):
	"""(good rows {n: text}, cues still to translate, reason or None)."""
	rows = dict((c['n'], got[c['n']]) for c in block if got.get(c['n']))
	if len(rows) >= 4:
		same = sum(1 for n, t in rows.items() if _norm(t) == _norm(next(c['text'] for c in block if c['n'] == n)))
		if same > len(rows) * 0.5:
			return {}, list(block), 'BAD_ANSWER: %d of %d lines came back untranslated' % (same, len(rows))
	out, missing = {}, []
	for c in block:
		t = rows.get(c['n'])
		# A runaway line (the model rambling inside it) is not a subtitle, and
		# a sentence sent back as it was is not a translation (a name or a
		# one-word shout may legitimately stay the same).
		# v2.0.27. MEASURED (kodi.log 5-nov-2026, Columbo 10x12): "Bono? Bullock?
		# Bochco?", "HB, Hollywood Boulevard." came back unchanged, were asked
		# again on their own, came back unchanged again and cost three requests
		# each. Asked again on its own (1-2 lines) after the rest of its block
		# was translated, an unchanged line is the answer (echo_ok).
		if (not t or len(t) > 3 * len(c['text']) + 60
				or (_norm(t) == _norm(c['text']) and len(c['text'].split()) >= 3 and not (echo_ok and len(block) <= 2))):
			missing.append(c)
		else:
			out[c['n']] = t
	if missing:
		return out, missing, 'BAD_ANSWER: %d of %d lines missing' % (len(missing), len(block))
	return out, [], None


def _norm(s):
	return re.sub(r'\W+', '', (s or '').lower(), flags=re.UNICODE)


# ──────────────────────────────────────────────────────────────────────
# HTTP: thread-safe twin of gemini_api._call_gemini
# ──────────────────────────────────────────────────────────────────────

def _payload(text, model, profile):
	payload = {'contents': [{'role': 'user', 'parts': [{'text': text}]}]}
	if profile >= 2:
		return payload
	payload['safetySettings'] = safety_settings
	gc = {}
	if model in gapi._sampling_models:
		gc['temperature'] = 0.3
	if profile == 0 and gapi._sends_thinking(model):
		gc['thinkingConfig'] = {'thinkingLevel': gapi._thinking_levels[model]}
	if gc:
		payload['generationConfig'] = gc
	if profile == 0:
		payload['systemInstruction'] = {'parts': [{'text': system_instruction}]}
	return payload


def _request(text, deadline):
	"""({id: text}, None) or (None, reason). Keys IN ORDER (Lucian, 4-nov-2026):
	every block goes to key 1 while it has quota, to key 2 once key 1 answers
	429, and so on; the whole chain of keys is walked before the next model.
	A key that answered 429 rests (see _cool) so the following blocks go
	straight to the next one instead of paying the failed round trip again.
	An answer with no text (blocked, or cut before the first row) is asked of
	the next model, EMPTY_MODELS at most."""
	global _profile_floor
	try:
		import requests
	except Exception as e:
		return None, 'requests import failed: %s' % e
	primary = gapi.gemini_model()
	chain = [primary] + [m for m in gapi.fallback_models if m != primary]
	chain = [m for m in chain if m not in gapi._unavailable_models] or chain
	chain = [m for m in chain if not _busy_model(m)] or chain
	last = 'Unknown error'
	empty = 0
	for model in chain:
		if empty >= EMPTY_MODELS:
			break
		keys = gapi._usable_keys()
		if not keys:
			return None, gapi._last_key_error or 'HTTP 401 (UNAUTHENTICATED): API_KEY_INVALID'
		order = [k for k in keys if not _resting(k, model)]
		if not order:
			last = 'HTTP 429 (RESOURCE_EXHAUSTED): every key is resting for %s' % model
			continue
		url = '%s/models/%s:generateContent' % (gapi.base_url, model)
		not_found = 0
		overloaded = False
		for key in order:
			profile = _profile_floor
			while profile <= 2:
				if time.time() >= deadline:
					return None, last if last != 'Unknown error' else 'BUDGET_EXHAUSTED'
				try:
					r = requests.post(url, headers={'x-goog-api-key': key, 'Content-Type': 'application/json'},
						data=json.dumps(_payload(text, model, profile)), timeout=min(REQUEST_TIMEOUT, max(5, deadline - time.time())))
				except requests.exceptions.Timeout as e:
					# v2.0.27. MEASURED (kodi.log 5-nov-2026, My Mister 1x07: 885
					# lines in 92.6 s): after Flash-Lite's 503 the next model went
					# silent and each key waited the whole timeout on it, with
					# nothing in the log. A model that does not answer in time is
					# treated like an overloaded one: it rests, the next one goes.
					last = 'Timeout: %s' % e
					with _lock:
						fresh = not _busy_model(model)
						_busy[model] = time.time() + BUSY_SECS
					if fresh:
						_log('%s did not answer in %d s: the next model takes over for %d s' % (model, REQUEST_TIMEOUT, BUSY_SECS), level=xbmc.LOGWARNING)
					overloaded = True
					break
				except Exception as e:
					last = '%s: %s' % (type(e).__name__, e)
					break
				if r.status_code == 200:
					try:
						body = r.json()
					except Exception:
						return None, 'BAD_ANSWER: response was not JSON'
					rows = parse_rows(gapi._extract_text(body))
					if rows:
						return rows, None
					why = _why_empty(body)
					last = 'BAD_ANSWER: no text (%s)' % why
					if why.startswith('blocked'):
						# A blocked prompt is Google's policy, not one model's: every
						# model answered the same in the log of 4-nov-2026.
						return None, last
					_log('%s from %s - trying the next model' % (last, model), level=xbmc.LOGWARNING)
					empty += 1
					break
				err = gapi._error_details(r)
				last = 'HTTP %d (%s): %s' % (err['status_code'], err['status'], err['message'])
				# v2.0.27. MEASURED (kodi.log 5-nov-2026, Baywatch 6x07: 565 lines in
				# 208 s instead of ~15): Flash-Lite answered 503 "high demand" again
				# and again and every key was tried on it. Overload is the model's,
				# not the key's: that model rests for everyone and the next one
				# in the chain takes the blocks.
				if err['status_code'] in (500, 503) or err['status'] in ('UNAVAILABLE', 'INTERNAL'):
					with _lock:
						fresh = not _busy_model(model)
						_busy[model] = time.time() + BUSY_SECS
					if fresh:
						_log('%s is overloaded (HTTP %d): the next model takes over for %d s' % (model, err['status_code'], BUSY_SECS), level=xbmc.LOGWARNING)
					overloaded = True
					break
				if err['status_code'] == 429 or err['status'] == 'RESOURCE_EXHAUSTED':
					_cool(key, model, r)
				_log('Gemini error (model %s, profile %d): %s' % (model, profile, last[:160]), level=xbmc.LOGWARNING)
				if gapi._is_shape_rejection(err) and gapi._sends_thinking(model):
					gapi._thinking_rejected.add(model)
					continue
				if gapi._is_shape_rejection(err) and profile < 2:
					profile += 1
					with _lock: _profile_floor = max(_profile_floor, profile)
					continue
				if gapi._is_bad_key(last):
					gapi._rejected_keys.add(key)
					gapi._last_key_error = last
					break
				if err['status_code'] == 404 or err['status'] == 'NOT_FOUND':
					not_found += 1
				if not gapi._should_try_next_key(err) and err['status_code'] != 400:
					return None, last
				break
			if last.startswith('BAD_ANSWER') or overloaded:
				break   # next model, not next key: the same model gives the same answer
		if order and not_found == len(order):
			gapi._unavailable_models.add(model)
	return None, last


# (key, model) -> time until which that key is not asked for that model. Quota
# is per project AND per model, so a key spent on Flash-Lite still serves the
# next model in the chain.
_rest = {}
# model -> time until which it is not asked (overloaded: HTTP 503 / 500)
_busy = {}
BUSY_SECS = 120


def _busy_model(model):
	return _busy.get(model, 0) > time.time()


def _resting(key, model):
	return _rest.get((key, model), 0) > time.time()


def _cool(key, model, response):
	"""How long a key rests after a 429: until the daily reset when the quota
	that ran out is a daily one, the seconds Google asks for when it says
	"retry in Ns", one minute otherwise (requests-per-minute)."""
	try: raw = response.text or ''
	except Exception: raw = ''
	now = time.time()
	if re.search(r'PerDay|per day|daily', raw, re.I):
		# The free quota resets at midnight Pacific time: 08:00 UTC (07:00 in
		# summer; an hour of rest too many is harmless).
		reset = (int(now // 86400) * 86400) + 8 * 3600
		until = reset if reset > now else reset + 86400
		why = 'daily quota'
	else:
		m = re.search(r'retry in ([\d.]+)\s*s', raw, re.I)
		until = now + (min(float(m.group(1)), 300) if m else 60)
		why = 'per-minute quota'
	with _lock:
		_rest[(key, model)] = until
	idx = gapi.gemini_api_keys().index(key) + 1 if key in gapi.gemini_api_keys() else 0
	_log('Key #%d out of %s for %s - next key' % (idx, why, model), level=xbmc.LOGWARNING)


def _why_empty(body):
	"""promptFeedback.blockReason or the candidate's finishReason, for the log."""
	try:
		block = (body.get('promptFeedback') or {}).get('blockReason')
		if block: return 'blocked: %s' % block
		return (body.get('candidates') or [{}])[0].get('finishReason') or 'no candidates'
	except Exception:
		return 'unknown'


def _prune():
	try:
		files = [os.path.join(cache_dir, n) for n in os.listdir(cache_dir) if n.endswith('.srt')]
		files.sort(key=lambda p: os.path.getmtime(p), reverse=True)
		for p in files[CACHE_KEEP:]:
			try: os.remove(p)
			except Exception: pass
	except Exception:
		pass


def _log(message, level=xbmc.LOGINFO):
	try: xbmc.log('%s %s' % (LOG_TAG, message), level)
	except Exception: pass
