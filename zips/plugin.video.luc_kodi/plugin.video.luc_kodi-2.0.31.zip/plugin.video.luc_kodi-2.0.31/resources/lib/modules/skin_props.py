# -*- coding: utf-8 -*-
"""
	luc_kodi Add-on — modules/skin_props.py (v2.0.28)

	Lo que luc_kodi le cuenta al skin.

	Un skin que pinta widgets en su Home solo ve lo que Kodi sabe de cada item:
	titulo, arte, la nota de TMDb. Todo lo demas que el plugin ya tiene en la
	mano se queda dentro. Este modulo lo publica como propiedades con el
	prefijo luc_kodi., para que cualquier skin pueda mostrarlo sin preguntar
	nada al plugin:

	  en cada item    ListItem.Property(luc_kodi.ratings) y compania
	  en la Home      Window(Home).Property(luc_kodi.accounts) y compania

	Dos reglas que no se rompen:

	  1. Ni una peticion de red al pintar una lista. Las notas salen de la
	     misma cascada de ratings.py con live=False: lo que ya esta en cache.
	     Un titulo que nunca se abrio puede salir solo con la de TMDb; la
	     siguiente vez saldra completo. Es lo mismo que hace el reproductor.
	  2. Una sola consulta a la base por pagina. La cascada abre la cache
	     hasta tres veces por titulo (MDBList, Trakt, OMDB); con 20 titulos
	     eran 60 conexiones por widget. Aqui se recorre la cascada una vez
	     anotando que claves pediria, se leen todas juntas y se vuelve a
	     recorrer con lo leido. La cascada es la de ratings.py, no una copia.

	Las propiedades de la Home las escribe el servicio (HomeProps), nunca un
	listado: asi un widget no espera a nadie.
"""

import threading
from ast import literal_eval
from datetime import date

from resources.lib.modules import control
from resources.lib.modules import log_utils

PREFIX = 'luc_kodi.'
_CHUNK = 400            # claves por consulta (SQLite admite 999 parametros)
_HOME_EVERY = 60        # segundos entre dos repasos de la Home
_HOME_FIRST = 10        # primera pasada, solo con lo que no necesita red
_HOME_NETWORK = 60      # a partir de aqui ya se puede preguntar a los debrid

# Lo que publica la Home. Se borra lo que deja de tener valor, nunca otra cosa.
HOME_KEYS = ('ready', 'version', 'accounts', 'accounts.count', 'tracking', 'debrid',
		'trakt.user', 'debrid.days', 'warning', 'warnings.count', 'update',
		'catalog', 'catalog.count')

_wake = threading.Event()


# ───────────────────────── notas de una pagina ─────────────────────────
def _read_many(keys):
	"""{clave: valor} de la cache del addon, en una sola conexion."""
	out = {}
	if not keys: return out
	dbcon = dbcur = None
	try:
		from resources.lib.database import cache
		dbcon = cache.get_connection()
		dbcur = dbcon.cursor()
		if not dbcur.execute('''SELECT name FROM sqlite_master WHERE type='table' AND name='cache' ''').fetchone():
			return out
		for n in range(0, len(keys), _CHUNK):
			part = keys[n:n + _CHUNK]
			rows = dbcur.execute('SELECT key, value FROM cache WHERE key IN (%s)' % ','.join('?' * len(part)), part).fetchall()
			for row in rows:
				try: out[row['key']] = literal_eval(row['value'])
				except Exception: pass
	except Exception:
		log_utils.error()
	finally:
		for obj in (dbcur, dbcon):
			try: obj.close()
			except Exception: pass
	return out


def _meta(i, mediatype):
	return {'imdb': i.get('imdb', ''), 'rating': i.get('rating', ''), 'mediatype': mediatype,
	        'season': i.get('season', ''), 'episode': i.get('episode', '')}


class PageRatings:
	"""Las notas de toda una pagina, leidas de la cache de una vez.

	Se construye antes del bucle del listado con los items crudos y se le pide
	cada uno dentro del bucle. Si algo falla, cada titulo se queda con la nota
	de TMDb que ya traia: nunca tumba el listado."""

	def __init__(self, items, mediatype):
		self.mediatype = mediatype
		self._values = {}
		try:
			from resources.lib.modules import ratings
			from resources.lib.database import cache
			wanted = {}

			def record(function, *args):
				wanted[cache._hash_function(function, args)] = None
				return None
			for i in items or []:
				if i.get('imdb'): ratings.fetch(_meta(i, mediatype), live=False, lookup=record)
			self._values = _read_many(list(wanted))
		except Exception:
			log_utils.error()

	def get(self, i):
		try:
			from resources.lib.modules import ratings
			from resources.lib.database import cache

			def lookup(function, *args):
				return self._values.get(cache._hash_function(function, args))
			return ratings.fetch(_meta(i, self.mediatype), live=False, lookup=lookup)
		except Exception:
			log_utils.error()
			return {}


def rating_values(r):
	"""Una propiedad por casa y una linea ya compuesta para el skin que quiera
	una sola etiqueta. El hueco de IMDb puede venir de Metacritic cuando IMDb
	no tiene nota: entonces no se publica como IMDb."""
	r = r or {}
	imdb = r.get('imdb', '') if r.get('imdb_source', 'imdb') == 'imdb' else ''
	mc = r.get('metacritic', '') or (r.get('imdb', '') if r.get('imdb_source') == 'metacritic' else '')
	v = {'rating.tmdb': r.get('tmdb', ''), 'rating.imdb': imdb, 'rating.rt': r.get('rt', ''),
	     'rating.metacritic': mc, 'rating.trakt': r.get('trakt', '')}
	line = []
	if imdb: line.append('IMDb %s' % imdb)
	if v['rating.rt']: line.append('RT %s' % v['rating.rt'])
	if mc: line.append('MC %s' % mc)
	if not imdb and v['rating.trakt']: line.append('Trakt %s' % v['rating.trakt'])
	if not line and v['rating.tmdb']: line.append('TMDb %s' % v['rating.tmdb'])
	v['ratings'] = ' · '.join(line)
	return v


def premiere_values(premiered, unaired=None):
	"""luc_kodi.unaired / .premiere (AAAA-MM-DD) / .premiere.label ('Nov 14')
	para lo que aun no ha salido."""
	try:
		# v2.0.28: sin strptime, que puede fallar en un hilo del Python de Kodi
		y, m, d = (int(x) for x in str(premiered)[:10].split('-'))
		day = date(y, m, d)
	except Exception:
		return {}
	if unaired is None: unaired = day > date.today()
	if not unaired: return {}
	label = '%s %d' % (day.strftime('%b'), day.day)
	if day.year != date.today().year: label = '%s %d' % (label, day.year)
	return {'unaired': 'true', 'premiere': day.isoformat(), 'premiere.label': label}


def item_values(ratings=None, premiered=None, unaired=None, episodes_left=None):
	v = rating_values(ratings)
	v.update(premiere_values(premiered, unaired))
	if episodes_left is not None: v['episodes_left'] = str(episodes_left)
	return v


def _num(value, scale=1.0):
	try: return round(float(str(value).replace('%', '').strip()) * scale, 1)
	except (TypeError, ValueError): return None


def kodi_ratings(r):
	"""v2.0.28: las notas en el formato estandar de Kodi, para skins que no
	conocen luc_kodi y leen ListItem.Rating(imdb), (trakt), (tomatometerallcritics)
	o (metacritic) (Estuary MOD V2, Aeon Nox). Escala de Kodi, 0 a 10: RT 94% es
	9.4 y Metacritic 78 es 7.8, que es como lo comparan esos skins. La de TMDb la
	pone infoTagger con sus votos y sigue siendo la principal."""
	r = r or {}
	out = {}
	if r.get('imdb') and r.get('imdb_source', 'imdb') == 'imdb':
		if (v := _num(r['imdb'])) is not None: out['imdb'] = (v, 0)
	if r.get('trakt') and (v := _num(r['trakt'])) is not None: out['trakt'] = (v, 0)
	if r.get('rt') and (v := _num(r['rt'], 0.1)) is not None: out['tomatometerallcritics'] = (v, 0)
	mc = r.get('metacritic') or (r.get('imdb') if r.get('imdb_source') == 'metacritic' else '')
	if mc and (v := _num(mc, 0.1)) is not None: out['metacritic'] = (v, 0)
	return out


def plain_rating_props(r):
	"""rating.imdb / rating.rotten / rating.metacritic sin prefijo: los nombres que
	ya lee Estuary MOD V2 (sobre 100 los dos ultimos)."""
	r = r or {}
	out = {}
	if r.get('imdb') and r.get('imdb_source', 'imdb') == 'imdb': out['rating.imdb'] = str(r['imdb'])
	if r.get('rt'): out['rating.rotten'] = str(r['rt']).replace('%', '')
	mc = r.get('metacritic') or (r.get('imdb') if r.get('imdb_source') == 'metacritic' else '')
	if mc: out['rating.metacritic'] = str(mc)
	return out


def decorate(item, meta, ratings=None, premiered=None, unaired=None, episodes_left=None):
	"""Todo lo que el skin puede leer de un item, de una vez. Se llama justo
	antes de infoTagger, cuando la URL del item ya esta hecha: meta['luc_ratings']
	no viaja en ella, solo lo lee infoTagger para las notas estandar."""
	apply(item, item_values(ratings, premiered=premiered, unaired=unaired, episodes_left=episodes_left))
	plain = plain_rating_props(ratings)
	if plain:
		try: item.setProperties(plain)
		except Exception:
			for k, v in plain.items():
				try: item.setProperty(k, v)
				except Exception: pass
	if ratings and isinstance(meta, dict): meta['luc_ratings'] = ratings


def apply(item, values):
	"""Escribe en el ListItem las que tienen valor."""
	props = dict((PREFIX + k, str(v)) for k, v in (values or {}).items() if v not in (None, ''))
	if not props: return
	try:
		item.setProperties(props)
	except Exception:
		for k, v in props.items():
			try: item.setProperty(k, v)
			except Exception: pass


# ───────────────────────── la Home ─────────────────────────
def _home_set(name, value):
	prop = PREFIX + name
	value = '' if value is None else str(value)
	try:
		if control.homeWindow.getProperty(prop) == value: return
		if value: control.homeWindow.setProperty(prop, value)
		else: control.homeWindow.clearProperty(prop)
	except Exception:
		pass


def home_values(network=True):
	"""Lo que la Home publica. Con network=False solo se usa lo que ya hay
	(cuentas configuradas, dias de debrid que alguien ya pidio, estado del
	precache): es la primera pasada, al arrancar."""
	from resources.lib.modules import system_status as ss
	v = dict((k, '') for k in HOME_KEYS)
	v['ready'] = 'true'
	try: v['version'] = control.getluc_kodiVersion()
	except Exception: pass
	days, accts = {}, []
	try: # cada bloque por su cuenta: un fallo aqui no deja la Home sin el resto
		if network:
			days = ss.debrid_days()
		else:
			cached = ss._read_cache(ss.PROP_DEBRID, ss.CACHE_TTL) or {}
			days = cached.get('days') or {}
		accts = ss.accounts(days)
	except Exception:
		log_utils.error()
	tracker_keys = set(t[0] for t in ss.TRACKERS)
	debrid_keys = set(d[0] for d in ss.DEBRIDS) | set(['easynews'])
	tracking = [a['name'] for a in accts if a['key'] in tracker_keys]
	debrid = [a['name'] for a in accts if a['key'] in debrid_keys]
	v['accounts'] = ', '.join(tracking + debrid)
	v['accounts.count'] = str(len(accts)) if accts else ''
	v['tracking'] = ', '.join(tracking)
	v['debrid'] = ', '.join(debrid)
	if any(a['key'] == 'trakt' for a in accts):
		v['trakt.user'] = (control.setting('trakt.username') or '').strip()
	active_days = [days[a['key']] for a in accts if a['key'] in days]
	if active_days: v['debrid.days'] = str(min(active_days))
	for key, name, logo in ss.DEBRIDS:
		v['debrid.%s.days' % key] = str(days[key]) if key in days else ''
	try: warns = ss.warnings(accts)
	except Exception: warns = []
	v['warning'] = warns[0] if warns else ''
	problems = len([a for a in accts if a['message']])
	v['warnings.count'] = str(problems) if problems else ''
	try:
		if network and control.setting('updater.enabled') == 'true':
			v['update'] = ss.update_label()
		elif not network:
			cached = ss._read_cache(ss.PROP_UPDATE, ss.CACHE_TTL) or {}
			v['update'] = cached.get('label') or ''
	except Exception:
		log_utils.error()
	try:
		from resources.lib.modules import catalog_updater as cu
		data = cu.read_status()
		ready = sum(int((data.get(k) or {}).get('ok') or 0) for k in ('fast', 'slow'))
		total = sum(int((data.get(k) or {}).get('total') or 0) for k in ('fast', 'slow'))
		if cu.is_running(): v['catalog'] = 'updating'
		elif control.setting('catalog.auto_update.enabled') != 'true' and not data: v['catalog'] = 'off'
		elif total and ready >= total: v['catalog'] = 'ready'
		elif total: v['catalog'] = 'partial'
		if total: v['catalog.count'] = '%d/%d' % (ready, total)
	except Exception:
		log_utils.error()
	return v


def publish_home(network=True):
	try:
		for k, val in home_values(network).items():
			_home_set(k, val)
	except Exception:
		log_utils.error()


def wake():
	"""Repasar la Home ya (p. ej. al cambiar los ajustes)."""
	_wake.set()


def service_loop():
	"""Bucle del servicio. Arranca sin red, a los 60 s ya pregunta a los debrid
	(con su cache de 6 h, la de System status) y repasa cada minuto. Solo
	reescribe una propiedad cuando cambia, para no repintar el skin en balde."""
	monitor = control.monitor
	if monitor.waitForAbort(_HOME_FIRST): return
	publish_home(network=False)
	waited, since = _HOME_FIRST, _HOME_EVERY # la primera pasada con red sale en cuanto se puede
	while not monitor.abortRequested():
		if monitor.waitForAbort(5): return
		waited += 5
		since += 5
		if waited < _HOME_NETWORK: continue
		if since >= _HOME_EVERY or _wake.is_set():
			first = not getattr(service_loop, '_rows_checked', False)
			_wake.clear()
			since = 0
			publish_home(network=True)
			# v2.0.28: las filas de la Home que se sirvieron con mas de 3 h se
			# vuelven a montar aqui, en segundo plano (y una vez al arrancar).
			try:
				from resources.lib.modules import home_widgets
				if first or control.homeWindow.getProperty(home_widgets.REFRESH_PROP) == 'true':
					service_loop._rows_checked = True
					home_widgets.refresh_rows()
			except Exception:
				log_utils.error()
