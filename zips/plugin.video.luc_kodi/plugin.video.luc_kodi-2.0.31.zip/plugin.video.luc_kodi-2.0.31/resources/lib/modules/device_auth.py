# -*- coding: utf-8 -*-
"""
	luc_kodi Add-on
	device_auth.py (v2.0.15) - one sign-in window for every service that links
	an account with a code.

	Before, each service put a small QR in a notification at the top of the
	screen (made by api.qrserver.com) and the address and code in a separate
	progress dialog. Now one window shows it all: a large QR made on the device
	(modules/qr_local.py), the address, the code in large type and the time left.

	start() returns an object with the same calls the services already made on
	control.progressDialog (update, iscanceled, close), so every sign-in loop
	keeps its own polling and only swaps the dialog it talks to. If the window
	cannot be opened, the classic notification + progress dialog is used, so a
	sign-in never fails because of the window.
"""

from resources.lib.modules import control
from resources.lib.modules import log_utils

# service key -> (name, logo in the skin's media folder)
SERVICES = {
	'trakt': ('Trakt', 'ctx/logo_trakt.png'),
	'simkl': ('SIMKL', 'ctx/logo_simkl.png'),
	'mdblist': ('MDBList', 'ctx/logo_mdblist.png'),
	'punchplay': ('PunchPlay', 'ctx/logo_punchplay.png'),
	'wetrakr': ('WeTrakr', 'ctx/logo_wetrakr.png'),
	'realdebrid': ('Real-Debrid', 'ctx/logo_realdebrid.png'),
	'premiumize': ('Premiumize', 'ctx/logo_premiumize.png'),
	'alldebrid': ('AllDebrid', 'ctx/logo_alldebrid.png'),
	'torbox': ('TorBox', 'ctx/logo_torbox.png'),
	'offcloud': ('Offcloud', 'ctx/logo_offcloud.png'), # v2.0.20
	'tvmaze': ('TVmaze', 'ctx/logo_tvmaze.png'), # v2.0.16
}


def short_url(url):
	"""Address as it is typed: no scheme and no trailing slash."""
	url = str(url or '')
	for scheme in ('https://', 'http://'):
		if url.startswith(scheme): url = url[len(scheme):]
	return url.rstrip('/')


class _Window(object):
	"""The sign-in window, driven like a progress dialog."""
	def __init__(self, window):
		self._w = window

	def create(self, *args, **kwargs): pass # already on screen

	def update(self, *args, **kwargs): pass # the window keeps its own countdown

	def set_status(self, text): self._w.set_status(text)

	def iscanceled(self):
		if self._w is None: return True
		try:
			if control.monitor.abortRequested(): return True
		except Exception: pass
		return self._w.canceled

	def close(self):
		w, self._w = self._w, None
		if w is None: return
		try:
			w.close()
			# the window lives in its own thread: wait for doModal() to return,
			# and close again if it opened just after the first close()
			t = getattr(w, 'thread', None)
			if t is not None:
				t.join(1.5)
				if t.is_alive():
					w.close()
					t.join(1.5)
			w.clear()
		except Exception: pass
		del w
		from resources.lib.modules import qr_local
		qr_local.clear()


class _Classic(object):
	"""What every service did before: QR in a notification + progress dialog."""
	def __init__(self, name, url, code, qr):
		try:
			if qr: control.notification(title=name, message='%s  |  %s' % (short_url(url), code) if code else short_url(url), icon=qr, time=15000)
		except Exception: pass
		hc = control.getHighlightColor()
		lines = [control.lang(32513) % (hc, short_url(url))]
		if code: lines.append(control.lang(32514) % (hc, code))
		self._p = control.progressDialog
		self._p.create(control.lang(401060) % name)
		self._p.update(100, '\n'.join(lines))

	def create(self, *args, **kwargs): pass

	def update(self, percent=None, *args, **kwargs):
		try:
			if percent is not None and percent >= 0: self._p.update(int(percent))
		except Exception: pass

	def set_status(self, text): pass

	def iscanceled(self):
		try: return self._p.iscanceled()
		except Exception: return False

	def close(self):
		try: self._p.close()
		except Exception: pass
		from resources.lib.modules import qr_local
		qr_local.clear()


def start(service, url, code='', qr_data='', expires_in=0, qr_has_code=False, title='', sub='', hint='', status='', logo=None, keep_scheme=False):
	"""Open the sign-in window for `service` and return its handle.

	url          address the user types (shown without https://)
	code         code to enter there ('' when the address already carries it)
	qr_data      what the QR opens (defaults to url); a link with the code in it
	             saves the user typing anything
	expires_in   seconds the code lasts, for the countdown
	qr_has_code  True when qr_data already carries the code
	title, sub, hint, status, logo   v2.0.25: the setup wizards (a page on the phone
	             instead of a code) say what they need in their own words;
	             keep_scheme shows http:// so a browser does not try https first"""
	name, _logo = SERVICES.get(service, (service.title(), ''))
	logo = _logo if logo is None else logo
	code = str(code or '')
	from resources.lib.modules import qr_local
	qr = qr_local.make(qr_data or url)
	hint = hint or (control.lang(401067) if (qr and qr_has_code and code) else '')
	try:
		from resources.lib.windows.device_auth import DeviceAuthXML
		window = DeviceAuthXML('device_auth.xml', control.addonPath(control.addonId()), data={
			'logo': logo, 'title': title or (control.lang(401060) % name), 'sub': sub, 'status': status,
			'qr': qr, 'url': url if keep_scheme else short_url(url), 'code': code, 'hint': hint, 'expires_in': expires_in})
		window.open()
		control.log('[ luc_kodi ] device_auth: %s sign-in window open (QR %s)' % (name, 'local' if qr else 'none'), log_utils.LOGINFO)
		return _Window(window)
	except Exception:
		log_utils.error('device_auth: window failed, using the classic dialog: ')
	return _Classic(name, url, code, qr)
