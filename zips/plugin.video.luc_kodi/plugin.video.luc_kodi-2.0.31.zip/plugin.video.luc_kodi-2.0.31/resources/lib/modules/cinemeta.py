# -*- coding: utf-8 -*-
"""
	luc_kodi - Cinemeta episode numbering for daily and talk shows (v2.0.31)

	Stremio-style scrapers (Torrentio, Comet, MediaFusion, Meteor, Peerflix,
	Sootio, TorrentsDB, Torz, Zilean, AIOStreams) look episodes up by IMDb id
	plus the season:episode of Cinemeta, Stremio's own catalogue built from
	IMDb. For daily shows that numbering rarely matches TMDb's: The Tonight
	Show Starring Jimmy Fallon is S14E13 on TMDb and S13E1xx on IMDb, so the
	request tt3444938:14:13 found nothing in any of them (kodi.log of
	11-nov-2026). This module finds Cinemeta's season:episode for an air date.
"""

import re
from datetime import date as _date, timedelta

from resources.lib.database import cache
from resources.lib.modules import log_utils

META_URL = 'https://v3-cinemeta.strem.io/meta/series/%s.json'
_TIMEOUT = 8
_WORD = re.compile(r"[a-z0-9']{3,}")
_SKIP = {'the', 'and', 'with', 'from', 'episode', 'show', 'tonight', 'special', 'guest', 'guests'}


def _words(text):
	# numbers never count: Cinemeta names many episodes 'Episode #13.127'
	return set(w for w in _WORD.findall((text or '').lower()) if w not in _SKIP and not w.isdigit())


def series_dates(imdb):
	"""{'YYYY-MM-DD': [[season, episode, name], ...]} from Cinemeta, or {}.
	Cached for 24 h by the caller (cache.get)."""
	try:
		import requests
		r = requests.get(META_URL % imdb, timeout=_TIMEOUT, headers={'User-Agent': 'luc_kodi'})
		if r.status_code != 200: return {}
		videos = ((r.json() or {}).get('meta') or {}).get('videos') or []
		out = {}
		for v in videos:
			try:
				s = int(v.get('season') or 0)
				e = int(v.get('episode') or v.get('number') or 0)
			except (TypeError, ValueError):
				continue
			day = str(v.get('released') or v.get('firstAired') or '')[:10]
			if s < 1 or e < 1 or not re.match(r'\d{4}-\d{2}-\d{2}$', day): continue
			out.setdefault(day, []).append([s, e, str(v.get('name') or v.get('title') or '')[:120]])
		return out
	except Exception:
		log_utils.error('CINEMETA: could not read %s' % imdb)
		return {}


def episode_for(imdb, premiered, title=''):
	"""(season, episode) Cinemeta gives to the episode that aired on
	`premiered`, or None. The same day comes first; the day before or after
	(time zones, late-night shows) only counts when the guest names in its
	title share words with the TMDb title, so a neighbouring day's episode is
	never taken by mistake."""
	try:
		imdb = str(imdb or '')
		day = str(premiered or '')[:10]
		if not imdb.startswith('tt') or not re.match(r'\d{4}-\d{2}-\d{2}$', day): return None
		dates = cache.get(series_dates, 24, imdb)
		if not isinstance(dates, dict) or not dates: return None
		want = _words(title)
		def score(c): return len(want & _words(c[2]))
		same = dates.get(day) or []
		if len(same) == 1 and (not want or not _words(same[0][2]) or score(same[0]) > 0):
			return same[0][0], same[0][1]
		d = _date(*map(int, day.split('-')))
		cands = list(same)
		for delta in (-1, 1):
			cands += dates.get((d + timedelta(days=delta)).isoformat()) or []
		if not want: return (same[0][0], same[0][1]) if len(same) == 1 else None
		best = max(cands, key=score) if cands else None
		if best and score(best) > 0 and sum(1 for c in cands if score(c) == score(best)) == 1:
			return best[0], best[1]
		return None
	except Exception:
		log_utils.error()
		return None
