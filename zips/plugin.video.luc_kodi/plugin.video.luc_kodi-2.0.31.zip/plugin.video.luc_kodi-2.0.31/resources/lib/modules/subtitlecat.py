# -*- coding: utf-8 -*-
"""
	luc_kodi Add-on — subtitlecat.py (v2.0.27)

	SubtitleCat (subtitlecat.com) as a second subtitle provider, next to
	OpenSubtitles. No account and no API key: the site has no API, so this
	reads its HTML pages.

	Based on the SubtitleCat provider of the Bazarr+ provider catalog
	(github.com/LavX/bazarr-provider-catalog, MIT licence): same page layout,
	same search queries and the same way of telling the original file from
	the copies the site translated with Google. Reduced to what luc_kodi needs.

	HOW THE SITE IS BUILT
	  search  /index.php?search=<title year | series SxxEyy>
	          -> links /subs/<n>/<release>.html
	  detail  one page per uploaded subtitle: a download link per language
	          (id="download_<code>", .../<release>-<code>.srt) and, in the
	          translate buttons, the ORIGINAL file '<release>.<Language>-orig.srt'
	          in its folder. Every other language is a Google translation the
	          site cached for an earlier visitor; languages nobody asked for
	          are buttons translated in the browser, not files.

	HOW LUC_KODI USES IT (see player.Subtitles._chain)
	  - the ORIGINAL in your language: used like an OpenSubtitles subtitle;
	  - the original in another language: a source for the Gemini translation;
	  - the site's own machine translation in your language: last resort only
	    (Settings > Subtitles > SubtitleCat machine translations).

	The index is full of unrelated and adult uploads, so a result is only
	taken when it names the title (and the year, or SxxEyy for an episode).
	There is no file hash on SubtitleCat: sync depends on the release name,
	so the one closest to the release being played comes first.
"""

import re
import time
import unicodedata
from difflib import SequenceMatcher
from urllib.parse import quote

import xbmc

BASE_URL = 'https://www.subtitlecat.com'
LOG_TAG = '[luc_kodi-subcat]'
TIMEOUT = 10
SEARCH_BUDGET = 20          # seconds for one whole lookup, detail pages included
MAX_DETAILS = 4             # detail pages read per lookup
UA = ('Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 (KHTML, like Gecko) '
	  'Chrome/130.0 Mobile Safari/537.36')

_DETAIL_LINK_RE = re.compile(rb'<a[^>]+href="(/?subs/(\d+)/([^"]+\.html))"[^>]*>(.*?)</a>', re.I | re.S)
_TAG_RE = re.compile(rb'<[^>]+>')
# v2.0.27: the search page says it next to each upload: "<a ...>Release</a> (translated from English)".
_FROM_RE = re.compile(rb'</a>\s*\(translated from ([A-Za-z][A-Za-z ()]{1,40})\)', re.I)
_ORIG_TEXT_MARK = b'These are the user uploaded subtitles that are being translated:'
_DOWNLOAD_RE = re.compile(rb'<a[^>]+id="download_([a-z]{2,3}(?:-[a-z0-9]{2,4})?)"'
						  rb'[^>]+href="(/?subs/\d+/[^"]+-([a-z]{2,3}(?:-[a-z0-9]{2,4})?)\.srt)"', re.I)
_ORIG_FILE_RE = re.compile(rb"translate_from_server_folder\(\s*'[^']*'\s*,\s*'([^']+-orig\.srt)'\s*,\s*'(/?subs/\d+/?)'")
_ORIG_NAMED_RE = re.compile(r'\.([A-Za-z]+)-orig\.srt$')
_ORIG_CODE_RE = re.compile(r'(?:^|[/_.\-])([a-z]{2,3}(?:-[A-Za-z0-9]{2,4})?)-orig\.srt$')

_ALIASES = {'iw': 'he', 'in': 'id', 'ji': 'yi', 'fil': 'tl', 'alb': 'sq', 'arm': 'hy', 'baq': 'eu', 'bur': 'my',
	'chi': 'zh', 'cze': 'cs', 'dut': 'nl', 'fre': 'fr', 'geo': 'ka', 'ger': 'de', 'gre': 'el', 'ice': 'is',
	'mac': 'mk', 'may': 'ms', 'per': 'fa', 'rum': 'ro', 'slo': 'sk', 'wel': 'cy',
	# ISO 639-2/T, seen as file suffixes ('...DKS.slv', log 4-nov-2026)
	'eng': 'en', 'spa': 'es', 'fra': 'fr', 'deu': 'de', 'ita': 'it', 'por': 'pt', 'ron': 'ro', 'rus': 'ru',
	'tur': 'tr', 'nld': 'nl', 'pol': 'pl', 'hun': 'hu', 'ces': 'cs', 'ell': 'el', 'heb': 'he', 'ara': 'ar',
	'zho': 'zh', 'jpn': 'ja', 'kor': 'ko', 'swe': 'sv', 'dan': 'da', 'fin': 'fi', 'nor': 'no', 'bul': 'bg',
	'hrv': 'hr', 'srp': 'sr', 'ukr': 'uk', 'slv': 'sl', 'slk': 'sk', 'vie': 'vi', 'tha': 'th', 'hin': 'hi'}
_NAMES = {'english': 'en', 'spanish': 'es', 'french': 'fr', 'german': 'de', 'italian': 'it', 'portuguese': 'pt',
	'polish': 'pl', 'russian': 'ru', 'turkish': 'tr', 'arabic': 'ar', 'hindi': 'hi', 'indonesian': 'id',
	'dutch': 'nl', 'chinese': 'zh', 'japanese': 'ja', 'korean': 'ko', 'czech': 'cs', 'greek': 'el',
	'hungarian': 'hu', 'romanian': 'ro', 'bulgarian': 'bg', 'swedish': 'sv', 'danish': 'da', 'norwegian': 'no',
	'finnish': 'fi', 'ukrainian': 'uk', 'slovak': 'sk', 'croatian': 'hr', 'serbian': 'sr', 'slovenian': 'sl',
	'lithuanian': 'lt', 'latvian': 'lv', 'estonian': 'et', 'vietnamese': 'vi', 'thai': 'th', 'malay': 'ms',
	'filipino': 'tl', 'hebrew': 'he', 'persian': 'fa', 'urdu': 'ur', 'bengali': 'bn', 'tamil': 'ta',
	'telugu': 'te', 'malayalam': 'ml', 'georgian': 'ka', 'armenian': 'hy', 'kazakh': 'kk'}

# Subtitle setting of luc_kodi -> SubtitleCat codes, best first.
_SETTING_CODES = {'Spanish': ['es'], 'Spanish (Spain)': ['es'], 'Spanish (Latin America)': ['es-419', 'es'],
	'Portuguese': ['pt-pt', 'pt'], 'Portuguese(Brazil)': ['pt-br', 'pt'],
	'Chinese': ['zh-cn', 'zh', 'zh-tw']}


def base_code(code):
	code = (code or '').lower().replace('_', '-')
	base = code.split('-', 1)[0]
	return _ALIASES.get(base, base)


def setting_codes(setting_value):
	"""SubtitleCat codes for a luc_kodi subtitle setting ('Romanian' -> ['ro'])."""
	value = (setting_value or '').strip()
	if value in _SETTING_CODES:
		return list(_SETTING_CODES[value])
	try:
		code = xbmc.convertLanguage(value, xbmc.ISO_639_1)
	except Exception:
		code = ''
	return [code.lower()] if code else []


# ──────────────────────────────────────────────────────────────────────
# Pages
# ──────────────────────────────────────────────────────────────────────

def _strip(b):
	return re.sub(r'\s+', ' ', _TAG_RE.sub(b' ', b or b'').decode('utf-8', 'replace')).strip()


def _url(path):
	return '%s/%s' % (BASE_URL, quote(path.lstrip('/'), safe='/-_.~()%'))


def lang_name_code(name):
	"""'English' / 'Chinese (Simplified)' / 'Portuguese (Brazil)' -> 'en' / 'zh' / 'pt'."""
	first = (name or '').strip().split(' ')[0].lower()
	return _NAMES.get(first)


def parse_search(html):
	"""[{'id', 'url', 'title', 'from'}] in the site's own order, first of
	each id. 'from' is the language of the original as the search page states
	it ("translated from English"), or None."""
	seen, out = set(), []
	html = html or b''
	for m in _DETAIL_LINK_RE.finditer(html):
		did = m.group(2).decode('ascii', 'replace')
		title = _strip(m.group(4))
		path = m.group(1).decode('ascii', 'replace')
		key = (did, path)
		if not title or key in seen:
			continue
		seen.add(key)
		frm = _FROM_RE.match(html, m.end() - 4) or _FROM_RE.search(html[m.end() - 4:m.end() + 120])
		out.append({'id': did, 'url': _url(path), 'title': title,
					'from': lang_name_code(frm.group(1).decode('ascii', 'replace')) if frm else None})
	return out


# v2.0.27: language of the original from its own text, when neither the file
# name nor the search page says it. A handful of very common short words per
# language is enough for a whole subtitle; a doubtful result is not used.
_STOP = {
	'en': 'the you and that what this have not are with for was just know your don get',
	'es': 'que los las por una con para del pero esta como eso est todo bien porque',
	'ro': 'si nu este sunt pentru ce mai care asta din cum unde acum bine trebuie',
	'fr': 'les des est pas une que vous pour dans qui sur mais avec tout cette',
	'it': 'che non per sono una della questo come cosa sei gli anche bene tutto',
	'de': 'und ich nicht die das ist sie der was mit ein auf sich wir habe',
	'pt': 'que nao uma voce com para isso esta mas por como bem tudo ele aqui',
	'tr': 've bir bu ne ben sen icin cok ama var mi degil gibi daha',
	'nl': 'het een niet van dat wat dit maar ik je zijn met op voor',
	'pl': 'nie to jest sie co jak tak ale czy mnie tylko ten juz',
}
_STOP_SETS = dict((k, set(v.split())) for k, v in _STOP.items())


def guess_language(text):
	"""Base code of the language of a subtitle's text, or None when unsure."""
	words = _fold(re.sub(r'\d+:\d+:\d+[,.]\d+', ' ', text or '')).split()
	if len(words) < 60:
		return None
	counts = sorted(((sum(1 for w in words if w in sw), code) for code, sw in _STOP_SETS.items()), reverse=True)
	best, code = counts[0]
	second = counts[1][0]
	if best >= 15 and best >= 1.6 * max(1, second):
		return code
	return None


def parse_detail(html):
	"""{'orig': base code of the original or None, 'orig_url': url or None,
	'downloads': {code: url}} (codes lowercased, regional kept: 'pt-br')."""
	downloads = {}
	for m in _DOWNLOAD_RE.finditer(html or b''):
		code = m.group(1).decode('ascii', 'replace').lower()
		downloads.setdefault(code, _url(m.group(2).decode('utf-8', 'replace')))
	orig = orig_url = None
	m = _ORIG_FILE_RE.search(html or b'')
	if m:
		fname = m.group(1).decode('utf-8', 'replace')
		folder = m.group(2).decode('ascii', 'replace').strip('/')
		orig_url = _url('%s/%s' % (folder, fname))
		named = _ORIG_NAMED_RE.search(fname)
		if named and named.group(1).lower() in _NAMES:
			orig = _NAMES[named.group(1).lower()]
		else:
			coded = _ORIG_CODE_RE.search(fname)
			if coded:
				orig = base_code(coded.group(1))
	if not orig:
		# v2.0.27: 'Release.Name.CHORTLE-orig.srt' says no language. The page
		# shows the original's text: guess it from there (see find(), which
		# prefers what the search page said).
		i = (html or b'').find(_ORIG_TEXT_MARK)
		if i >= 0:
			orig = guess_language((html[i + len(_ORIG_TEXT_MARK):i + 60000]).decode('utf-8', 'replace'))
	return {'orig': orig, 'orig_url': orig_url, 'downloads': downloads}


# ──────────────────────────────────────────────────────────────────────
# Matching
# ──────────────────────────────────────────────────────────────────────

def _fold(text):
	"""Lowercase, accents off ('Eşref Rüya' -> 'esref ruya'), only letters and digits."""
	text = unicodedata.normalize('NFKD', text or '')
	text = ''.join(c for c in text if not unicodedata.combining(c))
	return re.sub(r'[\W_]+', ' ', text.lower(), flags=re.U).strip()


def _tokens(text):
	return [t for t in _fold(text).split() if t]


def episode_tag(text, season, episode):
	t = _fold(text)
	try: s, e = int(season), int(episode)
	except (TypeError, ValueError): return False
	return bool(re.search(r'\bs0*%d ?e0*%d(?!\d)' % (s, e), t) or
				re.search(r'(?<![\d])%d ?x ?0*%d(?!\d)' % (s, e), t))


def accept(cand_title, title, year, season, episode):
	"""True when the result is about THIS title: the title at the start of
	the name, and for an episode its SxxEyy (or 1x02); for a film no other year."""
	toks = _tokens(_PREFIX_RE.sub('', cand_title or ''))
	words = _tokens(title)
	if not words or not _starts_with(toks, words):
		return False
	cand = set(toks)
	if season and episode:
		return episode_tag(cand_title, season, episode)
	if year:
		years = [t for t in cand if re.match(r'^(19|20)\d\d$', t)]
		if years and not any(abs(int(y) - int(year)) <= 1 for y in years):
			return False
	return True


def _starts_with(toks, words):
	"""The upload's name STARTS with the title's words, in order.
	v2.0.27: before, the title could be anywhere in the first three words, and
	"The Beast" took the subtitle of "Heart of the Beast" (kodi.log
	4-nov-2026). A leading [group] tag or 'www.site.com - ' is removed first
	(see accept)."""
	return toks[:len(words)] == words


_PREFIX_RE = re.compile(r'^\s*(?:[\[(][^\])]{0,40}[\])]\s*|www\.\S+\s*-\s*)+', re.I)


def similarity(cand_title, release):
	if not release: return 0.0
	return SequenceMatcher(None, _fold(cand_title), _fold(release)).ratio()


# ──────────────────────────────────────────────────────────────────────
# Lookup
# ──────────────────────────────────────────────────────────────────────

def _get(url, deadline):
	left = deadline - time.time()
	if left <= 1:
		return None
	try:
		import requests
		r = requests.get(url, headers={'User-Agent': UA, 'Accept-Language': 'en-US,en;q=0.9'},
						 timeout=min(TIMEOUT, left))
	except Exception as e:
		_log('request failed: %s' % type(e).__name__)
		return None
	if r.status_code != 200:
		_log('HTTP %s from SubtitleCat%s' % (r.status_code, ' (Cloudflare?)' if r.status_code in (403, 503) else ''))
		return None
	return r.content


def find(title, year=None, season=None, episode=None, release=''):
	"""Best SubtitleCat uploads for this title, best first:
	[{'title', 'url', 'orig', 'orig_url', 'downloads', 'ratio'}]."""
	deadline = time.time() + SEARCH_BUDGET
	if season and episode:
		try: tag = 'S%02dE%02d' % (int(season), int(episode))
		except (TypeError, ValueError): return []
		queries = ['%s %s' % (title, tag), title]
	else:
		queries = ['%s %s' % (title, year), title] if year else [title]
	found, seen = [], set()
	for q in queries:
		html = _get('%s/index.php?search=%s' % (BASE_URL, quote(q, safe='')), deadline)
		if html is None:
			break
		rows = parse_search(html)
		good = [r for r in rows if r['url'] not in seen and accept(r['title'], title, year, season, episode)]
		for r in good:
			seen.add(r['url'])
			r['ratio'] = similarity(r['title'], release)
		good.sort(key=lambda r: r['ratio'], reverse=True)
		_log('search "%s": %d results, %d about this title' % (q, len(rows), len(good)))
		for r in good[:MAX_DETAILS - len(found)]:
			html = _get(r['url'], deadline)
			if html is None:
				continue
			r.update(parse_detail(html))
			# MEASURED (screenshot 4-nov-2026, "Your Mother Your Mother Your
			# Mother"): uploads named '...-CHORTLE-orig.srt' say no language in
			# the file name, so the original was 'unknown' and could be neither
			# used nor translated. The search page says it: "translated from English".
			if r.get('from'):
				r['orig'] = r['from']
			if r['orig_url'] or r['downloads']:
				found.append(r)
		if found or len(found) >= MAX_DETAILS:
			break
	_log('%d upload(s) usable for %s%s' % (len(found), title, ''.join(
		'\n    %s: original %s, files %s' % (r['title'][:70], r.get('orig') or 'unknown', ','.join(sorted(r.get('downloads') or {})) or '-')
		for r in found)))
	return found


def pick(entries, setting_value, original=True):
	"""(url, entry) of the best upload in that language: its ORIGINAL file, or
	(original=False) the site's machine translation into it. (None, None)."""
	codes = setting_codes(setting_value)
	if not codes:
		return None, None
	base = base_code(codes[-1])
	for e in entries or []:
		is_orig = e.get('orig') and base_code(e['orig']) == base
		if original:
			if not is_orig:
				continue
			for c in codes:
				if c in e.get('downloads', {}):
					return e['downloads'][c], e
			if e.get('orig_url'):
				return e['orig_url'], e
		else:
			if is_orig or not e.get('orig'):
				continue      # unknown original: cannot tell a translation from it
			for c in codes:
				if c in e.get('downloads', {}):
					return e['downloads'][c], e
	return None, None


def originals(entries):
	"""[(base code, url, entry)] of every original file, for translation sources."""
	out = []
	for e in entries or []:
		if e.get('orig') and (e.get('orig_url') or e['orig'] in e.get('downloads', {})):
			out.append((e['orig'], e.get('downloads', {}).get(e['orig']) or e['orig_url'], e))
	return out


def fetch(url):
	"""Bytes of an .srt, or None."""
	return _get(url, time.time() + TIMEOUT + 2)


def _log(message, level=xbmc.LOGINFO):
	try: xbmc.log('%s %s' % (LOG_TAG, message), level)
	except Exception: pass


# Page patterns and matching rules adapted from the SubtitleCat provider of
# https://github.com/LavX/bazarr-provider-catalog, used under its licence:
#
# MIT License
#
# Copyright (c) 2026 LavX
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
