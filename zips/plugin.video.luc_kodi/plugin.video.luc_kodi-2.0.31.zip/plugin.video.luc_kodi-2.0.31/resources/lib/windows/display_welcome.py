# -*- coding: utf-8 -*-
"""
	luc_kodi Add-on
	DisplayWelcomeXML — unified notification window used by ALL plugin notifications.
	A module-level lock serializes concurrent notifications so only one
	WindowXMLDialog is ever showing at a time — avoids Kodi window init conflicts.
"""

import threading
import time
import xbmcgui
from resources.lib.modules import log_utils

# v2.0.14: shared with control, released at the end of the run
from resources.lib.modules.control import monitor, homeWindow as _HOME

# Serialization lock — one notification visible at a time
_show_lock = threading.Lock()
# Whose turn it is, across interpreters (service + plugin): 'token@until'
_TURN = 'luc_kodi.notif.turn'


class DisplayWelcomeXML(xbmcgui.WindowXMLDialog):

	def __init__(self, *args, **kwargs):
		xbmcgui.WindowXMLDialog.__init__(self, *args)
		self.line1    = kwargs.get('line1', 'luc_kodi')
		self.line2    = kwargs.get('line2', '')
		self.icon     = kwargs.get('icon',  '')
		self.duration = kwargs.get('duration', 4)

	def onInit(self):
		try:
			_HOME.setProperty('luc_kodi.notif.icon',  self.icon)
			_HOME.setProperty('luc_kodi.notif.line1', self.line1)
			_HOME.setProperty('luc_kodi.notif.line2', self.line2)
		except Exception:
			log_utils.error()

	def _clear(self):
		try:
			# Only what is still ours: another notification may own them now.
			if (_HOME.getProperty('luc_kodi.notif.line1') != self.line1
					or _HOME.getProperty('luc_kodi.notif.line2') != self.line2):
				return
			_HOME.clearProperty('luc_kodi.notif.icon')
			_HOME.clearProperty('luc_kodi.notif.line1')
			_HOME.clearProperty('luc_kodi.notif.line2')
		except Exception:
			log_utils.error()

	def onAction(self, action):
		if action.getId() in (9, 10, 13, 92):
			self._user_closed = True
			self.close()

	def show_and_close(self, duration=None):
		"""Acquire the module lock so notifications never overlap.

		v2.0.27. MEASURED (kodi.log 5-nov-2026: "an empty notification"): the
		lock above only covers one Python interpreter, and the service and a
		playing plugin are two. Two notifications then shared the window's
		text properties, and the first to close cleared them while the second
		was still on screen: an empty box. A turn is now also taken through a
		property on the home window, which every interpreter sees, and each
		notification only clears what is still its own."""
		secs = duration or self.duration
		self._user_closed = False
		with _show_lock:
			token = '%x%x' % (id(self), int(time.time() * 1000))
			give_up = time.time() + 20
			while not monitor.abortRequested():
				held = _HOME.getProperty(_TURN)
				try:
					until = float(held.rsplit('@', 1)[1]) if held else 0
				except Exception:
					until = 0
				if until < time.time() or time.time() > give_up:
					break
				monitor.waitForAbort(0.2)
			_HOME.setProperty(_TURN, '%s@%.2f' % (token, time.time() + secs + 3))
			self._token = token
			try:
				self.show()
				elapsed = 0
				while elapsed < secs and not monitor.abortRequested():
					# Si el usuario cierra el dialogo (Back/OK), salir YA: seguir
					# esperando bloqueaba al CPythonInvoker ("waiting on thread")
					# el resto de la duracion y provocaba un segundo close() sobre
					# un dialogo ya cerrado, ampliando la ventana de carrera con
					# la reinicializacion del interprete (reuselanguageinvoker).
					if self._user_closed: break
					monitor.waitForAbort(0.25)
					elapsed += 0.25
				if not self._user_closed: self.close()
			except Exception:
				log_utils.error()
			finally:
				self._clear()
				if _HOME.getProperty(_TURN).startswith(token + '@'):
					_HOME.clearProperty(_TURN)
