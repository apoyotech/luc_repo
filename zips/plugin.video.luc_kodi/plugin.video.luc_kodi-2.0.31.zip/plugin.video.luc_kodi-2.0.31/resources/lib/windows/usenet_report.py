# -*- coding: utf-8 -*-
"""
	luc_kodi Add-on
	Usenet report window (v2.0.25) - same right side panel as System status,
	see modules/usenet_report.py
"""

import threading

from resources.lib.modules import control
from resources.lib.modules import usenet_report as ur
from resources.lib.windows.base import BaseDialog

EXITS_ID = 3000   # grouplist: Back / Today / 7 days / 30 days / Clear
BACK_ID = 3002
PERIOD_IDS = {3005: 'today', 3006: 'week', 3007: 'month'}
CLEAR_ID = 3008
LIST_ID = 4300
ACTION_MOVE_UP, ACTION_MOVE_DOWN = 3, 4
ACTION_PAGE_UP, ACTION_PAGE_DOWN = 5, 6


class UsenetReportXML(BaseDialog):
	def __init__(self, *args, **kwargs):
		BaseDialog.__init__(self, args)
		self.period = 'week'
		self.acct = None          # None: still reading the Easynews account
		self._items = []
		self._alive = True
		self._lock = threading.RLock()

	# ───────── lifecycle ─────────
	def run(self):
		self.doModal()
		self._alive = False
		self.clearProperties()

	def onInit(self):
		self._paint_buttons()
		self._rebuild()
		self.setFocusId(3006)
		t = threading.Thread(target=self._read_account)
		t.daemon = True
		t.start()

	def _read_account(self):
		acct = ur.account()
		if not self._alive: return
		self.acct = acct
		self._rebuild()

	def clearProperties(self):
		for p in ('report.meta', 'report.b1', 'report.b2', 'report.b3'):
			try: self.clearProperty(p)
			except Exception: pass

	# ───────── content ─────────
	def _days(self):
		return {k: d for k, d, _ in ur.PERIODS}[self.period]

	def _paint_buttons(self):
		for n, (key, _, _label) in enumerate(ur.PERIODS, 1):
			short = {'today': 'Today', 'week': '7 days', 'month': '30 days'}[key]
			self.setProperty('report.b%d' % n, ('[COLOR FF00FA9A]%s[/COLOR]' % short) if key == self.period else short)
		label = {k: l for k, _, l in ur.PERIODS}[self.period]
		self.setProperty('report.meta', '%s  ·  Easynews + Newznab' % label)

	def _rebuild(self):
		with self._lock:
			try:
				items = []
				for title, note, rows in ur.sections(self._days(), self.acct):
					li = self.make_listitem()
					li.setLabel(title)
					li.setProperty('kind', 'header')
					li.setProperty('note', note or '')
					items.append(li)
					for row in rows:
						li = self.make_listitem()
						li.setLabel(row['label'])
						# colours travel inside the text (see windows/system_status.py)
						li.setProperty('dot', row.get('dot') or ur.GREY)
						if row.get('note'):
							li.setProperty('note', '[COLOR %s]%s[/COLOR]' % (row.get('notecolor') or ur.GREY, row['note']))
						if row.get('value'):
							li.setProperty('value', '[COLOR %s]%s[/COLOR]' % (row.get('dot') or ur.GREY, row['value']))
						items.append(li)
				self._items = items
				lst = self.getControl(LIST_ID)
				pos = max(0, lst.getSelectedPosition())
				lst.reset()
				lst.addItems(items)
				if pos < len(items): lst.selectItem(pos)
			except Exception:
				from resources.lib.modules import log_utils
				log_utils.error()

	def _clear(self):
		if not control.dialog.yesno('Usenet report', 'Delete the Usenet report history kept on this device?\n'
									'Searches, grabs and playbacks are counted again from now.'):
			return
		from resources.lib.modules import usenet_stats
		usenet_stats.clear()
		self._rebuild()
		control.notification(message='Usenet report history deleted')

	# ───────── input ─────────
	def onClick(self, controlID):
		try:
			if controlID == BACK_ID: self.close()
			elif controlID in PERIOD_IDS:
				self.period = PERIOD_IDS[controlID]
				self._paint_buttons()
				self._rebuild()
			elif controlID == CLEAR_ID: self._clear()
		except Exception:
			from resources.lib.modules import log_utils
			log_utils.error()

	def _is_header(self, pos):
		return 0 <= pos < len(self._items) and self._items[pos].getProperty('kind') == 'header'

	def _first_row(self, start=0, step=1):
		i = start
		while 0 <= i < len(self._items):
			if not self._is_header(i): return i
			i += step
		return -1

	def onAction(self, action):
		try:
			action_id = action.getId()
			if action_id in self.closing_actions or action_id in self.context_actions:
				self.close()
				return
			focus = self.getFocusId()
			if action_id == ACTION_MOVE_DOWN and (focus in PERIOD_IDS or focus in (BACK_ID, CLEAR_ID)) and self._items:
				first = self._first_row()
				if first >= 0:
					self.getControl(LIST_ID).selectItem(first)
					self.setFocusId(LIST_ID)
				return
			# section titles are rows of the list, not options: hop over them
			if focus == LIST_ID and action_id in (ACTION_MOVE_UP, ACTION_MOVE_DOWN, ACTION_PAGE_UP, ACTION_PAGE_DOWN):
				pos = self.get_position(LIST_ID)
				if self._is_header(pos):
					step = -1 if action_id in (ACTION_MOVE_UP, ACTION_PAGE_UP) else 1
					target = self._first_row(pos + step, step)
					if target < 0 and step < 0:
						self.setFocusId(EXITS_ID)
						return
					if target < 0: target = self._first_row(pos - step, -step)
					if target >= 0: self.getControl(LIST_ID).selectItem(target)
		except Exception:
			from resources.lib.modules import log_utils
			log_utils.error()
