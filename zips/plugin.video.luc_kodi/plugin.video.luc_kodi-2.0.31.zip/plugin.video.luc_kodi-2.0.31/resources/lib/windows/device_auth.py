# -*- coding: utf-8 -*-
"""
	luc_kodi Add-on
	Sign-in window (v2.0.15) shared by every service that links an account with
	a code: QR, address and code together, with the time left on the code. It
	runs doModal() in a thread of its own, like the sources progress window, so
	it takes Back and OK even over the Settings dialog, while the service keeps
	polling in its own loop and asks iscanceled(), exactly as it did with the
	progress dialog. See modules/device_auth.py.
"""

import threading
import time

from resources.lib.modules import control
from resources.lib.windows.base import BaseDialog

CANCEL_ID = 9300
PROGRESS_ID = 9310
_PROPS = ('da.logo', 'da.title', 'da.sub', 'da.qr', 'da.url', 'da.code', 'da.left', 'da.status', 'da.hint')


def _mmss(secs):
	secs = max(0, int(secs))
	return '%d:%02d' % (secs // 60, secs % 60)


class DeviceAuthXML(BaseDialog):
	def __init__(self, *args, **kwargs):
		BaseDialog.__init__(self, args)
		self.data = kwargs.get('data') or {}
		self.canceled = False
		self.alive = True
		self.started = time.time()
		try: self.expires_in = max(int(self.data.get('expires_in') or 0), 0)
		except Exception: self.expires_in = 0

	# ───────── lifecycle ─────────
	def run(self):
		# closed before its thread got here: never open it
		if self.alive: self.doModal()
		self.alive = False

	def open(self):
		self.thread = threading.Thread(target=self.run)
		self.thread.daemon = True
		self.thread.start()

	def onInit(self):
		try:
			d = self.data
			self.setProperty('da.logo', d.get('logo') or '')
			self.setProperty('da.title', d.get('title') or '')
			self.setProperty('da.sub', d.get('sub') or control.lang(401061))
			self.setProperty('da.qr', d.get('qr') or '')
			self.setProperty('da.url', d.get('url') or '')
			self.setProperty('da.code', d.get('code') or '')
			self.setProperty('da.hint', d.get('hint') or '')
			self.setProperty('da.status', d.get('status') or control.lang(401066))
			self._tick()
			self.setFocusId(CANCEL_ID)
		except Exception:
			from resources.lib.modules import log_utils
			log_utils.error()
		if self.expires_in:
			t = threading.Thread(target=self._ticker)
			t.daemon = True
			t.start()

	def _ticker(self):
		while self.alive:
			time.sleep(0.5)
			if not self.alive: break
			if not self._tick(): break

	def _tick(self):
		"""Time left on the code; False once it has run out."""
		if not self.expires_in: return True
		left = self.expires_in - (time.time() - self.started)
		try:
			if left <= 0:
				self.setProperty('da.left', '')
				self.setProperty('da.status', control.lang(401069))
				self.getControlProgress(PROGRESS_ID).setPercent(0)
				return False
			self.setProperty('da.left', control.lang(401065) % _mmss(left))
			self.getControlProgress(PROGRESS_ID).setPercent(left * 100.0 / self.expires_in)
		except Exception: pass
		return True

	def set_status(self, text):
		try: self.setProperty('da.status', text or '')
		except Exception: pass

	# ───────── input ─────────
	def onAction(self, action):
		if action.getId() in self.closing_actions: self.cancel()

	def onClick(self, control_id):
		if control_id == CANCEL_ID: self.cancel()

	def cancel(self):
		self.canceled = True
		self.close()

	def close(self):
		self.alive = False
		BaseDialog.close(self)

	def clear(self):
		for p in _PROPS:
			try: self.clearProperty(p)
			except Exception: pass
