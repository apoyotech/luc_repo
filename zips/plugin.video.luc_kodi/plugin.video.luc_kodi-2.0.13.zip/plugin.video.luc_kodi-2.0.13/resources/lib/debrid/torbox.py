import requests
from sys import argv, exit as sysexit
from threading import Thread
from urllib.parse import urlencode
from resources.lib.modules import control
from resources.lib.modules.context_hub import attach_cm # v2.0.09: modern panel or classic Kodi menu
from resources.lib.modules import log_utils
from resources.lib.modules import string_tools
from resources.lib.modules.source_utils import supported_video_extensions, lang_ep_numbers, loose_episode_pick

getLS = control.lang
getSetting = control.setting
base_url = 'https://api.torbox.app/v1/api'
tb_icon = control.joinPath(control.artPath(), 'torbox.png')
addonFanart = control.addonFanart()

session = requests.Session()
session.mount(base_url, requests.adapters.HTTPAdapter(max_retries=1))

# v2.0.05 -- su SDK oficial: cada consulta a /torrents/checkcached atiende
# unos 100 hashes; para mas, varias consultas. Antes iban todos en un POST
# (325 en una busqueda cargada), mas lento y con riesgo de que respondiera
# solo de una parte.
CACHE_CHUNK = 100


def norm_hash(h):
	"""v2.0.05 -- infohash a hex de 40 en minusculas, que es como lo devuelve
	TorBox. apibay (piratebay) lo da en MAYUSCULAS y algunos magnets de knaben
	vienen en base32 (32 caracteres): la lista los marcaba como cacheados y
	resolve_magnet(), que comparaba sin normalizar, los descartaba despues."""
	h = (h or '').strip()
	if len(h) == 32:
		try:
			from base64 import b32decode
			from binascii import hexlify
			return hexlify(b32decode(h.upper())).decode('ascii').lower()
		except Exception:
			pass
	return h.lower()


# ── v2.0.13: Usenet de TorBox Pro para el scraper Newznab ─────────────────────
# Con el buscador de TorBox cerrado, los NZB llegan del indexer propio del
# usuario (Newznab) y TorBox los descarga.

def nzb_hash(url):
	"""Hash con el que se archiva un NZB en la cache de Usenet: md5 del enlace
	SIN la clave del indexer, que cambia de un usuario a otro. Mismas formas que
	AIOStreams (debrid/utils.ts, canonicalNzbHash): .../api?t=get&id=X conserva
	t e id; .../getnzb conserva id; .../download (Prowlarr) conserva link; el
	resto pierde toda la query."""
	import hashlib
	from urllib.parse import urlsplit, urlunsplit, parse_qsl
	url = url or ''
	md5 = lambda v: hashlib.md5(v.encode('utf-8')).hexdigest()
	try:
		u = urlsplit(url)
		path = u.path.rstrip('/')
		params = parse_qsl(u.query, keep_blank_values=True)
		values = dict(params)
		for suffix, keep, cond in (('/api', ('t', 'id'), lambda d: d.get('t') in ('get', 'g')),
								   ('/download', ('link',), None), ('/getnzb', ('id',), None)):
			if not path.endswith(suffix) or any(not values.get(k) for k in keep): continue
			if cond and not cond(values): continue
			return md5(urlunsplit((u.scheme, u.netloc, u.path, urlencode([(k, v) for k, v in params if k in keep]), u.fragment)))
	except Exception:
		pass
	cleaned = url.split('?', 1)[0] if '?' in url else url.split('&', 1)[0]
	return md5(cleaned.split('#', 1)[0])

PLAN_PRO = 2
_PLAN_PROP = 'luc_kodi.torbox.plan'
_PLAN_HOURS = 6

def usenet_plan_ok():
	"""El Usenet de TorBox solo esta en el plan Pro (plan 2). Se pregunta una vez
	cada 6 horas; ante la duda (sin red, sin respuesta) no se bloquea."""
	import time
	try:
		raw = control.homeWindow.getProperty(_PLAN_PROP)
		if raw:
			plan, ts = raw.split('|')
			if time.time() - float(ts) < _PLAN_HOURS * 3600: return plan in ('', str(PLAN_PRO))
		info = TorBox().account_info() or {}
		plan = (info.get('data') or {}).get('plan')
		if plan is None: return True
		control.homeWindow.setProperty(_PLAN_PROP, '%s|%s' % (plan, time.time()))
		if plan != PLAN_PRO:
			log_utils.log('TorBox: plan %s has no Usenet; Newznab NZBs are not sent to TorBox' % plan, level=log_utils.LOGINFO)
		return plan == PLAN_PRO
	except Exception:
		return True


class TorBox:
	download = '/torrents/requestdl'
	download_usenet = '/usenet/requestdl'
	remove = '/torrents/controltorrent'
	remove_usenet = '/usenet/controlusenetdownload'
	stats = '/user/me'
	history = '/torrents/mylist'
	history_usenet = '/usenet/mylist'
	explore = '/torrents/mylist?id=%s'
	explore_usenet = '/usenet/mylist?id=%s'
	cache = '/torrents/checkcached'
	cache_usenet = '/usenet/checkcached'
	cloud = '/torrents/createtorrent'
	cloud_usenet = '/usenet/createusenetdownload'

	def __init__(self):
		self.name = 'TorBox'
		self.user_agent = 'Mozilla/5.0'
		self.api_key = getSetting('torbox.token')
		self.sort_priority = getSetting('torbox.priority')
		self.store_to_cloud = getSetting('torbox.saveToCloud') == 'true'
		self.timeout = 28.0

	def _request(self, method, path, params=None, json=None, data=None):
		if not self.api_key: return
		session.headers['Authorization'] = 'Bearer %s' % self.api_key
		full_path = '%s%s' % (base_url, path)
		try:
			response = session.request(method, full_path, params=params, json=json, data=data, timeout=self.timeout)
		except Exception as e:
			# v1.0.75 -- segunda linea de defensa. Aunque ya no mandemos el token
			# como parametro, requests incrusta la URL en el texto de sus
			# excepciones; scrub_url() la limpia antes de que llegue al log.
			try:
				from resources.lib.jacksparrow.client import scrub_url
				msg = scrub_url(str(e))
			except Exception: msg = '%s (%s %s)' % (type(e).__name__, method.upper(), path)
			log_utils.log('TorBox network error: %s' % msg, level=log_utils.LOGWARNING)
			return {}
		# Parse body first so we can read 'success'/'error'/'detail' regardless of status code
		try: result = response.json()
		except: result = {}
		# TorBox 2026: standardised response shape is {success, error, detail, data}.
		# Surface critical error codes user-friendly via 'detail'.
		# Per https://api-docs.torbox.app/ -- COOLDOWN_LIMIT, MONTHLY_LIMIT, ACTIVE_LIMIT,
		# PLAN_RESTRICTED_FEATURE, DOWNLOAD_TOO_LARGE are client-actionable, all others log only.
		if isinstance(result, dict) and result.get('success') is False:
			err = result.get('error') or ''
			detail = result.get('detail') or ''
			if err in ('COOLDOWN_LIMIT', 'MONTHLY_LIMIT', 'ACTIVE_LIMIT', 'PLAN_RESTRICTED_FEATURE', 'DOWNLOAD_TOO_LARGE'):
				# These are limit/plan errors the user can act on -- surface a toast.
				try: control.notification(title='TorBox: %s' % err, message=detail or err, icon=tb_icon)
				except Exception: pass
				log_utils.log('TorBox limit: %s -- %s' % (err, detail), level=log_utils.LOGWARNING)
			elif err in ('BAD_TOKEN', 'AUTH_ERROR', 'NO_AUTH'):
				log_utils.log('TorBox auth error (%s): %s' % (err, detail), level=log_utils.LOGWARNING)
			elif err:
				log_utils.log('TorBox %s: %s [%s %s]' % (err, detail, method.upper(), path), level=log_utils.LOGDEBUG)
		# Defensive raise_for_status (preserves existing behavior for non-2xx that didn't parse)
		try: response.raise_for_status()
		except Exception as e:
			if not (isinstance(result, dict) and 'success' in result):
				# v1.0.75 -- este mensaje lleva la URL completa, y la URL de
				# requestdl lleva el token. Se sanea igual que el error de red.
				try:
					from resources.lib.jacksparrow.client import scrub_url
					_e = scrub_url(str(e))
				except Exception: _e = '%s (%s %s)' % (type(e).__name__, method.upper(), path)
				log_utils.log('TorBox HTTP error: %s\n%s' % (_e, response.text[:500] if hasattr(response, 'text') else ''), level=log_utils.LOGDEBUG)
		return result

	@staticmethod
	def _ok(result):
		"""v1.0.75 -- _request() devuelve {} ante un error de red y None si no hay
		api_key, asi que result['success'] lanzaba KeyError/TypeError en las tres
		llamadas que lo leian a pelo. Un fallo de red no es una excepcion: es un
		no."""
		return isinstance(result, dict) and result.get('success') is True

	def _GET(self, url, params=None):
		return self._request('get', url, params=params)

	def _POST(self, url, params=None, json=None, data=None):
		return self._request('post', url, params=params, json=json, data=data)

	def add_headers_to_url(self, url):
		return url + '|' + urlencode(self.headers())

	def headers(self):
		return {'User-Agent': self.user_agent}

	@property
	def days_remaining(self):
		import datetime
		try:
			account_info = self.account_info()
			date_string = account_info['data']['premium_expires_at'][:10]
			expires = datetime.datetime.strptime(date_string, '%Y-%m-%d')
			days_remaining = (expires - datetime.datetime.today()).days
		except: days_remaining = None
		return days_remaining

	def account_info(self):
		return self._GET(self.stats)

	def torrent_info(self, request_id=''):
		# v2.0.05 -- bypass_cache: TorBox sirve /torrents/mylist desde una cache
		# que refresca cada 600 s. Justo despues de createtorrent hay que pedir
		# el dato fresco o la lista de ficheros puede llegar vacia.
		return self._GET(self.history, params={'id': request_id, 'bypass_cache': 'true'})

	def delete_torrent(self, request_id=''):
		data = {'torrent_id': request_id, 'operation': 'delete'}
		return self._POST(self.remove, json=data)

	def delete_usenet(self, request_id=''):
		data = {'usenet_id': request_id, 'operation': 'delete'}
		return self._POST(self.remove_usenet, json=data)

	# v1.0.75 -- OJO: el 'token' de estas dos llamadas NO es redundante.
	# /torrents/requestdl y /usenet/requestdl lo EXIGEN como parametro de query
	# y NO aceptan la cabecera Authorization: sin el devuelven 422 Unprocessable
	# Entity y no se reproduce nada. Se comprobo en aparato el 7-sep-2026.
	# La fuga al log que motivo el cambio se ataja donde toca: en _request(),
	# saneando el texto de la excepcion antes de escribirlo (red Y HTTP).
	def unrestrict_link(self, file_id):
		torrent_id, file_id = file_id.split(',')
		params = {'token': self.api_key, 'torrent_id': torrent_id, 'file_id': file_id}
		try: return self._GET(self.download, params=params)['data']
		except: return None

	def unrestrict_usenet(self, file_id):
		usenet_id, file_id = file_id.split(',')
		params = {'token': self.api_key, 'usenet_id': usenet_id, 'file_id': file_id}
		try: return self._GET(self.download_usenet, params=params)['data']
		except: return None

	def check_cache_single(self, hash):
		return self._GET(self.cache, params={'hash': hash, 'format': 'list'})

	def check_cache(self, hashlist, list_files=False):
		"""v2.0.05 -- hashes normalizados y sin repetir, troceados de CACHE_CHUNK
		en CACHE_CHUNK y consultados en paralelo. Devuelve la misma forma que
		antes, {'success': True, 'data': [...]}, o None si fallan todos los
		trozos. Con list_files=True cada fila trae los ficheros del torrent."""
		seen, uniq = set(), []
		for h in hashlist or []:
			h = norm_hash(h)
			if h and h not in seen:
				seen.add(h)
				uniq.append(h)
		if not uniq: return None
		params = {'format': 'list'}
		if list_files: params['list_files'] = 'true'
		rows, answered = [], []
		def _one(chunk):
			result = self._POST(self.cache, params=params, json={'hashes': chunk})
			if self._ok(result):
				answered.append(1)
				rows.extend(result.get('data') or [])
		chunks = [uniq[i:i + CACHE_CHUNK] for i in range(0, len(uniq), CACHE_CHUNK)]
		if len(chunks) == 1: _one(chunks[0])
		else:
			threads = [Thread(target=_one, args=(c,)) for c in chunks]
			[t.start() for t in threads]
			[t.join() for t in threads]
		if not answered: return None
		if len(answered) < len(chunks):
			log_utils.log('TorBox checkcached: %d of %d chunks answered' % (len(answered), len(chunks)),
						  level=log_utils.LOGWARNING)
		return {'success': True, 'data': rows}

	def check_cache_usenet(self, hashlist):
		"""TorBox 2026: cache check for usenet items.
		Hashes are md5(nzb_link) per https://api-docs.torbox.app/; for indexer
		links pass nzb_hash(link), which leaves the indexer key out (v2.0.13).
		Returns set of cached hashes (lowercase) or empty set on error."""
		if not hashlist: return set()
		try:
			data = {'hashes': list(hashlist)}
			response = self._POST(self.cache_usenet, params={'format': 'list'}, json=data)
			if not response or not response.get('success'): return set()
			rows = response.get('data') or []
			return set(i['hash'].lower() for i in rows if i.get('hash'))
		except Exception:
			log_utils.error()
			return set()

	def add_magnet(self, magnet, add_only_if_cached=None):
		"""TorBox 2026: pass add_only_if_cached so uncached magnets don't get
		silently queued against the user's active-download limit."""
		if add_only_if_cached is None:
			add_only_if_cached = getSetting('torbox.add_only_if_cached') in ('', 'true')
		data = {'magnet': magnet, 'seed': 3, 'allow_zip': 'false'}
		if add_only_if_cached:
			data['add_only_if_cached'] = 'true'
		return self._POST(self.cloud, data=data)

	def add_nzb(self, nzb_url, add_only_if_cached=None):
		"""TorBox 2026: add an NZB usenet download. Accepts a link or an NZB file.
		Pro plan required. By default honours the same add_only_if_cached setting
		as magnets; resolve_nzb() (Newznab, v2.0.13) passes False."""
		if add_only_if_cached is None:
			add_only_if_cached = getSetting('torbox.add_only_if_cached') in ('', 'true')
		data = {'link': nzb_url}
		if add_only_if_cached:
			data['add_only_if_cached'] = 'true'
		return self._POST(self.cloud_usenet, data=data)

	def resolve_nzb(self, nzb_url, info_hash, season, episode, title):
		"""Un NZB (de Newznab, v2.0.13) a una URL reproducible.

		Se anade a TorBox SIN add_only_if_cached: lo que TorBox ya tiene llega al
		momento y lo que no, TorBox lo baja de Usenet (plan Pro). Mientras baja se
		ensena un cuadro con el progreso, la velocidad y lo que falta; Cancelar, o
		que no avance en newznab.pm_stall_secs segundos, lo borra de la cuenta para
		no dejar descargas huerfanas. Despues se elige el fichero (episodio o el
		video mayor) y se pide su enlace.
		"""
		from resources.lib.modules.source_utils import seas_ep_filter, extras_filter
		home = control.homeWindow
		# Una sola a la vez: el autoplay y el pre-cacheo de vecinos podrian lanzar
		# varias y cada una es una descarga en la cuenta del usuario.
		if home.getProperty('luc_kodi.tb_nzb_busy') == 'true':
			log_utils.log('TorBox resolve_nzb: another NZB is being resolved; skipped', level=log_utils.LOGDEBUG)
			return None
		home.setProperty('luc_kodi.tb_nzb_busy', 'true')
		usenet_id = None
		try:
			extensions = supported_video_extensions()
			title = title or ''
			extras_filtering_list = tuple(i for i in extras_filter() if not i in title.lower())
			result = self.add_nzb(nzb_url, add_only_if_cached=False)
			if not result or not result.get('success'):
				err = (result or {}).get('detail') or (result or {}).get('error') or 'no answer'
				log_utils.log('TorBox resolve_nzb: add_nzb failed (%s)' % err, level=log_utils.LOGWARNING)
				control.notification(title='TorBox', message='Usenet: %s' % err, icon=tb_icon)
				return None
			_rdata = result.get('data') or {}
			usenet_id = _rdata.get('usenetdownload_id') or _rdata.get('usenet_id') or _rdata.get('id')
			if not usenet_id:
				log_utils.log('TorBox resolve_nzb: no usenetdownload_id in add_nzb response (data=%s)' % _rdata,
							  level=log_utils.LOGWARNING)
				return None
			files = self._wait_usenet(usenet_id, _rdata.get('name') or title)
			if not files:
				return None

			# El fichero: el episodio pedido o, si no, el video mayor.
			correct_files, match = [], False
			if season and episode:
				for f in files:
					name = f.get('short_name') or f.get('name') or ''
					if name.lower().endswith(tuple(extensions)) and seas_ep_filter(season, episode, name):
						correct_files.append(f)
						match = True
			if not match:
				vids = [f for f in files if (f.get('short_name') or f.get('name') or '').lower().endswith(tuple(extensions))]
				if vids:
					vids.sort(key=lambda f: int(f.get('size') or 0), reverse=True)
					correct_files = [vids[0]]
			if not correct_files:
				log_utils.log('TorBox resolve_nzb: no video file in usenet download %s' % usenet_id, level=log_utils.LOGWARNING)
				return None
			chosen = next((f for f in correct_files
						   if not any(x in (f.get('short_name') or f.get('name') or '').lower() for x in extras_filtering_list)),
						  correct_files[0])
			file_id = chosen.get('id')
			if file_id is None:
				return None
			return self.unrestrict_usenet('%s,%s' % (usenet_id, file_id))
		except Exception:
			log_utils.error()
			return None
		finally:
			home.clearProperty('luc_kodi.tb_nzb_busy')

	def _usenet_item(self, usenet_id):
		info = self._GET(self.history_usenet, params={'id': usenet_id, 'bypass_cache': 'true'})
		data = (info or {}).get('data') or {}
		return data if isinstance(data, dict) else {}

	@staticmethod
	def _usenet_ready(data):
		return bool(data.get('files')) and bool(data.get('download_finished') or data.get('download_present'))

	def _wait_usenet(self, usenet_id, name):
		"""Ficheros de la descarga cuando esta lista; None si fallo, se cancelo o
		se atasco (en esos casos se borra de la cuenta)."""
		import time as _t
		# Lo cacheado esta listo en el primer o segundo vistazo
		for wait in (0, 1.0, 2.0):
			if wait: _t.sleep(wait)
			data = self._usenet_item(usenet_id)
			if self._usenet_ready(data): return data['files']
		try: stall_limit = int(getSetting('newznab.pm_stall_secs') or 180)
		except Exception: stall_limit = 180
		dialog = control.progressDialog
		heading = 'TorBox'
		line1 = 'TorBox is fetching the NZB from Usenet...'
		try: dialog.create(heading, '%s\n%s' % (line1, name or ''))
		except Exception: pass
		last_prog, stall_since, outcome = -1.0, _t.time(), None
		try:
			while not control.monitor.abortRequested():
				data = self._usenet_item(usenet_id)
				if self._usenet_ready(data):
					outcome = data['files']
					break
				state = str(data.get('download_state') or '').lower()
				if any(x in state for x in ('fail', 'error', 'missing', 'invalid')):
					log_utils.log('TorBox resolve_nzb: usenet download %s ended as "%s"' % (usenet_id, state), level=log_utils.LOGWARNING)
					control.notification(title='TorBox', message='Usenet: %s' % (data.get('download_state') or 'failed'), icon=tb_icon)
					break
				try: prog = float(data.get('progress') or 0)
				except Exception: prog = 0.0
				if prog > 1.0: prog = prog / 100.0
				if prog > last_prog:
					last_prog, stall_since = prog, _t.time()
				elif stall_limit > 0 and _t.time() - stall_since > stall_limit:
					log_utils.log('TorBox resolve_nzb: no progress for %ss (usenet_id=%s)' % (stall_limit, usenet_id), level=log_utils.LOGWARNING)
					control.notification(title='TorBox', message='Usenet: the download did not advance', icon=tb_icon)
					break
				detail = []
				try:
					speed = float(data.get('download_speed') or 0)
					if speed > 0: detail.append('%.1f MB/s' % (speed / 1048576.0))
				except Exception: pass
				try:
					eta = int(data.get('eta') or 0)
					if eta > 0: detail.append('%d:%02d left' % (eta // 60, eta % 60))
				except Exception: pass
				try: dialog.update(int(prog * 100), '%s\n%s\n%s' % (line1, name or '', '  ·  '.join(detail) or (data.get('download_state') or '')))
				except Exception: pass
				try:
					if dialog.iscanceled(): break
				except Exception: pass
				control.sleep(2000)
		finally:
			try: dialog.close()
			except Exception: pass
		if outcome is None:
			try: self.delete_usenet(usenet_id) # no dejar una descarga a medias en la cuenta
			except Exception: pass
		return outcome

	def create_transfer(self, magnet_url, add_only_if_cached=None):
		result = self.add_magnet(magnet_url, add_only_if_cached)
		if not self._ok(result): return ''
		try: return result['data'].get('torrent_id', '')
		except Exception: return ''

	def resolve_magnet(self, magnet_url, info_hash, season, episode, title):
		from resources.lib.modules.source_utils import seas_ep_filter, extras_filter
		import time as _t
		# v1.0.17 FIX: initialize torrent_id BEFORE the try block. Previously, if an
		# exception fired between try-entry and the line `torrent_id = torrent['data'][...]`,
		# the except handler's `if torrent_id:` raised NameError, masking the real cause.
		torrent_id = None
		try:
			file_url, match = None, False
			extensions = supported_video_extensions()
			# v1.0.18 FIX: defensive — title can arrive as None when called from the
			# auto-play-next-episode flow (the next_meta in player._show_next_episode_dialog
			# may not carry a title field for the new episode). Other debrid modules don't
			# touch title, but this module does, so coerce to '' to prevent AttributeError.
			title = title or ''
			extras_filtering_list = tuple(i for i in extras_filter() if not i in title.lower())

			# v2.0.05 -- con add_only_if_cached (por defecto) createtorrent ya
			# rechaza lo no cacheado, asi que la comprobacion individual de antes
			# era una ida y vuelta de mas por fuente. Solo se hace si el usuario
			# permite anadir no cacheados. Se espera unicamente ante COOLDOWN_LIMIT:
			# antes cualquier fallo costaba 1,5+3+4,5 s por fuente en el autoplay.
			# El hash se normaliza (mayusculas, base32) igual que en la lista.
			info_hash = norm_hash(info_hash)
			# Un magnet en base32 se reescribe con el hash hex, el mismo que se
			# comprobo en la cache, para no depender de que TorBox lo traduzca.
			if info_hash and info_hash not in (magnet_url or '').lower():
				from re import sub as _re_sub, I as _re_I
				magnet_url = _re_sub(r'btih:[a-z0-9]{32,40}', 'btih:' + info_hash, magnet_url, flags=_re_I)
			if getSetting('torbox.add_only_if_cached') not in ('', 'true'):
				check = None
				for _attempt in range(3):
					check = self.check_cache_single(info_hash)
					if isinstance(check, dict) and check.get('error') == 'COOLDOWN_LIMIT':
						log_utils.log('TorBox COOLDOWN on check_cache_single, backing off (attempt %d)' % (_attempt + 1),
									  level=log_utils.LOGWARNING)
						_t.sleep(1.5 * (_attempt + 1))
						continue
					break
				if not (isinstance(check, dict) and isinstance(check.get('data'), list)):
					return None
				match = info_hash in [norm_hash(i.get('hash')) for i in check['data']]
				if not match: return None

			# v1.0.17 FIX: add_magnet with retry+backoff against COOLDOWN_LIMIT.
			torrent = None
			for _attempt in range(3):
				torrent = self.add_magnet(magnet_url)
				if isinstance(torrent, dict) and torrent.get('success'):
					break
				if isinstance(torrent, dict) and torrent.get('error') == 'COOLDOWN_LIMIT':
					log_utils.log('TorBox COOLDOWN on add_magnet, backing off (attempt %d)' % (_attempt + 1),
								  level=log_utils.LOGWARNING)
					_t.sleep(2.0 * (_attempt + 1))
					continue
				# Non-recoverable error (auth, plan, monthly limit, bad token, etc.)
				break
			if not (isinstance(torrent, dict) and torrent.get('success')):
				return None
			torrent_id = (torrent.get('data') or {}).get('torrent_id')
			if not torrent_id:
				return None

			# v2.0.05 -- un segundo intento si la lista de ficheros aun no esta.
			torrent_files = None
			for _attempt in range(2):
				torrent_files = self.torrent_info(torrent_id)
				if isinstance(torrent_files, dict) and (torrent_files.get('data') or {}).get('files'): break
				if _attempt == 0: _t.sleep(1.0)
			if not (isinstance(torrent_files, dict) and (torrent_files.get('data') or {}).get('files')):
				log_utils.log('TorBox resolve: no file list for torrent %s' % torrent_id, level=log_utils.LOGWARNING)
				if not self.store_to_cloud: Thread(target=self.delete_torrent, args=(torrent_id,)).start()
				return None
			selected_files = [
				{'link': '%d,%d' % (torrent_id, i['id']), 'filename': i['short_name'], 'size': i['size']}
				for i in torrent_files['data']['files'] if i['short_name'].lower().endswith(tuple(extensions))
			]
			if not selected_files:
				# v2.0.05 -- el torrent ya esta en la cuenta: no dejarlo ahi.
				if not self.store_to_cloud: Thread(target=self.delete_torrent, args=(torrent_id,)).start()
				return None
			if season:
				_all_files = list(selected_files)
				selected_files = [i for i in selected_files if seas_ep_filter(season, episode, i['filename'])]
				# v2.0.08: packs de langhelper numerados a su manera ("054.mkv", "54 seriya")
				_nums = lang_ep_numbers() if not selected_files else []
				if _nums:
					_pool = [i for i in _all_files if not any(x in i['filename'].lower() for x in extras_filtering_list)]
					_pick = loose_episode_pick([i['filename'] for i in _pool], _nums)
					if _pick is not None: selected_files = [_pool[_pick]]
					else: log_utils.log('TorBox resolve: episode %s not found in pack; files: %s' % ('/'.join(str(n) for n in _nums), ' | '.join(i['filename'] for i in _all_files[:8])), level=log_utils.LOGWARNING)
			else:
				# v2.0.13: un Blu-ray completo (BDMV/.m2ts) no se puede reproducir como
				# un fichero. Es un descarte, no un fallo: aviso en el log (antes salia
				# como ERROR con "Exception -> _m2ts_check") y se pasa a la siguiente.
				if self._m2ts_check(selected_files):
					log_utils.log('TorBox: "%s" is a full Blu-ray disc (.m2ts); skipped' % (title or info_hash), level=log_utils.LOGWARNING)
					if torrent_id: Thread(target=self.delete_torrent, args=(torrent_id,)).start() # como en el except de abajo
					return None
				selected_files = [i for i in selected_files if not any(x in i['filename'] for x in extras_filtering_list)]
				selected_files.sort(key=lambda k: k['size'], reverse=True)
			if not selected_files:
				# v2.0.05 -- el torrent ya esta en la cuenta: no dejarlo ahi.
				if not self.store_to_cloud: Thread(target=self.delete_torrent, args=(torrent_id,)).start()
				return None
			file_key = selected_files[0]['link']
			file_url = self.unrestrict_link(file_key)
			if not self.store_to_cloud: Thread(target=self.delete_torrent, args=(torrent_id,)).start()
			return file_url
		except Exception as e:
			log_utils.error('TorBox: Error RESOLVE MAGNET "%s" ' % magnet_url)
			if torrent_id: Thread(target=self.delete_torrent, args=(torrent_id,)).start()
			return None

	def display_magnet_pack(self, magnet_url, info_hash):
		# v1.0.75 -- mismo fallo que se corrigio en resolve_magnet en la v1.0.17:
		# torrent_id se leia en el except antes de existir, y el UnboundLocalError
		# resultante tapaba la causa real.
		torrent_id = None
		try:
			extensions = supported_video_extensions()
			torrent = self.add_magnet(magnet_url)
			if not self._ok(torrent): return None
			torrent_id = torrent['data']['torrent_id']
			torrent_files = self.torrent_info(torrent_id)
			torrent_files = [
				{'link': '%d,%d' % (torrent_id, item['id']), 'filename': item['short_name'], 'size': item['size'] / 1073741824}
				for item in torrent_files['data']['files'] if item['short_name'].lower().endswith(tuple(extensions))
			]
			self.delete_torrent(torrent_id)
			return torrent_files
		except Exception:
			if torrent_id: self.delete_torrent(torrent_id)
			return None

	def add_uncached_torrent(self, magnet_url, pack=False):
		control.busy()
		# v2.0.08: aqui el usuario PIDE descargar algo que no esta en cache, asi que
		# no se manda add_only_if_cached (TorBox respondia DOWNLOAD_NOT_CACHED y no
		# se podia cachear nada). La reproduccion sigue respetando el ajuste.
		result = self.create_transfer(magnet_url, add_only_if_cached=False)
		control.hide()
		if not result: return control.okDialog(title=getLS(40018), message=getLS(33586))
		control.okDialog(title='default', message=getLS(40101) % 'TorBox')
		# v2.0.08: no se intenta reproducir en el acto (antes devolvia True y el router
		# llamaba a playItem con la descarga recien encolada, que aun no esta en cache).
		# Premiumize espera con barra de progreso; TorBox avisa y se reproduce despues.
		return False

	def _m2ts_check(self, folder_items):
		for item in folder_items:
			if item['filename'].endswith('.m2ts'): return True
		return False

	def auth(self):
		"""TorBox OAuth Device Code flow (v1.0.12).
		Mirrors the pattern Umbrella and POV use. Endpoints:
		  GET  /user/auth/device/start?app=luc_kodi -> {device_code, code, verification_url, friendly_verification_url, interval}
		  POST /user/auth/device/token  {device_code} -> {data: {access_token: ...}}
		Falls back to manual API key paste if the user cancels.
		"""
		from urllib.parse import quote_plus
		device_start_url = base_url + '/user/auth/device/start'
		device_token_url = base_url + '/user/auth/device/token'
		try:
			response = requests.get(device_start_url, params={'app': 'luc_kodi'}, timeout=self.timeout)
			response.raise_for_status()
			result = response.json() or {}
			if not result.get('success') or not isinstance(result.get('data'), dict):
				log_utils.log('TorBox auth: device/start did not return success', level=log_utils.LOGWARNING)
				return self._auth_manual_fallback()
		except Exception as e:
			# v1.0.75 -- misma politica que el resto de _request: ninguna excepcion
			# se escribe cruda, aunque esta ruta todavia no lleve credencial.
			try:
				from resources.lib.jacksparrow.client import scrub_url
				_e = scrub_url(str(e))
			except Exception: _e = type(e).__name__
			log_utils.log('TorBox auth: device/start error: %s' % _e, level=log_utils.LOGWARNING)
			return self._auth_manual_fallback()

		data = result['data']
		device_code = data.get('device_code') or ''
		user_code = str(data.get('code') or '')
		verify_url = data.get('friendly_verification_url') or data.get('verification_url') or 'https://tor.box/link'
		interval = int(data.get('interval') or 5)
		expires_in = 600
		if not device_code or not user_code:
			log_utils.log('TorBox auth: response missing device_code/code', level=log_utils.LOGWARNING)
			return self._auth_manual_fallback()

		# Best-effort QR notification (mirrors RealDebrid's auth flow)
		try:
			qr_icon = 'https://api.qrserver.com/v1/create-qr-code/?size=256x256&qzone=1&bgcolor=04bf8a&data=%s' % quote_plus(verify_url)
			control.notification(message=verify_url, icon=qr_icon, time=15000)
		except Exception: pass

		highlight = control.getHighlightColor() if hasattr(control, 'getHighlightColor') else 'FF00FA9A'
		line1 = '[B]LOCATION:[/B] [COLOR %s]%s[/COLOR]' % (highlight, verify_url)
		line2 = '[B]PIN CODE:[/B] [COLOR %s]%s[/COLOR]' % (highlight, user_code)
		line3 = 'Open the link in your browser and enter the PIN'
		body = '%s\n%s\n%s' % (line1, line2, line3)

		progressDialog = control.progressDialog
		progressDialog.create('TorBox Authorization', body)
		progressDialog.update(100, body)

		access_token = None
		time_passed = 0
		try:
			while time_passed < expires_in:
				if progressDialog.iscanceled():
					progressDialog.close()
					return False
				control.sleep(interval * 1000)
				time_passed += interval
				progress_percent = 100 - int(100 * time_passed / expires_in)
				progressDialog.update(progress_percent, body)
				try:
					poll = requests.post(device_token_url, json={'device_code': device_code}, timeout=self.timeout)
					poll_json = poll.json()
				except Exception:
					continue
				# Per POV/Umbrella: success arrives as {success: true, data: {access_token: ...}}
				if isinstance(poll_json, dict) and poll_json.get('success') and isinstance(poll_json.get('data'), dict):
					access_token = poll_json['data'].get('access_token')
					if access_token: break
		finally:
			try: progressDialog.close()
			except Exception: pass

		if not access_token:
			control.notification(title='TorBox', message='Authorization timed out or cancelled', icon=tb_icon)
			return False

		# Persist + lookup customer
		self.api_key = access_token
		try:
			info = self.account_info() or {}
			customer = str((info.get('data') or {}).get('customer') or '')
		except Exception:
			customer = ''
		control.setSetting('torbox.token', access_token)
		control.setSetting('torbox.username', customer)
		try:
			from resources.lib.modules.debrid_state import sync_state
			sync_state()
		except Exception: pass
		control.notification(message='TorBox successfully authorized', icon=tb_icon)
		return True

	def _auth_manual_fallback(self):
		"""If device-code flow fails (network / API change / user preference),
		fall back to the original behavior: paste an API key manually."""
		try:
			if not control.yesnoDialog(
				'TorBox device-code authorization could not start.\n'
				'Would you like to paste an API key manually instead?', '', ''):
				return False
		except Exception:
			pass
		api_key = control.dialog.input('TorBox API Key:')
		if not api_key: return False
		self.api_key = api_key
		try:
			info = self.account_info() or {}
			customer = str((info.get('data') or {}).get('customer') or '')
		except Exception:
			customer = ''
		control.setSetting('torbox.token', api_key)
		control.setSetting('torbox.username', customer)
		control.notification(message='TorBox successfully authorized', icon=tb_icon)
		return True

	def remove_auth(self):
		try:
			self.api_key = ''
			control.setSetting('torbox.token', '')
			control.setSetting('torbox.username', '')
			try:
				from resources.lib.modules.debrid_state import sync_state
				sync_state()
			except Exception:
				pass
			control.notification(title='TorBox', message=40009)
		except: log_utils.error()

	def account_info_to_dialog(self):
		try:
			control.busy()
			# TorBox 2026: plan numbers per https://api-docs.torbox.app/
			# 0 Free / 1 Essential / 2 Pro (Usenet+) / 3 Standard.
			plans = {0: 'Free plan', 1: 'Essential plan', 2: 'Pro plan', 3: 'Standard plan'}
			account_info = self.account_info() or {}
			data = account_info.get('data') or {}
			def _human_bytes(n):
				try: n = float(n)
				except: return str(n)
				for unit in ('B', 'KB', 'MB', 'GB', 'TB', 'PB'):
					if n < 1024.0: return '%.2f %s' % (n, unit)
					n /= 1024.0
				return '%.2f EB' % n
			plan_id = data.get('plan')
			plan_label = plans.get(plan_id, 'Unknown plan (%s)' % plan_id)
			items = []
			items += ['[B]Email[/B]: %s' % data.get('email', '-')]
			items += ['[B]Customer[/B]: %s' % data.get('customer', '-')]
			items += ['[B]Plan[/B]: %s' % plan_label]
			items += ['[B]Expires[/B]: %s' % data.get('premium_expires_at', '-')]
			# v1.0.75 -- los demas debrid muestran los dias restantes; TorBox tenia
			# la propiedad days_remaining escrita y sin usar. Se reaprovecha el dato
			# ya descargado en vez de repetir la peticion a /user/me.
			try:
				import datetime as _dt
				_exp = _dt.datetime.strptime(str(data.get('premium_expires_at'))[:10], '%Y-%m-%d')
				items += [getLS(40042) % (_exp - _dt.datetime.today()).days]
			except Exception: pass
			td = data.get('total_downloaded')
			if td is not None:
				items += ['[B]Downloaded[/B]: %s' % _human_bytes(td)]
			control.hide()
			return control.selectDialog(items, 'TorBox')
		except: log_utils.error()

	def user_cloud(self, request_id=None):
		url = self.explore % request_id if request_id else self.history
		return self._GET(url)

	def user_cloud_usenet(self, request_id=None):
		url = self.explore_usenet % request_id if request_id else self.history_usenet
		return self._GET(url)

	def user_cloud_clear(self):
		if not control.yesnoDialog(getLS(32056), '', ''): return
		data = {'all': True, 'operation': 'delete'}
		self._POST(self.remove, json=data)
		self._POST(self.remove_usenet, json=data)

	def user_cloud_to_listItem(self):
		sysaddon, syshandle = 'plugin://plugin.video.luc_kodi/', int(argv[1])
		quote_plus = requests.utils.quote
		folder_str, deleteMenu = getLS(40046).upper(), getLS(40050)
		file_str, downloadMenu = getLS(40047).upper(), getLS(40048)
		folders = []
		try: folders += [{**i, 'mediatype': 'torent'} for i in self.user_cloud()['data'] if i['download_finished']]
		except: pass
		try: folders += [{**i, 'mediatype': 'usenet'} for i in self.user_cloud_usenet()['data'] if i['download_finished']]
		except: pass
		folders.sort(key=lambda k: k['updated_at'], reverse=True)
		for count, item in enumerate(folders, 1):
			try:
				cm = []
				folder_name = string_tools.strip_non_ascii_and_unprintable(item['name'])
				status_str = '[COLOR %s]%s[/COLOR]' % (control.getHighlightColor(), item['download_state'].capitalize())
				cm.append((deleteMenu % 'Torrent', 'RunPlugin(%s?action=tb_DeleteUserTorrent&id=%s&mediatype=%s&name=%s)' %
					(sysaddon, item['id'], item['mediatype'], quote_plus(folder_name))))
				label = '%02d | [B]%s[/B] | [B]%s[/B] | [I]%s [/I]' % (count, status_str, folder_str, folder_name)
				url = '%s?action=tb_BrowseUserTorrents&id=%s&mediatype=%s' % (sysaddon, item['id'], item['mediatype'])
				item = control.item(label=label, offscreen=True)
				attach_cm(item, cm)
				item.setArt({'icon': tb_icon, 'poster': tb_icon, 'thumb': tb_icon, 'fanart': addonFanart, 'banner': tb_icon})
				item.setInfo(type='video', infoLabels='')
				control.addItem(handle=syshandle, url=url, listitem=item, isFolder=True)
			except: log_utils.error()
		control.content(syshandle, 'files')
		control.directory(syshandle, cacheToDisc=True)

	def browse_user_torrents(self, folder_id, mediatype):
		sysaddon, syshandle = 'plugin://plugin.video.luc_kodi/', int(argv[1])
		quote_plus = requests.utils.quote
		extensions = supported_video_extensions()
		file_str, downloadMenu = getLS(40047).upper(), getLS(40048)
		files = self.user_cloud_usenet(folder_id) if mediatype == 'usenet' else self.user_cloud(folder_id)
		video_files = [i for i in files['data']['files'] if i['short_name'].lower().endswith(tuple(extensions))]
		for count, item in enumerate(video_files, 1):
			try:
				cm = []
				name = string_tools.strip_non_ascii_and_unprintable(item['short_name'])
				size = item['size']
				display_size = float(int(size)) / 1073741824
				label = '%02d | [B]%s[/B] | %.2f GB | [I]%s [/I]' % (count, file_str, display_size, name)
				item = '%d,%d' % (int(folder_id), item['id'])
				url = '%s?action=play_URL&url=%s&caller=torbox&mediatype=%s&type=unrestrict' % (sysaddon, item, mediatype)
				cm.append((downloadMenu, 'RunPlugin(%s?action=download&name=%s&image=%s&url=%s&caller=torbox&mediatype=%s&type=unrestrict)' %
					(sysaddon, quote_plus(name), quote_plus(tb_icon), item, mediatype)))
				item = control.item(label=label, offscreen=True)
				attach_cm(item, cm)
				item.setArt({'icon': tb_icon, 'poster': tb_icon, 'thumb': tb_icon, 'fanart': addonFanart, 'banner': tb_icon})
				item.setInfo(type='video', infoLabels='')
				control.addItem(handle=syshandle, url=url, listitem=item, isFolder=False)
			except: log_utils.error()
		control.content(syshandle, 'files')
		control.directory(syshandle, cacheToDisc=True)

	def delete_user_torrent(self, request_id, mediatype, name):
		if not control.yesnoDialog(getLS(40050) % '?\n' + name, '', ''): return
		result = self.delete_usenet(request_id) if mediatype == 'usenet' else self.delete_torrent(request_id)
		if self._ok(result):
			control.notification(message='TorBox: %s was removed' % name, icon=tb_icon)
			control.refresh()
