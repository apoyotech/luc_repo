# -*- coding: utf-8 -*-
"""
	jacksparrowscrapers Project - Newznab scraper (custom Usenet indexer)

	Scraper GENERICO de indexers Newznab. Agnostico al indexer: el usuario aporta
	SU PROPIO indexer Newznab (NZBGeek, DrunkenSlug, NZBFinder, NZBHydra2,
	Prowlarr con endpoint Newznab, o incluso un puente Easynews->Newznab).

	    provider.newznab   -> on/off del scraper (patron estandar del loader)
	    newznab.url        -> URL base del indexer (…/api)   [Setup Wizard]
	    newznab.apikey     -> API key del indexer            [Setup Wizard]
	    newznab.pm_autodelete -> borrar el NZB de la nube tras reproducir
	    newznab.pm_stall_secs -> abandonar si la descarga no avanza (seg.)

	──────────────────────────────────────────────────────────────────────
	SEPARACION DE CAPAS (igual que un tracker torrent tipo Knaben/DMM)
	──────────────────────────────────────────────────────────────────────
	  - CAPA BUSQUEDA (este modulo): consulta la API Newznab y devuelve
	    NZBs. Un NZB es un puntero (lista de Message-IDs de Usenet), NO un
	    stream reproducible. Emitimos items 'source':'usenet' con la URL
	    del .nzb en item['url'] y hash = md5(nzb_url).
	  - CAPA RESOLUCION (debrid): el NZB entra en sources.sourcesResolve(),
	    que lo enruta a Premiumize.resolve_nzb(). Premiumize descarga y
	    reensambla en su nube y devuelve una URL HTTP directa. Desde la
	    v2.0.13 tambien TorBox Pro (debrid/torbox.py resolve_nzb).

	v2.0.24: tambien EASYNEWS por NNTP (usenet_easynews.py + usenet_stream.py):
	    streaming al momento sin debrid; interruptor por servicio
	    (newznab.use_easynews / use_premiumize / use_torbox).
	v2.0.13: puede descargarlo TAMBIEN TorBox Pro (ajuste newznab.debrid), ahora
	que TorBox cerro su buscador y torboxnews se ha retirado.

	v1.0.59: este scraper esta ATADO a Premiumize. Antes se podia elegir
	TorBox, pero esa ruta exige el plan de 10 $/mes de TorBox (Usenet+NNTP
	viene tachado en los planes de 3 $ y 5 $), asi que no aportaba nada
	utilizable para un indexer propio. (Vuelve en la v2.0.13, ver arriba.)

	NO fijamos 'cached_remote': Premiumize no tiene cache-check barato por
	NZB, asi que sources.py presenta todos los items y la resolucion ocurre
	bajo demanda en resolve_nzb() via /transfer/create.

	API Newznab (estandar RSS/XML, soportado por TODOS los indexers; el
	output JSON no es universal):
	  Movie: {base}?t=movie&cat=2000&imdbid=<digits>&apikey=<key>
	  TV:    {base}?t=tvsearch&cat=5000&q=<title>&season=<s>&ep=<e>&apikey=<key>
	  Fallback generico: {base}?t=search&q=<terms>&apikey=<key>
	  NZB:   item/enclosure@url  (o item/link)   -> descarga del .nzb
	         item/newznab:attr[name=size]        -> tamano en bytes
"""

import hashlib
import json
import os
import re
import threading
import time
import xml.etree.ElementTree as ET
from urllib.parse import urlencode

from resources.lib.jacksparrow import client
from resources.lib.jacksparrow import source_utils
from resources.lib.jacksparrow.control import setting as getSetting


# Categorias Newznab estandar
_CAT_MOVIE = '2000'
_CAT_TV    = '5000'


def _normalize_newznab_url(raw):
	"""
	Devuelve la URL base del endpoint Newznab lista para inyectar params.

	Acepta lo que el usuario tenga a mano y lo normaliza a '<host>/api':
	  - 'https://indexer.tld'                 -> 'https://indexer.tld/api'
	  - 'https://indexer.tld/'                -> 'https://indexer.tld/api'
	  - 'https://indexer.tld/api'             -> 'https://indexer.tld/api'
	  - 'https://indexer.tld/api?t=caps&...'  -> 'https://indexer.tld/api'
	  - 'https://indexer.tld/newznab/api'     -> 'https://indexer.tld/newznab/api'
	  - pega el manifest/URL con apikey embebida -> se descarta la query

	Si el usuario NO pone esquema, se asume https://.
	"""
	if not raw:
		return ''
	url = raw.strip().strip('"').strip("'")
	if not url:
		return ''
	# Quitar cualquier query string (?t=...&apikey=...); la reconstruimos.
	url = url.split('?', 1)[0].split('#', 1)[0]
	# Esquema por defecto
	if not url.lower().startswith(('http://', 'https://')):
		url = 'https://' + url
	# Quitar slashes finales
	url = url.rstrip('/ \t\n\r')
	if not url:
		return ''
	# Asegurar que termina en /api (endpoint Newznab). Si el path ya
	# incluye '/api' en cualquier posicion (p.ej. /newznab/api) lo dejamos;
	# si no, lo anadimos.
	lower = url.lower()
	if lower.endswith('/api'):
		return url
	if '/api/' in lower or lower.endswith('/api'):
		return url
	return url + '/api'


def _apikey():
	return (getSetting('newznab.apikey') or '').strip()


def _base_url():
	return _normalize_newznab_url(getSetting('newznab.url') or '')


# v2.0.32 — varios indexers a la vez (auditoria Usenet del 11-nov-2026, P3). Con
# uno solo, si no tiene el release o te limita no hay segunda fuente. Cada hueco
# es URL + clave; se preguntan todos en paralelo y se quitan los duplicados
# (el mismo release en dos indexers trae NZB distintos: se compara por nombre y
# tamano). Cualquier indexer Newznab vale: altHUB, NinjaCentral, DrunkenSlug,
# NZBFinder, NZBPlanet, SearchNZB, nzb.life...
_SLOTS = (('newznab.url', 'newznab.apikey'), ('newznab.url2', 'newznab.apikey2'), ('newznab.url3', 'newznab.apikey3'))


def _indexers():
	out, seen = [], set()
	for u, k in _SLOTS:
		base = _normalize_newznab_url(getSetting(u) or '')
		key = (getSetting(k) or '').strip()
		if base and key and base not in seen:
			seen.add(base)
			out.append((base, key))
	return out


def _label(base):
	try: return base.split('://', 1)[-1].split('/', 1)[0] or 'newznab'
	except Exception: return 'newznab'


# Cuota: los indexers suspenden cuentas que siguen preguntando pasado el cupo.
# Se lee newznab:apilimits de cada respuesta y, al llegar al 90 % del cupo diario
# de busquedas, o si el indexer dice que se acabo (error 500/501/429), ese indexer
# descansa una hora. Los otros siguen. Vale para la sesion de Kodi.
QUOTA_SHARE = 0.9
REST_SECS = 3600
_PAUSE_PROP = 'luc_kodi.newznab.rest.%s'
_LIMIT_CODES = ('429', '500', '501')
# v2.0.32 (informe de 12-nov-2026, como Dex Hub): ante el indexer, luc_kodi
# dice quien es. Antes la API iba con un navegador al azar; el NZB ya iba con
# este mismo nombre. Los indexers permiten (y algunos piden) apps con nombre.
INDEXER_UA = 'luc_kodi for Kodi'
# v2.0.33 (kodi.log del 12-nov-2026, decision de Lucian): 1,5 s -> 3 s. Con 1,5 s, 4 de 5 listas
# salian con 0 verificados: comprobar los 8 primeros tardaba 1,6-2,6 s. Si los 8 buenos llegan antes,
# la espera acaba antes; lo que no llegue sigue detras como hasta ahora.
HEALTH_SEARCH_WAIT = 3.0   # lo que la busqueda espera a la salud de Easynews (el resto sigue detras)
_LEFT_PROP = 'luc_kodi.newznab.grableft.%s'   # lo lee usenet_easynews (salud)


def _resting(label):
	try:
		from resources.lib.jacksparrow.control import homeWindow
		return float(homeWindow.getProperty(_PAUSE_PROP % label) or 0) > time.time()
	except Exception:
		return False


def _rest(label, why):
	try:
		from resources.lib.jacksparrow.control import homeWindow
		homeWindow.setProperty(_PAUSE_PROP % label, str(int(time.time() + REST_SECS)))
		from resources.lib.jacksparrow import log_utils
		log_utils.log('NEWZNAB: %s rests for 1 h (%s)' % (label, why), level=log_utils.LOGINFO)
	except Exception:
		pass


def _check_quota(label, body):
	text = body if isinstance(body, str) else (body or b'').decode('utf-8', 'replace')
	m = re.search(r'<error\b[^>]*\bcode="(\d+)"', text[:2048], re.I)
	if m and m.group(1) in _LIMIT_CODES:
		_rest(label, 'indexer says the limit is reached, code %s' % m.group(1))
		return
	try:
		from resources.lib.modules import usenet_stats
		lim = usenet_stats.parse_limits(text) or {}
	except Exception:
		lim = {}
	cur, top = lim.get('apicurrent'), lim.get('apimax')
	if cur is not None and top and cur >= QUOTA_SHARE * top:
		_rest(label, '%d of %d searches used today' % (cur, top))
		return
	# v2.0.32: grabs (NZB) que quedan hoy; la salud de Easynews deja unos
	# cuantos sin tocar para reproducir, y sin ninguno el indexer no sirve
	gcur, gtop = lim.get('grabcurrent'), lim.get('grabmax')
	if gcur is not None and gtop:
		left = max(0, gtop - gcur)
		try:
			from resources.lib.jacksparrow.control import homeWindow
			homeWindow.setProperty(_LEFT_PROP % label, '%d|%d' % (left, int(time.time())))
		except Exception:
			pass
		if left <= 0:
			_rest(label, 'all %d NZB downloads used today' % gtop)


def _short_name(label):
	"""v2.0.32: nombre corto del indexer para la lista de fuentes: api.althub.co.za
	-> ALTHUB, api.nzbgeek.info -> NZBGEEK, api.nzb.life -> NZB.LIFE."""
	host = re.sub(r'^(api|www)\.', '', (label or '').lower().split(':')[0])
	if not host or host == 'localhost' or re.match(r'^[\d.]+$', host):
		return 'LOCAL'   # Prowlarr / NZBHydra en la red de casa
	parts = host.split('.')
	name = parts[0] if len(parts[0]) >= 4 or len(parts) < 2 else '%s.%s' % (parts[0], parts[1])
	return (name or 'newznab').upper()


def _dedupe_key(item):
	name = re.sub(r'[^a-z0-9]', '', str(item.get('name') or '').lower())
	try: size = round(float(item.get('size') or 0), 1)
	except Exception: size = 0
	return name, size


# v2.0.33 — lo que sabe buscar cada indexer (t=caps). Antes se buscaba igual en
# todos: series por titulo y peliculas por imdbid, lo entendiera o no el
# indexer. Ahora se lee su caps (una vez por semana, en <perfil>/usenet/caps.json)
# y se busca primero por el id que el indexer anuncia (TheTVDB, IMDb, TVmaze),
# pidiendo de una vez los resultados que permite (limits max). Si el id da pocos
# resultados se pregunta tambien por el titulo, porque hay releases que el
# indexer no tiene enlazados a la serie o la pelicula. Un indexer que no anuncia
# un parametro no lo recibe (antes: una consulta perdida por pelicula).
CAPS_TTL = 7 * 86400       # caps sano
CAPS_RETRY = 86400         # caps que no se pudo leer: se vuelve a probar al dia
CAPS_TIMEOUT = 6
ID_FEW = 3                 # con menos resultados por id, tambien por titulo
LIMIT_TOP = 100            # lo que se pide como maximo aunque el indexer de mas
_caps_lock = threading.Lock()
_caps_mem = {}


def parse_caps(text):
	"""{'tv': [params], 'movie': [params], 'tv_ok': bool, 'movie_ok': bool,
	'max': int} de una respuesta t=caps, o None si no es un caps."""
	if not text:
		return None
	raw = text.encode('utf-8') if isinstance(text, str) else text
	if b'<!ENTITY' in raw[:4096].upper():
		return None   # como con los NZB (usenet_core.parse_nzb): sin entidades
	try:
		root = ET.fromstring(raw)
	except Exception:
		return None
	if _localname(root.tag).lower() != 'caps':
		return None
	out = {'tv': [], 'movie': [], 'tv_ok': True, 'movie_ok': True, 'max': 0}
	for el in root.iter():
		ln = _localname(el.tag).lower()
		attrs = dict((k.lower(), v) for k, v in el.attrib.items())
		if ln == 'limits':
			try: out['max'] = int(attrs.get('max') or 0)
			except ValueError: pass
		elif ln in ('tv-search', 'movie-search'):
			kind = 'tv' if ln == 'tv-search' else 'movie'
			out[kind + '_ok'] = (attrs.get('available') or 'yes').strip().lower() != 'no'
			params = [p.strip().lower() for p in (attrs.get('supportedparams') or '').split(',') if p.strip()]
			out[kind] = params
	return out


def _caps_file():
	from resources.lib.jacksparrow.control import dataPath
	d = os.path.join(dataPath, 'usenet')
	if not os.path.isdir(d):
		try: os.makedirs(d)
		except OSError: pass
	return os.path.join(d, 'caps.json')


def _caps_load():
	try:
		with open(_caps_file(), 'r') as f:
			return json.load(f)
	except Exception:
		return {}


def _caps_store(label, entry):
	try:
		with _caps_lock:
			data = _caps_load()
			data[label] = entry
			tmp = _caps_file() + '.part'
			with open(tmp, 'w') as f:
				json.dump(data, f)
			os.replace(tmp, _caps_file())
	except Exception:
		pass


def _caps(base, key, label):
	"""Caps del indexer (dict de parse_caps) o None si no se sabe."""
	now = time.time()
	with _caps_lock:
		hit = _caps_mem.get(label)
	if hit is None:
		with _caps_lock:
			hit = _caps_load().get(label)
	if hit:
		age = now - float(hit.get('ts') or 0)
		if hit.get('caps') and age < CAPS_TTL:
			with _caps_lock: _caps_mem[label] = hit
			return hit['caps']
		if not hit.get('caps') and age < CAPS_RETRY:
			with _caps_lock: _caps_mem[label] = hit
			return None
	caps = None
	try:
		body = client.request(_build_query(base, {'t': 'caps', 'apikey': key}), timeout=CAPS_TIMEOUT,
							  headers={'User-Agent': INDEXER_UA})
		caps = parse_caps(body)
	except Exception:
		caps = None
	entry = {'ts': int(now), 'caps': caps}
	with _caps_lock: _caps_mem[label] = entry
	_caps_store(label, entry)
	try:
		from resources.lib.jacksparrow import log_utils
		if caps:
			log_utils.log('NEWZNAB: %s searches TV by %s and films by %s, up to %s results (caps)'
						  % (_short_name(label), ', '.join(caps['tv']) or 'title' if caps['tv_ok'] else 'nothing (TV search off)',
							 ', '.join(caps['movie']) or 'title' if caps['movie_ok'] else 'nothing (film search off)',
							 caps['max'] or 'default'), level=log_utils.LOGINFO)
		else:
			log_utils.log('NEWZNAB: %s gave no caps; searching as before' % _short_name(label), level=log_utils.LOGDEBUG)
	except Exception:
		pass
	return caps


def _merge(first, more):
	"""Une dos listas de resultados sin repetir el mismo NZB."""
	seen = set(e.get('nzb') for e in first or [])
	return list(first or []) + [e for e in (more or []) if e.get('nzb') not in seen]


def _build_query(base, params):
	"""Construye la URL final. Los valores SI van url-encoded (los titulos
	llevan espacios/acentos y Newznab lo exige). El apikey se anade al final."""
	pairs = urlencode(params)
	return '%s?%s' % (base, pairs)


def _localname(tag):
	"""Devuelve el nombre local de un tag ElementTree quitando el namespace
	'{http://...}attr' -> 'attr'."""
	return tag.split('}')[-1] if '}' in tag else tag


def _parse_rfc2822(date_str):
	"""Epoch (int) de una fecha RFC-2822 Newznab ('Wed, 02 Oct 2024 13:00:00
	+0000'). Es el formato de <pubDate> y del attr 'usenetdate'. 0 si falla."""
	if not date_str:
		return 0
	try:
		import email.utils as _eut
		tt = _eut.parsedate_tz(date_str.strip())
		if not tt:
			return 0
		return int(_eut.mktime_tz(tt))
	except Exception:
		return 0


def _age_from_epoch(posted_epoch):
	"""(age_days:int, badge:str) desde un epoch de posteo. Salud en Usenet:
	no hay seeders; la edad indica exposicion a takedowns/retencion. Badge
	compacto para la columna info: '14h' / '3d' / '1.2y'. ('', -1) si no hay
	fecha."""
	if not posted_epoch:
		return -1, ''
	try:
		import time as _t
		secs = max(0, int(_t.time()) - int(posted_epoch))
		hours = secs // 3600
		days = secs // 86400
		if hours < 48:
			return int(days), '%dh' % max(hours, 1)
		if days < 365:
			return int(days), '%dd' % days
		return int(days), '%.1fy' % (days / 365.25)
	except Exception:
		return -1, ''


def _parse_newznab_xml(xml_text):
	"""
	Parsea la respuesta RSS/XML de Newznab y devuelve una lista de dicts:
	  {'title':..., 'nzb':..., 'size':int, 'grabs':int, 'guid':...}

	Robusto a namespaces (newznab:attr). Devuelve [] si no parsea.
	"""
	out = []
	if not xml_text:
		return out
	try:
		root = ET.fromstring(xml_text.encode('utf-8') if isinstance(xml_text, str) else xml_text)
	except Exception:
		# Algunos indexers devuelven un <error code=.. description=..>
		return out

	# Buscar todos los <item> sin depender del prefijo de namespace
	for item in root.iter():
		if _localname(item.tag) != 'item':
			continue
		title = ''
		nzb_url = ''
		size = 0
		grabs = 0
		guid = ''
		posted = 0        # epoch de posteo en Usenet (attr usenetdate > pubDate)
		pubdate = 0
		password = False  # release protegido con contrasena -> inservible
		tvdbid = ''       # v2.0.31: serie a la que el indexer asocia el release
		for child in list(item):
			ln = _localname(child.tag)
			if ln == 'title':
				title = (child.text or '').strip()
			elif ln == 'pubDate':
				pubdate = _parse_rfc2822(child.text or '')
			elif ln == 'link' and not nzb_url:
				# link puede ser el .nzb de descarga; enclosure tiene prioridad
				link_txt = (child.text or '').strip()
				if link_txt.lower().startswith('http'):
					nzb_url = link_txt
			elif ln == 'enclosure':
				enc_url = child.attrib.get('url') or ''
				if enc_url.lower().startswith('http'):
					nzb_url = enc_url  # enclosure gana sobre <link>
				try:
					if child.attrib.get('length'):
						size = int(child.attrib.get('length'))
				except Exception:
					pass
			elif ln == 'guid' and not guid:
				guid = (child.text or '').strip()
			elif ln == 'attr':
				name = (child.attrib.get('name') or '').lower()
				val = child.attrib.get('value') or ''
				if name == 'size' and val:
					try: size = int(val)
					except Exception: pass
				elif name == 'grabs' and val:
					try: grabs = int(val)
					except Exception: pass
				elif name == 'usenetdate' and val:
					# Fecha real de posteo en Usenet (mas fiable que pubDate,
					# que en algunos indexers es la fecha de indexacion).
					posted = _parse_rfc2822(val) or posted
				elif name == 'password' and val:
					# '0' = sin password; '1'/'2' = protegido (rar con pass).
					password = val.strip() not in ('', '0')
				elif name == 'guid' and val and not guid:
					guid = val
				elif name == 'tvdbid' and val:
					tvdbid = val.strip()
		if not title or not nzb_url:
			continue
		if not posted:
			posted = pubdate
		out.append({'title': title, 'nzb': nzb_url, 'size': size, 'grabs': grabs,
					'guid': guid, 'posted': posted, 'password': password, 'tvdbid': tvdbid})
	return out


class source:
	timeout = 20
	priority = 3
	pack_capable = True
	hasMovies = True
	hasEpisodes = True

	def __init__(self):
		self.user_agent = 'luc_kodi for Kodi'
		self.base = _base_url()
		self.key = _apikey()
		self.language = ['en']
		self.min_seeders = -2
		self.caps = None        # v2.0.33: lo que anuncia el indexer (t=caps)
		# Etiqueta legible del indexer (host) para la columna 'tracker'
		try:
			host = self.base.split('://', 1)[-1].split('/', 1)[0]
			self.indexer_label = host or 'newznab'
		except Exception:
			self.indexer_label = 'newznab'

	# --- Fetch ---------------------------------------------------------------

	def _fetch(self, params):
		"""Ejecuta una consulta Newznab y devuelve la lista de dicts parseados.
		Enmascara el apikey en el log."""
		if not self.base or not self.key:
			return []
		if _resting(self.indexer_label):
			return []
		params = dict(params)
		top = (self.caps or {}).get('max') or 0
		if top and 'limit' not in params:
			params['limit'] = str(min(int(top), LIMIT_TOP))   # v2.0.33: todo de una vez
		params['apikey'] = self.key
		url = _build_query(self.base, params)
		from resources.lib.jacksparrow import log_utils
		try:
			masked = url.replace(self.key, '<APIKEY>') if self.key else url
			log_utils.log('NEWZNAB: GET %s' % masked, level=log_utils.LOGDEBUG)
		except Exception:
			pass
		try:
			t0 = time.time()
			body = client.request(url, timeout=self.timeout, headers={'User-Agent': INDEXER_UA})
			if not body:
				log_utils.log('NEWZNAB: %s gave no answer in %.1fs' % (_short_name(self.indexer_label), time.time() - t0),
							  level=log_utils.LOGDEBUG)
				return []
			_check_quota(self.indexer_label, body)
			found = _parse_newznab_xml(body)
			log_utils.log('NEWZNAB: %s %d results in %.1fs' % (_short_name(self.indexer_label), len(found), time.time() - t0),
						  level=log_utils.LOGDEBUG)
			# v2.0.25: cada llamada a la API y, si el indexer los manda
			# (newznab:apilimits), sus contadores de API y grabs: Tools > Usenet report
			try:
				from resources.lib.modules import usenet_stats
				usenet_stats.note_search(self.indexer_label, body, len(found))
			except Exception:
				pass
			return found
		except Exception:
			source_utils.scraper_error('NEWZNAB')
			return []

	def _supports(self, kind, param):
		"""v2.0.33: True/False segun el caps del indexer; None si no hay caps."""
		c = self.caps
		if not c:
			return None
		if not c.get(kind + '_ok', True):
			return False
		return param in (c.get(kind) or [])

	def _search_ok(self, kind):
		"""False solo si el caps dice que ese tipo de busqueda esta apagado."""
		return not self.caps or self.caps.get(kind + '_ok', True)

	def _fetch_by_tvdb(self, params, tvdb):
		"""v2.0.31: tvsearch por el id de TheTVDB en vez de por el titulo. Los
		programas diarios se publican con un nombre corto (la busqueda de
		"The Tonight Show Starring Jimmy Fallon" no encontraba los
		"Jimmy.Fallon.2026.09.21...": kodi.log del 11-nov-2026). Solo valen los
		resultados que el propio indexer asocia a ESA serie (attr tvdbid): un
		indexer que no entiende el parametro devuelve lo ultimo publicado, y eso
		se descarta."""
		if not tvdb:
			return []
		params = dict(params, t='tvsearch', cat=_CAT_TV, tvdbid=tvdb, extended='1')
		found = self._fetch(params) or []
		if self._supports('tv', 'tvdbid'):
			# v2.0.33: el indexer anuncia tvdbid; un resultado sin el attr tambien
			# vale (el titulo y el episodio se siguen comprobando en _make_item)
			return [e for e in found if e.get('tvdbid') in (tvdb, '')]
		return [e for e in found if e.get('tvdbid') == tvdb]

	# --- Item builder --------------------------------------------------------

	@staticmethod
	def _episodes_only():
		"""v1.0.61: descartar packs de temporada/serie en las busquedas de un
		solo episodio.

		Con TORRENTS un pack no molesta: el debrid ya lo tiene cacheado y
		extrae el fichero al momento. Con NZB es al reves: Premiumize tiene
		que DESCARGAR el pack entero de Usenet a su nube antes de darte nada.
		Medido en pruebas reales: un pack de temporada en 2160p son ~113 GB y
		~29 minutos, frente a 2-8 GB de un episodio suelto. Ademas confunde,
		porque en la lista el pack no se distingue a simple vista del episodio.

		Por defecto ACTIVADO. Se desactiva en Usenet -> Search and source list (v2.0.33).
		"""
		return getSetting('newznab.episodes_only') in ('', 'true')

	def _make_item(self, entry, title, aliases, hdlr, year, imdb,
			episode_title, total_seasons, season, pack_mode,
			undesirables, check_foreign_audio, absolute=None):
		"""Convierte un dict Newznab en un item de luc_kodi (o None si se
		descarta). source='usenet'."""
		nzb_url = entry.get('nzb') or ''
		file_title = entry.get('title') or ''
		if not nzb_url or not file_title:
			return None
		# Releases con password (attr password != 0) son inservibles para
		# streaming: el debrid no puede extraer el rar. Fuera directamente.
		if entry.get('password'):
			return None
		# hash = md5 del enlace nzb (igual que TorBox check_cache_usenet)
		hash_val = hashlib.md5(nzb_url.encode('utf-8')).hexdigest()
		name = source_utils.clean_name(file_title)

		package, episode_start, episode_end, last_season = None, 0, 0, None

		if pack_mode:
			# En modo pack aplicamos los filtros de temporada/serie completa.
			valid = False
			if total_seasons is not None:
				valid, last_season = source_utils.filter_show_pack(
					title, aliases, imdb, year, season, name, total_seasons)
				if valid:
					package = 'show'
			if not package:
				valid, episode_start, episode_end = source_utils.filter_season_pack(
					title, aliases, year, season, name)
				if not valid:
					return None
				package = 'season'
		elif absolute:
			# Anime by absolute number: only a release named for that exact
			# episode counts; packs come from their own search.
			if not source_utils.check_title_absolute(title, aliases, name, absolute, year):
				return None
		else:
			tvdb = getattr(self, '_tvdb', '')
			if tvdb and entry.get('tvdbid') == tvdb:
				# v2.0.31: el indexer dice que el release es de ESTA serie: su propio
				# nombre de serie ('Jimmy Fallon') vale como alias. El episodio o la
				# fecha se siguen comprobando.
				try:
					m_ep = source_utils._find_episode(name, hdlr)[0]
					if m_ep and m_ep.start() > 0:
						aliases = list(source_utils.aliases_to_array(aliases) or []) + [name[:m_ep.start()]]
				except Exception: pass
			if not source_utils.check_title(title, aliases, name, hdlr, year):
				# El titulo no casa con este episodio concreto. Podria ser un
				# pack que lo contenga; con NZB eso significa bajar la temporada
				# entera, asi que por defecto se descarta.
				if self._episodes_only():
					return None
				# Puede ser un pack que cubra este episodio (single-file season)
				if total_seasons is None:
					return None
				valid, last_season = source_utils.filter_show_pack(
					title, aliases, imdb, year, season, name, total_seasons)
				if not valid:
					valid, episode_start, episode_end = source_utils.filter_season_pack(
						title, aliases, year, season, name)
					if not valid:
						return None
					package = 'season'
				else:
					package = 'show'

		name_info = source_utils.info_from_name(name, title, year, hdlr, episode_title)
		if source_utils.remove_lang(name_info, check_foreign_audio):
			return None
		if undesirables and source_utils.remove_undesirables(name_info, undesirables):
			return None

		try:
			seeders = int(entry.get('grabs') or 0)
			if self.min_seeders > seeders:
				return None
		except Exception:
			seeders = 0

		quality, info = source_utils.get_release_quality(name_info, nzb_url)
		info = list(info) if info else []
		info += [t for t in source_utils.get_extra_tags(name) if t not in info]
		try:
			size = '%.2f GB' % (float(entry.get('size') or 0) / 1073741824)
			dsize, isize = source_utils._size(size)
			if isize:
				info.insert(0, isize)
		except Exception:
			dsize = 0
		# Salud Usenet: edad del posteo (proxy de retencion/takedowns) como
		# badge compacto justo despues del tamano, p.ej. "4.2 GB | AGE 3d".
		age_days, age_badge = _age_from_epoch(entry.get('posted') or 0)
		if age_badge:
			info.insert(1 if info else 0, 'AGE %s' % age_badge)
		info = ' | '.join(info)

		item = {
			'source': 'usenet', 'language': 'en', 'direct': False, 'debridonly': True,
			'provider': 'newznab', 'hash': hash_val, 'url': nzb_url,
			'name': name, 'name_info': name_info,
			'quality': quality, 'info': info, 'size': dsize, 'seeders': seeders,
			'age_days': age_days,
			'tracker': self.indexer_label,
			# v2.0.32: de que indexer viene, ahora que puede haber hasta tres. La
			# lista de fuentes lo pone en el hueco del proveedor (NEWZNAB): kodi.log
			# del 11-nov-2026, AltHUB aportaba 39 de 119 resultados y no se veia.
			'indexer': _short_name(self.indexer_label),
			'nzb_host': self.indexer_label,
		}
		if package:
			item['package'] = package
		if package == 'show':
			# v1.0.60 FIX: antes era `if package == 'show' and last_season:`.
			# Cuando filter_show_pack() validaba el pack pero devolvia
			# last_season = 0 o None, el item salia con package='show' pero SIN
			# la clave 'last_season'. sources.py hace entonces
			#   i.get('last_season') >= int(season)
			# -> TypeError: '>=' not supported between NoneType and int,
			# y TODOS los resultados de show-pack del indexer se perdian (el
			# except los tragaba en silencio). Ademas quedaban cacheados en
			# rel_src, asi que el fallo se repetia en cada busqueda posterior.
			# Se replica lo que hace torrentio: la clave se fija SIEMPRE, con
			# total_seasons como respaldo.
			item['last_season'] = last_season or total_seasons or 0
		if episode_start:
			item['episode_start'] = episode_start
			item['episode_end'] = episode_end
		return item

	# --- Public API ----------------------------------------------------------

	def _sources_one(self, data, hostDict):
		sources = []
		if not data:
			return sources
		if not self.base or not self.key:
			return sources
		try:
			is_episode = 'tvshowtitle' in data
			title = data['tvshowtitle'] if is_episode else data['title']
			title = title.replace('&', 'and').replace('Special Victims Unit', 'SVU').replace('/', ' ')
			aliases = data['aliases']
			year = data['year']
			imdb = data['imdb']
			imdb_digits = (imdb or '').replace('tt', '')
			episode_title = data['title'] if is_episode else None
			total_seasons = data.get('total_seasons') if is_episode else None   # v2.0.32: no siempre viene (KeyError del 12-nov-2026)
			if 'timeout' in data:
				self.timeout = int(data['timeout'])
			self.caps = _caps(self.base, self.key, self.indexer_label)

			if is_episode:
				season = data['season']
				episode = data['episode']
				hdlr = 'S%02dE%02d' % (int(season), int(episode))
				tvdb = str(data.get('tvdb') or '').strip()
				if not tvdb.isdigit() or tvdb == '0': tvdb = ''
				self._tvdb = tvdb
				sea, epi = str(int(season)), str(int(episode))
				# v2.0.33: primero por el id que anuncia el indexer (caps)
				entries = []
				if tvdb and self._supports('tv', 'tvdbid'):
					entries = self._fetch_by_tvdb({'season': sea, 'ep': epi}, tvdb)
				elif imdb_digits and self._supports('tv', 'imdbid'):
					entries = self._fetch({'t': 'tvsearch', 'cat': _CAT_TV, 'imdbid': imdb_digits,
										   'season': sea, 'ep': epi})
				# tvsearch por titulo + temporada/episodio (la primaria de antes)
				if len(entries) < ID_FEW and self._search_ok('tv'):
					entries = _merge(entries, self._fetch({
						't': 'tvsearch', 'cat': _CAT_TV,
						'q': title, 'season': sea, 'ep': epi,
					}))
				if not entries and tvdb and self._supports('tv', 'tvdbid') is None:
					# v2.0.31: el titulo no da nada; la misma busqueda por id de serie
					entries = self._fetch_by_tvdb({'season': sea, 'ep': epi}, tvdb)
				if not entries:
					# Fallback: search generico "titulo SxxExx"
					entries = self._fetch({
						't': 'search', 'cat': _CAT_TV,
						'q': '%s %s' % (title, hdlr),
					})
				tagged = [(e, hdlr, None) for e in (entries or [])]
				# TheTVDB season layout when it differs from TMDb (the numbering
				# most indexers use), and for anime the absolute number.
				for suffix, v_hdlr, absolute in source_utils.episode_variants(data)[1:]:
					m = None if absolute else re.match(r'S(\d+)E(\d+)', v_hdlr or '', re.I)
					d = None if (absolute or m) else re.match(r'(\d{4})\.(\d{2})\.(\d{2})$', v_hdlr or '')
					if d and tvdb and self._supports('tv', 'tvdbid') is not False:
						# v2.0.31: programa diario por id de serie y fecha, a la manera
						# Newznab (season=AAAA, ep=MM/DD); si no da nada, por texto como antes
						extra = self._fetch_by_tvdb({'season': d.group(1), 'ep': '%s/%s' % (d.group(2), d.group(3))}, tvdb) \
							or self._fetch({'t': 'search', 'cat': _CAT_TV, 'q': '%s %s' % (title, suffix)})
						if not extra: # v2.0.31: indexer without TheTVDB ids: the presenter's name
							for h_query, h_hdlr in source_utils.host_queries(data):
								extra = self._fetch({'t': 'search', 'cat': _CAT_TV, 'q': h_query})
					elif absolute or not m: # absolute number, or the air date of a daily show (v2.0.16)
						extra = self._fetch({'t': 'search', 'cat': _CAT_TV, 'q': '%s %s' % (title, suffix)})
					elif not self._search_ok('tv'):   # v2.0.33: el indexer no tiene tvsearch
						extra = self._fetch({'t': 'search', 'cat': _CAT_TV, 'q': '%s %s' % (title, v_hdlr)})
					else:
						extra = self._fetch({'t': 'tvsearch', 'cat': _CAT_TV, 'q': title,
											'season': str(int(m.group(1))), 'ep': str(int(m.group(2)))})
					tagged.extend((e, v_hdlr, absolute) for e in (extra or []))
			else:
				season = None
				hdlr = year
				self._tvdb = ''
				# Primaria: movie por imdbid (lo mas fiable cuando el indexer lo soporta)
				# v2.0.33: solo si el indexer anuncia imdbid (o no hay caps)
				entries = []
				if imdb_digits and self._search_ok('movie') and self._supports('movie', 'imdbid') is not False:
					entries = self._fetch({
						't': 'movie', 'cat': _CAT_MOVIE, 'imdbid': imdb_digits,
					})
				if len(entries) < ID_FEW:
					# search generico "titulo year": tambien con pocos resultados
					# por id (releases que el indexer no tiene enlazados)
					entries = _merge(entries, self._fetch({
						't': 'search', 'cat': _CAT_MOVIE,
						'q': '%s %s' % (title, year),
					}))
				tagged = [(e, hdlr, None) for e in (entries or [])]

			undesirables = source_utils.get_undesirables()
			check_foreign_audio = source_utils.check_foreign_audio()
		except Exception:
			source_utils.scraper_error('NEWZNAB')
			return sources

		seen = set()
		for entry, e_hdlr, absolute in tagged:
			try:
				h = entry.get('nzb') or ''
				if h in seen:
					continue
				item = self._make_item(
					entry, title, aliases, e_hdlr, year, imdb, episode_title,
					total_seasons, season, False, undesirables, check_foreign_audio,
					absolute=absolute)
				if item:
					seen.add(h)
					sources.append(item)
			except Exception:
				source_utils.scraper_error('NEWZNAB')
		return sources

	def _packs_one(self, data, hostDict, search_series=False, total_seasons=None, bypass_filter=False):
		sources = []
		# v1.0.61: con 'solo episodios' activo no se buscan packs en absoluto.
		# Ademas de evitar los packs en la lista, ahorra 2-3 consultas al
		# indexer por cada busqueda de serie (las de season-pack y show-pack).
		if self._episodes_only():
			from resources.lib.jacksparrow import log_utils
			log_utils.log('NEWZNAB: pack search skipped (episodes-only mode)', level=log_utils.LOGDEBUG)
			return sources
		if not data:
			return sources
		if not self.base or not self.key:
			return sources
		try:
			title = data['tvshowtitle']
			title = title.replace('&', 'and').replace('Special Victims Unit', 'SVU').replace('/', ' ')
			aliases = data['aliases']
			year = data['year']
			imdb = data['imdb']
			season = data['season']
			hdlr = 'S%02d' % int(season)
			self.caps = _caps(self.base, self.key, self.indexer_label)
			tvdb = str(data.get('tvdb') or '').strip()
			if not tvdb.isdigit() or tvdb == '0': tvdb = ''

			if search_series:
				# Serie completa: buscar por titulo (sin temporada) + "complete"
				entries = self._fetch({
					't': 'search', 'cat': _CAT_TV,
					'q': '%s complete' % title,
				})
				if not entries:
					entries = self._fetch({'t': 'tvsearch', 'cat': _CAT_TV, 'q': title})
			else:
				# Pack de temporada: tvsearch por temporada (sin episodio); v2.0.33:
				# primero por el id de TheTVDB si el indexer lo anuncia
				entries = []
				if tvdb and self._supports('tv', 'tvdbid'):
					entries = self._fetch_by_tvdb({'season': str(int(season))}, tvdb)
				if len(entries) < ID_FEW and self._search_ok('tv'):
					entries = _merge(entries, self._fetch({
						't': 'tvsearch', 'cat': _CAT_TV,
						'q': title, 'season': str(int(season)),
					}))
				if not entries:
					entries = self._fetch({
						't': 'search', 'cat': _CAT_TV,
						'q': '%s Season %s' % (title, int(season)),
					})

			undesirables = source_utils.get_undesirables()
			check_foreign_audio = source_utils.check_foreign_audio()
		except Exception:
			source_utils.scraper_error('NEWZNAB')
			return sources

		seen = set()
		for entry in entries:
			try:
				h = entry.get('nzb') or ''
				if h in seen:
					continue
				seen.add(h)
				item = self._make_item(
					entry, title, aliases, hdlr, year, imdb, None,
					total_seasons, season, True, undesirables, check_foreign_audio)
				if item:
					sources.append(item)
			except Exception:
				source_utils.scraper_error('NEWZNAB')
		# Salud: mas grabs primero (mismo criterio que sources()).
		try: sources.sort(key=lambda i: int(i.get('seeders') or 0), reverse=True)
		except Exception: pass
		return sources


	# --- Varios indexers (v2.0.32) ---------------------------------------------

	def _each(self, run):
		"""run(instancia) en cada indexer configurado, en paralelo. Una
		instancia por indexer: base, clave, etiqueta y timeout son suyos."""
		from resources.lib.jacksparrow import workers
		found = []
		def one(base, key):
			inst = source()
			inst.base, inst.key, inst.indexer_label = base, key, _label(base)
			inst.timeout = self.timeout
			try: found.extend(run(inst) or [])
			except Exception: source_utils.scraper_error('NEWZNAB')
		threads = [workers.Thread(one, b, k) for b, k in _indexers()]
		[t.start() for t in threads]
		[t.join() for t in threads]
		# mismo release en dos indexers: se queda el de mas grabs y el NZB del
		# otro va de alternativa (si el primero se queda sin cupo, log del
		# 11-nov-2026, el motor lo baja del otro)
		found.sort(key=lambda i: int(i.get('seeders') or 0), reverse=True)
		out, seen = [], {}
		for item in found:
			k = _dedupe_key(item)
			if k in seen:
				first = seen[k]
				if item.get('nzb_host') != first.get('nzb_host') and item.get('url'):
					first.setdefault('alts', []).append([item.get('url'), item.get('nzb_host') or ''])
				continue
			seen[k] = item
			out.append(item)
		return out

	def sources(self, data, hostDict):
		if not data:
			return []
		if not _indexers():
			from resources.lib.jacksparrow import log_utils
			log_utils.log('NEWZNAB: url/apikey not configured; skipped', level=log_utils.LOGDEBUG)
			return []
		sources = self._each(lambda inst: inst._sources_one(data, hostDict))
		# v2.0.24: con Easynews como reproductor, salud REAL en vez de grabs:
		# se pregunta a Easynews (STAT, sin bajar datos) si los articulos
		# siguen ahi y se quitan los borrados. Prueba del 1-nov-2026: 3 de 5
		# releases recientes de NZBGeek ya no estaban en Easynews.
		# Solo si Easynews reproduce los NZB y tiene cuenta: sin eso el modulo
		# del motor ni se importa.
		if sources and getSetting('newznab.use_easynews') != 'false' \
				and (getSetting('easynews.username') or '').strip() and (getSetting('easynews.password') or '').strip():
			try:
				from resources.lib.modules import usenet_easynews
				sources = usenet_easynews.health_filter(sources, wait=HEALTH_SEARCH_WAIT)
			except Exception:
				source_utils.scraper_error('NEWZNAB health')
		return sources

	def sources_packs(self, data, hostDict, search_series=False, total_seasons=None, bypass_filter=False):
		if not data or not _indexers():
			return []
		return self._each(lambda inst: inst._packs_one(data, hostDict, search_series, total_seasons, bypass_filter))


# -----------------------------------------------------------------------------
# Helper de test para el Setup Wizard (no lo usa el pipeline de scraping)
# -----------------------------------------------------------------------------

def _as_text(body):
	"""Normaliza la respuesta de client.request a str, venga en bytes o str.
	(client.request puede devolver cualquiera de los dos segun el indexer; si
	no se normaliza, '<x' in body revienta con TypeError sobre bytes.)"""
	if body is None:
		return ''
	if isinstance(body, bytes):
		try:
			return body.decode('utf-8', 'replace')
		except Exception:
			return body.decode('latin-1', 'replace')
	return body


def _looks_like_newznab(text):
	"""True si el cuerpo parece una respuesta Newznab valida (caps o feed)."""
	low = text.lower()
	return any(tag in low for tag in (
		'<caps', '<server', '<categories', '<rss', '<channel',
		'<item', 'newznab:response', '<?xml'))


def _newznab_error(text):
	"""Si el cuerpo es un <error .../> de Newznab, devuelve su descripcion;
	si no, None."""
	low = text.lower()
	if '<error' not in low:
		return None
	try:
		root = ET.fromstring(text.encode('utf-8') if isinstance(text, str) else text)
		return root.attrib.get('description') or 'Indexer returned an error.'
	except Exception:
		# Sacar la descripcion a mano si el XML no parsea limpio
		import re as _re
		m = _re.search(r'description="([^"]+)"', text)
		return m.group(1) if m else 'Indexer returned an error (bad API key or URL).'


def test_indexer(base_url, apikey):
	"""
	Comprueba credenciales contra el indexer. Primero t=caps; si la respuesta
	no es concluyente, hace una busqueda real t=search como segundo sondeo.
	Devuelve (ok:bool, msg:str). Usado por newznab_wizard.

	Robusto a: respuestas en bytes, <error> mal formados, y endpoints que
	restringen t=caps pero si permiten t=search.
	"""
	base = _normalize_newznab_url(base_url)
	key = (apikey or '').strip()
	if not base:
		return False, 'Empty indexer URL.'
	if not key:
		return False, 'Empty API key.'
	host = base.split('://', 1)[-1].split('/', 1)[0]

	def _probe(params):
		url = _build_query(base, params)
		try:
			return _as_text(client.request(url, timeout=15, headers={'User-Agent': INDEXER_UA})), None
		except Exception as e:
			return None, str(e)

	# 1) t=caps
	body, err = _probe({'t': 'caps', 'apikey': key})
	if body is not None:
		desc = _newznab_error(body)
		if desc:
			return False, desc  # error explicito (p.ej. API key incorrecta)
		if _looks_like_newznab(body):
			return True, 'Indexer OK (%s).' % host

	# 2) Fallback: busqueda real (algunos endpoints limitan caps)
	body2, err2 = _probe({'t': 'search', 'q': 'a', 'apikey': key})
	if body2 is not None:
		desc = _newznab_error(body2)
		if desc:
			return False, desc
		if _looks_like_newznab(body2):
			return True, 'Indexer OK (%s).' % host

	# Sin exito: diagnostico util
	if body is None and body2 is None:
		return False, 'Could not reach the indexer (network error: %s).' % (err or err2 or 'unknown')
	snippet = (body or body2 or '').strip().replace('\n', ' ')[:120]
	if not snippet:
		return False, 'Empty response from indexer (check the URL host).'
	return False, 'Unexpected response (is this a Newznab /api endpoint?). Got: %s' % snippet
