# -*- coding: utf-8 -*-
"""
	luc_kodi - Usenet core (v2.0.24 test)

	Biblioteca SIN dependencias de Kodi (solo libreria estandar) para leer NZB
	directamente de un proveedor Usenet por NNTP. Hoy el proveedor es Easynews
	(tu cuenta de Easynews es tambien un servidor Usenet), pero nada aqui es
	especifico de Easynews: vale para cualquier servidor NNTP con SSL.

	Piezas:
	  NNTPConn      conexion NNTP sobre SSL: login, STAT, STAT en lote, BODY.
	  yenc_decode   decodifica un articulo yEnc y devuelve los datos + la
	                posicion (begin/end) que ocupan dentro del fichero.
	  parse_nzb     lee el XML del NZB: ficheros, segmentos y message-ids.
	  pick_media    elige el fichero de video dentro del NZB (los nombres
	                ofuscados se resuelven por tamano, no por nombre).
	  sniff         identifica el contenedor por sus primeros bytes
	                (MKV / MP4 / AVI / TS / RAR4 / RAR5 / 7z).
	  check_health  comprueba con STAT (sin descargar datos) si los articulos
	                del fichero de video siguen en el servidor.

	Datos medidos el 1-nov-2026 en una tablet Android con Easynews (Termux):
	  - STAT en lote de 23 articulos existentes: 0,09 s. Los que NO existen
	    (430) los contesta lentos, ~0,5 s cada uno: por eso check_health mira
	    primero 3 articulos y abandona al primer 430.
	  - 4 conexiones: 11,3 MB/s. 10 conexiones: 7,7 MB/s (en Python mas hilos
	    compiten por el GIL al decodificar). De ahi el defecto de 4, que en la
	    v2.0.32 pasa a 6 con 2 BODY en tuberia por conexion (12 en vuelo).
	  - De 5 releases recientes de NZBGeek, 3 estaban borrados en Easynews.
"""

import re
import time
import socket
import ssl
import threading
import zlib
import xml.etree.ElementTree as ET

EASYNEWS_HOSTS = {
	'eu': 'secure.news.easynews.com',
	'us': 'secure-us.news.easynews.com',
}

# Codigos NNTP que importan aqui
NNTP_OK_STAT = 223
NNTP_OK_BODY = 222
NNTP_NO_ARTICLE = 430

_TERM = b'\r\n.\r\n'


class NNTPError(Exception):
	pass


class NNTPAuthError(NNTPError):
	pass


class NNTPTooMany(NNTPError):
	"""v2.0.32: el servidor no deja abrir mas conexiones a esta cuenta (502/503
	'too many connections'). No es un fallo del login ni del articulo."""
	pass


_TOO_MANY_RE = re.compile(r'too many|connection limit|max(imum)? (number of )?connections|connections? (per|limit)|already .*connect', re.I)


# Servidores cuyo certificado solo pasa sin VERIFY_X509_STRICT (ver _tls_connect).
_RELAXED_HOSTS = set()


# v2.0.32 — TLS y DNS una sola vez (auditoria del 11-nov-2026, L4/P2). Antes cada
# conexion creaba DOS contextos SSL (cada uno carga el almacen de certificados
# del sistema) y resolvia el DNS de nuevo: al arrancar, en cada reintento y tras
# cada pausa. Un SSLContext es seguro entre hilos para wrap_socket, asi que se
# crea uno por modo (estricto / relajado) y se reutiliza. La resolucion se guarda
# 10 min y se prueba IPv4 primero (IPv6 roto en casa da esperas de 20 s antes de
# caer a IPv4).
_CTX = {}
_CTX_LOCK = threading.Lock()
_DNS = {}
DNS_TTL = 600


def _context(relaxed):
	with _CTX_LOCK:
		ctx = _CTX.get(relaxed)
		if ctx is None:
			ctx = ssl.create_default_context()
			strict = getattr(ssl, 'VERIFY_X509_STRICT', 0)
			if relaxed and strict:
				ctx.verify_flags &= ~strict
			_CTX[relaxed] = ctx
		return ctx


def _addresses(host, port):
	now = time.time()
	hit = _DNS.get((host, port))
	if hit and now - hit[0] < DNS_TTL:
		return hit[1]
	infos = socket.getaddrinfo(host, int(port), 0, socket.SOCK_STREAM)
	addrs = [i[4][:2] for i in infos if i[0] == socket.AF_INET] + [i[4][:2] for i in infos if i[0] != socket.AF_INET]
	seen, out = set(), []
	for a in addrs:
		if a not in seen:
			seen.add(a)
			out.append(a)
	if out:
		_DNS[(host, port)] = (now, out)
	return out


def _open_socket(host, port, timeout):
	"""TCP a la primera direccion que conteste, IPv4 antes que IPv6."""
	last = None
	try: addrs = _addresses(host, port)
	except socket.gaierror:
		_DNS.pop((host, port), None)
		raise
	for addr in addrs:
		try:
			return socket.create_connection(addr, timeout=timeout)
		except OSError as e:
			last = e
	_DNS.pop((host, port), None)   # quiza cambio de IP: la proxima vez se resuelve otra vez
	raise last or OSError('no address for %s' % host)


def _tls_connect(host, port, timeout):
	"""Conexion TLS verificada. Python 3.13+ (Kodi 22) anade VERIFY_X509_STRICT
	a create_default_context(), que rechaza certificados validos pero mal
	formados (sin Authority Key Identifier, CA sin basicConstraints critico...).
	Si el servidor cae SOLO por eso, se repite con las reglas de Python 3.12:
	cadena y nombre del servidor se siguen comprobando."""
	strict = getattr(ssl, 'VERIFY_X509_STRICT', 0)

	def _attempt(relaxed):
		raw = _open_socket(host, port, timeout)
		try:
			return _context(relaxed).wrap_socket(raw, server_hostname=host)
		except Exception:
			try: raw.close()
			except Exception: pass
			raise

	can_relax = bool(strict and (_context(False).verify_flags & strict))
	if can_relax and host in _RELAXED_HOSTS:
		return _attempt(True)
	try:
		return _attempt(False)
	except ssl.SSLCertVerificationError:
		if not can_relax:
			raise
		# Si tambien falla asi, sale ESE error: es el motivo real (nombre del
		# servidor, CA desconocida...), no el de la regla estricta.
		sock = _attempt(True)
		_RELAXED_HOSTS.add(host)
		return sock


class NNTPConn(object):
	"""Una conexion NNTP con SSL. No es thread-safe: una por hilo."""

	def __init__(self, host, port, user, password, timeout=20, use_ssl=True, sock=None):
		self.host = host
		self.timeout = timeout
		if sock is None:
			if use_ssl:
				sock = _tls_connect(host, port, timeout)
			else:
				sock = _open_socket(host, port, timeout)
		try: sock.settimeout(timeout)
		except Exception: pass
		self.sock = sock
		self.buf = bytearray()
		self.rx = 0                          # bytes recibidos (informe de uso)
		code, line = self._resp()
		if code not in (200, 201):
			self.close()
			if code in (400, 502, 503) and _TOO_MANY_RE.search(line or ''):
				raise NNTPTooMany('greeting %s %s' % (code, line))
			raise NNTPError('greeting %s %s' % (code, line))
		self.greeting = line
		if user:
			code, line = self.cmd('AUTHINFO USER %s' % user)
			if code == 381:
				code, line = self.cmd('AUTHINFO PASS %s' % password)
			if code != 281:
				self.close()
				# Easynews: '502 Too many connections' llega en el login, no en
				# el saludo; no es una clave mala (v2.0.32)
				if code in (400, 502, 503) and _TOO_MANY_RE.search(line or ''):
					raise NNTPTooMany('%s %s' % (code, line))
				raise NNTPAuthError('%s %s' % (code, line))

	# -- bajo nivel ----------------------------------------------------------
	def _fill(self):
		d = self.sock.recv(262144)
		if not d:
			raise NNTPError('connection closed by server')
		self.buf += d
		self.rx += len(d)

	def _readline(self):
		while True:
			i = self.buf.find(b'\r\n')
			if i >= 0:
				line = bytes(self.buf[:i])
				del self.buf[:i + 2]
				return line
			self._fill()

	def _resp(self):
		line = self._readline().decode('latin-1', 'replace')
		try: code = int(line[:3])
		except ValueError: raise NNTPError('bad response: %r' % line[:60])
		return code, line[4:]

	def cmd(self, command):
		self.sock.sendall(command.encode('latin-1') + b'\r\n')
		return self._resp()

	# -- comandos ------------------------------------------------------------
	@staticmethod
	def _mid(msgid):
		return '<%s>' % msgid.strip().strip('<>')

	def stat(self, msgid):
		return self.cmd('STAT %s' % self._mid(msgid))[0]

	def stat_many(self, msgids):
		"""STAT en tuberia: se mandan todos y luego se leen todas las
		respuestas. Un solo viaje de ida y vuelta."""
		if not msgids:
			return []
		payload = b''.join(('STAT %s\r\n' % self._mid(m)).encode('latin-1') for m in msgids)
		self.sock.sendall(payload)
		return [self._resp()[0] for _ in msgids]

	def body(self, msgid):
		"""(codigo, articulo crudo sin el terminador) o (codigo, None).
		self.timing = (s hasta la respuesta del servidor, s en total) del ultimo."""
		t0 = time.time()
		code, line = self.cmd('BODY %s' % self._mid(msgid))
		self.timing = (time.time() - t0, 0.0)
		if code != NNTP_OK_BODY:
			return code, None
		data = self._read_body()
		self.timing = (self.timing[0], time.time() - t0)
		return code, data

	def body_many(self, msgids):
		"""v2.0.32 — BODY en tuberia (auditoria P1): se mandan todos los comandos
		y luego se leen las respuestas en orden. La espera del servidor del
		segundo articulo se solapa con la transferencia del primero, sin abrir
		mas conexiones ni mas hilos (que en Python compiten por el GIL).
		[(codigo, articulo o None)] en el mismo orden."""
		if not msgids:
			return []
		t0 = time.time()
		self.sock.sendall(b''.join(('BODY %s\r\n' % self._mid(m)).encode('latin-1') for m in msgids))
		out = []
		# v2.0.32 (informe N1): el tiempo de CADA articulo, no solo del lote. Para
		# el primero, desde que se mandaron los comandos; para los siguientes,
		# desde que acabo el anterior (lo que de verdad tardo en llegar).
		self.timings = []
		prev = t0
		for _ in msgids:
			code, line = self._resp()
			t_ans = time.time()
			out.append((code, self._read_body() if code == NNTP_OK_BODY else None))
			t_end = time.time()
			self.timings.append((t_ans - prev, t_end - prev))
			prev = t_end
		self.timing = (0.0, time.time() - t0)
		return out

	def _read_body(self):
		start = 0
		while True:
			# cuerpo vacio: el terminador '.' llega como primera linea
			if self.buf[:3] == b'.\r\n':
				del self.buf[:3]
				return b''
			i = self.buf.find(_TERM, start)
			if i >= 0:
				data = bytes(self.buf[:i + 2])
				del self.buf[:i + 5]
				return data
			if len(self.buf) >= 3:
				start = max(0, len(self.buf) - 4)
			self._fill()

	def ping(self):
		"""v2.0.32 — comando ligero (DATE, RFC 3977) para que el servidor no cierre
		la conexion durante una pausa. True si contesta 111."""
		return self.cmd('DATE')[0] == 111

	def close(self):
		try:
			self.sock.sendall(b'QUIT\r\n')
		except Exception:
			pass
		try:
			self.sock.close()
		except Exception:
			pass


# ----------------------------------------------------------------- yEnc -----
_DEC = bytes(((i - 42) & 0xFF) for i in range(256))
_ESC = bytes(((i - 106) & 0xFF) for i in range(256))   # -64 -42
_RE_KV = re.compile(rb'(\w+)=(\S+)')


def _header_values(line):
	out = {}
	# name= va siempre al final y puede llevar espacios
	if b' name=' in line:
		head, name = line.split(b' name=', 1)
		out['name'] = name.decode('utf-8', 'replace').strip()
	else:
		head = line
	for k, v in _RE_KV.findall(head):
		out[k.decode('ascii', 'replace')] = v.decode('ascii', 'replace')
	return out


def yenc_decode(article):
	"""Decodifica un articulo yEnc (cuerpo de BODY, con CRLF).

	Devuelve dict: data, begin (0-based), end (exclusivo), size (tamano total
	del fichero), name, crc_ok. Lanza ValueError si no es yEnc.
	Todo el trabajo pesado son operaciones C de bytes (replace, split,
	translate): en una tablet Android rinde ~34 MB/s por hilo.
	"""
	if not article:
		raise ValueError('empty article')
	# dot-stuffing de NNTP: una linea que empieza por '.' llega con '..'
	if article.startswith(b'..'):
		article = article[1:]
	article = article.replace(b'\r\n..', b'\r\n.')
	p = article.find(b'=ybegin')
	if p < 0:
		raise ValueError('not yEnc')
	eol = article.find(b'\r\n', p)
	ybegin = _header_values(article[p:eol])
	pos = eol + 2
	ypart = {}
	if article.startswith(b'=ypart', pos):
		eol2 = article.find(b'\r\n', pos)
		ypart = _header_values(article[pos:eol2])
		pos = eol2 + 2
	e = article.rfind(b'=yend')
	if e < 0:
		e = len(article)
		yend = {}
	else:
		yend = _header_values(article[e:].split(b'\r\n', 1)[0])
	body = article[pos:e].replace(b'\r\n', b'').replace(b'\n', b'')
	parts = body.split(b'=')
	if len(parts) == 1:
		data = body.translate(_DEC)
	else:
		res = [parts[0].translate(_DEC)]
		for q in parts[1:]:
			if q:
				res.append(_ESC[q[0]:q[0] + 1])
				res.append(q[1:].translate(_DEC))
		data = b''.join(res)
	crc_ok = True
	want = yend.get('pcrc32') or (None if ypart else yend.get('crc32'))
	if want:
		try: crc_ok = (zlib.crc32(data) & 0xFFFFFFFF) == int(want, 16)
		except ValueError: pass
	try: size = int(ybegin.get('size') or 0)
	except ValueError: size = 0
	if ypart:
		begin = int(ypart.get('begin', '1')) - 1
		end = int(ypart.get('end', str(begin + len(data))))
	else:
		begin, end = 0, len(data)
	return {'data': data, 'begin': begin, 'end': end, 'size': size or end,
			'name': ybegin.get('name', ''), 'crc_ok': crc_ok}


# ------------------------------------------------------------------ NZB -----
_EXTRA_EXT = re.compile(r'\.(par2|nfo|sfv|srr|nzb|jpg|jpeg|png|txt|url|srt|sub|idx|ass|ssa|exe|db)$', re.I)
_VIDEO_EXT = re.compile(r'\.(mkv|mp4|m4v|avi|ts|m2ts|mov|wmv|webm|mpg|mpeg)$', re.I)
_RAR_EXT = re.compile(r'(\.part\d+\.rar|\.rar|\.r\d\d|\.\d{3})$', re.I)
_7Z_EXT = re.compile(r'\.7z(\.\d+)?$', re.I)
_SAMPLE_NAME = re.compile(r'(?i)(^|[ ._\-\[(])sample([ ._\-\])]|$)')
SAMPLE_FACTOR = 5


def parse_nzb(raw):
	"""Lista de ficheros: {'name','subject','segments':[(n,bytes,msgid)],'bytes'}"""
	if isinstance(raw, str):
		raw = raw.encode('utf-8', 'replace')
	if raw[:2] == b'\x1f\x8b':                      # v2.0.25: NZB guardado comprimido
		import gzip
		raw = gzip.decompress(raw)
	# algunos indexers anteponen un DOCTYPE con DTD externa; ET lo ignora.
	# Un NZB nunca declara entidades: se rechaza (expansion de entidades).
	if b'<!ENTITY' in raw[:4096].upper():
		raise ValueError('NZB with entity declarations')
	root = ET.fromstring(raw)
	files = []
	for f in root.iter():
		if not f.tag.endswith('file'):
			continue
		subject = f.get('subject') or ''
		m = re.search(r'"([^"]+)"', subject)
		name = m.group(1) if m else subject
		segs = []
		for s in f.iter():
			if s.tag.endswith('segment') and s.text:
				try: num = int(s.get('number') or 0)
				except ValueError: num = 0
				try: nb = int(s.get('bytes') or 0)
				except ValueError: nb = 0
				segs.append((num, nb, s.text.strip()))
		if not segs:
			continue
		segs.sort(key=lambda x: x[0])
		files.append({'name': name, 'subject': subject, 'segments': segs,
					  'bytes': sum(x[1] for x in segs)})
	return files


def classify(name):
	n = (name or '').strip().lower()
	if _EXTRA_EXT.search(n): return 'par2' if n.endswith('.par2') else 'extra'
	if _VIDEO_EXT.search(n): return 'video'
	if _7Z_EXT.search(n): return '7z'
	if _RAR_EXT.search(n): return 'rar'
	return 'obfuscated'


def pick_media(files):
	"""(fichero de video candidato, tipo por nombre).

	tipo: 'video' (nombre de video), 'rar' (volumenes RAR por nombre),
	'7z', 'obfuscated' (nombre aleatorio: hay que mirar los bytes) o None.
	Se elige el MAYOR fichero que no sea par2/extra: en un release normal es
	el video; en uno ofuscado el video tambien es, con mucho, el mas grande.
	"""
	cands = [f for f in files if classify(f['name']) not in ('par2', 'extra')]
	if not cands:
		return None, None
	kinds = {classify(f['name']) for f in cands}
	if 'video' in kinds:
		vids = [f for f in cands if classify(f['name']) == 'video']
		vid = max(vids, key=lambda f: f['bytes'])
		rest = [f for f in cands if classify(f['name']) != 'video']
		# v2.0.27. MEASURED (kodi.log 5-nov-2026, The Rockford Files 2x05,
		# "1080p.BluRay" announced at ~4 GB): the stream was an 80 MB MKV of
		# 66 seconds. A video by name next to an archive many times its size
		# (or named "sample") is the sample: the release is the archive.
		if rest and (_SAMPLE_NAME.search(vid['name'] or '')
					 or sum(f['bytes'] for f in rest) > SAMPLE_FACTOR * vid['bytes']):
			cands, kinds = rest, {classify(f['name']) for f in rest}
		else:
			return vid, 'video'
	if 'rar' in kinds:
		rars = [f for f in cands if classify(f['name']) == 'rar']
		return sorted(rars, key=lambda f: f['name'].lower())[0], 'rar'
	if '7z' in kinds:
		return max(cands, key=lambda f: f['bytes']), '7z'
	return max(cands, key=lambda f: f['bytes']), 'obfuscated'


# ------------------------------------------------------------ containers ----
def _vint(b, i):
	v, sh = 0, 0
	while True:
		c = b[i]; i += 1
		v |= (c & 0x7F) << sh; sh += 7
		if not c & 0x80:
			return v, i


def sniff(data):
	"""('mkv'|'mp4'|'avi'|'ts'|'m2ts'|'rar'|'7z'|'unknown', detalle)."""
	if not data:
		return 'unknown', 'empty'
	if data[:4] == b'\x1a\x45\xdf\xa3':
		return 'mkv', 'Matroska'
	if data[4:8] == b'ftyp':
		return 'mp4', 'MP4/ISO'
	if data[:4] == b'RIFF' and data[8:12] == b'AVI ':
		return 'avi', 'AVI'
	if len(data) > 376 and data[0] == 0x47 and data[188] == 0x47 and data[376] == 0x47:
		return 'ts', 'MPEG-TS'
	# v2.0.32: M2TS de Blu-ray (paquetes de 192 bytes: 4 de reloj + 188 de TS).
	# kodi.log del 12-nov-2026: American Psycho de DIYHDHome y Zootopia 2 de TMT
	# eran el .m2ts de la pelicula y salian como 'UNKNOWN ... not streamable'.
	if len(data) > 388 and data[4] == 0x47 and data[196] == 0x47 and data[388] == 0x47:
		return 'm2ts', 'Blu-ray M2TS'
	if data[:7] == b'Rar!\x1a\x07\x00':
		return 'rar', 'RAR4 ' + _rar4_method(data)
	if data[:8] == b'Rar!\x1a\x07\x01\x00':
		return 'rar', 'RAR5 ' + _rar5_method(data)
	if data[:6] == b'7z\xbc\xaf\x27\x1c':
		return '7z', '7-Zip'
	# v2.0.33 (kodi.log del 13-nov-2026, Avatar Fire and Ash UHD BluRay de MTeam):
	# una imagen de disco empieza con 32 KB a cero y en el sector 16 lleva la
	# firma ISO 9660 (CD001) o UDF (BEA01, la de los Blu-ray). Salia como
	# 'UNKNOWN (0000000000000000)'.
	if len(data) >= 0x8006 and data[0x8001:0x8006] in (b'CD001', b'BEA01'):
		return 'iso', 'disc image'
	return 'unknown', data[:8].hex()


def _rar4_method(data):
	i = 7
	try:
		while i + 7 < len(data):
			htype = data[i + 2]
			flags = int.from_bytes(data[i + 3:i + 5], 'little')
			hsize = int.from_bytes(data[i + 5:i + 7], 'little')
			if htype == 0x74:
				method = data[i + 25]
				enc = ' encrypted' if flags & 0x04 else ''
				return ('store' if method == 0x30 else 'compressed') + enc
			add = int.from_bytes(data[i + 7:i + 11], 'little') if (flags & 0x8000 and htype != 0x73) else 0
			if hsize < 7: break
			i += hsize + add
	except Exception:
		pass
	return '?'


def _rar5_method(data):
	i = 8
	try:
		while i < len(data) - 16:
			i += 4
			hsize, j = _vint(data, i); start = j
			htype, j = _vint(data, j); hflags, j = _vint(data, j)
			if hflags & 1: _, j = _vint(data, j)
			dsize = 0
			if hflags & 2: dsize, j = _vint(data, j)
			if htype == 4: return 'encrypted headers'
			if htype == 2:
				fflags, j = _vint(data, j); _, j = _vint(data, j); _, j = _vint(data, j)
				if fflags & 2: j += 4
				if fflags & 4: j += 4
				comp, j = _vint(data, j)
				return 'store' if ((comp >> 7) & 7) == 0 else 'compressed'
			i = start + hsize + dsize
	except Exception:
		pass
	return '?'


# ------------------------------------------------------------------ RAR -----
_RE_SUBJ_IDX = re.compile(r'[\[(](\d+)\s*(?:/|of)\s*(\d+)[\])]')
_RE_PARTN = re.compile(r'\.part(\d+)\.rar$', re.I)
_RE_OLDVOL = re.compile(r'\.([r-z])(\d\d)$', re.I)
_RE_NUMVOL = re.compile(r'\.(\d{3})$')


def _vol_key(name):
	n = name.lower()
	m = _RE_PARTN.search(n)
	if m: return (0, int(m.group(1)))
	if n.endswith('.rar'): return (1, -1)
	m = _RE_OLDVOL.search(n)
	if m: return (1, (ord(m.group(1)) - ord('r')) * 100 + int(m.group(2)))
	m = _RE_NUMVOL.search(n)
	if m: return (2, int(m.group(1)))
	return (9, 0)


def _vol_stem(name):
	n = name.lower()
	for rx in (_RE_PARTN, _RE_OLDVOL, _RE_NUMVOL):
		m = rx.search(n)
		if m:
			return n[:m.start()]
	return n[:-4] if n.endswith('.rar') else n


def _subject_index(f, pos):
	m = _RE_SUBJ_IDX.search(f.get('subject') or '')
	return int(m.group(1)) if m else pos


def rar_candidates(files):
	"""Ficheros ofuscados que pueden ser volumenes, en el orden del asunto
	('[03/45]') o del NZB. Si varios comparten nombre y ese grupo es el grueso
	del release, se descartan los de otro nombre (un fichero ajeno colado)."""
	obf = [f for f in files if classify(f['name']) == 'obfuscated']
	if not obf:
		return []
	groups = {}
	for f in obf:
		groups.setdefault(f['name'], []).append(f)
	best = max(groups.values(), key=lambda g: sum(x['bytes'] for x in g))
	if len(best) >= 2 and sum(x['bytes'] for x in best) >= 0.5 * sum(x['bytes'] for x in obf):
		obf = best
	order = sorted(enumerate(obf), key=lambda p: _subject_index(p[1], p[0]))
	return [f for _, f in order]


def rar_volumes(files):
	"""Volumenes de un RAR en orden, o [].

	Con nombre: .partNN.rar, .rar + .r00/.r01..., o .001/.002...
	Ofuscados: orden del indice del asunto ('[03/45]') o el del NZB; se
	quedan los ficheros del tamano de los volumenes grandes mas el ultimo,
	mas pequeno, que va justo detras. El motor comprueba despues cada
	cabecera, asi que un orden equivocado da error, nunca datos cruzados.
	"""
	cands = [f for f in files if classify(f['name']) not in ('par2', 'extra')]
	named = [f for f in cands if classify(f['name']) == 'rar']
	if named:
		# Puede haber otros RAR en el NZB (subtitulos, sample): se agrupan por
		# nombre base y se queda el grupo que mas pesa.
		groups = {}
		for f in named:
			groups.setdefault(_vol_stem(f['name']), []).append(f)
		best = max(groups.values(), key=lambda g: sum(x['bytes'] for x in g))
		return sorted(best, key=lambda f: _vol_key(f['name']))
	order = rar_candidates(files)
	if not order:
		return []
	big = max(f['bytes'] for f in order)
	# Los volumenes grandes seguidos y, detras, los mas pequenos que vengan:
	# cuantos volumenes hacen falta lo dicen despues las cabeceras del RAR.
	vols, tail = [], False
	for f in order:
		if f['bytes'] >= 0.9 * big:
			if tail:
				break
			vols.append(f)
		elif vols:
			vols.append(f)
			tail = True
	return vols


# -------------------------------------------------------------- 7z store ----
# v2.0.28: un 7z 'store' (sin compresion), como los reproduce TMDb Movies
# (usenet/nzb.py): tras la cabecera de inicio de 32 bytes viene el contenido
# tal cual. Firma (6) + version (2) + CRC (4) + NextHeaderOffset (8) +
# NextHeaderSize (8) + CRC (4). Los datos empaquetados van de 32 a
# 32 + NextHeaderOffset y el archivo entero mide 32 + offset + size. Un 7z
# partido (.7z.001, .002...) es ese mismo archivo cortado a trozos iguales, sin
# cabeceras en los trozos siguientes. Si el contenido va comprimido, lo que hay
# en el byte 32 no es un video y el motor lo dice (no se sirven bytes rotos).
_RE_7ZVOL = re.compile(r'\.7z\.(\d+)$', re.I)


def _7z_stem(name):
	n = (name or '').lower()
	m = _RE_7ZVOL.search(n)
	if m: return n[:m.start()]
	return n[:-3] if n.endswith('.7z') else n


def _7z_key(name):
	m = _RE_7ZVOL.search((name or '').lower())
	return int(m.group(1)) if m else 0


def seven_volumes(files):
	"""Volumenes del 7z en orden (un .7z suelto es un juego de un volumen), o [].
	Si hay varios 7z en el NZB se queda el grupo que mas pesa."""
	named = [f for f in files if classify(f['name']) == '7z']
	if not named:
		return []
	groups = {}
	for f in named:
		groups.setdefault(_7z_stem(f['name']), []).append(f)
	best = max(groups.values(), key=lambda g: sum(x['bytes'] for x in g))
	return sorted(best, key=lambda f: _7z_key(f['name']))


def parse_7z(data):
	"""Cabecera de inicio de un 7z -> {'data_off': 32, 'packed': n, 'archive': total}.
	ValueError si no es un 7z o la cabecera no tiene sentido."""
	if len(data) < 32 or data[:6] != b'7z\xbc\xaf\x27\x1c':
		raise ValueError('not a 7z archive')
	import struct
	off, size = struct.unpack_from('<QQ', data, 12)
	if off <= 0:
		raise ValueError('7z without file data')
	if size <= 0:
		raise ValueError('7z header missing')
	return {'data_off': 32, 'packed': off, 'archive': 32 + off + size}


def _u16(b, i): return b[i] | (b[i + 1] << 8)
def _u32(b, i): return b[i] | (b[i + 1] << 8) | (b[i + 2] << 16) | (b[i + 3] << 24)


def parse_rar(data):
	"""Cabecera del fichero dentro de UN volumen RAR (4 o 5).

	Devuelve dict: fmt (4|5), data_off (donde empiezan los datos en este
	volumen), data_size (cuantos datos lleva este volumen), unp_size (tamano
	total del fichero), store (sin compresion), encrypted, split_before,
	split_after, first_volume, name. Lanza ValueError si no se encuentra.
	"""
	if data[:7] == b'Rar!\x1a\x07\x00':
		pos, first_vol = 7, None
		while pos + 7 <= len(data):
			htype = data[pos + 2]
			flags = _u16(data, pos + 3)
			hsize = _u16(data, pos + 5)
			if hsize < 7:
				break
			if htype == 0x73:
				first_vol = bool(flags & 0x0100) or not (flags & 0x0001)
				pos += hsize
				continue
			if htype in (0x74, 0x7a):
				pack = _u32(data, pos + 7)
				unp = _u32(data, pos + 11)
				method = data[pos + 25]
				nsize = _u16(data, pos + 26)
				npos = pos + 32
				if flags & 0x0100:
					pack |= _u32(data, pos + 32) << 32
					unp |= _u32(data, pos + 36) << 32
					npos = pos + 40
				if htype == 0x7a:
					pos += hsize + pack
					continue
				name = data[npos:npos + nsize].split(b'\x00')[0].decode('utf-8', 'replace')
				return {'fmt': 4, 'data_off': pos + hsize, 'data_size': pack, 'unp_size': unp,
						'store': method == 0x30, 'encrypted': bool(flags & 0x0004),
						'split_before': bool(flags & 0x0001), 'split_after': bool(flags & 0x0002),
						'first_volume': first_vol, 'name': name}
			add = _u32(data, pos + 7) if flags & 0x8000 else 0
			pos += hsize + add
		raise ValueError('RAR4 file header not found')
	if data[:8] == b'Rar!\x1a\x07\x01\x00':
		pos, first_vol = 8, None
		while pos + 7 < len(data):
			hsize, j = _vint(data, pos + 4)
			start = j
			htype, j = _vint(data, j)
			hflags, j = _vint(data, j)
			extra = dsize = 0
			if hflags & 0x1: extra, j = _vint(data, j)
			if hflags & 0x2: dsize, j = _vint(data, j)
			end = start + hsize
			if htype == 1:
				aflags, j = _vint(data, j)
				volnum = 0
				if aflags & 0x2: volnum, j = _vint(data, j)
				first_vol = volnum == 0
			elif htype == 4:
				return {'fmt': 5, 'encrypted': True, 'store': False, 'data_off': 0, 'data_size': 0,
						'unp_size': 0, 'split_before': False, 'split_after': False,
						'first_volume': first_vol, 'name': ''}
			elif htype == 2:
				fflags, j = _vint(data, j)
				unp, j = _vint(data, j)
				_, j = _vint(data, j)                 # atributos
				if fflags & 0x2: j += 4
				if fflags & 0x4: j += 4
				comp, j = _vint(data, j)
				_, j = _vint(data, j)                 # sistema
				nlen, j = _vint(data, j)
				name = data[j:j + nlen].decode('utf-8', 'replace')
				enc = False
				k = end - extra
				while extra and k < end:
					rsize, k2 = _vint(data, k)
					rtype, _ = _vint(data, k2)
					if rtype == 1: enc = True
					k = k2 + rsize
				if not fflags & 0x1:                  # no es un directorio
					return {'fmt': 5, 'data_off': end, 'data_size': dsize, 'unp_size': unp,
							'store': ((comp >> 7) & 7) == 0, 'encrypted': enc,
							'split_before': bool(hflags & 0x8), 'split_after': bool(hflags & 0x10),
							'first_volume': first_vol, 'name': name}
			elif htype == 5:
				break
			pos = end + dsize
		raise ValueError('RAR5 file header not found')
	raise ValueError('not a RAR volume')


# ------------------------------------------------------- archive check -----
# v2.0.33: lo que el motor no puede reproducir se sabe mirando la cabecera del
# archivo, que va en el primer articulo (~0,7 MB). Antes un RAR comprimido o
# cifrado pasaba la salud (sus articulos estan) y se veia al darle a reproducir:
# un grab y un intento perdidos. Ahora la salud lee ese articulo en los releases
# en archivo (RAR, 7z, ofuscados) y dice el motivo antes de abrir la lista.
ARCHIVE_KINDS = ('rar', 'obfuscated', '7z')
_PLAYABLE = ('mkv', 'mp4', 'avi', 'ts', 'm2ts')


def archive_verdict(data):
	"""Motivo por el que el motor no podra reproducir un archivo cuyo primer
	articulo decodificado es `data`, o None si puede (o no se sabe).
	Solo se dice que no cuando la cabecera lo deja claro."""
	c, _ = sniff(data)
	if c == 'rar':
		try: h = parse_rar(data)
		except ValueError: return None
		if h.get('encrypted'):
			return 'encrypted RAR'
		if not h.get('store'):
			return 'compressed RAR'
		off = h.get('data_off') or 0
		if h.get('first_volume') is not False and not h.get('split_before') and 0 < off < len(data) - 16:
			inner, _ = sniff(data[off:off + 0x8006])
			if inner in ('rar', '7z'):
				return 'archive inside an archive'
			if inner == 'iso':
				return 'disc image (ISO) inside the archive'
		return None
	if c == 'iso':
		return 'disc image (ISO)'
	if c == '7z':
		try: h = parse_7z(data)
		except ValueError: return None
		if len(data) >= h['data_off'] + 4096:
			# v2.0.33 (auditoria del 13-nov-2026): 0x8006 bytes como en el RAR, que la firma de una ISO va a 32 KB
			inner, _ = sniff(data[h['data_off']:h['data_off'] + 0x8006])
			if inner == 'iso':
				return 'disc image (ISO) inside the archive'
			if inner not in _PLAYABLE:
				return 'compressed 7z'
		return None
	return None


def check_archive(conn, files, meter=None):
	"""Lee el primer articulo del archivo del NZB y devuelve el motivo por el
	que no se puede reproducir, o None. Releases sin archivo: None sin leer.
	meter (v2.0.33): lista a la que se suma lo leido, para el Usenet report."""
	media, kind = pick_media(files)
	if not media or kind not in ARCHIVE_KINDS:
		return None
	f = media
	if kind == 'rar':
		vols = rar_volumes(files)
		f = vols[0] if vols else media
	elif kind == '7z':
		vols = seven_volumes(files)
		f = vols[0] if vols else media
	code, art = conn.body(f['segments'][0][2])
	if not art:
		return None
	if meter is not None:
		meter.append(len(art))
	try:
		return archive_verdict(yenc_decode(art)['data'])
	except ValueError:
		return None


# --------------------------------------------------------------- health -----
def sample_ids(segments, count):
	"""Message-ids repartidos por todo el fichero (incluye primero y ultimo)."""
	n = len(segments)
	if n <= count:
		return [s[2] for s in segments]
	step = (n - 1) / float(count - 1)
	idx = sorted({round(k * step) for k in range(count)})
	return [segments[k][2] for k in idx]


def check_health(conn, files, deep=40, backup=None):
	"""Comprueba la disponibilidad del video del NZB en el servidor.

	Fase 1: el primer articulo. Si falta, 'dead': el motor lo necesita para
	abrir el fichero, y el servidor tarda ~0,5 s en cada articulo que no
	tiene (un release borrado por DMCA lo esta entero).
	Fase 2: `deep` articulos repartidos por todo el fichero (40: con 15 se
	colo un remux de Coco al que le faltaba ~6%; con 40 se ve en el ~92% de
	los casos, y los STAT de articulos presentes cuestan milisegundos). Si
	falta alguno
	el release sale como 'partial' con su porcentaje (sin PAR2, cada
	articulo que falta es un salto de imagen al reproducir).

	Devuelve {'status': 'ok'|'partial'|'dead'|'empty', 'pct': int,
	          'kind': tipo por nombre, 'checked': n}
	"""
	media, kind = pick_media(files)
	if not media:
		return {'status': 'empty', 'pct': 0, 'kind': None, 'checked': 0}
	segs = media['segments']
	# RAR (por nombre, o ofuscado en varios ficheros del mismo tamano): se
	# muestrean TODOS los volumenes, no solo el primero.
	if kind in ('rar', 'obfuscated'):
		vols = rar_volumes(files)
		if len(vols) > 1:
			segs = [x for v in vols for x in v['segments']]
	elif kind == '7z': # v2.0.28: todos los volumenes del 7z, como en un RAR
		vols = seven_volumes(files)
		if len(vols) > 1:
			segs = [x for v in vols for x in v['segments']]
	# Fase 1: SOLO el primer articulo. Sin el, el motor no puede ni abrir el
	# fichero, asi que basta para declararlo muerto, y un 430 cuesta ~0,5 s.
	# v2.0.32 (informe L7): con proveedor de respaldo, lo que el principal no
	# tiene se pregunta alli. backup: funcion sin argumentos que da su
	# conexion (o None si no hay o no conecta).
	def _with_backup(ids, codes):
		if backup is None or all(c == NNTP_OK_STAT for c in codes):
			return codes
		try: bconn = backup()
		except Exception: bconn = None
		if bconn is None:
			return codes
		lost = [i for i, c in enumerate(codes) if c != NNTP_OK_STAT]
		try: again = bconn.stat_many([ids[i] for i in lost])
		except Exception: return codes
		codes = list(codes)
		for i, c in zip(lost, again):
			if c == NNTP_OK_STAT: codes[i] = c
		return codes
	codes = _with_backup([segs[0][2]], conn.stat_many([segs[0][2]]))
	if codes[0] != NNTP_OK_STAT:
		return {'status': 'dead', 'pct': 0, 'kind': kind, 'checked': 1}
	first = [segs[0][2], segs[len(segs) // 2][2], segs[-1][2]]
	codes = codes + _with_backup(first[1:], conn.stat_many(first[1:]))
	more = [m for m in sample_ids(segs, deep) if m not in first]
	codes2 = _with_backup(more, conn.stat_many(more)) if more else []
	allc = codes + codes2
	ok = allc.count(NNTP_OK_STAT)
	pct = round(100.0 * ok / len(allc))
	return {'status': 'ok' if ok == len(allc) else 'partial', 'pct': pct,
			'kind': kind, 'checked': len(allc)}
