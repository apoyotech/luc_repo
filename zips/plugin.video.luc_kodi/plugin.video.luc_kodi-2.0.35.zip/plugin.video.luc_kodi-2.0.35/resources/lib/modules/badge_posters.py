# -*- coding: utf-8 -*-
"""
	luc_kodi Add-on — modules/badge_posters.py (v2.0.35)

	Posters with badges, drawn by a SpatialPosters server the user runs.

	v2.0.35: cuando TMDb tiene un poster SIN texto y hay clearlogo, se manda
	ese poster y el logo (`logo=`); el servidor coloca el logo el mismo, como en
	su demo. Si no hay logo, nunca se manda un poster sin texto (el titulo se
	perderia): se usa el poster con titulo.
	v2.0.35 (decisiones de Lucian, 15-nov-2026): sin nota en el poster (pisaba
	el texto o no se distinguia) y la cinta de arriba en color, sacado del
	propio poster por el servidor (`rs=colored`), como en su demo.

	El poster es lo unico que todos los skins pintan sin tocar su XML: si
	art['poster'] es una imagen que ya lleva las insignias, sale igual en
	Nimbus, FENtastic, Estuary MOD V2 y cualquier otro, en la Home y en las
	listas. luc_kodi no dibuja nada: solo construye la URL de la instancia
	que el usuario escribe en Ajustes (decision de Lucian, 15-nov-2026:
	pedir la URL, no depender de ninguna instancia ajena).

	Como funciona el servidor (leido de TheAceOfficials/SpatialPosters,
	src/app/api/poster/[type]/[id]/route.ts):
	  - GET /api/poster/<movie|tv>/<tmdbId> devuelve un JPEG de 500x750.
	  - Con `poster=` el servidor usa ESE poster (acepta URL completa) y entra
	    en el "modo consulta": respeta badges/ranking/bg/by/br. Sin `poster=`
	    ignora esos interruptores y lo enciende todo, y ademas necesita su
	    propia clave de TMDb. Por eso se manda siempre el poster que luc_kodi
	    ya eligio (respeta la rotacion y el idioma del arte).
	  - Genero y año (si el usuario los enciende) los da luc_kodi (genreName,
	    year): son los mismos que ve en la ficha. La nota ya no se manda (v2.0.35).
	  - `ranking=1` enciende la insignia de arriba: Top 20 de JustWatch por
	    pais, premios de Wikidata, IMDb Top 250, estreno o serie terminada.
	  - Calidad (`mq`/`mf`): el texto libre de calidad NO se manda nunca: un
	    titulo no es un release y la insignia mentiria (mismo criterio que
	    home_badges.py). `mq` solo viaja como "ov:<ids>" con las insignias de
	    Elite-Badges de un release que luc_kodi conoce (ver release_badges).
	  - `lang` por defecto es "it" en el servidor: se manda siempre en ingles.
	  - `be=0` apaga el desenfoque que el servidor pone por defecto en el 30 %
	    inferior del poster: esta pensado para posters sin texto y emborronaba
	    los titulos de los nuestros (visto en la prueba 2.0.35, 15-nov-2026).
	  - `v` lo descarta el servidor de su clave de cache, asi que sirve para
	    que Kodi pida la imagen de nuevo cada semana (el Top 20 cambia; ver
	    _period) sin fragmentar la cache del servidor.

	NUNCA se manda ninguna clave (ni la de TMDb del plugin ni la del usuario):
	la URL viaja a un servidor que no controlamos. En modo consulta no la
	necesita; si la instancia tiene su propia clave de TMDb, la usa ella.

	Solo cambia el ARTE del item (poster, thumb/icon si eran el mismo poster).
	meta['poster'] se queda con el poster limpio: lo usan las ventanas propias
	del plugin (lista de fuentes, proximo episodio), que ya tienen su marco.
"""

import re
import time
from urllib.parse import quote, urlparse

from resources.lib.modules import control

getSetting = control.setting

_PATH = '/api/poster/%s/%s'
_TYPES = {'movie': 'movie', 'tvshow': 'tv'}

# Misma idea que poster_rotator: control.setting() parsea el JSON de ajustes en
# cada llamada; con este TTL un directorio entero se resuelve con UNA lectura y
# un cambio de ajustes se nota como mucho 5 s despues (reuselanguageinvoker).
_conf_cache = {'ts': 0.0}
_CONF_TTL = 5.0


def normalize_url(raw):
	"""'posters.example.com/' -> 'https://posters.example.com'. Vacio si no vale."""
	try:
		u = (raw or '').strip()
		if not u: return ''
		if '://' not in u: u = 'https://' + u
		p = urlparse(u)
		if p.scheme not in ('http', 'https') or not p.netloc: return ''
		path = p.path.rstrip('/')
		if path.endswith('/api/poster'): path = path[:-len('/api/poster')] # pegaron la ruta entera
		return '%s://%s%s' % (p.scheme, p.netloc, path)
	except Exception: return ''


def _conf():
	now = time.time()
	if now - _conf_cache['ts'] > _CONF_TTL:
		c = {'ts': now}
		try:
			c['url'] = normalize_url(getSetting('posters.badges.url')) if getSetting('posters.badges') == 'true' else ''
			c['genre'] = getSetting('posters.badges.genre') == 'true'
			c['top'] = getSetting('posters.badges.top') != 'false'
			c['av'] = getSetting('posters.badges.av') != 'false'
		except Exception: c['url'] = ''
		_conf_cache.clear(); _conf_cache.update(c)
	return _conf_cache


def enabled():
	return bool(_conf().get('url'))


def _first_genre(genre):
	if not genre: return ''
	if isinstance(genre, (list, tuple)): genre = genre[0] if genre else ''
	return str(genre).split(' / ')[0].split(', ')[0].strip()


def _period():
	"""Valor de `v`: cambia una vez por SEMANA (año y semana ISO, p. ej. 202646).

	v2.0.35 (kodi.log de Lucian, 15-nov-2026): con el servidor ya rapido (mediana
	0,06 s), lo que tarda es Kodi al guardar cada poster NUEVO (descargar,
	decodificar y volver a codificar un 500x750: ~1,4 s por poster en cada uno
	de sus 4-5 hilos), unos 5-7 s para una pagina de 20. Kodi nunca vuelve a
	comprobar una imagen de internet que ya tiene, asi que `v` es lo unico que la
	renueva; con `v` diario se repetia ese coste en cada pagina cada dia. Semanal:
	la primera visita de la semana lo paga y el resto va al instante. A cambio,
	un puesto del Top 20 puede tener hasta una semana.
	"""
	import datetime
	y, w, _d = datetime.date.today().isocalendar() # isocalendar, no strftime('%G%V'): no depende de la libc de Android
	return '%d%02d' % (y, w)


def build_url(base, mediatype, tmdb, poster, meta, genre=False, top=True, day=None, logo='', ov=None):
	"""URL del poster con insignias, o '' si falta algo imprescindible.
	Con `logo` (poster sin texto + clearlogo) el servidor coloca el logo el mismo."""
	kind = _TYPES.get(mediatype)
	tmdb = str(tmdb or '').strip()
	if not (base and kind and tmdb.isdigit() and poster and str(poster).startswith('http')): return ''
	meta = meta or {}
	gname = _first_genre(meta.get('genre')) if genre else ''
	year = str(meta.get('year') or '')[:4] if genre else ''
	parts = [('poster', poster)]
	if logo and str(logo).startswith('http'): parts.append(('logo', logo))
	parts.append(('lang', 'en'))
	if ov: parts.append(('mq', 'ov:' + ','.join(ov))) # v2.0.35: Elite-Badges abajo (ver release_badges)
	if gname: parts.append(('genreName', gname))
	if year.isdigit(): parts.append(('year', year))
	imdb = str(meta.get('imdb') or '')
	if imdb.startswith('tt'): parts.append(('imdbId', imdb))
	pill = bool(gname or year.isdigit())
	parts += [('badges', '1' if pill else '0'), ('br', '0'),
				('bg', '1' if gname else '0'), ('by', '1' if year.isdigit() else '0'),
				('ranking', '1' if top else '0'), ('rs', 'colored'), ('be', '0'), ('v', day or _period())]
	query = '&'.join('%s=%s' % (k, quote(str(v), safe='')) for k, v in parts)
	return base + (_PATH % (kind, tmdb)) + '?' + query


# v2.0.35: el servidor dibuja SIEMPRE a 500x750, asi que pedirle a TMDb el
# poster en 'original' (2000x3000, varios MB, lo que da la calidad Original del
# plugin) o el logo en w1280 solo le hace descargar y reducir mas: cada poster
# tardaba mas en aparecer. Se le mandan los tamanos w500 de TMDb, que cubren
# exactamente lo que dibuja. Otras fuentes (fanart.tv) se mandan tal cual.
_TMDB_SIZE = re.compile(r'^(https?://image\.tmdb\.org/t/p/)[^/]+(/.+)$')


def _w500(url):
	try: return _TMDB_SIZE.sub(lambda m: m.group(1) + 'w500' + m.group(2), url) if url else url
	except Exception: return url


def pick(plain, meta, clearlogo):
	"""(poster, logo) que se manda al servidor.

	- Hay logo y TMDb tiene posters sin texto: uno sin texto (el que eligio la
	  rotacion si ya lo es) + el logo, que coloca el servidor.
	- No hay logo y el poster elegido es uno sin texto (la rotacion tambien los
	  usa): se cambia por uno con titulo, para que el titulo no se pierda.
	- Si no, el poster tal cual, sin logo.
	"""
	clean = [u for u in (meta.get('posters_clean') or []) if str(u).startswith('http')]
	logo = clearlogo if str(clearlogo or '').startswith('http') else ''
	if logo and clean: return (plain if plain in clean else clean[0]), logo
	if plain in clean:
		for alt in (meta.get('poster3'), meta.get('poster'), meta.get('poster2')):
			if alt and str(alt).startswith('http') and alt not in clean: return alt, ''
	return plain, ''


def apply(art, meta, mediatype):
	"""Cambia el poster del arte por el de la instancia. Inocuo si esta apagado o falla."""
	try:
		c = _conf()
		if not c.get('url'): return art
		plain = art.get('poster')
		meta = meta or {}
		poster, logo = pick(plain, meta, art.get('clearlogo'))
		poster, logo = _w500(poster), _w500(logo)
		ov = release_badges(mediatype, meta.get('tmdb')) if c.get('av') else []
		url = build_url(c['url'], mediatype, meta.get('tmdb'), poster, meta, c['genre'], c['top'], logo=logo, ov=ov)
		if not url: return art
		for k in ('poster', 'tvshow.poster', 'thumb', 'icon'):
			if k == 'poster' or (art.get(k) and art.get(k) == plain): art[k] = url
		if len(_pending) < 100: _pending.append(url)
		return art
	except Exception: return art


# ---------------------------------------------------------------------------
# v2.0.35 — Dolby Vision / HDR y Dolby Atmos / DTS abajo, con las imagenes de
# Elite-Badges (leonevz/Elite-Badges), que dibuja el servidor del usuario.
#
# Un titulo no es un release: estas insignias solo salen donde luc_kodi SABE
# que release hay (decision de Lucian, 15-nov-2026: "ambos"):
#   1. el release que el usuario reprodujo de ese titulo (manda siempre), y si
#      no hay,
#   2. el mejor release que encontro la ultima busqueda de fuentes de ese
#      titulo, durante FOUND_DAYS dias.
# Siempre de UN mismo release: nunca el Dolby Vision de uno con el Atmos de
# otro. Una insignia de imagen y otra de sonido como mucho.
# Se guarda en badge_releases.json, en el perfil del addon. Las series usan el
# id de la serie: un episodio visto o buscado pone las del episodio en el poster
# de la serie.
# ---------------------------------------------------------------------------
_STORE_NAME = 'badge_releases.json'
FOUND_DAYS = 30
_STORE_MAX = 3000
_store_cache = {'mtime': None, 'data': {}}

_VIDEO_RANK = {'dolby-vision': 4, 'hdr10-plus': 3, 'hdr10': 2, 'hdr': 1}
_AUDIO_RANK = {'dolby-atmos': 5, 'dts-x': 4, 'dts-hd-master-audio': 3, 'dts-hd': 2, 'dts': 1}


def _store_path():
	import os
	return os.path.join(control.dataPath, _STORE_NAME)


def _store_load():
	import os, json
	path = _store_path()
	try: mtime = os.path.getmtime(path)
	except Exception: return {}
	if _store_cache['mtime'] == mtime: return _store_cache['data']
	try:
		with open(path, 'r', encoding='utf-8') as fh: data = json.load(fh)
		if not isinstance(data, dict): data = {}
	except Exception: data = {}
	_store_cache.update(mtime=mtime, data=data)
	return data


def _store_save(data):
	import os, json
	path = _store_path()
	try:
		if len(data) > _STORE_MAX:
			keep = sorted(data.items(), key=lambda kv: max(kv[1].get('pt', 0), kv[1].get('ft', 0)), reverse=True)[:_STORE_MAX]
			data = dict(keep)
		os.makedirs(os.path.dirname(path), exist_ok=True)
		tmp = path + '.tmp'
		with open(tmp, 'w', encoding='utf-8') as fh: json.dump(data, fh, separators=(',', ':'))
		os.replace(tmp, path)
	except Exception: pass


def _key(mediatype, tmdb):
	tmdb = str(tmdb or '').strip()
	if not tmdb.isdigit(): return ''
	return ('movie:%s' if mediatype == 'movie' else 'tv:%s') % tmdb


def badges_from_release(name, flags=None):
	"""[imagen, sonido] de Elite-Badges para un release (nombre + getFileType)."""
	try:
		import re
		# Como name_info: minusculas, separado por puntos y con punto a cada lado
		# (getFileType busca 'dts.x.', '.dts'...). Un nombre crudo queda igual.
		low = '.%s.' % re.sub(r'[^a-z0-9+]+', '.', (name or '').lower()).strip('.')
		if flags is None:
			from resources.lib.modules.source_utils import getFileType
			flags = getFileType(name_info=low) or ''
		parts = set(p.strip().upper() for p in str(flags).split('/') if p.strip())
		out = []
		if 'DOLBY-VISION' in parts or any(p.startswith('DV-P') for p in parts): out.append('dolby-vision')
		elif 'HDR' in parts or 'HDR10' in parts or 'HDR10+' in parts:
			if any(t in low for t in ('hdr10+', 'hdr10plus', 'hdr10p.', 'hdr10.plus')): out.append('hdr10-plus')
			elif 'hdr10' in low: out.append('hdr10')
			else: out.append('hdr')
		if 'ATMOS' in parts: out.append('dolby-atmos')
		elif 'DTS-X' in parts: out.append('dts-x')
		elif 'DTS-HD MA' in parts: out.append('dts-hd-master-audio')
		elif 'DTS-HD' in parts: out.append('dts-hd')
		elif 'DTS' in parts: out.append('dts')
		return out
	except Exception: return []


def _score(ids):
	return max([_VIDEO_RANK.get(i, 0) for i in ids] + [0]) * 10 + max([_AUDIO_RANK.get(i, 0) for i in ids] + [0])


def _item_name(item):
	return str(item.get('name_info') or item.get('name') or '') if isinstance(item, dict) else ''


def record_played(mediatype, tmdb, item):
	"""sourcesResolve: el release que el usuario va a ver de ese titulo."""
	try:
		key = _key(mediatype, tmdb)
		if not key: return
		ids = badges_from_release(_item_name(item))
		data = dict(_store_load())
		entry = dict(data.get(key) or {})
		entry.update(p=ids, pt=int(time.time()))
		data[key] = entry
		_store_save(data)
	except Exception: pass


def record_found(mediatype, tmdb, items):
	"""Tras filtrar las fuentes: el MEJOR release (uno solo) de los encontrados."""
	try:
		key = _key(mediatype, tmdb)
		if not key or not items: return
		best = []
		for it in items:
			ids = badges_from_release(_item_name(it))
			if _score(ids) > _score(best): best = ids
		data = dict(_store_load())
		entry = dict(data.get(key) or {})
		if entry.get('f') == best and entry.get('ft', 0) > time.time() - 86400: return # nada nuevo hoy: no se reescribe
		entry.update(f=best, ft=int(time.time()))
		data[key] = entry
		_store_save(data)
	except Exception: pass


def release_badges(mediatype, tmdb):
	"""Ids de Elite-Badges para el poster: lo reproducido o, si no, lo encontrado."""
	try:
		entry = _store_load().get(_key(mediatype, tmdb))
		if not entry: return []
		if entry.get('pt'): return list(entry.get('p') or [])
		if entry.get('ft', 0) > time.time() - FOUND_DAYS * 86400: return list(entry.get('f') or [])
	except Exception: pass
	return []


# ---------------------------------------------------------------------------
# v2.0.35 — calentar los posters de la pagina (kodi.log de Lucian, 15-nov-2026):
# el directorio se construye en ~0,8 s, pero Kodi pide los posters de uno en uno
# segun aparecen en pantalla, y los que el servidor aun no tiene hechos tardan
# 1,5-3,8 s cada uno (los ya hechos, ~0,13 s). Al terminar cada pagina, el
# plugin deja sus URLs en una propiedad de la ventana Home y el servicio las
# pide todas a la vez: el servidor las dibuja en paralelo antes de que Kodi las
# necesite, y cuando Kodi las pide ya estan hechas. Es lo mismo que pediria
# Kodi, con la misma URL: ni datos nuevos ni nada que no viajara ya.
# ---------------------------------------------------------------------------
_pending = []
_WARM_PROP = 'luc_kodi.badge_posters.warm'
_WARM_MAX = 200


def flush():
	"""Al acabar un directorio: pasa al servicio las URLs de esta pagina."""
	global _pending
	if not _pending: return
	urls, _pending = _pending, []
	try:
		import json
		win = control.homeWindow
		try: queued = json.loads(win.getProperty(_WARM_PROP) or '[]')
		except Exception: queued = []
		queued.extend(u for u in urls if u not in queued)
		win.setProperty(_WARM_PROP, json.dumps(queued[-_WARM_MAX:]))
	except Exception: pass


def _in_kodi_cache(urls):
	"""URLs que Kodi ya tiene en su cache de texturas: no hace falta pedirlas.

	Lectura en SOLO LECTURA de Textures*.db (el mismo metodo que el test de
	pantalla). Si algo falla, se devuelve vacio y simplemente se piden todas.
	"""
	try:
		import sqlite3
		from resources.lib.modules.display_test import _texture_db
		path = _texture_db()
		if not path or not urls: return set()
		safe = path.replace('?', '%3f').replace('#', '%23')
		conn = sqlite3.connect('file:%s?mode=ro' % safe, uri=True, timeout=2)
		try:
			rows = conn.execute('SELECT url FROM texture WHERE url IN (%s)' % ','.join('?' * len(urls)), list(urls)).fetchall()
		finally: conn.close()
		return set(r[0] for r in rows)
	except Exception: return set()


def service_loop():
	"""Servicio: pide al servidor las URLs que dejan las paginas, 6 a la vez.

	Sin nada en cola solo mira la propiedad cada medio segundo. Recuerda las
	ultimas URLs ya pedidas para no repetirlas (cambian solas cada semana por `v`).
	Hilos daemon con cola propia: al cerrar Kodi no hay que esperar a ninguna
	peticion a medias.
	"""
	import json
	from queue import Queue, Empty
	from threading import Thread
	import requests
	from resources.lib.modules import log_utils
	monitor = control.monitor
	win = control.homeWindow
	work = Queue()
	done, order = set(), []
	session = requests.Session()

	def _worker():
		while not monitor.abortRequested():
			try: url = work.get(timeout=1)
			except Empty: continue
			try: session.get(url, timeout=20).close()
			except Exception: pass

	for _ in range(6):
		t = Thread(target=_worker); t.daemon = True; t.start()

	while not monitor.abortRequested():
		if monitor.waitForAbort(0.5): break
		try: raw = win.getProperty(_WARM_PROP)
		except Exception: raw = ''
		if not raw: continue
		try: win.clearProperty(_WARM_PROP)
		except Exception: pass
		try: urls = json.loads(raw)
		except Exception: urls = []
		fresh = [u for u in urls if isinstance(u, str) and u.startswith('http') and u not in done][:_WARM_MAX]
		if not fresh: continue
		cached = _in_kodi_cache(fresh)
		for u in cached: done.add(u); order.append(u)
		fresh = [u for u in fresh if u not in cached]
		if not fresh: continue
		for u in fresh:
			done.add(u); order.append(u); work.put(u)
		if len(order) > 2000:
			for u in order[:1000]: done.discard(u)
			del order[:1000]
		log_utils.log('badge_posters warm: %d poster(s) requested' % len(fresh), level=log_utils.LOGDEBUG)


def test():
	"""Settings > Appearance > Test badge server: pide un poster real a la instancia."""
	from resources.lib.modules import log_utils
	base = normalize_url(getSetting('posters.badges.url'))
	if not base: return control.okDialog(title=45025, message=control.lang(45031))
	# The Matrix (TMDb 603) con su poster de TMDb: si el poster de prueba faltara,
	# el servidor responde igualmente y eso ya prueba que esta vivo.
	url = build_url(base, 'movie', '603', 'https://image.tmdb.org/t/p/w500/f89U3ADr1oiB1s9GkdPOEpXUk5H.jpg',
					{'genre': 'Action', 'year': '1999', 'imdb': 'tt0133093'}, True, True)
	control.busy()
	try:
		import requests
		r = requests.get(url, timeout=30)
		ctype = r.headers.get('Content-Type', '')
		size = len(r.content or b'')
	except Exception as e:
		control.hide()
		log_utils.log('badge_posters test: %s -> %s' % (base, e), level=log_utils.LOGWARNING)
		return control.okDialog(title=45025, message=control.lang(45032) % base)
	control.hide()
	log_utils.log('badge_posters test: %s -> HTTP %s %s %d bytes' % (base, r.status_code, ctype, size), level=log_utils.LOGINFO)
	if r.status_code == 200 and ctype.startswith('image/'):
		return control.okDialog(title=45025, message=control.lang(45033))
	if r.status_code == 404 and not ctype.startswith('image/') and 'Poster' in (r.text or '')[:80]:
		return control.okDialog(title=45025, message=control.lang(45033)) # vivo; solo faltaba la imagen de prueba
	return control.okDialog(title=45025, message=control.lang(45034) % (base, r.status_code))
