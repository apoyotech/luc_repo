# -*- coding: utf-8 -*-
"""
	luc_kodi Add-on — Personalized Source Ranker

	Aprende qué fuentes prefiere el usuario y ajusta el orden de autoplay
	en consecuencia. Modelo: log-odds suavizados con prior Laplace por feature.

	Schema
	──────
	source_features(feature_key, feature_type, feature_value,
	                pos_count, neg_count, exp_count, last_ts)
		feature_key   : tipo:valor  (e.g. 'quality:4K', 'provider:torrentio',
		                'host:cdn2-ovh-fra.energycdn.com')
		pos_count     : veces que el usuario eligió una fuente con esta feature
		                Y la reproducción arrancó bien
		neg_count     : veces que la fuente FALLÓ de verdad — enlace muerto o
		                ancho de banda insuficiente para su bitrate (v1.0.65)
		exp_count     : veces que se mostró (elegida, saltada o fallida)

	net_stats(key, num, cnt, last_ts)                            (v1.0.65)
		Medidas agregadas de red. Hoy solo 'line_mbps': EWMA del throughput
		real medido por preflight.py en cada reproducción.

	Modelo
	──────
	Para cada feature F de una fuente, contribución:
		log( (pos[F] + α) / (skipped[F] + (W-1)·neg[F] + α) )
	donde skipped = exp - pos y W = _NEG_WEIGHT. α=1.0 (prior Laplace).

	Un fallo real pesa W veces más que un simple "no lo elegiste": que una
	fuente no se escoja es ruido, que no se pueda reproducir es señal.

	El total se suma a _smart_score multiplicado por el peso del setting.
	Sin datos → contribución 0 → comportamiento idéntico al ranker estático.

	Semilla por grupo de release (v2.0.21)
	──────────────────────────────────────
	Mientras el modelo no sabe nada (arranque en frío, o un grupo que nunca ha
	visto), el nivel TRaSH del grupo da una pista: SEED[nivel] de
	release_groups.py, en las mismas unidades que una feature aprendida. La
	pista se encoge sola con lo que el ranker ve de ese grupo:
		semilla · K / (K + shown[group])          K = _SEED_HALF
	y la feature 'group:<nombre>' aprende a la vez como cualquier otra. Con 8
	apariciones la pista vale la mitad; con unas 50, casi nada. Ajuste:
	personal.ranker.groups.

	v2.0.21 — tres correcciones de lo que el modelo cree que aprende
	────────────────────────────────────────────────────────────────
	1. Autoplay. Las fuentes que el autoplay probó ANTES de la que sonó no
	   las saltó el usuario: no resolvieron (enlace caducado, no cacheado,
	   formato no reproducible). Contarlas como "no elegidas" castigaba lo que
	   el autoplay intenta primero —4K, HDR, Atmos— solo por ir primero. Ahora
	   solo cuentan, como vistas y sin elegir, para su scraper y su debrid
	   (record_resolve_miss); el pre-flight sigue registrando sus fallos
	   reales como antes.
	2. Éxito real. Arrancar una fuente ya no basta para que cuente del todo:
	   si se para antes de _EARLY_STOP_S segundos y en los _RETRY_WINDOW_S
	   siguientes se elige OTRA fuente del mismo título, la primera pasa de
	   acierto a fallo (pos -1, neg +1). Parar e irse a dormir no castiga
	   nada: sin un segundo intento no hay corrección. Tabla ranker_pending.
	3. Olvido. Cada contador pierde la mitad de su peso cada
	   personal.ranker.halflife días (90 por defecto; 0 = nunca). Los CDN y
	   los grupos cambian y lo de hace un año no debe mandar hoy. Se aplica al
	   leer y antes de cada suma (contadores con decaimiento exponencial,
	   exactos con un solo last_ts por fila). La guardia de los 10 plays usa
	   el total de toda la vida (net_stats 'plays'), que no decae: el ranker
	   no se apaga por pasar unos meses sin usarlo.
"""

from sqlite3 import dbapi2 as db
from time import time
from math import log
import json
from resources.lib.modules.control import makeFile, dataPath, joinPath, setting as getSetting

_DB_FILE = joinPath(dataPath, 'source_ranker.db')

# Prior Laplace (también shrinkage hacia 0). Más alto = modelo más conservador,
# necesita más datos para mover el ranking. 1.0 es estándar.
_ALPHA = 1.0

# Plays mínimos antes de aplicar ajustes. Evita sesgos de los 5 primeros plays.
_MIN_TOTAL_PLAYS = 10

# Cuánto pesa un FALLO frente a un simple "saltada" (v1.0.65). 3.0 = un enlace
# muerto o demasiado pesado para la línea cuenta como tres no-elecciones.
_NEG_WEIGHT = 3.0

# v2.0.21 — apariciones de un grupo con las que su semilla TRaSH vale la mitad.
_SEED_HALF = 8.0

# v2.0.21 — éxito real: una parada antes de esto, seguida de otra fuente del
# mismo título dentro de la ventana, convierte el acierto en fallo.
_EARLY_STOP_S = 120
_RETRY_WINDOW_S = 900

# v2.0.21 — vida media por defecto de los contadores, en días (0 = sin olvido).
_HALFLIFE_DEFAULT = 90
_HALFLIFE_CHOICES = (0, 30, 90, 180, 365)   # orden del enum en settings.xml

# Segundos niveles que no son dominio registrable (para no cortar 'x.co.uk'
# en 'co.uk', que agruparía medio Reino Unido bajo la misma feature).
_SLD_UNDER_CCTLD = ('co', 'com', 'net', 'org', 'gov', 'edu', 'ac')

# Caché en memoria de las features. Se invalida al escribir.
_features_cache = None
_features_cache_ts = 0


# ── helpers DB ────────────────────────────────────────────────────────────────

def _connect():
	makeFile(dataPath)
	con = db.connect(_DB_FILE)
	con.row_factory = db.Row
	return con


def _ensure_table(cur):
	cur.execute('''
		CREATE TABLE IF NOT EXISTS source_features (
			feature_key   TEXT PRIMARY KEY,
			feature_type  TEXT NOT NULL,
			feature_value TEXT NOT NULL,
			pos_count     INTEGER DEFAULT 0,
			neg_count     INTEGER DEFAULT 0,
			exp_count     INTEGER DEFAULT 0,
			last_ts       INTEGER NOT NULL
		)
	''')
	cur.execute('''
		CREATE INDEX IF NOT EXISTS idx_features_type
		ON source_features (feature_type)
	''')
	# v2.0.21 — la última fuente arrancada, a la espera de saber si se vio.
	cur.execute('''
		CREATE TABLE IF NOT EXISTS ranker_pending (
			k      TEXT PRIMARY KEY,
			title  TEXT,
			feats  TEXT,
			state  TEXT,
			ts     INTEGER NOT NULL
		)
	''')
	# v1.0.65 — medidas de red agregadas (EWMA de velocidad de línea).
	cur.execute('''
		CREATE TABLE IF NOT EXISTS net_stats (
			key      TEXT PRIMARY KEY,
			num      REAL    DEFAULT 0,
			cnt      INTEGER DEFAULT 0,
			last_ts  INTEGER NOT NULL
		)
	''')


def _invalidate_cache():
	global _features_cache, _features_cache_ts
	_features_cache = None
	_features_cache_ts = 0


# ── Featurización ─────────────────────────────────────────────────────────────

def _size_bucket(size_gb):
	"""Discretiza el tamaño en buckets significativos para video."""
	try:
		s = float(size_gb or 0)
	except (ValueError, TypeError):
		return 'unknown'
	if s <= 0:           return 'unknown'
	if s < 1.5:          return 'tiny'      # SD / muy comprimido
	if s < 4:            return 'small'     # 1080p web-dl ligero
	if s < 10:           return 'medium'    # 1080p bluray / 4K bajo
	if s < 25:           return 'large'     # 4K web-dl / bluray
	if s < 50:           return 'xlarge'    # 4K REMUX
	return 'huge'                            # REMUX raros, packs


def _seeders_bucket(seeders):
	"""Discretiza seeders. Refleja salud del torrent."""
	try:
		n = int(seeders or 0)
	except (ValueError, TypeError):
		return 'unknown'
	if n <= 0:    return 'dead'
	if n < 5:     return 'low'
	if n < 30:    return 'medium'
	if n < 100:   return 'high'
	return 'very_high'


def normalize_host(url_or_host):
	"""
	Host normalizado para usar como valor de feature.

	Se reduce al dominio registrable (dos labels, tres cuando el TLD es un
	ccTLD de dos letras tras un SLD tipo .co.uk). Motivo: los CDN de debrid
	reparten por nodo y el identificador va DENTRO del primer label
	('3-cdn2-ovh-fra.energycdn.com', '7-cdn5-ovh-fra.energycdn.com'), así que
	recortar labels no agrupa nada. Aprender nodo a nodo tampoco sirve: el
	usuario casi nunca vuelve a caer en el mismo. Lo que se repite y predice
	el rendimiento es el CDN, y eso es 'energycdn.com'.
	"""
	try:
		if not url_or_host:
			return ''
		s = str(url_or_host).strip().split('|', 1)[0]
		if '://' in s:
			from urllib.parse import urlparse
			s = urlparse(s).netloc or ''
		s = s.lower()
		if '@' in s:
			s = s.split('@', 1)[-1]
		if ':' in s:
			s = s.split(':', 1)[0]
		if s.startswith('www.'):
			s = s[4:]
		if not s or '.' not in s:
			return s
		parts = [p for p in s.split('.') if p]
		# Una IP no tiene dominio registrable: recortarla daria '0.1' y juntaria
		# hosts sin ninguna relacion bajo la misma feature.
		if len(parts) == 4 and all(p.isdigit() for p in parts):
			return s
		if len(parts) <= 2:
			return '.'.join(parts)
		if len(parts[-1]) == 2 and parts[-2] in _SLD_UNDER_CCTLD:
			return '.'.join(parts[-3:])
		return '.'.join(parts[-2:])
	except Exception:
		return ''


def featurize(item, resolved_url=None):
	"""
	Extrae las features de una fuente. Devuelve lista de claves
	'tipo:valor'. Cualquier dato faltante se omite (no contribuye).

	`resolved_url` (v1.0.65) solo existe DESPUÉS de resolve(), así que la
	feature 'host:' se aprende al registrar el resultado pero no puede
	usarse al puntuar una lista sin resolver. Esa asimetría es deliberada:
	el host entra en el modelo por `record_choice`/`record_failure` y se
	consulta aparte con `host_health()` cuando ya se conoce.

	El campo `info` de luc_kodi está pre-tokenizado con ' | ' como
	separador (e.g. '5.2 GB | HEVC | HDR | ATMOS'). Lo parseamos por
	tokens en vez de por substring para alinear con get_extra_tags
	y evitar falsos positivos (e.g. 'DV' dentro de palabras).
	"""
	if not isinstance(item, dict):
		return []
	feats = []
	info_raw = item.get('info') or ''
	tokens = set(t.strip().upper() for t in info_raw.split('|') if t.strip())
	# Quality (siempre presente)
	q = item.get('quality')
	if q: feats.append('quality:%s' % q)
	# Codec — uno solo (jerarquía AV1 > HEVC > H264)
	if 'AV1' in tokens:
		feats.append('codec:AV1')
	elif 'HEVC' in tokens or 'H265' in tokens or 'X265' in tokens:
		feats.append('codec:HEVC')
	elif 'H264' in tokens or 'X264' in tokens or 'AVC' in tokens:
		feats.append('codec:H264')
	# HDR — uno solo, jerarquía: DV > HDR10+ > HDR > SDR
	if 'DV' in tokens or 'DOLBY-VISION' in tokens or 'DOLBYVISION' in tokens:
		feats.append('hdr:DV')
	elif 'HDR10+' in tokens or 'HDR10PLUS' in tokens:
		feats.append('hdr:HDR10+')
	elif 'HDR' in tokens or 'HDR10' in tokens:
		feats.append('hdr:HDR')
	else:
		feats.append('hdr:SDR')
	# Audio — uno solo, jerarquía
	if 'ATMOS' in tokens:
		feats.append('audio:ATMOS')
	elif 'TRUEHD' in tokens or 'DOLBY-TRUEHD' in tokens:
		feats.append('audio:TRUEHD')
	elif any(t in tokens for t in ('DTS-HD', 'DTSHD', 'DTS-HD MA', 'DTS-X')):
		feats.append('audio:DTS-HD')
	elif 'DD+' in tokens or 'DDP' in tokens or 'EAC3' in tokens:
		feats.append('audio:DDPLUS')
	elif 'AAC' in tokens:
		feats.append('audio:AAC')
	# Provider y debrid
	prov = item.get('provider') or ''
	if prov: feats.append('provider:%s' % prov.lower())
	deb = item.get('debrid') or 'none'
	feats.append('debrid:%s' % str(deb).lower().replace(' ', '').replace('-', '').replace('.', ''))
	# Size + seeders en buckets
	feats.append('size:%s' % _size_bucket(item.get('size')))
	feats.append('seeders:%s' % _seeders_bucket(item.get('seeders')))
	# v2.0.21 — grupo que firma la release ('...HEVC-FLUX' -> 'group:flux').
	try:
		from resources.lib.modules.release_groups import parse_group, item_name
		g = parse_group(item_name(item))
		if g: feats.append('group:%s' % g)
	except Exception:
		pass
	# Host del CDN que sirvió el fichero (v1.0.65). Solo disponible tras resolve().
	if resolved_url:
		h = normalize_host(resolved_url)
		if h:
			feats.append('host:%s' % h)
	return feats


# ── Lectura del modelo (con caché) ────────────────────────────────────────────

_plays_guard = None


def _halflife_days():
	"""Vida media elegida en Ajustes, en días. 0 = sin olvido (v2.0.21)."""
	try:
		v = getSetting('personal.ranker.halflife')
		if v in (None, ''):
			return _HALFLIFE_DEFAULT
		return _HALFLIFE_CHOICES[int(v)]
	except Exception:
		return _HALFLIFE_DEFAULT


def _decay_factor(last_ts, now=None, halflife_days=None):
	"""Peso que conserva un contador escrito en last_ts (1.0 = intacto)."""
	try:
		hl = _halflife_days() if halflife_days is None else halflife_days
		if not hl:
			return 1.0
		age = max(0.0, float((now or time()) - (last_ts or 0)))
		return 0.5 ** (age / (hl * 86400.0))
	except Exception:
		return 1.0


_decay_started = False


def _start_decay_once(cur, con):
	"""
	v2.0.21: lo aprendido antes de esta versión empieza a olvidarse desde el
	día de la actualización, no desde su last_ts (que solo dice cuándo se tocó
	la fila por última vez). Una sola vez por instalación: net_stats 'decay_since'.
	"""
	global _decay_started
	if _decay_started:
		return
	try:
		cur.execute("SELECT 1 FROM net_stats WHERE key = 'decay_since'")
		if not cur.fetchone():
			now = int(time())
			cur.execute('UPDATE source_features SET last_ts = ?', (now,))
			cur.execute("INSERT OR REPLACE INTO net_stats (key, num, cnt, last_ts) VALUES ('decay_since', 0, 1, ?)", (now,))
			con.commit()
		_decay_started = True
	except Exception:
		pass


def _load_features():
	"""Carga todas las features a un dict. Cacheado para evitar I/O repetida."""
	global _features_cache, _features_cache_ts
	# Caché válido durante toda la sesión de ranking (se invalida en escrituras)
	if _features_cache is not None:
		return _features_cache
	out = {}
	try:
		con = _connect()
		cur = con.cursor()
		_ensure_table(cur)
		_start_decay_once(cur, con)
		cur.execute('SELECT feature_key, pos_count, exp_count, neg_count, last_ts FROM source_features')
		now, hl = time(), _halflife_days()
		for row in cur.fetchall():
			# v2.0.21: contadores con olvido; reales, no enteros.
			f = _decay_factor(row['last_ts'], now, hl)
			out[row['feature_key']] = (float(row['pos_count'] or 0) * f, float(row['exp_count'] or 0) * f,
			                           float(row['neg_count'] or 0) * f)
	except Exception:
		from resources.lib.modules import log_utils
		log_utils.error()
	finally:
		try: con.close()
		except Exception: pass
	_features_cache = out
	_features_cache_ts = int(time())
	return out


def _total_plays():
	"""
	Plays de toda la vida (v2.0.21: net_stats 'plays', sin olvido).

	Hasta la 2.0.20 era la suma de pos de quality:*. Con el olvido esa suma
	baja sola, así que la primera vez se siembra con ella y desde entonces
	cuenta record_choice().
	"""
	try:
		_v, cnt = get_net('plays')
		if cnt:
			return int(cnt)
		total = 0
		con = _connect()
		try:
			cur = con.cursor()
			_ensure_table(cur)
			cur.execute("SELECT COALESCE(SUM(pos_count), 0) FROM source_features WHERE feature_key LIKE 'quality:%'")
			total = int(round(float(cur.fetchone()[0] or 0)))
			if total > 0:
				cur.execute('INSERT OR REPLACE INTO net_stats (key, num, cnt, last_ts) VALUES (?, 0, ?, ?)',
				            ('plays', total, int(time())))
				con.commit()
		finally:
			con.close()
		return total
	except Exception:
		return 0


def _count_play():
	con = None
	try:
		_total_plays()   # siembra el contador si aún no existe
		con = _connect()
		cur = con.cursor()
		_ensure_table(cur)
		cur.execute('''
			INSERT INTO net_stats (key, num, cnt, last_ts) VALUES ('plays', 0, 1, ?)
			ON CONFLICT(key) DO UPDATE SET cnt = cnt + 1, last_ts = ?
		''', (int(time()), int(time())))
		con.commit()
	except Exception:
		pass
	finally:
		try:
			if con is not None: con.close()
		except Exception: pass


# ── API pública: scoring ──────────────────────────────────────────────────────

def score_adjustment(item):
	"""
	Devuelve el ajuste personalizado para una fuente. 0.0 si:
		· ranker desactivado en settings
		· menos de _MIN_TOTAL_PLAYS plays acumulados y sin semilla de grupo
		· cualquier error
	El llamador debe multiplicar por el peso del setting antes de sumar a _smart_score.

	v2.0.21: suma además la semilla del grupo de release (ver cabecera), que
	no espera a los 10 plays: es justo para el arranque en frío.
	"""
	try:
		# v1.0.78 — el ajuste y la guardia de plays se resuelven UNA vez por
		# sesion de ranking, no una por fuente (ver nota en _load_features).
		# El total se ata a la caché de features: _load_features() ya se
		# invalida al escribir, asi que colgar el contador de la misma
		# identidad de objeto lo invalida a la vez.
		global _plays_guard
		feats = _load_features()
		guard = globals().get('_plays_guard')
		if guard is None or guard[0] is not feats:
			total = _total_plays()   # v2.0.21: toda la vida, sin olvido
			_plays_guard = (feats, total,
			                getSetting('personal.ranker.enabled') == 'true',
			                getSetting('personal.ranker.groups') != 'false')
			guard = _plays_guard
		_feats_id, total, enabled, groups = guard
		if not enabled:
			return 0.0
		item_feats = featurize(item)
		score = 0.0
		if total >= _MIN_TOTAL_PLAYS:
			for f in item_feats:
				pos, exp, neg = feats.get(f, (0, 0, 0))
				skipped = max(0, exp - pos)
				# Log-odds Laplace-suavizado, con los fallos reales pesando _NEG_WEIGHT
				score += log((pos + _ALPHA) / (skipped + (_NEG_WEIGHT - 1.0) * neg + _ALPHA))
		if groups:
			score += group_seed(item, feats)
		return score
	except Exception:
		from resources.lib.modules import log_utils
		log_utils.error()
		return 0.0


def group_seed(item, feats=None):
	"""Pista TRaSH del grupo de la fuente, ya encogida por lo aprendido (v2.0.21)."""
	try:
		from resources.lib.modules import release_groups
		name = release_groups.item_name(item)
		g = release_groups.parse_group(name)
		if not g:
			return 0.0
		seed = release_groups.SEED.get(release_groups.tier_of(g, release_groups.release_kind(name)), 0.0)
		if not seed:
			return 0.0
		if feats is None:
			feats = _load_features()
		shown = feats.get('group:%s' % g, (0, 0, 0))[1]
		return seed * _SEED_HALF / (_SEED_HALF + shown)
	except Exception:
		return 0.0


# ── API pública: registro de eventos ──────────────────────────────────────────

def _apply_updates(updates):
	"""
	Escribe un lote {feature_key: (pos, neg, exp, type, value)}.

	v2.0.21: antes de sumar, lo guardado pierde el peso que le toca por el
	tiempo pasado desde su last_ts (ver _decay_factor). Los deltas pueden ser
	negativos (corrección de una parada temprana); un contador nunca baja de 0.
	"""
	if not updates:
		return
	ts = int(time())
	con = None
	try:
		con = _connect()
		cur = con.cursor()
		_ensure_table(cur)
		_start_decay_once(cur, con)
		hl = _halflife_days()
		for key, (pd, nd, ed, ftype, fval) in updates.items():
			cur.execute('SELECT pos_count, neg_count, exp_count, last_ts FROM source_features WHERE feature_key = ?', (key,))
			row = cur.fetchone()
			if row:
				f = _decay_factor(row['last_ts'], ts, hl)
				pos = max(0.0, float(row['pos_count'] or 0) * f + pd)
				neg = max(0.0, float(row['neg_count'] or 0) * f + nd)
				exp = max(0.0, float(row['exp_count'] or 0) * f + ed)
			else:
				pos, neg, exp = max(0.0, pd), max(0.0, nd), max(0.0, ed)
			exp = max(exp, pos)
			cur.execute('''
				INSERT OR REPLACE INTO source_features
					(feature_key, feature_type, feature_value, pos_count, neg_count, exp_count, last_ts)
				VALUES (?, ?, ?, ?, ?, ?, ?)
			''', (key, ftype, fval, round(pos, 4), round(neg, 4), round(exp, 4), ts))
		con.commit()
		_invalidate_cache()
	except Exception:
		from resources.lib.modules import log_utils
		log_utils.error()
	finally:
		try:
			if con is not None: con.close()
		except Exception: pass


def _collect(updates, item, pos_d, neg_d, exp_d, resolved_url=None):
	for f in featurize(item, resolved_url=resolved_url):
		ftype, fval = f.split(':', 1)
		if f in updates:
			op, on, oe, _, _ = updates[f]
			updates[f] = (op + pos_d, on + neg_d, oe + exp_d, ftype, fval)
		else:
			updates[f] = (pos_d, neg_d, exp_d, ftype, fval)


def record_choice(chosen_item, all_items=None, resolved_url=None, title_key='', autoplay=False):
	"""
	Llamado cuando el usuario (o autoplay) confirma una fuente.

	chosen_item  : dict de la fuente que se va a reproducir → +1 pos +1 exp
	all_items    : lista de fuentes mostradas/intentadas antes de la elegida
	               → cada una recibe +1 exp (sin pos), señalando "fue saltada".
	               Si es None, solo se registra la elegida.
	resolved_url : URL final tras resolve() (v1.0.65). Solo se usa para
	               aprender la feature 'host:' de la fuente ELEGIDA — de las
	               saltadas no se conoce el host y sería falsearlo.

	title_key    : (v2.0.21) id del título y episodio. Permite convertir en
	               fallo una fuente que se paró enseguida y se cambió por otra.
	autoplay     : (v2.0.21) las anteriores no las saltó el usuario, no
	               resolvieron: solo cuentan para su scraper y su debrid.

	No bloqueante en caso de error — nunca debe romper la reproducción.
	"""
	if getSetting('personal.ranker.enabled') != 'true':
		return
	try:
		chosen_feats = featurize(chosen_item, resolved_url=resolved_url)
		_settle_pending(title_key, chosen_feats)
		updates = {}
		_collect(updates, chosen_item, 1, 0, 1, resolved_url=resolved_url)
		if all_items:
			for it in all_items:
				if it is chosen_item:
					continue
				if autoplay:
					_collect_service(updates, it, 0, 0, 1)
				else:
					_collect(updates, it, 0, 0, 1)
		_count_play()      # antes de sumar: la siembra lee el total previo
		_apply_updates(updates)
		_set_pending(title_key, chosen_feats)
	except Exception:
		from resources.lib.modules import log_utils
		log_utils.error()


def _collect_service(updates, item, pos_d, neg_d, exp_d):
	"""Como _collect, pero solo las features del scraper y del debrid (v2.0.21)."""
	for f in featurize(item):
		if not (f.startswith('provider:') or f.startswith('debrid:')):
			continue
		ftype, fval = f.split(':', 1)
		op, on, oe = updates.get(f, (0, 0, 0, ftype, fval))[:3]
		updates[f] = (op + pos_d, on + neg_d, oe + exp_d, ftype, fval)


def _set_pending(title_key, feats):
	if not title_key or not feats:
		return
	con = None
	try:
		con = _connect()
		cur = con.cursor()
		_ensure_table(cur)
		cur.execute('INSERT OR REPLACE INTO ranker_pending (k, title, feats, state, ts) VALUES (?, ?, ?, ?, ?)',
		            ('last', str(title_key), json.dumps(feats), 'playing', int(time())))
		con.commit()
	except Exception:
		pass
	finally:
		try:
			if con is not None: con.close()
		except Exception: pass


def _get_pending():
	con = None
	try:
		con = _connect()
		cur = con.cursor()
		_ensure_table(cur)
		cur.execute("SELECT title, feats, state, ts FROM ranker_pending WHERE k = 'last'")
		row = cur.fetchone()
		if not row:
			return None
		return {'title': row['title'] or '', 'feats': json.loads(row['feats'] or '[]'),
		        'state': row['state'] or '', 'ts': int(row['ts'] or 0)}
	except Exception:
		return None
	finally:
		try:
			if con is not None: con.close()
		except Exception: pass


def _clear_pending():
	con = None
	try:
		con = _connect()
		cur = con.cursor()
		_ensure_table(cur)
		cur.execute("DELETE FROM ranker_pending WHERE k = 'last'")
		con.commit()
	except Exception:
		pass
	finally:
		try:
			if con is not None: con.close()
		except Exception: pass


def _settle_pending(title_key, new_feats):
	"""
	Al elegir una fuente: si la anterior del MISMO título se paró enseguida
	y esta es otra, la anterior pasa de acierto a fallo (v2.0.21).
	"""
	pend = _get_pending()
	if not pend:
		return
	try:
		if (pend['state'] == 'early' and title_key and pend['title'] == str(title_key)
				and (time() - pend['ts']) <= _RETRY_WINDOW_S
				and sorted(pend['feats']) != sorted(new_feats or [])):
			updates = {}
			for f in pend['feats']:
				ftype, fval = f.split(':', 1)
				updates[f] = (-1, 1, 0, ftype, fval)
			_apply_updates(updates)
			try:
				from resources.lib.modules import log_utils
				log_utils.log('[RANKER] early stop then another source: previous choice counted as a failure',
				              level=log_utils.LOGDEBUG)
			except Exception:
				pass
	finally:
		_clear_pending()


def playback_finished(seconds, percent=0.0, ended=False):
	"""
	Lo llama el reproductor al terminar (v2.0.21). Una reproducción de al
	menos _EARLY_STOP_S segundos, o que llega al final, confirma el acierto.
	Una parada antes queda en espera: solo cuenta como fallo si se elige otra
	fuente del mismo título dentro de _RETRY_WINDOW_S.
	"""
	if getSetting('personal.ranker.enabled') != 'true':
		return
	try:
		pend = _get_pending()
		if not pend or pend['state'] != 'playing':
			return
		if ended or float(percent or 0) >= 85 or float(seconds or 0) >= _EARLY_STOP_S:
			_clear_pending()
			return
		con = _connect()
		try:
			cur = con.cursor()
			_ensure_table(cur)
			cur.execute("UPDATE ranker_pending SET state = 'early', ts = ? WHERE k = 'last'", (int(time()),))
			con.commit()
		finally:
			con.close()
	except Exception:
		pass


def record_resolve_miss(item):
	"""
	Autoplay: la fuente no resolvió y se pasó a la siguiente (v2.0.21). Cuenta
	como vista y no usada SOLO para su scraper y su debrid: la calidad, el HDR
	o el audio no tienen la culpa de que un enlace haya caducado.
	"""
	if getSetting('personal.ranker.enabled') != 'true':
		return
	try:
		updates = {}
		_collect_service(updates, item, 0, 0, 1)
		_apply_updates(updates)
	except Exception:
		pass


def record_failure(item, resolved_url=None, reason=''):
	"""
	Llamado cuando una fuente FALLÓ de verdad (v1.0.65): enlace muerto,
	vídeo de error, o ancho de banda por debajo de lo que exige su bitrate.

	Suma +1 neg +1 exp (sin pos) a todas sus features, host incluido cuando
	se conoce. Un fallo pesa _NEG_WEIGHT veces más que una simple no-elección.

	Distinguir esto de "no la elegiste" es justo lo que permite que el modelo
	aprenda qué CDN funciona en esta conexión y no solo qué le gusta al usuario.
	"""
	if getSetting('personal.ranker.enabled') != 'true':
		return
	try:
		if not isinstance(item, dict):
			return
		updates = {}
		_collect(updates, item, 0, 1, 1, resolved_url=resolved_url)
		_apply_updates(updates)
		if reason:
			try:
				from resources.lib.modules import log_utils
				log_utils.log('[RANKER] failure recorded (%s) host=%s provider=%s' % (
					reason, normalize_host(resolved_url) or '-',
					item.get('provider') or '-'), level=log_utils.LOGDEBUG)
			except Exception:
				pass
	except Exception:
		from resources.lib.modules import log_utils
		log_utils.error()


def record_host(resolved_url, ok=True):
	"""
	Registra SOLO la feature 'host:' de un enlace ya resuelto (v1.0.65).

	Existe para la reproducción manual: `source_results` ya llama a
	`record_choice()` en el momento de la selección, cuando el host todavía
	no se conoce. Volver a llamar allí duplicaría el conteo de todas las
	demás features, así que aquí se toca únicamente el host.
	"""
	if getSetting('personal.ranker.enabled') != 'true':
		return
	try:
		h = normalize_host(resolved_url)
		if not h:
			return
		key = 'host:%s' % h
		_apply_updates({key: ((1 if ok else 0), (0 if ok else 1), 1, 'host', h)})
	except Exception:
		from resources.lib.modules import log_utils
		log_utils.error()


def host_health(url_or_host):
	"""
	Historial de un host ya resuelto (v1.0.65).

	Devuelve {'host','pos','neg','exp','log_odds','samples'}. Un host sin
	historial devuelve log_odds 0.0 — neutro, nunca penalizado por nuevo.
	"""
	out = {'host': '', 'pos': 0, 'neg': 0, 'exp': 0, 'log_odds': 0.0, 'samples': 0}
	try:
		h = normalize_host(url_or_host)
		if not h:
			return out
		out['host'] = h
		pos, exp, neg = _load_features().get('host:%s' % h, (0, 0, 0))
		skipped = max(0, exp - pos)
		out.update({'pos': pos, 'neg': neg, 'exp': exp, 'samples': exp,
		            'log_odds': round(log((pos + _ALPHA) / (skipped + (_NEG_WEIGHT - 1.0) * neg + _ALPHA)), 3)})
		return out
	except Exception:
		return out


# ── API pública: medidas de red agregadas (v1.0.65) ───────────────────────────

def get_net(key):
	"""Devuelve (valor, muestras) de net_stats. (0.0, 0) si no existe."""
	con = None
	try:
		con = _connect()
		cur = con.cursor()
		_ensure_table(cur)
		cur.execute('SELECT num, cnt FROM net_stats WHERE key = ?', (key,))
		row = cur.fetchone()
		if not row:
			return (0.0, 0)
		return (float(row['num'] or 0.0), int(row['cnt'] or 0))
	except Exception:
		return (0.0, 0)
	finally:
		try:
			if con is not None: con.close()
		except Exception: pass


def update_net_ewma(key, value, alpha=0.30):
	"""
	Incorpora una medida a la media exponencial de `key`.

	La primera muestra se toma tal cual; a partir de ahí
	nuevo = alpha·medida + (1-alpha)·anterior.
	"""
	con = None
	try:
		value = float(value)
		if value <= 0:
			return
		prev, cnt = get_net(key)
		new = value if cnt <= 0 else (alpha * value + (1.0 - alpha) * prev)
		con = _connect()
		cur = con.cursor()
		_ensure_table(cur)
		cur.execute('''
			INSERT INTO net_stats (key, num, cnt, last_ts) VALUES (?, ?, 1, ?)
			ON CONFLICT(key) DO UPDATE SET num = ?, cnt = cnt + 1, last_ts = ?
		''', (key, new, int(time()), new, int(time())))
		con.commit()
	except Exception:
		from resources.lib.modules import log_utils
		log_utils.error()
	finally:
		try:
			if con is not None: con.close()
		except Exception: pass


# ── API pública: introspección y mantenimiento ────────────────────────────────

def get_stats():
	"""
	Devuelve resumen del modelo para mostrar al usuario.

	Returns:
		{
			'total_plays': N,
			'features': [
				{'type': 'quality', 'value': '4K', 'pos': 12, 'exp': 30,
				 'win_rate': 0.40, 'log_odds': 0.32},
				...
			]
		}
	"""
	try:
		feats = _load_features()
		out_feats = []
		for k, (pos, exp, neg) in feats.items():
			ftype, fval = k.split(':', 1)
			skipped = max(0, exp - pos)
			win_rate = (pos / float(exp)) if exp else 0.0
			lo = log((pos + _ALPHA) / (skipped + (_NEG_WEIGHT - 1.0) * neg + _ALPHA))
			out_feats.append({
				'type': ftype, 'value': fval,
				'pos': int(round(pos)), 'exp': int(round(exp)), 'neg': int(round(neg)),
				'win_rate': round(win_rate, 3),
				'log_odds': round(lo, 3),
			})
		# Ordenar por log_odds desc para que las más preferidas salgan arriba
		out_feats.sort(key=lambda x: (-x['log_odds'], -x['exp']))
		return {'total_plays': _total_plays(), 'features': out_feats}
	except Exception:
		from resources.lib.modules import log_utils
		log_utils.error()
		return {'total_plays': 0, 'features': []}


def reset():
	"""Borra todo el modelo. Acción destructiva — confirmar antes de llamar."""
	try:
		con = _connect()
		cur = con.cursor()
		_ensure_table(cur)
		cur.execute('DELETE FROM source_features')
		cur.execute('DELETE FROM net_stats')
		cur.execute('DELETE FROM ranker_pending')
		con.commit()
		_invalidate_cache()
		return True
	except Exception:
		from resources.lib.modules import log_utils
		log_utils.error()
		return False
	finally:
		try: con.close()
		except Exception: pass
