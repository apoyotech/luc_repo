# -*- coding: utf-8 -*-
"""
	luc_kodi Add-on — Release groups (v2.0.21)

	Semilla del ranker personal para el arranque en frio: el grupo que firma una
	release (la ultima parte tras el guion: '...HEVC-FLUX' -> 'flux') y el nivel
	que le dan las guias TRaSH segun el tipo de release (WEB, Blu-ray, Blu-ray
	UHD, REMUX).

	No es un filtro: solo da una pista pequena al orden, que se va apagando sola
	a medida que el ranker ve ese grupo en tus listas (ver source_ranker.py). La
	calidad nunca se salta: la pista mayor vale una fraccion de lo que separa
	1080p de 4K.

	Listas: TRaSH Guides (github.com/TRaSH-Guides/Guides, licencia MIT),
	custom formats de Radarr y Sonarr "WEB/HD Bluray/UHD Bluray/Remux Tier 01-03"
	y "LQ", copiadas el 28-oct-2026. Un grupo en dos niveles (cine y series)
	queda en el mejor. Del LQ se quitan los nombres de menos de tres letras y
	'Scene'/'NoGroup', que no identifican a un grupo.
"""

import re

_WEB_T1 = frozenset((
	'abbie', 'ajp69', 'apex', 'blutonium', 'byndr', 'casstudio', 'cmrg', 'crfw', 'crud', 'ctrlhd',
	'flux', 'gnome', 'hone', 'kings', 'kitsune', 'madsky', 'monkee', 'nosivid', 'ntb', 'ntg',
	'qoq', 'rawr', 'rtn', 'sic', 't6d', 'tepes', 'thefarm', 'tommy', 'visum', 'zorosenpai',
))
_WEB_T2 = frozenset((
	'3ctweb', 'btw', 'chotab', 'cinefeel', 'cit', 'coo7', 'db', 'deep', 'end', 'ethics', 'fc',
	'flights', 'ijp', 'ika', 'it00nz', 'jetix', 'khn', 'kimchi', 'lazy', 'miu', 'mzabi', 'npms',
	'nyh', 'orbitron', 'phoenix', 'playweb', 'psig', 'roccat', 'rtfm', 'sa89', 'sbr', 'sdcc',
	'sigma', 'smurf', 'spirit', 'tvsmash', 'welp', 'xebec',
))
_WEB_T3 = frozenset((
	'bloom', 'dooky', 'dracula', 'gnomission', 'ninjacentral', 'slignome', 'swaglander', 't4h',
	'vision',
))
_BLURAY_T1 = frozenset((
	'atelier', 'bbq', 'bmf', 'c0ke', 'chotab', 'crisc', 'ctrlhd', 'd-z0n3', 'dariush', 'decibel',
	'don', 'ebp', 'edph', 'geek', 'lolhd', 'ncmt', 'pter', 'tayto', 'tdd', 'tnp', 'viethd',
	'zorosenpai', 'zq',
))
_BLURAY_T2 = frozenset((
	'ea', 'hidt', 'hisd', 'ift', 'ntb', 'qoq', 'sa89', 'sbr',
))
_BLURAY_T3 = frozenset((
	'bhdstudio', 'hallowed', 'hifi', 'hone', 'lord', 'playhd', 'sphd', 'w4nk3r',
))
_UHD_T1 = frozenset((
	'ctrlhd', 'don', 'mainframe', 'w4nk3r',
))
_UHD_T2 = frozenset((
	'hidt', 'hqmux', 'randombytes',
))
_UHD_T3 = frozenset((
	'bhdstudio', 'hallowed', 'hone', 'pter', 'sphd', 'webdv',
))
_REMUX_T1 = frozenset((
	'3l', 'atelier', 'bizkit', 'bluranium', 'bmf', 'cinephiles', 'framestor', 'piramidhead', 'pmp',
	'wildcat', 'zq',
))
_REMUX_T2 = frozenset((
	'ncmt', 'playbd', 'sicfoi', 'surfinbird', 'tepes',
))
_REMUX_T3 = frozenset((
	'12gaugeshotgun', 'decibel', 'epsilon', 'hifi', 'ift', 'kralimarko', 'ntb', 'ptp', 'sumvision',
	'toa', 'triton',
))
_LQ = frozenset((
	'126811', '24xhd', '41rgb', '4k4u', 'aoc', 'aroma', 'axxo', 'azaze', 'barc0de', 'bauckley',
	'bdc', 'beast', 'brink', 'btm', 'c1nem4', 'c4k', 'cddhd', 'chaos', 'chd', 'chx', 'cine',
	'cleanup', 'collective', 'creative24', 'crewsade', 'ctfoh', 'd3g', 'ddr', 'depraved', 'dnl',
	'drx', 'epic', 'eureka', 'evo', 'fangding0', 'feranki1980', 'fgt', 'fmd', 'frds', 'fzhd',
	'galaxyrg', 'ghd', 'ghosts', 'gpthd', 'hdhub4u', 'hds', 'hdt', 'hdtime', 'hdwing', 'hiqve',
	'intenso', 'iplanet', 'ivy', 'jennaortega', 'jff', 'kingdom', 'kira', 'l0sernight', 'lama',
	'leffe', 'liber8', 'ligas', 'lucy', 'markii', 'megusta', 'mesc', 'mhd', 'msd', 'mteam',
	'mysilu', 'nhanc3', 'nhd', 'nikt0', 'nsd', 'oft', 'pahe', 'patomiel', 'prodji', 'psa', 'ptnk',
	'rarbg', 'rbb', 'rdn', 'rifftrax', 'ru4hd', 'santi', 'sasukeduck', 'shd', 'shieldbearer',
	'stuttershit', 'sunscreen', 'syncup', 'tbs', 'tekno3d', 'tigole', 'tiko', 'videohole',
	'visionplushdr', 'waf', 'wiki', 'worldmkv', 'x0r', 'xlf', 'yify', 'yts', 'zero00', 'zeus',
))

_TIERS = {
	'web': (_WEB_T1, _WEB_T2, _WEB_T3),
	'bluray': (_BLURAY_T1, _BLURAY_T2, _BLURAY_T3),
	'uhd': (_UHD_T1, _UHD_T2, _UHD_T3),
	'remux': (_REMUX_T1, _REMUX_T2, _REMUX_T3),
}

# Pista en unidades de log-odds del ranker (las mismas que suma cada feature
# aprendida). Con el peso por defecto (30) el nivel 1 suma 36 puntos: menos que
# HDR (50) y que Atmos (40), y nada frente a los 1000 que separan 1080p de 4K.
SEED = {3: 1.2, 2: 0.8, 1: 0.4, 0: 0.0, -1: -1.2}

# Tokens que pueden quedar tras el ultimo guion y no son un grupo.
_NOT_GROUP = frozenset((
	'aac', 'ac3', 'amzn', 'atmos', 'atvp', 'av1', 'avc', 'bluray', 'bdrip', 'brrip', 'complete',
	'criterion', 'dd5', 'ddp5', 'dl', 'dsnp', 'dts', 'dv', 'dovi', 'eac3', 'h264', 'h265', 'hdr',
	'hdr10', 'hevc', 'hmax', 'hybrid', 'imax', 'internal', 'multi', 'nf', 'pcok', 'proper', 'ray',
	'repack', 'remux', 'rip', 'sdr', 'season', 'truehd', 'uhd', 'web', 'webdl', 'webrip', 'x264',
	'x265', '1080p', '2160p', '720p', '480p', '4k', 'mkv', 'mp4', 'avi', 'sample', 'hd', 'ma', 'x',
	'dd', 'ddp', 'es', 'en', 'eng', 'spa', 'lat', 'dual', 'subs', 'sub', 'hdtv', 'xvid',
	'ingles', 'castellano', 'latino', 'spanish', 'english', 'vose', 'cast', 'ing',
))
_EXT_RE = re.compile(r'\.(mkv|mp4|avi|m4v|ts|m2ts|wmv)$', re.I)
_TAIL_TAG_RE = re.compile(r'(\s*[\[(][^\])]{1,30}[\])])+\s*$')
_GROUP_RE = re.compile(r'-([A-Za-z0-9][A-Za-z0-9@]{0,23})$')
_GROUP2_RE = re.compile(r'-([A-Za-z0-9]{1,8}-[A-Za-z0-9]{1,12})$')   # D-Z0N3
_WORD_RE = re.compile(r'[^a-z0-9]+')


def parse_group(name):
	"""'Movie.2024.2160p.WEB-DL.DV.HEVC-FLUX.mkv' -> 'flux'. '' when unknown."""
	try:
		s = str(name or '').split('|', 1)[0].strip()
		s = s.replace('\\', '/').rsplit('/', 1)[-1]
		s = _EXT_RE.sub('', s)
		s = _TAIL_TAG_RE.sub('', s)          # [rarbg], (EZTV), [ES-EN]...
		s = re.sub(r'\s+', '.', s.strip())
		m2 = _GROUP2_RE.search(s)
		if m2 and tier_of(m2.group(1).lower()):
			return m2.group(1).lower()
		m = _GROUP_RE.search(s)
		if not m:
			return ''
		g = m.group(1).split('@', 1)[0].strip('.').lower()   # Thor@HDSky -> thor
		if len(g) < 2 or g in _NOT_GROUP or g.isdigit():
			return ''
		return g
	except Exception:
		return ''


def release_kind(name):
	"""'remux', 'uhd', 'bluray', 'web' or '' from the release name."""
	try:
		words = set(_WORD_RE.split(str(name or '').lower()))
		flat = _WORD_RE.sub('', str(name or '').lower())
		if 'remux' in words or 'bdremux' in words or 'uhdremux' in flat:
			return 'remux'
		bluray = bool(words & {'bluray', 'bdrip', 'brrip', 'bd'}) or 'bluray' in flat
		if bluray:
			return 'uhd' if (words & {'2160p', '4k', 'uhd'}) else 'bluray'
		if words & {'web', 'webdl', 'webrip', 'amzn', 'nf', 'dsnp', 'atvp', 'hmax'} or 'webdl' in flat or 'webrip' in flat:
			return 'web'
		return ''
	except Exception:
		return ''


def tier_of(group, kind=''):
	"""3, 2, 1 (TRaSH tier 01/02/03), -1 (LQ) or 0 (unknown)."""
	if not group:
		return 0
	if group in _LQ:
		return -1
	if kind in _TIERS:
		for i, names in enumerate(_TIERS[kind]):
			if group in names:
				return 3 - i
	# Grupo con nivel en otro tipo de release (HONE es WEB tier 1 y saca Blu-ray
	# tier 3): encoder conocido, solo la pista minima.
	for tiers in _TIERS.values():
		for names in tiers:
			if group in names:
				return 1
	return 0


def item_name(item):
	try:
		return item.get('name') or item.get('display_name') or ''
	except Exception:
		return ''


def tier(item):
	name = item_name(item)
	return tier_of(parse_group(name), release_kind(name))
