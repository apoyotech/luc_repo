# -*- coding: utf-8 -*-
"""
	luc_kodi Add-on — Personal Ranker UI

	Renderiza el estado del modelo de ranking personalizado en una ventana
	TextViewer y gestiona la confirmación del reset.

	No contiene lógica del modelo — solo lectura de get_stats() y formato
	para mostrar al usuario.
"""

from resources.lib.modules import control
from resources.lib.modules import log_utils
from resources.lib.windows.textviewer import TextViewerXML
from resources.lib.database import source_ranker

LOGINFO = log_utils.LOGINFO

# Human-readable labels per feature type
_TYPE_LABELS = {
	'quality':  'Quality',
	'codec':    'Codec',
	'hdr':      'HDR',
	'audio':    'Audio',
	'provider': 'Provider',
	'debrid':   'Debrid',
	'size':     'Size',
	'seeders':  'Seeders',
	'host':     'Delivery host',
	'group':    'Release group',
}


def _format_stats(stats):
	"""Convert stats into BBCode text blocks for the textviewer."""
	total = stats.get('total_plays', 0)
	feats = stats.get('features', [])

	lines = []
	add = lines.append

	add('[B][COLOR ff00fa9a]Personal ranker · summary[/COLOR][/B]')
	add('')
	if total == 0:
		add('[COLOR ffaaaaaa]No data yet. The model learns from the sources '
			'you actually play.[/COLOR]')
		add('')
		add('Once you reach 10 plays it will start influencing the order.')
		if control.setting('personal.ranker.groups') != 'false':
			add('')
			add('Until then, releases from groups rated by TRaSH Guides get a small hint '
				'(Release group hints in Settings).')
		return '[CR]'.join(lines)

	add('[COLOR ffaaaaaa]Plays recorded:[/COLOR] [B]%d[/B]' % total)
	# v1.0.65 — velocidad de linea medida por el pre-flight. Es el numero que
	# decide que fuentes se marcan como pesadas en la lista de resultados.
	try:
		from resources.lib.modules import preflight
		_line, _samples = preflight.line_mbps(), preflight.line_samples()
		if _samples:
			add('[COLOR ffaaaaaa]Measured line speed:[/COLOR] [B]%.0f Mbps[/B] '
				'[COLOR ffaaaaaa](%d measurement%s)[/COLOR]'
				% (_line, _samples, '' if _samples == 1 else 's'))
		else:
			add('[COLOR ffaaaaaa]Measured line speed:[/COLOR] not measured yet')
	except Exception:
		pass
	if total < 10:
		add('[COLOR ffd25c1d]At least 10 plays are needed before the model '
			'affects ranking. %d to go.[/COLOR]' % (10 - total))
		if control.setting('personal.ranker.groups') != 'false':
			add('[COLOR ffaaaaaa]Meanwhile, release group hints from TRaSH Guides are in use.[/COLOR]')
	add('')

	# Group by feature type
	by_type = {}
	for f in feats:
		by_type.setdefault(f['type'], []).append(f)

	# Fixed type order for consistent readability
	type_order = ['quality', 'codec', 'hdr', 'audio', 'provider', 'debrid', 'size', 'seeders', 'group', 'host']

	for ftype in type_order:
		group = by_type.get(ftype) or []
		if not group:
			continue
		label = _TYPE_LABELS.get(ftype, ftype)
		add('[B][COLOR fffdb515]%s[/COLOR][/B]' % label)
		# Each feature: name, hits/exposures, win-rate, log-odds with color
		# Los hosts se cuentan por decenas cuando el debrid reparte por CDN;
		# solo se listan los diez con mas historial para no llenar la ventana.
		if ftype in ('host', 'group'):
			group = sorted(group, key=lambda x: -x['exp'])[:10]
		for f in group:
			lo = f['log_odds']
			# Green for positive preferences, red for negative, gray for neutral
			if   lo >  0.30: color = 'ff00fa9a'
			elif lo < -0.30: color = 'ffd25c1d'
			else:            color = 'ffaaaaaa'
			sign = '+' if lo >= 0 else ''
			_neg = f.get('neg', 0)
			_fail = ('  [COLOR ffd25c1d]failed %d[/COLOR]' % _neg) if _neg else ''
			add('  %-22s  picked %3d / shown %3d%s   '
				'[COLOR %s]%s%.2f[/COLOR]' %
				(f['value'][:22], f['pos'], f['exp'], _fail, color, sign, lo))
		add('')

	add('[COLOR ffaaaaaa]How to read this:[/COLOR]')
	add('· [B]picked[/B] = times you chose a source with that feature')
	add('· [B]shown[/B] = times it appeared in the candidate list')
	add('· [B]failed[/B] = times the link was dead or too slow for your line')
	add('· [B]log-odds[/B] = weight applied to ranking. Green = boosts up, red = pushes down.')
	add('· [B]Delivery host[/B] = the CDN that actually served the file, learned after playback.')
	try:
		_hl = source_ranker._halflife_days()
		if _hl:
			add('· Older choices fade: each one keeps half its weight after %d days '
				'(Forget older choices after, in Settings).' % _hl)
	except Exception:
		pass
	add('· [B]Release group[/B] = who made the release (the name after the last hyphen). '
		'Groups rated by TRaSH Guides start with a small hint that fades as the ranker sees them in your lists.')
	return '[CR]'.join(lines)


def show_stats():
	"""Show the model state in a TextViewer."""
	try:
		stats = source_ranker.get_stats()
		text = _format_stats(stats)
		viewer = TextViewerXML(
			'textviewer.xml',
			control.addonPath('plugin.video.luc_kodi'),
			heading='Personal ranker',
			text=text,
		)
		viewer.run()
		del viewer
	except Exception:
		log_utils.error()
		try:
			control.notification(
				title='luc_kodi',
				message='Error displaying ranker stats',
				time=4000,
			)
		except Exception:
			pass


def reset_with_confirm():
	"""Ask for confirmation and wipe the model if user accepts."""
	try:
		ok = control.yesnoDialog(
			line1='Reset the personal ranker model?',
			line2='Learned preferences and the measured line speed will be lost.',
			line3='This action cannot be undone.',
			heading='luc_kodi · Personal ranker',
			nolabel='Cancel',
			yeslabel='Reset',
		)
		if not ok:
			return
		if source_ranker.reset():
			control.notification(
				title='luc_kodi',
				message='Personal ranker reset',
				time=3000,
			)
			control.log('[ plugin.video.luc_kodi ]  Personal ranker reset by user', LOGINFO)
		else:
			control.notification(
				title='luc_kodi',
				message='Could not reset the ranker',
				time=4000,
			)
	except Exception:
		log_utils.error()
