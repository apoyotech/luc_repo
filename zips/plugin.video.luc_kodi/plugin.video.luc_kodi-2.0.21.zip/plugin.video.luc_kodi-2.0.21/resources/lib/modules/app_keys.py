# -*- coding: utf-8 -*-
"""
	luc_kodi Add-on
	Application keys of luc_kodi for TMDb, Fanart.tv, OMDb, Trakt, SIMKL,
	MDBList, PunchPlay, WeTrakr, OpenSubtitles and TheTVDB, used until a user enters
	their own in Settings.
"""

from base64 import b64decode
from hashlib import sha256

_TAG = b'luc_kodi/seal/v2'
_ID_FP = '0226a3aa221e913011f4dbe8eb5e2d8c4003d79a46cd340bd3476abd64157f43'
_BLOBS = {
	'tmdb': ('ozDOJfUYPXgg3KYlZ21tRU0+m6cTdeYeTla2yPBrDJQ=', '4b8cdffbd1cd45713559b4b71a5498d7fc3aaca28ffc69d7aa5696d6040228a5'),
	'fanart': ('QmYxAtmfA91xGY6WJcvzean0PKzxvocVQ1LYqim3nk0=', 'da0e6ed363492fb3de7338d2c29ced6a01cc0f490d60c57f2daab3f989728c7d'),
	'omdb': ('41lu26DOww==', 'c6955bd6649eae144448ecbaf75f94d1e5fc413e611449700284b707f81884d8'),
	'trakt_id': ('aE1iE4/oZnCzzpMByI30GtQ9h8peIajMX3qOFTTuOkApTOOalV8UDvrOaTbbE2AdGbqGfRg4NCi0Ys2Ulb06Ig==', '9336997cc9ae908cd817aa41eb37fa2f630349206a5885dc1df7ca63189d8aca'),
	'trakt_secret': ('CTEDz5ItOofa7Gkb3QPPf2aUzHWrbIumj/ILQddSKousgZiNHfs42yM3PdOyg7P/tcYy8beYCLt40l3qNOm1hQ==', '13916555d504f3e2b0b49bd8d8781a2218bcbbc00bdb5669e14172f679688ca5'),
	'simkl': ('UfBk6aVEkfnqPEL1UyRQiHE2W07X4l0N6CGvqJzQ3mB9XO+xLRWBDiI/TlbfD4fgOq/YxOZlXILitnapClrA8w==', 'bb2d6eab7aa419585c8ab89b087c3e7ea4c81b04324d5a8aa1d24b3b179a6c8d'),
	'simkl_v2': ('HUzTpfE56YWVeM40bTK/3ydx7huYaOTNT5zfHjm1wlNHnTTVWWj06GhGZt7AZKjYcrNE8jLX+o76JsXj+c6CRA==', '07f0a3b331bc8051d1da59ca79b5b8d157aaed7dcc0aee984f086e179b2c9d80'),
	'mdblist': ('dDbBcaDyGTxW2Mtkh0Gv6pfu8mWsWpD3Kog40PlKvjrOObFtwbFcjA==', '808e64b3c7108c69dc59359fd0b8d65bb00c4c0e8ca73f6699a407d60a7c11d6'),
	'punchplay': ('qX0Efy8cw0fGER36LLsXFHPmnG01OaSTUQYsSA==', '19fb1cab845d3644f55ab4307c057d81579b11e05687b37f69caadf4d083e43e'),
	'opensubs': ('wkecpki/yOBM0hzE2PVOkiGUj3Pou5sn6w5LqYAB4HI=', '25e7d220ede50897958bf1df97f676058d838748e0092776644d206b38c17734'),
	'wetrakr': ('Mg7Q3BhMU/I2mMzk39xDZtgP8x5JrRq5V9SwN75B/Lk=', 'f2363741bf2fae7463a5a5a24fbe842f79b850fb1db4190fe3a09bce60d20336'),
	'tvdb': ('/5ZYWNNCgruh8TwvPZ1UcAylJ7A9uELoDYGpbjx4O0ZZgFwe', 'c656182b797bf0508b042a981d0403484aed868a63c60052da8dd606be0956e4'),
}
_cache = {}
_host = None        # (running_id, is_official)
_warned = False


def _stream(addon_id, name, n):
	out, i = b'', 0
	while len(out) < n:
		out += sha256(_TAG + b'|' + addon_id.encode() + b'|' + name.encode() + b'|' + str(i).encode()).digest()
		i += 1
	return out[:n]


def _unseal(name, addon_id):
	"""Plain value of `name` for `addon_id`, or '' when it does not belong to it."""
	try:
		blob, fp = _BLOBS[name]
		raw = b64decode(blob)
		text = bytes(a ^ b for a, b in zip(raw, _stream(addon_id or '', name, len(raw)))).decode('ascii')
		if sha256(_TAG + b'|fp|' + name.encode() + b'|' + text.encode()).hexdigest() == fp:
			return text
	except Exception:
		pass
	return ''


def _id_from_addon_xml():
	try:
		import os, re
		here = os.path.dirname(os.path.abspath(__file__))
		path = os.path.join(here, os.pardir, os.pardir, os.pardir, 'addon.xml')
		with open(path, 'rb') as f:
			m = re.search(rb'<addon\s[^>]*?\bid\s*=\s*["\']([^"\']+)["\']', f.read(4096))
		return m.group(1).decode('utf-8') if m else ''
	except Exception:
		return ''


def _running_id():
	try:
		import xbmcaddon
		aid = xbmcaddon.Addon().getAddonInfo('id') or ''
		if aid:
			return aid
	except Exception:
		pass
	return _id_from_addon_xml()


def _host_info():
	global _host
	if _host is None:
		aid = _running_id()
		_host = (aid, sha256(aid.encode('utf-8')).hexdigest() == _ID_FP)
	return _host


def _warn_foreign(aid):
	global _warned
	if _warned:
		return
	_warned = True
	try:
		import xbmc
		xbmc.log('[ %s ] The application keys bundled with luc_kodi only work in luc_kodi. '
		         'Enter your own keys in Settings.' % (aid or 'unknown add-on'), xbmc.LOGWARNING)
	except Exception:
		pass


def sealed_ok():
	"""True when the bundled keys open for the add-on that is running."""
	return _host_info()[1]


def get(name):
	"""Plain value of one application credential, or '' if unknown or not ours."""
	if name in _cache:
		return _cache[name]
	aid, official = _host_info()
	value = _unseal(name, aid) if official else ''
	if not value and name in _BLOBS and not official:
		_warn_foreign(aid)
	_cache[name] = value
	return value
