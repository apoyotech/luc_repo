# -*- coding: utf-8 -*-
"""
	luc_kodi Add-on
"""

from resources.lib.modules.control import setting as getSetting, refresh as containerRefresh, addonInfo, progressDialogBG, monitor
from resources.lib.modules import trakt
from resources.lib.modules import simkl
traktIndicators = trakt.getTraktIndicatorsInfo()
# v1.0.18: SIMKL as alternative indicator source. Active when Trakt is NOT
# the chosen source AND the user explicitly opted in via simkl.indicators.
simklIndicators = (not traktIndicators) and simkl.getSimklIndicatorsInfo()


def getMovieIndicators(refresh=False):
	try:
		if traktIndicators:
			if not refresh: timeout = 720
			elif trakt.getMoviesWatchedActivity() < trakt.timeoutsyncMovies(): timeout = 720
			else: timeout = 0
			indicators = trakt.cachesyncMovies(timeout=timeout)
			return indicators
		elif simklIndicators:
			if not refresh: timeout = 720
			elif simkl.getMoviesWatchedActivity() < simkl.timeoutsyncMovies(): timeout = 720
			else: timeout = 0
			indicators = simkl.cachesyncMovies(timeout=timeout)
			return indicators
		else:
			from resources.lib.database import watchedcache
			indicators = watchedcache
			return indicators
	except:
		from resources.lib.modules import log_utils
		log_utils.error()

def getTVShowIndicators(refresh=False):
	try:
		if traktIndicators:
			if not refresh: timeout = 720
			elif trakt.getEpisodesWatchedActivity() < trakt.timeoutsyncTVShows(): timeout = 720
			else: timeout = 0
			indicators = trakt.cachesyncTVShows(timeout=timeout)
			return indicators
		elif simklIndicators:
			if not refresh: timeout = 720
			elif simkl.getEpisodesWatchedActivity() < simkl.timeoutsyncTVShows(): timeout = 720
			else: timeout = 0
			indicators = simkl.cachesyncTVShows(timeout=timeout)
			return indicators
		else:
			from resources.lib.database import watchedcache
			indicators = watchedcache
			return indicators
	except:
		from resources.lib.modules import log_utils
		log_utils.error()

def getSeasonIndicators(imdb, tvdb, refresh=False):
	try:
		if traktIndicators:
			timeoutsyncSeasons = trakt.timeoutsyncSeasons(imdb, tvdb)
			if timeoutsyncSeasons is None: return # if no entry means no completed season watched so do not make needless requests 
			if not refresh: timeout = 720
			elif trakt.getEpisodesWatchedActivity() < timeoutsyncSeasons: timeout = 720
			else: timeout = 0
			indicators = trakt.cachesyncSeasons(imdb, tvdb, timeout=timeout)
			return indicators
		else:
			# v2.0.23: misma forma que Trakt, (temporadas, recuentos). Los menus
			# leen indicators[0] / indicators[1]; con el modulo suelto eso
			# lanzaba TypeError y se perdia el menu contextual entero de cada
			# serie y temporada (ni "Marcar como visto" salia).
			from resources.lib.database import watchedcache
			return (watchedcache, watchedcache)
	except:
		from resources.lib.modules import log_utils
		log_utils.error()

def getMovieOverlay(indicators, imdb):
	if not indicators: return '4'
	try:
		if traktIndicators or simklIndicators:
			# Both return the same shape: list of IMDb IDs of watched movies.
			playcount = [i for i in indicators if i == imdb]
			playcount = '5' if len(playcount) > 0 else '4'
			return playcount
		else: # sin cuenta de tracking: base local (watchedcache)
			playcount = indicators.get_watched('movie', imdb, '')
			return str(playcount)
	except:
		from resources.lib.modules import log_utils
		log_utils.error()
		return '4'

def getTVShowOverlay(indicators, imdb, tvdb): # tvdb no longer used
	if not indicators: return '4'
	try: #{1: {'total': 10, 'watched': 10, 'unwatched': 0}, 2: {'total': 2, 'watched': 2, 'unwatched': 0}}
		if isinstance(indicators, (dict, list, tuple)): # datos de Trakt; si no, la base local
			playcount = {'total': 0, 'watched': 0}
			for key, value in iter(indicators.items()):
				playcount['total'] += value['total']
				playcount['watched'] += value['watched']
			playcount = '5' if playcount['total'] == playcount['watched'] else '4'
			return playcount
		else: # sin cuenta de tracking: base local (watchedcache)
			return _local_overlay(indicators, imdb, tvdb)
	except:
		from resources.lib.modules import log_utils
		log_utils.error()
		return '4'

def getSeasonOverlay(indicators, imdb, tvdb, season): # tvdb no longer used
	if not indicators: return '4'
	try:
		if isinstance(indicators, (dict, list, tuple)): # datos de Trakt; si no, la base local
			playcount = [i for i in indicators if int(season) == int(i)]
			playcount = '5' if len(playcount) > 0 else '4'
			return playcount
		else: # sin cuenta de tracking: base local (watchedcache)
			return _local_overlay(indicators, imdb, tvdb, season)
	except:
		from resources.lib.modules import log_utils
		log_utils.error()
		return '4'

def getEpisodeOverlay(indicators, imdb, tvdb, season, episode):
	if not indicators: return '4'
	try:
		if traktIndicators:
			playcount = [i[2] for i in indicators if (i[0].get('imdb') == imdb or str(i[0].get('tvdb')) == tvdb)]
			playcount = playcount[0] if len(playcount) > 0 else []
			playcount = [i for i in playcount if int(season) == int(i[0]) and int(episode) == int(i[1])]
			playcount = '5' if len(playcount) > 0 else '4'
			return playcount
		else: # sin cuenta de tracking: base local (watchedcache)
			playcount = indicators.get_watched_episode('episode', imdb, '', season=season, episode=episode)
			return str(playcount)
	except:
		from resources.lib.modules import log_utils
		log_utils.error()
		return '4'

def getShowCount(indicators, imdb, tvdb): # ID's currently not used. totals from indicators
	try:
		if traktIndicators:
			if not indicators: return None
			result = {'total': 0, 'watched': 0, 'unwatched': 0}
			for key, value in iter(indicators.items()):
				result['total'] += value['total']
				result['watched'] += value['watched']
				result['unwatched'] += value['unwatched']
			return result
		else: return None # sin cuenta de tracking no hay recuentos por serie
	except:
		from resources.lib.modules import log_utils
		log_utils.error()
		return None

def getSeasonCount(imdb, tvdb, season=None):
	try:
		if all(not value for value in (imdb, tvdb)): return
		if not traktIndicators: return None # sin cuenta de tracking no hay recuentos por serie
		result = trakt.seasonCount(imdb, tvdb)
		if not result: return None
		if not season: return result
		else: return result.get(int(season))
	except:
		from resources.lib.modules import log_utils
		log_utils.error()
		return None

def _trakt_scrobble_owns_history():
	"""True cuando el scrobble de Trakt esta activo y, por tanto, es EL de
	/scrobble/stop quien escribe el historial de esta reproduccion.

	v1.0.79. Habia dos caminos independientes marcando visto la misma sesion:
	este (POST /sync/history al llegar al 85 % DURANTE la reproduccion) y el
	/scrobble/stop de player.set_scrobble() al parar. Consecuencia: una entrada
	duplicada en el historial de Trakt para un solo visionado, y un 409 en el
	scrobble posterior que hacia creer al addon que habia fallado -- se saltaba
	el espejo local y sacaba un aviso de error falso. La documentacion de Trakt
	lo dice sin rodeos: si quieres un umbral distinto del 80 %, manda tu la
	pausa para no crear scrobbles duplicados. Aqui se cede el historial al
	scrobble y este camino deja de escribir en Trakt. El indicador de visto
	aparece al parar en vez de al 85 %, que es cuando el usuario puede verlo
	de todas formas.

	No se lee al importar el modulo: con reuselanguageinvoker el modulo
	sobrevive entre invocaciones y el ajuste se quedaria congelado.
	"""
	return getSetting('trakt.scrobble') == 'true' and trakt.getTraktCredentialsInfo()


def markMovieDuringPlayback(imdb, watched):
	try:
		if traktIndicators:
			if int(watched) == 5 and _trakt_scrobble_owns_history(): return
			if int(watched) == 5: trakt.markMovieAsWatched(imdb)
			else: trakt.markMovieAsNotWatched(imdb)
			trakt.cachesyncMovies()
		else:
			from resources.lib.database import watchedcache
			watchedcache.change_watched('movie', imdb, '', watched=int(watched))
	except:
		from resources.lib.modules import log_utils
		log_utils.error()

def markEpisodeDuringPlayback(imdb, tvdb, season, episode, watched):
	try:
		if traktIndicators:
			if int(watched) == 5 and _trakt_scrobble_owns_history(): return
			if int(watched) == 5: trakt.markEpisodeAsWatched(imdb, tvdb, season, episode)
			else: trakt.markEpisodeAsNotWatched(imdb, tvdb, season, episode)
			trakt.cachesyncTV(imdb, tvdb) # updates all watched shows, as well as season indicators and counts for given ID of show
		else:
			from resources.lib.database import watchedcache
			watchedcache.change_watched('episode', imdb, '', season=season, episode=episode, watched=int(watched))
	except:
		from resources.lib.modules import log_utils
		log_utils.error()

def movies(name, imdb, watched):
	try:
		if traktIndicators:
			if int(watched) == 5: trakt.watch(content_type='movie', name=name, imdb=imdb, refresh=True)
			else: trakt.unwatch(content_type='movie', name=name, imdb=imdb, refresh=True)
		else:
			from resources.lib.database import watchedcache
			watchedcache.change_watched('movie', imdb, '', title=name, watched=int(watched))
			containerRefresh()
	except:
		from resources.lib.modules import log_utils
		log_utils.error()

def tvshows(tvshowtitle, imdb, tvdb, season, watched, tmdb=None):
	try:
		if traktIndicators:
			content_type='season' if season else 'tvshow'
			if int(watched) == 5: trakt.watch(content_type=content_type, name=tvshowtitle, imdb=imdb, tvdb=tvdb, season=season, refresh=True)
			else: trakt.unwatch(content_type=content_type, name=tvshowtitle, imdb=imdb, tvdb=tvdb, season=season, refresh=True)
		else: # v2.0.23: sin cuenta de tracking, cada episodio emitido a la base local
			from resources.lib.database import watchedcache
			name = addonInfo('name')
			dialog = progressDialogBG
			dialog.create(str(name), str(tvshowtitle))
			try:
				tmdb, aired = _local_aired(imdb, tvdb, tmdb)
				if season not in (None, ''): aired = {k: v for k, v in aired.items() if k == int(season)}
				items = [(s, e) for s in sorted(aired) for e in range(1, aired[s] + 1)]
				count = len(items)
				for n, (s, e) in enumerate(items):
					if monitor.abortRequested(): break
					dialog.update(int(100.0 * n / count), str(name), '%s S%02dE%02d' % (tvshowtitle, s, e))
					watchedcache.change_watched('episode', imdb, tmdb or '', season=s, episode=e, title=tvshowtitle, watched=int(watched))
			finally:
				try: dialog.close()
				except: pass
			containerRefresh()
	except:
		from resources.lib.modules import log_utils
		log_utils.error()

def seasons(tvshowtitle, imdb, tvdb, season, watched, tmdb=None):
	tvshows(tvshowtitle=tvshowtitle, imdb=imdb, tvdb=tvdb, season=season, watched=watched, tmdb=tmdb)

def episodes(name, imdb, tvdb, season, episode, watched):
	try:
		if traktIndicators:
			if int(watched) == 5: trakt.watch(content_type='episode', name=name, imdb=imdb, tvdb=tvdb, season=season, episode=episode, refresh=True)
			else: trakt.unwatch(content_type='episode', name=name, imdb=imdb, tvdb=tvdb, season=season, episode=episode, refresh=True)
		else:
			from resources.lib.database import watchedcache
			watchedcache.change_watched('episode', imdb, '', season=season, episode=episode, title=name, watched=int(watched))
			containerRefresh()
	except:
		from resources.lib.modules import log_utils
		log_utils.error()


# ─────────────────────────────────────────────────────────────────────────────
#  v2.0.23 — VISTO SIN CUENTA DE TRACKING (series y temporadas)
#
#  Sin Trakt ni SIMKL, lo visto vive en la base local (watchedcache), que guarda
#  peliculas y episodios. Serie y temporada no se guardan: se DEDUCEN de sus
#  episodios. Antes esto seguia apuntando a metahandler, un addon que ya no se
#  usa: marcar una serie o temporada no hacia nada y su tick no salia nunca
#  (cada fila dejaba ademas un error en kodi.log).
#
#  Criterio de Lucian: solo cuentan los episodios YA EMITIDOS y sin especiales
#  (temporada 0). Una temporada esta vista cuando lo estan todos sus episodios
#  emitidos, y la serie cuando lo estan todas sus temporadas.
#
#  Los recuentos salen de la ficha de la serie en cache (una sola peticion, la
#  misma que usan los menus). Para pintar el tick, una serie sin NINGUN
#  episodio visto en local se resuelve con una consulta SQL, sin red.
# ─────────────────────────────────────────────────────────────────────────────
def _local_aired(imdb, tvdb, tmdb=None):
	"""(tmdb, {temporada: episodios_emitidos}) sin especiales."""
	from resources.lib.indexers import tmdb as tmdb_indexer
	from resources.lib.database import cache
	idx = tmdb_indexer.TVshows()
	if not tmdb:
		try:
			result = cache.get(idx.IdLookup, 96, imdb, tvdb)
			tmdb = str(result.get('id')) if isinstance(result, dict) and result.get('id') else ''
		except Exception: tmdb = ''
	if not tmdb: return '', {}
	show = cache.get(idx.get_showSeasons_meta, 96, tmdb)
	if not isinstance(show, dict): return tmdb, {}
	last = show.get('last_episode_to_air') or {}
	last_s = last.get('season_number') if isinstance(last, dict) else None
	last_e = last.get('episode_number') if isinstance(last, dict) else None
	ended = str(show.get('status') or '').lower() in ('ended', 'canceled')
	aired = {}
	for s in show.get('seasons') or []:
		try: num, total = int(s.get('season_number')), int(s.get('episode_count') or 0)
		except (TypeError, ValueError): continue
		if num < 1 or total < 1: continue
		if last_s is None: # TMDb sin ultimo episodio: solo vale si la serie ya termino
			if ended: aired[num] = total
		elif num < last_s: aired[num] = total
		elif num == last_s: aired[num] = min(total, int(last_e or 0))
	return tmdb, {k: v for k, v in aired.items() if v > 0}

def _local_overlay(indicators, imdb, tvdb, season=None):
	"""'5' visto / '4' no visto para una serie (season=None) o una temporada."""
	try:
		rows = indicators.get_episodes_watched('episode', imdb, '') if imdb else []
		seen = set()
		for r in rows:
			try:
				if int(r.get('overlay') or 0) == 5 and int(r.get('season') or 0) > 0:
					seen.add((int(r['season']), int(r['episode'])))
			except (TypeError, ValueError): continue
		if season not in (None, ''):
			season = int(season)
			if not any(s == season for s, _e in seen): return '4' # nada visto: sin red
		elif not seen: return '4'
		_tmdb, aired = _local_aired(imdb, tvdb)
		if season not in (None, ''): aired = {season: aired.get(season, 0)}
		if not aired or not all(aired.values()): return '4'
		done = all((s, e) in seen for s, n in aired.items() for e in range(1, n + 1))
		return '5' if done else '4'
	except Exception:
		from resources.lib.modules import log_utils
		log_utils.error()
		return '4'
