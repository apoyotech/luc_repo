"""
	luc_kodi Add-on

	Offcloud (v2.0.20) -- debrid de primera clase, al lado de Real-Debrid,
	Premiumize, AllDebrid y TorBox.

	La API de Offcloud cambio en marzo de 2026 (login con usuario/clave y
	?key= retirados; /api/login devuelve 404). Lo que se usa aqui sale de los
	clientes que la siguen hoy: StremThru (store/offcloud, oct-2026),
	MediaFusion (providers/torrents/offcloud.rs, oct-2026) y Umbrella 6.7.98.

	  Autenticacion   Authorization: Bearer <token>. El token es el de la
	                  asociacion por codigo (offcloud.com/activate) o la API key
	                  de la cuenta; los dos funcionan igual.
	  Cuenta          GET  /api/account/info
	  Cache           POST /api/cache        {hashes}          -> {cachedItems}
	                  POST /api/cache/info   {urls, includeFiles} -> [{cached, files}]
	                  (la segunda es la que usa StremThru; se pregunta solo si
	                  la primera no contesta)
	  Reproducir      POST /api/cache/download {url}         -> [{filename, url, size}]
	                  (lo cacheado, sin pasar por la nube del usuario) y, si no,
	                  POST /api/cloud {url} + GET /api/cloud/explore/<id>
	  Nube            GET  /api/cloud/history, GET /api/cloud/remove/<id>
	  Asociacion      POST /oauth/device/code, POST /oauth/token

	Las respuestas de Offcloud no son uniformes (lista o dict segun la ruta y la
	version), asi que todo se lee con guardas y nada se indexa a pelo.
"""

import re
import requests
from sys import argv
from threading import Thread
from resources.lib.modules import control
from resources.lib.modules.context_hub import attach_cm
from resources.lib.modules import log_utils
from resources.lib.modules import string_tools
from resources.lib.modules.source_utils import supported_video_extensions, lang_ep_numbers, loose_episode_pick

getLS = control.lang
getSetting = control.setting
site_url = 'https://offcloud.com'
base_url = site_url + '/api'
oauth_base = site_url + '/oauth'
activate_url = site_url + '/activate'
oc_icon = control.joinPath(control.artPath(), 'offcloud.png')
addonFanart = control.addonFanart()

session = requests.Session()
session.mount(site_url, requests.adapters.HTTPAdapter(max_retries=1))

CACHE_CHUNK = 100 # hashes por consulta de cache, como TorBox y DMM
_AUTH_PROP = 'luc_kodi.offcloud.auth_notice' # un aviso de token caducado por sesion de Kodi


def norm_hash(h):
	"""Infohash a hex de 40 en minusculas. apibay lo da en MAYUSCULAS y algunos
	magnets vienen en base32 (32 caracteres); sin esto la lista de cacheados no
	casaria con el hash de la fuente."""
	h = (h or '').strip()
	if len(h) == 32:
		try:
			from base64 import b32decode
			from binascii import hexlify
			return hexlify(b32decode(h.upper())).decode('ascii').lower()
		except Exception:
			pass
	return h.lower()


def magnet_hash(link):
	m = re.search(r'btih:([a-z0-9]{32,40})', link or '', re.I)
	return norm_hash(m.group(1)) if m else ''


def _scrub(text):
	try:
		from resources.lib.jacksparrow.client import scrub_url
		return scrub_url(str(text))
	except Exception:
		return str(text)[:200]


class Offcloud:
	account = '/account/info'
	cache = '/cache'
	cache_info = '/cache/info'
	cache_download = '/cache/download'
	cloud = '/cloud'
	history = '/cloud/history'
	explore = '/cloud/explore/%s'
	remove = '/cloud/remove/%s'

	def __init__(self):
		self.name = 'Offcloud'
		self.api_key = getSetting('offcloud.token')
		self.sort_priority = getSetting('offcloud.priority')
		self.store_to_cloud = getSetting('offcloud.saveToCloud') == 'true'
		self.timeout = 20.0
		self.last_status = None # codigo HTTP de la ultima llamada (None = sin red)
		self.auth_failed = False

	# ── transporte ─────────────────────────────────────────────────────────
	def _request(self, method, path, params=None, json=None, base=None, auth=True):
		"""JSON de la respuesta (dict o lista); None ante un fallo de red, sin
		token o con cuerpo que no es JSON. Nunca lanza."""
		self.last_status = None
		if auth and not self.api_key: return None
		headers = {'User-Agent': 'luc_kodi', 'Accept': 'application/json'}
		if auth: headers['Authorization'] = 'Bearer %s' % self.api_key
		url = '%s%s' % (base or base_url, path)
		try:
			response = session.request(method, url, params=params, json=json, headers=headers, timeout=self.timeout)
		except Exception as e:
			log_utils.log('Offcloud network error: %s (%s %s)' % (_scrub(e), method.upper(), path), level=log_utils.LOGWARNING)
			return None
		self.last_status = response.status_code
		try: result = response.json()
		except Exception: result = None
		err = result.get('error') if isinstance(result, dict) else None
		if response.status_code in (401, 403) or (isinstance(err, str) and err.upper() in ('NOAUTH', 'UNAUTHORIZED')):
			self.auth_failed = True
			log_utils.log('Offcloud auth error: HTTP %s %s [%s %s]' % (response.status_code, err or '', method.upper(), path), level=log_utils.LOGWARNING)
			if auth: self._auth_notice()
		elif response.status_code == 429:
			log_utils.log('Offcloud rate limit (429) [%s %s]' % (method.upper(), path), level=log_utils.LOGWARNING)
		elif response.status_code >= 400:
			body = ''
			try: body = _scrub(response.text[:300])
			except Exception: pass
			log_utils.log('Offcloud HTTP %s [%s %s] %s' % (response.status_code, method.upper(), path, body), level=log_utils.LOGDEBUG)
		elif err:
			log_utils.log('Offcloud error "%s" [%s %s]' % (err, method.upper(), path), level=log_utils.LOGDEBUG)
		return result

	def _GET(self, path, params=None):
		return self._request('get', path, params=params)

	def _POST(self, path, json=None):
		return self._request('post', path, json=json)

	def _auth_notice(self):
		"""Token rechazado: se avisa una vez por sesion de Kodi, no en cada llamada."""
		try:
			home = control.homeWindow
			if home.getProperty(_AUTH_PROP) == 'true': return
			home.setProperty(_AUTH_PROP, 'true')
			control.notification(title='Offcloud', message=getLS(49112), icon=oc_icon)
		except Exception: pass

	@staticmethod
	def requote_uri(url):
		return requests.utils.requote_uri(url)

	def add_headers_to_url(self, url):
		return url

	# ── cuenta ─────────────────────────────────────────────────────────────
	def account_info(self):
		info = self._GET(self.account)
		return info if isinstance(info, dict) and not info.get('error') else {}

	@staticmethod
	def _expires(info):
		return str(info.get('expiration_date') or info.get('expirationDate') or '')[:10]

	@property
	def days_remaining(self):
		import datetime
		try:
			stamp = self._expires(self.account_info())
			return (datetime.datetime.strptime(stamp, '%Y-%m-%d') - datetime.datetime.today()).days
		except Exception: return None

	@staticmethod
	def _account_name(info):
		return str(info.get('email') or info.get('user_id') or info.get('userId') or '')

	def account_info_to_dialog(self):
		try:
			control.busy()
			info = self.account_info()
			control.hide()
			if not info:
				return control.okDialog(title='Offcloud', message=getLS(49113))
			premium = info.get('is_premium') if 'is_premium' in info else info.get('isPremium')
			items = []
			if info.get('email'): items.append('[B]Email[/B]: %s' % info['email'])
			uid = info.get('user_id') or info.get('userId')
			if uid: items.append('[B]User ID[/B]: %s' % uid)
			items.append('[B]Premium[/B]: %s' % ('Yes' if premium else 'No'))
			stamp = self._expires(info)
			items.append('[B]Expires[/B]: %s' % (stamp or '-'))
			try:
				import datetime as _dt
				items.append(getLS(40042) % (_dt.datetime.strptime(stamp, '%Y-%m-%d') - _dt.datetime.today()).days)
			except Exception: pass
			if 'can_download' in info:
				items.append('[B]Can download[/B]: %s' % ('Yes' if info.get('can_download') else 'No'))
			limits = info.get('limits') if isinstance(info.get('limits'), dict) else {}
			for key, label in (('cloud', 'Cloud limit'), ('premium', 'Premium limit'), ('links', 'Links limit')):
				if limits.get(key) not in (None, ''):
					try: items.append('[B]%s[/B]: {:,}'.format(int(limits[key])) % label)
					except Exception: items.append('[B]%s[/B]: %s' % (label, limits[key]))
			return control.selectDialog(items, 'Offcloud')
		except Exception:
			control.hide()
			log_utils.error()

	# ── cache ──────────────────────────────────────────────────────────────
	def check_cache(self, hashlist):
		"""Conjunto de hashes cacheados (hex en minusculas), o None si Offcloud no
		contesto a ningun trozo. Se pregunta en trozos de CACHE_CHUNK en paralelo.
		Por cada trozo: /cache (cachedItems) y, si esa ruta no contesta como se
		espera, /cache/info con magnets (la forma de StremThru)."""
		seen, uniq = set(), []
		for h in hashlist or []:
			h = norm_hash(h)
			if len(h) == 40 and h not in seen:
				seen.add(h)
				uniq.append(h)
		if not uniq or not self.api_key: return None
		cached, answered = set(), []
		def _one(chunk):
			res = self._POST(self.cache, json={'hashes': chunk})
			if isinstance(res, dict) and isinstance(res.get('cachedItems'), list):
				answered.append(1)
				cached.update(norm_hash(i) for i in res['cachedItems'] if isinstance(i, str))
				return
			if self.auth_failed: return
			res = self._POST(self.cache_info, json={'urls': ['magnet:?xt=urn:btih:%s' % h for h in chunk]})
			if isinstance(res, list):
				answered.append(1)
				for h, row in zip(chunk, res):
					if isinstance(row, dict) and row.get('cached'): cached.add(h)
		chunks = [uniq[i:i + CACHE_CHUNK] for i in range(0, len(uniq), CACHE_CHUNK)]
		if len(chunks) == 1: _one(chunks[0])
		else:
			threads = [Thread(target=_one, args=(c,)) for c in chunks]
			[t.start() for t in threads]
			[t.join() for t in threads]
		if not answered: return None
		if len(answered) < len(chunks):
			log_utils.log('Offcloud cache: %d of %d chunks answered' % (len(answered), len(chunks)), level=log_utils.LOGWARNING)
		return cached

	# ── ficheros de un magnet ──────────────────────────────────────────────
	@staticmethod
	def _file_rows(rows):
		"""Normaliza las varias formas de lista de ficheros de Offcloud a
		[{'filename', 'url', 'size'}]: dicts de /cache/download, dicts de
		/cloud/explore?format=detailed y la lista de URLs de la explore antigua."""
		out = []
		if isinstance(rows, dict): rows = rows.get('files') or rows.get('entries') or []
		if not isinstance(rows, list): return out
		for f in rows:
			if isinstance(f, str):
				url = f
				name = requests.utils.unquote(url.split('?', 1)[0].rstrip('/').split('/')[-1])
				size = 0
			elif isinstance(f, dict):
				url = f.get('url') or f.get('link') or ''
				name = f.get('filename') or f.get('name') or str(f.get('path') or '').split('/')[-1]
				if not name and url: name = requests.utils.unquote(url.split('?', 1)[0].split('/')[-1])
				try: size = int(f.get('size') or f.get('fileSize') or 0)
				except Exception: size = 0
			else: continue
			if url and name: out.append({'filename': name, 'url': url, 'size': size})
		return out

	def _instant_files(self, magnet_url):
		"""Lo cacheado sin anadirlo a la nube del usuario."""
		return self._file_rows(self._POST(self.cache_download, json={'url': magnet_url}))

	def add_magnet(self, magnet):
		return self._POST(self.cloud, json={'url': magnet})

	def create_transfer(self, magnet_url):
		"""requestId de la descarga en la nube ('' si Offcloud no la acepto)."""
		result = self.add_magnet(magnet_url)
		if not isinstance(result, dict) or result.get('error') or result.get('not_available'):
			if isinstance(result, dict) and result.get('not_available'):
				log_utils.log('Offcloud: not available (%s)' % result.get('not_available'), level=log_utils.LOGWARNING)
			return ''
		if result.get('status') in ('error', 'canceled'): return ''
		return str(result.get('requestId') or '')

	def _cloud_files(self, request_id, info=None):
		files = self._file_rows(self._GET(self.explore % request_id, params={'format': 'detailed'}))
		if files: return files
		# Un solo fichero: la entrada trae el enlace o el servidor y el nombre
		info = info or {}
		if info.get('url'):
			return self._file_rows([{'url': info['url'], 'filename': info.get('fileName'), 'size': info.get('fileSize')}])
		if info.get('server') and info.get('fileName'):
			url = 'https://%s.offcloud.com/cloud/download/%s/%s' % (info['server'], request_id, requests.utils.quote(info['fileName']))
			return [{'filename': info['fileName'], 'url': url, 'size': int(info.get('fileSize') or 0)}]
		return []

	def _cloud_route(self, magnet_url, wait=True):
		"""Segunda via: anadir a la nube y leer los ficheros. Lo cacheado sale como
		'downloaded' al momento; si no, se mira dos veces mas. Devuelve
		(ficheros, requestId)."""
		import time as _t
		result = self.add_magnet(magnet_url)
		if not isinstance(result, dict) or result.get('error') or result.get('not_available'):
			return [], ''
		request_id = str(result.get('requestId') or '')
		if not request_id: return [], ''
		status = result.get('status')
		tries = (0, 1.5, 3.0) if wait else (0,)
		for pause in tries:
			if pause:
				_t.sleep(pause)
				status = self._history_status(request_id) or status
			if status == 'downloaded':
				return self._cloud_files(request_id, result), request_id
			if status in ('error', 'canceled'): break
		# No estaba en cache: Offcloud lo habria empezado a bajar a la nube del
		# usuario sin que nadie lo pidiera (fuentes 'unchecked'). Se quita. Para
		# guardar algo no cacheado esta "Cache to Offcloud Cloud".
		Thread(target=self.delete_torrent, args=(request_id,)).start()
		log_utils.log('Offcloud: %s is not cached; removed from the cloud again' % (magnet_hash(magnet_url) or request_id), level=log_utils.LOGDEBUG)
		return [], ''

	def _history_status(self, request_id):
		for item in self.user_cloud() or []:
			if str(item.get('requestId')) == request_id: return item.get('status')
		return None

	def magnet_files(self, magnet_url, wait=True):
		"""(ficheros, requestId de la nube o '') de un magnet cacheado."""
		files = self._instant_files(magnet_url)
		if files or self.auth_failed: return files, ''
		return self._cloud_route(magnet_url, wait=wait)

	# ── reproducir ─────────────────────────────────────────────────────────
	def resolve_magnet(self, magnet_url, info_hash, season, episode, title):
		from resources.lib.modules.source_utils import seas_ep_filter, extras_filter
		try:
			title = title or ''
			extensions = tuple(supported_video_extensions())
			extras_filtering_list = tuple(i for i in extras_filter() if not i in title.lower())
			info_hash = norm_hash(info_hash)
			if info_hash and info_hash not in (magnet_url or '').lower():
				magnet_url = re.sub(r'btih:[a-z0-9]{32,40}', 'btih:' + info_hash, magnet_url, flags=re.I)
			files, request_id = self.magnet_files(magnet_url)
			files = [f for f in files if f['filename'].lower().endswith(extensions)]
			if not files:
				log_utils.log('Offcloud resolve: no playable file for %s' % (info_hash or 'magnet'), level=log_utils.LOGDEBUG)
				return None
			if season:
				pool = list(files)
				files = [f for f in pool if seas_ep_filter(season, episode, f['filename'])
						 and not any(x in f['filename'].lower() for x in extras_filtering_list)]
				# langhelper: packs numerados a su manera ("054.mkv"), como en TorBox
				_nums = lang_ep_numbers() if not files else []
				if _nums:
					_pool = [f for f in pool if not any(x in f['filename'].lower() for x in extras_filtering_list)]
					_pick = loose_episode_pick([f['filename'] for f in _pool], _nums)
					if _pick is not None: files = [_pool[_pick]]
				if not files:
					log_utils.log('Offcloud resolve: S%sE%s not found in %s' % (season, episode, ' | '.join(f['filename'] for f in pool[:8])), level=log_utils.LOGWARNING)
					return None
			else:
				if self._m2ts_check(files):
					log_utils.log('Offcloud: "%s" is a full Blu-ray disc (.m2ts); skipped' % (title or info_hash), level=log_utils.LOGWARNING)
					return None
				files = [f for f in files if not any(x in f['filename'].lower() for x in extras_filtering_list)] or files
				files.sort(key=lambda k: k['size'], reverse=True)
			return files[0]['url']
		except Exception:
			log_utils.error('Offcloud: Error RESOLVE MAGNET %s ' % (norm_hash(info_hash) or ''))
			return None

	def display_magnet_pack(self, magnet_url, info_hash):
		try:
			extensions = tuple(supported_video_extensions())
			files, request_id = self.magnet_files(magnet_url)
			return [{'link': f['url'], 'filename': f['filename'], 'size': f['size'] / 1073741824}
					for f in files if f['filename'].lower().endswith(extensions)] or None
		except Exception:
			log_utils.error()
			return None

	def unrestrict_link(self, link):
		"""Los enlaces de Offcloud ya son el fichero: no hay paso de desbloqueo."""
		return link

	def add_uncached_torrent(self, magnet_url, pack=False):
		control.busy()
		request_id = self.create_transfer(magnet_url)
		control.hide()
		if not request_id: return control.okDialog(title=getLS(40018), message=getLS(33586))
		control.okDialog(title='default', message=getLS(40101) % 'Offcloud')
		return False # como TorBox: se reproduce cuando Offcloud termina

	def _m2ts_check(self, files):
		return any(f['filename'].lower().endswith('.m2ts') for f in files)

	# ── asociacion ─────────────────────────────────────────────────────────
	def auth(self):
		"""Codigo de dispositivo en offcloud.com/activate, con la ventana comun de
		asociacion y QR local. Si Offcloud no da codigo, se ofrece pegar la API
		key de la cuenta."""
		try:
			r = session.post('%s/device/code' % oauth_base, json={}, timeout=self.timeout,
							 headers={'User-Agent': 'luc_kodi', 'Accept': 'application/json'})
			data = r.json() if r.status_code < 400 else {}
		except Exception as e:
			log_utils.log('Offcloud auth: device/code error: %s' % _scrub(e), level=log_utils.LOGWARNING)
			data = {}
		device_code = (data or {}).get('device_code') if isinstance(data, dict) else None
		user_code = str((data or {}).get('user_code') or '') if isinstance(data, dict) else ''
		if not device_code or not user_code:
			log_utils.log('Offcloud auth: no device code; offering the API key instead', level=log_utils.LOGINFO)
			return self.auth_api_key(ask=True)
		verify_url = data.get('verification_uri') or activate_url
		qr_url = data.get('verification_uri_complete') or ''
		try: interval = max(int(data.get('interval') or 5), 2)
		except Exception: interval = 5
		try: expires_in = int(data.get('expires_in') or 600)
		except Exception: expires_in = 600

		from resources.lib.modules import device_auth
		dialog = device_auth.start('offcloud', verify_url, user_code, qr_data=qr_url or verify_url,
								   expires_in=expires_in, qr_has_code=bool(qr_url))
		token, failed, elapsed = None, '', 0
		try:
			while elapsed < expires_in and not token and not failed:
				if dialog.iscanceled(): return False
				control.sleep(interval * 1000)
				elapsed += interval
				dialog.update(100 - int(100 * elapsed / expires_in))
				try:
					p = session.post('%s/token' % oauth_base, timeout=self.timeout,
									 headers={'User-Agent': 'luc_kodi', 'Accept': 'application/json'},
									 json={'grant_type': 'urn:ietf:params:oauth:grant-type:device_code', 'device_code': device_code})
					p = p.json()
				except Exception: continue
				if not isinstance(p, dict): continue
				if p.get('access_token'): token = p['access_token']
				elif p.get('error') == 'slow_down': interval += 5
				elif p.get('error') in ('expired_token', 'access_denied'): failed = p['error']
		finally:
			try: dialog.close()
			except Exception: pass
		if not token:
			control.notification(title='Offcloud', message=failed or 'Authorization timed out or cancelled', icon=oc_icon)
			return False
		return self._store_token(token)

	def auth_api_key(self, ask=False):
		"""Pegar la API key de la cuenta (offcloud.com > Account > API Key)."""
		try:
			if ask and not control.yesnoDialog(getLS(49114), '', ''): return False
		except Exception: pass
		key = control.dialog.input(getLS(49115))
		key = (key or '').strip()
		if not key: return False
		return self._store_token(key)

	def _store_token(self, token):
		self.api_key = token
		self.auth_failed = False
		info = self.account_info()
		if not info and self.auth_failed:
			self.api_key = getSetting('offcloud.token')
			control.okDialog(title='Offcloud', message=getLS(49116))
			return False
		control.setSetting('offcloud.token', token)
		control.setSetting('offcloud.username', self._account_name(info) or 'Offcloud')
		try: control.homeWindow.clearProperty(_AUTH_PROP)
		except Exception: pass
		try:
			from resources.lib.modules.debrid_state import sync_state
			sync_state()
		except Exception: pass
		control.notification(title='Offcloud', message='Offcloud successfully authorized', icon=oc_icon)
		return True

	def remove_auth(self):
		try:
			self.api_key = ''
			control.setSetting('offcloud.token', '')
			control.setSetting('offcloud.username', '')
			try:
				from resources.lib.modules.debrid_state import sync_state
				sync_state()
			except Exception: pass
			control.notification(title='Offcloud', message=40009)
		except Exception: log_utils.error()

	# ── nube del usuario ───────────────────────────────────────────────────
	def user_cloud(self):
		res = self._GET(self.history)
		if isinstance(res, dict): res = res.get('history') or res.get('requests') or res.get('data') or []
		return [i for i in res if isinstance(i, dict)] if isinstance(res, list) else []

	def delete_torrent(self, request_id=''):
		return self._GET(self.remove % request_id)

	def user_cloud_clear(self):
		if not control.yesnoDialog(getLS(32056), '', ''): return
		items = self.user_cloud()
		threads = [Thread(target=self.delete_torrent, args=(str(i.get('requestId')),)) for i in items if i.get('requestId')]
		[t.start() for t in threads]
		[t.join() for t in threads]
		control.notification(title='Offcloud', message='%d items removed' % len(threads), icon=oc_icon)

	def user_cloud_to_listItem(self):
		sysaddon, syshandle = 'plugin://plugin.video.luc_kodi/', int(argv[1])
		quote_plus = requests.utils.quote
		folder_str, deleteMenu = getLS(40046).upper(), getLS(40050)
		items = [i for i in self.user_cloud() if i.get('status') == 'downloaded' and i.get('requestId')]
		items.sort(key=lambda k: str(k.get('createdOn') or ''), reverse=True)
		for count, item in enumerate(items, 1):
			try:
				cm = []
				name = string_tools.strip_non_ascii_and_unprintable(item.get('fileName') or item['requestId'])
				request_id = str(item['requestId'])
				status_str = '[COLOR %s]%s[/COLOR]' % (control.getHighlightColor(), str(item.get('status')).capitalize())
				cm.append((deleteMenu % 'Torrent', 'RunPlugin(%s?action=oc_DeleteUserTorrent&id=%s&name=%s)' %
					(sysaddon, request_id, quote_plus(name))))
				label = '%02d | [B]%s[/B] | [B]%s[/B] | [I]%s [/I]' % (count, status_str, folder_str, name)
				url = '%s?action=oc_BrowseUserTorrents&id=%s' % (sysaddon, request_id)
				li = control.item(label=label, offscreen=True)
				attach_cm(li, cm)
				li.setArt({'icon': oc_icon, 'poster': oc_icon, 'thumb': oc_icon, 'fanart': addonFanart, 'banner': oc_icon})
				control.setVideoLabels(li, None)
				control.addItem(handle=syshandle, url=url, listitem=li, isFolder=True)
			except Exception: log_utils.error()
		control.content(syshandle, 'files')
		control.directory(syshandle, cacheToDisc=False)

	def browse_user_torrents(self, request_id):
		sysaddon, syshandle = 'plugin://plugin.video.luc_kodi/', int(argv[1])
		quote_plus = requests.utils.quote
		extensions = tuple(supported_video_extensions())
		file_str, downloadMenu = getLS(40047).upper(), getLS(40048)
		info = next((i for i in self.user_cloud() if str(i.get('requestId')) == str(request_id)), {})
		files = [f for f in self._cloud_files(request_id, info) if f['filename'].lower().endswith(extensions)]
		for count, f in enumerate(files, 1):
			try:
				cm = []
				name = string_tools.strip_non_ascii_and_unprintable(f['filename'])
				size = ' | %.2f GB' % (f['size'] / 1073741824) if f['size'] else ''
				label = '%02d | [B]%s[/B]%s | [I]%s [/I]' % (count, file_str, size, name)
				link = self.requote_uri(f['url'])
				url = '%s?action=play_URL&url=%s&caller=offcloud&type=direct' % (sysaddon, quote_plus(link))
				cm.append((downloadMenu, 'RunPlugin(%s?action=download&name=%s&image=%s&url=%s&caller=offcloud&type=direct)' %
					(sysaddon, quote_plus(name), quote_plus(oc_icon), quote_plus(link))))
				li = control.item(label=label, offscreen=True)
				attach_cm(li, cm)
				li.setArt({'icon': oc_icon, 'poster': oc_icon, 'thumb': oc_icon, 'fanart': addonFanart, 'banner': oc_icon})
				control.setVideoLabels(li, None)
				control.addItem(handle=syshandle, url=url, listitem=li, isFolder=False)
			except Exception: log_utils.error()
		control.content(syshandle, 'files')
		control.directory(syshandle, cacheToDisc=False)

	def delete_user_torrent(self, request_id, name):
		if not control.yesnoDialog(getLS(40050) % '?\n' + (name or ''), '', ''): return
		result = self.delete_torrent(request_id)
		if self.last_status and self.last_status < 400 and not (isinstance(result, dict) and result.get('error')):
			control.notification(title='Offcloud', message='%s was removed' % name, icon=oc_icon)
			control.refresh()
		else:
			control.notification(title='Offcloud', message=getLS(49117), icon=oc_icon)
