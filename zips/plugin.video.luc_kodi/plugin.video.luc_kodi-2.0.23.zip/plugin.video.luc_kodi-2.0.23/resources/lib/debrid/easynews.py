"""
	luc_kodi Add-on
"""


from base64 import b64encode
import re
import requests
from urllib.parse import quote, quote_plus, urlparse
from resources.lib.modules import control
from resources.lib.modules.context_hub import attach_cm # v2.0.09: modern panel or classic Kodi menu
from resources.lib.modules import string_tools

getLS = control.lang
getSetting = control.setting
en_icon = control.joinPath(control.artPath(), 'easynews.png')
addonFanart = control.addonFanart()

# v2.0.19: the search request lives in the scraper (jacksparrow torrents/easynews.py,
# 2.0 /advanced with the plain 2.0 path as fallback); the manual search uses it too.


class EasyNews:
	def __init__(self):
		self.base_link = 'https://members.easynews.com'
		self.search_link = '/2.0/search/solr-search/'
		self.auth = self._get_auth()
		self.account_link = 'https://account.easynews.com/editinfo.php'
		self.usage_link = 'https://account.easynews.com/usageview.php'
		self.highlight_color = control.getHighlightColor()

	def _get_auth(self):
		auth = None
		try:
			username = getSetting('easynews.username')
			password = getSetting('easynews.password')
			if username == '' or password == '': return auth
			user_info = '%s:%s' % (username, password)
			user_info = user_info.encode('utf-8')
			auth = '%s%s' % ('Basic ', b64encode(user_info).decode('utf-8'))
		except:
			from resources.lib.modules import log_utils
			log_utils.error()
		return auth

	def search(self):
		from resources.lib.menus import navigator
		navigator.Navigator().addDirectoryItem(getLS(32603) % self.highlight_color, 'en_Searchnew', 'search.png', 'DefaultAddonsSearch.png', isFolder=False)
		from sqlite3 import dbapi2 as database
		try:
			if not control.existsPath(control.dataPath): control.makeFile(control.dataPath)
			dbcon = database.connect(control.searchFile)
			dbcur = dbcon.cursor()
			dbcur.executescript('''CREATE TABLE IF NOT EXISTS easynews (ID Integer PRIMARY KEY AUTOINCREMENT, term);''')
			dbcur.execute('''SELECT * FROM easynews ORDER BY ID DESC''')
			dbcur.connection.commit()
			lst = []
			delete_option = False
			for (id, term) in sorted(dbcur.fetchall(), key=lambda k: re.sub(r'(^the |^a |^an )', '', k[1].lower()), reverse=False):
				if term not in str(lst):
					delete_option = True
					navigator.Navigator().addDirectoryItem(term, 'en_searchResults&query=%s' % term, 'search.png', 'DefaultAddonsSearch.png', isSearch=True, table='easynews')
					lst += [(term)]
		except:
			from resources.lib.modules import log_utils
			log_utils.error()
		finally:
			try:
				dbcur.close()
			except Exception:
				pass
			try:
				dbcon.close()
			except Exception:
				pass
		if delete_option:
			navigator.Navigator().addDirectoryItem(32605, 'cache_clearSearch', 'tools.png', 'DefaultAddonService.png', isFolder=False)
		navigator.Navigator().endDirectory()

	def search_new(self):
		k = control.keyboard('', control.lang(32010))
		k.doModal()
		query = k.getText() if k.isConfirmed() else None
		if not query: return control.closeAll()
		from sqlite3 import dbapi2 as database
		try:
			dbcon = database.connect(control.searchFile)
			dbcur = dbcon.cursor()
			dbcur.execute('''INSERT INTO easynews VALUES (?,?)''', (None, query))
			dbcur.connection.commit()
		except:
			from resources.lib.modules import log_utils
			log_utils.error()
		finally:
			try:
				dbcur.close()
			except Exception:
				pass
			try:
				dbcon.close()
			except Exception:
				pass
		control.closeAll()
		control.execute('ActivateWindow(Videos,plugin://plugin.video.luc_kodi/?action=en_searchResults&query=%s,return)' % quote_plus(query))

	def query_results_to_dialog(self, query):
		from sys import argv
		try:
			syshandle = int(argv[1])
			downloadMenu = control.lang(40048)
			# v2.0.19: the same request as the scraper (2.0 /advanced, up to 1000
			# files, falling back to the plain 2.0 path), so both find the same
			files = []
			from resources.lib.jacksparrow.sourcesdir.torrents import easynews as en_scraper
			results = en_scraper.source()._get(en_scraper.easynews_query(query), force_v2=True)
			if results: files = self._process_files(results)
		except:
			from resources.lib.modules import log_utils
			log_utils.error()

		for count, item in enumerate(files, 1):
			try:
				cm = []
				name = string_tools.strip_non_ascii_and_unprintable(item['name'])
				url_dl = item['url_dl']
				sysurl_dl = quote_plus(url_dl)
				size = str(round(float(int(item['rawSize'])) / 1048576000, 1))
				label = '%02d | [B]%s GB[/B] | [I]%s [/I]' % (count, size, name)
				url = 'plugin://plugin.video.luc_kodi/?action=en_resolve_forPlayback&url=%s' % sysurl_dl
				cm.append((downloadMenu, 'RunPlugin(plugin://plugin.video.luc_kodi/?action=download&name=%s&image=%s&url=%s&caller=easynews)' %
									(quote_plus(name), quote_plus(en_icon), sysurl_dl)))
				item = control.item(label=label, offscreen=True)
				attach_cm(item, cm)
				item.setArt({'icon': en_icon, 'poster': en_icon, 'thumb': en_icon, 'fanart': addonFanart, 'banner': en_icon})
				control.setVideoLabels(item, None)
				item.setLabel(label)
				control.addItem(handle=syshandle, url=url, listitem=item, isFolder=False)
			except:
				from resources.lib.modules import log_utils
				log_utils.error()
		control.content(syshandle, 'files')
		control.directory(syshandle, cacheToDisc=True)

	def _process_files(self, results):
		def _process():
			for item in files:
				try:
					valid_result = True
					size, post_title, ext, duration = item['4'], item['10'], item['11'], item['14']
					# v1.0.52: en el formato objeto 'hash' viene pelado y 'id' aporta el
					# sufijo de 4 caracteres que la URL de descarga necesita. El campo
					# '0' del formato antiguo ya trae el hash completo.
					post_hash = item.get('0') or ''
					if not post_hash:
						_sig = item.get('id')
						post_hash = '%s%s' % (item.get('hash') or '', '' if _sig is None else str(_sig))
					if not post_hash: continue
					if 'alangs' in item and item['alangs']: language = item['alangs']
					else: language = ''
					if 'type' in item and item['type'].upper() != 'VIDEO': valid_result = False
					elif 'virus' in item and item['virus']: valid_result = False
					elif item.get('passwd'): valid_result = False # post protegido con contrasena
					elif re.match(r'^\d+s', duration) or re.match(r'^[0-5]m', duration): valid_result = False
					if not valid_result: continue
					# v1.0.53: URL limpia. La cabecera Basic se adjunta en
					# _with_auth() justo antes de reproducir o descargar, para que
					# la contrasena no acabe en el directorio cacheado en disco
					# (directory(..., cacheToDisc=True)) ni en el menu contextual.
					stream_url = down_url + quote('/%s/%s/%s%s/%s%s' % (dl_farm, dl_port, post_hash, ext, post_title, ext))
					result = {'name': post_title, 'size': size, 'rawSize': item['rawSize'], 'url_dl': stream_url, 'version': 'version2', 'full_item': item, 'language': language}
					yield result
				except:
					from resources.lib.modules import log_utils
					log_utils.error()
		down_url = results.get('downURL') or '%s/dl' % self.base_link
		dl_farm = results.get('dlFarm') or 'auto'
		dl_port = results.get('dlPort') or 'auto'
		files = results.get('data', [])
		sources = list(_process())
		return sources

	def _with_auth(self, url):
		"""Adjunta la cabecera Basic justo antes de usar la URL."""
		if not url: return None
		if '|Authorization=' in url: return url
		if not url.startswith(self.base_link) and '/dl/' not in url: return url
		if not self.auth: return None
		return '%s|Authorization=%s' % (url, quote(self.auth))

	def resolve_forPlayback(self, url):
		from resources.lib.modules import player
		play_url = None
		try:
			# v2.0.19: the download server's own link when Easynews redirects to one
			from resources.lib.jacksparrow.sourcesdir.torrents import easynews as en_scraper
			play_url = en_scraper.source().resolve(url)
		except Exception:
			from resources.lib.modules import log_utils
			log_utils.error()
		if not play_url: play_url = self._with_auth(url)
		if not play_url:
			return control.notification(message='Easynews: no credentials set', icon=en_icon)
		return player.Player().play(play_url)

	def _fetch_page(self, url):
		"""v2.0.19: -> (HTTP status, html, final host). 0 when Easynews could not be reached."""
		try:
			r = requests.get(url, headers={'Authorization': self.auth, 'User-Agent': 'luc_kodi for Kodi'}, timeout=20)
			try: host = urlparse(r.url).netloc
			except Exception: host = ''
			return r.status_code, r.text or '', host
		except Exception as e:
			from resources.lib.modules import log_utils
			log_utils.log('EASYNEWS account: %s unreachable (%s)' % (urlparse(url).netloc, e.__class__.__name__), level=log_utils.LOGWARNING)
			return 0, '', ''

	@staticmethod
	def _cell_text(html):
		text = re.sub(r'<[^>]+>', ' ', html or '')
		text = text.replace('&nbsp;', ' ').replace('&amp;', '&')
		return re.sub(r'\s+', ' ', text).strip()

	def _label_pairs(self, html):
		"""v2.0.19: every two-cell row of a page as {label: value}, whatever the layout
		around it (the account pages are read by their labels, not by position)."""
		pairs = {}
		for row in re.findall(r'<tr[^>]*>(.*?)</tr>', html or '', re.S | re.I):
			cells = [self._cell_text(c) for c in re.findall(r'<t[dh][^>]*>(.*?)</t[dh]>', row, re.S | re.I)]
			cells = [c for c in cells if c]
			if len(cells) >= 2:
				pairs.setdefault(cells[0].rstrip(':').strip().lower(), cells[1])
		return pairs

	@staticmethod
	def _pick(pairs, *words):
		for label, value in pairs.items():
			if any(w in label for w in words): return value
		return ''

	def _credentials_status(self):
		"""v2.0.19: what the search API says of these credentials: 200, 401/403, 0 if unreachable."""
		try:
			r = requests.get('%s%s' % (self.base_link, self.search_link), headers={'Authorization': self.auth},
							 params={'gps': 'test', 'pby': 1, 'fty[]': 'VIDEO', 'st': 'basic', 'fly': 2}, timeout=20)
			return r.status_code
		except Exception:
			return 0

	def account(self):
		"""-> (account_info, usage_info) in the classic order, or (None, None).
		v2.0.19: also self._pairs (every label found on both pages) and self._codes, for
		the dialog when the classic layout is not there any more."""
		account_info = usage_info = None
		self._pairs, self._codes = {}, []
		from resources.lib.modules.dom_parser import parseDOM
		code, account_html, host = self._fetch_page(self.account_link)
		self._codes.append(('account', code, host))
		u_code, usage_html, u_host = self._fetch_page(self.usage_link)
		self._codes.append(('usage', u_code, u_host))
		self._pairs.update(self._label_pairs(account_html if code == 200 else ''))
		self._pairs.update(self._label_pairs(usage_html if u_code == 200 else ''))
		try:
			if code != 200 or not account_html or u_code != 200 or not usage_html: raise ValueError('page')
			account_info = parseDOM(account_html, 'form', attrs={'id': 'accountForm'})
			account_info = parseDOM(account_info, 'td')[0:11][1::3]
			usage_info = parseDOM(usage_html, 'div', attrs={'class': 'table-responsive'})
			usage_info = parseDOM(usage_info, 'td')[0:11][1::3]
			if len(account_info) < 4 or len(usage_info) < 3: raise ValueError('layout')
		except Exception:
			account_info = usage_info = None
		from resources.lib.modules import log_utils
		log_utils.log('EASYNEWS account: %s; %d labelled values read; classic layout %s'
					  % (', '.join('%s page HTTP %s%s' % (n, c, (' via %s' % h) if h else '') for n, c, h in self._codes),
						 len(self._pairs), 'found' if account_info else 'not found'), level=log_utils.LOGINFO)
		return account_info, usage_info

	def _classic_body(self, account_info, usage_info):
		from datetime import datetime
		import time
		expires = datetime.fromtimestamp(time.mktime(time.strptime(account_info[2], '%Y-%m-%d'))) # could utilize a new cleandate method
		days_remaining = (expires - datetime.today()).days
		expires = expires.strftime('%Y-%m-%d')
		body = []
		append = body.append
		append(getLS(40036) % account_info[0])  # Username
		append(getLS(40066) % account_info[1])  # Plan
		append(getLS(40037) % account_info[3])  # Status
		append(getLS(40041) % expires)               # Expires
		append(getLS(40042) % days_remaining) # Days Remaining
		append(getLS(32218) % usage_info[2])    # Loyalty
		append(getLS(32219) % usage_info[0].replace('Gigs', 'GB')) # Data Used
		append(getLS(32220) % re.sub(r'[</].+?>', '', usage_info[1].replace('Gigs', 'GB'))) # Data Remaining
		return body

	def _labelled_body(self):
		"""v2.0.19: the account read by its labels, plus a line saying the login works."""
		p = getattr(self, '_pairs', {}) or {}
		body = [getLS(40036) % (self._pick(p, 'username', 'user name') or getSetting('easynews.username')), getLS(48222)]
		found = 0
		for sid, words in ((40066, ('plan', 'package', 'service')), (40037, ('status',)), (40041, ('expir', 'renew', 'next bill')),
						   (32218, ('loyal',)), (32219, ('used', 'usage', 'download')), (32220, ('remain', 'left', 'available'))):
			value = self._pick(p, *words)
			if value:
				found += 1
				body.append(getLS(sid) % value.replace('Gigs', 'GB'))
		if found < 2: body.append(getLS(48223))
		return body

	def account_info_to_dialog(self):
		from resources.lib.windows.textviewer import TextViewerXML
		try:
			if not self.auth:
				return control.notification(message=48224, icon=en_icon)
			control.busy()
			account_info, usage_info = self.account()
			body = None
			if account_info and usage_info:
				try: body = self._classic_body(account_info, usage_info)
				except Exception: body = None
			if not body:
				# v2.0.19: the account pages did not give the classic table. Before,
				# this was always "Error retrieving EasyNews Account Info", for a wrong
				# password and for a page Easynews redesigned alike. Now the search API
				# tells which: wrong credentials, Easynews unreachable, or credentials
				# fine and only the account page unreadable (then what it shows).
				status = self._credentials_status()
				if status in (401, 403):
					control.hide()
					return control.notification(message=48220, icon=en_icon)
				if status != 200:
					control.hide()
					return control.notification(message=48221 if status == 0 else 32221, icon=en_icon)
				body = self._labelled_body()
			control.hide()
			windows = TextViewerXML('textviewer.xml', control.addonPath(control.addonId()), heading='[B]EasyNews[/B]', text='\n\n'.join(body))
			windows.run()
			del windows
		except:
			from resources.lib.modules import log_utils
			log_utils.error()
			control.hide()
