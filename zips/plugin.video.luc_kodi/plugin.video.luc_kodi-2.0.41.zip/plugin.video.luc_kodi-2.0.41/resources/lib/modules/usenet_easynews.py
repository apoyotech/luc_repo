# -*- coding: utf-8 -*-
"""
	luc_kodi - Easynews como proveedor Usenet para el scraper Newznab (v2.0.24 test)

	Modelo: el INDEXER (NZBGeek u otro Newznab) encuentra el NZB, EASYNEWS lo
	sirve por NNTP (tu cuenta de Easynews es tambien un servidor Usenet) y el
	motor local de luc_kodi (usenet_stream.py, en el servicio) lo reproduce
	al momento, sin descargarlo entero y sin pasar por ningun debrid.

	Este modulo es el pegamento del lado del plugin:
	  enabled()         ajuste newznab.use_easynews + credenciales de Easynews
	  nntp_config()     servidor/puerto/conexiones desde los ajustes
	  fetch_nzb()       baja el .nzb del indexer UNA vez y lo guarda en el
	                    perfil (usenet/nzb/<hash>.nzb, sin el apikey)
	  health_filter()   comprobacion de salud en el scraper: descarta los NZB
	                    borrados en Easynews y marca los verificados
	  resolve()         prepara la sesion en el servicio y devuelve la URL local
	  start_service() / stop_service()   arranque del motor en service.py
	  test()            accion de ajustes "Test Easynews Usenet (NNTP)"

	Las credenciales se leen de los ajustes en cada uso; no se escriben en
	ningun fichero ni salen en el log.
"""

import gzip
import hashlib
import json
import os
import re
import ssl
import threading
import time
from urllib.request import Request, urlopen

from resources.lib.modules import control
from resources.lib.modules import log_utils
from resources.lib.modules import usenet_core as core

getSetting = control.setting
LOGDEBUG = log_utils.LOGDEBUG

HEALTH_TTL_OK = 12 * 3600       # un NZB sano se da por bueno 12 h
# v2.0.33: un NZB borrado (DMCA) no vuelve: se recuerda 7 dias, no 1. Si cambian
# los proveedores de respaldo se vuelve a mirar (el nuevo puede tenerlo).
HEALTH_TTL_DEAD = 7 * 86400
HEALTH_TTL_PLAYED = 7 * 86400   # v2.0.33: un NZB que de verdad se reprodujo
PLAYED_MIN_BYTES = 64 * 1024 * 1024   # lo que hay que ver para darlo por bueno
ARCHIVE_CHECKS = 6              # v2.0.33: cabeceras de archivo que se leen por busqueda
NZB_KEEP_SECS = 3 * 86400       # los .nzb del perfil se limpian a los 3 dias
# Sube cada vez que el motor aprende a abrir algo que antes rechazaba (4 =
# RAR con un ajeno colado entre volumenes con nombre): lo rechazado por un motor
# anterior se vuelve a ofrecer.
ENGINE_VERSION = 11 # v2.0.37 (19-nov-2026): ISO de Blu-ray (UDF) leidas por dentro, discos Blu-ray enteros (listas de reproduccion) y RAR cifrados o con varios ficheros; los 'no se puede' de antes caducan. Antes 9 (v2.0.37): 7z partido con el primer trozo menor (150 MB + 500 MB), 7z cifrado con la clave en el NZB y RAR con volumenes .10 ... .223 sin ceros; antes v2.0.32: M2TS de Blu-ray; los que el motor 5 dio por no reproducibles se vuelven a mirar. Antes: v2.0.28: 7z 'store'; los 7z que dio por no reproducibles el motor 4 se vuelven a mirar
HEALTH_BUDGET_SECS = 18         # tiempo maximo de la comprobacion por busqueda
# v2.0.25: un NZB que el indexer tarda en dar no retiene la busqueda. Log del
# 2-nov-2026: en 6 de 7 busquedas un solo NZB agotaba los 20 s de espera y la
# lista tardaba 20,1 s en salir con los otros 7 ya comprobados en 2-7 s.
HEALTH_NZB_TIMEOUT = 8
HEALTH_WANT_OK = 8              # se para al encontrar estos releases buenos
HEALTH_CONNECTIONS = 8          # conexiones para STAT (Easynews permite 60)
UA = 'luc_kodi for Kodi'

_health_lock = threading.Lock()
_HEALTH_MEM = None
_HEALTH_MTIME = None
_SSL_CTX = None
_SSL_LOCK = threading.Lock()
_DISC_RE = re.compile(r'(?:^|[ ._\-\[(])(?:COMPLETE[ ._\-]+(?:UHD[ ._\-]+)?BLU-?RAY|BDMV|BD(?:25|50|66|100)|ISO|DISC\d*)(?:[ ._\-\])]|$)', re.I)
# v2.0.33 (kodi.log del 12-nov-2026): 'Project.Hail.Mary.2026.COMPLETE.2160p.USA.UHD.Blu-ray...-TMT' es
# el disco entero en 7z y se colaba: entre COMPLETE y BLU-RAY van la resolucion y la region. Hasta 5
# etiquetas en medio, y nunca si el nombre dice que es un fichero (x264/x265, REMUX, WEB): un pack de
# serie 'S01.COMPLETE.1080p.BluRay.x264' no es un disco.
_DISC_LOOSE_RE = re.compile(r'(?:^|[ ._\-\[(])COMPLETE(?:[ ._\-]+[A-Za-z0-9]{1,8}){0,5}?[ ._\-]+(?:UHD[ ._\-]+)?BLU-?RAY(?:[ ._\-\])]|$)', re.I)
_NOT_DISC_RE = re.compile(r'(?i)(?:^|[ ._\-\[(])(?:[xh][ ._]?26[45]|REMUX|WEB(?:-?DL|-?RIP)?|AVC[ ._\-]?REMUX)(?:[ ._\-\])]|$)')
# v2.0.33 (auditoria del 13-nov-2026): la regla amplia tomaba por disco 5 de cada 10 packs de
# temporada (en HEVC, AV1 o sin codec en el nombre) y, sin Premiumize ni TorBox, los quitaba de la
# lista. Un nombre con marca de temporada no es disco por la regla amplia; un disco de temporada
# sigue cayendo por la estricta (S01.COMPLETE.BLURAY) o por su primer trozo (v2.0.33).
_SEASON_MARK_RE = re.compile(r'(?i)(?:^|[ ._\-\[(])(?:S\d{1,2}(?:[ ._\-]?E\d{1,3})?|SEASONS?[ ._\-]?\d{1,2}|COMPLETE[ ._\-]SERIES)(?:[ ._\-\])]|$)')


def _ssl_context():
	global _SSL_CTX
	if _SSL_CTX is None:
		with _SSL_LOCK:
			if _SSL_CTX is None:
				_SSL_CTX = ssl.create_default_context()
	return _SSL_CTX


_ISO_RE = re.compile(r'(?i)(?:^|[ ._\-\[(])ISO(?:[ ._\-\])]|$)')


def is_iso(name):
	"""v2.0.37: release que dice en el nombre que es una imagen de disco ISO."""
	return bool(_ISO_RE.search(name or ''))


def is_disc(name):
	"""Imagen de disco Blu-ray (BDMV/ISO o el disco entero empaquetado)."""
	name = name or ''
	if _DISC_RE.search(name):
		return True
	return bool(_DISC_LOOSE_RE.search(name)) and not _NOT_DISC_RE.search(name) and not _SEASON_MARK_RE.search(name)


# -------------------------------------------------------------- ajustes -----
def _bool(id_, default='true'):
	v = getSetting(id_)
	return (v or default) == 'true'


def credentials():
	return (getSetting('easynews.username') or '').strip(), (getSetting('easynews.password') or '').strip()


def enabled():
	"""Easynews activado como reproductor de NZB y con credenciales."""
	if not _bool('newznab.use_easynews'):
		return False
	u, p = credentials()
	return bool(u and p)


def other_services():
	"""Hay otro servicio de NZB activo (Premiumize/TorBox) como respaldo."""
	pm = _bool('newznab.use_premiumize') and getSetting('premiumize.enable') == 'true' and bool(getSetting('premiumize.token'))
	tb = _bool('newznab.use_torbox') and getSetting('torbox.enable') == 'true' and bool(getSetting('torbox.token'))
	return pm or tb


def nntp_config():
	u, p = credentials()
	server = getSetting('newznab.en_server') or '0'
	host = core.EASYNEWS_HOSTS['us' if server == '1' else 'eu']
	port = 443 if (getSetting('newznab.en_port') or '0') == '1' else 563
	try: conns = int(getSetting('newznab.en_connections') or DEFAULT_CONNECTIONS)
	except ValueError: conns = DEFAULT_CONNECTIONS
	return {'host': host, 'port': port, 'user': u, 'password': p,
			'connections': max(2, min(conns, MAX_CONNECTIONS)), 'ssl': True, 'timeout': 20,
			'profile': _profile(), 'backups': backup_configs()}


MAX_CONNECTIONS = 60      # Easynews: 60 a la vez por cuenta, en todas las cuentas
DEFAULT_CONNECTIONS = 20


LOW_RAM_MB = 2048     # por debajo, Balanced pasa solo a Efficient
_TOTAL_RAM_MB = False
_RAM_TRIES = [0]


def _device_ram_mb():
	"""RAM total del aparato en MB segun Kodi, o None."""
	global _TOTAL_RAM_MB
	if _TOTAL_RAM_MB is not False:
		return _TOTAL_RAM_MB
	try:
		import xbmc
		raw = xbmc.getInfoLabel('System.Memory(total)') or ''
		m = re.search(r'([\d.,]+)\s*([GM])B', raw, re.I)
		if not m:
			_RAM_TRIES[0] += 1 # v2.0.41: Kodi aun no lo sabe; tras 3 intentos se deja de preguntar
			if _RAM_TRIES[0] >= 3: _TOTAL_RAM_MB = None
			return None
		n = float(m.group(1).replace(',', '.'))
		_TOTAL_RAM_MB = int(n * 1024) if m.group(2).upper() == 'G' else int(n)
		return _TOTAL_RAM_MB
	except Exception:
		return None


_PROFILE_NOTED = []


def _profile():
	"""0 Efficient, 1 Balanced. v2.0.32: Balanced pasa solo a Efficient en
	aparatos de menos de 2 GB de RAM (cajas y TV con skin y addons)."""
	try: p = max(0, min(1, int(getSetting('newznab.en_profile') or 1)))
	except ValueError: p = 1
	if p == 1:
		ram = _device_ram_mb()
		if ram and ram < LOW_RAM_MB:
			if not _PROFILE_NOTED:
				_PROFILE_NOTED.append(1)
				log_utils.log('USENET: %d MB of RAM on this device: the Efficient profile is used' % ram, level=log_utils.LOGINFO)
			return 0
	return p


_BK_SLOTS = {1: 'newznab.bk_', 2: 'newznab.bk2_'}


def backup_config(slot=1):
	"""v2.0.32 (informe L7): proveedor Usenet de respaldo n.º slot (1 o 2), solo
	para los articulos que Easynews ya no tiene. None si no esta configurado.
	Arreglo B2: un puerto escrito en el servidor ('host:443') manda sobre el
	desplegable, y la prueba lo dice."""
	pre = _BK_SLOTS.get(int(slot or 1), 'newznab.bk_')
	host = (getSetting(pre + 'host') or '').strip()
	if not host:
		return None
	host = re.sub(r'^\w+://', '', host).split('/')[0].strip()
	port = {'1': 443, '2': 119}.get(getSetting(pre + 'port') or '0', 563)
	typed = False
	m = re.match(r'^\[?([^\]]+?)\]?:(\d{2,5})$', host)
	if m:
		host, port, typed = m.group(1), int(m.group(2)), True
	# SSL salvo en los puertos clasicos sin cifrar (119 y los de Easynews sin SSL)
	ssl_on = port not in (119, 23, 25, 80, 110, 8000) if typed else port != 119
	try: conns = int(getSetting(pre + 'connections') or 4)
	except ValueError: conns = 4
	return {'host': host, 'port': port, 'ssl': ssl_on, 'timeout': 20, 'port_typed': typed, 'slot': int(slot or 1),
			'name': 'backup provider %d' % int(slot or 1),
			'user': (getSetting(pre + 'user') or '').strip(), 'password': getSetting(pre + 'pass') or '',
			'connections': max(1, min(conns, 20))}


def backup_configs():
	"""Los proveedores de respaldo configurados, por orden (1 y luego 2)."""
	return [b for b in (backup_config(1), backup_config(2)) if b]


_DIR_READY = False


def _usenet_dir():
	global _DIR_READY
	d = os.path.join(control.dataPath, 'usenet')
	if not _DIR_READY:
		nzb = os.path.join(d, 'nzb')
		if not os.path.isdir(nzb):
			try: os.makedirs(nzb)
			except OSError: pass
		_DIR_READY = os.path.isdir(nzb)
	return d


def nzb_dir():
	return os.path.join(_usenet_dir(), 'nzb')


def nzb_key(nzb_url):
	"""Misma clave que el 'hash' del scraper Newznab: md5 del enlace."""
	return hashlib.md5((nzb_url or '').encode('utf-8')).hexdigest()


def _mask(text, nzb_url=None):
	key = getSetting('newznab.apikey') or ''
	if key and text:
		text = text.replace(key, '<APIKEY>')
	return text


# ------------------------------------------------------------- informe ------
def _stats(kind, key='', title='', **data):
	"""v2.0.25: apunta en usenet_stats (Tools > Usenet report). Nunca falla."""
	try:
		from resources.lib.modules import usenet_stats
		usenet_stats.record(kind, key, title, **data)
	except Exception:
		pass


def _group(name):
	try:
		from resources.lib.modules.release_groups import parse_group
		g = parse_group(name or '') or ''
		# as the group writes itself in the release name (FLUX, NTb), not lowercased
		m = re.search(r'(?i)(?<![A-Za-z0-9])(%s)(?![A-Za-z0-9])' % re.escape(g), name or '') if g else None
		return m.group(1) if m else g
	except Exception:
		return ''


# ------------------------------------------------------------------ NZB -----
# v2.0.32 — descargas de NZB por indexer (log del 11-nov-2026: tras ~30 grabs de
# comprobaciones de salud un indexer devolvio 429 a cada NZB, tambien al darle
# a reproducir, y Forrest Gump / Fight Club no arrancaron). Cada .nzb es 1 grab
# del cupo diario y las cuentas gratis traen 3-10. Ahora:
#   - un 429 (o el error 500/501 de Newznab: cupo agotado) deja ese indexer en
#     reposo (Retry-After o 1 h): ni busqueda ni NZB, sin martillearlo;
#   - si el indexer manda newznab:apilimits, la salud deja GRAB_RESERVE grabs
#     sin tocar para poder reproducir;
#   - el mismo release en otro indexer queda como alternativa ('alts') y
#     se usa si el primero no da el NZB.
GRAB_RESERVE = 3
_REST_PROP = 'luc_kodi.newznab.rest.%s'      # el mismo que mira newznab.py
_LEFT_PROP = 'luc_kodi.newznab.grableft.%s'  # 'quedan|epoch', lo pone newznab.py
_LEFT_FRESH = 1800
_NZB_LIMIT_CODES = ('429', '500', '501')


def _host(url):
	try: return str(url).split('://', 1)[1].split('/', 1)[0].lower()
	except Exception: return ''


def _short(host):
	h = re.sub(r'^(api|www)\.', '', (host or '').split(':')[0])
	return (h.split('.')[0] or 'indexer').upper()


def grab_resting(host):
	try: return float(control.homeWindow.getProperty(_REST_PROP % host) or 0) > time.time()
	except Exception: return False


def _grab_rest(host, why, secs=3600):
	if not host: return
	if grab_resting(host): return      # otro hilo ya lo dejo en reposo
	try: control.homeWindow.setProperty(_REST_PROP % host, str(int(time.time() + secs)))
	except Exception: pass
	log_utils.log('USENET: %s gives no more NZBs (%s); it rests for %d min' % (_short(host), why, secs // 60),
				  level=log_utils.LOGINFO)


def grabs_left(host):
	"""Grabs que le quedan hoy al indexer segun su ultima respuesta, o None."""
	try:
		raw = control.homeWindow.getProperty(_LEFT_PROP % host) or ''
		left, ts = raw.split('|')
		if time.time() - float(ts) > _LEFT_FRESH: return None
		return int(left)
	except Exception:
		return None


def _spent_grab(host):
	n = grabs_left(host)
	if n is None: return
	try: control.homeWindow.setProperty(_LEFT_PROP % host, '%d|%d' % (max(0, n - 1), int(time.time())))
	except Exception: pass


def candidates(item):
	"""[(url, host)] del item: el suyo y los del mismo release en otros indexers."""
	url = item.get('url') or ''
	out = [(url, item.get('nzb_host') or _host(url))]
	for alt in item.get('alts') or []:
		try:
			u, h = alt[0], alt[1] or _host(alt[0])
			if u and u != url: out.append((u, h))
		except Exception: pass
	return out


def _cached_nzb(key):
	path = os.path.join(nzb_dir(), '%s.nzb' % key)
	return path if os.path.exists(path) and os.path.getsize(path) > 0 else None


def _fetch_nzb_raw(nzb_url, key=None, timeout=20, host=None):
	"""(ruta local del .nzb, bytes descomprimidos si se acaba de bajar o None)."""
	key = key or nzb_key(nzb_url)
	path = os.path.join(nzb_dir(), '%s.nzb' % key)
	if _cached_nzb(key):
		_stats('cached', key)
		return path, None
	if not str(nzb_url or '').lower().startswith(('http://', 'https://')):
		return None, None
	host = host or _host(nzb_url)
	if grab_resting(host):
		return None, None
	tmp = path + '.part'
	try:
		req = Request(nzb_url, headers={'User-Agent': UA, 'Accept-Encoding': 'gzip'})
		with urlopen(req, timeout=timeout, context=_ssl_context()) as r:
			raw = r.read()
		if raw[:2] == b'\x1f\x8b':
			raw = gzip.decompress(raw)
		if b'<nzb' not in raw:
			snippet = raw[:160].decode('utf-8', 'replace')
			m = re.search(r'<error\b[^>]*\bcode="(\d+)"', snippet, re.I)
			if m and m.group(1) in _NZB_LIMIT_CODES:
				_grab_rest(host, 'indexer error %s' % m.group(1))
			log_utils.log('USENET: %s did not return an NZB: %s' % (_short(host), _mask(snippet)), level=LOGDEBUG)
			return None, None
		# v2.0.25: comprimido (un NZB de un remux pesa 4-6 MB de XML y baja a la
		# quinta parte); usenet_core.parse_nzb lo abre igual comprimido o no.
		with open(tmp, 'wb') as f:
			f.write(gzip.compress(raw, 5))
		os.replace(tmp, path)
		_spent_grab(host)
		_stats('grab', key, bytes=len(raw))
		return path, raw
	except Exception as e:
		try:
			if os.path.exists(tmp): os.remove(tmp)
		except OSError:
			pass
		code = getattr(e, 'code', None)
		if code == 429:
			try: secs = int((e.headers or {}).get('Retry-After') or 0)
			except Exception: secs = 0
			_grab_rest(host, 'HTTP 429 Too Many Requests', secs if 60 <= secs <= 86400 else 3600)
		log_utils.log('USENET: NZB download from %s failed: %s' % (_short(host), _mask('%s: %s' % (type(e).__name__, e))),
					  level=LOGDEBUG)
		return None, None


def fetch_nzb(nzb_url, key=None, timeout=20, host=None):
	"""Ruta local del .nzb (descargandolo si hace falta) o None."""
	return _fetch_nzb_raw(nzb_url, key=key, timeout=timeout, host=host)[0]


def fetch_nzb_item(item, key=None, timeout=20):
	"""Prueba el NZB del item y, si su indexer no lo da, el mismo release en
	los otros. (ruta, None) o (None, motivo)."""
	key = key or item.get('hash') or nzb_key(item.get('url'))
	cached = _cached_nzb(key)
	if cached:
		_stats('cached', key)
		return cached, None
	tried, resting = [], []
	for url, host in candidates(item):
		if grab_resting(host):
			resting.append(_short(host)); continue
		tried.append(_short(host))
		path = fetch_nzb(url, key, timeout=timeout, host=host)
		if path:
			if len(tried) > 1 or resting:
				log_utils.log('USENET: NZB taken from %s (the same release on another indexer)' % _short(host),
							  level=log_utils.LOGINFO)
			return path, None
		if grab_resting(host):
			resting.append(_short(host))
	if resting:
		return None, '%s gives no more NZBs today (download limit); pick a release from another indexer' \
			% '/'.join(sorted(set(resting)))
	return None, 'could not download the NZB from the indexer'


def cleanup(max_age=NZB_KEEP_SECS):
	try:
		d = nzb_dir(); now = time.time()
		for n in os.listdir(d):
			p = os.path.join(d, n)
			try:
				age = now - os.path.getmtime(p)
				if age > max_age or (n.endswith('.part') and age > 3600):
					os.remove(p)
			except OSError: pass
	except Exception:
		pass


# --------------------------------------------------------------- salud ------
_OLD_CLEANED = False


def _health_path():
	# Ficheros de versiones de prueba anteriores: se borran una vez. Desde
	# aqui los 'no reproducible' llevan la version del motor (ENGINE_VERSION)
	# y caducan solos cuando el motor aprende algo nuevo.
	global _OLD_CLEANED
	u = _usenet_dir()
	if not _OLD_CLEANED:
		for oldname in ('health.json', 'health_v2.json'):
			old = os.path.join(u, oldname)
			if os.path.exists(old):
				try: os.remove(old)
				except OSError: pass
		_OLD_CLEANED = True
	return os.path.join(u, 'health_v3.json')


def _health_load():
	"""Lee la cache de salud; reutiliza la copia en memoria si el fichero no
	ha cambiado en disco (sincronizado entre el plugin y el servicio)."""
	global _HEALTH_MEM, _HEALTH_MTIME
	p = _health_path()
	try:
		st = os.stat(p)
		mt = (st.st_mtime_ns, st.st_size)
	except OSError:
		_HEALTH_MEM, _HEALTH_MTIME = {}, None
		return {}
	if _HEALTH_MEM is not None and _HEALTH_MTIME == mt:
		return dict(_HEALTH_MEM)
	try:
		with open(p, 'r') as f:
			data = json.load(f)
		if isinstance(data, dict):
			_HEALTH_MEM = data
			_HEALTH_MTIME = mt
			return dict(data)
	except Exception:
		pass
	return {}


def _ttl(v):
	if v.get('status') in ('dead', 'unplayable'):
		return HEALTH_TTL_DEAD
	if v.get('played'):
		return HEALTH_TTL_PLAYED
	return HEALTH_TTL_OK


def providers_mark(cfg=None):
	"""v2.0.33: huella de los proveedores de respaldo. Un 'borrado' que se
	apunto con otros proveedores se vuelve a comprobar."""
	try:
		bks = (cfg or {}).get('backups') if cfg is not None else backup_configs()
		return '|'.join(sorted('%s:%s' % (b.get('host'), b.get('port')) for b in bks or []))
	except Exception:
		return ''


def _health_save(data):
	global _HEALTH_MEM, _HEALTH_MTIME
	now = time.time()
	keep = {k: v for k, v in data.items() if now - v.get('ts', 0) < _ttl(v)}
	p = _health_path()
	try:
		tmp = p + '.part'
		with open(tmp, 'w') as f:
			json.dump(keep, f, separators=(',', ':')) # v2.0.41: compacto
		os.replace(tmp, p)
		_HEALTH_MEM = dict(keep)
		try:
			st = os.stat(p)
			_HEALTH_MTIME = (st.st_mtime_ns, st.st_size)
		except OSError: _HEALTH_MTIME = None
	except Exception:
		pass


def _cached_verdict(cache, key, mark=None):
	v = cache.get(key)
	if not v:
		return None
	if v.get('eng') is not None and v.get('eng') != ENGINE_VERSION:
		return None      # lo rechazo un motor anterior: se vuelve a mirar
	if mark is not None and v.get('status') == 'dead' and v.get('eng') is None and (v.get('pf') or '') != mark:
		return None      # v2.0.33: otros proveedores de respaldo; puede que ahora si este
	return v if time.time() - v.get('ts', 0) < _ttl(v) else None


def _aes_lib_path():
	try:
		import xbmcvfs
		return xbmcvfs.translatePath('special://home/addons/%s/lib' % core.AES_MODULE)
	except Exception:
		return ''


def _offer_aes_install():
	"""v2.0.37: un 7z con clave y sin pycryptodome. Kodi pregunta una vez por
	sesion si se instala (dependencia opcional: solo quien la necesita)."""
	try:
		if control.homeWindow.getProperty('luc_kodi.aes.offered') == 'true':
			return
		control.homeWindow.setProperty('luc_kodi.aes.offered', 'true')
		log_utils.log('USENET: password-protected releases: asking to install %s' % core.AES_MODULE, level=log_utils.LOGINFO)
		control.execute('InstallAddon(%s)' % core.AES_MODULE)
	except Exception:
		log_utils.error()


def _aes_report():
	"""v2.0.37: en el kodi.log, si hay AES en C para los 7z cifrados y cuanto corre."""
	try:
		core.AES_PATHS[:] = [_aes_lib_path()]
		name, mbps = core.aes_probe(8)
		if name:
			log_utils.log('USENET: password-protected releases: AES from %s, %.0f MB/s on this device' % (name, mbps),
						  level=log_utils.LOGINFO)
		elif os.path.isdir(core.AES_PATHS[0] or ''):
			why = ''
			for mod in ('Cryptodome.Cipher.AES', 'Crypto.Cipher.AES'):
				try: __import__(mod)
				except Exception as e: why = '%s: %s' % (type(e).__name__, e)
			log_utils.log('USENET: password-protected releases: %s is installed but its AES does not load on this device (%s)'
						  % (core.AES_MODULE, why[:200]), level=log_utils.LOGWARNING)
		else:
			log_utils.log('USENET: password-protected releases: %s not installed (it is asked for the first time one is played)'
						  % core.AES_MODULE, level=log_utils.LOGINFO)
	except Exception:
		log_utils.error()


def _forget_old_dead():
	"""v2.0.37, una vez: los 'borrados' apuntados sin version del motor se
	olvidan. Entre ellos estaban los 7z partidos con el primer trozo menor que
	el motor anterior daba por 'damaged post' (kodi.log del 17-nov-2026); los
	borrados de verdad se vuelven a ver en la siguiente comprobacion (STAT)."""
	flag = os.path.join(_usenet_dir(), 'health_v3.mig37')
	if os.path.exists(flag):
		return
	try:
		with _health_lock:
			cache = _health_load()
			drop = [k for k, v in cache.items() if isinstance(v, dict)
					and v.get('status') == 'dead' and v.get('eng') is None]
			for k in drop:
				cache.pop(k, None)
			if drop:
				_health_save(cache)
		with open(flag, 'w') as f:
			f.write('1')
		if drop:
			log_utils.log('USENET: %d old "removed" verdicts forgotten (checked again on the next search)' % len(drop),
						  level=log_utils.LOGINFO)
	except Exception:
		pass


def _remember_dead(key, pct=0, engine=False, why=None):
	"""engine=True: no es que falten articulos, es que el motor no sabe
	abrirlo; el veredicto lleva su version y caduca con la siguiente.
	v2.0.37 (kodi.log del 17-nov-2026): esos se apuntan como 'unplayable' con su
	motivo; antes iban como 'dead' y luego se decian 'removed from Easynews
	(430)', que no era verdad."""
	try:
		with _health_lock:
			cache = _health_load()
			cache[key] = {'status': 'unplayable' if engine else 'dead', 'pct': pct, 'kind': None, 'checked': 1,
						  'ts': time.time(), 'pf': providers_mark()}
			if engine:
				cache[key]['eng'] = ENGINE_VERSION
				cache[key]['why'] = (why or 'archive').replace(' (not streamable)', '')[:120]
			_health_save(cache)
	except Exception:
		pass


def _remember_played(summary):
	"""v2.0.33: un NZB que se reprodujo de verdad (sin cortarse por
	incompleto) queda como bueno 7 dias: sale el primero en el salto al
	siguiente NZB y no se vuelve a comprobar. Corre en el servicio."""
	try:
		key = summary.get('key') or ''
		if not (key and summary.get('ready')) or summary.get('incomplete') is not None:
			return
		if int(summary.get('bytes') or 0) < PLAYED_MIN_BYTES:
			return
		with _health_lock:
			cache = _health_load()
			old = cache.get(key) or {}
			cache[key] = {'status': 'ok', 'pct': old.get('pct', 100) if old.get('status') == 'partial' else 100,
						  'kind': old.get('kind'), 'checked': old.get('checked', 0), 'ts': time.time(), 'played': 1}
			if old.get('status') == 'partial':
				cache[key]['status'] = 'partial'
			_health_save(cache)
	except Exception:
		pass


def _on_incomplete(key, pct):
	"""El motor corto un release al que le faltan articulos: se oculta en
	las proximas busquedas y se avisa (esto corre en el servicio)."""
	_remember_dead(key, pct)
	try:
		control.notification(message='Easynews: this release is incomplete (~%d%% missing). Pick another one.' % pct)
	except Exception:
		pass


def known_status(items):
	"""v2.0.32: {clave: 'ok'|'partial'|'dead'} de lo que ya se sabe de estos
	items en Easynews, tambien lo que comprobo la salud en segundo plano
	despues de abrirse la lista (el salto al siguiente NZB lo usa)."""
	with _health_lock:
		cache = _health_load()
	mark = providers_mark()
	out = {}
	for it in items or []:
		k = it.get('hash') or nzb_key(it.get('url'))
		v = _cached_verdict(cache, k, mark)
		if v:
			st = v.get('status')
			out[k] = 'dead' if st in ('dead', 'empty', 'unplayable') else ('played' if v.get('played') else st)
	return out


def dead_keys():
	"""Claves de NZB que se sabe que estan borrados en Easynews (vigentes).
	sources.py las quita tambien de los resultados que vienen de la cache de
	proveedores (que no vuelve a pasar por el scraper durante horas).
	v2.0.33: tambien los que el motor no puede abrir (RAR comprimido...), salvo
	que haya Premiumize o TorBox para bajarlos."""
	with _health_lock:
		cache = _health_load()
	mark = providers_mark()
	gone = ('dead', 'unplayable') if not other_services() else ('dead',)
	return {k for k in cache if (_cached_verdict(cache, k, mark) or {}).get('status') in gone}


def _badge_into_info(info, badge):
	"""El badge va DETRAS del tamano: la lista de fuentes corta todo lo que
	hay antes de 'GB ' (prueba del 1-nov-2026: 'EN OK' delante no se veia)."""
	if not info:
		return badge
	parts = info.split(' | ')
	if parts and re.match(r'^\d+(\.\d+)?\s*(GB|MB|GiB|MiB)$', parts[0].strip(), re.I):
		return ' | '.join([parts[0], badge] + parts[1:])
	return '%s | %s' % (badge, info)


def _pick_grab(key, cands, budget):
	"""(url, host) con el que comprobar un release, o None si bajar su NZB
	gastaria un grab que hace falta para reproducir. Se llama con el lock."""
	if _cached_nzb(key):
		return cands[0]
	for url, host in cands:
		if grab_resting(host):
			continue
		if host not in budget:
			left = grabs_left(host)
			budget[host] = None if left is None else max(0, left - GRAB_RESERVE)
		b = budget[host]
		if b is None:
			return url, host
		if b > 0:
			budget[host] = b - 1
			return url, host
	return None


class _BackupChain(object):
	"""v2.0.32 (informe L7, B1): los proveedores de respaldo, por orden, para la
	comprobacion de salud (solo STAT de lo que falta en Easynews). Cada uno con
	su grupo de conexiones compartido, nunca mas de las de su ajuste."""
	def __init__(self, cfgs):
		from resources.lib.modules.usenet_stream import BackupPool
		self.pools = [BackupPool(dict(c, connections=min(2, c.get('connections') or 2)),
								 lambda m: log_utils.log(m, level=log_utils.LOGINFO)) for c in cfgs]

	def get(self):
		return self if any(not p.failed for p in self.pools) else None

	def stat_many(self, ids):
		codes = [None] * len(ids)
		todo = list(range(len(ids)))
		for pool in self.pools:
			if not todo or pool.failed:
				continue
			try: got = pool.stat_many([ids[i] for i in todo])
			except Exception: continue
			left = []
			for i, c in zip(todo, got):
				if c == core.NNTP_OK_STAT: codes[i] = c
				else: left.append(i)
			todo = left
		return [c if c is not None else core.NNTP_NO_ARTICLE for c in codes]

	def close(self):
		for p in self.pools:
			p.close()


def health_filter(items, other_resolvers=None, wait=None):
	"""Comprueba en Easynews los NZB de la lista y devuelve la lista filtrada.

	Orden: el mismo que vera el usuario (mejor calidad primero, luego grabs).
	Se sigue comprobando hasta tener HEALTH_WANT_OK releases buenos, o llegar
	al tope del ajuste (cada comprobacion baja el NZB = 1 grab del indexer), o
	agotar el tiempo. Prueba del 1-nov-2026 (Supergirl 2026, Tenzing 2026):
	los 8 primeros estaban todos borrados y el usuario fue pinchando, uno
	tras otro, releases sin comprobar que tambien lo estaban.

	  - 'dead' (borrado en Easynews)          -> fuera
	  - 'ok' / 'partial'                       -> marcado (en_health, badge)
	  - 7z                                     -> se queda (v2.0.28: el motor
	                                              reproduce los 7z 'store'; uno
	                                              comprimido lo dice al abrirlo)
	  - sin comprobar                          -> 'EN ?'; y si la mitad o mas
	    de lo comprobado estaba borrado, fuera tambien: en ese titulo lo que
	    queda sin comprobar casi seguro que tampoco esta.
	"""
	if not items or not enabled() or not _bool('newznab.en_health'):
		return items
	if other_resolvers is None:
		other_resolvers = other_services()
	try: limit = int(getSetting('newznab.en_health_checks') or 20)
	except ValueError: limit = 20
	cfg = nntp_config()
	mark = providers_mark(cfg)
	fg_bytes = [0]     # v2.0.33: MB de cabeceras leidos antes de abrir la lista
	t0 = time.time()
	with _health_lock:
		cache = _health_load()
	# v2.0.37 (Lucian, 19-nov-2026): los discos Blu-ray enteros ('4 Disc',
	# 'COMPLETE BLURAY', 'BDMV') ya se reproducen: el motor lee sus listas de
	# reproduccion y sirve la pelicula entera (usenet_disc), tambien si el
	# disco viene en una imagen ISO (usenet_udf). Se comprueban como los demas.
	n_disc = 0
	disc_keys = set()
	for i in items:
		if is_disc(i.get('name')) or is_iso(i.get('name')):
			disc_keys.add(i.get('hash') or nzb_key(i.get('url')))
	_qrank = {'4K': 0, '1080p': 1, '720p': 2, 'SD': 3, 'SCR': 4, 'CAM': 5}
	ordered = sorted(items, key=lambda i: (_qrank.get(i.get('quality'), 3), -int(i.get('seeders') or 0)))
	verdicts = {}
	queue = []
	queued = {}
	for it in ordered:
		if it.get('package'):
			continue   # v2.0.33: un pack se comprueba al abrir SU episodio, no el fichero mayor
		k = it.get('hash') or nzb_key(it.get('url'))
		v = _cached_verdict(cache, k, mark)
		if v:
			verdicts[k] = v
		elif k in queued:
			seen = {u for u, _ in queued[k]}
			for c in candidates(it):
				if c[0] not in seen:
					queued[k].append(c); seen.add(c[0])
		else:
			cands = candidates(it)
			queued[k] = cands
			queue.append((k, cands))
	state = {'auth_failed': False, 'checked': 0, 'inflight': 0, 'archives': 0, 'abytes': 0,
			 'ok': sum(1 for v in verdicts.values() if v.get('status') in ('ok', 'partial'))}

	fresh = set()
	found = {}          # lo que comprueban los hilos; se copia al acabar el tiempo
	if queue and limit > 0:
		lock = threading.Lock()
		cond = threading.Condition(lock)
		budget = {}     # grabs que la salud puede gastar por indexer (None: sin datos)
		backup = _BackupChain(cfg['backups']) if cfg.get('backups') else None

		def worker():
			conn = None
			while not state['auth_failed']:
				rem = HEALTH_BUDGET_SECS - (time.time() - t0)
				if rem <= 0:
					break
				with cond:
					while (queue and state['checked'] < limit and state['ok'] < HEALTH_WANT_OK
						   and not state['auth_failed'] and state['ok'] + state['inflight'] >= HEALTH_WANT_OK):
						rem = HEALTH_BUDGET_SECS - (time.time() - t0)
						if rem <= 0:
							break
						cond.wait(min(0.25, rem))
					if not queue or state['checked'] >= limit or state['ok'] >= HEALTH_WANT_OK or state['auth_failed']:
						break
					if time.time() - t0 >= HEALTH_BUDGET_SECS:
						break
					# Con 8 hilos en vuelo se pasaba de largo: la prueba del
					# 1-nov-2026 comprobo 15 para quedarse con 8 (15 grabs). Si
					# los que ya estan en vuelo bastan, se espera a ver como
					# acaban antes de bajar otro NZB.
					pick = None
					while queue and pick is None:
						k, cands = queue.pop(0)
						pick = _pick_grab(k, cands, budget)
					if pick is None:
						break      # lo que queda no se puede bajar sin gastar los grabs de reproducir
					url, host = pick
					state['checked'] += 1
					state['inflight'] += 1
				try:
					left = HEALTH_BUDGET_SECS - (time.time() - t0)
					path, _raw = _fetch_nzb_raw(url, k, timeout=max(3, min(HEALTH_NZB_TIMEOUT, left)), host=host)
					if not path:
						# el indexer se acaba de quedar sin cupo: el release vuelve
						# a la cola con los NZB de los otros indexers
						rest_c = [c for c in cands if c[1] != host]
						if rest_c and grab_resting(host):
							with cond:
								queue.insert(0, (k, rest_c))
								state['checked'] -= 1
						continue
					if _raw is None:
						with open(path, 'rb') as f:
							_raw = f.read()
					files = core.parse_nzb(_raw)
					if conn is None:
						conn = core.NNTPConn(cfg['host'], cfg['port'], cfg['user'], cfg['password'], timeout=15)
					v = core.check_health(conn, files, backup=backup.get if backup else None)
					# v2.0.33: en un release en archivo (RAR, 7z, ofuscado) se lee
					# la cabecera (1 articulo): un RAR comprimido o cifrado se sabe
					# ahora y no al darle a reproducir
					if v['status'] in ('ok', 'partial') and v.get('kind') in core.ARCHIVE_KINDS:
						with cond:
							# v2.0.37: un disco entero se mira siempre (un articulo): muchos
							# 'COMPLETE.UHD.BLURAY' son una ISO dentro del RAR
							look = state['archives'] < ARCHIVE_CHECKS or k in disc_keys
							if look: state['archives'] += 1
						meter = []
						why = core.check_archive(conn, files, meter, core.nzb_password(_raw), k in disc_keys) if look else None
						if meter:
							with cond: state['abytes'] += meter[0]
						if why:
							v = dict(v, status='unplayable', why=why, eng=ENGINE_VERSION)
					v['ts'] = time.time()
					if v['status'] == 'dead':
						v['pf'] = mark
					with cond:
						found[k] = v
						if v['status'] in ('ok', 'partial'): state['ok'] += 1
				except core.NNTPAuthError as e:
					state['auth_failed'] = True
					log_utils.log('USENET: Easynews login refused during health check: %s' % e, level=log_utils.LOGINFO)
				except Exception as e:
					log_utils.log('USENET: health check error: %s: %s' % (type(e).__name__, e), level=LOGDEBUG)
					try:
						if conn: conn.close()
					except Exception: pass
					conn = None
				finally:
					with cond:
						state['inflight'] -= 1
						cond.notify_all()
			if conn: conn.close()

		# Solo STAT, sin decodificar nada: aqui mas conexiones si cunden.
		n = min(len(queue), limit, HEALTH_CONNECTIONS)
		threads = [threading.Thread(target=worker) for _ in range(n)]
		for t in threads:
			t.daemon = True
			t.start()
		# no se espera a los rezagados: lo que no acabe a tiempo sale como 'EN ?'.
		# v2.0.32: con wait (la busqueda, log del 11-nov-2026) se espera solo eso:
		# la comprobacion entera tardaba 6-10 s y la busqueda rapida abria la
		# lista sin ningun resultado de NZBGeek ni de altHUB. Lo que siga
		# comprobandose se guarda al acabar y vale para la siguiente vez y para
		# el salto al siguiente NZB.
		cap = HEALTH_BUDGET_SECS + 1 if wait is None else max(0.1, float(wait))
		for t in threads:
			left = cap - (time.time() - t0)
			if left <= 0: break
			t.join(left)
		with lock:
			done = dict(found)
			fg_bytes[0] = state['abytes']
		verdicts.update(done)
		fresh = set(done)
		with _health_lock:
			cache = _health_load()
			for k, v in list(verdicts.items()):
				if 'ts' in v: cache[k] = v
			_health_save(cache)
		late = [t for t in threads if t.is_alive()]
		if not late and backup:
			backup.close()
		if late:
			def _finish():
				for t in late:
					t.join(max(0.1, HEALTH_BUDGET_SECS + 1 - (time.time() - t0)))
				if backup:
					backup.close()
				with lock:
					rest = {k: v for k, v in found.items() if k not in done}
					late_bytes = state['abytes'] - fg_bytes[0]
				if late_bytes > 0:
					_stats('headers', header_bytes=late_bytes)   # v2.0.33: lo leido en segundo plano
				if not rest:
					return
				with _health_lock:
					c = _health_load()
					c.update(rest)
					_health_save(c)
				n_ok = sum(1 for v in rest.values() if v.get('status') in ('ok', 'partial'))
				n_un = sum(1 for v in rest.values() if v.get('status') == 'unplayable')
				log_utils.log('USENET: health check finished in the background: %d more checked, %d good, %d removed, '
							  '%d not streamable here (%.1fs)'
							  % (len(rest), n_ok, len(rest) - n_ok - n_un, n_un, time.time() - t0), level=log_utils.LOGINFO)
			fin = threading.Thread(target=_finish)
			fin.daemon = True
			fin.start()

	# v2.0.33 (kodi.log del 13-nov-2026): ya no se esconden los no comprobados
	# cuando la mitad de lo comprobado esta borrado. Con los borrados recordados
	# 7 dias esa cuenta crecia en cada busqueda: Mayday y Eternity abrian la
	# lista VACIA y la salud de detras encontraba luego 4 y 5 releases buenos;
	# al repetir la busqueda salian 4 y 1. Desde la 2.0.32, si uno sin comprobar
	# esta borrado se prueba solo el siguiente NZB (primero los verificados).
	hide_unchecked = False
	out, dead, rar_dropped, ok, hidden, unplay = [], 0, n_disc, 0, 0, 0
	for it in items:
		if it.get('package'):
			new = dict(it)
			new['info'] = _badge_into_info(new.get('info') or '', 'EN PACK')
			out.append(new); continue
		k = it.get('hash') or nzb_key(it.get('url'))
		v = verdicts.get(k)
		if not v:
			if hide_unchecked:
				hidden += 1; continue
			new = dict(it)
			new['info'] = _badge_into_info(new.get('info') or '', 'EN ?')
			out.append(new); continue
		if v['status'] in ('dead', 'empty'):
			dead += 1; continue
		if v['status'] == 'unplayable':
			# v2.0.33: el motor no lo abre; con Premiumize/TorBox se queda para
			# ellos (sin pasar por Easynews), sin ellos fuera
			unplay += 1
			if not other_resolvers:
				continue
			new = dict(it)
			new['en_unplayable'] = v.get('why') or 'not streamable'
			new['info'] = _badge_into_info(new.get('info') or '', 'EN %s' % ('7Z' if '7z' in (v.get('why') or '') else 'RAR'))
			out.append(new); continue
		kind = v.get('kind')
		# v2.0.24: el motor ya reproduce RAR 'store'; v2.0.28: y 7z 'store'. Los
		# comprimidos o cifrados los dice el motor al abrirlos (y se apuntan).
		new = dict(it)
		new['en_health'] = v['status']
		new['en_kind'] = kind
		badge = 'EN %d%%' % v.get('pct', 0) if v['status'] == 'partial' else ('EN PLAYED' if v.get('played') else 'EN OK')
		if kind == '7z':
			badge += ' ' + kind.upper()
		if k in disc_keys:
			badge += ' DISC'        # v2.0.37: disco Blu-ray entero, se sirve su pelicula
		new['info'] = _badge_into_info(new.get('info') or '', badge)
		ok += 1
		out.append(new)
	if fresh:
		names = {(it.get('hash') or nzb_key(it.get('url'))): it.get('name') or '' for it in ordered}
		groups = {}
		for k in fresh:
			g = _group(names.get(k))
			if not g: continue
			a = groups.setdefault(g, [0, 0]); a[0] += 1
			if verdicts[k].get('status') in ('dead', 'empty'): a[1] += 1
		_stats('health', checked=len(fresh),
			   ok=sum(1 for k in fresh if verdicts[k].get('status') == 'ok'),
			   partial=sum(1 for k in fresh if verdicts[k].get('status') == 'partial'),
			   dead=sum(1 for k in fresh if verdicts[k].get('status') in ('dead', 'empty')),
			   unplayable=sum(1 for k in fresh if verdicts[k].get('status') == 'unplayable'),
			   secs=round(time.time() - t0, 1), groups=groups, header_bytes=fg_bytes[0])
	log_utils.log('USENET: health check on Easynews: %d verified, %d removed/dead, %d not streamable here '
				  '(compressed or encrypted archives), %d disc images skipped, %d unchecked%s (%d checked now, %.1fs)'
				  % (ok, dead, unplay, rar_dropped, hidden or (len(out) - ok - (unplay if other_resolvers else 0)),
					 ' and hidden (most checked releases of this title are gone)' if hidden else '',
					 state['checked'], time.time() - t0), level=log_utils.LOGINFO)
	return out


# ------------------------------------------------------------- resolver -----
def _service_port():
	try:
		return int(control.homeWindow.getProperty('luc_kodi.usenet.port') or 0)
	except Exception:
		return 0


def _local_get(port, path, timeout=60):
	with urlopen('http://127.0.0.1:%d%s' % (port, path), timeout=timeout) as r:
		return r.read()


def _episode_files(files, season, episode):
	"""v2.0.33: los ficheros de UN episodio dentro de un pack de temporada:
	los que lo nombran (S01E05, 1x05...). Solo el nombre del fichero, nunca el
	asunto entero: su '[01/05]' parece un S01E05. [] si no se puede saber."""
	try:
		from resources.lib.modules.source_utils import seas_ep_filter
	except Exception:
		return []
	out = []
	for f in files or []:
		if core.classify(f.get('name')) in ('par2', 'extra', 'obfuscated'):
			continue
		try:
			if seas_ep_filter(season, episode, f.get('name') or ''):
				out.append(f)
		except Exception:
			pass
	return out


def _write_nzb(path, files, password=None):
	"""Un NZB minimo con estos ficheros (el motor pide por message-id: no
	hacen falta grupos), comprimido como los demas. v2.0.37: con la clave del
	NZB original, si la tenia (7z cifrado)."""
	from xml.sax.saxutils import escape, quoteattr
	parts = ['<?xml version="1.0" encoding="utf-8"?>\n<nzb xmlns="http://www.newzbin.com/DTD/2003/nzb">']
	if password:
		parts.append('<head><meta type="password">%s</meta></head>' % escape(password))
	for f in files:
		parts.append('<file poster="" date="0" subject=%s><groups><group>alt.binaries</group></groups><segments>'
					 % quoteattr(f.get('subject') or '"%s"' % (f.get('name') or '')))
		for num, nb, mid in f.get('segments') or []:
			parts.append('<segment bytes="%d" number="%d">%s</segment>' % (int(nb or 0), int(num or 0), escape(mid)))
		parts.append('</segments></file>')
	parts.append('</nzb>')
	tmp = path + '.part'
	try:
		with open(tmp, 'wb') as fh:
			fh.write(gzip.compress(''.join(parts).encode('utf-8'), 5))
		os.replace(tmp, path)
	except Exception:
		try:
			if os.path.exists(tmp): os.remove(tmp)
		except OSError:
			pass
		raise


def pack_episode(path, key, season, episode):
	"""v2.0.33: de un NZB de pack, (clave, None, False) de un NZB propio con solo
	el episodio pedido, o (None, motivo, False). Antes el motor abria el fichero
	mayor del pack: otro episodio (con 'solo episodios' apagado).

	v2.0.36: si los nombres de fuera no dicen que fichero es el episodio pero el
	pack va en un archivo (un 7z con todos los episodios dentro, o nombres
	ofuscados), se devuelve (clave, None, True): el motor recibe el episodio y lo
	busca por los nombres que guarda la cabecera del archivo, como TMDb Movies.
	Si no lo encuentra lo dice y se pasa al siguiente NZB; nunca pone otro."""
	try:
		s_n, e_n = int(season), int(episode)
	except (TypeError, ValueError):
		return None, 'season pack: no episode number to pick', False
	sub = nzb_key('%s|S%02dE%02d' % (key, s_n, e_n))
	if _cached_nzb(sub):
		return sub, None, False
	inner = nzb_key('%s|S%02dE%02d|inner' % (key, s_n, e_n))
	if _cached_nzb(inner):
		return inner, None, True
	try:
		with open(path, 'rb') as f:
			raw = f.read()
		files = core.parse_nzb(raw)
		pw = core.nzb_password(raw)
	except Exception as e:
		return None, 'season pack: NZB unreadable (%s)' % type(e).__name__, False
	mine = _episode_files(files, s_n, e_n)
	if not mine:
		kinds = {core.classify(f.get('name')) for f in files}
		if not kinds & {'7z', 'rar', 'obfuscated'}:
			return None, 'season pack with hidden file names: S%02dE%02d cannot be picked (not streamable)' % (s_n, e_n), False
		try:
			_write_nzb(os.path.join(nzb_dir(), '%s.nzb' % inner),
					   [f for f in files if core.classify(f.get('name')) not in ('par2', 'extra')], pw)
		except Exception as e:
			return None, 'season pack: %s' % type(e).__name__, False
		log_utils.log('USENET: season pack: S%02dE%02d is not named outside, looking inside the archive' % (s_n, e_n),
					  level=log_utils.LOGINFO)
		return inner, None, True
	try:
		_write_nzb(os.path.join(nzb_dir(), '%s.nzb' % sub), mine, pw)
	except Exception as e:
		return None, 'season pack: %s' % type(e).__name__, False
	log_utils.log('USENET: season pack: S%02dE%02d is %d of its %d files' % (s_n, e_n, len(mine), len(files)),
				  level=log_utils.LOGINFO)
	return sub, None, False


def _write_twins(key, item):
	"""v2.0.37 (Lucian, 19-nov-2026): los NZB del mismo release en otros
	indexers (o subido otra vez al mismo) que ya trae la busqueda: si a este
	post le falta un articulo, el motor lo busca en ellos (usenet_stream,
	_twin_data). Aqui solo se apuntan; no se baja nada hasta que hay un hueco."""
	path = os.path.join(nzb_dir(), '%s.nzb.twins' % key)
	try:
		twins = [[u, h] for u, h in candidates(item) if u and u != item.get('url')]
		if twins:
			with open(path, 'w') as f:
				json.dump(twins[:5], f)
		elif os.path.exists(path):
			os.remove(path)
	except Exception:
		pass


def resolve(item, runtime=None, season=None, episode=None):
	"""(url local reproducible, None) o (None, motivo). runtime: segundos de
	video si se saben (v2.0.32, informe N3: la lectura anticipada se calcula
	con la duracion real, no con 90 min supuestos). v2.0.33: season/episode
	para un pack de temporada (se reproduce ese episodio, no el fichero mayor)."""
	if not enabled():
		return None, 'Easynews is not enabled or has no credentials'
	port = _service_port()
	if not port:
		return None, 'luc_kodi service stream server is not running'
	url = item.get('url') or ''
	key = item.get('hash') or nzb_key(url)
	# v2.0.33 (kodi.log del 12-nov-2026): la salud que sigue detras de la lista
	# ya habia visto el disco de Project Hail Mary y aun asi se abrio. Lo ya
	# sabido se dice al momento y se pasa al siguiente NZB.
	# v2.0.37: un NZB que el usuario eligio a mano (usenet_local) se prueba
	# siempre, aunque antes no se pudiera: puede que el motor ya sepa abrirlo
	if not item.get('package') and not item.get('local'):
		try:
			with _health_lock:
				v = _cached_verdict(_health_load(), key, providers_mark())
		except Exception:
			v = None
		if v and v.get('status') in ('dead', 'empty'):
			return None, 'removed from Easynews (430), found by the availability check'
		if v and v.get('status') == 'unplayable':
			return None, '%s (not streamable), found by the availability check' % (v.get('why') or 'archive')
	path, why = fetch_nzb_item(item, key)
	if not path:
		return None, why
	look_inside = False
	if item.get('package'):
		key, why, look_inside = pack_episode(path, key, season, episode)
		if not key:
			return None, why
	_write_twins(key, item)
	try:
		q = ['rt=%d' % int(runtime)] if runtime else []
		if look_inside:
			q += ['s=%d' % int(season), 'e=%d' % int(episode)]
		q = ('?' + '&'.join(q)) if q else ''
		info = json.loads(_local_get(port, '/prepare/%s%s' % (key, q), timeout=60).decode('utf-8'))
	except Exception as e:
		return None, 'stream server: %s: %s' % (type(e).__name__, e)
	if not info.get('ok'):
		reason = info.get('reason') or 'not streamable'
		if core.AES_MODULE in reason:
			_offer_aes_install()
		# El primer articulo ya no esta en Easynews: release borrado. Se apunta
		# como 'dead' para que la proxima busqueda no lo vuelva a ensenar.
		# Lo mismo si no se puede reproducir (RAR/7z, imagen de disco, ...):
		# log del 1-nov-2026, un Blu-ray completo (Hocus Pocus BeyondHD) con
		# nombre ofuscado pasaba la salud y fallaba aqui cada vez.
		# Un RAR/7z si lo puede bajar Premiumize/TorBox: no se oculta.
		# Borrado, incompleto o post danado: es el contenido del servidor, no
		# el motor; ninguna version nueva lo arregla.
		# v2.0.37: 'damaged post' por un volumen que falta lo deduce el motor de
		# las cabeceras (kodi.log del 17-nov-2026: un 7z con el primer trozo menor
		# se tomaba por incompleto). Ese veredicto lleva la version del motor y
		# caduca con la siguiente; un 430 o un incompleto medido, no.
		if 'damaged post' in reason and 'volume missing' in reason:
			_remember_dead(key, engine=True, why=reason)
		elif '(430)' in reason or 'incomplete' in reason or 'damaged post' in reason:
			_remember_dead(key)
		elif 'not streamable' in reason and not other_services():
			_remember_dead(key, engine=True, why=reason)
		return None, reason
	ext = info.get('container') or 'mkv'
	name = (item.get('name') or 'video').replace('/', ' ')
	safe = ''.join(c if (c.isalnum() or c in '._-') else '.' for c in name)[:120].strip('.') or 'video'
	_stats('resolve', key, name, size=info.get('size') or 0)
	log_utils.log('USENET: Easynews stream ready: %s (%s, %.2f GB)'
				  % (name, info.get('detail'), (info.get('size') or 0) / 1073741824.0), level=log_utils.LOGINFO)
	return 'http://127.0.0.1:%d/stream/%s/%s.%s' % (port, key, safe, ext), None


# -------------------------------------------------------------- servicio ----
_server = None


def start_service():
	"""Arranca el motor en el servicio y publica el puerto. Siempre arranca
	(es un socket en 127.0.0.1 sin conexiones hasta que se usa): asi activar
	Easynews en ajustes no exige reiniciar Kodi."""
	global _server
	if _server:
		return _server.port
	from resources.lib.modules.usenet_stream import StreamServer
	_usenet_dir()
	def _housekeeping(): # v2.0.41: la limpieza de la carpeta de NZB ya no retrasa el arranque
		cleanup()
		_forget_old_dead()
		_aes_report()
	threading.Thread(target=_housekeeping, name='usenet-aes-probe', daemon=True).start()

	def _log(msg, level=None):
		log_utils.log(msg, level=log_utils.LOGINFO)
	def _on_close(summary):
		_stats('play', summary.get('key', ''), **{k: v for k, v in summary.items() if k != 'key'})
		_remember_played(summary)   # v2.0.33
	_server = StreamServer(nzb_dir(), nntp_config, _log, on_incomplete=_on_incomplete, on_close=_on_close)
	port = _server.start()
	if port:
		control.homeWindow.setProperty('luc_kodi.usenet.port', str(port))
	return port


def stop_service():
	global _server
	try: control.homeWindow.clearProperty('luc_kodi.usenet.port')
	except Exception: pass
	if _server:
		_server.stop()
		_server = None


# ----------------------------------------------------------------- test -----
def test():
	"""Accion de ajustes: login NNTP + control de STAT + puerto del motor."""
	u, p = credentials()
	if not (u and p):
		control.okDialog(title='Easynews Usenet — test',
						 message='Fill in your Easynews username and password in Settings > Usenet first.')
		return
	cfg = nntp_config()
	lines = []
	conn = None
	try:
		t = time.time()
		conn = core.NNTPConn(cfg['host'], cfg['port'], cfg['user'], cfg['password'], timeout=15)
		lines.append('[COLOR ff00fa9a]Login OK[/COLOR] on %s:%d (%.1fs)' % (cfg['host'], cfg['port'], time.time() - t))
		ok_ctrl = None
		for group in ('alt.binaries.multimedia', 'alt.binaries.teevee'):
			code, line = conn.cmd('GROUP %s' % group)
			if code != 211: continue
			last = line.split()[2]
			code, line = conn.cmd('STAT %s' % last)
			mid = line.split()[-1] if code == 223 else ''
			ok_ctrl = (conn.stat(mid) == 223) if mid else False
			break
		lines.append('Article lookup: %s' % ('[COLOR ff00fa9a]OK[/COLOR]' if ok_ctrl else '[COLOR ffff6666]could not verify[/COLOR]'))
	except core.NNTPAuthError as e:
		lines.append('[COLOR ffff6666]Login refused[/COLOR] (%s). Check the username/password, or your plan may not include NNTP access.' % e)
	except Exception as e:
		lines.append('[COLOR ffff6666]Could not connect[/COLOR]: %s: %s' % (type(e).__name__, e))
	finally:
		if conn:
			try: conn.close()
			except Exception: pass
	port = _service_port()
	lines.append('Stream engine: %s' % (('[COLOR ff00fa9a]running on port %d[/COLOR]' % port) if port
										else '[COLOR ffff6666]not running — restart Kodi[/COLOR]'))
	control.okDialog(title='Easynews Usenet — test', message='\n'.join(lines))


def test_backup(slot=1):
	"""v2.0.32 (informe L7): accion de ajustes, prueba el proveedor de respaldo n.º slot."""
	b = backup_config(slot)
	title = 'Backup Usenet provider %d — test' % int(slot or 1)
	if not b:
		control.okDialog(title=title, message='Fill in the backup provider\'s server first.')
		return
	lines = []
	if b.get('port_typed'):
		lines.append('Port %d taken from the server field (the Port list is ignored).' % b['port'])
	conn = None
	try:
		t = time.time()
		conn = core.NNTPConn(b['host'], b['port'], b['user'], b['password'], timeout=15, use_ssl=b['ssl'])
		lines.append('[COLOR ff00fa9a]Login OK[/COLOR] on %s:%d%s (%.1fs)'
					 % (b['host'], b['port'], '' if b['ssl'] else ' without SSL', time.time() - t))
		lines.append('It is asked only for the pieces Easynews no longer has, with up to %d connection%s.'
					 % (b['connections'], '' if b['connections'] == 1 else 's'))
	except core.NNTPTooMany as e:
		lines.append('[COLOR fffdb515]Login OK, but the provider allows no more connections right now[/COLOR] (%s).' % e)
	except core.NNTPAuthError as e:
		lines.append('[COLOR ffff6666]Login refused[/COLOR] (%s). Check the username and password.' % e)
	except Exception as e:
		lines.append('[COLOR ffff6666]Could not connect[/COLOR]: %s: %s' % (type(e).__name__, e))
	finally:
		if conn:
			try: conn.close()
			except Exception: pass
	control.okDialog(title=title, message='\n'.join(lines))