# -*- coding: utf-8 -*-
"""
	luc_kodi Add-on

	v2.0.41 -- ready-made rows ("show now, refresh after").

	A TMDb category page used to be built on every click: the list from the
	cache, every title from the metadata cache, and a request to TMDb for any
	title whose metadata had expired or was missing; the click waited for all of
	it. Now the finished page (titles with their metadata, in order) is kept here
	as one row. Opening the category reads that row and shows it at once; if the
	row is getting old, or was made while some titles still had light metadata,
	the click asks the service to rebuild it and the next visit gets the new one.

	A row belongs to the settings it was made with (language, image sizes,
	fanart.tv...): fingerprint() is part of its key, so a change there makes the
	old rows unused (the janitor removes them after ROW_MAX_AGE).
"""
from hashlib import md5
from json import dumps as jsdumps, loads as jsloads
from time import time
from sqlite3 import dbapi2 as db
from resources.lib.modules.control import existsPath, dataPath, makeFile, joinPath

rowsFile = joinPath(dataPath, 'rows.db')
ROWS_VERSION = 1
ROW_MAX_AGE = 96 * 3600     # same life as the TMDb list cache: older rows are not shown
REFRESH_AFTER = 6 * 3600    # older than this: shown, and rebuilt in the background
WANTED_PROP = 'luc_kodi.rows_wanted'
SERVE_BATCH = 6
_TABLES_DONE = []


def fingerprint(idx):
	parts = (ROWS_VERSION, getattr(idx, 'lang', ''), getattr(idx, 'art_lang', ''), getattr(idx, 'mpa_country', ''),
			 getattr(idx, 'enable_fanarttv', ''), getattr(idx, 'prefer_en_titles', ''), getattr(idx, 'poster_path', ''),
			 getattr(idx, 'fanart_path', ''), getattr(idx, 'still_path', ''), getattr(idx, 'profile_path', ''),
			 getattr(idx, 'user', ''))
	return md5(repr(parts).encode('utf-8')).hexdigest()[:16]


def _key(kind, url, fp):
	return md5(('%s|%s|%s' % (kind, url, fp)).encode('utf-8')).hexdigest()


def _digest(row):
	try: return md5(row[0].encode('utf-8')).digest() if row and row[0] else None
	except Exception: return None


def _connect():
	if not existsPath(dataPath): makeFile(dataPath)
	dbcon = db.connect(rowsFile, timeout=20)
	dbcon.execute('PRAGMA synchronous = NORMAL')
	if not _TABLES_DONE:
		dbcon.execute('PRAGMA journal_mode = WAL') # v2.0.41: queda guardado en el fichero; una vez por proceso basta
		dbcon.execute('CREATE TABLE IF NOT EXISTS rows (key TEXT PRIMARY KEY, kind TEXT, url TEXT, fp TEXT, built INTEGER, has_light INTEGER, payload TEXT)')
		dbcon.execute('CREATE TABLE IF NOT EXISTS rows_queue (key TEXT PRIMARY KEY, kind TEXT, url TEXT, fp TEXT, asked INTEGER)')
		dbcon.commit()
		_TABLES_DONE.append(1)
	return dbcon


def _complete(items):
	# a page made under the precache's time budget can hold titles that were not
	# filled in yet: such a page is not kept
	for i in items:
		if not isinstance(i, dict) or not i.get('tmdb'): return False
		if not (i.get('title') or i.get('tvshowtitle')): return False
	return True


def get(kind, url, fp):
	"""The kept page, or None. Asks for a rebuild when it is old or light."""
	dbcon = None
	try:
		dbcon = _connect()
		key = _key(kind, url, fp)
		row = dbcon.execute('SELECT built, has_light, payload FROM rows WHERE key=?', (key,)).fetchone()
		if not row: return None
		age = time() - int(row[0] or 0)
		if age > ROW_MAX_AGE: return None
		items = jsloads(row[2])
		if not isinstance(items, list) or not items: return None
		if row[1] or age > REFRESH_AFTER:
			dbcon.execute('INSERT OR IGNORE INTO rows_queue VALUES (?, ?, ?, ?, ?)', (key, kind, url, fp, int(time())))
			dbcon.commit()
			_wake_service()
		return items
	except Exception:
		from resources.lib.modules import log_utils
		log_utils.error()
		return None
	finally:
		try:
			if dbcon: dbcon.close()
		except Exception: pass


def put(kind, url, fp, items):
	if not items or not isinstance(items, list) or not _complete(items): return False
	try: payload = jsdumps(items, ensure_ascii=False, separators=(',', ':'))
	except Exception: return False # something JSON cannot hold: the page is simply not kept
	dbcon = None
	try:
		dbcon = _connect()
		key = _key(kind, url, fp)
		has_light = 1 if any(i.get('meta_light') for i in items) else 0
		dbcon.execute('INSERT OR REPLACE INTO rows VALUES (?, ?, ?, ?, ?, ?, ?)', (key, kind, url, fp, int(time()), has_light, payload))
		dbcon.execute('DELETE FROM rows_queue WHERE key=?', (key,))
		dbcon.commit()
		return True
	except Exception:
		from resources.lib.modules import log_utils
		log_utils.error()
		return False
	finally:
		try:
			if dbcon: dbcon.close()
		except Exception: pass


def _wake_service():
	try:
		from resources.lib.modules import control
		control.homeWindow.setProperty(WANTED_PROP, str(int(time())))
	except Exception: pass


def wanted():
	try:
		from resources.lib.modules import control
		return bool(control.homeWindow.getProperty(WANTED_PROP))
	except Exception: return False


def serve(batch=SERVE_BATCH):
	"""Service side: rebuild the rows the clicks asked for. Returns how many
	rows changed (the caller refreshes the widgets when any did)."""
	try:
		from resources.lib.modules import control
		control.homeWindow.clearProperty(WANTED_PROP)
	except Exception: pass
	dbcon = None
	try:
		dbcon = _connect()
		todo = dbcon.execute('SELECT key, kind, url, fp FROM rows_queue ORDER BY asked ASC LIMIT ?', (int(batch),)).fetchall()
		# v2.0.41: solo la huella de cada fila, no su JSON entero (50-150 KB) mientras se descarga el lote
		olds = dict((k, _digest(dbcon.execute('SELECT payload FROM rows WHERE key=?', (k,)).fetchone())) for k, _a, _b, _c in todo)
	except Exception:
		from resources.lib.modules import log_utils
		log_utils.error()
		return 0
	finally:
		try:
			if dbcon: dbcon.close()
		except Exception: pass
	if not todo: return 0
	from resources.lib.indexers.tmdb import Movies, TVshows
	from resources.lib.modules.nav_busy import PoliteSemaphore
	changed = 0
	indexers = {}
	for key, kind, url, fp in todo:
		try:
			if kind not in indexers: indexers[kind] = Movies() if kind == 'movie' else TVshows()
			idx = indexers[kind]
			if fingerprint(idx) == fp:
				idx.meta = []
				idx.tmdb_list(url, meta_sem=PoliteSemaphore(4)) # stores the new row itself
			dbcon = _connect()
			try:
				new = dbcon.execute('SELECT payload FROM rows WHERE key=?', (key,)).fetchone()
				dbcon.execute('DELETE FROM rows_queue WHERE key=?', (key,))
				dbcon.commit()
			finally:
				dbcon.close()
			if new and (not olds.get(key) or olds[key] != _digest(new)): changed += 1
		except Exception:
			from resources.lib.modules import log_utils
			log_utils.error()
	return changed


def clear():
	dbcon = None
	try:
		dbcon = _connect()
		dbcon.execute('DELETE FROM rows')
		dbcon.execute('DELETE FROM rows_queue')
		dbcon.commit()
		return True
	except Exception:
		return False
	finally:
		try:
			if dbcon: dbcon.close()
		except Exception: pass
