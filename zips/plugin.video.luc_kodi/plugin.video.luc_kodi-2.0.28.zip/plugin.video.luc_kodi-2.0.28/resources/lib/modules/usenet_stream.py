# -*- coding: utf-8 -*-
"""
	luc_kodi - motor de streaming Usenet (v2.0.24 test)

	Servidor HTTP local (127.0.0.1) que convierte un NZB en un fichero de
	video reproducible por Kodi SIN descargarlo entero y SIN debrid:

	  Kodi --GET Range--> 127.0.0.1:<puerto>/stream/<clave>/video.mkv
	        <-- bytes --- sesion: pide a Easynews (NNTP) solo los segmentos
	                      que cubren ese rango, los decodifica (yEnc) y los
	                      sirve en orden, con lectura anticipada.

	Vive en el SERVICIO de luc_kodi (service.py), no en la llamada del plugin:
	el plugin termina en cuanto entrega la URL a Kodi, y con
	reuseLanguageInvoker sus hilos no tienen una vida fiable. El servicio
	corre mientras Kodi este abierto. El puerto se publica en la propiedad de
	ventana 'luc_kodi.usenet.port' (Window 10000) para que el plugin lo lea.

	Rutas:
	  GET /ping                    -> 'luc_kodi-usenet'
	  GET /prepare/<clave>         -> JSON: abre la sesion, elige el video del
	                                  NZB, descarga el 1er segmento y comprueba
	                                  que se puede reproducir (MKV/MP4/AVI/TS).
	  GET|HEAD /stream/<clave>/<x> -> el video, con soporte de Range (seek).
	  GET /close/<clave>           -> cierra la sesion y sus conexiones.

	El NZB lo deja el plugin en <perfil>/usenet/nzb/<clave>.nzb (clave = md5
	del enlace del NZB, el mismo 'hash' que pone el scraper Newznab), asi que
	el apikey del indexer nunca viaja hasta aqui.

	Formatos: fichero directo (MKV/MP4/AVI/TS) y RAR 'store' (sin compresion,
	RAR4 y RAR5, en uno o cientos de volumenes, con nombres ofuscados o no).
	v2.0.28: tambien 7z 'store', en un volumen o partido (.7z.001...), como
	TMDb Movies.
	Limites (se dicen claro al plugin para que use el siguiente servicio
	activo, Premiumize o TorBox):
	  - 7z o RAR comprimidos, RAR cifrado, 7z partido con nombres ofuscados.
	  - sin reparacion PAR2: un articulo que falta se rellena con ceros
	    (un salto de imagen) y se anota en el log. Por eso la comprobacion
	    de salud del scraper descarta antes los NZB incompletos.
"""

import json
import os
import re
import socket
import threading
import time
from bisect import bisect_right
from collections import OrderedDict
from heapq import heappush, heappop
from http.server import BaseHTTPRequestHandler, HTTPServer
from socketserver import ThreadingMixIn

from resources.lib.modules import usenet_core as core

PORT_PROPERTY = 'luc_kodi.usenet.port'
PORT_RANGE = range(47321, 47331)
KEY_RE = re.compile(r'^[0-9a-f]{32}$')

# Ventanas en BYTES, no en segmentos: hay posts con segmentos de 3,84 MB
# (log del 1-nov-2026, Hocus Pocus / Mayday) y con 16/48 segmentos fijos eran
# 61 MB por delante y 184 MB de RAM por sesion.
PREFETCH_BYTES = 12 * 1024 * 1024   # ~12 MB por delante
CACHE_BYTES = 36 * 1024 * 1024      # ~36 MB de RAM como mucho por sesion
SESSION_IDLE_SECS = 600     # una sesion sin lecturas se cierra a los 10 min
CONN_IDLE_SECS = 45         # una conexion NNTP ociosa se cierra
GET_TIMEOUT = 45            # espera maxima por un segmento
MAX_SESSIONS = 2
SCAN_MAX_FILES = 250       # tope de ficheros para reparar el orden de un RAR ofuscado
MAX_CONSECUTIVE_MISSING = 12
# Release incompleto: si de lo ya pedido falta el 3% o mas (con al menos 40
# segmentos de muestra) se corta. Log del 1-nov-2026: un remux de Coco paso
# la comprobacion de salud (15 muestras) y faltaba ~6%: 35 huecos en 605
# segmentos, la imagen rota cada pocos segundos.
INCOMPLETE_MIN_SEGMENTS = 40
INCOMPLETE_RATIO = 0.03

CONTENT_TYPES = {'mkv': 'video/x-matroska', 'mp4': 'video/mp4', 'avi': 'video/x-msvideo',
				 'ts': 'video/mp2t'}
STREAMABLE = ('mkv', 'mp4', 'avi', 'ts')


def _noop_log(msg, level=None):
	pass


class SessionError(Exception):
	pass


def _vint_len(n):
	k = 1
	while n >= 0x80:
		n >>= 7
		k += 1
	return k


class Session(object):
	def __init__(self, key, nzb_path, cfg, log=_noop_log, on_incomplete=None, on_close=None):
		self.key = key
		self.on_close = on_close
		self.nzb_path = nzb_path
		self.cfg = dict(cfg)
		self.log = log
		self.lock = threading.RLock()
		self.cond = threading.Condition(self.lock)
		self.cache = OrderedDict()           # idx -> bytes
		self.inflight = set()
		self.queued = {}                     # idx -> mejor prioridad encolada
		self.failed = {}                     # idx -> motivo (error duro)
		self.missing = set()                 # idx rellenados con ceros (430)
		self.consecutive_missing = 0
		self.incomplete = None               # % que falta, si se corta
		self.on_incomplete = on_incomplete
		self.heap = []
		self.seq = 0
		self.readers = {}                    # id lector -> segmento actual
		self.closed = False
		self.last_use = time.time()
		self.workers = []
		self.ready = False
		self.info = {}
		self.stats = {'bytes': 0, 'segments': 0, 'started': time.time()}
		# v2.0.25: medidas para el informe de uso (Tools > Usenet report)
		self.conns = []                      # toda conexion abierta, para sumar sus bytes
		self.cpu = 0.0                       # s de CPU decodificando yEnc
		self.cache_peak = 0                  # bytes en RAM, maximo
		self.buckets = {}                    # tramo de 5 s -> bytes recibidos
		self.stalls = 0                      # esperas de mas de 2 s viendo de seguido
		self.stall_secs = 0.0
		self.seeks = 0
		self.last_idx = None
		self.reads = {}                      # lector -> segmentos leidos de seguido
		self.started_at = {}                 # idx en vuelo -> cuando se pidio al servidor
		self.reconnects = 0
		self.retries = 0
		self.lag_max = 0.0                   # mayor retraso del reloj de Python (diagnostico)
		self.is_rar = False
		self.nseg = 0

	# -- preparacion ---------------------------------------------------------
	def _fetch_first(self, conn, f):
		code, art = conn.body(f['segments'][0][2])
		if not art:
			raise SessionError('first article not available (%s)' % code)
		return core.yenc_decode(art)

	def prepare(self):
		"""Abre el release: fichero directo (MKV/MP4/AVI/TS) o RAR 'store'
		(sin compresion) en uno o varios volumenes, con o sin nombres
		ofuscados. Lo que ve Kodi es el video de dentro.

		Modelo comun: una lista de volumenes, cada uno con sus segmentos y el
		trozo [data_off, data_off + data_size) que aporta al video. Un fichero
		directo es un unico 'volumen' con data_off 0. Los segmentos se numeran
		seguidos a traves de todos los volumenes (indice lineal), asi la cache,
		la lectura anticipada y el corte por incompleto no cambian.
		"""
		with open(self.nzb_path, 'rb') as f:
			files = core.parse_nzb(f.read())
		media, kind = core.pick_media(files)
		if not media:
			raise SessionError('no video file in NZB')
		if kind == '7z':
			return self._prepare_7z(files, core.seven_volumes(files), kind)
		vol_files = core.rar_volumes(files) if kind == 'rar' else [media]
		if not vol_files:
			raise SessionError('no RAR volumes found in NZB')
		second = tail = None
		conn = self._connect()
		try:
			first = self._fetch_first(conn, vol_files[0])
			container, detail = core.sniff(first['data'])
			if container not in STREAMABLE and container != 'rar' and kind == 'obfuscated':
				# El mayor fichero puede ser justo un ajeno del tamano de un
				# volumen: se prueban los primeros candidatos en su orden.
				for alt in core.rar_candidates(files)[:3]:
					if alt is media:
						continue
					try:
						cand = self._fetch_first(conn, alt)
					except SessionError:
						continue
					c2, d2 = core.sniff(cand['data'])
					if c2 == 'rar' or c2 in STREAMABLE:
						media, first, container, detail = alt, cand, c2, d2
						vol_files = [alt]
						break
			if container == '7z' and kind == 'obfuscated':
				# v2.0.28: un 7z de un solo volumen con nombre ofuscado
				conn.close(); conn = None
				return self._prepare_7z(files, [media], kind, first=first)
			if container == 'rar' and kind != 'rar':
				# ofuscado: el mayor fichero era un volumen; se ordenan todos
				vol_files = core.rar_volumes(files)
				if not vol_files:
					raise SessionError('RAR volumes not found (not streamable)')
				if vol_files[0] is not media:
					first = self._fetch_first(conn, vol_files[0])
			if container == 'rar':
				try:
					h1 = core.parse_rar(first['data'])
				except ValueError as e:
					raise SessionError('RAR: %s (not streamable)' % e)
				if h1['encrypted']:
					raise SessionError('encrypted RAR (not streamable)')
				if not h1['store']:
					raise SessionError('compressed RAR (not streamable)')
				if h1['split_before']:
					raise SessionError('RAR volumes out of order (not streamable)')
				inner, idetail = core.sniff(first['data'][h1['data_off']:h1['data_off'] + 4096])
				if inner not in STREAMABLE:
					raise SessionError('RAR holds %s, not a playable video (not streamable)' % inner.upper())
				def _layout(vol_files):
					second = tail = None
					n = len(vol_files) if h1['split_after'] else 1
					if n < 2 and h1['split_after']:
						raise SessionError('RAR volumes missing from NZB (not streamable)')
					offs, sizes = [h1['data_off']], [h1['data_size']]
					if h1['split_after']:
						second = self._fetch_first(conn, vol_files[1])
						try:
							h2 = core.parse_rar(second['data'])
						except ValueError as e:
							raise SessionError('RAR volume 2: %s (not streamable)' % e)
						if not h2['split_before']:
							raise SessionError('RAR volume order mismatch (not streamable)')
						mid = h2['data_size']
						if mid <= 0:
							raise SessionError('RAR volume layout mismatch (not streamable)')
						# RAR5 guarda el numero de volumen como vint en la cabecera
						# principal: a partir del volumen 129 ocupa 2 bytes, la
						# cabecera crece 1 byte y el volumen lleva 1 byte menos de
						# datos (el tamano de volumen es fijo). RAR4 no lo guarda ahi.
						def _grow(k):
							if h1['fmt'] != 5: return 0
							return _vint_len(k) - _vint_len(1)
						# Cuantos volumenes hacen falta sale de las cabeceras, no de
						# cuantos ficheros trae el NZB: log del 1-nov-2026, Miami
						# Bici, un fichero de mas (par2 ofuscado) se tomo por el
						# ultimo volumen.
						rem = h1['unp_size'] - h1['data_size']
						k = 1
						while rem > 0:
							d = mid - _grow(k)
							if rem <= d:
								sizes.append(rem)
							else:
								sizes.append(d)
							rem -= d
							k += 1
							if k > 20000:
								raise SessionError('RAR volume layout mismatch (not streamable)')
						n = len(sizes)
						if n > len(vol_files):
							# Log del 1-nov-2026, Miami Bici de PlayWEB: el volumen 33 de 60
							# esta sustituido por otro fichero en el propio post. Sin
							# reparacion PAR2 no hay forma de reproducirlo.
							raise SessionError('damaged post: RAR volume missing on the server (%d of %d), needs PAR2 repair (not streamable)' % (len(vol_files), n))
						offs += [h2['data_off'] + _grow(k) for k in range(1, n)]
						last = sizes[-1]
						if n == 2:
							if h2['split_after'] or h2['data_size'] != last:
								raise SessionError('RAR last volume mismatch (not streamable)')
						else:
							# El ultimo volumen no sigue el patron: su cabecera no lleva
							# 'continua en el siguiente' y su tamano de datos ocupa menos
							# (RAR5 lo guarda como vint). Se lee su cabecera de verdad.
							tail = self._fetch_first(conn, vol_files[n - 1])
							try:
								ht = core.parse_rar(tail['data'])
							except ValueError as e:
								raise SessionError('RAR last volume: %s (not streamable)' % e)
							if ht['split_after'] or ht['data_size'] != last:
								raise SessionError('RAR last volume mismatch (not streamable)')
							offs[n - 1] = ht['data_off']
					elif h1['data_size'] != h1['unp_size']:
						raise SessionError('RAR volume missing from NZB (not streamable)')
					vol_files = vol_files[:n]
					return vol_files, offs, sizes, second, tail, n
				try:
					vol_files, offs, sizes, second, tail, n = _layout(vol_files)
				except SessionError as e:
					# Un fichero ajeno colado entre los volumenes (log del
					# 1-nov-2026, Miami Bici de PlayWEB: el 33 de 70 era otro
					# fichero del mismo tamano) descuadra todo el orden. Si el
					# release es ofuscado y no muy grande, se mira el primer
					# segmento de cada candidato, se quitan los que no son
					# volumenes RAR y se vuelve a intentar una vez.
					# Tambien con nombres: log del 1-nov-2026, Miami Bici de
					# PlayWEB traia los volumenes nombrados y el ajeno entre ellos.
					cands = core.rar_volumes(files) if kind == 'rar' else core.rar_candidates(files)
					if 'not streamable' not in str(e) or len(cands) > SCAN_MAX_FILES:
						raise
					vol_files = self._scan_rar(cands, h1['fmt'])
					self.log('USENET: session %s: RAR order repaired by scanning %d files (%d volumes kept)'
							 % (self.key[:8], len(cands), len(vol_files)))
					vol_files, offs, sizes, second, tail, n = _layout(vol_files)
				total = h1['unp_size']
				detail = 'RAR%d store, %d vol, %s' % (h1['fmt'], n, idetail)
				container = inner
				self.is_rar = True
			elif container in STREAMABLE:
				total = first['size']
				offs, sizes = [0], [total]
				self.is_rar = False
			else:
				raise SessionError('%s (%s) is not streamable yet' % (container.upper(), detail))
		finally:
			if conn is not None: conn.close()
		return self._finish(media, kind, vol_files, offs, sizes, first, second, tail, total, container, detail)

	def _prepare_7z(self, files, vol_files, kind, first=None):
		"""v2.0.28: 7z 'store'. Volumen 1: el contenido empieza en el byte 32;
		los siguientes son el mismo archivo cortado a trozos, sin cabecera."""
		if not vol_files:
			raise SessionError('no 7z volumes found in NZB')
		tail = None
		conn = self._connect()
		try:
			if first is None:
				first = self._fetch_first(conn, vol_files[0])
			try:
				h = core.parse_7z(first['data'])
			except ValueError as e:
				raise SessionError('7z: %s (not streamable)' % e)
			inner, idetail = core.sniff(first['data'][h['data_off']:h['data_off'] + 4096])
			if inner not in STREAMABLE:
				raise SessionError('compressed 7z, or it holds %s and not a video (not streamable)' % inner.upper())
			vol_size = first['size']
			n = max(1, -(-h['archive'] // vol_size))
			if n > 1 and kind != '7z':
				raise SessionError('split 7z with hidden names (not streamable)')
			if n > len(vol_files):
				raise SessionError('damaged post: 7z volume missing on the server (%d of %d) (not streamable)' % (len(vol_files), n))
			vol_files = vol_files[:n]
			offs = [h['data_off']] + [0] * (n - 1)
			rem, sizes = h['packed'], []
			for k in range(n):
				room = vol_size - offs[k]
				sizes.append(min(rem, room))
				rem -= sizes[-1]
			if rem > 0:
				raise SessionError('7z volume layout mismatch (not streamable)')
			if n > 1:
				# los trozos de en medio miden lo mismo que el primero (mismos
				# articulos en el NZB); el ultimo, lo que falta del archivo: se
				# comprueba con su propio yEnc
				nfirst = len(vol_files[0]['segments'])
				if any(len(v['segments']) != nfirst for v in vol_files[1:n - 1]):
					raise SessionError('7z volumes of different sizes (not streamable)')
				tail = self._fetch_first(conn, vol_files[n - 1])
				if tail['size'] != h['archive'] - vol_size * (n - 1):
					raise SessionError('7z last volume mismatch (not streamable)')
				# el ultimo trozo puede llevar solo la cabecera final del 7z
				while n > 1 and sizes[-1] == 0:
					n -= 1; sizes.pop(); offs.pop(); vol_files = vol_files[:n]; tail = None
		finally:
			conn.close()
		detail = '7z store, %d vol, %s' % (n, idetail)
		return self._finish(vol_files[0], kind, vol_files, offs, sizes, first, None, tail, h['packed'], inner, detail)

	def _finish(self, media, kind, vol_files, offs, sizes, first, second, tail, total, container, detail):
		part = first['end'] - first['begin']
		if first['begin'] != 0 or part <= 0 or total <= 0:
			raise SessionError('unexpected yEnc layout')
		expected = (first['size'] + part - 1) // part
		if expected != len(vol_files[0]['segments']):
			raise SessionError('irregular segments (%d in NZB, %d expected)' % (len(vol_files[0]['segments']), expected))
		for extra, vf in ((second, vol_files[1] if len(vol_files) > 1 else None), (tail, vol_files[-1])):
			if extra is not None and len(vf['segments']) > 1 and extra['end'] - extra['begin'] != part:
				raise SessionError('RAR volumes posted with different segment sizes')
		self.vols = vol_files
		self.offs, self.sizes = offs, sizes
		self.base, self.starts = [], []
		nseg = vstart = 0
		for v, sz in zip(vol_files, sizes):
			self.base.append(nseg)
			self.starts.append(vstart)
			nseg += len(v['segments'])
			vstart += sz
		self.nseg = nseg
		self.verified = set([0, 1] if second is not None else [0])
		if tail is not None:
			self.verified.add(len(vol_files) - 1)
		self.layout_error = None
		self.name = media['name']
		self.part = part
		self.prefetch = max(4, PREFETCH_BYTES // part)
		self.cache_max = max(8, CACHE_BYTES // part)
		self.total = total
		self.container = container
		with self.lock:
			self.cache[0] = first['data']
			if second is not None:
				self.cache[self.base[1]] = second['data']
			if tail is not None:
				self.cache[self.base[-1]] = tail['data']
		self.info = {'ok': True, 'size': total, 'container': container, 'detail': detail,
					 'name': self.name if not kind == 'obfuscated' else '',
					 'segments': nseg, 'part': part, 'kind': kind, 'volumes': len(vol_files)}
		self.ready = True
		t = threading.Thread(target=self._watchdog, name='usenet-watchdog')
		t.daemon = True
		t.start()
		for _ in range(max(1, int(self.cfg.get('connections') or 4))):
			t = threading.Thread(target=self._worker, name='usenet-worker')
			t.daemon = True
			t.start()
			self.workers.append(t)
		# el final del fichero lo pide Kodi casi siempre (indices del MKV)
		self.request(self._lin_for(total - 1), 5)
		self.log('USENET: session %s ready: %s %s, %.2f GB, %d segments of %d bytes'
				 % (self.key[:8], container, detail, total / 1073741824.0, nseg, part))
		return self.info

	def _scan_rar(self, cands, fmt):
		"""Primer segmento de cada candidato (4 conexiones a la vez): se quedan
		los que son volumenes RAR del mismo formato, en orden, desde el que no
		continua de otro hasta el que no sigue en otro."""
		heads = [None] * len(cands)
		lock = threading.Lock()
		todo = list(range(len(cands)))

		def work():
			c = None
			try:
				c = self._connect()
				while True:
					with lock:
						if not todo: break
						i = todo.pop(0)
					try:
						code, art = c.body(cands[i]['segments'][0][2])
						if art:
							heads[i] = core.parse_rar(core.yenc_decode(art)['data'])
					except (ValueError, KeyError):
						heads[i] = None
			except Exception:
				pass
			finally:
				if c: c.close()
		th = [threading.Thread(target=work) for _ in range(4)]
		[t.start() for t in th]
		[t.join(120) for t in th]
		vols, started = [], False
		for f, h in zip(cands, heads):
			if not h or h.get('fmt') != fmt:
				continue
			if not started:
				if h['split_before']:
					continue
				started = True
			vols.append(f)
			if not h['split_after']:
				break
		if not vols:
			raise SessionError('RAR volumes not found after scan (not streamable)')
		return vols

	# -- mapa fichero virtual -> (volumen, segmento) --------------------------
	def _vol_of(self, pos):
		return bisect_right(self.starts, pos) - 1

	def _lin_for(self, pos):
		k = self._vol_of(pos)
		fo = self.offs[k] + (pos - self.starts[k])
		return self.base[k] + fo // self.part

	def _split(self, lin):
		k = bisect_right(self.base, lin) - 1
		return k, lin - self.base[k]

	def _check_volume(self, k, data):
		"""Cabecera real del volumen k frente a la supuesta (los intermedios
		iguales al 2). Si no cuadra se corta: mejor un error que video con
		trozos cruzados."""
		try:
			h = core.parse_rar(data)
		except ValueError as e:
			return 'volume %d: %s' % (k + 1, e)
		if h['data_off'] != self.offs[k] or h['data_size'] != self.sizes[k]:
			return ('volume %d layout differs (data at %d+%d, expected %d+%d)'
					% (k + 1, h['data_off'], h['data_size'], self.offs[k], self.sizes[k]))
		return None

	def _connect(self):
		c = self.cfg
		conn = core.NNTPConn(c['host'], c['port'], c['user'], c['password'],
							 timeout=c.get('timeout', 20), use_ssl=c.get('ssl', True))
		self.conns.append(conn)
		return conn

	def wire_bytes(self):
		return sum(getattr(c, 'rx', 0) for c in list(self.conns))

	# -- cola de segmentos ---------------------------------------------------
	def request(self, idx, prio):
		if idx < 0 or idx >= self.nseg:
			return
		with self.lock:
			if idx in self.cache or idx in self.inflight:
				return
			if self.queued.get(idx, 1 << 30) <= prio:
				return
			self.queued[idx] = prio
			self.seq += 1
			heappush(self.heap, (prio, self.seq, idx))
			# v2.0.25: notify_all. Los lectores esperan en la misma condicion que los
			# hilos de descarga: notify() podia despertar a un lector en vez de a un
			# hilo libre, y el segmento esperaba al timeout del hilo (5 s). Log del
			# 2-nov-2026: una pausa de 4,7-4,9 s en cada reproduccion, siempre a los
			# 20-34 segmentos, con 78-228 Mb/s de linea.
			self.cond.notify_all()

	def _wanted(self, idx):
		for pos in self.readers.values():
			if pos - 1 <= idx <= pos + self.prefetch + 2:
				return True
		return idx == self.nseg - 1

	def _worker(self):
		conn = None
		last_used = t_worker = time.time()
		while True:
			with self.lock:
				while not self.heap and not self.closed:
					self.cond.wait(1)
					if conn and time.time() - last_used > CONN_IDLE_SECS:
						try: conn.close()
						except Exception: pass
						conn = None
				if self.closed:
					break
				prio, _, idx = heappop(self.heap)
				if self.queued.get(idx) == prio:
					del self.queued[idx]
				if idx in self.cache or idx in self.inflight:
					continue
				if prio > 0 and not self._wanted(idx):
					continue           # prefetch viejo de antes de un seek
				self.inflight.add(idx)
				self.started_at[idx] = time.time()
			data, err = None, None
			for attempt in range(3):
				try:
					if conn is None:
						if attempt or last_used != t_worker: self.reconnects += 1
						conn = self._connect()
					vk, vi = self._split(idx)
					code, art = conn.body(self.vols[vk]['segments'][vi][2])
					if art is None:
						if code == core.NNTP_NO_ARTICLE:
							data = None
							err = 'missing'
						else:
							err = 'BODY %s' % code
							raise core.NNTPError(err)
					else:
						tm = getattr(conn, 'timing', (0, 0))
						if tm[1] > 2:
							self.log('USENET: segment %d took %.1fs from Easynews (answer after %.1fs, %d KB)'
									 % (idx + 1, tm[1], tm[0], len(art) // 1024))
						t_cpu = time.thread_time()
						dec = core.yenc_decode(art)
						self.cpu += time.thread_time() - t_cpu
						b5 = int(time.time() // 5)
						self.buckets[b5] = self.buckets.get(b5, 0) + len(art)
						if dec['begin'] != vi * self.part:
							# v2.0.27. MEASURED (kodi.log 4-nov-2026, Esref Ruya 2x04
							# TURK265): the NZB pointed segments 24 and 39 at articles
							# from somewhere else (offsets 119238656 and 408252416, not
							# even on a segment boundary). Before, that was a hard
							# error: Kodi got a short read every 2 s and the episode
							# stopped after 30 s. It is treated as a missing article
							# now: zero-filled (a short glitch), counted towards the
							# 'release incomplete' limit like any other hole.
							misplaced = dec['begin']
							data, err = None, 'misplaced'
						else:
							data, err = dec['data'], None
							if not dec['crc_ok']:
								self.log('USENET: crc mismatch on segment %d (kept)' % idx)
					break
				except Exception as e:
					err = '%s: %s' % (type(e).__name__, e)
					self.retries += 1
					if self.retries <= 5:
						self.log('USENET: segment %d, attempt %d failed (%.1fs in): %s'
								 % (idx + 1, attempt + 1, time.time() - self.stats['started'], err))
					try:
						if conn: conn.close()
					except Exception: pass
					conn = None
					time.sleep(0.5 * (attempt + 1))
			last_used = time.time()
			with self.lock:
				self.inflight.discard(idx)
				self.started_at.pop(idx, None)
				if err in ('missing', 'misplaced'):
					size = self._seg_len(idx)
					self.missing.add(idx)
					self.consecutive_missing += 1
					self.cache[idx] = b'\x00' * size
					if err == 'missing':
						self.log('USENET: article %d/%d missing on server, zero-filled' % (idx + 1, self.nseg))
					else:
						self.log('USENET: article %d/%d belongs elsewhere (yEnc offset %d, expected %d): wrong article in the NZB, zero-filled'
								 % (idx + 1, self.nseg, misplaced, vi * self.part))
				elif err:
					self.failed[idx] = err
					self.log('USENET: segment %d failed: %s' % (idx, err))
				else:
					self.consecutive_missing = 0
					self.cache[idx] = data
					if self.is_rar and vk not in self.verified and vi == 0:
						self.verified.add(vk)
						bad = self._check_volume(vk, data)
						if bad and not self.layout_error:
							self.layout_error = bad
							self.log('USENET: session %s stopped: RAR %s' % (self.key[:8], bad))
					self.stats['bytes'] += len(data)
					self.stats['segments'] += 1
				fetched = self.stats['segments'] + len(self.missing)
				if (self.incomplete is None and fetched >= INCOMPLETE_MIN_SEGMENTS
						and len(self.missing) >= INCOMPLETE_RATIO * fetched):
					self.incomplete = round(100.0 * len(self.missing) / fetched)
					self.log('USENET: session %s stopped: release incomplete on the server '
							 '(%d of %d articles missing, ~%d%%)' % (self.key[:8], len(self.missing), fetched, self.incomplete))
					if self.on_incomplete:
						try: self.on_incomplete(self.key, self.incomplete)
						except Exception: pass
				while len(self.cache) > self.cache_max:
					self.cache.popitem(last=False)
				held = len(self.cache) * self.part
				if held > self.cache_peak: self.cache_peak = held
				self.cond.notify_all()
		if conn:
			try: conn.close()
			except Exception: pass

	def _watchdog(self):
		"""Diagnostico: si Python entero se queda parado (otro addon ocupando el
		interprete, CPU al arrancar el video), este reloj lo nota."""
		while not self.closed:
			t = time.time()
			time.sleep(0.25)
			lag = time.time() - t - 0.25
			if lag > self.lag_max: self.lag_max = lag

	def _seg_len(self, idx):
		return self.part

	def get(self, idx, reader):
		self.last_use = time.time()
		with self.lock:
			prev = self.readers.get(reader)
			self.readers[reader] = idx
			# Kodi abre una peticion nueva en cada salto: cuenta como salto la que
			# empieza lejos de donde se iba leyendo (sin el final: indices del MKV)
			last = self.last_idx
			if prev is None and last is not None and abs(idx - last) > 2 and 2 < idx < self.nseg - 3:
				self.seeks += 1
			self.last_idx = idx
			# viendo de seguido (no un salto): esperar aqui es un parón en pantalla.
			# v2.0.25: sin contar el arranque ni lo justo despues de un salto (los
			# primeros segmentos de cada lectura los espera Kodi antes de pintar):
			# log del 2-nov-2026, una 'pausa' por reproduccion, siempre al empezar.
			n_read = self.reads.get(reader, 0) + 1 if prev is not None and idx == prev + 1 else 0
			self.reads[reader] = n_read
			watching = n_read > self.prefetch and idx not in self.cache
			if watching:   # para diagnosticar una pausa: como estaba el segmento al empezar a esperar
				w_state = ('in flight %.1fs' % (time.time() - self.started_at.get(idx, time.time()))) if idx in self.inflight else \
					(('queued, priority %s' % self.queued[idx]) if idx in self.queued else 'not requested')
				w_done, w_busy, w_heap = self.stats['segments'], len(self.inflight), len(self.heap)
				self.lag_max = 0.0
		t_wait = time.time()
		for k in range(idx + 1, min(idx + 1 + self.prefetch, self.nseg)):
			self.request(k, k - idx)
		# RAR: la cabecera de un volumen nuevo se comprueba en cuanto se entra
		if self.is_rar:
			vk, vi = self._split(idx)
			if vk not in self.verified and vi != 0:
				self.request(self.base[vk], 3)
		self.request(idx, 0)
		deadline = time.time() + GET_TIMEOUT
		with self.lock:
			while True:
				if self.incomplete is not None:
					raise SessionError('release incomplete on the server (~%d%% missing)' % self.incomplete)
				if self.layout_error:
					raise SessionError('RAR %s' % self.layout_error)
				if idx in self.cache:
					self.cache.move_to_end(idx)
					if watching:
						waited = time.time() - t_wait
						if waited > 2:
							self.stalls += 1
							self.stall_secs += waited
							self.log('USENET: pause of %.1fs while watching, segment %d/%d (%s; %d in flight, %d queued; '
									 '%d segments fetched meanwhile; Python held up to %.1fs; %d reconnects, %d retries so far)'
									 % (waited, idx + 1, self.nseg, w_state, w_busy, w_heap, self.stats['segments'] - w_done,
										self.lag_max, self.reconnects, self.retries))
					return self.cache[idx]
				if idx in self.failed:
					err = self.failed.pop(idx)
					raise SessionError('segment %d: %s' % (idx, err))
				if self.consecutive_missing >= MAX_CONSECUTIVE_MISSING:
					raise SessionError('too many missing articles in a row')
				if self.closed:
					raise SessionError('session closed')
				left = deadline - time.time()
				if left <= 0:
					raise SessionError('timeout waiting for segment %d' % idx)
				if idx not in self.inflight and self.queued.get(idx) is None:
					self.lock.release()
					try: self.request(idx, 0)
					finally: self.lock.acquire()
				self.cond.wait(min(left, 2))

	def iter_range(self, start, end, reader):
		"""Bytes [start, end] inclusive del fichero virtual, en trozos."""
		pos = start
		while pos <= end:
			k = self._vol_of(pos)
			fo = self.offs[k] + (pos - self.starts[k])
			vi = fo // self.part
			data = self.get(self.base[k] + vi, reader)
			off = fo - vi * self.part
			n = min(len(data) - off, end - pos + 1, self.starts[k] + self.sizes[k] - pos)
			if n <= 0:
				raise SessionError('empty chunk at %d' % pos)
			yield data[off:off + n]
			pos += n

	def drop_reader(self, reader):
		with self.lock:
			self.readers.pop(reader, None)
			self.reads.pop(reader, None)

	def close(self):
		with self.lock:
			if self.closed:
				return
			self.closed = True
			self.cond.notify_all()
		if self.ready:
			self.log('USENET: session %s closed: %.1f MB in %d segments, %d missing'
					 % (self.key[:8], self.stats['bytes'] / 1e6, self.stats['segments'], len(self.missing)))
		if self.on_close:
			try: self.on_close(self.summary())
			except Exception: pass

	def summary(self):
		"""Lo que costo esta sesion: para el informe de uso (Tools > Usenet report)."""
		busy = [b for b in self.buckets.values() if b > 0]
		mbps = lambda b: b * 8 / 5.0 / 1e6
		return {'key': self.key, 'ready': bool(self.ready), 'wire': self.wire_bytes(),
				'bytes': self.stats['bytes'], 'segments': self.stats['segments'],
				'missing': len(self.missing), 'size': getattr(self, 'total', 0),
				'secs': round(time.time() - self.stats['started'], 1), 'cpu': round(self.cpu, 2),
				'peak_mbps': round(max(mbps(b) for b in busy), 1) if busy else 0,
				'avg_mbps': round(sum(mbps(b) for b in busy) / len(busy), 1) if busy else 0,
				'cache_peak': self.cache_peak, 'cache_max': getattr(self, 'cache_max', 0) * getattr(self, 'part', 0),
				'stalls': self.stalls, 'stall_secs': round(self.stall_secs, 1), 'seeks': self.seeks,
				'incomplete': self.incomplete, 'rar': bool(self.is_rar),
				'volumes': len(getattr(self, 'vols', []) or []), 'conns': int(self.cfg.get('connections') or 4)}


class Engine(object):
	"""Registro de sesiones + configuracion. Uno por servicio."""

	def __init__(self, nzb_dir, cfg_provider, log=_noop_log, on_incomplete=None, on_close=None):
		self.nzb_dir = nzb_dir
		self.on_close = on_close
		self.cfg_provider = cfg_provider
		self.log = log
		self.sessions = OrderedDict()
		self.on_incomplete = on_incomplete
		self.lock = threading.Lock()
		self.prep_locks = {}

	def nzb_path(self, key):
		return os.path.join(self.nzb_dir, '%s.nzb' % key)

	def prepare(self, key):
		if not KEY_RE.match(key or ''):
			return {'ok': False, 'reason': 'bad key'}
		with self.lock:
			plock = self.prep_locks.setdefault(key, threading.Lock())
		with plock:
			with self.lock:
				s = self.sessions.get(key)
			if s and s.ready and not s.closed and s.incomplete is None:
				s.last_use = time.time()
				return s.info
			if s and s.incomplete is not None:
				return {'ok': False, 'reason': 'release incomplete on Easynews (~%d%% missing)' % s.incomplete}
			path = self.nzb_path(key)
			if not os.path.exists(path):
				return {'ok': False, 'reason': 'NZB not found'}
			cfg = self.cfg_provider()
			if not cfg or not cfg.get('user') or not cfg.get('password'):
				return {'ok': False, 'reason': 'Easynews credentials not set'}
			s = Session(key, path, cfg, self.log, self.on_incomplete, self.on_close)
			try:
				info = s.prepare()
			except core.NNTPAuthError as e:
				s.close()
				return {'ok': False, 'reason': 'Easynews login refused (%s)' % e}
			except Exception as e:
				s.close()
				self.log('USENET: prepare %s failed: %s: %s' % (key[:8], type(e).__name__, e))
				return {'ok': False, 'reason': str(e) or type(e).__name__}
			with self.lock:
				old = self.sessions.pop(key, None)
				self.sessions[key] = s
				extra = []
				while len(self.sessions) > MAX_SESSIONS:
					extra.append(self.sessions.popitem(last=False)[1])
			for o in ([old] if old else []) + extra:
				o.close()
			return info

	def get(self, key):
		with self.lock:
			s = self.sessions.get(key)
		if s and s.ready and not s.closed:
			return s
		return None

	def close(self, key=None):
		with self.lock:
			if key is None:
				items = list(self.sessions.values()); self.sessions.clear()
			else:
				s = self.sessions.pop(key, None); items = [s] if s else []
		for s in items:
			s.close()

	def reap(self):
		now = time.time()
		with self.lock:
			dead = [k for k, s in self.sessions.items()
					if now - s.last_use > SESSION_IDLE_SECS and not s.readers]
		for k in dead:
			self.close(k)


class _Server(ThreadingMixIn, HTTPServer):
	daemon_threads = True
	allow_reuse_address = True
	engine = None


class _Handler(BaseHTTPRequestHandler):
	protocol_version = 'HTTP/1.1'
	server_version = 'luc_kodi-usenet'

	def log_message(self, fmt, *args):
		pass

	def _send_plain(self, code, body, ctype='text/plain'):
		if isinstance(body, str):
			body = body.encode('utf-8')
		self.send_response(code)
		self.send_header('Content-Type', ctype)
		self.send_header('Content-Length', str(len(body)))
		self.send_header('Connection', 'close')
		self.end_headers()
		if self.command != 'HEAD':
			try: self.wfile.write(body)
			except Exception: pass
		self.close_connection = True

	def do_HEAD(self):
		self.do_GET()

	def do_GET(self):
		engine = self.server.engine
		parts = [p for p in self.path.split('?', 1)[0].split('/') if p]
		if not parts:
			return self._send_plain(404, 'not found')
		if parts[0] == 'ping':
			return self._send_plain(200, 'luc_kodi-usenet')
		if parts[0] == 'prepare' and len(parts) >= 2:
			info = engine.prepare(parts[1])
			return self._send_plain(200, json.dumps(info), 'application/json')
		if parts[0] == 'close' and len(parts) >= 2:
			engine.close(parts[1])
			return self._send_plain(200, 'closed')
		if parts[0] == 'stream' and len(parts) >= 2:
			return self._stream(engine, parts[1])
		return self._send_plain(404, 'not found')

	def _stream(self, engine, key):
		s = engine.get(key)
		if s is None:
			# Kodi puede volver a una URL tras cerrar la sesion por inactividad
			info = engine.prepare(key)
			s = engine.get(key) if info.get('ok') else None
			if s is None:
				return self._send_plain(404, info.get('reason') or 'no session')
		total = s.total
		start, end = 0, total - 1
		rng = self.headers.get('Range')
		partial = False
		if rng:
			m = re.match(r'bytes=(\d*)-(\d*)', rng.strip())
			if m:
				a, b = m.group(1), m.group(2)
				if a == '' and b:
					start = max(0, total - int(b))
				else:
					start = int(a or 0)
					if b: end = min(int(b), total - 1)
				partial = True
		if start >= total or start > end:
			self.send_response(416)
			self.send_header('Content-Range', 'bytes */%d' % total)
			self.send_header('Content-Length', '0')
			self.end_headers()
			return
		length = end - start + 1
		self.send_response(206 if partial else 200)
		self.send_header('Content-Type', CONTENT_TYPES.get(s.container, 'application/octet-stream'))
		self.send_header('Accept-Ranges', 'bytes')
		self.send_header('Content-Length', str(length))
		if partial:
			self.send_header('Content-Range', 'bytes %d-%d/%d' % (start, end, total))
		self.end_headers()
		if self.command == 'HEAD':
			return
		reader = '%s-%s' % (threading.get_ident(), time.time())
		try:
			for chunk in s.iter_range(start, end, reader):
				self.wfile.write(chunk)
		except (BrokenPipeError, ConnectionResetError, ConnectionAbortedError, socket.timeout):
			pass   # Kodi corta la conexion al hacer seek: es lo normal
		except SessionError as e:
			engine.log('USENET: stream %s stopped: %s' % (key[:8], e))
		except Exception as e:
			engine.log('USENET: stream %s error: %s: %s' % (key[:8], type(e).__name__, e))
		finally:
			s.drop_reader(reader)
			self.close_connection = True


class StreamServer(object):
	def __init__(self, nzb_dir, cfg_provider, log=_noop_log, ports=PORT_RANGE, on_incomplete=None, on_close=None):
		self.engine = Engine(nzb_dir, cfg_provider, log, on_incomplete, on_close)
		self.log = log
		self.ports = ports
		self.httpd = None
		self.port = None
		self._stop = threading.Event()

	def start(self):
		for p in self.ports:
			try:
				httpd = _Server(('127.0.0.1', p), _Handler)
			except OSError:
				continue
			httpd.engine = self.engine
			self.httpd, self.port = httpd, p
			t = threading.Thread(target=httpd.serve_forever, kwargs={'poll_interval': 0.5}, name='usenet-httpd')
			t.daemon = True
			t.start()
			r = threading.Thread(target=self._reaper, name='usenet-reaper')
			r.daemon = True
			r.start()
			self.log('USENET: stream server listening on 127.0.0.1:%d' % p)
			return p
		self.log('USENET: no free port for the stream server')
		return None

	def _reaper(self):
		while not self._stop.wait(30):
			try: self.engine.reap()
			except Exception: pass

	def stop(self):
		self._stop.set()
		try: self.engine.close()
		except Exception: pass
		if self.httpd:
			try:
				self.httpd.shutdown()
				self.httpd.server_close()
			except Exception: pass
