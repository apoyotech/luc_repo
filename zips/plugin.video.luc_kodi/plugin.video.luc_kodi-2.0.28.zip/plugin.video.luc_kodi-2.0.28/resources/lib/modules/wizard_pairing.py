# -*- coding: utf-8 -*-
"""
	luc_kodi Add-on
	wizard_pairing.py (v2.0.25) - how the setup wizards meet the phone or PC.

	Before, each wizard showed its address in a text dialog (OK to go on) and then
	waited behind a small progress bar in a corner. The address had to be typed by
	hand, and nothing on the TV said whether the phone had reached Kodi at all.

	Now every wizard uses the sign-in window of the accounts (modules/device_auth.py):
	a QR made on the device that opens the page straight away, the address in large
	type, the time left, and a status line that changes as soon as the phone opens
	the page ("Page open on 192.168.1.40"). Back or Cancel stops the wizard at once.
	If the window cannot be opened, device_auth falls back to the classic dialog.
"""

import socket
import time

from resources.lib.modules import control
from resources.lib.modules import log_utils


def wait(srv, url, name, timeout, what='your details'):
	"""Show the pairing window until the page sends its form, the user cancels or
	the time runs out. Returns 'done', 'cancelled' or 'timeout'. The caller still
	reads srv.result and stops the server."""
	port = str(url).rsplit(':', 1)[-1]
	from resources.lib.modules import device_auth
	handle = device_auth.start(
		'wizard', url, expires_in=timeout, keep_scheme=True,
		title='Set up %s' % name,
		sub='Fill in %s on your phone or computer' % what,
		status='Waiting for the page to be opened...',
		hint='Same Wi-Fi as this device (not a guest network, no VPN on the phone). '
			 'On this same device: http://127.0.0.1:%s' % port,
		logo=_icon())
	t0, seen, stage = time.time(), None, ''
	outcome = 'timeout'
	try:
		while time.time() - t0 < timeout:
			if srv.result is not None:
				outcome = 'done'
				break
			if not srv.is_alive():
				break
			if handle.iscanceled():
				outcome = 'cancelled'
				break
			try:
				if control.monitor.abortRequested():   # Kodi closing: never keep it waiting
					outcome = 'cancelled'
					break
			except Exception: pass
			peer = getattr(srv, 'seen', None)
			if peer and peer != seen:
				seen = peer
				handle.set_status('Page open on %s: fill it in and press Save' % peer)
			elif not seen:
				# v2.0.25: what reached Kodi so far, so the TV says where it gets stuck
				tls, knock = getattr(srv, 'tls', None), getattr(srv, 'knock', None)
				if tls and stage != 'tls':
					stage = 'tls'
					handle.set_status('The browser on %s asked for https: open %s (with http://)' % (tls, url))
				elif knock and stage not in ('tls', 'knock'):
					stage = 'knock'
					handle.set_status('%s reached this device. Waiting for the page...' % knock)
				elif not knock and not stage and time.time() - t0 > 25:
					stage = 'nothing'
					handle.set_status('Nothing has reached this device yet. Same Wi-Fi, no VPN; on Android allow the browser "Nearby devices" (local network)')
			control.sleep(250)
	finally:
		handle.close()
	log_utils.log('%s setup wizard: %s; page opened from %s; https asked by %s; connections from %s'
				  % (name, outcome, seen or 'nobody', getattr(srv, 'tls', None) or 'nobody', getattr(srv, 'knock', None) or 'nobody'),
				  level=log_utils.LOGINFO)
	return outcome


def _icon():
	try: return control.addonIcon()
	except Exception: return ''


# --------------------------------------------------- the wizard servers -----
def knock(srv, addr):
	"""A connection reached the wizard (it may still send nothing: Chrome opens
	spare ones while the address is typed)."""
	try:
		if getattr(srv, 'knock', None) != addr[0]:
			srv.knock = addr[0]
			log_utils.log('setup wizard: connection from %s' % addr[0], level=log_utils.LOGINFO)
	except Exception: pass


def sniff(srv, conn):
	"""False when the connection is not plain HTTP and must be closed now.
	A browser that tries https first sends a TLS handshake (first byte 0x16): the
	wizard has no certificate, so it is closed at once and the browser falls back
	to http instead of waiting on a connection that never answers."""
	try:
		head = conn.recv(1, socket.MSG_PEEK)
	except Exception:
		return False
	if not head:
		return False
	if head[:1] == b'\x16':
		try: peer = conn.getpeername()[0]
		except Exception: peer = '?'
		srv.tls = peer
		try:
			conn.settimeout(1.0)
			conn.recv(16384)                                   # the hello, so the close is clean
			conn.sendall(b'\x15\x03\x01\x00\x02\x02\x28')   # TLS alert: handshake_failure
		except Exception: pass
		log_utils.log('setup wizard: %s asked for https (TLS); closed so the browser uses http' % peer, level=log_utils.LOGINFO)
		return False
	return True
