# -*- coding: utf-8 -*-
"""
	luc_kodi - Easynews como proveedor Usenet para el scraper Newznab (v2.0.24 test)

	Modelo: el INDEXER (NZBGeek u otro Newznab) encuentra el NZB, EASYNEWS lo
	sirve por NNTP (tu cuenta de Easynews es tambien un servidor Usenet) y el
	motor local de luc_kodi (usenet_stream.py, en el servicio) lo reproduce
	al momento, sin descargarlo entero y sin pasar por ningun debrid.

	Este modulo es el pegamento del lado del plugin:
	  enabled()         ajuste newznab.use_easynews + credenciales de Easynews
	  nntp_config()     servidor/puerto/conexiones desde los ajustes
	  fetch_nzb()       baja el .nzb del indexer UNA vez y lo guarda en el
	                    perfil (usenet/nzb/<hash>.nzb, sin el apikey)
	  health_filter()   comprobacion de salud en el scraper: descarta los NZB
	                    borrados en Easynews y marca los verificados
	  resolve()         prepara la sesion en el servicio y devuelve la URL local
	  start_service() / stop_service()   arranque del motor en service.py
	  test()            accion de ajustes "Test Easynews Usenet (NNTP)"

	Las credenciales se leen de los ajustes en cada uso; no se escriben en
	ningun fichero ni salen en el log.
"""

import hashlib
import json
import os
import re
import threading
import time
from urllib.request import Request, urlopen

from resources.lib.modules import control
from resources.lib.modules import log_utils
from resources.lib.modules import usenet_core as core

getSetting = control.setting
LOGDEBUG = log_utils.LOGDEBUG

HEALTH_TTL_OK = 12 * 3600       # un NZB sano se da por bueno 12 h
HEALTH_TTL_DEAD = 24 * 3600     # un NZB borrado no vuelve
NZB_KEEP_SECS = 3 * 86400       # los .nzb del perfil se limpian a los 3 dias
# Sube cada vez que el motor aprende a abrir algo que antes rechazaba (4 =
# RAR con un ajeno colado entre volumenes con nombre): lo rechazado por un motor
# anterior se vuelve a ofrecer.
ENGINE_VERSION = 4
HEALTH_BUDGET_SECS = 18         # tiempo maximo de la comprobacion por busqueda
HEALTH_WANT_OK = 8              # se para al encontrar estos releases buenos
HEALTH_CONNECTIONS = 8          # conexiones para STAT (Easynews permite 60)
UA = 'luc_kodi for Kodi'

_health_lock = threading.Lock()
_DISC_RE = re.compile(r'(?:^|[ ._\-\[(])(?:COMPLETE[ ._\-]+(?:UHD[ ._\-]+)?BLU-?RAY|BDMV|BD(?:25|50|66|100)|ISO|DISC\d*)(?:[ ._\-\])]|$)', re.I)


# -------------------------------------------------------------- ajustes -----
def _bool(id_, default='true'):
	v = getSetting(id_)
	return (v or default) == 'true'


def credentials():
	return (getSetting('easynews.username') or '').strip(), (getSetting('easynews.password') or '').strip()


def enabled():
	"""Easynews activado como reproductor de NZB y con credenciales."""
	if not _bool('newznab.use_easynews'):
		return False
	u, p = credentials()
	return bool(u and p)


def other_services():
	"""Hay otro servicio de NZB activo (Premiumize/TorBox) como respaldo."""
	pm = _bool('newznab.use_premiumize') and getSetting('premiumize.enable') == 'true' and bool(getSetting('premiumize.token'))
	tb = _bool('newznab.use_torbox') and getSetting('torbox.enable') == 'true' and bool(getSetting('torbox.token'))
	return pm or tb


def nntp_config():
	u, p = credentials()
	server = getSetting('newznab.en_server') or '0'
	host = core.EASYNEWS_HOSTS['us' if server == '1' else 'eu']
	port = 443 if (getSetting('newznab.en_port') or '0') == '1' else 563
	try: conns = int(getSetting('newznab.en_connections') or 4)
	except ValueError: conns = 4
	return {'host': host, 'port': port, 'user': u, 'password': p,
			'connections': max(1, min(conns, 10)), 'ssl': True, 'timeout': 20}


def _usenet_dir():
	d = os.path.join(control.dataPath, 'usenet')
	nzb = os.path.join(d, 'nzb')
	if not os.path.isdir(nzb):
		try: os.makedirs(nzb)
		except OSError: pass
	return d


def nzb_dir():
	return os.path.join(_usenet_dir(), 'nzb')


def nzb_key(nzb_url):
	"""Misma clave que el 'hash' del scraper Newznab: md5 del enlace."""
	return hashlib.md5((nzb_url or '').encode('utf-8')).hexdigest()


def _mask(text, nzb_url=None):
	key = getSetting('newznab.apikey') or ''
	if key and text:
		text = text.replace(key, '<APIKEY>')
	return text


# ------------------------------------------------------------------ NZB -----
def fetch_nzb(nzb_url, key=None, timeout=20):
	"""Ruta local del .nzb (descargandolo si hace falta) o None."""
	key = key or nzb_key(nzb_url)
	path = os.path.join(nzb_dir(), '%s.nzb' % key)
	if os.path.exists(path) and os.path.getsize(path) > 0:
		return path
	if not str(nzb_url or '').lower().startswith(('http://', 'https://')):
		return None
	try:
		req = Request(nzb_url, headers={'User-Agent': UA})
		with urlopen(req, timeout=timeout) as r:
			raw = r.read()
		if b'<nzb' not in raw:
			snippet = raw[:160].decode('utf-8', 'replace')
			log_utils.log('USENET: indexer did not return an NZB: %s' % _mask(snippet), level=LOGDEBUG)
			return None
		tmp = path + '.part'
		with open(tmp, 'wb') as f:
			f.write(raw)
		os.replace(tmp, path)
		return path
	except Exception as e:
		log_utils.log('USENET: NZB download failed: %s' % _mask('%s: %s' % (type(e).__name__, e)), level=LOGDEBUG)
		return None


def cleanup(max_age=NZB_KEEP_SECS):
	try:
		d = nzb_dir(); now = time.time()
		for n in os.listdir(d):
			p = os.path.join(d, n)
			try:
				if now - os.path.getmtime(p) > max_age:
					os.remove(p)
			except OSError: pass
	except Exception:
		pass


# --------------------------------------------------------------- salud ------
def _health_path():
	# Ficheros de versiones de prueba anteriores: se borran una vez. Desde
	# aqui los 'no reproducible' llevan la version del motor (ENGINE_VERSION)
	# y caducan solos cuando el motor aprende algo nuevo.
	for oldname in ('health.json', 'health_v2.json'):
		old = os.path.join(_usenet_dir(), oldname)
		if os.path.exists(old):
			try: os.remove(old)
			except OSError: pass
	return os.path.join(_usenet_dir(), 'health_v3.json')


def _health_load():
	try:
		with open(_health_path(), 'r') as f:
			return json.load(f)
	except Exception:
		return {}


def _health_save(data):
	now = time.time()
	keep = dict((k, v) for k, v in data.items()
				if now - v.get('ts', 0) < (HEALTH_TTL_DEAD if v.get('status') == 'dead' else HEALTH_TTL_OK))
	try:
		tmp = _health_path() + '.part'
		with open(tmp, 'w') as f:
			json.dump(keep, f)
		os.replace(tmp, _health_path())
	except Exception:
		pass


def _cached_verdict(cache, key):
	v = cache.get(key)
	if not v:
		return None
	if v.get('eng') is not None and v.get('eng') != ENGINE_VERSION:
		return None      # lo rechazo un motor anterior: se vuelve a mirar
	ttl = HEALTH_TTL_DEAD if v.get('status') == 'dead' else HEALTH_TTL_OK
	return v if time.time() - v.get('ts', 0) < ttl else None


def _remember_dead(key, pct=0, engine=False):
	"""engine=True: no es que falten articulos, es que el motor no sabe
	abrirlo; el veredicto lleva su version y caduca con la siguiente."""
	try:
		with _health_lock:
			cache = _health_load()
			cache[key] = {'status': 'dead', 'pct': pct, 'kind': None, 'checked': 1, 'ts': time.time()}
			if engine:
				cache[key]['eng'] = ENGINE_VERSION
			_health_save(cache)
	except Exception:
		pass


def _on_incomplete(key, pct):
	"""El motor corto un release al que le faltan articulos: se oculta en
	las proximas busquedas y se avisa (esto corre en el servicio)."""
	_remember_dead(key, pct)
	try:
		control.notification(message='Easynews: this release is incomplete (~%d%% missing). Pick another one.' % pct)
	except Exception:
		pass


def dead_keys():
	"""Claves de NZB que se sabe que estan borrados en Easynews (vigentes).
	sources.py las quita tambien de los resultados que vienen de la cache de
	proveedores (que no vuelve a pasar por el scraper durante horas)."""
	with _health_lock:
		cache = _health_load()
	return set(k for k in cache if (_cached_verdict(cache, k) or {}).get('status') == 'dead')


def _badge_into_info(info, badge):
	"""El badge va DETRAS del tamano: la lista de fuentes corta todo lo que
	hay antes de 'GB ' (prueba del 1-nov-2026: 'EN OK' delante no se veia)."""
	if not info:
		return badge
	parts = info.split(' | ')
	if parts and re.match(r'^\d+(\.\d+)?\s*(GB|MB|GiB|MiB)$', parts[0].strip(), re.I):
		return ' | '.join([parts[0], badge] + parts[1:])
	return '%s | %s' % (badge, info)


def health_filter(items, other_resolvers=None):
	"""Comprueba en Easynews los NZB de la lista y devuelve la lista filtrada.

	Orden: el mismo que vera el usuario (mejor calidad primero, luego grabs).
	Se sigue comprobando hasta tener HEALTH_WANT_OK releases buenos, o llegar
	al tope del ajuste (cada comprobacion baja el NZB = 1 grab del indexer), o
	agotar el tiempo. Prueba del 1-nov-2026 (Supergirl 2026, Tenzing 2026):
	los 8 primeros estaban todos borrados y el usuario fue pinchando, uno
	tras otro, releases sin comprobar que tambien lo estaban.

	  - 'dead' (borrado en Easynews)          -> fuera
	  - 'ok' / 'partial'                       -> marcado (en_health, badge)
	  - 7z por nombre sin otro servicio        -> fuera (el motor aun no los
	                                              reproduce)
	  - sin comprobar                          -> 'EN ?'; y si la mitad o mas
	    de lo comprobado estaba borrado, fuera tambien: en ese titulo lo que
	    queda sin comprobar casi seguro que tampoco esta.
	"""
	if not items or not enabled() or not _bool('newznab.en_health'):
		return items
	if other_resolvers is None:
		other_resolvers = other_services()
	try: limit = int(getSetting('newznab.en_health_checks') or 20)
	except ValueError: limit = 20
	cfg = nntp_config()
	t0 = time.time()
	with _health_lock:
		cache = _health_load()
	# Discos Blu-ray completos (BDMV/ISO dentro del RAR): ni el motor ni Kodi
	# los reproducen como un fichero. Log del 1-nov-2026: Addams Family y
	# Shawshank 'COMPLETE.UHD.BLURAY' pasaban la salud y fallaban al abrirlos.
	n_disc = 0
	if not other_resolvers:
		keep = [i for i in items if not _DISC_RE.search(i.get('name') or '')]
		n_disc = len(items) - len(keep)
		items = keep
	_qrank = {'4K': 0, '1080p': 1, '720p': 2, 'SD': 3, 'SCR': 4, 'CAM': 5}
	ordered = sorted(items, key=lambda i: (_qrank.get(i.get('quality'), 3), -int(i.get('seeders') or 0)))
	verdicts = {}
	queue = []
	for it in ordered:
		k = it.get('hash') or nzb_key(it.get('url'))
		v = _cached_verdict(cache, k)
		if v: verdicts[k] = v
		else: queue.append((k, it.get('url')))
	state = {'auth_failed': False, 'checked': 0, 'inflight': 0,
			 'ok': sum(1 for v in verdicts.values() if v.get('status') in ('ok', 'partial'))}

	if queue and limit > 0:
		lock = threading.Lock()

		def worker():
			conn = None
			while time.time() - t0 < HEALTH_BUDGET_SECS and not state['auth_failed']:
				with lock:
					if not queue or state['checked'] >= limit or state['ok'] >= HEALTH_WANT_OK:
						break
					# Con 8 hilos en vuelo se pasaba de largo: la prueba del
					# 1-nov-2026 comprobo 15 para quedarse con 8 (15 grabs). Si
					# los que ya estan en vuelo bastan, se espera a ver como
					# acaban antes de bajar otro NZB.
					wait = state['ok'] + state['inflight'] >= HEALTH_WANT_OK
					if not wait:
						k, url = queue.pop(0)
						state['checked'] += 1
						state['inflight'] += 1
				if wait:
					time.sleep(0.05)
					continue
				try:
					path = fetch_nzb(url, k)
					if not path: continue
					with open(path, 'rb') as f:
						files = core.parse_nzb(f.read())
					if conn is None:
						conn = core.NNTPConn(cfg['host'], cfg['port'], cfg['user'], cfg['password'], timeout=15)
					v = core.check_health(conn, files)
					v['ts'] = time.time()
					with lock:
						verdicts[k] = v
						if v['status'] in ('ok', 'partial'): state['ok'] += 1
				except core.NNTPAuthError as e:
					state['auth_failed'] = True
					log_utils.log('USENET: Easynews login refused during health check: %s' % e, level=log_utils.LOGINFO)
				except Exception as e:
					log_utils.log('USENET: health check error: %s: %s' % (type(e).__name__, e), level=LOGDEBUG)
					try:
						if conn: conn.close()
					except Exception: pass
					conn = None
				finally:
					with lock: state['inflight'] -= 1
			if conn: conn.close()

		# Solo STAT, sin decodificar nada: aqui mas conexiones si cunden.
		n = min(len(queue), limit, HEALTH_CONNECTIONS)
		threads = [threading.Thread(target=worker) for _ in range(n)]
		[t.start() for t in threads]
		[t.join(HEALTH_BUDGET_SECS + 5) for t in threads]
		with _health_lock:
			cache = _health_load()
			for k, v in list(verdicts.items()):
				if 'ts' in v: cache[k] = v
			_health_save(cache)

	n_dead = sum(1 for v in verdicts.values() if v.get('status') in ('dead', 'empty'))
	n_known = len(verdicts)
	hide_unchecked = n_known >= 4 and n_dead * 2 >= n_known
	out, dead, rar_dropped, ok, hidden = [], 0, n_disc, 0, 0
	for it in items:
		k = it.get('hash') or nzb_key(it.get('url'))
		v = verdicts.get(k)
		if not v:
			if hide_unchecked:
				hidden += 1; continue
			new = dict(it)
			new['info'] = _badge_into_info(new.get('info') or '', 'EN ?')
			out.append(new); continue
		if v['status'] in ('dead', 'empty'):
			dead += 1; continue
		kind = v.get('kind')
		# v2.0.24: el motor ya reproduce RAR 'store'. Quedan fuera los 7z (y,
		# al reproducir, los RAR comprimidos o cifrados).
		if kind == '7z' and not other_resolvers:
			rar_dropped += 1; continue
		new = dict(it)
		new['en_health'] = v['status']
		new['en_kind'] = kind
		badge = 'EN %d%%' % v.get('pct', 0) if v['status'] == 'partial' else 'EN OK'
		if kind == '7z':
			badge += ' ' + kind.upper()
		new['info'] = _badge_into_info(new.get('info') or '', badge)
		ok += 1
		out.append(new)
	log_utils.log('USENET: health check on Easynews: %d verified, %d removed/dead, %d 7z/disc skipped, '
				  '%d unchecked%s (%d checked now, %.1fs)'
				  % (ok, dead, rar_dropped, hidden or (len(out) - ok),
					 ' and hidden (most checked releases of this title are gone)' if hidden else '',
					 state['checked'], time.time() - t0), level=log_utils.LOGINFO)
	return out


# ------------------------------------------------------------- resolver -----
def _service_port():
	try:
		return int(control.homeWindow.getProperty('luc_kodi.usenet.port') or 0)
	except Exception:
		return 0


def _local_get(port, path, timeout=60):
	with urlopen('http://127.0.0.1:%d%s' % (port, path), timeout=timeout) as r:
		return r.read()


def resolve(item):
	"""(url local reproducible, None) o (None, motivo)."""
	if not enabled():
		return None, 'Easynews is not enabled or has no credentials'
	port = _service_port()
	if not port:
		return None, 'luc_kodi service stream server is not running'
	url = item.get('url') or ''
	key = item.get('hash') or nzb_key(url)
	if not fetch_nzb(url, key):
		return None, 'could not download the NZB from the indexer'
	try:
		info = json.loads(_local_get(port, '/prepare/%s' % key, timeout=60).decode('utf-8'))
	except Exception as e:
		return None, 'stream server: %s: %s' % (type(e).__name__, e)
	if not info.get('ok'):
		reason = info.get('reason') or 'not streamable'
		# El primer articulo ya no esta en Easynews: release borrado. Se apunta
		# como 'dead' para que la proxima busqueda no lo vuelva a ensenar.
		# Lo mismo si no se puede reproducir (RAR/7z, imagen de disco, ...):
		# log del 1-nov-2026, un Blu-ray completo (Hocus Pocus BeyondHD) con
		# nombre ofuscado pasaba la salud y fallaba aqui cada vez.
		# Un RAR/7z si lo puede bajar Premiumize/TorBox: no se oculta.
		# Borrado, incompleto o post danado: es el contenido del servidor, no
		# el motor; ninguna version nueva lo arregla.
		if '(430)' in reason or 'incomplete' in reason or 'damaged post' in reason:
			_remember_dead(key)
		elif 'not streamable' in reason and not other_services():
			_remember_dead(key, engine=True)
		return None, reason
	ext = info.get('container') or 'mkv'
	name = (item.get('name') or 'video').replace('/', ' ')
	safe = ''.join(c if (c.isalnum() or c in '._-') else '.' for c in name)[:120].strip('.') or 'video'
	log_utils.log('USENET: Easynews stream ready: %s (%s, %.2f GB)'
				  % (name, info.get('detail'), (info.get('size') or 0) / 1073741824.0), level=log_utils.LOGINFO)
	return 'http://127.0.0.1:%d/stream/%s/%s.%s' % (port, key, safe, ext), None


# -------------------------------------------------------------- servicio ----
_server = None


def start_service():
	"""Arranca el motor en el servicio y publica el puerto. Siempre arranca
	(es un socket en 127.0.0.1 sin conexiones hasta que se usa): asi activar
	Easynews en ajustes no exige reiniciar Kodi."""
	global _server
	if _server:
		return _server.port
	from resources.lib.modules.usenet_stream import StreamServer
	_usenet_dir()
	cleanup()

	def _log(msg, level=None):
		log_utils.log(msg, level=log_utils.LOGINFO)
	_server = StreamServer(nzb_dir(), nntp_config, _log, on_incomplete=_on_incomplete)
	port = _server.start()
	if port:
		control.homeWindow.setProperty('luc_kodi.usenet.port', str(port))
	return port


def stop_service():
	global _server
	try: control.homeWindow.clearProperty('luc_kodi.usenet.port')
	except Exception: pass
	if _server:
		_server.stop()
		_server = None


# ----------------------------------------------------------------- test -----
def test():
	"""Accion de ajustes: login NNTP + control de STAT + puerto del motor."""
	u, p = credentials()
	if not (u and p):
		control.okDialog(title='Easynews Usenet — test',
						 message='Fill in your Easynews username and password under Accounts first.')
		return
	cfg = nntp_config()
	lines = []
	try:
		t = time.time()
		conn = core.NNTPConn(cfg['host'], cfg['port'], cfg['user'], cfg['password'], timeout=15)
		lines.append('[COLOR ff00fa9a]Login OK[/COLOR] on %s:%d (%.1fs)' % (cfg['host'], cfg['port'], time.time() - t))
		ok_ctrl = None
		for group in ('alt.binaries.multimedia', 'alt.binaries.teevee'):
			code, line = conn.cmd('GROUP %s' % group)
			if code != 211: continue
			last = line.split()[2]
			code, line = conn.cmd('STAT %s' % last)
			mid = line.split()[-1] if code == 223 else ''
			ok_ctrl = (conn.stat(mid) == 223) if mid else False
			break
		conn.close()
		lines.append('Article lookup: %s' % ('[COLOR ff00fa9a]OK[/COLOR]' if ok_ctrl else '[COLOR ffff6666]could not verify[/COLOR]'))
	except core.NNTPAuthError as e:
		lines.append('[COLOR ffff6666]Login refused[/COLOR] (%s). Check the username/password, or your plan may not include NNTP access.' % e)
	except Exception as e:
		lines.append('[COLOR ffff6666]Could not connect[/COLOR]: %s: %s' % (type(e).__name__, e))
	port = _service_port()
	lines.append('Stream engine: %s' % (('[COLOR ff00fa9a]running on port %d[/COLOR]' % port) if port
										else '[COLOR ffff6666]not running — restart Kodi[/COLOR]'))
	control.okDialog(title='Easynews Usenet — test', message='\n'.join(lines))
