# -*- coding: utf-8 -*-
"""
	luc_kodi Add-on
	Exit list (v2.0.09).

	Every "Next page" is a new folder in Kodi's history, so leaving page 9 of
	a list took nine Back presses (reported on Xbox). The plugin now remembers
	where a list was entered from:

	  note_list()  called when a media list (movies, shows, seasons, episodes,
	               collections) is built. Kodi still shows the PREVIOUS folder
	               while the plugin runs, so Container.FolderPath is the place
	               the list was opened from. If that previous folder already
	               belongs to the current list (next page, show -> seasons ->
	               episodes, "find similar"...) the list just grows; otherwise a
	               new list starts and its exit target is that folder.
	  note_menu()  called when a menu is built: no list is open any more.
	  exit_list()  rebuilds the history as  luc_kodi home -> exit target,
	               so the next Back still behaves naturally.
	  go_home()    v2.0.09, panel button Home: luc_kodi main menu.

	v2.0.09, two levels. Inside a show (its seasons and episodes) the exit is
	"Exit <show>": it goes back to the page of the list the show was opened
	from, pressing Back once per level (seasons, episodes) so Kodi's history
	stays exactly as it was. Inside the list itself the exit is still
	"Exit <list>", back to the menu the list was opened from.
"""

from json import dumps as jsdumps, loads as jsloads
from urllib.parse import unquote_plus, parse_qsl
from resources.lib.modules import control

PROP_STATE = 'luc_kodi.exit.state'
PROP_TARGET = 'luc_kodi.exit.target'
PROP_LABEL = 'luc_kodi.exit.label'
ROOT = 'plugin://plugin.video.luc_kodi/'
VIDEOS_WINDOW = 'Window.IsActive(10025)'
MAX_CHAIN = 80
SHOW_ACTIONS = ('seasons', 'episodes')  # a show's own folders (router.py)


def _norm(path):
	try: p = unquote_plus(path or '')
	except Exception: p = path or ''
	return p.rstrip('/').strip()


def _ours(path):
	return (path or '').startswith(ROOT)


def _load():
	try:
		raw = control.homeWindow.getProperty(PROP_STATE)
		return jsloads(raw) if raw else {}
	except Exception: return {}


def _short(name, size=24):
	return (name[:size - 2] + '..') if len(name) > size else name


def _save(state, current=None):
	"""current: the folder being built, so the native entry is named after the
	right level (Exit <show> in its seasons/episodes, Exit <list> in the list)."""
	show = (state or {}).get('show') or {}
	if state and (state.get('target') or show.get('path')):
		control.homeWindow.setProperty(PROP_STATE, jsdumps(state))
		control.homeWindow.setProperty(PROP_TARGET, state.get('target') or show.get('parent') or '')
		if show.get('path') and current is not None and _norm(current) in show['path']:
			label = show.get('name') or ''
			text = (control.lang(48131) % _short(label)) if label else control.lang(48118)
		else:
			label = state.get('label') or ''
			text = (control.lang(48128) % label) if label else control.lang(48118)
		control.homeWindow.setProperty(PROP_LABEL, '[COLOR FFFFAA44]%s[/COLOR]' % text)
	else: clear()


def clear():
	for p in (PROP_STATE, PROP_TARGET, PROP_LABEL): control.homeWindow.clearProperty(p)


def _is_directory_call():
	try:
		from sys import argv
		return int(argv[1]) >= 0
	except Exception: return False


def _current_url():
	try:
		from sys import argv
		return '%s%s' % (argv[0], argv[2] if len(argv) > 2 else '')
	except Exception: return ''


def _params(url):
	try: return dict(parse_qsl(url.split('?', 1)[1])) if '?' in (url or '') else {}
	except Exception: return {}


def _clicked_label():
	label = control.infoLabel('ListItem.Label')
	try:
		from resources.lib.modules.context_hub import clean_label
		label = clean_label(label)
	except Exception: pass
	return label


def note_list():
	"""Call at the START of a media list builder (before endOfDirectory)."""
	try:
		if not _is_directory_call() or not control.condVisibility(VIDEOS_WINDOW): return  # widgets, Bingie windows, scripts
		cur = _current_url()
		if not _ours(cur): return
		parent = control.infoLabel('Container.FolderPath')
		state = _load()
		chain = state.get('chain') or []
		ncur, nparent = _norm(cur), _norm(parent)
		params = _params(cur)

		# ── show level (v2.0.09): its seasons and episodes ──
		show = state.get('show') or {}
		if params.get('action') in SHOW_ACTIONS:
			path = show.get('path') or []
			if path and nparent in path:
				if ncur not in path: path.append(ncur)
			elif path and ncur in path:
				pass  # Back from episodes into seasons, or a refresh
			elif _ours(parent) and nparent != ncur:
				name = params.get('tvshowtitle') or _clicked_label()
				show = {'name': name[:60], 'parent': parent, 'path': [ncur]}
			else:
				show = {}
			if show: show['path'] = (show.get('path') or [])[-MAX_CHAIN:]
			state['show'] = show
		else:
			state.pop('show', None)

		# ── list level ──
		if chain and (nparent in chain or ncur in chain):
			if ncur not in chain:
				chain.append(ncur)
				state['chain'] = chain[-MAX_CHAIN:]
		elif not _ours(parent) or nparent == ncur:
			state.update({'target': '', 'label': '', 'chain': []})  # opened from a home shortcut/widget: Back already leaves
		else:
			state.update({'target': parent, 'label': _clicked_label()[:40], 'chain': [ncur]})
		_save(state, cur)
	except Exception:
		from resources.lib.modules import log_utils
		log_utils.error()


def note_menu():
	"""Call when a menu (navigator, genres, languages, user lists...) is built."""
	try:
		if _is_directory_call() and control.condVisibility(VIDEOS_WINDOW): clear()
	except Exception: pass


def is_root(folderpath):
	return _norm(folderpath) == _norm(ROOT)


def exit_name():
	"""Name of the subcategory the current list was opened from (e.g. Trending)."""
	return _short(_load().get('label') or '')


def exit_level(folderpath=None):
	"""v2.0.09: ('show', name) inside a show's seasons/episodes, ('list', name)
	inside a list, (None, '') elsewhere."""
	state = _load()
	if folderpath is None: folderpath = control.infoLabel('Container.FolderPath')
	cur = _norm(folderpath)
	show = state.get('show') or {}
	if cur in (show.get('path') or []): return 'show', _short(show.get('name') or '')
	if state.get('target') and cur in (state.get('chain') or []): return 'list', _short(state.get('label') or '')
	return None, ''


def list_name():
	"""Name of the list the user is browsing, even from inside a show."""
	state = _load()
	return _short(state.get('label') or '') if state.get('target') else ''


def go_home():
	"""Panel button Home: luc_kodi main menu with a clean history."""
	try:
		clear()
		control.execute('Container.Update(%s,replace)' % ROOT)
	except Exception:
		from resources.lib.modules import log_utils
		log_utils.error()


def can_exit(folderpath=None):
	return exit_level(folderpath)[0] is not None


def _wait_for(path, timeout=8.0):
	monitor = control.monitor
	want = _norm(path)
	waited = 0.0
	while waited < timeout and not monitor.abortRequested():
		if _norm(control.infoLabel('Container.FolderPath')) == want and not control.condVisibility('Window.IsActive(busydialog)') \
				and not control.condVisibility('Window.IsActive(busydialognocancel)'):
			return True
		monitor.waitForAbort(0.1)
		waited += 0.1
	return False


def _exit_show(state, current):
	"""Back once per level of the show (episodes -> seasons -> list page),
	waiting for each folder so Kodi's history is left exactly as it was."""
	show = state.get('show') or {}
	path = show.get('path') or []
	steps = path[:path.index(current) + 1] if current in path else []
	expected = list(reversed([show.get('parent', '')] + steps[:-1]))
	state.pop('show', None)
	_save(state)
	for want in expected:
		control.execute('Action(Back)')
		if not _wait_for(want, timeout=6.0): break


def exit_list():
	"""Router action ctx_ExitList (native menu entry and the panel button)."""
	try:
		state = _load()
		current = _norm(control.infoLabel('Container.FolderPath'))
		level = exit_level()[0]
		if level == 'show':
			_exit_show(state, current)
			return
		target = state.get('target')
		if level != 'list' or not target:
			control.notification(message=control.lang(48119))
			return
		clear()
		if _norm(target) == _norm(ROOT):
			control.execute('Container.Update(%s,replace)' % ROOT)
			return
		# history becomes: luc_kodi home -> target, so Back from target goes home
		control.execute('Container.Update(%s,replace)' % ROOT)
		_wait_for(ROOT)
		control.execute('Container.Update(%s)' % target)
	except Exception:
		from resources.lib.modules import log_utils
		log_utils.error()
