# -*- coding: utf-8 -*-
"""
	luc_kodi Add-on
	Context hub (v2.0.09): the plugin's own context panel.

	Every listing still builds its context options as a (label, builtin) list,
	exactly as before. attach_cm() decides how they reach the user:
	  - Modern (default): the list is stored on the ListItem as the property
	    'luc_kodi.cm'. Kodi's native menu then shows a single global entry
	    (addon.xml kodi.context.item -> resources/lib/contextitems/ctx_hub.py),
	    which opens the right-side panel (windows/context_hub.py) with the same
	    options grouped by what they do.
	  - Classic: item.addContextMenuItems(cm), the native Kodi menu as before.

	Because the panel is fed by the very same lists, every category,
	subcategory and item type keeps all of its options without a second copy
	of the builtins to maintain.
"""

import re
from json import dumps as jsdumps, loads as jsloads
from urllib.parse import unquote_plus, parse_qsl
from resources.lib.modules import control

PROP_CM = 'luc_kodi.cm'
PROP_PAYLOAD = 'luc_kodi.ctx.payload'
PROP_MODERN = 'luc_kodi.ctx.modern'
PROP_EXIT = 'luc_kodi.ctx.exit'
SYSADDON = 'plugin://plugin.video.luc_kodi/'

# group id -> (string id of the header, colour ARGB)
GROUPS = (
	('play', 48110, 'FF00B471'),
	('track', 48111, 'FF00C8FF'),
	('library', 48112, 'FFFDB515'),
	('discover', 48113, 'FFFF69B4'),
	('sources', 48114, 'FFFFAA44'),
	('cloud', 48115, 'FFAA78FF'),
	('more', 48116, 'FFB0B0D0'),
	('settings', 48117, 'FF00FA9A'),
)
_GROUP_COLOR = dict((g[0], g[2]) for g in GROUPS)
# per-service accents inside the Tracking group
_SERVICE_COLOR = {
	'tools_traktManager': 'FFED1C24', 'mdblist_Manager': 'FFAA78FF', 'simklManager': 'FF4FC3F7',
	'wetrakr_Manager': 'FF26C6DA', 'punchplay_Manager': 'FFFF7043',
}
# v2.0.09: service logos (resources/skins/Default/media/ctx/logo_*.png, made from resources/media/luc_kodi)
_LOGO_BY_ACTION = {
	'tools_traktManager': 'trakt', 'tools_likeList': 'trakt', 'tools_unlikeList': 'trakt',
	'mdblist_Manager': 'mdblist', 'simklManager': 'simkl', 'wetrakr_Manager': 'wetrakr',
	'punchplay_Manager': 'punchplay', 'play_Trailer': 'youtube',
}
_LOGO_BY_PREFIX = (('rd_', 'realdebrid'), ('ad_', 'alldebrid'), ('pm_', 'premiumize'), ('tb_', 'torbox'), ('en_', 'easynews'),
					('trakt_', 'trakt'), ('simkl_', 'simkl'), ('mdblist_', 'mdblist'), ('wetrakr_', 'wetrakr'), ('punchplay_', 'punchplay'))
CHEVRON = '\u00bb'  # Latin-1: the plugin has no fonts of its own, glyphs come from the skin
# actions that open another menu or dialog: shown with a chevron
_SUBMENU = ('Manager', 'rescrapeMenu', 'alterSources', 'premiereAdd', 'playlist_Manager')
_BBCODE = re.compile(r'\[/?(?:COLOR[^\]]*|B|I|UPPERCASE|LOWERCASE|CAPITALIZE|LIGHT|CR)\]', re.I)


def clean_label(label):
	try: return _BBCODE.sub('', str(label)).strip()
	except Exception: return str(label)


def is_modern():
	"""Window property set by the service (fast path); falls back to the setting."""
	val = control.homeWindow.getProperty(PROP_MODERN)
	if val in ('true', 'false'): return val == 'true'
	return control.setting('context.style') != '1'


def refresh_properties():
	"""Called by the service at start-up and on every settings change."""
	try:
		control.homeWindow.setProperty(PROP_MODERN, 'true' if control.setting('context.style') != '1' else 'false')
		control.homeWindow.setProperty(PROP_EXIT, 'true' if control.setting('context.exitlist') != 'false' else 'false')
		control.homeWindow.clearProperty('luc_kodi.search.index')  # v2.0.09: menus follow the settings
	except Exception:
		from resources.lib.modules import log_utils
		log_utils.error()


def attach_cm(item, cm):
	"""Replacement for item.addContextMenuItems(cm) in every listing."""
	if not cm: return
	try:
		if is_modern(): item.setProperty(PROP_CM, jsdumps(cm, separators=(',', ':')))
		else: item.addContextMenuItems(cm)
	except Exception:
		try: item.addContextMenuItems(cm)
		except Exception: pass


# ───────────────────────── classification ─────────────────────────
def _action_of(builtin):
	m = re.search(r'[?&]action=([A-Za-z0-9_]+)', builtin or '')
	return m.group(1) if m else ''


def classify(label, builtin):
	"""-> (group, icon name, hint) for one (label, builtin) entry."""
	b = builtin or ''
	act = _action_of(b)
	low = clean_label(label).lower()
	kind = b.split('(', 1)[0].strip()
	hint = CHEVRON if any(k in act for k in _SUBMENU) else ''

	if act == 'tools_openSettings' or act.startswith('tools_open'): return 'settings', 'gear', ''
	if act in ('play_Item',):
		if 'rescrape=true' in b: return 'sources', 'redo', hint
		return 'play', 'play', hint
	if act == 'play_Trailer': return 'play', 'film', hint
	if act == 'play_Random': return 'play', 'shuffle', hint
	if act == 'alterSources': return 'play', 'list', CHEVRON
	if act == 'rescrapeMenu': return 'sources', 'redo', CHEVRON
	if act.startswith('cache_clearSources'): return 'sources', 'trash', hint
	if act.startswith('playcount_'):
		return 'track', ('eye' if 'unwatch' in low or 'query=4' in b else 'check'), hint
	if act in _SERVICE_COLOR or act.endswith('Manager') and act != 'playlist_Manager':
		return 'track', 'check', CHEVRON
	if act in ('tools_likeList',): return 'track', 'heart', hint
	if act in ('tools_unlikeList',): return 'track', 'x', hint
	if act == 'reco_feedback':  # recommendations feedback: More like this / Not interested
		return ('discover', 'heart', hint) if 'signal=1' in b and 'signal=-1' not in b else ('discover', 'x', hint)
	if act.startswith('playlist_'):
		if act == 'playlist_Clear': return 'library', 'trash', hint
		if act == 'playlist_QueueItem': return 'library', 'queue', hint
		return 'library', 'list', hint
	if act.startswith('library_premiere'):
		if 'Delete' in act: return 'library', 'trash', hint
		if 'Rename' in act: return 'library', 'pencil', hint
		if 'Add' in act: return 'library', 'star', hint
		return 'library', 'redo', hint
	if act.startswith('library_'): return 'library', 'plus', hint
	if act == 'download' or act.startswith('download'): return 'cloud', 'download', hint
	if re.match(r'^(rd|ad|pm|tb|en)_', act):
		if 'Delete' in act or 'Clear' in act: return 'cloud', 'trash', hint
		if 'Rename' in act: return 'cloud', 'pencil', hint
		if 'Restart' in act: return 'cloud', 'redo', hint
		return 'cloud', 'cloud', hint
	if act.startswith('cache_clear') or act.endswith('clrProgressCache'): return 'more', 'trash', hint
	if kind in ('Container.Update', 'ActivateWindow'):
		if 'related' in b: return 'discover', 'spark', hint
		if act == 'collections': return 'discover', 'folder', hint
		return 'discover', 'folder', hint
	if kind == 'PlayMedia': return 'play', 'play', hint
	return 'more', 'dot', hint


def logo_for(builtin):
	act = _action_of(builtin)
	name = _LOGO_BY_ACTION.get(act)
	if not name:
		for prefix, logo in _LOGO_BY_PREFIX:
			if act.startswith(prefix): name = logo; break
	return ('ctx/logo_%s.png' % name) if name else ''


def build_entries(cm):
	"""Group the (label, builtin) list. Returns the action rows in GROUPS order;
	inside a group, the order the listing gave them. v2.0.09: no header rows any
	more (they were labels that looked like buttons) - the coloured tiles and the
	service logos already tell the groups apart."""
	buckets = dict((g[0], []) for g in GROUPS)
	seen = set()
	for entry in cm or []:
		try:
			label, builtin = entry[0], entry[1]
		except Exception:
			continue
		if not builtin or builtin in seen: continue
		seen.add(builtin)
		group, icon, hint = classify(label, builtin)
		color = _GROUP_COLOR.get(group, 'FFB0B0D0')
		act = _action_of(builtin)
		if group == 'track' and act in _SERVICE_COLOR: color = _SERVICE_COLOR[act]
		buckets[group].append({'kind': 'action', 'label': clean_label(label), 'builtin': builtin,
								'icon': 'ctx/ic_%s.png' % icon, 'color': color,
								'tile': '2E' + color[2:], 'hint': hint, 'logo': logo_for(builtin)})
	out = []
	for gid, sid, color in GROUPS:
		out.extend(buckets[gid])
	return out


# ───────────────────────── header (title, meta, chips) ─────────────────────────
def _fmt_runtime(seconds):
	try:
		m = int(float(seconds)) // 60
		if m <= 0: return ''
		return '%dh %02dm' % (m // 60, m % 60) if m >= 60 else '%dm' % m
	except Exception: return ''


def header_from_info(info):
	"""info: dict with any of title label year mediatype rating playcount duration
	tvshowtitle season episode poster resume total foldername folderpath."""
	getLS = control.lang
	info = info or {}
	mt = (info.get('mediatype') or '').lower()
	title = clean_label(info.get('title') or info.get('label') or '')
	year = str(info.get('year') or '')
	if year in ('0', 'None'): year = ''
	parts = []
	if mt == 'movie':
		parts = [getLS(48122), year, _fmt_runtime(info.get('duration'))]
	elif mt == 'tvshow':
		parts = [getLS(48123), year]
	elif mt == 'season':
		show = clean_label(info.get('tvshowtitle') or '')
		try: season_label = '%s %d' % (getLS(48124), int(info.get('season')))
		except Exception: season_label = getLS(48124)
		# v2.0.09: the title already says "Season 1", so the line names the show
		parts = [show, year] if title.lower().startswith(season_label.lower()) else [season_label, show]
	elif mt == 'episode':
		show = clean_label(info.get('tvshowtitle') or '')
		try: se = 'S%02dE%02d' % (int(info.get('season')), int(info.get('episode')))
		except Exception: se = getLS(48125)
		parts = [se, show, _fmt_runtime(info.get('duration'))]
	else:
		parts = [getLS(48126)]
	meta = '  ·  '.join([p for p in parts if p])
	rating = ''
	try:
		r = float(info.get('rating') or 0)
		if r > 0: rating = '%.1f' % r  # the chip draws its own star
	except Exception: pass
	watched = ''
	try:
		if int(info.get('playcount') or 0) > 0: watched = getLS(48121)
	except Exception: pass
	progress = ''
	try:
		resume, total = float(info.get('resume') or 0), float(info.get('total') or 0)
		if resume > 0 and total > 0: progress = '%s %d%%' % (getLS(48129), min(99, int(resume * 100 / total)))
	except Exception: pass
	# v2.0.09: titles keep the poster frame; menus show their icon whole (square, uncropped)
	artkind = 'poster' if mt in ('movie', 'tvshow', 'season', 'episode') else 'icon'
	return {'poster': info.get('poster') or '', 'artkind': artkind, 'title': title, 'meta': meta,
			'rating': rating, 'watched': watched, 'progress': progress}


def _crumb(folderpath, foldername):
	"""v2.0.09: inside a list, its name and page (Trending · Trakt  ·  page 8).
	In menus Kodi's folder name is just the add-on name, so nothing is shown."""
	name = ''
	try:
		from resources.lib.modules import navstate
		level, level_name = navstate.exit_level(folderpath)
		if level == 'list': name = level_name
		elif level == 'show':  # v2.0.09: Trending - Trakt  >>  Ted Lasso
			name = ('  %s  ' % CHEVRON).join([n for n in (navstate.list_name(), level_name) if n])
	except Exception: pass
	if not name: return ''
	page = ''
	try:
		flat = unquote_plus(unquote_plus(folderpath or ''))
		m = re.findall(r'[?&]page=(\d+)', flat)
		if m and int(m[-1]) > 1: page = control.lang(48127) % m[-1]
	except Exception: pass
	return '  ·  '.join([p for p in (name, page) if p])


# ───────────────────────── information view (v2.0.09) ─────────────────────────
MEDIA_TYPES = ('movie', 'tvshow', 'season', 'episode')


def _param_from_cm(cm, key):
	"""First value of a URL parameter (tmdb, imdb, season...) found in the item's
	own context builtins: every listing already puts the ids there."""
	for entry in cm or []:
		try:
			m = re.search(r'[?&]%s=([^&)]*)' % key, entry[1])
			if m and m.group(1) not in ('', 'None', 'none', '0'): return unquote_plus(m.group(1))
		except Exception: pass
	return ''


def _season_details(tmdb, season):
	"""TMDb /tv/{id}/season/{n}: name, overview, air date, episodes, rating."""
	try:
		from resources.lib.indexers.tmdb import TVshows
		api = TVshows()
		data = api.get_season_request(tmdb, season) or {}
		out = {'name': data.get('name') or '', 'overview': data.get('overview') or '',
			   'air_date': data.get('air_date') or '', 'episodes': len(data.get('episodes') or []),
			   'rating': data.get('vote_average') or 0}
		if not out['overview']:
			try: out['overview'] = api.get_en_overview(tmdb, season=season, level_type='season') or ''
			except Exception: pass
		return out
	except Exception:
		from resources.lib.modules import log_utils
		log_utils.error()
		return {}


def info_text(info, cm=None):
	"""Text for the panel's Information view."""
	getLS = control.lang
	info = info or {}
	mt = (info.get('mediatype') or '').lower()
	plot = clean_label(info.get('plot') or '')
	date = str(info.get('premiered') or '')[:10]
	rating = info.get('rating') or 0
	extra = []
	if mt == 'season':
		tmdb = str(info.get('tmdb') or _param_from_cm(cm, 'tmdb'))
		season = str(info.get('season') or _param_from_cm(cm, 'season'))
		if tmdb and season.isdigit():
			try:
				from resources.lib.database import cache
				d = cache.get(_season_details, 24, tmdb, season) or {}
			except Exception:
				d = _season_details(tmdb, season)
			plot = d.get('overview') or plot
			date = d.get('air_date') or date
			if d.get('rating'): rating = d['rating']
			if d.get('episodes'): extra.append(getLS(48137) % d['episodes'])
	details = []
	if date: details.append(getLS(48136) % date)
	details += extra
	try:
		if float(rating) > 0: details.append('%s %.1f' % (getLS(48138), float(rating)))
	except Exception: pass
	genre = info.get('genre') or ''
	if isinstance(genre, (list, tuple)): genre = ', '.join([g for g in genre if g])
	lines = []
	if details: lines.append('[COLOR FFB0B0D0]%s[/COLOR]' % '  ·  '.join(details))
	if genre: lines.append('[COLOR FFB0B0D0]%s[/COLOR]' % clean_label(genre))
	lines.append('')
	lines.append(plot or getLS(48139))
	return '[CR]'.join(lines)


# ───────────────────────── presentation ─────────────────────────
def _exits(folderpath, allow_exit):
	"""v2.0.09: Back (one step), Exit <subcategory> (leave the whole list), Home (luc_kodi main menu).
	Only in luc_kodi folders of the Videos window: not in widgets nor in the Bingie windows."""
	back = exit_label = home = ''
	if not allow_exit or not (folderpath or '').startswith(SYSADDON): return back, exit_label, home
	try:
		from resources.lib.modules import navstate
		at_root = navstate.is_root(folderpath)
		if not at_root:
			back, home = control.lang(48130), control.lang(48132)
		level, name = navstate.exit_level(folderpath)  # v2.0.09: Exit <show> inside its seasons/episodes
		if level:
			exit_label = (control.lang(48131) % name) if name else control.lang(48118)
	except Exception:
		from resources.lib.modules import log_utils
		log_utils.error()
	return back, exit_label, home


def show(cm, info=None, folderpath='', foldername='', allow_exit=True):
	"""Open the panel for a cm list. Runs the chosen builtin after the panel closes."""
	entries = build_entries(cm)
	if ((info or {}).get('mediatype') or '').lower() in MEDIA_TYPES:  # v2.0.09: Information view
		pos = 1 if entries and entries[0].get('icon') == 'ctx/ic_play.png' else 0
		entries.insert(pos, {'kind': 'action', 'label': control.lang(48134), 'builtin': '__info__',
							 'icon': 'ctx/ic_info.png', 'color': 'FF00C8FF', 'tile': '2E00C8FF', 'hint': '', 'logo': ''})
	back, exit_label, home = _exits(folderpath, allow_exit)
	if not entries and not (back or exit_label or home): return
	header = header_from_info(info)
	header['crumb'] = _crumb(folderpath, foldername)
	header['back'], header['exit'], header['home'] = back, exit_label, home
	try: header['version'] = 'v%s' % control.addon('plugin.video.luc_kodi').getAddonInfo('version')
	except Exception: header['version'] = ''
	chosen = None
	try:
		from resources.lib.windows.context_hub import ContextHubXML
		window = ContextHubXML('context_hub.xml', control.addonPath(control.addonId()), entries=entries, header=header,
							   info_loader=lambda: info_text(info, cm))
		chosen = window.run()
		del window
	except Exception:
		from resources.lib.modules import log_utils
		log_utils.error()
		# never leave the user without options: fall back to Kodi's own menu
		try:
			sel = control.dialog.contextmenu([e['label'] for e in entries if e['kind'] == 'action'])
			acts = [e for e in entries if e['kind'] == 'action']
			if sel is not None and 0 <= sel < len(acts): chosen = acts[sel]['builtin']
		except Exception: chosen = None
	if not chosen: return
	if chosen == '__search__':  # v2.0.09
		from resources.lib.modules import spotlight
		control.sleep(80)
		spotlight.open_search()
		return
	if chosen in ('__exit__', '__back__', '__home__'):
		from resources.lib.modules import navstate
		if chosen == '__exit__': navstate.exit_list()
		elif chosen == '__home__': navstate.go_home()
		else:
			control.sleep(80)
			control.execute('Action(Back)')
		return
	control.sleep(80)  # let the panel finish closing before the builtin takes focus
	control.execute(chosen)


def open_from_payload():
	"""Router action ctx_Hub: the global context item stored the focused item
	in a window property (resources/lib/contextitems/ctx_hub.py)."""
	raw = control.homeWindow.getProperty(PROP_PAYLOAD)
	control.homeWindow.clearProperty(PROP_PAYLOAD)
	try: data = jsloads(raw) if raw else {}
	except Exception: data = {}
	try: cm = jsloads(data.get('cm') or '[]')
	except Exception: cm = []
	# v2.0.09: a real Play entry for playable items (movies, episodes) - the same
	# URL Kodi opens when the item is clicked, so it follows the user's play mode
	path = data.get('path') or ''
	if data.get('playable') == 'true' and path.startswith(SYSADDON):
		cm = [(control.lang(48133), 'PlayMedia(%s)' % path)] + [c for c in cm if c[1] != 'PlayMedia(%s)' % path]
	show(cm, info=data, folderpath=data.get('folderpath', ''), foldername=data.get('foldername', ''),
		allow_exit=data.get('inVideos') == 'true')
