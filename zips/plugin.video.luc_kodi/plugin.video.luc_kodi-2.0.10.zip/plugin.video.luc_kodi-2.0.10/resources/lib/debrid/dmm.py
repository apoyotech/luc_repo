import threading, time
import requests


# ─────────────────────────────────────────────────────────────────────────────
# Token de DMM — v1.0.76
#
# Hasta el 31-ago-2026 el par (dmmProblemKey, solution) se calculaba EN EL
# CLIENTE, con un algoritmo y un salt que viajaban dentro del bundle del
# navegador, asi que cualquiera podia acuñarlo sin pedir permiso. Ese dia el
# proyecto lo movio al servidor:
#
#   dd6ff80  fix: sign availability tokens server-side instead of in the browser
#   cc24c36  fix: stop accepting the legacy client-signed availability token
#
# Ahora la firma es un HMAC-SHA256 con DMM_PROBLEM_SECRET, una variable de
# entorno que NUNCA sale del servidor (src/utils/problemToken.ts), y el periodo
# de gracia que aun aceptaba los tokens viejos se cerro el mismo dia. Por eso
# desde entonces TODA peticion del addon recibia 403 "Authentication error": no
# era un bloqueo a terceros ni un problema de red, era un algoritmo que ya no
# existe.
#
# La via soportada es pedir el token: GET /api/challenge devuelve {token, hash}
# y se envian como dmmProblemKey + solution. El propio cliente web hace esto
# (src/utils/token.ts) y cachea el par ~2 min frente a un TTL de servidor de 5,
# para que una peticion lenta nunca llegue con el token recien caducado. Aqui se
# replica ese margen exacto.
#
# El limitador tambien cambio (f2b90c9, 2-sep-2026): cada configuracion tiene ya
# su propio contador, asi que /api/challenge (bucket "default", 5/s por IP) NO
# gasta el presupuesto de /api/torrents (bucket "torrents", 1 cada 2 s). Pedir
# el token sale gratis para el scraper.
# ─────────────────────────────────────────────────────────────────────────────
_CHALLENGE_LINK = 'https://debridmediamanager.com/api/challenge'
_TOKEN_REUSE = 120.0   # el servidor lo acepta 300 s; se reutiliza solo 120
_TOKEN_TIMEOUT = 5.0   # acotado: el scraper tiene 7 s de presupuesto propio

_TOKEN_LOCK = threading.Lock()
_TOKEN = {'key': None, 'solution': None, 'expires': 0.0}


def get_secret():
	"""Devuelve (dmmProblemKey, solution) o (None, None) si no se puede acuñar.

	El candado se sostiene durante la peticion a proposito: es el equivalente al
	"in-flight sharing" del cliente web. Varias comprobaciones de cache arrancan
	a la vez y deben costar UN token, no uno por hilo."""
	from resources.lib.modules import log_utils
	with _TOKEN_LOCK:
		if _TOKEN['key'] and time.time() < _TOKEN['expires']:
			return _TOKEN['key'], _TOKEN['solution']
		try:
			response = requests.get(_CHALLENGE_LINK, headers={'Accept': 'application/json'}, timeout=_TOKEN_TIMEOUT)
		except requests.exceptions.RequestException as e:
			log_utils.log('DMM: no se pudo pedir el token (%s: %s)' % (type(e).__name__, e), __name__, log_utils.LOGDEBUG)
			return None, None
		if response.status_code != 200:
			# 500 = el servidor no tiene DMM_PROBLEM_SECRET configurado y no
			# valida NADA; 429 = se pidieron mas de 5 tokens en un segundo.
			log_utils.log('DMM: /api/challenge devolvio HTTP %s' % response.status_code, __name__, log_utils.LOGWARNING)
			return None, None
		try: payload = response.json()
		except Exception: payload = None
		token = payload.get('token') if isinstance(payload, dict) else None
		solution = payload.get('hash') if isinstance(payload, dict) else None
		if not isinstance(token, str) or not isinstance(solution, str) or not token or not solution:
			log_utils.log('DMM: /api/challenge respondio 200 sin las claves "token"/"hash"', __name__, log_utils.LOGWARNING)
			return None, None
		_TOKEN['key'], _TOKEN['solution'] = token, solution
		_TOKEN['expires'] = time.time() + _TOKEN_REUSE
		return token, solution


def invalidate_secret(stale_key=None):
	"""Tira el token cacheado tras un 403.

	Se pasa el token que fallo para no tirar uno recien acuñado por un hilo
	hermano: si dos hilos comen el mismo 403, solo el primero fuerza el
	reacuñado y el segundo se encuentra el nuevo ya puesto."""
	with _TOKEN_LOCK:
		if stale_key and _TOKEN['key'] != stale_key: return False
		_TOKEN['key'], _TOKEN['solution'], _TOKEN['expires'] = None, None, 0.0
		return True


class DMMCache:
	"""Cache de Real-Debrid que DMM ha visto — v2.0.10.

	El 15-oct-2026 DMM cerro /api/availability/check a todo lo que no sea su
	propia web (commit b49f6307, src/utils/ownPageRequest.ts): exige la cabecera
	Sec-Fetch-Site: same-origin que solo pone un navegador, y a cualquier otro
	cliente le responde 403 "This endpoint serves DMM pages only. Tools use the
	sponsor API". El commit cita expresamente python-requests, que es lo que
	usaba esto. No se falsea esa cabecera: es un cierre deliberado y DMM vende
	ese mismo dato en su API de patrocinadores.

	Desde entonces luc_kodi solo pregunta a DMM si el usuario ha puesto SU clave
	de patrocinador (Accounts > Real-Debrid > DMM API key). Sin clave no se
	hace ninguna peticion y sources.py marca los torrents de RD como
	"unchecked": el propio resolve_magnet de Real-Debrid hace de comprobacion
	al reproducir (anade, mira si esta "ended" en 1,5 s y si no lo borra), y la
	reproduccion pasa a la siguiente fuente.

	check_cache devuelve un dict {hash: ficheros} cuando DMM contesto (vacio =
	no ha visto ninguno cacheado) y None cuando no se le pudo preguntar. Los dos
	casos son distintos y sources.py los trata distinto."""
	sponsor_link = 'https://debridmediamanager.com/api/sponsor/availability'
	timeout = 6.05
	_REFUSED_PROP = 'luc_kodi.dmm_key_refused'

	@staticmethod
	def api_key():
		try:
			from resources.lib.modules.control import setting as getSetting
			return (getSetting('dmm.api_key') or '').strip()
		except Exception:
			return ''

	def _key_refused(self, status, body):
		"""Clave mala o patrocinio caducado: log siempre, aviso al usuario una
		vez por sesion de Kodi para no repetirlo en cada episodio."""
		from resources.lib.modules import control, log_utils
		log_utils.log('DMM sponsor availability: la clave fue rechazada (HTTP %s) | body[:300]=%r' % (status, body), __name__, log_utils.LOGWARNING)
		try:
			if control.homeWindow.getProperty(self._REFUSED_PROP) != 'true':
				control.homeWindow.setProperty(self._REFUSED_PROP, 'true')
				control.notification(message=48148)
		except Exception:
			pass

	def check_cache(self, unchecked_hashes_chunk, imdb): # Sponsor API: max 100 hashes per request, 25 calls/min per address.
		from resources.lib.modules import log_utils
		key = self.api_key()
		if not key: return None
		hashes = [i.lower() for i in unchecked_hashes_chunk if len(i) == 40]
		if not hashes: return {}
		data = {'service': 'rd', 'hashes': hashes}
		# imdbId es opcional en la API de patrocinadores y acota la respuesta a
		# ese titulo. Si no tiene la forma que exige (/^tt\d+$/) daria 400, asi
		# que entonces se pregunta solo por los hashes.
		if imdb and str(imdb).startswith('tt') and str(imdb)[2:].isdigit():
			data['imdbId'] = str(imdb)
		headers = {'x-api-key': key, 'Accept': 'application/json'}
		try: results = requests.post(self.sponsor_link, json=data, headers=headers, timeout=self.timeout)
		except requests.exceptions.RequestException as e:
			log_utils.log('DMM sponsor availability: fallo de red (%s: %s)' % (type(e).__name__, e), __name__, log_utils.LOGDEBUG)
			return None
		status = results.status_code
		body = (results.text or '')[:300].replace('\n', ' ').replace('\r', ' ')
		if status in (401, 403):
			self._key_refused(status, body)
			return None
		try: payload = results.json()
		except Exception: payload = None
		available_hashes = payload.get('available') if isinstance(payload, dict) else None
		if status != 200 or available_hashes is None:
			# 429 = mas de 25 llamadas por minuto desde esta IP; cualquier otra
			# cosa es una anomalia del servidor. En los dos casos el lote queda
			# "unchecked", no se pierde.
			level = log_utils.LOGDEBUG if status == 429 else log_utils.LOGWARNING
			log_utils.log('DMM sponsor availability: HTTP %s | Content-Type=%s | body[:300]=%r'
					% (status, results.headers.get('Content-Type', ''), body), __name__, level)
			return None
		try: return {file['hash'].lower(): file['files'] for file in available_hashes if 'hash' in file}
		except Exception:
			log_utils.log('DMM sponsor availability: respuesta con forma inesperada en "available"', __name__, log_utils.LOGWARNING)
			return None
