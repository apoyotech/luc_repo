# -*- coding: utf-8 -*-
"""
	luc_kodi Add-on — trailer_httpd.py (v1.0.57)

	Micro-servidor HTTP en 127.0.0.1 que sirve a inputstream.adaptive tanto el
	manifest DASH de los tráilers como sus segmentos de vídeo y audio.

	Por qué el manifest (desde v1.0.49):
	  el descargador de ISA (pila CURL) no entiende rutas special:// ni ficheros
	  locales, así que el MPD tiene que viajar por HTTP.

	Por qué también los segmentos (nuevo en v1.0.57):
	  googlevideo limita cuánto se puede descargar por delante del punto de
	  reproducción. ISA rellena su buffer a toda velocidad, y en un dispositivo
	  con enlace rápido (NVIDIA Shield por Ethernet: ISA midió 133-176 Mbit/s en
	  el log del 14-08) el stream de AUDIO se planta en ~60 s de adelanto en
	  milisegundos y Google responde HTTP 403 a la siguiente petición. ISA
	  reintenta solo 6 veces en ~3 s, se rinde, y el hilo de audio se queda seco:
	    CDVDAudio::AddPacketsRenderer - timeout adding data to renderer
	    Flush - timed out waiting for renderer to flush
	  Eso es el bloqueo. El 403 NO es permanente: la ventana de Google se abre
	  sola según avanza la reproducción (en el log el vídeo se reanudaba a los
	  8 s con la misma URL firmada). Al pasar los segmentos por este proxy,
	  reintentamos con backoff hasta que se abre y ISA nunca ve el error.

	Diseño:
	- Contenido del MPD en la window property luc_kodi.trailer_mpd.
	- Mapa {itag: URL de googlevideo} + User-Agent del cliente InnerTube en la
	  window property luc_kodi.trailer_streams (JSON). Así el MPD queda pequeño
	  (las URLs firmadas de googlevideo pasan de 700 chars cada una) y las URLs
	  no viajan por la query string.
	- Rutas: GET/HEAD /trailer.mpd y GET/HEAD /s/<itag>. Todo lo demás 404.
	- Bind exclusivo a 127.0.0.1. Sin logging por petición.
	- Puerto: primero libre del rango 48996-49005, publicado en
	  luc_kodi.trailer_httpd_port.
	- Arranca desde service.py (hilo daemon). yt_resolver tiene además un
	  arranque efímero de emergencia por si la property del puerto no existiera.
"""

import json
import threading
import time
import http.server
import socketserver
from urllib.request import Request, urlopen
from urllib.error import HTTPError, URLError

from resources.lib.modules import control
from resources.lib.modules import log_utils

LOGINFO = log_utils.LOGINFO
LOGDEBUG = log_utils.LOGDEBUG

PROP_CONTENT = 'luc_kodi.trailer_mpd'
PROP_STREAMS = 'luc_kodi.trailer_streams'
PROP_PORT = 'luc_kodi.trailer_httpd_port'
PORT_RANGE = range(48996, 49006)

SEG_PATH = '/s/'

# Backoff ante el throttle de googlevideo. La pausa observada en el log era de
# ~8 s (el vídeo se reanudaba solo con la misma URL firmada), así que el
# presupuesto de 14 s la cubre. Es un tope de RELOJ, no la suma de las esperas:
# la pila CURL de Kodi corta una descarga sin avance a los 20 s (curllowspeedtime),
# y hay que quedarse por debajo pase lo que pase.
# Si aun así se agota, se devuelve el error a ISA, que reintenta por su cuenta
# 6 veces — y cada uno de esos reintentos vuelve a entrar aquí con presupuesto
# nuevo, así que el aguante real ronda el minuto y medio.
# Menos intentos y más espaciados que en 1.0.57: en el log del 14-08 (01:20)
# se agotaron 16 presupuestos, a 8 peticiones cada uno, martilleando a
# googlevideo mientras ya estaba rechazando. Misma ventana, 6 peticiones.
_RETRY_DELAYS = (1.0, 2.0, 3.0, 4.0, 4.0)
_RETRY_BUDGET = 14.0
_RETRY_STATUS = (403, 429, 500, 502, 503, 504)
_UPSTREAM_TIMEOUT = 10
_CHUNK = 65536

# ── Ritmo de entrega (v1.0.58) ────────────────────────────────────────────
# El proxy de la 1.0.57 aguantaba el rechazo de googlevideo, pero seguía
# tropezando con él. Google limita cuánto se puede descargar POR DELANTE del
# punto de reproducción, y en el log del 14-08 esa ventana se estrechó de ~123 s
# de audio (00:51) a ~54 s (01:24) para la misma IP, el mismo vídeo y el mismo
# itag. Aguantar más no es la solución: la solución es no adelantarse tanto.
#
# Aquí se mide la ENTREGA del cuerpo, no la espera antes de pedir. Así los bytes
# fluyen sin parar y la pila CURL de Kodi nunca ve una conexión muda (su
# curllowspeedtime son 20 s), que es lo que impedía hacer esto con una espera
# seca. Es lo mismo que hace la app oficial de YouTube: pedir a ritmo.
#
# La posición dentro del medio se deduce del Range y del bitrate declarado en el
# MPD, que yt_resolver publica junto a las URLs. Se permite un adelanto de
# _PACE_LEAD segundos (arranque instantáneo hasta ahí) y a partir de ese punto
# se entrega a ritmo de reproducción.
# El freno se reparte en DOS tramos, y el orden importa: el límite de Google se
# aplica a CUÁNDO PIDES, no a cuándo entregas, así que la mayor parte tiene que
# ser espera antes de salir a googlevideo. Pero durante esa espera la conexión
# con ISA está muda, y la pila CURL de Kodi corta a los 20 s (curllowspeedtime),
# así que va acotada; lo que sobre se toma repartiendo el cuerpo, que mantiene
# los bytes fluyendo y no cuenta como conexión muda.
# v1.0.59 — el colchón se AJUSTA SOLO. La ventana que concede Google no es un
# número fijo: en los logs del 14-08 pasó de ~123 s a ~54 s y de ahí a menos de
# 40 s en cuestión de horas, así que fijar una constante es perder siempre.
# Esquema clásico de control de congestión: se recorta a la mitad ante cada
# rechazo y se recupera de segundo en segundo mientras todo va bien, así el
# colchón converge al valor que Google esté concediendo y vuelve a crecer
# cuando afloja.
_PACE_LEAD = 30.0        # colchón inicial y máximo, por delante de la reproducción
_PACE_LEAD_MIN = 8.0     # suelo: por debajo el búfer se queda demasiado fino
_PACE_LEAD_RECOVER = 1.0 # se gana por cada segmento servido sin un solo rechazo
_PACE_MAX_WAIT = 10.0    # tope de espera ANTES de pedir (silencio hacia ISA)
_PACE_MAX_SPREAD = 15.0  # tope de reparto del cuerpo de un solo segmento
_PACE_SEEK_TOL = 10.0    # si piden algo muy anterior, es un salto: se rebasa el origen
# v1.0.62 — la marca por URL guarda el INICIO del último tramo pedido, no su
# final. Guardaba el final, y así un REINTENTO del mismo segmento (mismo tramo,
# porque googlevideo lo había rechazado) parecía un salto hacia atrás en cuanto
# el segmento duraba más que la tolerancia — el audio venía en tramos de 10-11 s.
# Consecuencia en el log del 15-08: cada rechazo rebasaba el origen y devolvía el
# colchón a 30 s, así que se veía 30->15, 30->15, 30->15 sin asentarse nunca.
# Con el inicio, un reintento da exactamente la misma posición y no es un salto.
_PACE_CAP = 64
# Silencio total tolerable hacia ISA: espera previa + reintentos. Por debajo de
# los 20 s de curllowspeedtime pase lo que pase.
_SILENCE_CAP = 17.0

_pace_lock = threading.Lock()
# v1.0.61 — el estado va por TRÁILER (token 'g' que publica yt_resolver), no por
# URL. Iba por URL y eso rompía en cuanto ISA cambiaba de representación: el itag
# nuevo estrenaba línea de tiempo desde cero mientras la reproducción ya iba por
# el segundo 100, así que el freno lo creía 100 s adelantado y le clavaba el tope
# de 25 s a cada segmento, para siempre. En el log del 15-08 el vídeo acabó 40 s
# por detrás del audio. Audio y vídeo comparten línea de tiempo, así que compartir
# origen es además lo correcto.
_pace = {}        # gen -> {'t0', 'base', 'lead'}
_pace_last = {}   # url -> última posición pedida (solo para detectar saltos)


def _range_bytes(rng):
	"""(inicio, fin) de una cabecera Range de un solo tramo, o (None, None)."""
	try:
		lo, _, hi = (rng or '').split('=')[1].partition('-')
		return int(lo), (int(hi) if hi else None)
	except (IndexError, ValueError, AttributeError):
		return None, None


def _pace_plan(gen, url, key, bps, rng):
	"""(espera antes de pedir, segundos de reparto del cuerpo). (0, 0) = a tope.
	bps = bytes por segundo REALES del formato, publicados por yt_resolver. En
	v1.0.58 se usaba el 'bitrate' del MPD, que en YouTube es el pico: con vídeo
	VBR eso subestimaba la posición hasta 29 s y el freno no entraba nunca en las
	pistas de vídeo, que eran justo las que primero recibían el 403."""
	try:
		bps = float(bps or 0)
	except (TypeError, ValueError):
		bps = 0.0
	start, end = _range_bytes(rng)
	if bps <= 0 or start is None:
		return 0.0, 0.0  # sin datos para calcular: no se frena nada
	pos_start = start / bps
	pos_end = ((end + 1) / bps) if end is not None else pos_start
	now = time.monotonic()
	with _pace_lock:
		st = _pace.get(gen)
		seen = _pace_last.get(url)
		# Origen nuevo solo en dos casos: primer segmento del tráiler, o salto
		# hacia atrás DENTRO de la misma pista. Un itag que aparece por primera
		# vez (cambio de representación) hereda el origen: no es un salto.
		if st is None or (seen is not None and pos_start < seen - _PACE_SEEK_TOL):
			if len(_pace) > _PACE_CAP: _pace.clear()
			if len(_pace_last) > _PACE_CAP * 4: _pace_last.clear()
			# v1.0.62: el colchón aprendido SOBREVIVE al rebase. Es una propiedad
			# de lo que concede Google en ese momento, no de la línea de tiempo:
			# saltar dentro del tráiler no cambia el margen que hay disponible.
			st = {'t0': now, 'base': pos_start, 'lead': (st or {}).get('lead', _PACE_LEAD)}
			_pace[gen] = st
		_pace_last[url] = pos_start
		lead = st['lead']
		# instante en que esta posición deja de ir demasiado adelantada
		target = st['t0'] + (pos_end - st['base']) - lead
	late = max(0.0, target - now)
	wait = min(late, _PACE_MAX_WAIT)
	spread = min(late - wait, _PACE_MAX_SPREAD)
	if late > 0.5:
		control.log('[ luc_kodi ] trailer_httpd: itag %s paced +%.1fs (%.1fs before request, %.1fs spread; media position %.0fs, lead %.0fs)'
					% (key, wait + spread, wait, spread, pos_end, lead), LOGDEBUG)
	return wait, spread


def _pace_feedback(gen, key, refused):
	"""Ajusta el colchón: a la mitad si hubo rechazo, +1 s por cada entrega
	limpia. Converge solo al margen que Google esté concediendo en cada momento."""
	with _pace_lock:
		st = _pace.get(gen)
		if not st: return
		before = st['lead']
		if refused:
			st['lead'] = max(_PACE_LEAD_MIN, before / 2.0)
		else:
			st['lead'] = min(_PACE_LEAD, before + _PACE_LEAD_RECOVER)
		after = st['lead']
	if refused and after < before:
		control.log('[ luc_kodi ] trailer_httpd: itag %s lead tightened %.0fs -> %.0fs after refusal'
					% (key, before, after), LOGINFO)


# ── Refresco de URLs (v1.0.63) ────────────────────────────────────────────
# El ritmo evita tropezar con el límite de adelanto, pero no con el otro: cada
# URL firmada sirve un tramo del fichero y luego responde 403 para siempre. Un
# resolve nuevo devuelve URLs nuevas y el contador se reinicia. Aquí se hace
# solo, sin que ISA se entere: mismo itag, mismo fichero, mismos rangos.
_REFRESH_COOLDOWN = 8.0   # las dos pistas chocan con el muro con segundos de diferencia
_REFRESH_MAX = 8          # tope por tráiler, para no entrar en bucle
_refresh_lock = threading.Lock()
_refresh_state = {}       # gen -> {'at': monotonic, 'n': int}


def _refresh(gen, streams, key):
	"""Pide URLs nuevas y las publica. True si la del itag `key` cambió.
	Serializado: si la otra pista acaba de refrescar, esta reutiliza el
	resultado en vez de volver a resolver."""
	url_before = (streams.get('u') or {}).get(key)
	with _refresh_lock:
		st = _refresh_state.get(gen) or {'at': 0.0, 'n': 0}
		if time.monotonic() - st['at'] < _REFRESH_COOLDOWN:
			# otra pista acaba de refrescar: mirar si ya hay URL nueva
			return (_streams().get('u') or {}).get(key) not in (None, url_before)
		if st['n'] >= _REFRESH_MAX:
			return False
		video_id, client = streams.get('v') or '', streams.get('c') or ''
		if not video_id: return False
		st = {'at': time.monotonic(), 'n': st['n'] + 1}
		_refresh_state[gen] = st
		if len(_refresh_state) > _PACE_CAP: 
			for k in list(_refresh_state)[:-1]:
				if k != gen: _refresh_state.pop(k, None)

	try:
		from resources.lib.modules import yt_resolver
		fresh = yt_resolver.refresh_urls(video_id, client, list((streams.get('u') or {}).keys()))
	except Exception:
		log_utils.error()
		fresh = None
	if not fresh:
		control.log('[ luc_kodi ] trailer_httpd: url refresh failed for %s (attempt %s)' % (video_id, st['n']), LOGINFO)
		return False

	with _refresh_lock:
		cur = _streams()
		if (cur.get('g') or '') != gen: return False   # ya se reproduce otro tráiler
		cur.setdefault('u', {}).update(fresh)
		try: control.homeWindow.setProperty(PROP_STREAMS, json.dumps(cur))
		except Exception:
			log_utils.error()
			return False
	control.log('[ luc_kodi ] trailer_httpd: refreshed signed urls for %s (attempt %s/%s)'
				% (video_id, st['n'], _REFRESH_MAX), LOGINFO)
	return fresh.get(key) != url_before


# ── Corte limpio cuando el stream está realmente muerto (v1.0.65) ─────────
# Cuando YouTube deja de servir a mitad de tráiler, ISA NO aborta: se queda
# parado con el stream seco, y el usuario ve una imagen congelada y tiene que
# pulsar stop él mismo (en los logs, entre 20 y 36 s después). Contra el límite
# no podemos hacer nada, pero contra eso sí: se corta la reproducción y se dice
# la verdad en un aviso. El mando vuelve a sus manos en segundos.
_DEAD_GIVEUPS = 3        # abandonos seguidos del mismo tráiler antes de rendirse
_DEAD_CAP = 32
_dead_lock = threading.Lock()
_dead = {}               # gen -> {'n': int, 'done': bool}


def _stream_dead(gen, key):
	"""Cuenta abandonos del tráiler y, pasado el umbral, para y avisa."""
	with _dead_lock:
		if len(_dead) > _DEAD_CAP:
			for k in list(_dead):
				if k != gen: _dead.pop(k, None)
		st = _dead.setdefault(gen, {'n': 0, 'done': False})
		if st['done']: return
		st['n'] += 1
		if st['n'] < _DEAD_GIVEUPS: return
		st['done'] = True

	try:
		# Solo si lo que está sonando es NUESTRO tráiler: nunca se para otra cosa
		if not control.player.isPlayingVideo(): return
		playing = control.player.getPlayingFile() or ''
		if '/trailer.mpd' not in playing: return
		control.log('[ luc_kodi ] trailer_httpd: stream dead on itag %s after %s give-ups — stopping playback'
					% (key, st['n']), LOGINFO)
		control.notification(title='Trailer', message=_DEAD_MESSAGE, time=5000)
		control.player.stop()
	except Exception:
		log_utils.error()


_DEAD_MESSAGE = 'YouTube is limiting trailer playback right now. Try again in a while.'


_started_lock = threading.Lock()
_started = [False]


def _streams():
	try: return json.loads(control.homeWindow.getProperty(PROP_STREAMS) or '{}')
	except Exception: return {}


class _Handler(http.server.BaseHTTPRequestHandler):
	protocol_version = 'HTTP/1.1'

	# ── utilidades ────────────────────────────────────────────────────
	def _fail(self, code):
		self.send_response(code)
		self.send_header('Content-Length', '0')
		self.end_headers()

	def log_message(self, *args):
		pass  # sin ruido en el log de Kodi

	# ── entradas ──────────────────────────────────────────────────────
	def do_GET(self):
		self._route(with_body=True)

	def do_HEAD(self):
		self._route(with_body=False)

	def _route(self, with_body):
		path = self.path.split('?')[0]
		if path == '/trailer.mpd':
			self._serve_mpd(with_body)
		elif path.startswith(SEG_PATH):
			self._serve_segment(path[len(SEG_PATH):], with_body)
		else:
			self._fail(404)

	# ── manifest ──────────────────────────────────────────────────────
	def _serve_mpd(self, with_body):
		try: content = control.homeWindow.getProperty(PROP_CONTENT) or ''
		except Exception: content = ''
		data = content.encode('utf-8')
		if not data:
			self._fail(404)
			return
		self.send_response(200)
		self.send_header('Content-Type', 'application/dash+xml')
		self.send_header('Content-Length', str(len(data)))
		self.end_headers()
		if with_body:
			try: self.wfile.write(data)
			except Exception: pass

	# ── segmentos (proxy con reintentos) ──────────────────────────────
	def _serve_segment(self, key, with_body):
		streams = _streams()
		url = (streams.get('u') or {}).get(key)
		if not url:
			self._fail(404)
			return
		ua = streams.get('ua') or ''
		rng = self.headers.get('Range')

		gen = streams.get('g') or ''
		wait, spread = _pace_plan(gen, url, key, (streams.get('b') or {}).get(key), rng)
		if wait and control.monitor.waitForAbort(wait):
			self._fail(503)
			return

		# lo que ya se gastó callado se descuenta del margen de reintentos
		resp, status, refused = self._upstream(url, ua, rng, key, max(4.0, _SILENCE_CAP - wait))
		_pace_feedback(gen, key, refused)
		if resp is not None:
			with _dead_lock:
				st = _dead.get(gen)
				if st and not st['done']: st['n'] = 0

		if resp is None and status == 403 and _refresh(gen, streams, key):
			# llave nueva: mismo fichero y mismo rango, así que se reintenta ya
			url = (_streams().get('u') or {}).get(key) or url
			resp, status, refused = self._upstream(url, ua, rng, key, max(4.0, _SILENCE_CAP - wait))

		if resp is None:
			control.log('[ luc_kodi ] trailer_httpd: upstream gave up on itag %s (last status %s)' % (key, status), LOGINFO)
			_stream_dead(gen, key)
			self._fail(status if isinstance(status, int) and 400 <= status < 600 else 502)
			return

		try:
			code = resp.getcode() or 200
			length = resp.headers.get('Content-Length')
			self.send_response(code)
			for h in ('Content-Type', 'Content-Range', 'Accept-Ranges'):
				v = resp.headers.get(h)
				if v: self.send_header(h, v)
			if length is not None:
				self.send_header('Content-Length', length)
			else:
				# sin longitud no podemos mantener keep-alive con seguridad
				self.send_header('Connection', 'close')
				self.close_connection = True
			self.end_headers()
			if with_body:
				total = int(length) if length is not None else 0
				t0 = time.monotonic()
				sent = 0
				while True:
					chunk = resp.read(_CHUNK)
					if not chunk: break
					self.wfile.write(chunk)
					sent += len(chunk)
					if spread and total:
						# se reparte proporcionalmente: el segmento acaba de llegar
						# justo cuando toca, y entretanto los bytes no dejan de fluir
						due = t0 + spread * (float(sent) / total) - time.monotonic()
						if due > 0 and control.monitor.waitForAbort(min(due, 1.0)): break
		except Exception:
			# cliente cerró (ISA cambia de representación o para) — no es un fallo
			self.close_connection = True
		finally:
			try: resp.close()
			except Exception: pass

	def _upstream(self, url, ua, rng, key='', budget=_RETRY_BUDGET):
		"""Devuelve (respuesta, status). Reintenta el throttle de googlevideo
		hasta agotar el presupuesto de reloj."""
		deadline = time.monotonic() + budget
		started = time.monotonic()
		absorbed = 0
		last = 0
		for attempt in range(len(_RETRY_DELAYS) + 1):
			req = Request(url)
			if ua: req.add_header('User-Agent', ua)
			if rng: req.add_header('Range', rng)
			resp = None
			try:
				timeout = min(_UPSTREAM_TIMEOUT, max(1.0, deadline - time.monotonic()))
				resp = urlopen(req, timeout=timeout)
			except HTTPError as e:
				last = e.code
				try: e.close()
				except Exception: pass
				if e.code not in _RETRY_STATUS: return None, last, True
				absorbed += 1
			except URLError:
				last = 502
				absorbed += 1
			except Exception:
				log_utils.error()
				return None, 502, absorbed > 0
			if resp is not None:
				# El log va FUERA del try: si fallara, no debe tumbar la descarga
				# que acabamos de conseguir. v1.0.58: hasta ahora esto era
				# invisible y no había forma de saber cuánto trabajaba el proxy
				# en las reproducciones que salían bien.
				if absorbed:
					try:
						control.log('[ luc_kodi ] trailer_httpd: itag %s recovered after %s refusal(s) in %.1fs (last status %s)'
									% (key, absorbed, time.monotonic() - started, last), LOGDEBUG)
					except Exception: pass
				return resp, 200, absorbed > 0
			if attempt >= len(_RETRY_DELAYS): break
			wait = min(_RETRY_DELAYS[attempt], deadline - time.monotonic())
			if wait <= 0: break
			if control.monitor.waitForAbort(wait): return None, last, True
		return None, last, True


class _Server(socketserver.ThreadingTCPServer):
	allow_reuse_address = True
	daemon_threads = True


def start():
	"""Arranca el servidor en un hilo daemon. Idempotente dentro del mismo
	proceso; entre procesos, el bind exclusivo del puerto hace de guardia."""
	with _started_lock:
		if _started[0]: return
		_started[0] = True
	worker = threading.Thread(target=_serve)
	worker.daemon = True
	worker.start()


def _serve():
	for port in PORT_RANGE:
		try:
			server = _Server(('127.0.0.1', port), _Handler)
		except OSError:
			continue
		try:
			control.homeWindow.setProperty(PROP_PORT, str(port))
			control.log('[ luc_kodi ] trailer_httpd: serving on 127.0.0.1:%s' % port, LOGINFO)
			server.serve_forever(poll_interval=1.0)
		except Exception:
			log_utils.error()
		finally:
			try: server.server_close()
			except Exception: pass
		return
	control.log('[ luc_kodi ] trailer_httpd: no free port in %s-%s' % (PORT_RANGE.start, PORT_RANGE.stop - 1), LOGINFO)
	with _started_lock:
		_started[0] = False
