# -*- coding: utf-8 -*-
"""
	luc_kodi Add-on — trailer_probe.py (v1.0.64)

	Diagnóstico de una sola pasada para saber HASTA DÓNDE deja leer googlevideo.

	Por qué existe: desde el log del 15-ago está claro que el corte no es del
	addon. Mismo vídeo, mismos números con y sin proxy, con y sin ritmo, con y
	sin refresco de URL, y con `trailer.py`/`trailer_httpd.py` idénticos byte a
	byte desde la v1.0.43: siempre 6 segmentos de audio (0,97 MB) y ~12,5 MB de
	vídeo, o sea el primer minuto largo y ni un byte más. Refrescar la firma no
	amplía nada, así que el tope va por posición dentro del fichero, no por URL.

	Lo que hace falta saber ahora es si ALGÚN cliente de InnerTube, o el
	progresivo, sigue entregando el fichero entero. Eso no se adivina: se mide.
	Esta sonda resuelve el mismo vídeo con cada cliente y, para cada formato,
	pide tres tramos sueltos — al principio, pasado el minuto y al final — y
	anota qué responde googlevideo en cada uno. El resultado va al log y a un
	diálogo. Una ejecución y sabemos contra qué estamos jugando.
"""

import json
from urllib.request import Request, urlopen
from urllib.error import HTTPError, URLError

from resources.lib.modules import control
from resources.lib.modules import log_utils
from resources.lib.modules import yt_resolver

LOGINFO = log_utils.LOGINFO

# Tráiler de prueba por defecto: uno de los que fallan en su log.
DEFAULT_VIDEO = '3oB9AxspVow'
PROBE_AT = (5.0, 75.0, 0.0)   # segundos dentro del medio; 0.0 = el final
PROBE_BYTES = 65536
TIMEOUT = 15


def _probe_range(url, ua, start, length):
	"""Devuelve el código HTTP de una petición por rango, o el motivo del fallo."""
	req = Request(url)
	if ua: req.add_header('User-Agent', ua)
	req.add_header('Range', 'bytes=%d-%d' % (start, start + length - 1))
	try:
		resp = urlopen(req, timeout=TIMEOUT)
		code = resp.getcode() or 200
		try: n = len(resp.read())
		finally: resp.close()
		return code, n
	except HTTPError as e:
		try: e.close()
		except Exception: pass
		return e.code, 0
	except URLError:
		return 0, 0
	except Exception:
		log_utils.error()
		return -1, 0


def _probe_format(f, ua):
	"""Sondea inicio, pasado el minuto y final de un formato."""
	url = f.get('url')
	if not url: return None
	bps = yt_resolver._bytes_per_second(f)
	try: clen = int(f.get('contentLength') or 0)
	except (TypeError, ValueError): clen = 0
	if not clen: return None
	out = []
	for at in PROBE_AT:
		if at == 0.0:
			start = max(0, clen - PROBE_BYTES)
			label = 'final'
		else:
			start = int(at * bps) if bps else 0
			label = '%.0fs' % at
			if start + PROBE_BYTES >= clen:
				out.append((label, 'n/d'))
				continue
		code, n = _probe_range(url, ua, start, PROBE_BYTES)
		out.append((label, '%s' % code if code != 200 and code != 206 else 'OK'))
	return out


def run(video_id=None):
	video_id = video_id or DEFAULT_VIDEO
	lines = ['[ luc_kodi ] trailer_probe: %s' % video_id]
	summary = []
	visitor = yt_resolver._get_visitor_data()

	for spec in yt_resolver._CLIENTS:
		label = spec['label']
		data = yt_resolver._innertube_player(video_id, spec, visitor_data=visitor)
		if not data:
			lines.append('  %-16s sin respuesta' % label)
			summary.append('%s: sin respuesta' % label)
			continue
		fresh = yt_resolver._response_visitor_data(data)
		if fresh and fresh != visitor:
			yt_resolver._set_visitor_data(fresh)
			visitor = fresh
		status = (data.get('playabilityStatus') or {}).get('status')
		if status != 'OK':
			lines.append('  %-16s %s' % (label, status))
			summary.append('%s: %s' % (label, status))
			continue

		sd = data.get('streamingData') or {}
		best = {}
		for f in sd.get('adaptiveFormats') or []:
			kind = (f.get('mimeType') or '').split('/')[0]
			if kind not in ('video', 'audio'): continue
			if kind not in best or (f.get('bitrate') or 0) > (best[kind].get('bitrate') or 0):
				best[kind] = f
		prog = None
		for f in sd.get('formats') or []:
			if f.get('url'): prog = f; break

		got = []
		for kind in ('video', 'audio'):
			if kind not in best: continue
			r = _probe_format(best[kind], spec['client']['userAgent'])
			if r:
				txt = ' '.join('%s=%s' % (a, b) for a, b in r)
				lines.append('  %-16s %-6s itag %-5s %s' % (label, kind, best[kind].get('itag'), txt))
				got.append('%s %s' % (kind[0], txt))
		if prog:
			r = _probe_format(prog, spec['client']['userAgent'])
			if r:
				txt = ' '.join('%s=%s' % (a, b) for a, b in r)
				lines.append('  %-16s %-6s itag %-5s %s' % (label, 'prog', prog.get('itag'), txt))
				got.append('prog %s' % txt)
		summary.append('%s → %s' % (label, ' | '.join(got) if got else 'sin formatos'))

	for ln in lines: control.log(ln, LOGINFO)
	control.log('[ luc_kodi ] trailer_probe: fin', LOGINFO)
	try:
		control.dialog.textviewer('luc_kodi — diagnóstico de tráilers',
								  '\n'.join(lines[1:]) or 'sin resultados')
	except Exception:
		log_utils.error()
