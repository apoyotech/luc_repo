# -*- coding: utf-8 -*-
"""
	luc_kodi Add-on — yt_resolver.py (v1.0.45)

	Resolver de vídeos de YouTube SIN API key, sin login y sin dependencias:
	API interna de YouTube (InnerTube, youtube.com/youtubei/v1/player)
	imitando clientes que no exigen PO token ni descifrado de firmas JS.

	v1.0.45 — lecciones del log real del Shield (2026-07-03):
	· android_vr devolvía LOGIN_REQUIRED "confirm you're not a bot".
	  FIX: truco visitorData de yt-dlp — la propia respuesta LOGIN_REQUIRED
	  trae responseContext.visitorData; se reintenta UNA vez con ese valor en
	  context.client.visitorData + header X-Goog-Visitor-Id, y se persiste en
	  una window property (cada tráiler es un invoker nuevo, el estado del
	  módulo muere) para que los siguientes pasen a la primera.
	· ios respondía OK pero con streamingData solo-SABR (sin PO token no hay
	  URLs utilizables) y el código pasaba EN SILENCIO. FIX: se loguea.
	· TVHTML5_SIMPLY_EMBEDDED_PLAYER 2.0 está muerto ("no longer supported").
	  Sustituido por el cliente ANDROID (sin JS; su HLS no exige PO token).

	v1.0.47 — segundo log real: los clientes keyless solo dan 360p como
	progresivo (itag 18); el 720p/1080p existe únicamente en adaptiveFormats
	(vídeo y audio separados). FIX: se genera un manifest DASH estático (MPD)
	con esos formatos —estructura tomada del generador GPL de SlyGuy
	Trailers— y se reproduce con inputstream.adaptive. Sin ISA instalado se
	cae al progresivo de siempre.

	v1.0.49 — tercer log real: ISA resolvía el MPD pero no podía abrirlo
	("CURLOpen failed ... special://temp/..."): su descargador CURL no lee
	rutas special:// ni archivos locales. FIX: el MPD se publica en una
	window property y se sirve por HTTP local (trailer_httpd.py en el
	service), igual que hacen el addon oficial de YouTube y SlyGuy.

	v1.0.58 — el proxy pasa a entregar A RITMO (ver trailer_httpd): aguantar el
	rechazo de Google no bastaba porque su ventana de adelanto se estrecha con el
	uso. Aquí se publican también los bitrates, que el proxy necesita para
	traducir un Range a una posición dentro del medio.

	v1.0.58 — quinto log real: el vídeo V-O-uBaHk3c solo lo resolvía 'ios'
	(android_vr → UNPLAYABLE, android → SABR-only) y sus URLs de googlevideo
	morían con 403 permanente. Añadido el cliente 'android_sdkless' por delante
	de ambos: omitir androidSdkVersion es lo que evita el PO token en los
	formatos HTTPS, y es el primer cliente sin JS del yt-dlp actual.

	v1.0.57 — cuarto log real (Shield, 14-08): googlevideo devolvía HTTP 403 al
	stream de audio tras exactamente 6 segmentos (~60 s de adelanto de
	descarga) mientras el vídeo seguía sin un fallo; ISA reintenta solo 3 s, se
	rinde, y el hilo de audio se queda seco → Kodi bloqueado. FIX: los
	segmentos pasan por trailer_httpd, que reintenta con backoff hasta que
	Google reabre la ventana. Además el MPD publica ahora UN solo
	AdaptationSet de vídeo y uno de audio (antes cuatro), y hay tope de
	resolución configurable para paneles 4K con decodificador limitado.

	MANTENIMIENTO: si vuelve a romperse, actualizar _CLIENTS con las
	constantes de yt_dlp/extractor/youtube/_base.py (INNERTUBE_CLIENTS) del
	yt-dlp más reciente. La capa Invidious y la cadena de trailer.py siguen
	funcionando aunque esto caiga.
"""

import json
import time
from urllib.request import Request, urlopen
from urllib.error import HTTPError, URLError
from urllib.parse import quote

import re
import xbmc
from resources.lib.modules import control
from resources.lib.modules import log_utils

LOGINFO = log_utils.LOGINFO

_PLAYER_URL = 'https://www.youtube.com/youtubei/v1/player?prettyPrint=false'
_TIMEOUT = 10
_VISITOR_PROP = 'luc_kodi.yt_visitor_data'

# Constantes de cliente — sincronizadas con yt-dlp 2026.01 (INNERTUBE_CLIENTS)
_CLIENTS = [
	{
		# Sin PO token, sin JS player. Cliente principal.
		'label': 'android_vr',
		'client': {
			'clientName': 'ANDROID_VR', 'clientVersion': '1.65.10',
			'deviceMake': 'Oculus', 'deviceModel': 'Quest 3',
			'androidSdkVersion': 32, 'osName': 'Android', 'osVersion': '12L',
			'userAgent': 'com.google.android.apps.youtube.vr.oculus/1.65.10 (Linux; U; Android 12L; eureka-user Build/SQ3A.220605.009.A1) gzip',
		},
		'client_id': 28,
	},
	{
		# v1.0.58 — 'android_sdkless': el cliente ANDROID pero SIN declarar
		# androidSdkVersion. Es el primer cliente sin JS que usa yt-dlp hoy
		# (_DEFAULT_JSLESS_CLIENTS = android_sdkless, web_safari, web) porque
		# omitir ese campo evita que YouTube exija PO token para los formatos
		# HTTPS. Va por delante de 'android', que en el log del 14-08 devolvía
		# streams SABR-only, y por delante de 'ios', cuyas URLs mueren con 403
		# permanente. Sin prefer_hls: aquí sí queremos el DASH.
		'label': 'android_sdkless',
		'client': {
			'clientName': 'ANDROID', 'clientVersion': '21.02.35',
			'osName': 'Android', 'osVersion': '11',
			'userAgent': 'com.google.android.youtube/21.02.35 (Linux; U; Android 11) gzip',
		},
		'client_id': 3,
	},
	{
		# Sin JS. PO token requerido para HTTPS pero NO para HLS →
		# se intenta HLS primero y progresivo como propina.
		'label': 'android',
		'client': {
			'clientName': 'ANDROID', 'clientVersion': '21.02.35',
			'androidSdkVersion': 30, 'osName': 'Android', 'osVersion': '11',
			'userAgent': 'com.google.android.youtube/21.02.35 (Linux; U; Android 11) gzip',
		},
		'client_id': 3,
		'prefer_hls': True,
	},
	{
		# Último recurso: HLS a veces disponible aunque su política pida PO.
		'label': 'ios',
		'client': {
			'clientName': 'IOS', 'clientVersion': '21.02.3',
			'deviceMake': 'Apple', 'deviceModel': 'iPhone16,2',
			'osName': 'iPhone', 'osVersion': '18.3.2.22D82',
			'userAgent': 'com.google.ios.youtube/21.02.3 (iPhone16,2; U; CPU iOS 18_3_2 like Mac OS X;)',
		},
		'client_id': 5,
		'prefer_hls': True,
	},
]


def _get_visitor_data():
	try: return control.homeWindow.getProperty(_VISITOR_PROP) or None
	except: return None


def _set_visitor_data(value):
	try:
		if value: control.homeWindow.setProperty(_VISITOR_PROP, value)
	except: pass


def _innertube_player(video_id, spec, visitor_data=None):
	client = dict(spec['client'])
	client.update({'hl': 'en', 'timeZone': 'UTC', 'utcOffsetMinutes': 0})
	if visitor_data:
		client['visitorData'] = visitor_data
	payload = {
		'context': {'client': client},
		'videoId': video_id,
		'contentCheckOk': True,
		'racyCheckOk': True,
	}
	body = json.dumps(payload).encode('utf-8')
	req = Request(_PLAYER_URL, data=body)
	req.add_header('Content-Type', 'application/json')
	req.add_header('User-Agent', spec['client']['userAgent'])
	req.add_header('X-YouTube-Client-Name', str(spec['client_id']))
	req.add_header('X-YouTube-Client-Version', spec['client']['clientVersion'])
	req.add_header('Origin', 'https://www.youtube.com')
	if visitor_data:
		req.add_header('X-Goog-Visitor-Id', visitor_data)
	try:
		resp = urlopen(req, timeout=_TIMEOUT)
		return json.loads(resp.read().decode('utf-8'))
	except (HTTPError, URLError) as e:
		control.log('[ luc_kodi ] yt_resolver: %s HTTP error: %s' % (spec['label'], e), LOGINFO)
		return None
	except Exception:
		log_utils.error()
		return None


def _response_visitor_data(data):
	try: return (data.get('responseContext') or {}).get('visitorData')
	except: return None


def _best_progressive(streaming_data):
	"""Mejor formato progresivo (audio+vídeo, URL limpia). Si viene
	'signatureCipher' en vez de 'url' necesitaría JS — se descarta."""
	best, best_height = None, -1
	for fmt in streaming_data.get('formats') or []:
		url = fmt.get('url')
		if not url: continue
		if not fmt.get('mimeType', '').startswith('video/'): continue
		height = fmt.get('height') or 0
		if height > best_height:
			best_height, best = height, url
	return best, best_height


_MPD_URL = 'http://127.0.0.1:%s/trailer.mpd'
_SEG_URL = 'http://127.0.0.1:%s/s/%s'


_ISA_ID = 'inputstream.adaptive'
_isa_state = [None]  # caché por proceso (cada tráiler es un invoker nuevo, pero evita repetir JSON-RPC dentro del mismo resolve)


def _isa_available():
	"""v1.0.48: System.HasAddon devuelve false si ISA está instalado pero
	DESHABILITADO — el caso real de la tablet Android del log del 03-07.
	En Android ISA viene incluido con Kodi; si está apagado se habilita en
	silencio vía JSON-RPC. Si de verdad no está instalado (Linux/otros),
	se lanza el diálogo de instalación de Kodi una vez."""
	if _isa_state[0] is not None: return _isa_state[0]
	try:
		resp = json.loads(xbmc.executeJSONRPC(json.dumps({
			'jsonrpc': '2.0', 'id': 1, 'method': 'Addons.GetAddonDetails',
			'params': {'addonid': _ISA_ID, 'properties': ['enabled']}})))
		addon = (resp.get('result') or {}).get('addon')
		if addon:
			if addon.get('enabled'):
				_isa_state[0] = True
				return True
			enable = json.loads(xbmc.executeJSONRPC(json.dumps({
				'jsonrpc': '2.0', 'id': 1, 'method': 'Addons.SetAddonEnabled',
				'params': {'addonid': _ISA_ID, 'enabled': True}})))
			ok = enable.get('result') == 'OK'
			control.log('[ luc_kodi ] yt_resolver: inputstream.adaptive was disabled — auto-enabled: %s' % ok, LOGINFO)
			_isa_state[0] = ok
			return ok
		# No instalado: diálogo de instalación de Kodi (acción iniciada por el
		# usuario al pedir el tráiler, así que el prompt es aceptable)
		control.log('[ luc_kodi ] yt_resolver: inputstream.adaptive not installed — prompting Kodi install dialog', LOGINFO)
		try: control.notification(message='Installing InputStream Adaptive — retry the trailer after it finishes')
		except: pass
		xbmc.executebuiltin('InstallAddon(%s)' % _ISA_ID)
		_isa_state[0] = False
		return False
	except Exception:
		log_utils.error()
		_isa_state[0] = False
		return False


def _xml_escape(url):
	return (url.replace('&', '&amp;').replace('"', '&quot;')
			   .replace('<', '&lt;').replace('>', '&gt;'))


def _codecs(mime):
	m = re.search(r'codecs="([^"]+)"', mime or '')
	return m.group(1) if m else ''


def _codec_prefs():
	"""Filtro de códecs configurable por el usuario. AV1 (av01.*) y VP9
	Profile 2 (vp09.02.*, 10-bit/HDR) no se decodifican por hardware en
	dispositivos muy comunes (p. ej. NVIDIA Shield TV: pantalla negra o
	software-decode a tirones) → excluidos del MPD por defecto. Los
	dispositivos recientes (Google TV Streamer, Fire TV 2023+) pueden
	habilitarlos en Ajustes. H.264 (avc1) y VP9 8-bit pasan siempre."""
	return (control.setting('trailer.codec.av1') == 'true',
			control.setting('trailer.codec.vp92') == 'true')


def _codec_allowed(codecs, allow_av1, allow_vp92):
	c = (codecs or '').lower()
	if c.startswith('av01'): return allow_av1
	if c.startswith('vp09.02'): return allow_vp92
	return True


def _max_height():
	"""Tope de resolución del MPD. 'Auto' (0) = sin tope propio: manda la
	pantalla, que es lo que ya calcula el chooser de ISA. Los demás valores
	existen para dispositivos con panel 4K cuyo decodificador no da la talla
	real en 2160p."""
	try: return (0, 720, 1080, 1440, 2160)[int(control.setting('trailer.max.resolution') or 0)]
	except (ValueError, TypeError, IndexError): return 0


def _refs(f):
	"""Número de referencias del sidx = número de segmentos del formato. Se
	deduce del tamaño de indexRange (cabecera de 32 bytes + 12 por referencia).
	Más referencias = segmentos más cortos = menos adelanto acumula ISA por
	descarga. Se usa para elegir la pista de audio menos propensa a disparar el
	throttle de googlevideo (el 403 del log del Shield salía SIEMPRE en el
	audio, que venía en segmentos de ~10 s)."""
	try:
		ir = f.get('indexRange') or {}
		size = int(ir.get('end', 0)) - int(ir.get('start', 0)) + 1
		return max(0, (size - 32) // 12)
	except (TypeError, ValueError):
		return 0


def _family(codecs):
	"""Familia de códec de vídeo. Un AdaptationSet solo debe contener
	representaciones intercambiables sin reiniciar el decodificador, así que
	nunca se mezclan avc1 con vp9 ni con av01."""
	c = (codecs or '').lower()
	if c.startswith('av01'): return 'av1'
	if c.startswith('vp09.02'): return 'vp9.2'   # 10-bit/HDR: nunca junto al 8-bit
	if c.startswith('vp09') or c.startswith('vp9'): return 'vp9'
	if c.startswith('avc'): return 'avc1'
	return c.split('.')[0] or 'other'


# A igualdad de altura máxima gana el más compatible. Los ajustes de AV1 y
# VP9.2 son permisos ("Allow ..."), no preferencias: solo se acaba en esas
# familias si llegan MÁS alto que las demás.
_FAMILY_RANK = {'avc1': 0, 'vp9': 1, 'vp9.2': 2, 'av1': 3}


def _pick_video(groups):
	"""Un ÚNICO AdaptationSet de vídeo, de una sola familia de códec. Antes se
	publicaban los dos contenedores (mp4 y webm), así que ISA creaba
	AdaptiveStreams de más y Kodi ofrecía pistas de vídeo duplicadas en el OSD.
	Gana la familia que llegue más alto dentro de lo que permiten los filtros —
	así un dispositivo capaz se lleva el 2160p VP9 que el avc1 no tiene nunca;
	a igualdad de altura, la más compatible. Bajar el tope de resolución a
	1080p devuelve automáticamente a avc1, que es la vía más segura."""
	buckets = {}
	for mime in ('video/mp4', 'video/webm'):
		for f in groups[mime]:
			fam = _family(_codecs(f.get('mimeType')))
			buckets.setdefault((mime, fam), []).append(f)
	if not buckets: return [], None
	def score(item):
		(mime, fam), fmts = item
		return (max([f.get('height') or 0 for f in fmts]), -_FAMILY_RANK.get(fam, 9))
	(mime, fam), fmts = max(buckets.items(), key=score)
	return fmts, mime


def _pick_audio(groups):
	"""Un ÚNICO AdaptationSet de audio, el de segmentos más cortos (ver
	_refs). A igualdad de segmentación, mp4/AAC por compatibilidad."""
	mp4, webm = groups['audio/mp4'], groups['audio/webm']
	r_mp4 = max([_refs(f) for f in mp4] or [0])
	r_webm = max([_refs(f) for f in webm] or [0])
	if webm and r_webm > r_mp4: return webm, 'audio/webm'
	if mp4: return mp4, 'audio/mp4'
	if webm: return webm, 'audio/webm'
	return [], None


def _bytes_per_second(f):
	"""Bytes por segundo reales del formato. Exacto vía contentLength y
	duración; si faltan, se cae a averageBitrate y solo en último extremo al
	'bitrate' de pico, que es el que engañaba al freno."""
	try:
		clen = int(f.get('contentLength') or 0)
		dur = int(f.get('approxDurationMs') or 0) / 1000.0
		if clen > 0 and dur > 0: return clen / dur
	except (TypeError, ValueError): pass
	try:
		return int(f.get('averageBitrate') or f.get('bitrate') or 0) / 8.0
	except (TypeError, ValueError): return 0


def _build_mpd(data, min_height, max_height, port):
	"""Manifest DASH estático a partir de adaptiveFormats con URL limpia e
	initRange/indexRange (SegmentBase). Devuelve (mpd, url_map, best_height).

	v1.0.57: las <BaseURL> ya NO apuntan a googlevideo sino al proxy local
	(trailer_httpd), y el manifest lleva un solo AdaptationSet de vídeo y uno
	de audio. Las URLs firmadas viajan aparte en una window property para que
	el MPD no engorde."""
	sd = data.get('streamingData') or {}
	allow_av1, allow_vp92 = _codec_prefs()
	groups = {'video/mp4': [], 'audio/mp4': [], 'video/webm': [], 'audio/webm': []}
	for f in sd.get('adaptiveFormats') or []:
		if not f.get('url'): continue  # signatureCipher → necesitaría JS
		if not f.get('initRange') or not f.get('indexRange'): continue
		if not f.get('itag'): continue
		mime = (f.get('mimeType') or '').split(';')[0].strip()
		if mime not in groups: continue
		if mime.startswith('video/'):
			h = f.get('height') or 0
			if min_height and h < min_height: continue
			if max_height and h > max_height: continue
			if not _codec_allowed(_codecs(f.get('mimeType')), allow_av1, allow_vp92): continue
		groups[mime].append(f)

	video, v_mime = _pick_video(groups)
	audio, a_mime = _pick_audio(groups)
	if not video or not audio: return None, None, 0

	# v1.0.61 — UNA sola representación de cada tipo. Un tráiler de minuto y medio
	# no necesita conmutar calidad, y con el proxy entregando a ritmo la
	# adaptación es directamente dañina: cualquier frenado deliberado ISA lo lee
	# como conexión lenta. En el log del 15-08 su medición se hundió de 938
	# Mbit/s a 0,9 Mbit/s y fue bajando la calidad sola, 1080p → 720p, en un
	# enlace de fibra. Publicando una única representación no hay nada que bajar.
	video = [max(video, key=lambda f: ((f.get('height') or 0), f.get('bitrate') or 0))]
	audio = [max(audio, key=lambda f: f.get('bitrate') or 0)]

	try: duration = int((data.get('videoDetails') or {}).get('lengthSeconds') or 0)
	except (TypeError, ValueError): duration = 0
	if not duration:
		try: duration = int(int(video[0].get('approxDurationMs', 0)) / 1000)
		except Exception: duration = 300

	url_map, rate_map = {}, {}
	out = ['<?xml version="1.0" encoding="UTF-8"?>',
		   '<MPD xmlns="urn:mpeg:dash:schema:mpd:2011" minBufferTime="PT1.5S" '
		   'mediaPresentationDuration="PT%dS" type="static" '
		   'profiles="urn:mpeg:dash:profile:isoff-main:2011">' % duration, '<Period>']
	for adap_id, (mime, fmts) in enumerate(((v_mime, video), (a_mime, audio))):
		out.append('<AdaptationSet id="%d" mimeType="%s"><Role schemeIdUri="urn:mpeg:DASH:role:2011" value="main"/>' % (adap_id, mime))
		for f in fmts:
			itag = str(f['itag'])
			url_map[itag] = f['url']
			# v1.0.59: al proxy le viajan BYTES POR SEGUNDO exactos, no el bitrate.
			# El campo 'bitrate' de YouTube es el PICO, y en vídeo VBR eso
			# subestimaba la posición dentro del medio entre 12 y 29 s (medido
			# con el log del 14-08 15:16), así que el freno no llegaba a
			# activarse nunca en las pistas de vídeo. contentLength dividido
			# entre la duración real es exacto e inmune al VBR.
			rate_map[itag] = _bytes_per_second(f)
			line = '<Representation id="%s" codecs="%s" bandwidth="%s"' % (
				itag, _codecs(f.get('mimeType')), f.get('bitrate') or 0)
			if mime.startswith('video/'):
				line += ' width="%s" height="%s"' % (f.get('width') or 0, f.get('height') or 0)
			line += '>'
			out.append(line)
			if mime.startswith('audio/'):
				out.append('<AudioChannelConfiguration schemeIdUri="urn:mpeg:dash:23003:3:audio_channel_configuration:2011" value="2"/>')
			out.append('<BaseURL>%s</BaseURL>' % (_SEG_URL % (port, itag)))
			out.append('<SegmentBase indexRange="%s-%s"><Initialization range="%s-%s" /></SegmentBase>' % (
				f['indexRange'].get('start', 0), f['indexRange'].get('end', 0),
				f['initRange'].get('start', 0), f['initRange'].get('end', 0)))
			out.append('</Representation>')
		out.append('</AdaptationSet>')
	out.append('</Period>')
	out.append('</MPD>')
	best_h = max([f.get('height') or 0 for f in video] or [0])
	return '\n'.join(out), (url_map, rate_map), best_h


def _httpd_port():
	"""Puerto del micro-servidor del service. Si la property no existe (service
	aún no arrancado — raro), arranque efímero de emergencia en este mismo
	invoker: sobrevive lo suficiente porque ISA pide el manifest nada más
	resolver, mientras el invoker sigue vivo."""
	try:
		from resources.lib.modules import trailer_httpd
		port = control.homeWindow.getProperty(trailer_httpd.PROP_PORT)
		if not port:
			control.log('[ luc_kodi ] yt_resolver: trailer_httpd not running — starting ephemeral fallback', LOGINFO)
			trailer_httpd.start()
			for _ in range(20):
				port = control.homeWindow.getProperty(trailer_httpd.PROP_PORT)
				if port: break
				if control.monitor.waitForAbort(0.1): return None
		if port: return port
		control.log('[ luc_kodi ] yt_resolver: trailer_httpd unavailable, cannot serve MPD', LOGINFO)
	except Exception:
		log_utils.error()
	return None


def _publish(mpd, maps, user_agent, video_id='', client_label=''):
	"""Publica manifest y mapa de URLs firmadas en las window properties que lee
	trailer_httpd. Cero disco, cero traducción de rutas, y accesible entre
	invokers (esto se escribe desde el invoker del tráiler y lo lee el proceso
	del service)."""
	try:
		from resources.lib.modules import trailer_httpd
		url_map, rate_map = maps
		# 'g' identifica esta reproducción: el proxy agrupa por ahí el estado del
		# ritmo, para que audio y vídeo compartan origen de línea de tiempo.
		control.homeWindow.setProperty(trailer_httpd.PROP_STREAMS,
									   json.dumps({'ua': user_agent, 'u': url_map,
												   'b': rate_map, 'v': video_id, 'c': client_label,
												   'g': '%d' % int(time.time() * 1000)}))
		control.homeWindow.setProperty(trailer_httpd.PROP_CONTENT, mpd)
		return True
	except Exception:
		log_utils.error()
	return False


def _extract_stream(data, spec, video_id, min_height=0):
	"""De una respuesta con status OK, saca la mejor URL reproducible.
	min_height: los progresivos por debajo se descartan; el HLS se acepta
	siempre porque el manifest adaptativo incluye todas las calidades de la
	fuente y Kodi sube solo hasta la mejor disponible."""
	sd = data.get('streamingData') or {}
	ua = spec['client']['userAgent']

	# v1.0.47: DASH adaptativo primero — es la única vía keyless a 720p/1080p
	# (el progresivo tope es 360p). Requiere inputstream.adaptive.
	# v1.0.57: los segmentos van por el proxy local, no directos a googlevideo.
	if _isa_available():
		port = _httpd_port()
		if port:
			mpd, maps, best_h = _build_mpd(data, min_height, _max_height(), port)
			if mpd and _publish(mpd, maps, ua, video_id, spec['label']):
				control.log('[ luc_kodi ] yt_resolver: resolved %s via %s (DASH up to %sp, proxied)'
							% (video_id, spec['label'], best_h), LOGINFO)
				return {'url': _MPD_URL % port, 'user_agent': ua, 'is_hls': False,
						'is_dash': True, 'client': spec['label']}
	elif min_height:
		control.log('[ luc_kodi ] yt_resolver: inputstream.adaptive not installed — cannot serve >360p keyless', LOGINFO)

	if spec.get('prefer_hls'):
		hls = sd.get('hlsManifestUrl')
		if hls:
			control.log('[ luc_kodi ] yt_resolver: resolved %s via %s (HLS)' % (video_id, spec['label']), LOGINFO)
			return {'url': hls + '|User-Agent=' + quote(ua), 'user_agent': ua,
					'is_hls': True, 'client': spec['label']}

	url, height = _best_progressive(sd)
	if url and min_height and height < min_height:
		control.log('[ luc_kodi ] yt_resolver: %s progressive %sp < min %sp, skipping'
					% (spec['label'], height, min_height), LOGINFO)
		url = None
	if url:
		control.log('[ luc_kodi ] yt_resolver: resolved %s via %s (progressive %sp)'
					% (video_id, spec['label'], height), LOGINFO)
		return {'url': url + '|User-Agent=' + quote(ua), 'user_agent': ua,
				'is_hls': False, 'client': spec['label']}

	hls = sd.get('hlsManifestUrl')
	if hls:
		control.log('[ luc_kodi ] yt_resolver: resolved %s via %s (HLS fallback)' % (video_id, spec['label']), LOGINFO)
		return {'url': hls + '|User-Agent=' + quote(ua), 'user_agent': ua,
				'is_hls': True, 'client': spec['label']}

	# v1.0.45: antes este caso moría en silencio (lección del log del Shield)
	control.log('[ luc_kodi ] yt_resolver: %s → OK but no usable streams (SABR-only/ciphered, PO token likely required)'
				% spec['label'], LOGINFO)
	return None


def refresh_urls(video_id, client_label, wanted_itags):
	"""Vuelve a pedir el player a YouTube y devuelve {itag: url} recién
	firmadas para los itags indicados, o None.

	v1.0.63 — googlevideo sirve solo un tramo del fichero por URL y después
	responde 403 para siempre. Medido en el log del 15-ago 12:58, idéntico en
	dos tráilers seguidos: 12,5 MB de vídeo y 0,97 MB de audio, unos 60-65 s de
	medio, con el último acierto a los +32 s de haber resuelto. Y es POR URL:
	el tráiler siguiente, con URLs nuevas, volvía a servir otros 60 s. Así que
	cuando se cierra el grifo no hay que esperar, hay que pedir llave nueva.
	El fichero es el mismo (mismo itag, mismo contentLength), así que los
	rangos de bytes que ya tenía ISA siguen siendo válidos."""
	wanted = set(str(i) for i in wanted_itags)
	visitor = _get_visitor_data()
	specs = [c for c in _CLIENTS if c['label'] == client_label] or list(_CLIENTS)
	for spec in specs:
		data = _innertube_player(video_id, spec, visitor_data=visitor)
		if not data: continue
		fresh = _response_visitor_data(data)
		if fresh and fresh != visitor:
			_set_visitor_data(fresh)
			visitor = fresh
		if (data.get('playabilityStatus') or {}).get('status') != 'OK': continue
		out = {}
		for f in ((data.get('streamingData') or {}).get('adaptiveFormats') or []):
			itag = str(f.get('itag') or '')
			if itag in wanted and f.get('url'): out[itag] = f['url']
		if wanted.issubset(out): return out
	return None


def resolve(video_id, min_height=0):
	"""Devuelve dict {'url', 'user_agent', 'is_hls', 'client'} o None.
	La URL lleva |User-Agent= embebido porque googlevideo valida que el UA
	coincida con el cliente que resolvió."""
	visitor = _get_visitor_data()

	for spec in _CLIENTS:
		data = _innertube_player(video_id, spec, visitor_data=visitor)
		if not data: continue

		# Persistir SIEMPRE el visitorData más fresco que nos den
		fresh = _response_visitor_data(data)
		if fresh and fresh != visitor:
			_set_visitor_data(fresh)

		status = (data.get('playabilityStatus') or {}).get('status')
		if status == 'OK':
			resolved = _extract_stream(data, spec, video_id, min_height)
			if resolved: return resolved
			continue

		reason = (data.get('playabilityStatus') or {}).get('reason', '')
		control.log('[ luc_kodi ] yt_resolver: %s → %s %s' % (spec['label'], status, reason), LOGINFO)

		# Bot-check: reintentar UNA vez con el visitorData de la propia
		# respuesta (mismo mecanismo que yt-dlp). Solo si no lo llevaba ya.
		if status == 'LOGIN_REQUIRED' and fresh and fresh != visitor:
			control.log('[ luc_kodi ] yt_resolver: %s retrying with fresh visitorData' % spec['label'], LOGINFO)
			visitor = fresh
			data = _innertube_player(video_id, spec, visitor_data=visitor)
			if data:
				fresh2 = _response_visitor_data(data)
				if fresh2: _set_visitor_data(fresh2)
				status2 = (data.get('playabilityStatus') or {}).get('status')
				if status2 == 'OK':
					resolved = _extract_stream(data, spec, video_id, min_height)
					if resolved: return resolved
				else:
					control.log('[ luc_kodi ] yt_resolver: %s retry → %s' % (spec['label'], status2), LOGINFO)

	control.log('[ luc_kodi ] yt_resolver: could not resolve %s with any client' % video_id, LOGINFO)
	return None
