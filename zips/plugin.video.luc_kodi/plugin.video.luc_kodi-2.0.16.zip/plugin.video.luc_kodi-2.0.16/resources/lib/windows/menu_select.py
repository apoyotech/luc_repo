# -*- coding: utf-8 -*-
"""
	luc_kodi Add-on
	menu_select.py (v2.0.16) - window of modules/menu_panel.py: the menus opened
	from the context panel, in the style of the Assistant's welcome window.
"""

from resources.lib.windows.base import BaseDialog

LIST_ID = 9601
PROPS = ('menu', 'meta', 'title', 'poster', 'artkind', 'version')


class MenuSelectXML(BaseDialog):
	def __init__(self, *args, **kwargs):
		BaseDialog.__init__(self, args)
		self.entries = kwargs.get('entries') or []
		self.header = kwargs.get('header') or {}
		self.chosen = -1
		self.item_list = []
		for e in self.entries:
			li = self.make_listitem()
			li.setLabel(e.get('label', ''))
			li.setProperty('icon', e.get('icon', 'ctx/ic_dot.png'))
			li.setProperty('color', e.get('color', 'FFB0B0D0'))
			li.setProperty('tile', e.get('tile', '2EB0B0D0'))
			self.item_list.append(li)
		for key in PROPS:
			self.setProperty('ms.%s' % key, self.header.get(key, '') or '')

	def onInit(self):
		try:
			lst = self.getControl(LIST_ID)
			lst.reset()
			lst.addItems(self.item_list)
			lst.selectItem(0)
			self.setFocusId(LIST_ID)
		except Exception:
			from resources.lib.modules import log_utils
			log_utils.error()

	def run(self):
		self.doModal()
		self.clearProperties()
		return self.chosen

	def onClick(self, controlID):
		try:
			if controlID == LIST_ID:
				pos = self.get_position(LIST_ID)
				if 0 <= pos < len(self.entries):
					self.chosen = pos
					self.close()
		except Exception:
			from resources.lib.modules import log_utils
			log_utils.error()

	def onAction(self, action):
		try:
			if action.getId() in self.closing_actions or action.getId() in self.context_actions:
				self.chosen = -1
				self.close()
		except Exception:
			from resources.lib.modules import log_utils
			log_utils.error()
