# -*- coding: utf-8 -*-
"""
	luc_kodi Add-on
"""

from resources.lib.modules import app_keys
from datetime import datetime, timedelta
from json import dumps as jsdumps
import re
from threading import Thread
from time import time as _now
from urllib.parse import quote_plus, urlencode, parse_qsl, urlparse, urlsplit
from resources.lib.database import cache, metacache, fanarttv_cache, traktsync
from resources.lib.indexers.tmdb import TVshows as tmdb_indexer
from resources.lib.indexers.fanarttv import FanartTv
from resources.lib.modules import cleangenre
from resources.lib.modules import control
from resources.lib.modules.context_hub import attach_cm # v2.0.09: modern panel or classic Kodi menu
from resources.lib.modules import lang_assist
from resources.lib.modules import poster_rotator
from resources.lib.modules.playcount import getTVShowOverlay, getShowCount, getSeasonIndicators
from resources.lib.modules import trakt
from resources.lib.modules import views

getLS = control.lang
getSetting = control.setting
KODI_VERSION = control.getKodiVersion()
# v2.0.04: Anos, Generos e Idiomas traen solo lo popular de TMDb (popularidad,
# con al menos estos votos; las series reciben menos que las pelis, que piden 100),
# sin seguir el orden general de listas. Anos va del actual hacia atras hasta 1960.
YEAR_FIRST = 1960
POPULAR_MIN_VOTES_SHOWS = 50
# Idiomas: una serie popular en su pais rara vez sale en torrents cacheados. Las que
# estan en las plataformas grandes (series turcas, coreanas o portuguesas de Netflix,
# Prime Video, Disney+...) si: salen en WEB-DL y con titulo en ingles. Por eso Idiomas
# solo muestra lo que esta en estas plataformas por suscripcion (catalogo de EE. UU.,
# ids de TMDb los mismos que en Streaming). El filtro ya es la seleccion, asi que el
# suelo de votos baja.
# v2.0.08: mas plataformas para Languages. A las 8 grandes se suman las que el plugin
# ya tiene verificadas en Streaming y llevan mucho contenido que no es en ingles:
# MUBI y Kanopy (cine internacional), Vix (espanol), OnDemandKorea, AMC+, Starz, MGM+,
# Shudder y las gratuitas con anuncios Tubi, Pluto TV, The Roku Channel y Plex. Fuera
# Crunchyroll (anime) y Google Play (alquiler y compra). Cuenta suscripcion, gratis y
# con anuncios, no alquiler.
LANG_STREAMING_PROVIDERS = '8|9|337|1899|15|350|386|2303|11|191|457|575|526|43|34|99|73|300|207|538'
LANG_STREAMING_MONETIZATION = 'flatrate|free|ads'
# Top rated necesita un minimo para que la nota signifique algo (mismo suelo que el resto de series)
LANG_TOP_MIN_VOTES_SHOWS = 50
LANG_STREAMING_REGION = 'US'
# v2.0.08: sin suelo de votos. Lo que esta en el catalogo de estas plataformas ya es
# la seleccion; el minimo de votos dejaba fuera series de otros idiomas que se votan poco.

class TVshows:
	def __init__(self, notifications=True):
		self.list = []
		self.page_limit = getSetting('page.item.limit')
		self.search_page_limit = getSetting('search.page.limit')
		self.lang = control.apiLanguage()['tmdb']
		self.notifications = notifications
		# v1.0.81 — ganchos del precache de catalogo. Los menus NUNCA los ponen:
		# solo el servicio de catalogo, para que el enriquecido de estas listas
		# comparta el semaforo global de peticiones y respete el presupuesto de
		# tiempo de la pasada en segundo plano.
		self.precache_sem = None
		self.precache_deadline = None
		# Auto-activar FanartTV en pantallas 4K (clearlogo, clearart, poster/fanart alternativos)
		# is_4k_display() espera al flag con timeout corto — evita race en boot.
		from resources.lib.modules.gui_resolution import is_4k_display as _is_4k_display
		_is_4k = _is_4k_display()
		self.enable_fanarttv = getSetting('enable.fanarttv') == 'true' or _is_4k
		self.prefer_tmdbArt = getSetting('prefer.tmdbArt') == 'true'
		self.prefer_en_titles = getSetting('title.lang.en') == 'true'
		self.unairedcolor = control.getColor(getSetting('unaired.identify'))
		self.highlight_color = control.getHighlightColor()
		self.date_time = datetime.now()
		self.today_date = (self.date_time).strftime('%Y-%m-%d')
		self.user = '' # v2.0.04: clave de la metacache de series (antes imdb.user, siempre vacio)

		self.tmdb_anime_link = 'https://api.themoviedb.org/3/discover/tv?api_key=%s&with_genres=16&with_original_language=ja&sort_by=popularity.desc&page=1'

		self.trakt_user = getSetting('trakt.username').strip()
		self.traktCredentials = trakt.getTraktCredentialsInfo()
		self.trakt_link = 'https://api.trakt.tv'
		self.search_link = 'https://api.trakt.tv/search/show?limit=%s&page=1&query=' % self.search_page_limit
		self.traktlists_link = 'https://api.trakt.tv/users/me/lists'
		self.traktlikedlists_link = 'https://api.trakt.tv/users/likes/lists?limit=1000000' # used by library import only
		self.traktwatchlist_link = 'https://api.trakt.tv/users/me/watchlist/shows?limit=%s&page=1' % self.page_limit # this is now a dummy link for pagination to work
		self.traktcollection_link = 'https://api.trakt.tv/users/me/collection/shows?limit=%s&page=1' % self.page_limit # this is now a dummy link for pagination to work
		self.traktlist_link = 'https://api.trakt.tv/users/%s/lists/%s/items/shows?limit=%s&page=1' % ('%s', '%s', self.page_limit) # local pagination, limit and page used to advance, pulled from request
		self.progress_link = 'https://api.trakt.tv/sync/watched/shows' # 2026-06-30: noseason(s) deprecated; no-seasons + full info is the default now
		self.trakttrending_link = 'https://api.trakt.tv/shows/trending?page=1&limit=%s' % self.page_limit
		self.traktpopular_link = 'https://api.trakt.tv/shows/popular?page=1&limit=%s' % self.page_limit
		self.traktrecommendations_link = 'https://api.trakt.tv/recommendations/shows?limit=40'
		self.trakt_popularLists_link = 'https://api.trakt.tv/lists/popular?limit=40&page=1' # use limit=40 due to filtering out Movie only lists
		self.trakt_trendingLists_link = 'https://api.trakt.tv/lists/trending?limit=40&page=1'

		# SIMKL public trending lists (no login required, client_id-only).
		# extended=tmdb gives us the tmdb id + title + year upfront so the
		# worker pipeline can resolve metadata without an extra round trip.
		self.simkl_link = 'https://api.simkl.com'
		self.simkldata_link = 'https://data.simkl.in'
		self.simkltrendingtoday_link = 'https://data.simkl.in/discover/trending/tv/today_100.json'
		self.simkltrendingweek_link  = 'https://data.simkl.in/discover/trending/tv/week_100.json'
		self.simkltrendingmonth_link = 'https://data.simkl.in/discover/trending/tv/month_100.json'
		# PunchPlay: catalogo PUBLICO, sin auth ni token (/api/public/v1).
		# `type` es 'movie' o 'show', los unicos kinds enrutables de PunchPlay.
		self.punchplay_link = 'https://punchplay.tv'
		self.punchplaytrending_link = 'https://punchplay.tv/api/public/v1/catalog/trending?type=show'
		self.punchplaypopular_link = 'https://punchplay.tv/api/public/v1/catalog/discover?category=popular&type=show'
		# v1.0.99 WeTrakr Discover. Van con el token del usuario (cuota suya).
		self.wetrakr_link = 'https://api.wetrakr.com'
		self.wetrakrtrending_link = 'https://api.wetrakr.com/discover/trending?filter_type=show&limit=100'
		self.wetrakrpopular_link = 'https://api.wetrakr.com/discover/popular?filter_type=show&limit=100'
		self.wetrakrtoprated_link = 'https://api.wetrakr.com/discover/toprated?filter_type=show&limit=100'
		self.wetrakrrecommended_link = 'https://api.wetrakr.com/discover/recommended?filter_type=show&limit=100'

		self.tvmaze_link = 'https://www.tvmaze.com'
		self.tmdb_key = getSetting('tmdb.api.key')
		if self.tmdb_key == '' or self.tmdb_key is None:
			self.tmdb_key = app_keys.get('tmdb')
		self.tmdb_session_id = getSetting('tmdb.session_id')
		self.tmdb_link = 'https://api.themoviedb.org'
		self.tmdb_userlists_link = 'https://api.themoviedb.org/3/account/{account_id}/lists?api_key=%s&language=en-US&session_id=%s&page=1' % ('%s', self.tmdb_session_id) # used by library import only
		self.tmdb_popular_link = 'https://api.themoviedb.org/3/tv/popular?api_key=%s&with_original_language=en&language=en-US&region=US&page=1'
		self.tmdb_toprated_link = 'https://api.themoviedb.org/3/tv/top_rated?api_key=%s&language=en-US&region=US&page=1'
		self.tmdb_ontheair_link = 'https://api.themoviedb.org/3/tv/on_the_air?api_key=%s&language=en-US&region=US&page=1'
		self.tmdb_airingtoday_link = 'https://api.themoviedb.org/3/tv/airing_today?api_key=%s&language=en-US&region=US&page=1'
		self.tmdb_networks_link = 'https://api.themoviedb.org/3/discover/tv?api_key=%s&with_networks=%s&sort_by=%s&page=1' % ('%s', '%s', self.tmdb_DiscoverSort())
		# v1.0.96 — TV Shows > Streaming: series AVAILABLE on a platform (TMDb watch
		# providers, data from JustWatch), not only the ones it produced, which is what
		# Networks shows. Same 50-vote floor as Tools > Test networks and streaming: below it a
		# series rarely has cached sources. Sorting by rating already brings its own.
		_tv_sort = self.tmdb_DiscoverSort()
		self.tmdb_watchproviders_link = 'https://api.themoviedb.org/3/discover/tv?api_key=%s&language=en-US&watch_region=US&with_watch_providers=%s&include_null_first_air_dates=false&sort_by=%s%s&page=1' % ('%s', '%s', _tv_sort, '' if 'vote_count.gte' in _tv_sort else '&vote_count.gte=50')
		self.tmdb_genre_link = 'https://api.themoviedb.org/3/discover/tv?api_key=%s&with_genres=%s&include_null_first_air_dates=false&sort_by=popularity.desc&vote_count.gte=%s&page=1' % ('%s', '%s', POPULAR_MIN_VOTES_SHOWS)
		# v2.0.04: cada ano trae las series populares que empezaron ese ano (suelo de votos)
		self.tmdb_year_link = 'https://api.themoviedb.org/3/discover/tv?api_key=%s&language=en-US&include_null_first_air_dates=false&first_air_date_year=%s&sort_by=popularity.desc&vote_count.gte=%s&page=1' % ('%s', '%s', POPULAR_MIN_VOTES_SHOWS)
		# v2.0.04: lo que leia paginas de IMDb sale ahora de TMDb. IMDb cambio su
		# maquetado y el lector viejo ya no encontraba nada.
		self.tmdb_mostvoted_link = 'https://api.themoviedb.org/3/discover/tv?api_key=%s&language=en-US&include_null_first_air_dates=false&sort_by=vote_count.desc&page=1'
		# v2.0.08: cada idioma abre un submenu con cuatro listas (language_menu)
		_lp = '&watch_region=%s&with_watch_providers=%s&with_watch_monetization_types=%s' % (LANG_STREAMING_REGION, LANG_STREAMING_PROVIDERS, LANG_STREAMING_MONETIZATION)
		_lb = 'https://api.themoviedb.org/3/discover/tv?api_key=%s&language=en-US&include_null_first_air_dates=false&with_original_language=%s'
		self.tmdb_language_link = _lb + _lp + '&sort_by=popularity.desc&page=1'
		self.tmdb_language_new_link = _lb + '&first_air_date.gte=%s&first_air_date.lte=%s' % ((self.date_time - timedelta(days=365)).strftime('%Y-%m-%d'), self.today_date) + _lp + '&sort_by=popularity.desc&page=1'
		self.tmdb_language_top_link = _lb + _lp + '&sort_by=vote_average.desc&vote_count.gte=%s&page=1' % LANG_TOP_MIN_VOTES_SHOWS
		self.tmdb_language_all_link = _lb + '&sort_by=popularity.desc&page=1'
		self.tmdb_language_links = (self.tmdb_language_link, self.tmdb_language_new_link, self.tmdb_language_top_link, self.tmdb_language_all_link)
		# Series de una persona: discover/tv no filtra por persona, asi que van sus
		# creditos (ver tmdb.credit_shows). Primero el id de la persona, luego la clave.
		self.tmdb_person_link = 'https://api.themoviedb.org/3/person/%s/tv_credits?api_key=%s&language=en-US'
		self.tmdb_persons_link = 'https://api.themoviedb.org/3/search/person?api_key=%s&language=en-US&include_adult=false&page=1&query='
		self.tmdb_personlist_link = 'https://api.themoviedb.org/3/person/popular?api_key=%s&language=en-US&page=1'
		# --- Premiere calendar (global, NOT watchlist-based) -----------------
		# Ventana de fechas sobre first_air_date de todo el catalogo TMDb, igual
		# que la seccion "Premieres" del calendario de Trakt.
		_cal = lambda days: (self.date_time + timedelta(days=days)).strftime('%Y-%m-%d')
		self.tmdb_calendarPremieres_link = 'https://api.themoviedb.org/3/discover/tv?api_key=%s&language=en-US&include_null_first_air_dates=false&first_air_date.gte=%s&first_air_date.lte=%s&sort_by=popularity.desc&page=1' % ('%s', _cal(1), _cal(180))
		self.tmdb_calendarNew_link = 'https://api.themoviedb.org/3/discover/tv?api_key=%s&language=en-US&include_null_first_air_dates=false&first_air_date.gte=%s&first_air_date.lte=%s&sort_by=popularity.desc&page=1' % ('%s', _cal(-60), self.today_date)
		# Ticket is in to add this feature but currently not available
		# self.tmdb_certification_link = 'https://api.themoviedb.org/3/discover/tv?api_key=%s&language=en-US&certification_country=US&certification=%s&sort_by=%s&page=1' % ('%s', '%s', self.tmdb_DiscoverSort())

	def get(self, url, idx=True, create_directory=True):
		self.list = []
		try:
			try: url = getattr(self, url + '_link')
			except: pass
			try: u = urlparse(url).netloc.lower()
			except: pass
			if u in self.trakt_link and '/users/' in url:
				try:
					if '/users/me/' not in url: raise Exception()
					if '/collection/' in url: return self.traktCollection(url)
					if '/watchlist/' in url: return self.traktWatchlist(url)
					if trakt.getActivity() > cache.timeout(self.trakt_list, url, self.trakt_user):
						self.list = cache.get(self.trakt_list, 0, url, self.trakt_user)
					else: self.list = cache.get(self.trakt_list, 720, url, self.trakt_user)
				except: self.list = self.trakt_userList(url)
				if idx: self.worker()
				self.sort()
			elif u in self.trakt_link and self.search_link in url:
				self.list = cache.get(self.trakt_list, 0, url, self.trakt_user)
				if idx: self.worker()
			elif u in self.trakt_link:
				self.list = cache.get(self.trakt_list, 24, url, self.trakt_user)
				if idx: self.worker()
			elif u in self.simkl_link or u in self.simkldata_link:
				# SIMKL trending: cache TTL matches the period — today=6h, week=24h, month=96h
				# '/today' casa con la URL vieja (/trending/today) y con el fichero (/movies/today_100.json)
				if '/today' in url:   _ttl = 6
				elif '/week' in url:  _ttl = 24
				elif '/month' in url: _ttl = 96
				else: _ttl = 24
				from resources.lib.modules import simkl as simkl_mod
				self.list = cache.get(simkl_mod.simkl_list, _ttl, url)
				if idx: self.worker()
			elif u in self.punchplay_link:
				# Trending se mueve a diario; discover/popular aguanta mas.
				_ttl = 6 if '/trending' in url else 24
				from resources.lib.modules import punchplay as punchplay_mod
				self.list = cache.get(punchplay_mod.punchplay_list, _ttl, url)
				if idx: self.worker()
			elif u in self.wetrakr_link:
				_ttl = 6 if ('/trending' in url or '/recommended' in url) else 24
				from resources.lib.modules import wetrakr as wetrakr_mod
				self.list = cache.get(wetrakr_mod.wetrakr_list, _ttl, url)
				if idx: self.worker()
			if self.list is None: self.list = []
			if create_directory: self.tvshowDirectory(self.list)
			return self.list
		except:
			from resources.lib.modules import log_utils
			log_utils.error()
			if not self.list:
				control.hide()
				if self.notifications: control.notification(title=32002, message=33049)

	def getTMDb(self, url, create_directory=True):
		self.list = []
		try:
			try: url = getattr(self, url + '_link')
			except: pass
			try: u = urlparse(url).netloc.lower()
			except: pass
			if u in self.tmdb_link and '/list/' in url:
				self.list = cache.get(tmdb_indexer().tmdb_collections_list, 0, url)
			elif u in self.tmdb_link and not '/list/' in url:
				self.list = tmdb_indexer().tmdb_list(url) # caching handled in list indexer
			if self.list is None: self.list = []
			lang_assist.register(url, self.list, 'tv', self.tmdb_language_links) # v2.0.08: titulos de Languages para el ayudante langhelper
			if create_directory: self.tvshowDirectory(self.list)
			return self.list
		except:
			from resources.lib.modules import log_utils
			log_utils.error()
			if not self.list:
				control.hide()
				if self.notifications: control.notification(title=32002, message=33049)

	def getTraktPublicLists(self, url, create_directory=True):
		self.list = []
		try:
			try: url = getattr(self, url + '_link')
			except: pass
			if '/popular' in url:
				self.list = cache.get(self.trakt_public_list, 168, url)
			elif '/trending' in url:
				self.list = cache.get(self.trakt_public_list, 48, url)
			else:
				self.list = cache.get(self.trakt_public_list, 24, url)
			if self.list is None: self.list = []
			if create_directory: self.addDirectory(self.list)
			return self.list
		except:
			from resources.lib.modules import log_utils
			log_utils.error()

	def traktHiddenManager(self, idx=True):
		control.busy()
		try:
			if trakt.getProgressActivity() > cache.timeout(self.trakt_list, self.progress_link, self.trakt_user): raise Exception()
			self.list = cache.get(self.trakt_list, 24, self.progress_link, self.trakt_user)
		except: self.list = cache.get(self.trakt_list, 0, self.progress_link, self.trakt_user)
		# v2.0.03: sin progreso que mostrar (Trakt sin respuesta o cuenta vacia)
		# el bucle de abajo petaba con None y el indicador de ocupado se quedaba
		# en pantalla.
		if not self.list:
			control.hide()
			return control.notification(title='Trakt Hidden Progress Manager', message=33049)

		for i in self.list:
			imdb, tvdb = i.get('imdb'), i.get('tvdb')
			try: indicators = getSeasonIndicators(imdb, tvdb)
			except: indicators = None
			count = getShowCount(indicators[1], imdb, tvdb) if indicators else None
			i.update({'watched_count': count})
		try:
			hidden = traktsync.fetch_hidden_progress()
			hidden = [str(i['tvdb']) for i in hidden]
			for i in self.list: i.update({'isHidden': 'true'}) if i['tvdb'] in hidden else i.update({'isHidden': ''})
			if idx: self.worker()
			self.list = sorted(self.list, key=lambda k: re.sub(r'(^the |^a |^an )', '', k['tvshowtitle'].lower()), reverse=False)
			self.list = sorted(self.list, key=lambda k: k['isHidden'], reverse=True)
			control.hide()
			from resources.lib.windows.trakthidden_manager import TraktHiddenManagerXML
			window = TraktHiddenManagerXML('trakthidden_manager.xml', control.addonPath(control.addonId()), results=self.list)
			chosen_hide, chosen_unhide = window.run()
			del window
			if chosen_unhide:
				success = trakt.unHideItems(chosen_unhide)
				if success: control.notification(title='Trakt Hidden Progress Manager', message='Successfully Unhid %s Item%s' % (len(chosen_unhide), 's' if len(chosen_unhide) >1 else ''))
			if chosen_hide:
				success = trakt.hideItems(chosen_hide)
				if success: control.notification(title='Trakt Hidden Progress Manager', message='Successfully Hid %s Item%s' % (len(chosen_hide), 's' if len(chosen_hide) >1 else ''))
		except:
			from resources.lib.modules import log_utils
			log_utils.error()
			control.hide()

	def collectionManager(self):
		try:
			control.busy()
			self.list = traktsync.fetch_collection('shows_collection')
			self.worker()
			self.sort()
			# self.list = sorted(self.list, key=lambda k: re.sub(r'(^the |^a |^an )', '', k['tvshowtitle'].lower()), reverse=False)
			control.hide()
			from resources.lib.windows.traktbasic_manager import TraktBasicManagerXML
			window = TraktBasicManagerXML('traktbasic_manager.xml', control.addonPath(control.addonId()), results=self.list)
			selected_items = window.run()
			del window
			if selected_items:
				# refresh = 'plugin.video.luc_kodi' in control.infoLabel('Container.PluginName')
				trakt.removeCollectionItems('shows', selected_items)
		except:
			from resources.lib.modules import log_utils
			log_utils.error()
			control.hide()

	def watchlistManager(self):
		try:
			control.busy()
			self.list = traktsync.fetch_watch_list('shows_watchlist')
			self.worker()
			self.sort(type='shows.watchlist')
			# self.list = sorted(self.list, key=lambda k: re.sub(r'(^the |^a |^an )', '', k['tvshowtitle'].lower()), reverse=False)
			control.hide()
			from resources.lib.windows.traktbasic_manager import TraktBasicManagerXML
			window = TraktBasicManagerXML('traktbasic_manager.xml', control.addonPath(control.addonId()), results=self.list)
			selected_items = window.run()
			del window
			if selected_items:
				# refresh = 'plugin.video.luc_kodi' in control.infoLabel('Container.PluginName')
				trakt.removeWatchlistItems('shows', selected_items)
		except:
			from resources.lib.modules import log_utils
			log_utils.error()
			control.hide()

	def sort(self, type='shows'):
		try:
			if not self.list: return
			attribute = int(getSetting('sort.%s.type' % type))
			reverse = int(getSetting('sort.%s.order' % type)) == 1
			if attribute == 0: reverse = False # Sorting Order is not enabled when sort method is "Default"
			if attribute > 0:
				if attribute == 1:
					try: self.list = sorted(self.list, key=lambda k: re.sub(r'(^the |^a |^an )', '', k['tvshowtitle'].lower()), reverse=reverse)
					except: self.list = sorted(self.list, key=lambda k: re.sub(r'(^the |^a |^an )', '', k['title'].lower()), reverse=reverse)
				elif attribute == 2: self.list = sorted(self.list, key=lambda k: float(k['rating']), reverse=reverse)
				elif attribute == 3: self.list = sorted(self.list, key=lambda k: int(str(k['votes']).replace(',', '')), reverse=reverse)
				elif attribute == 4:
					for i in range(len(self.list)):
						if 'premiered' not in self.list[i]: self.list[i]['premiered'] = ''
					self.list = sorted(self.list, key=lambda k: k['premiered'], reverse=reverse)
				elif attribute == 5:
					for i in range(len(self.list)):
						if 'added' not in self.list[i]: self.list[i]['added'] = ''
					self.list = sorted(self.list, key=lambda k: k['added'], reverse=reverse)
				elif attribute == 6:
					for i in range(len(self.list)):
						if 'lastplayed' not in self.list[i]: self.list[i]['lastplayed'] = ''
					self.list = sorted(self.list, key=lambda k: k['lastplayed'], reverse=reverse)
			elif reverse:
				self.list = list(reversed(self.list))
		except:
			from resources.lib.modules import log_utils
			log_utils.error()

	def tmdb_DiscoverSort(self):
		sort = int(getSetting('sort.shows.type'))
		tmdb_sort = 'popularity' # default sort=0
		if sort == 1: tmdb_sort = 'title'
		elif sort == 2: tmdb_sort = 'vote_average'
		elif sort == 3: tmdb_sort = 'vote_count'
		elif sort in (4, 5, 6): tmdb_sort = 'primary_release_date'
		tmdb_sort_order = '.asc' if (int(getSetting('sort.movies.order')) == 0) else '.desc'
		sort_string = tmdb_sort + tmdb_sort_order
		if sort == 2: sort_string = sort_string + '&vote_count.gte=500'
		return sort_string

	def search(self):
		from resources.lib.menus import navigator
		navigator.Navigator().addDirectoryItem(getLS(32603) % self.highlight_color, 'tvSearchnew', 'search.png', 'DefaultAddonsSearch.png', isFolder=False)
		from sqlite3 import dbapi2 as database
		try:
			if not control.existsPath(control.dataPath): control.makeFile(control.dataPath)
			dbcon = database.connect(control.searchFile)
			dbcur = dbcon.cursor()
			dbcur.executescript('''CREATE TABLE IF NOT EXISTS tvshow (ID Integer PRIMARY KEY AUTOINCREMENT, term);''')
			dbcur.execute('''SELECT * FROM tvshow ORDER BY ID DESC''')
			dbcur.connection.commit()
			lst = []
			delete_option = False
			for (id, term) in sorted(dbcur.fetchall(), key=lambda k: re.sub(r'(^the |^a |^an )', '', k[1].lower()), reverse=False):
				if term not in str(lst):
					delete_option = True
					navigator.Navigator().addDirectoryItem(term, 'tvSearchterm&name=%s' % term, 'search.png', 'DefaultAddonsSearch.png', isSearch=True, table='tvshow')
					lst += [(term)]
		except:
			from resources.lib.modules import log_utils
			log_utils.error()
		finally:
			try:
				dbcur.close()
			except Exception:
				pass
			try:
				dbcon.close()
			except Exception:
				pass
		if delete_option: navigator.Navigator().addDirectoryItem(32605, 'cache_clearSearch', 'tools.png', 'DefaultAddonService.png', isFolder=False)
		navigator.Navigator().endDirectory()

	def search_new(self):
		k = control.keyboard('', getLS(32010))
		k.doModal()
		q = k.getText() if k.isConfirmed() else None
		if not q: return control.closeAll()
		from sqlite3 import dbapi2 as database
		try:
			dbcon = database.connect(control.searchFile)
			dbcur = dbcon.cursor()
			dbcur.execute('''INSERT INTO tvshow VALUES (?,?)''', (None, q))
			dbcur.connection.commit()
		except:
			from resources.lib.modules import log_utils
			log_utils.error()
		finally:
			try:
				dbcur.close()
			except Exception:
				pass
			try:
				dbcon.close()
			except Exception:
				pass
		url = self.search_link + quote_plus(q)
		control.closeAll()
		control.execute('ActivateWindow(Videos,plugin://plugin.video.luc_kodi/?action=tvshows&url=%s,return)' % (quote_plus(url)))

	def search_term(self, name):
		url = self.search_link + quote_plus(name)
		self.get(url)

	def person(self):
		k = control.keyboard('', getLS(32010))
		k.doModal()
		q = k.getText().strip() if k.isConfirmed() else None
		if not q: return control.closeAll()
		url = self.tmdb_persons_link + quote_plus(q)
		control.closeAll()
		control.execute('ActivateWindow(Videos,plugin://plugin.video.luc_kodi/?action=tvPersons&url=%s,return)' % (quote_plus(url)))

	def persons(self, url):
		if url is None: self.list = cache.get(self.tmdb_person_list, 24, self.tmdb_personlist_link, 3)
		else: self.list = cache.get(self.tmdb_person_list, 1, url, 1)
		if self.list is None: self.list = []
		if self.list:
			for i in range(0, len(self.list)): self.list[i].update({'content': 'actors', 'icon': 'DefaultActor.png', 'action': 'tmdbTvshows'})
		self.addDirectory(self.list)
		return self.list

	def genres(self, url):
		try: url = getattr(self, url + '_link')
		except: pass
		genres = [
			('Action', 'action', True, '10759'), ('Adventure', 'adventure', True), ('Animation', 'animation', True, '16'), ('Anime', 'anime', False),
			('Biography', 'biography', True), ('Comedy', 'comedy', True, '35'), ('Crime', 'crime', True, '80'), ('Drama', 'drama', True, '18'),
			('Family', 'family', True, '10751'), ('Fantasy', 'fantasy', True), ('Game-Show', 'game_show', True), ('History', 'history', True),
			('Horror', 'horror', True), ('Music', 'music', True), ('Musical', 'musical', True), ('Mystery', 'mystery', True, '9648'),
			('News', 'news', True, '10763'), ('Reality', 'reality_tv', True, '10764'), ('Romance', 'romance', True), ('Science Fiction', 'sci_fi', True, '10765'),
			('Sport', 'sport', True), ('Talk-Show', 'talk_show', True, '10767'), ('Thriller', 'thriller', True), ('War', 'war', True, '10768'), ('Western', 'western', True, '37')]
		for i in genres:
			if self.tmdb_link in url:
				try: self.list.append({'content': 'genres', 'name': cleangenre.lang(i[0], self.lang), 'url': url % ('%s', i[3]), 'image': control.genreArt(i[0]), 'icon': control.genreArt(i[0]), 'action': 'tmdbTvshows'})
				except: pass
		self.addDirectory(self.list)
		return self.list

	def networks(self):
		networks = tmdb_indexer().get_networks()
		for i in networks:
			self.list.append({'content': 'studios', 'name': i[0], 'url': self.tmdb_networks_link % ('%s', i[1]), 'image': i[2], 'icon': i[2], 'action': 'tmdbTvshows'})
		self.addDirectory(self.list)
		return self.list

	def watchproviders(self):
		# Same curated platforms as Movies > Streaming, minus the film-only ones.
		from resources.lib.indexers.tmdb import Movies as tmdb_movies, WATCHPROVIDERS_FILM_ONLY
		for i in tmdb_movies().get_watchproviders():
			if i[0] in WATCHPROVIDERS_FILM_ONLY: continue
			url = self.tmdb_watchproviders_link % ('%s', i[1])
			region = i[3] if len(i) > 3 and i[3] else 'US'
			if region != 'US': url = url.replace('watch_region=US', 'watch_region=%s' % region)
			self.list.append({'content': 'studios', 'name': i[0], 'url': url, 'image': i[2], 'icon': i[2], 'action': 'tmdbTvshows'})
		self.addDirectory(self.list)
		return self.list

	def originals(self):
		originals = tmdb_indexer().get_originals()
		for i in originals:
			self.list.append({'content': 'studios', 'name': i[0], 'url': self.tmdb_networks_link % ('%s', i[1]), 'image': i[2], 'icon': i[2], 'action': 'tmdbTvshows'})
		self.addDirectory(self.list)
		return self.list

	def languages(self):
		# v2.0.04: fuera bosnio, bulgaro, croata, macedonio, serbio y esloveno (muy poco catalogo),
		# y persa, panyabi, hebreo, hungaro, griego, ucraniano e islandes (casi nada con fuentes en cache)
		languages = [
			('Arabic', 'ar'), ('Chinese', 'zh'), ('Dutch', 'nl'), ('English', 'en'), ('Finnish', 'fi'),
			('French', 'fr'), ('German', 'de'), ('Hindi ', 'hi'), ('Italian', 'it'),
			('Japanese', 'ja'), ('Korean', 'ko'), ('Norwegian', 'no'), ('Polish', 'pl'), ('Portuguese', 'pt'), ('Romanian', 'ro'), ('Russian', 'ru'), ('Spanish', 'es'), ('Swedish', 'sv'), ('Turkish', 'tr')]
		for i in languages:
			self.list.append({'content': 'countries', 'name': str(i[0]), 'url': self.tmdb_language_link % ('%s', i[1]), 'image': control.flagArt(i[1]), 'icon': control.flagArt(i[1]), 'action': 'tvLanguageMenu'})
		self.addDirectory(self.list)
		return self.list

	def language_menu(self, url):
		"""v2.0.08: submenu de un idioma. url es su lista Popular, de la que se saca el
		codigo. Popular, New y Top rated son de las plataformas; Everything no."""
		m = re.search(r'with_original_language=([a-z]{2})', url or '')
		if not m: return self.addDirectory([])
		code = m.group(1)
		for label, link in ((40102, self.tmdb_language_link), (40103, self.tmdb_language_new_link), (40104, self.tmdb_language_top_link), (40105, self.tmdb_language_all_link)):
			self.list.append({'content': 'countries', 'name': getLS(label), 'url': link % ('%s', code), 'image': control.flagArt(code), 'icon': control.flagArt(code), 'action': 'tmdbTvshows'})
		self.addDirectory(self.list)
		return self.list

	def years(self, url):
		try: url = getattr(self, url + '_link')
		except: pass
		year = (self.date_time.strftime('%Y'))
		for i in range(int(year), YEAR_FIRST - 1, -1): # v2.0.04: hasta 1960
			if self.tmdb_link in url: self.list.append({'content': 'years', 'name': str(i), 'url': url % ('%s', str(i)), 'image': 'calendar.png', 'icon': 'DefaultYear.png', 'action': 'tmdbTvshows'})
		self.addDirectory(self.list)
		return self.list

	def tvshowsListToLibrary(self, url):
		url = getattr(self, url + '_link')
		u = urlparse(url).netloc.lower()
		try:
			control.hide()
			if u in self.tmdb_link: items = tmdb_indexer().userlists(url)
			elif u in self.trakt_link:
				if url in self.traktlikedlists_link:
					items = self.traktLikedLists()
				else: items = self.trakt_user_lists(url, self.trakt_user)
			items = [(i['name'], i['url']) for i in items]
			message = 32663
			if 'themoviedb' in url: message = 32681
			select = control.selectDialog([i[0] for i in items], getLS(message))
			list_name = items[select][0]
			if select == -1: return
			link = items[select][1]
			link = link.split('&sort_by')[0]
			link = link.split('?limit=')[0]
			from resources.lib.modules import library
			library.libtvshows().range(link, list_name)
		except:
			from resources.lib.modules import log_utils
			log_utils.error()

	def userlists(self):
		userlists = []
		try:
			if not self.traktCredentials: raise Exception()
			activity = trakt.getActivity()
			self.list = [] ; lists = []
			try:
				if activity > cache.timeout(self.trakt_user_lists, self.traktlists_link, self.trakt_user): raise Exception()
				lists += cache.get(self.trakt_user_lists, 720, self.traktlists_link, self.trakt_user)
			except: lists += cache.get(self.trakt_user_lists, 0, self.traktlists_link, self.trakt_user)
			userlists += lists
		except: pass
		try:
			if self.tmdb_session_id == '': raise Exception()
			self.list = []
			url = self.tmdb_link + '/3/account/{account_id}/lists?api_key=%s&language=en-US&session_id=%s&page=1' % ('%s', self.tmdb_session_id)
			lists = cache.get(tmdb_indexer().userlists, 0, url)
			for i in range(len(lists)): lists[i].update({'image': 'tmdb.png', 'icon': 'DefaultVideoPlaylists.png', 'action': 'tmdbTvshows'})
			userlists += lists
		except: pass
		self.list = []
		for i in range(len(userlists)): # Filter the user's own lists that were
			contains = False
			adapted = userlists[i]['url'].replace('/me/', '/%s/' % self.trakt_user)
			for j in range(len(self.list)):
				if adapted == self.list[j]['url'].replace('/me/', '/%s/' % self.trakt_user):
					contains = True
					break
			if not contains: self.list.append(userlists[i])
		if self.tmdb_session_id != '': # TMDb Favorites
			url = self.tmdb_link + '/3/account/{account_id}/favorite/tv?api_key=%s&session_id=%s&sort_by=created_at.asc&page=1' % ('%s', self.tmdb_session_id)
			self.list.insert(0, {'name': getLS(32026), 'url': url, 'image': 'tmdb.png', 'icon': 'DefaultVideoPlaylists.png', 'action': 'tmdbTvshows'})
		if self.tmdb_session_id != '': # TMDb Watchlist
			url = self.tmdb_link + '/3/account/{account_id}/watchlist/tv?api_key=%s&session_id=%s&sort_by=created_at.asc&page=1' % ('%s', self.tmdb_session_id)
			self.list.insert(0, {'name': getLS(32033), 'url': url, 'image': 'tmdb.png', 'icon': 'DefaultVideoPlaylists.png', 'action': 'tmdbTvshows'})
		self.addDirectory(self.list)
		return self.list

	def traktCollection(self, url, create_directory=True):
		self.list = []
		try:
			q = dict(parse_qsl(urlsplit(url).query))
			index = int(q['page']) - 1
			self.list = traktsync.fetch_collection('shows_collection')
			self.sort() # sort before local pagination
			if getSetting('trakt.paginate.lists') == 'true' and self.list:
				paginated_ids = [self.list[x:x + int(self.page_limit)] for x in range(0, len(self.list), int(self.page_limit))]
				self.list = paginated_ids[index]
			try:
				if int(q['limit']) != len(self.list): raise Exception()
				q.update({'page': str(int(q['page']) + 1)})
				q = (urlencode(q)).replace('%2C', ',')
				next = url.replace('?' + urlparse(url).query, '') + '?' + q
			except: next = ''
			for i in range(len(self.list)): self.list[i]['next'] = next
			self.worker()
			if self.list is None: self.list = []
			if create_directory: self.tvshowDirectory(self.list)
			return self.list
		except:
			from resources.lib.modules import log_utils
			log_utils.error()

	def traktWatchlist(self, url, create_directory=True):
		self.list = []
		try:
			q = dict(parse_qsl(urlsplit(url).query))
			index = int(q['page']) - 1
			self.list = traktsync.fetch_watch_list('shows_watchlist')
			# 2026 self-heal: si la tabla local esta vacia pero hay credenciales
			# Trakt, el marcador last_watchlisted_at quedo envenenado por una
			# sync fallida (cambio de API 30-jun-2026) y el servicio nunca
			# reintenta. Forzamos una sync inline con backoff de 10 min.
			if not self.list and trakt.getTraktCredentialsInfo():
				import time as _t
				_prop = 'luc_kodi.watchlist_selfheal.shows_watchlist'
				_last = control.homeWindow.getProperty(_prop)
				if not _last or (int(_t.time()) - int(_last)) > 600:
					control.homeWindow.setProperty(_prop, str(int(_t.time())))
					trakt.sync_watch_list(forced=True)
					self.list = traktsync.fetch_watch_list('shows_watchlist')
			self.sort(type='shows.watchlist') # sort before local pagination
			if getSetting('trakt.paginate.lists') == 'true' and self.list:
				paginated_ids = [self.list[x:x + int(self.page_limit)] for x in range(0, len(self.list), int(self.page_limit))]
				self.list = paginated_ids[index]
			try:
				if int(q['limit']) != len(self.list): raise Exception()
				q.update({'page': str(int(q['page']) + 1)})
				q = (urlencode(q)).replace('%2C', ',')
				next = url.replace('?' + urlparse(url).query, '') + '?' + q
			except: next = ''
			for i in range(len(self.list)): self.list[i]['next'] = next
			self.worker()
			if self.list is None: self.list = []
			if create_directory: self.tvshowDirectory(self.list)
			return self.list
		except:
			from resources.lib.modules import log_utils
			log_utils.error()

	def traktLikedLists(self):
		items = traktsync.fetch_liked_list('', True)
		for item in items:
			try:
				if item['content_type'] == 'movies': continue
				list_name = item['list_name']
				list_owner = item['list_owner']
				list_owner_slug = item['list_owner_slug']
				list_id = item['trakt_id']
				list_url = self.traktlist_link % (list_owner_slug, list_id)
				next = ''
				label = '%s - [COLOR %s]%s[/COLOR]' % (list_name, self.highlight_color, list_owner)
				self.list.append({'name': label, 'list_type': 'traktPulicList', 'url': list_url, 'list_owner': list_owner, 'list_name': list_name, 'list_id': list_id, 'context': list_url, 'next': next, 'image': 'trakt.png', 'icon': 'DefaultVideoPlaylists.png', 'action': 'tvshows'})
			except:
				from resources.lib.modules import log_utils
				log_utils.error()
		self.list = sorted(self.list, key=lambda k: re.sub(r'(^the |^a |^an )', '', k['name'].lower()))
		self.addDirectory(self.list, queue=True)
		return self.list

	def trakt_list(self, url, user):
		self.list = []
		if ',return' in url: url = url.split(',return')[0]
		# 2026-06-30 Trakt API: /watched endpoints are paginated (100-item cap without
		# params). If the caller did not build local pagination into the url, fetch all pages.
		# v1.0.95: cualquier URL sin limit= (importar a la biblioteca la
		# watchlist, la coleccion o una lista) necesita recorrer todas las paginas
		if 'limit=' not in url:
			items = trakt.getTraktAsJsonPaginated(url, page_size=250, apply_sort=True)
		else:
			items = trakt.getTraktAsJson(url)
		if not items: return
		try:
			q = dict(parse_qsl(urlsplit(url).query))
			if int(q['limit']) != len(items): raise Exception()
			q.update({'page': str(int(q['page']) + 1)})
			q = (urlencode(q)).replace('%2C', ',')
			next = url.replace('?' + urlparse(url).query, '') + '?' + q
		except: next = ''
		for item in items: # rating and votes via TMDb, or I must use `extended=full and it slows down
			try:
				values = {}
				values['next'] = next 
				values['added'] = item.get('listed_at', '')
				values['paused_at'] = item.get('paused_at', '') # for unfinished
				try: values['progress'] = item['progress']
				except: values['progress'] = ''
				try: values['lastplayed'] = item['watched_at'] # for history
				except: values['lastplayed'] = ''
				show = item.get('show') or item
				values['title'] = show.get('title')
				values['originaltitle'] = values['title']
				values['tvshowtitle'] = values['title']
				values['year'] = str(show.get('year')) if show.get('year') else ''
				ids = show.get('ids', {})
				values['imdb'] = str(ids.get('imdb', '')) if ids.get('imdb') else ''
				values['tmdb'] = str(ids.get('tmdb', '')) if ids.get('tmdb') else ''
				values['tvdb'] = str(ids.get('tvdb', '')) if ids.get('tvdb') else ''
				self.list.append(values)
			except:
				from resources.lib.modules import log_utils
				log_utils.error()
		return self.list

	def trakt_userList(self, url, create_directory=True):
		self.list = []
		q = dict(parse_qsl(urlsplit(url).query))
		index = int(q['page']) - 1
		def userList_allItems(url):
			# v1.0.95 (issue #1): la URL llegaba sin limit/page y getTraktAsJson
			# no pagina. Desde el 15-abr-2026 Trakt devuelve entonces solo la
			# primera pagina de la lista (100) y el resto no aparecia nunca.
			# Renombrada ademas para no reutilizar 48 h la cache truncada.
			items = trakt.getTraktAsJsonPaginated(url, page_size=250, apply_sort=True)
			if not items: return
			for item in items:
				try:
					values = {}
					values['added'] = item.get('listed_at', '')
					show = item.get('show')
					if not show: continue
					values['title'] = show.get('title')
					values['originaltitle'] = values['title']
					values['tvshowtitle'] = values['title']
					try: values['premiered'] = show.get('first_aired', '')[:10]
					except: values['premiered'] = ''
					values['year'] = str(show.get('year', '')) if show.get('year') else ''
					if not values['year']:
						try: values['year'] = str(values['premiered'][:4])
						except: values['year'] = ''
					ids = show.get('ids', {})
					values['imdb'] = str(ids.get('imdb', '')) if ids.get('imdb') else ''
					values['tmdb'] = str(ids.get('tmdb', '')) if ids.get('tmdb') else ''
					values['tvdb'] = str(ids.get('tvdb')) if ids.get('tvdb', '') else ''
					values['rating'] = show.get('rating')
					values['votes'] = show.get('votes')
					# v1.0.95: airs puede faltar o venir null (series de streaming o
					# terminadas); airs['day'] lanzaba y la serie se descartaba entera
					airs = show.get('airs') or {}
					values['airday'] = airs.get('day') or ''
					values['airtime'] = airs.get('time') or ''
					values['airzone'] = airs.get('timezone') or ''
					self.list.append(values)
				except:
					from resources.lib.modules import log_utils
					log_utils.error()
			return self.list
		self.list = cache.get(userList_allItems, 48, url.split('?')[0] + '?extended=full')
		if not self.list: return
		self.sort() # sort before local pagination
		total_pages = 1
		if getSetting('trakt.paginate.lists') == 'true':
			paginated_ids = [self.list[x:x + int(self.page_limit)] for x in range(0, len(self.list), int(self.page_limit))]
			total_pages = len(paginated_ids)
			self.list = paginated_ids[index]
		try:
			if int(q['limit']) != len(self.list): raise Exception()
			if int(q['page']) == total_pages: raise Exception()
			q.update({'page': str(int(q['page']) + 1)})
			q = (urlencode(q)).replace('%2C', ',')
			next = url.replace('?' + urlparse(url).query, '') + '?' + q
		except: next = ''
		for i in range(len(self.list)): self.list[i]['next'] = next
		self.worker()
		if self.list is None: self.list = []
		if create_directory: self.tvshowDirectory(self.list)
		return self.list

	def trakt_user_lists(self, url, user):
		items = traktsync.fetch_user_lists('', True)
		for item in items:
			try:
				if item['content_type'] == 'movies': continue
				list_name = item['list_name']
				list_owner = item['list_owner']
				list_owner_slug = item['list_owner_slug']
				list_id = item['trakt_id']
				list_url = self.traktlist_link % (list_owner_slug, list_id)
				next = ''
				label = '%s - [COLOR %s]%s[/COLOR]' % (list_name, self.highlight_color, list_owner)
				self.list.append({'name': label, 'url': list_url, 'list_owner': list_owner, 'list_name': list_name, 'list_id': list_id, 'context': list_url, 'next': next, 'image': 'trakt.png', 'icon': 'DefaultVideoPlaylists.png', 'action': 'tvshows'})
			except:
				from resources.lib.modules import log_utils
				log_utils.error()
		self.list = sorted(self.list, key=lambda k: re.sub(r'(^the |^a |^an )', '', k['name'].lower()))
		return self.list

	def trakt_public_list(self, url):
		# v2.0.03: sin respuesta de Trakt (red caida, 5xx) getTrakt devuelve None;
		# antes eso dejaba 'items' sin definir y fallaba tambien la cache.
		items = []
		try:
			response = trakt.getTrakt(url)
			if response is not None: items = response.json() or []
		except:
			from resources.lib.modules import log_utils
			log_utils.error()
		try:
			q = dict(parse_qsl(urlsplit(url).query))
			if int(q['limit']) != len(items): raise Exception()
			q.update({'page': str(int(q['page']) + 1)})
			q = (urlencode(q)).replace('%2C', ',')
			next = url.replace('?' + urlparse(url).query, '') + '?' + q
		except: next = ''

		for item in items:
			try:
				if item.get('type', '') == 'officiallist': continue #seems bugy so until Justin replies hold off
				list_item = item.get('list', {})
				list_name = list_item.get('name', '')
				list_id = list_item.get('ids', {}).get('trakt', '')
				list_owner = list_item.get('user', {}).get('username', '')
				list_owner_slug = list_item.get('user', {}).get('ids', {}).get('slug', '')
				if any(list_item.get('privacy', '') == value for value in ('private', 'friends')): continue
				list_url = self.traktlist_link % (list_owner_slug, list_id)
				list_content = traktsync.fetch_public_list(list_id)
				if not list_content: pass
				else: 
					if list_content.get('content_type', '') == 'movies': continue
				label = '%s - [COLOR %s]%s[/COLOR]' % (list_name, self.highlight_color, list_owner)
				self.list.append({'name': label, 'list_type': 'traktPulicList', 'url': list_url, 'list_owner': list_owner, 'list_name': list_name, 'list_id': list_id, 'context': list_url, 'next': next, 'image': 'trakt.png', 'icon': 'trakt.png', 'action': 'tvshows'})
			except:
				from resources.lib.modules import log_utils
				log_utils.error()
		return self.list

	def tmdb_person_list(self, url, pages=1):
		"""v2.0.04: personas de TMDb (busqueda o populares). Cada una abre sus
		series (tmdb_person_link)."""
		return [{'name': name, 'url': self.tmdb_person_link % (pid, '%s'), 'image': photo or 'people.png'}
			for pid, name, photo in tmdb_indexer().people(url, pages)]

	def worker(self):
		try:
			if not self.list: return
			self.meta = []
			total = len(self.list)
			for i in range(0, total): self.list[i].update({'metacache': False})
			self.list = metacache.fetch(self.list, self.lang, self.user)
			for r in range(0, total, 40):
				threads = []
				append = threads.append
				for i in range(r, r + 40):
					if i < total: append(Thread(target=self.super_info, args=(i,)))
				[i.start() for i in threads]
				[i.join() for i in threads]
			if self.meta: metacache.insert(self.meta)
			self.list = [i for i in self.list if i.get('tmdb') or i.get('tvdb')]
		except:
			from resources.lib.modules import log_utils
			log_utils.error()

	def super_info(self, i):
		# Envoltura del precache (v1.0.81). Sin semaforo ni deadline se comporta
		# exactamente igual que antes.
		if self.precache_deadline and _now() > self.precache_deadline: return
		if self.precache_sem is None: return self._super_info(i)
		self.precache_sem.acquire()
		try: return self._super_info(i)
		finally: self.precache_sem.release()

	def _super_info(self, i):
		try:
			if self.list[i]['metacache']: return
			imdb, tmdb, tvdb = self.list[i].get('imdb', ''), self.list[i].get('tmdb', ''), self.list[i].get('tvdb', '')
#### -- Missing id's lookup -- ####
			trakt_ids = None
			if (not tmdb or not tvdb) and imdb: trakt_ids = trakt.IdLookup('imdb', imdb, 'show')
			elif (not tmdb or not imdb) and tvdb: trakt_ids = trakt.IdLookup('tvdb', tvdb, 'show')
			if trakt_ids:
				if not imdb: imdb = str(trakt_ids.get('imdb', '')) if trakt_ids.get('imdb') else ''
				if not tmdb: tmdb = str(trakt_ids.get('tmdb', '')) if trakt_ids.get('tmdb') else ''
				if not tvdb: tvdb = str(trakt_ids.get('tvdb', '')) if trakt_ids.get('tvdb') else ''
			if not tmdb and (imdb or tvdb):
				try:
					result = cache.get(tmdb_indexer().IdLookup, 96, imdb, tvdb)
					tmdb = str(result.get('id', '')) if result.get('id') else ''
				except: tmdb = ''
			if not imdb or not tmdb or not tvdb:
				try:
					results = trakt.SearchTVShow(quote_plus(self.list[i]['title']), self.list[i]['year'], full=False)
					if results[0]['show']['title'].lower() != self.list[i]['title'].lower() or int(results[0]['show']['year']) != int(self.list[i]['year']): return # Trakt has "THEM" and "Them" twice for same show, use .lower()
					ids = results[0].get('show', {}).get('ids', {})
					if not imdb: imdb = str(ids.get('imdb', '')) if ids.get('imdb') else ''
					if not tmdb: tmdb = str(ids.get('tmdb', '')) if ids.get('tmdb') else ''
					if not tvdb: tvdb = str(ids.get('tvdb', '')) if ids.get('tvdb') else ''
				except: pass
#################################
			if not tmdb:
				if getSetting('debug.level') != '1': return
				from resources.lib.modules import log_utils
				return log_utils.log('tvshowtitle: (%s) missing tmdb_id: ids={imdb: %s, tmdb: %s, tvdb: %s}' % (self.list[i]['title'], imdb, tmdb, tvdb), __name__, log_utils.LOGDEBUG) # log TMDb shows that they do not have
			showSeasons = tmdb_indexer().get_showSeasons_meta(tmdb)
			if not showSeasons or '404:NOT FOUND' in showSeasons: return # trakt search turns up alot of junk with wrong tmdb_id's
			values = {}
			values.update(showSeasons)
			if 'rating' in self.list[i] and self.list[i]['rating']: values['rating'] = self.list[i]['rating'] # prefer imdb,trakt rating and votes if set
			if 'votes' in self.list[i] and self.list[i]['votes']: values['votes'] = self.list[i]['votes']
			if 'year' in self.list[i] and self.list[i]['year'] != values.get('year'): values['year'] = self.list[i]['year']
			if not tvdb: tvdb = values.get('tvdb', '')
			if not values.get('imdb'): values['imdb'] = imdb
			if not values.get('tmdb'): values['tmdb'] = tmdb
			if not values.get('tvdb'): values['tvdb'] = tvdb
			if self.lang != 'en':
				try:
					if 'available_translations' in self.list[i] and self.lang not in self.list[i]['available_translations']: raise Exception()
					trans_item = trakt.getTVShowTranslation(imdb, lang=self.lang, full=True)
					if trans_item:
						if trans_item.get('title') and not self.prefer_en_titles: # con títulos EN activos solo se traduce la sinopsis
							values['tvshowtitle'] = trans_item.get('title')
							values['title'] = trans_item.get('title')
						if trans_item.get('overview'): values['plot'] =trans_item.get('overview')
				except:
					from resources.lib.modules import log_utils
					log_utils.error()
			if self.enable_fanarttv:
				extended_art = fanarttv_cache.get(FanartTv().get_tvshow_art, 336, tvdb)
				if extended_art: values.update(extended_art)
			values = dict((k, v) for k, v in iter(values.items()) if v is not None and v != '') # remove empty keys so .update() doesn't over-write good meta with empty values.
			self.list[i].update(values)
			meta = {'imdb': imdb, 'tmdb': tmdb, 'tvdb': tvdb, 'lang': self.lang, 'user': self.user, 'item': values}
			self.meta.append(meta)
		except:
			from resources.lib.modules import log_utils
			log_utils.error()

	def tvshowDirectory(self, items, next=True):
		from sys import argv # some functions like ActivateWindow() throw invalid handle less this is imported here.
		from resources.lib.modules import navstate; navstate.note_list() # v2.0.09: Exit list
		control.playlist.clear()
		if not items: # with reuselanguageinvoker on an empty directory must be loaded, do not use sys.exit()
			control.hide() ; control.notification(title=32002, message=33049)
		sysaddon, syshandle = 'plugin://plugin.video.luc_kodi/', int(argv[1])
		is_widget = 'plugin' not in control.infoLabel('Container.PluginName')
		settingFanart = getSetting('fanart') == 'true'
		addonPoster, addonFanart, addonBanner = control.missingPoster(), control.missingFanart(), control.addonBanner() # v2.0.04: aviso si falta el arte
		flatten = int(getSetting('flatten.tvshows'))
		if trakt.getTraktIndicatorsInfo(): watchedMenu, unwatchedMenu = getLS(32068), getLS(32069)
		else: watchedMenu, unwatchedMenu = getLS(32066), getLS(32067)
		traktManagerMenu, queueMenu = getLS(32070), getLS(32065)
		showPlaylistMenu, clearPlaylistMenu = getLS(35517), getLS(35516)
		playRandom, addToLibrary = getLS(32535), getLS(32551)
		nextMenu, findSimilarMenu = getLS(32053), getLS(32184)
		for i in items:
			try:
				imdb, tmdb, tvdb, year, trailer = i.get('imdb', ''), i.get('tmdb', ''), i.get('tvdb', ''), i.get('year', ''), i.get('trailer', '')
				title = label = i.get('tvshowtitle') or i.get('title')
				systitle = quote_plus(title)
				try:
					premiered = i['premiered']
					if (not premiered and i['status'] in ('Rumored', 'Planned', 'In Production', 'Post Production', 'Upcoming')) or (int(re.sub('[^0-9]', '', premiered)) > int(re.sub('[^0-9]', '', str(self.today_date)))):
						label = '[COLOR %s]%s [I][Coming Soon][/I][/COLOR]' % (self.unairedcolor, label)
				except: pass
				try: indicators = getSeasonIndicators(imdb, tvdb)
				except: indicators = None
				meta = dict((k, v) for k, v in iter(i.items()) if v is not None and v != '')
				meta.update({'code': imdb, 'imdbnumber': imdb, 'mediatype': 'tvshow', 'tag': [imdb, tmdb]}) # "tag" and "tagline" for movies only, but works in my skin mod so leave
				try: meta.update({'genre': cleangenre.lang(meta['genre'], self.lang)})
				except: pass
				try:
					if 'tvshowtitle' not in meta: meta.update({'tvshowtitle': title})
				except: pass
				if self.prefer_tmdbArt:
					poster = meta.get('poster3') or meta.get('poster') or meta.get('poster2') or addonPoster
					clearlogo = meta.get('tmdblogo') or meta.get('clearlogo', '')
				else:
					poster = meta.get('poster2') or meta.get('poster3') or meta.get('poster') or addonPoster
					clearlogo = meta.get('clearlogo') or meta.get('tmdblogo', '')
				poster = poster_rotator.rotate(meta, poster) # rotación de pósters TMDb (si está activada)
				landscape = meta.get('landscape')
				fanart = ''
				if settingFanart:
					if self.prefer_tmdbArt: fanart = meta.get('fanart3') or meta.get('fanart') or meta.get('fanart2') or addonFanart
					else: fanart = meta.get('fanart2') or meta.get('fanart3') or meta.get('fanart') or addonFanart
				thumb = meta.get('thumb') or poster or landscape # set to show level poster
				icon = meta.get('icon') or poster
				banner = meta.get('banner3') or meta.get('banner2') or meta.get('banner') or addonBanner
				art = {}
				art.update({'poster': poster, 'tvshow.poster': poster, 'fanart': fanart, 'icon': icon, 'thumb': thumb, 'banner': banner, 'clearlogo': clearlogo,
						'tvshow.clearlogo': clearlogo, 'clearart': meta.get('clearart', ''), 'tvshow.clearart': meta.get('clearart', ''), 'landscape': landscape})
				for k in ('metacache', 'meta_light', 'poster2', 'poster3', 'posters_all', 'fanart2', 'fanart3', 'banner2', 'banner3', 'trailer'): meta.pop(k, None)
				meta.update({'poster': poster, 'fanart': fanart, 'banner': banner, 'thumb': thumb, 'icon': icon})
				sysmeta, sysart = quote_plus(jsdumps(meta)), quote_plus(jsdumps(art))
				if flatten:
					total_seasons = meta.get('total_seasons')
					if flatten == 2 and total_seasons < 2: url = '%s?action=episodes&tvshowtitle=%s&year=%s&imdb=%s&tmdb=%s&tvdb=%s&meta=%s' % (sysaddon, systitle, year, imdb, tmdb, tvdb, sysmeta)
					elif flatten == 1: url = '%s?action=episodes&tvshowtitle=%s&year=%s&imdb=%s&tmdb=%s&tvdb=%s&meta=%s' % (sysaddon, systitle, year, imdb, tmdb, tvdb, sysmeta)
					else: url = '%s?action=seasons&tvshowtitle=%s&year=%s&imdb=%s&tmdb=%s&tvdb=%s&art=%s' % (sysaddon, systitle, year, imdb, tmdb, tvdb, sysart)
				else: url = '%s?action=seasons&tvshowtitle=%s&year=%s&imdb=%s&tmdb=%s&tvdb=%s&art=%s' % (sysaddon, systitle, year, imdb, tmdb, tvdb, sysart)

####-Context Menu and Overlays-####
				cm = []
				try:
					watched = (getTVShowOverlay(indicators[1], imdb, tvdb) == '5') if indicators else False
					if self.traktCredentials:
						cm.append((traktManagerMenu, 'RunPlugin(%s?action=tools_traktManager&name=%s&imdb=%s&tvdb=%s&watched=%s)' % (sysaddon, systitle, imdb, tvdb, watched)))
					from resources.lib.modules.mdblist import getMDBListCredentialsInfo as _mdb_ok
					if _mdb_ok() and imdb:
						cm.append((getLS(40220), 'RunPlugin(%s?action=mdblist_Manager&name=%s&imdb=%s&media_type=show)' % (sysaddon, systitle, imdb)))
					try: # v1.0.91: SIMKL (valoraciones y listas)
						from resources.lib.modules.simkl import getSimklCredentialsInfo as _simkl_ok
						if _simkl_ok() and imdb:
							cm.append((getLS(400843), 'RunPlugin(%s?action=simklManager&name=%s&imdb=%s&media_type=show)' % (sysaddon, systitle, imdb)))
					except Exception: pass
					try: # v1.0.99: WeTrakr Manager
						if getattr(self, '_wt_ok', None) is None:
							from resources.lib.modules.wetrakr import getWeTrakrCredentialsInfo as _wt_ok
							self._wt_ok = _wt_ok()
						if self._wt_ok and (imdb or tmdb):
							cm.append((getLS(47050), 'RunPlugin(%s?action=wetrakr_Manager&name=%s&imdb=%s&tmdb=%s&tvdb=%s&media_type=show)' % (sysaddon, systitle, imdb, tmdb, tvdb)))
					except Exception: pass
					try: # v2.0.09: PunchPlay Manager
						if getattr(self, '_pp_ok', None) is None:
							from resources.lib.modules.punchplay import getPunchPlayCredentialsInfo as _pp_ok
							self._pp_ok = _pp_ok()
						if self._pp_ok and (imdb or tmdb):
							cm.append((getLS(46060), 'RunPlugin(%s?action=punchplay_Manager&name=%s&imdb=%s&tmdb=%s&tvdb=%s&media_type=show)' % (sysaddon, systitle, imdb, tmdb, tvdb)))
					except Exception: pass
					try: # v2.0.16: TVmaze Manager (follow / unfollow)
						if getattr(self, '_tm_ok', None) is None:
							from resources.lib.modules.tvmaze import getTVmazeCredentialsInfo as _tm_ok
							self._tm_ok = _tm_ok()
						if self._tm_ok and (imdb or tvdb):
							cm.append((getLS(49027), 'RunPlugin(%s?action=tvmaze_Manager&name=%s&imdb=%s&tvdb=%s&media_type=show)' % (sysaddon, systitle, imdb, tvdb)))
					except Exception: pass
					if watched:
						meta.update({'playcount': 1, 'overlay': 5})
						cm.append((unwatchedMenu, 'RunPlugin(%s?action=playcount_TVShow&name=%s&imdb=%s&tvdb=%s&query=4)' % (sysaddon, systitle, imdb, tvdb)))
					else:
						meta.update({'playcount': 0, 'overlay': 4})
						cm.append((watchedMenu, 'RunPlugin(%s?action=playcount_TVShow&name=%s&imdb=%s&tvdb=%s&query=5)' % (sysaddon, systitle, imdb, tvdb)))
				except: pass
				cm.append((findSimilarMenu, 'Container.Update(%s?action=tvshows&url=%s)' % (sysaddon, quote_plus('https://api.trakt.tv/shows/%s/related?limit=20&page=1,return' % imdb))))
				# v1.0.44: tráiler keyless — usa el id de TMDb ya presente en meta['trailer'] si existe
				cm.append(('Play Trailer', 'PlayMedia(%s?action=play_Trailer&type=show&name=%s&year=%s&imdb=%s&tmdb=%s&url=%s)' % (sysaddon, systitle, year, imdb, tmdb, quote_plus(trailer) if trailer else '')))
				cm.append((playRandom, 'RunPlugin(%s?action=play_Random&rtype=season&tvshowtitle=%s&year=%s&imdb=%s&tmdb=%s&tvdb=%s&art=%s)' % (sysaddon, systitle, year, imdb, tmdb, tvdb, sysart)))
				# cm.append((queueMenu, 'RunPlugin(%s?action=playlist_QueueItem&name=%s)' % (sysaddon, systitle)))
				# cm.append((showPlaylistMenu, 'RunPlugin(%s?action=playlist_Show)' % sysaddon))
				# cm.append((clearPlaylistMenu, 'RunPlugin(%s?action=playlist_Clear)' % sysaddon))
				cm.append((addToLibrary, 'RunPlugin(%s?action=library_tvshowToLibrary&tvshowtitle=%s&year=%s&imdb=%s&tmdb=%s&tvdb=%s)' % (sysaddon, systitle, year, imdb, tmdb, tvdb)))
				if str(meta.get('status') or '').lower() not in ('ended', 'canceled'): # v2.0.0: Premiere Lists
					cm.append((getLS(32701), 'RunPlugin(%s?action=library_premiereAdd&tvshowtitle=%s&year=%s&imdb=%s&tmdb=%s&tvdb=%s)' % (sysaddon, systitle, year, imdb, tmdb, tvdb)))
				cm.append(('[COLOR red]luc_kodi Settings[/COLOR]', 'RunPlugin(%s?action=tools_openSettings)' % sysaddon))
				# ── Feedback explícito (solo visible en listas de recomendaciones) ──
				fb_tmdb = i.get('_fb_tmdb', '')
				if fb_tmdb:
					fb_mt     = quote_plus(i.get('_fb_media_type', 'tv'))
					fb_genres = quote_plus(i.get('_fb_genres', ''))
					fb_title  = quote_plus(i.get('tvshowtitle') or i.get('title', ''))
					cm.insert(0, ('[COLOR limegreen][B]More like this[/B][/COLOR]',  'RunPlugin(%s?action=reco_feedback&signal=1&tmdb=%s&title=%s&media_type=%s&genres=%s)'  % (sysaddon, fb_tmdb, fb_title, fb_mt, fb_genres)))
					cm.insert(1, ('[COLOR red][B]Not interested[/B][/COLOR]', 'RunPlugin(%s?action=reco_feedback&signal=-1&tmdb=%s&title=%s&media_type=%s&genres=%s)' % (sysaddon, fb_tmdb, fb_title, fb_mt, fb_genres)))
####################################
				if trailer: meta.update({'trailer': trailer}) # removed temp so it's not passed to CM items, only skin
				else: meta.update({'trailer': '%s?action=play_Trailer&type=%s&name=%s&year=%s&imdb=%s' % (sysaddon, 'show', systitle, year, imdb)})
				item = control.item(label=label, offscreen=True)
				item.setArt({k: v for k, v in art.items() if v is not None})  # Kodi 22 avisa por cada None
				try: 
					count = getShowCount(indicators[1], imdb, tvdb) if indicators else None # if indicators and no matching imdb_id in watched items then it returns None and we use TMDb meta to avoid Trakt request
					if count:
						item.setProperties({'WatchedEpisodes': str(count['watched']), 'UnWatchedEpisodes': str(count['unwatched'])})
						item.setProperties({'TotalSeasons': str(meta.get('total_seasons', '')), 'TotalEpisodes': str(count['total'])})
					else:
						if KODI_VERSION < 20: item.setProperties({'WatchedEpisodes': '0', 'UnWatchedEpisodes': str(meta.get('total_aired_episodes', ''))}) # for shows never watched
						else: item.setProperties({'UnWatchedEpisodes': str(meta.get('total_aired_episodes', ''))}) # for shows never watched
						item.setProperties({'TotalSeasons': str(meta.get('total_seasons', '')), 'TotalEpisodes': str(meta.get('total_aired_episodes', ''))})
				except: pass
				item.setProperty('tmdb_id', str(tmdb))
				if is_widget: item.setProperty('isluc_kodi_widget', 'true')
				control.infoTagger(item, meta)
				attach_cm(item, cm)
				control.addItem(handle=syshandle, url=url, listitem=item, isFolder=True)
			except:
				from resources.lib.modules import log_utils
				log_utils.error()
		if next:
			try:
				if not items: raise Exception()
				url = items[0]['next']
				if not url: raise Exception()
				url_params = dict(parse_qsl(urlsplit(url).query))
				page = '  [I](%s)[/I]' % url_params.get('page')
				nextMenu = '[COLOR skyblue]' + nextMenu + page + '[/COLOR]'
				u = urlparse(url).netloc.lower()
				if u in self.trakt_link:
					url = '%s?action=tvshowPage&url=%s' % (sysaddon, quote_plus(url))
				elif u in self.tmdb_link:
					url = '%s?action=tmdbTvshowPage&url=%s' % (sysaddon, quote_plus(url))
				item = control.item(label=nextMenu, offscreen=True)
				icon = control.addonNext()
				item.setArt({'icon': icon, 'thumb': icon, 'poster': icon, 'banner': icon})
				item.setProperty ('SpecialSort', 'bottom')
				control.addItem(handle=syshandle, url=url, listitem=item, isFolder=True)
			except:
				from resources.lib.modules import log_utils
				log_utils.error()
		control.content(syshandle, 'tvshows')
		control.directory(syshandle, cacheToDisc=False) # disable cacheToDisc so unwatched counts loads fresh data counts if changes made
		control.sleep(200) # da tiempo al skin a renderizar antes de forzar el view (igual que movieDirectory); sin esto las páginas 2+ se quedan en list en vez de wall
		views.setView('tvshows', {'skin.estuary': 500, 'skin.confluence': 500})

	def addDirectory(self, items, queue=False):
		from sys import argv # some functions like ActivateWindow() throw invalid handle less this is imported here.
		from resources.lib.modules import navstate; navstate.note_menu() # v2.0.09: Exit list
		control.playlist.clear()
		if not items: # with reuselanguageinvoker on an empty directory must be loaded, do not use sys.exit()
			content = '' ; control.hide() ; control.notification(title=32002, message=33049)
		sysaddon, syshandle = 'plugin://plugin.video.luc_kodi/', int(argv[1])
		addonThumb = control.addonThumb()
		artPath = control.artPath()
		queueMenu, playRandom, addToLibrary = getLS(32065), getLS(32535), getLS(32551)
		likeMenu, unlikeMenu = getLS(32186), getLS(32187)
		for i in items:
			try:
				content = i.get('content', '')
				name = i['name']
				if i['image'].startswith('http'): poster = i['image']
				elif artPath: poster = control.joinPath(artPath, i['image'])
				else: poster = addonThumb
				if content == 'genres':
					icon = control.joinPath(control.genreIconPath(), i['icon']) or 'DefaultFolder.png'
					poster = control.joinPath(control.genrePosterPath(), i['image']) or addonThumb
				else:
					icon = i['icon']
					if icon.startswith('http'): pass
					elif not icon.startswith('Default'): icon = control.joinPath(artPath, icon)
				url = '%s?action=%s' % (sysaddon, i['action'])
				try: url += '&url=%s' % quote_plus(i['url'])
				except: pass
				# ── Bingie modern grid (perfil 'bingie'): items de submenú que
				#    apuntan a listados de series se abren en la ventana propia. ──
				try:
					from resources.lib.modules import views
					if views.getViewStyle() == 'bingie':
						_a = i['action']
						_tmdb = '&tmdb=1' if _a in ('tmdbTvshows', 'tmdbTvshowPage') else ''
						if _a in ('tvshows', 'tvshowPage', 'tmdbTvshows', 'tmdbTvshowPage'):
							url = url.replace('?action=%s' % _a, '?action=bingie_gridTVShows', 1)
							url += '&title=%s%s' % (quote_plus(name), _tmdb)
				except Exception: pass
				cm = []
				if (i.get('list_type', '') == 'traktPulicList') and self.traktCredentials:
					liked = traktsync.fetch_liked_list(i['list_id'])
					if not liked:
						cm.append((likeMenu, 'RunPlugin(%s?action=tools_likeList&list_owner=%s&list_name=%s&list_id=%s)' % (sysaddon, quote_plus(i['list_owner']), quote_plus(i['list_name']), i['list_id'])))
					else:
						name = '[COLOR %s][Liked][/COLOR] %s' % (self.highlight_color, name)
						cm.append((unlikeMenu, 'RunPlugin(%s?action=tools_unlikeList&list_owner=%s&list_name=%s&list_id=%s)' % (sysaddon, quote_plus(i['list_owner']), quote_plus(i['list_name']), i['list_id'])))
				cm.append((playRandom, 'RunPlugin(%s?action=play_Random&rtype=show&url=%s)' % (sysaddon, quote_plus(i['url']))))
				if queue: cm.append((queueMenu, 'RunPlugin(%s?action=playlist_QueueItem)' % sysaddon))
				try:
					if getSetting('library.service.update') == 'true':
						cm.append((addToLibrary, 'RunPlugin(%s?action=library_tvshowsToLibrary&url=%s&name=%s)' % (sysaddon, quote_plus(i['context']), name)))
				except: pass
				cm.append(('[COLOR red]luc_kodi Settings[/COLOR]', 'RunPlugin(%s?action=tools_openSettings)' % sysaddon))
				item = control.item(label=name, offscreen=True)
				item.setArt({'icon': icon, 'poster': poster, 'thumb': poster, 'fanart': control.addonFanart(), 'banner': poster})
				item.setInfo(type='video', infoLabels={'plot': name}) if KODI_VERSION < 20 else item.getVideoInfoTag().setPlot(name)
				attach_cm(item, cm)
				_isFolder = False if 'action=bingie_grid' in url else True
				control.addItem(handle=syshandle, url=url, listitem=item, isFolder=_isFolder)
			except:
				from resources.lib.modules import log_utils
				log_utils.error()
		try:
			if not items: raise Exception()
			url = items[0].get('next', '')
			if url == '': raise Exception()
			url_params = dict(parse_qsl(urlsplit(url).query))
			nextMenu = getLS(32053)
			page = '  [I](%s)[/I]' % url_params.get('page')
			nextMenu = '[COLOR skyblue]' + nextMenu + page + '[/COLOR]'
			icon = control.addonNext()
			url = '%s?action=tv_PublicLists&url=%s' % (sysaddon, quote_plus(url))
			item = control.item(label=nextMenu, offscreen=True)
			item.setArt({'icon': icon, 'thumb': icon, 'poster': icon, 'banner': icon})
			item.setProperty ('SpecialSort', 'bottom')
			control.addItem(handle=syshandle, url=url, listitem=item, isFolder=True)
		except:
			from resources.lib.modules import log_utils
			log_utils.error()

		skin = control.skin
		if skin == 'skin.arctic.horizon': pass
		elif skin in ('skin.estuary', 'skin.aeon.nox.silvo'): content = ''
		elif skin == 'skin.auramod':
			if content not in ('actors', 'genres'): content = 'addons'
			else: content = ''
		control.content(syshandle, content) # some skins use their own thumb for things like "genres" when content type is set here
		control.directory(syshandle, cacheToDisc=True)
