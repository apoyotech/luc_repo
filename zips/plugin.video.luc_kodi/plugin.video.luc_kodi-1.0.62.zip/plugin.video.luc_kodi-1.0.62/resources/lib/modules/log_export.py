# -*- coding: utf-8 -*-
"""
	luc_kodi Add-on — log_export.py (v1.0.65)

	Escribe una copia saneada de kodi.log que se pueda compartir.

	POR QUE HACE FALTA. `client.scrub_url()` solo limpia lo que loguea ESTE
	addon. La linea que de verdad filtra credenciales la escribe KODI:

	  CCurlFile::Open - <https://<instancia>/stremio/torz/<base64>/_/strem/...

	Ese base64 decodifica a {"stores":[{"c":"pm","t":"<apikey del debrid>"}]}.
	Kodi la escribe en cuanto hay debug activo y el addon no puede evitarlo.
	Resultado: cualquier log que un usuario comparta lleva su clave dentro.

	ESTRATEGIA. La regla fuerte no es adivinar formatos, es **redactar por
	valor**: se leen los secretos que el propio addon tiene guardados y se
	tachan alli donde aparezcan, en claro o en base64. Lo que no se conozca
	cae en las reglas genericas, que son la red y no la defensa principal.
"""

import base64
import binascii
import json
import os
import re

from resources.lib.modules import control
from resources.lib.modules import log_utils
from resources.lib.jacksparrow import client

LOGINFO = log_utils.LOGINFO

# Ajustes cuyo VALOR es un secreto. Se tachan por valor exacto.
SECRET_SETTINGS = (
	'premiumize.token', 'realdebrid.token', 'realdebrid.secret', 'realdebrid.client_id',
	'realdebrid.refresh', 'alldebrid.token', 'torbox.token', 'debridlink.token',
	'debridlink.refresh', 'offcloud.token', 'easydebrid.token',
	'torz.config', 'comet.config', 'sootio.config', 'meteor.config_token',
	'mediafusion.secret', 'aiostreams.uuid', 'aiostreams.password',
	'trakt.token', 'trakt.refresh', 'simkl.token', 'mdblist.api', 'tmdb.api',
	'fanart.api', 'omdb.api', 'orion.api',
)

# Claves que, dentro de un JSON en base64, marcan el objeto como credencial.
CRED_KEYS = ('t', 'token', 'apikey', 'api_key', 'password', 'secret', 'key')

GENERIC = (
	# UUID en cualquier posicion
	(re.compile(r'(?i)\b[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}\b'), '<UUID>'),
	# Cabecera Basic
	(re.compile(r'(?i)(authorization:\s*(?:basic|bearer)\s+)\S+'), r'\1<REDACTED>'),
	# Parametros de query con pinta de credencial
	(re.compile(r'(?i)([?&](?:api_?key|token|password|passwd|secret|access_token|refresh_token)=)[^&\s<>"\']+'),
	 r'\1<REDACTED>'),
)

# base64 suelto de al menos 16 chars, que es donde viven los blobs de config.
B64 = re.compile(r'[A-Za-z0-9+/]{16,}={0,2}')


def _looks_credential(blob):
	"""True si el base64 decodifica a JSON con una clave de credencial."""
	try:
		pad = blob + '=' * (-len(blob) % 4)
		raw = base64.b64decode(pad, validate=True)
	except (binascii.Error, ValueError):
		return False
	try:
		obj = json.loads(raw.decode('utf-8', 'strict'))
	except Exception:
		return False

	def walk(node):
		if isinstance(node, dict):
			for k, v in node.items():
				if str(k).lower() in CRED_KEYS and isinstance(v, str) and v:
					return True
				if walk(v):
					return True
		elif isinstance(node, list):
			for v in node:
				if walk(v):
					return True
		return False

	return walk(obj)


def _secrets():
	"""Valores reales a tachar, mas su forma en base64."""
	out = set()
	for sid in SECRET_SETTINGS:
		try:
			val = (control.setting(sid) or '').strip()
		except Exception:
			continue
		# Los muy cortos causarian falsos positivos por todo el log.
		if len(val) < 8:
			continue
		out.add(val)
		try:
			out.add(base64.b64encode(val.encode()).decode())
		except Exception:
			pass
	return sorted(out, key=len, reverse=True)


def _sanitize_line(line, secrets):
	for sec in secrets:
		if sec in line:
			line = line.replace(sec, '<REDACTED>')
	for pattern, repl in GENERIC:
		line = pattern.sub(repl, line)
	# base64 que decodifica a algo con pinta de credencial
	def _b64(m):
		blob = m.group(0)
		return '<REDACTED_CONFIG>' if _looks_credential(blob) else blob
	line = B64.sub(_b64, line)
	# Y por ultimo las reglas del addon sobre cualquier URL que quede.
	for url in re.findall(r'https?://[^\s<>"\']+', line):
		try:
			line = line.replace(url, client.scrub_url(url))
		except Exception:
			pass
	return line


def run():
	try:
		# v1.0.71: antes solo se saneaba kodi.log. Pero la actividad de los
		# scrapers va, POR DEFECTO, a jacksparrowscrapers.log — o sea que el
		# boton hecho para poder compartir logs sin filtrar credenciales
		# ignoraba justo el fichero que hace falta para diagnosticar.
		secrets = _secrets()
		done, missing = [], []
		for fname in ('kodi.log', 'jacksparrowscrapers.log'):
			log_path = control.transPath('special://logpath/%s' % fname)
			if not os.path.exists(log_path):
				missing.append(fname)
				continue
			out_path = control.transPath(
				'special://logpath/%s-sanitized.log' % fname.replace('.log', ''))
			hits, total = 0, 0
			with open(log_path, 'r', encoding='utf-8', errors='replace') as src, \
			     open(out_path, 'w', encoding='utf-8') as dst:
				for line in src:
					total += 1
					clean = _sanitize_line(line, secrets)
					if clean != line:
						hits += 1
					dst.write(clean)
			control.log('[ luc_kodi ] log_export: %s -> %s/%s lineas saneadas'
			            % (fname, hits, total), LOGINFO)
			done.append((out_path, hits, total))

		if not done:
			control.okDialog(message='No log files were found to sanitize.')
			return
		body = '[COLOR ff00fa9a]Written.[/COLOR]\n\n'
		for out_path, hits, total in done:
			body += '%s\n%d of %d lines had something redacted.\n\n' % (out_path, hits, total)
		if missing:
			body += '[COLOR ff888888]Not present: %s[/COLOR]\n\n' % ', '.join(missing)
		body += ('Check them before sharing: this removes what it recognises, '
		         'not everything that could ever identify you.')
		control.okDialog('Sanitized log', body)
	except Exception:
		log_utils.error()
		control.okDialog(message='The sanitized log could not be written. See the log for details.')
