# -*- coding: utf-8 -*-
"""
	luc_kodi Add-on — provider_test.py (v1.0.64)

	Test de proveedores. Inspirado en speedtest.py de plugin.video.pov, pero
	midiendo TRES cosas por separado en vez de una.

	pov cuenta cuantos resultados devuelve cada proveedor y ordena por tiempo.
	El problema es que un 0 ahi no dice nada: no sabes si al proveedor le falta
	el token, si el host esta caido, o si esa pelicula simplemente no esta.
	Aqui se separan:

	  CONFIGURADO  ¿hay credenciales? — se lee el ajuste de token del proveedor.
	  ALCANZABLE   ¿responde el host? — peticion corta, independiente del titulo.
	  PRODUCTIVO   ¿devuelve resultados? — sources() contra un IMDb fijo.

	Un proveedor CONFIGURADO + ALCANZABLE + 0 resultados es un catalogo sin esa
	peli. CONFIGURADO + NO alcanzable es una instancia caida. NO configurado es
	cosa del usuario. Son tres arreglos distintos y por eso son tres columnas.

	El tiempo por proveedor va aparte, y es lo que habria cantado a la cara que
	AIOStreams tardaba de mas en las pasadas de packs.
"""

import json
import threading
import time

import xbmc
import xbmcgui

from resources.lib.modules import control
from resources.lib.modules import log_utils
from resources.lib.jacksparrow import client

LOGINFO = log_utils.LOGINFO

# Pelicula de prueba. Popular y antigua a proposito: si un proveedor no la
# tiene, el problema es del proveedor, no del catalogo.
DEFAULT_TEST = {
	'imdb': 'tt0468569', 'title': 'The Dark Knight', 'year': '2008',
}

# Ajuste que guarda el token de cada proveedor Custom, para la columna
# CONFIGURADO. Los que no aparecen aqui no llevan credenciales propias.
TOKEN_SETTING = {
	'torz':        'torz.config',
	'comet':       'comet.config',
	'sootio':      'sootio.config',
	'meteor':      'meteor.config_token',
	'mediafusion': 'mediafusion.secret',
	'aiostreams':  'aiostreams.uuid',
}

# v1.0.69 — el test se estorbaba a si mismo. Medido en el log del 22-ago:
# lanzado dos veces seguidas, la SEGUNDA tanda daba sootio 0 en 90,14 s,
# aiostreams 0 en 30,10 s, mediafusion 0 en 20,11 s y torrentio 0 en 30,07 s,
# cuando minutos antes habian dado 139, 120, 29 y 38. No eran catalogos vacios:
# eran timeouts. Diecinueve proveedores en paralelo, cada uno abriendo sus
# propios hilos, cayendo encima de las conexiones que la ronda anterior todavia
# no habia soltado.
#
# Un test que miente en la columna de resultados es peor que no tener test, asi
# que van tres frenos: tope de concurrencia, cerrojo contra ejecuciones
# solapadas y periodo de reposo entre tandas.
MAX_PARALLEL = 4
COOLDOWN = 60           # segundos de reposo recomendados entre tandas
RUN_FLAG = 'luc_kodi.provider_test.running'
LAST_END = 'luc_kodi.provider_test.lastend'

OK, BAD, NA = '[COLOR ff00fa9a]OK[/COLOR]', '[COLOR ffff4444]NO[/COLOR]', '[COLOR ff888888]--[/COLOR]'


def _configured(name):
	sid = TOKEN_SETTING.get(name)
	if not sid:
		return None  # no aplica: proveedor sin credenciales
	try:
		return bool((control.setting(sid) or '').strip())
	except Exception:
		return False


def _enabled(name):
	try:
		return control.setting('provider.%s' % name) == 'true'
	except Exception:
		return False


def _reachable(module):
	"""Peticion corta al host del proveedor, sin depender del titulo."""
	# Los seis Custom exponen self.base_link; los demas puede que no.
	base = getattr(module, 'base_link', '') or ''
	if not base:
		return None
	try:
		start = time.time()
		# output='headers': si el host responde algo, devuelve un dict; si esta
		# caido o no resuelve, None. No existe un modo 'responsecode' en
		# client.request — comprobado antes de escribir esto.
		# v1.0.67: error=True es imprescindible. Con el valor por defecto,
		# client.request devuelve None ante CUALQUIER codigo de error HTTP, asi
		# que un host que contesta 404 en su raiz —zilean y meteor, medido—
		# salia como "NO alcanzable" mientras devolvia 161 y 99 resultados.
		# Que el host CONTESTE es lo que se mide aqui; que conteste 200 en la
		# raiz no es asunto nuestro. Solo un fallo de DNS o de conexion cuenta.
		resp = client.request(base, timeout='8', output='headers', error=True)
		return (resp is not None, time.time() - start)
	except Exception:
		return (False, 0.0)


def _run_one(entry, data, gate):
	"""gate es un Semaphore: se adquiere ANTES de arrancar el cronometro, para
	que el tiempo medido sea el del proveedor y no el de la espera en la cola."""
	name, module = entry[0], entry[1]
	gate.acquire()
	row = {'name': name, 'configured': _configured(name),
	       'enabled': _enabled(name),
	       'reachable': None, 'reach_time': 0.0,
	       'results': None, 'elapsed': 0.0, 'error': ''}
	try:
		inst = module()
		r = _reachable(inst)
		if r is not None:
			row['reachable'], row['reach_time'] = r
		start = time.time()
		res = inst.sources(dict(data), {})
		row['elapsed'] = time.time() - start
		# None y [] son cosas DISTINTAS: None es fallo del scraper, [] es
		# "no tengo esa peli". Colapsarlos es el fallo de diseno de pov.
		row['results'] = None if res is None else len(res)
	except Exception as e:
		row['error'] = str(e)[:60]
		log_utils.error()
	finally:
		gate.release()
	return row


def _label(row):
	cfg = NA if row['configured'] is None else (OK if row['configured'] else BAD)
	rch = NA if row['reachable'] is None else (OK if row['reachable'] else BAD)
	if row['results'] is None:
		res = '[COLOR ffff4444]FALLO[/COLOR]'
	elif row['results'] == 0:
		res = '[COLOR fffdb515]0[/COLOR]'
	else:
		res = '[COLOR ff00fa9a]%d[/COLOR]' % row['results']
	enb = OK if row['enabled'] else '[COLOR ff888888]off[/COLOR]'
	line2 = 'Enabled: %s   Configured: %s   Reachable: %s   Results: %s   %.2fs' % (
		enb, cfg, rch, res, row['elapsed'])
	if row['error']:
		line2 += '   [COLOR ffff4444]%s[/COLOR]' % row['error']
	return line2


def run():
	try:
		# v1.0.65 fix: era sources_mod.sources(), y la clase se llama Sources.
		# Ademas instanciarla arrastra resolutores de debrid y hosters premium
		# solo para listar modulos. fs_sources() es el enumerador real y es lo
		# unico que hace falta: devuelve [(nombre, clase source), ...].
		from resources.lib.jacksparrow import sources as fs_sources
		from resources.lib.jacksparrow import workers
	except Exception:
		log_utils.error()
		control.okDialog(message='Could not load the source modules.')
		return

	# Cerrojo: una segunda tanda encima de la primera falsea las dos.
	try:
		running = control.homeWindow.getProperty(RUN_FLAG)
		if running and (time.time() - int(running)) < 360:
			control.okDialog('Provider test', 'A test is already running. Let it finish first.')
			return
		last = control.homeWindow.getProperty(LAST_END)
		if last and (time.time() - int(last)) < COOLDOWN:
			wait = COOLDOWN - int(time.time() - int(last))
			if not control.yesnoDialog(
					'The last test finished %d seconds ago. Providers still have connections open, '
					'so running again now will report working providers as timed out.\n\n'
					'Wait about %d more seconds for numbers you can trust.'
					% (int(time.time() - int(last)), wait),
					'', '', heading='Too soon'):
				return
	except Exception:
		pass

	imdb = control.dialog.input('IMDb id of a movie to test with', DEFAULT_TEST['imdb'])
	if not imdb:
		return
	data = {'imdb': imdb.strip(), 'title': DEFAULT_TEST['title'],
	        'year': DEFAULT_TEST['year'], 'aliases': [], 'localtitle': ''}
	if imdb.strip() != DEFAULT_TEST['imdb']:
		# Titulo desconocido: check_title() descartaria todo. Se avisa en vez de
		# devolver ceros que parecerian fallos de los proveedores.
		control.okDialog(message='Using a custom IMDb id: titles are matched by name, '
		                         'so results may read as 0 unless the title matches. '
		                         'The Configured and Reachable columns stay valid.')

	try:
		# ret_all=True: incluye tambien los DESACTIVADOS. En un test de
		# proveedores interesa ver el que esta apagado, no esconderlo.
		entries = [(n, cls) for n, cls in fs_sources(ret_all=True)
		           if getattr(cls, 'hasMovies', False)]
	except Exception:
		log_utils.error()
		control.okDialog(message='Could not enumerate the providers.')
		return
	if not entries:
		control.okDialog(message='No providers were found.')
		return

	progress = xbmcgui.DialogProgress()
	progress.create('Provider test', 'Starting...')
	rows, total = [], len(entries)
	try:
		control.homeWindow.setProperty(RUN_FLAG, str(int(time.time())))
	except Exception:
		pass
	gate = threading.Semaphore(MAX_PARALLEL)
	threads = [workers.Thread(lambda e=e: rows.append(_run_one(e, data, gate))) for e in entries]
	for t in threads:
		t.start()
	# Con la concurrencia limitada la tanda tarda mas de reloj, asi que el tope
	# sube: cortarla antes de tiempo produciria justo los ceros falsos que
	# estamos eliminando.
	deadline = time.time() + 300
	while any(t.is_alive() for t in threads) and time.time() < deadline:
		if progress.iscanceled():
			break
		done = len(rows)
		progress.update(int(done / float(total) * 100),
		                'Testing %d providers, %d at a time...[CR]Finished: %d / %d'
		                % (total, MAX_PARALLEL, done, total))
		xbmc.sleep(200)
	progress.close()
	try:
		control.homeWindow.setProperty(LAST_END, str(int(time.time())))
		control.homeWindow.clearProperty(RUN_FLAG)
	except Exception:
		pass

	rows.sort(key=lambda r: (not r['enabled'], r['results'] is None, -(r['results'] or 0), r['elapsed']))
	for r in rows:
		control.log('[ luc_kodi ] provider_test: %s' % json.dumps(r, sort_keys=True), LOGINFO)

	items = []
	for r in rows:
		li = xbmcgui.ListItem(r['name'].upper(), offscreen=True)
		li.setLabel2(_label(r))
		items.append(li)
	xbmcgui.Dialog().select('Provider test — %s' % data['imdb'], items, useDetails=True)
