# -*- coding: utf-8 -*-
"""
	luc_kodi Add-on — modules/usenet_mkv.py

	v2.0.37 (Lucian, 19-nov-2026): un articulo que falta y no se puede tapar de
	ninguna forma (ni respaldo ni otro post) se rellenaba con ceros. En un MKV
	los ceros caen en mitad de un bloque: el demuxer lee basura, pierde el hilo
	y se ve un fallo de imagen. Aqui se busca el elemento del Cluster donde
	empieza el hueco y se tapa desde el con un elemento EBML Void hasta el final
	del Cluster (y, si el hueco sigue, otro Void hasta el siguiente Cluster de
	los Cues, que empieza en un fotograma clave). El demuxer salta los Void: el
	video da un salto limpio en vez de un fallo. Lo hace tambien AIOStreams
	(usenet: 'repair MKV holes with EBML Void fill instead of raw zeros').

	Solo lectura de cabeceras EBML; nada que dependa de Kodi.
"""

ID_EBML = 0x1A45DFA3
ID_SEGMENT = 0x18538067
ID_SEEKHEAD = 0x114D9B74
ID_SEEK = 0x4DBB
ID_SEEKID = 0x53AB
ID_SEEKPOS = 0x53AC
ID_CUES = 0x1C53BB6B
ID_CUEPOINT = 0xBB
ID_CUETRACKPOS = 0xB7
ID_CUECLUSTERPOS = 0xF1
ID_CLUSTER = 0x1F43B675
ID_VOID = 0xEC
ID_INFO = 0x1549A966          # v2.0.43: Segment Info
ID_TIMECODESCALE = 0x2AD7B1
ID_DURATION = 0x4489


class MkvError(Exception):
	pass


def read_id(buf, i):
	"""-> (id con sus bits de longitud, siguiente indice)."""
	if i >= len(buf):
		raise MkvError('short id')
	b = buf[i]
	n = 1
	while n <= 4 and not (b & (0x80 >> (n - 1))):
		n += 1
	if n > 4 or i + n > len(buf):
		raise MkvError('bad id')
	return int.from_bytes(buf[i:i + n], 'big'), i + n


def read_size(buf, i):
	"""-> (tamano o None si es 'desconocido', siguiente indice)."""
	if i >= len(buf):
		raise MkvError('short size')
	b = buf[i]
	n = 1
	while n <= 8 and not (b & (0x80 >> (n - 1))):
		n += 1
	if n > 8 or i + n > len(buf):
		raise MkvError('bad size')
	v = b & (0xFF >> n)
	for x in buf[i + 1:i + n]:
		v = (v << 8) | x
	if v == (1 << (7 * n)) - 1:
		return None, i + n
	return v, i + n


def _children(buf, i, end):
	while i < end:
		eid, j = read_id(buf, i)
		size, k = read_size(buf, j)
		if size is None:
			raise MkvError('unknown size')
		yield eid, i, k, k + size
		i = k + size


def _uint(buf, i, j):
	return int.from_bytes(buf[i:j], 'big')


def segment_head(head):
	"""De los primeros KB del fichero: (inicio de los datos del Segment,
	posicion absoluta de los Cues o None)."""
	eid, j = read_id(head, 0)
	if eid != ID_EBML:
		raise MkvError('not EBML')
	size, k = read_size(head, j)
	i = k + (size or 0)
	eid, j = read_id(head, i)
	if eid != ID_SEGMENT:
		raise MkvError('no Segment')
	_size, seg = read_size(head, j)
	cues = None
	try:
		for eid, s, d, e in _children(head, seg, len(head)):
			if eid == ID_SEEKHEAD:
				for sid, _s, sd, se in _children(head, d, min(e, len(head))):
					if sid != ID_SEEK:
						continue
					what = pos = None
					for fid, _fs, fd, fe in _children(head, sd, se):
						if fid == ID_SEEKID:
							what = _uint(head, fd, fe)
						elif fid == ID_SEEKPOS:
							pos = _uint(head, fd, fe)
					if what == ID_CUES and pos is not None:
						cues = seg + pos
				break
			if eid == ID_CLUSTER:
				break
	except MkvError:
		pass
	return seg, cues


def segment_duration(head):
	"""v2.0.43: duracion real en segundos del Segment Info (Duration x
	TimecodeScale), de los primeros KB del fichero. None si no esta ahi."""
	import struct
	try:
		eid, j = read_id(head, 0)
		if eid != ID_EBML:
			return None
		size, k = read_size(head, j)
		i = k + (size or 0)
		eid, j = read_id(head, i)
		if eid != ID_SEGMENT:
			return None
		_size, seg = read_size(head, j)
		for eid, s, d, e in _children(head, seg, len(head)):
			if eid == ID_CLUSTER:
				return None
			if eid != ID_INFO:
				continue
			if e > len(head):
				return None
			scale, dur = 1000000, None
			for fid, _fs, fd, fe in _children(head, d, e):
				if fid == ID_TIMECODESCALE:
					scale = _uint(head, fd, fe) or 1000000
				elif fid == ID_DURATION:
					n = fe - fd
					if n == 8:
						dur = struct.unpack('>d', bytes(head[fd:fe]))[0]
					elif n == 4:
						dur = struct.unpack('>f', bytes(head[fd:fe]))[0]
			if dur and dur > 0:
				secs = dur * scale / 1e9
				return secs if 60 <= secs <= 86400 else None
			return None
	except (MkvError, struct.error, ValueError):
		return None
	return None


def cues_element(buf):
	"""Del principio de los Cues: el tamano total del elemento."""
	eid, j = read_id(buf, 0)
	if eid != ID_CUES:
		raise MkvError('not Cues')
	size, k = read_size(buf, j)
	if size is None:
		raise MkvError('unknown Cues size')
	return k + size


def cue_clusters(cues, seg):
	"""Posiciones absolutas (ordenadas, sin repetir) de los Clusters que los
	Cues senalan: cada uno empieza en un fotograma clave."""
	eid, j = read_id(cues, 0)
	if eid != ID_CUES:
		raise MkvError('not Cues')
	size, k = read_size(cues, j)
	out = set()
	for pid, _ps, pd, pe in _children(cues, k, min(len(cues), k + (size or len(cues)))):
		if pid != ID_CUEPOINT:
			continue
		for tid, _ts, td, te in _children(cues, pd, pe):
			if tid != ID_CUETRACKPOS:
				continue
			for cid, _cs, cd, ce in _children(cues, td, te):
				if cid == ID_CUECLUSTERPOS:
					out.add(seg + _uint(cues, cd, ce))
	return sorted(out)


def void_bytes(length):
	"""Un elemento Void de exactamente 'length' bytes (minimo 2)."""
	if length < 2:
		raise MkvError('void too short')
	if length >= 9:
		return b'\xec\x01' + (length - 9).to_bytes(7, 'big') + bytes(length - 9)
	n = length - 1                       # tamano 0 escrito en n bytes
	return b'\xec' + bytes([0x80 >> (n - 1)]) + bytes(n - 1)


def plan(read, clusters, hole_start, hole_end):
	"""Los Void que tapan [hole_start, hole_end). read(pos, n) -> bytes del
	fichero (lo que haya; los huecos vienen como ceros). -> [(start, end)] o []
	si no se puede hacer limpio (el hueco toca la cabecera del Cluster, tamanos
	desconocidos, sin Cues)."""
	from bisect import bisect_right
	k = bisect_right(clusters, hole_start) - 1
	if k < 0:
		return []
	c = clusters[k]
	# del Cluster de los Cues al que contiene el hueco (los que no llevan
	# fotograma clave no estan en los Cues): de elemento en elemento
	while True:
		if c + 12 > hole_start:
			return []                    # la cabecera del Cluster esta en el hueco
		head = read(c, 12)
		eid, j = read_id(head, 0)
		size, d = read_size(head, j)
		if size is None:
			return []
		c_data, c_end = c + d, c + d + size
		if hole_start < c_end:
			if eid != ID_CLUSTER or hole_start < c_data:
				return []
			break
		c = c_end
	pos, elem = c_data, None
	while pos < c_end:
		if pos + 12 > hole_start:
			elem = pos                   # su cabecera ya toca el hueco: desde aqui
			break
		h = read(pos, 12)
		eid, j = read_id(h, 0)
		esize, k2 = read_size(h, j)
		if esize is None:
			return []
		nxt = pos + k2 + esize
		if nxt > hole_start:
			elem = pos
			break
		pos = nxt
	if elem is None or c_end - elem < 2:
		return []
	out = [(elem, c_end)]
	if hole_end > c_end:
		k3 = bisect_right(clusters, hole_end - 1)
		if k3 >= len(clusters):
			return []                    # no hay un Cluster limpio despues
		nxt = clusters[k3]
		if nxt - c_end >= 2:
			out.append((c_end, nxt))
		elif nxt != c_end:
			return []
	return out
