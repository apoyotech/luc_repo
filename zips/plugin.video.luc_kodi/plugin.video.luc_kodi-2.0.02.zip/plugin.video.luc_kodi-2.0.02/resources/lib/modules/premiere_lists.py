# -*- coding: utf-8 -*-
"""
	luc_kodi Add-on

	v2.0.0 - Premiere Lists.
	Listas con nombre propio donde el usuario aparta series que aun no se han
	estrenado o temporadas nuevas de series que sigue. El servicio vuelve a
	mirar la fecha en TMDb cada 12 horas, avisa el dia antes, y cuando el
	estreno ya se ha emitido lo mete en la biblioteca con las mismas reglas que
	libtvshows (solo lo emitido, retraso de 24 h incluido).

	Estados de un elemento:
	  waiting    sin fecha, o con fecha a mas de WINDOW_DAYS dias
	  scheduled  con fecha dentro de la ventana
	  added      ya en la biblioteca; se borra solo a los KEEP_ADDED_DAYS dias

	v2.0.02 - sincronizacion entre aparatos (premiere_sync.py).
	Cada lista lleva un uid que no cambia de un aparato a otro y cada lista y
	cada elemento un sello 'updated' (UTC). Lo que se borra deja una lapida
	en premiere_tombstones para que la sincronizacion no lo resucite:
	  user  lo quito el usuario; los demas aparatos tambien lo quitan
	  done  salio solo de la lista tras entrar en la biblioteca; los demas
	        aparatos lo terminan por su cuenta (su biblioteca puede ser otra)
	Solo viaja lo que decide el usuario. 'state', 'notified', 'added_on' y
	premiere_meta son de cada aparato, y las fechas las relee cada uno en TMDb.
"""
from datetime import datetime, timedelta
from sqlite3 import dbapi2 as database
from urllib.parse import quote_plus
import re
import uuid
from resources.lib.modules import control
from resources.lib.modules import log_utils

getLS = control.lang
WINDOW_DAYS = 90
KEEP_ADDED_DAYS = 7
REFRESH_HOURS = 12
LIBRARY_RETRY_HOURS = 6 # estreno emitido pero TMDb aun sin episodios: no reintentar en cada vuelta
FINISHED = ('ended', 'canceled', 'cancelled')
MONTHS = ('Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec')
GREEN, AMBER, GREY = 'ff00fa9a', 'fffdb515', 'ff9e9e9e'


# ---------------------------------------------------------------- base de datos

TOMB_KEEP_DAYS = 180 # un aparato apagado mas tiempo que esto podria devolver algo borrado
_migrated = False

def _connect():
	global _migrated
	control.makeFile(control.dataPath)
	dbcon = database.connect(control.libcacheFile, timeout=15)
	dbcon.execute('''CREATE TABLE IF NOT EXISTS premiere_lists (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL UNIQUE, created TEXT, uid TEXT, updated TEXT);''')
	dbcon.execute('''CREATE TABLE IF NOT EXISTS premiere_items (list_id INTEGER, kind TEXT, tmdb TEXT, imdb TEXT, tvdb TEXT, tvshowtitle TEXT, year TEXT, season INTEGER, air_date TEXT, state TEXT, notified TEXT, added_on TEXT, poster TEXT, fanart TEXT, updated TEXT, UNIQUE(tmdb, season));''')
	dbcon.execute('''CREATE TABLE IF NOT EXISTS premiere_meta (key TEXT PRIMARY KEY, value TEXT);''')
	dbcon.execute('''CREATE TABLE IF NOT EXISTS premiere_tombstones (kind TEXT, key TEXT, ts TEXT, reason TEXT, PRIMARY KEY(kind, key));''')
	if not _migrated:
		_migrate(dbcon)
		_migrated = True
	dbcon.commit()
	return dbcon

def _migrate(dbcon):
	"""v2.0.02: las tablas de la 2.0.0/2.0.01 no tienen uid ni updated."""
	now = stamp()
	for table, col in (('premiere_lists', 'uid'), ('premiere_lists', 'updated'), ('premiere_items', 'updated')):
		cols = [r[1] for r in dbcon.execute('PRAGMA table_info(%s)' % table).fetchall()]
		if col in cols: continue
		try: dbcon.execute('ALTER TABLE %s ADD COLUMN %s TEXT' % (table, col))
		except database.OperationalError: pass # el servicio y el plugin migrando a la vez: ya la ha anadido el otro
	for (list_id,) in dbcon.execute("SELECT id FROM premiere_lists WHERE uid IS NULL OR uid = ''").fetchall():
		dbcon.execute('UPDATE premiere_lists SET uid=? WHERE id=?', (new_uid(), list_id))
	dbcon.execute("UPDATE premiere_lists SET updated=? WHERE updated IS NULL OR updated = ''", (now,))
	dbcon.execute("UPDATE premiere_items SET updated=? WHERE updated IS NULL OR updated = ''", (now,))

def stamp():
	"""Sello UTC ordenable como texto."""
	return datetime.utcnow().strftime('%Y-%m-%dT%H:%M:%S.%fZ')

def new_uid():
	return uuid.uuid4().hex

def item_key(tmdb, season):
	return '%s:%s' % (tmdb, int(season))

def tomb(dbcon, kind, key, reason):
	ts = stamp()
	dbcon.execute('INSERT OR REPLACE INTO premiere_tombstones VALUES (?, ?, ?, ?)', (kind, key, ts, reason))
	return ts

def mark_dirty():
	"""Avisa al hilo de sincronizacion del servicio de que hay cambios que mandar."""
	try: control.homeWindow.setProperty('luc_kodi.psync.dirty', stamp())
	except: pass

_ITEM_COLS = ('list_id', 'kind', 'tmdb', 'imdb', 'tvdb', 'tvshowtitle', 'year', 'season', 'air_date', 'state', 'notified', 'added_on', 'poster', 'fanart', 'updated')

def _rows(dbcon, where='', args=()):
	rows = dbcon.execute('SELECT %s FROM premiere_items %s' % (', '.join(_ITEM_COLS), where), args).fetchall()
	return [dict(zip(_ITEM_COLS, r)) for r in rows]

def _update(dbcon, item, **changes):
	item.update(changes)
	sets = ', '.join('%s=?' % k for k in changes)
	dbcon.execute('UPDATE premiere_items SET %s WHERE tmdb=? AND season=?' % sets, tuple(changes.values()) + (item['tmdb'], item['season']))

def get_lists():
	try:
		dbcon = _connect()
		try:
			rows = dbcon.execute('''SELECT l.id, l.name, COUNT(i.tmdb) FROM premiere_lists l LEFT JOIN premiere_items i ON i.list_id = l.id GROUP BY l.id ORDER BY l.name COLLATE NOCASE''').fetchall()
			return [{'id': r[0], 'name': r[1], 'count': r[2]} for r in rows]
		finally: dbcon.close()
	except:
		log_utils.error()
		return []


# ---------------------------------------------------------------- fechas

def _today():
	return datetime.now().date()

def _parse(d):
	m = re.search(r'(\d{4})-(\d{2})-(\d{2})', str(d or ''))
	if not m: return None
	try: return datetime(int(m.group(1)), int(m.group(2)), int(m.group(3))).date()
	except ValueError: return None

def _fmt(d):
	d = _parse(d) if not hasattr(d, 'year') else d
	if not d: return ''
	return '%d %s %d' % (d.day, MONTHS[d.month - 1], d.year)

def _state_for(air_date):
	d = _parse(air_date)
	if not d or d > _today() + timedelta(days=WINDOW_DAYS): return 'waiting'
	return 'scheduled'

def _library_cutoff():
	# El mismo dia de corte que la biblioteca: ayer con el retraso de 24 h, hoy sin el.
	if control.setting('library.importdelay') != 'true': return _today()
	return _today() - timedelta(days=1)


# ---------------------------------------------------------------- TMDb

def _details(tmdb):
	from resources.lib.indexers import tmdb as tmdb_indexer
	result = tmdb_indexer.TVshows().get_show_request(tmdb, light=True)
	if not result or isinstance(result, str): return None
	return result

def _resolve_tmdb(imdb, tvdb):
	try:
		from resources.lib.indexers import tmdb as tmdb_indexer
		result = tmdb_indexer.TVshows().IdLookup(imdb, tvdb)
		if isinstance(result, dict) and result.get('id'): return str(result['id'])
	except: log_utils.error()
	return ''

def _never_aired(details):
	last = details.get('last_episode_to_air') or {}
	if not last: return True
	first = _parse(details.get('first_air_date'))
	return bool(first and first > _today())

def _target(details, season=None):
	"""(kind, season) a vigilar, o (None, id de mensaje) si no hay nada que esperar."""
	if _never_aired(details): return 'show', 1
	last_season = int((details.get('last_episode_to_air') or {}).get('season_number') or 0)
	if season not in (None, ''):
		season = int(season)
		if season <= last_season: return None, 32714
		return 'season', season
	status = str(details.get('status') or '').lower()
	nxt = details.get('next_episode_to_air') or {}
	if nxt and int(nxt.get('season_number') or 0) > last_season: return 'season', int(nxt['season_number'])
	later = sorted(int(s.get('season_number') or 0) for s in details.get('seasons') or [] if int(s.get('season_number') or 0) > last_season)
	if later: return 'season', later[0]
	if status in FINISHED: return None, 32713
	return 'season', last_season + 1 # renovada sin temporada anunciada: espera fecha

def _air_date(details, kind, season):
	if kind == 'show':
		nxt = details.get('next_episode_to_air') or {}
		return details.get('first_air_date') or (nxt.get('air_date') if int(nxt.get('season_number') or 0) <= 1 else '') or ''
	nxt = details.get('next_episode_to_air') or {}
	if nxt and int(nxt.get('season_number') or 0) == int(season) and int(nxt.get('episode_number') or 0) == 1 and nxt.get('air_date'):
		return nxt['air_date']
	for s in details.get('seasons') or []:
		if int(s.get('season_number') or -1) == int(season): return s.get('air_date') or ''
	return ''

def _snapshot(details):
	ext = details.get('external_ids') or {}
	first = details.get('first_air_date') or ''
	return {
		'tvshowtitle': details.get('name') or details.get('original_name') or '',
		'year': first[:4] if first else '',
		'imdb': ext.get('imdb_id') or '',
		'tvdb': str(ext.get('tvdb_id') or ''),
		'poster': ('https://image.tmdb.org/t/p/w500%s' % details['poster_path']) if details.get('poster_path') else '',
		'fanart': ('https://image.tmdb.org/t/p/original%s' % details['backdrop_path']) if details.get('backdrop_path') else ''}


# ---------------------------------------------------------------- avisos

def _label(item):
	return item['tvshowtitle'] if item['kind'] == 'show' else '%s · %s' % (item['tvshowtitle'], getLS(32730) % item['season'])

def _notify(item, message):
	control.notification(title=_label(item), message=message, icon=item.get('poster') or None, time=6000)
	control.sleep(6500)


# ---------------------------------------------------------------- alta desde el menu contextual

def add(tvshowtitle, year, imdb, tmdb, tvdb, season=None):
	try:
		if not tmdb: tmdb = _resolve_tmdb(imdb, tvdb)
		details = _details(tmdb) if tmdb else None
		if not details: return control.notification(title=tvshowtitle, message=32729)
		kind, target = _target(details, season)
		if kind is None: return control.notification(title=tvshowtitle, message=target)
		snap = _snapshot(details)
		dbcon = _connect()
		try:
			dupe = dbcon.execute('''SELECT l.name FROM premiere_items i JOIN premiere_lists l ON l.id = i.list_id WHERE i.tmdb=? AND i.season=?''', (str(tmdb), target)).fetchone()
			if dupe: return control.notification(title=snap['tvshowtitle'] or tvshowtitle, message=getLS(32712) % dupe[0])
			list_id, list_name = _choose_list(dbcon)
			if not list_id: return
			air_date = _air_date(details, kind, target)
			state = _state_for(air_date)
			# v2.0.02: columnas con nombre; con 'updated' la tabla ya no admite VALUES posicional de 14
			dbcon.execute('INSERT INTO premiere_items (%s) VALUES (%s)' % (', '.join(_ITEM_COLS), ', '.join('?' * len(_ITEM_COLS))), (
				list_id, kind, str(tmdb), snap['imdb'] or imdb or '', snap['tvdb'] or tvdb or '', snap['tvshowtitle'] or tvshowtitle, snap['year'] or year or '',
				target, air_date, state, '', '', snap['poster'], snap['fanart'], stamp()))
			dbcon.commit()
		finally: dbcon.close()
		mark_dirty()
		item = {'kind': kind, 'tvshowtitle': snap['tvshowtitle'] or tvshowtitle, 'season': target}
		when = ('%s · %s' % (getLS(32715), _fmt(air_date))) if (state == 'waiting' and air_date) else getLS(32715) if state == 'waiting' else _fmt(air_date)
		control.notification(title=_label(item), message='%s · %s' % (getLS(32711) % list_name, when), icon=snap['poster'] or None, time=5000)
	except:
		log_utils.error()

def _choose_list(dbcon):
	lists = dbcon.execute('SELECT id, name FROM premiere_lists ORDER BY name COLLATE NOCASE').fetchall()
	if lists:
		labels = [r[1] for r in lists] + ['[COLOR %s]%s[/COLOR]' % (AMBER, getLS(32702))]
		pick = control.selectDialog(labels, heading=getLS(32710))
		if pick < 0: return None, None
		if pick < len(lists): return lists[pick][0], lists[pick][1]
	name = _ask_name(dbcon)
	if not name: return None, None
	cur = dbcon.execute('INSERT INTO premiere_lists (name, created, uid, updated) VALUES (?, ?, ?, ?)', (name, _today().isoformat(), new_uid(), stamp()))
	dbcon.commit()
	return cur.lastrowid, name

def _ask_name(dbcon, current=''):
	while True:
		name = control.dialog.input(getLS(32703), defaultt=current).strip()
		if not name: return None
		taken = dbcon.execute('SELECT 1 FROM premiere_lists WHERE name=? COLLATE NOCASE', (name,)).fetchone()
		if taken and name.lower() != current.lower():
			control.notification(message=32709)
			current = name
			continue
		return name


# ---------------------------------------------------------------- gestion de listas

def new_list():
	try:
		dbcon = _connect()
		try:
			name = _ask_name(dbcon)
			if not name: return
			dbcon.execute('INSERT INTO premiere_lists (name, created, uid, updated) VALUES (?, ?, ?, ?)', (name, _today().isoformat(), new_uid(), stamp()))
			dbcon.commit()
		finally: dbcon.close()
		mark_dirty()
		control.refresh()
	except: log_utils.error()

def rename_list(list_id):
	try:
		dbcon = _connect()
		try:
			row = dbcon.execute('SELECT name FROM premiere_lists WHERE id=?', (int(list_id),)).fetchone()
			if not row: return
			name = _ask_name(dbcon, row[0])
			if not name or name == row[0]: return
			dbcon.execute('UPDATE premiere_lists SET name=?, updated=? WHERE id=?', (name, stamp(), int(list_id)))
			dbcon.commit()
		finally: dbcon.close()
		mark_dirty()
		control.refresh()
	except: log_utils.error()

def delete_list(list_id):
	try:
		dbcon = _connect()
		try:
			row = dbcon.execute('SELECT name, uid FROM premiere_lists WHERE id=?', (int(list_id),)).fetchone()
			if not row: return
			if not control.yesnoDialog(getLS(32706) % row[0], '', ''): return
			for tmdb, season in dbcon.execute('SELECT tmdb, season FROM premiere_items WHERE list_id=?', (int(list_id),)).fetchall():
				tomb(dbcon, 'item', item_key(tmdb, season), 'user')
			if row[1]: tomb(dbcon, 'list', row[1], 'user')
			dbcon.execute('DELETE FROM premiere_items WHERE list_id=?', (int(list_id),))
			dbcon.execute('DELETE FROM premiere_lists WHERE id=?', (int(list_id),))
			dbcon.commit()
		finally: dbcon.close()
		mark_dirty()
		control.refresh()
	except: log_utils.error()

def remove_item(tmdb, season):
	try:
		dbcon = _connect()
		try:
			tomb(dbcon, 'item', item_key(tmdb, season), 'user')
			dbcon.execute('DELETE FROM premiere_items WHERE tmdb=? AND season=?', (str(tmdb), int(season)))
			dbcon.commit()
		finally: dbcon.close()
		mark_dirty()
		control.refresh()
	except: log_utils.error()


# ---------------------------------------------------------------- vigilancia (servicio)

def _due_refresh(dbcon):
	row = dbcon.execute("SELECT value FROM premiere_meta WHERE key='last_refresh'").fetchone()
	if not row: return True
	try: return datetime.now() - datetime.strptime(row[0], '%Y-%m-%d %H:%M:%S') >= timedelta(hours=REFRESH_HOURS)
	except: return True

def _refresh(dbcon, items, notices):
	"""Vuelve a leer la fecha en TMDb, una peticion por serie."""
	by_show = {}
	for item in items: by_show.setdefault(item['tmdb'], []).append(item)
	for tmdb, show_items in by_show.items():
		if control.monitor.abortRequested(): return False
		details = _details(tmdb)
		if not details: continue # sin red o sin respuesta: se conserva lo guardado
		snap = _snapshot(details)
		for item in show_items:
			old_date, old_state = item['air_date'], item['state']
			new_date = _air_date(details, item['kind'], item['season'])
			new_state = _state_for(new_date)
			changes = {'air_date': new_date, 'state': new_state}
			for k in ('tvshowtitle', 'year', 'imdb', 'tvdb', 'poster', 'fanart'):
				if snap[k]: changes[k] = snap[k]
			_update(dbcon, item, **changes)
			old_d, new_d = _parse(old_date), _parse(new_date)
			if old_state == 'waiting' and new_state == 'scheduled':
				notices.append((item, getLS(32720) % _fmt(new_d)))
			elif old_state == 'scheduled' and old_d and (not new_d or new_d > old_d):
				notices.append((item, getLS(32721) % (_fmt(new_d) if new_d else getLS(32715))))
	dbcon.execute("INSERT OR REPLACE INTO premiere_meta VALUES ('last_refresh', ?)", (datetime.now().strftime('%Y-%m-%d %H:%M:%S'),))
	dbcon.commit()
	return True

def _to_library(item):
	"""Numero de episodios del estreno ya en disco, None si fallo."""
	from resources.lib.modules import library
	lib = library.libtvshows()
	if item['kind'] == 'season':
		return lib.add_season(item['tvshowtitle'], item['year'], item['imdb'], item['tmdb'], item['tvdb'], item['season'])
	written = lib.add(item['tvshowtitle'], item['year'], item['imdb'], item['tmdb'], item['tvdb'], range=True)
	if written: return written
	# 0 o None: si la serie ya estaba en la biblioteca (anadida a mano), cuenta como hecho
	if control.isfilePath(control.joinPath(lib.show_folder(item['tvshowtitle'], item['year']), 'tvshow.nfo')): return 1
	return written

def _may_try_library(dbcon, item, manual):
	key = 'try:%s:%s' % (item['tmdb'], item['season'])
	row = dbcon.execute('SELECT value FROM premiere_meta WHERE key=?', (key,)).fetchone()
	now = datetime.now()
	if row and not manual:
		try:
			if now - datetime.strptime(row[0], '%Y-%m-%d %H:%M:%S') < timedelta(hours=LIBRARY_RETRY_HOURS): return False
		except: pass
	dbcon.execute('INSERT OR REPLACE INTO premiere_meta VALUES (?, ?)', (key, now.strftime('%Y-%m-%d %H:%M:%S')))
	dbcon.commit()
	return True

def check(force_refresh=False, manual=False):
	"""Una pasada: refresco de fechas si toca, avisos, altas en la biblioteca y limpieza."""
	# Con video en marcha la pasada entera espera a la siguiente vuelta: ni
	# avisos encima de la pelicula ni avisos marcados como dados sin verse.
	if not manual and control.condVisibility('Player.HasVideo'): return
	try:
		dbcon = _connect()
	except:
		log_utils.error()
		return
	written_any = False
	notices = []
	try:
		items = _rows(dbcon, 'WHERE state != ?', ('added',))
		if items and (force_refresh or _due_refresh(dbcon)):
			if not _refresh(dbcon, items, notices): return
		today, cutoff = _today(), _library_cutoff()
		for item in items:
			if control.monitor.abortRequested(): return
			if item['state'] != 'scheduled': continue
			d = _parse(item['air_date'])
			if not d: continue
			eve_tag, day_tag = 'eve:%s' % d.isoformat(), 'day:%s' % d.isoformat()
			if d <= cutoff:
				if not _may_try_library(dbcon, item, manual): continue
				on_disk = _to_library(item)
				if on_disk:
					_update(dbcon, item, state='added', added_on=today.isoformat())
					dbcon.commit()
					written_any = True
					notices.append((item, getLS(32722)))
			elif d == today + timedelta(days=1) and item['notified'] != eve_tag:
				notices.append((item, getLS(32716)))
				_update(dbcon, item, notified=eve_tag)
			elif d == today and item['notified'] not in (eve_tag, day_tag):
				# Kodi apagado la vispera: se avisa el mismo dia
				notices.append((item, getLS(32718)))
				_update(dbcon, item, notified=day_tag)
		done_cut = (today - timedelta(days=KEEP_ADDED_DAYS)).isoformat()
		done = dbcon.execute('SELECT tmdb, season FROM premiere_items WHERE state=? AND added_on < ?', ('added', done_cut)).fetchall()
		for tmdb, season in done: tomb(dbcon, 'item', item_key(tmdb, season), 'done')
		if done: mark_dirty()
		dbcon.execute('DELETE FROM premiere_items WHERE state=? AND added_on < ?', ('added', done_cut))
		dbcon.execute('DELETE FROM premiere_tombstones WHERE ts < ?', ((datetime.utcnow() - timedelta(days=TOMB_KEEP_DAYS)).strftime('%Y-%m-%dT%H:%M:%S'),))
		dbcon.execute("DELETE FROM premiere_meta WHERE key LIKE 'try:%' AND substr(key, 5) NOT IN (SELECT tmdb || ':' || season FROM premiere_items WHERE state != 'added')")
		dbcon.commit()
	except:
		log_utils.error()
	finally:
		try: dbcon.close()
		except: pass
	try:
		for item, message in notices:
			if control.monitor.abortRequested(): break
			_notify(item, message)
	except: log_utils.error()
	if written_any and control.setting('library.update') != 'false' and not control.condVisibility('Library.IsScanningVideo'):
		control.execute('UpdateLibrary(video)')
	if manual: control.notification(message=32732)

def service_loop():
	monitor = control.monitor
	if monitor.waitForAbort(90): return
	while not monitor.abortRequested():
		check()
		if monitor.waitForAbort(1800): return


# ---------------------------------------------------------------- directorios

def _sysaddon():
	from sys import argv
	return argv[0], int(argv[1])

def _end(handle, content=''):
	control.content(handle, content)
	control.directory(handle, cacheToDisc=False)

def lists_directory():
	sysaddon, handle = _sysaddon()
	paired = 0
	try:
		# v2.0.02: con aparatos emparejados, lo que se haya cambiado en ellos llega antes de pintar
		from resources.lib.modules import premiere_sync
		paired = premiere_sync.peer_count()
		if paired: premiere_sync.quick_sync()
	except: log_utils.error()
	try:
		for l in get_lists():
			item = control.item(label='%s  [COLOR %s](%s)[/COLOR]' % (l['name'], GREY, l['count']), offscreen=True)
			item.setArt({'icon': 'DefaultVideoPlaylists.png', 'thumb': 'DefaultVideoPlaylists.png', 'fanart': control.addonFanart()})
			item.addContextMenuItems([
				(getLS(32704), 'RunPlugin(%s?action=library_premiereRename&list_id=%s)' % (sysaddon, l['id'])),
				(getLS(32705), 'RunPlugin(%s?action=library_premiereDelete&list_id=%s)' % (sysaddon, l['id'])),
				(getLS(32708), 'RunPlugin(%s?action=library_premiereCheck)' % sysaddon)])
			control.addItem(handle=handle, url='%s?action=library_premiereList&list_id=%s' % (sysaddon, l['id']), listitem=item, isFolder=True)
		item = control.item(label='[COLOR %s]%s[/COLOR]' % (AMBER, getLS(32702)), offscreen=True)
		item.setArt({'icon': 'DefaultAddSource.png', 'thumb': 'DefaultAddSource.png', 'fanart': control.addonFanart()})
		control.addItem(handle=handle, url='%s?action=library_premiereNewList' % sysaddon, listitem=item, isFolder=False)
		label = getLS(32733) + ('  [COLOR %s](%s)[/COLOR]' % (GREY, getLS(32759) % paired) if paired else '')
		item = control.item(label=label, offscreen=True)
		item.setArt({'icon': 'DefaultNetwork.png', 'thumb': 'DefaultNetwork.png', 'fanart': control.addonFanart()})
		control.addItem(handle=handle, url='%s?action=library_premiereSync' % sysaddon, listitem=item, isFolder=False)
	except: log_utils.error()
	_end(handle, 'files')

def _status(item):
	if item['state'] == 'added': return '[COLOR %s]%s[/COLOR]' % (GREEN, getLS(32727))
	d = _parse(item['air_date'])
	if item['state'] == 'waiting':
		return '[COLOR %s]%s%s[/COLOR]' % (GREY, getLS(32715), (' · %s %d' % (MONTHS[d.month - 1], d.year)) if d else '')
	if not d: return '[COLOR %s]%s[/COLOR]' % (GREY, getLS(32715))
	days = (d - _today()).days
	if days < 0: return '[COLOR %s]%s[/COLOR]' % (AMBER, getLS(32728))
	when = getLS(32724) if days == 0 else getLS(32725) if days == 1 else getLS(32726) % days
	return '[COLOR %s]%s[/COLOR] [COLOR %s]· %s[/COLOR]' % (GREEN if days <= 1 else AMBER, when, GREY, _fmt(d))

def list_directory(list_id):
	sysaddon, handle = _sysaddon()
	try:
		dbcon = _connect()
		try: items = _rows(dbcon, 'WHERE list_id=?', (int(list_id),))
		finally: dbcon.close()
		order = {'scheduled': 0, 'waiting': 1, 'added': 2}
		items.sort(key=lambda i: (order.get(i['state'], 3), i['air_date'] or '9999', i['tvshowtitle'].lower()))
		for i in items:
			label = '[B]%s[/B]  %s' % (_label(i), _status(i))
			systitle = quote_plus(i['tvshowtitle'])
			item = control.item(label=label, offscreen=True)
			poster = i['poster'] or control.addonPoster()
			item.setArt({'poster': poster, 'thumb': poster, 'icon': poster, 'fanart': i['fanart'] or control.addonFanart()})
			try:
				tag = item.getVideoInfoTag()
				tag.setMediaType('tvshow')
				tag.setTitle(i['tvshowtitle'])
				tag.setTvShowTitle(i['tvshowtitle'])
				if i['air_date']: tag.setPremiered(i['air_date'])
				tag.setPlot('%s\n%s' % (_label(i), re.sub(r'\[/?COLOR[^\]]*\]', '', _status(i))))
			except: pass
			item.addContextMenuItems([
				('Play Trailer', 'PlayMedia(%s?action=play_Trailer&type=show&name=%s&year=%s&imdb=%s&tmdb=%s&url=)' % (sysaddon, systitle, i['year'], i['imdb'], i['tmdb'])),
				(getLS(32707), 'RunPlugin(%s?action=library_premiereRemove&tmdb=%s&season=%s)' % (sysaddon, i['tmdb'], i['season'])),
				(getLS(32708), 'RunPlugin(%s?action=library_premiereCheck)' % sysaddon)])
			url = '%s?action=seasons&tvshowtitle=%s&year=%s&imdb=%s&tmdb=%s&tvdb=%s' % (sysaddon, systitle, i['year'], i['imdb'], i['tmdb'], i['tvdb'])
			control.addItem(handle=handle, url=url, listitem=item, isFolder=True)
		if not items:
			item = control.item(label='[COLOR %s]%s[/COLOR]' % (GREY, getLS(32731)), offscreen=True)
			item.setArt({'icon': 'DefaultIconInfo.png', 'thumb': 'DefaultIconInfo.png', 'fanart': control.addonFanart()})
			control.addItem(handle=handle, url='%s?action=library_premiereNoop' % sysaddon, listitem=item, isFolder=False)
	except: log_utils.error()
	_end(handle, 'tvshows')
