"""
luc_kodi Add-on -- Real-Debrid 2026 keyword-filter compliance module
====================================================================
Around 2026-05-10 Real-Debrid started rejecting cached torrents whose
names contain certain release-naming keywords. The rule changed on
2026-10-03 (see the pattern table below). The block surfaces as
HTTP 451 + error_code: 35 (infringing_file). The /torrents listing still
reports the item as 'downloaded' so we cannot detect it from the cache
check.

RD applies the rule to TWO names, at two moments:
  - POST /torrents/addMagnet: the torrent's own (root) name only.
  - POST /unrestrict/link:   each file's own name.
So a cleanly named pack can still hold files RD refuses to stream.

Strategy:
  - "Fast pass": baked-in filename regex covering the measured patterns,
    checked against the release name and, when the RD cache check knows
    them (DMM availability returns file paths), the root folder and the
    file names. Drops what RD will refuse before it reaches the user as
    a clickable item.
  - "Defense in depth": realdebrid.py captures HTTP 451 + code 35 and
    tells a refused name apart from an account-wide pause on adds.

The filter is enabled/disabled via setting `realdebrid.rd2026_filter`
(default true). Only applied to results that would be resolved via
Real-Debrid -- it does NOT touch TorBox, Premiumize, AllDebrid or
Easynews items, which have no equivalent filter today.
"""

import re

# Version tag for the regex table. Bump whenever the pattern list
# changes so debugging and changelogs can correlate user reports.
RD_FILTER_VERSION = '2026.10.03'

# ---------------------------------------------------------------------
# Pattern table (v2.0.01, 2026.10.03)
# ---------------------------------------------------------------------
# El 3-oct-2026 RD cambio el filtro. El desarrollador de DMM lo volvio a
# medir con 121 torrents nuevos y 12 enlaces de fichero (cada torrent
# construido sobre datos aleatorios, asi que solo decidia el nombre) y
# lo publico en su post de Patreon "Complete List of Real-Debrid's
# Filename Filters"; DMM (src/utils/deInfringe.ts, commits 26c091a y
# 8f5e40e) y LitterBox de ElfHosted (PR #26) lo adoptaron el mismo fin
# de semana. Hoy RD solo rechaza CINCO literales, en cualquier parte del
# nombre y RESPETANDO MAYUSCULAS Y SEPARADOR:
#
#   WEB-DL | WEB.x264 | WEB.H264 | HDTV.x264 | HDTV.XviD
#
# Vuelven a pasar (rechazados hasta septiembre de 2026):
#   - WEBRip, BDRip, HDRip y DVDRip;
#   - BluRay.x264, y BluRay.DTS con cualquier cosa detras;
#   - WEB.h264 con h minuscula (el formato de GRACE, ETHEL, EDITH).
# Y como ya no se ignoran mayusculas, tambien pasan web-dl, WEB-dl,
# web.H264, WEB.X264... Solo el punto o guion indicados cuentan: WEB.DL,
# WEBDL, WEB DL y WEB-x264 pasan; WEB-DLRip contiene WEB-DL y no pasa.
#
# Por eso el patron se compila SIN re.IGNORECASE: con la bandera, la
# tabla volveria a esconder web-dl y WEB.h264, que RD ya sirve.
#
# Ojo: clean_name() de los scrapers cambia espacios por puntos, asi que
# un titulo "WEB H264" llega aqui como "WEB.H264". Se deja tal cual: es
# el mismo nombre que viaja en el dn= del magnet, y solo afecta a la H
# mayuscula separada por espacio (WEB h264 pasa igualmente).
#
# La captura del HTTP 451 + error_code 35 en realdebrid.py sigue siendo
# la segunda linea de defensa: si RD vuelve a cambiar, el log lo dira.
# ---------------------------------------------------------------------

_RD_FILTER_PATTERN = r'WEB-DL|WEB\.x264|WEB\.H264|HDTV\.x264|HDTV\.XviD'

# Case-sensitive on purpose (see the table above).
_RD_FILTER_RE = re.compile(_RD_FILTER_PATTERN)

# Video containers, to pick the file a resolve would actually stream.
# Local tuple so the module stays importable outside Kodi (tests).
_VIDEO_EXT = ('.mkv', '.mp4', '.avi', '.m4v', '.ts', '.m2ts', '.mts',
	'.wmv', '.mov', '.webm', '.mpg', '.mpeg', '.vob', '.divx', '.flv')


def is_rd_filtered(name):
	"""
	Return True if `name` (a torrent release name, a root folder or a
	file name) contains one of the literals Real-Debrid refuses.

	Safe on None / empty / non-str. No exceptions raised.
	"""
	if not name:
		return False
	try:
		return bool(_RD_FILTER_RE.search(name))
	except Exception:
		return False


def _base_name(path):
	return (path or '').replace('\\', '/').rstrip('/').rsplit('/', 1)[-1]


def is_files_filtered(files, package=False):
	"""
	Judge a cached torrent by the file paths the RD cache check returned
	(DMM availability: [{'file_id', 'path', 'bytes'}, ...]). Returns True
	when RD will refuse what a resolve would play:
	  - the root folder name matches (RD refuses the add itself);
	  - single item: the largest video file's own name matches (that is
	    the file resolve_magnet() picks, and /unrestrict/link refuses it);
	  - pack: EVERY video file's own name matches. A pack with only some
	    refused episodes is kept; resolve_magnet() checks the one it picks.
	An empty or unexpected list leaves the verdict to the release name.
	"""
	try:
		paths = [(f.get('path') or '', f.get('bytes') or 0) for f in files if isinstance(f, dict) and f.get('path')]
		if not paths:
			return False
		for p, _b in paths:
			parts = p.replace('\\', '/').strip('/').split('/')
			if len(parts) > 1 and is_rd_filtered(parts[0]):
				return True
		videos = [(_base_name(p), b) for p, b in paths if p.lower().endswith(_VIDEO_EXT)]
		if not videos:
			return False
		if package:
			return all(is_rd_filtered(n) for n, _b in videos)
		return is_rd_filtered(max(videos, key=lambda x: x[1])[0])
	except Exception:
		return False


def filter_enabled():
	"""
	Read the user setting. Cached at module level to avoid hitting
	xbmcaddon on every name check in a tight loop.
	"""
	# Lazy import keeps module importable from non-Kodi contexts (tests)
	try:
		from resources.lib.modules import control
		val = control.setting('realdebrid.rd2026_filter')
		# Default ON: empty string (never set) -> enabled
		return val in ('', 'true')
	except Exception:
		return True


def apply_to_torrent_list(torrent_list, files_by_hash=None):
	"""
	Remove items whose `name` matches the RD-2026 filter, or whose file
	paths (`files_by_hash`, the RD cache check result keyed by lowercase
	hash) show RD will refuse them -- see is_files_filtered(). Returns a
	new list (does NOT mutate the input list reference).

	Used inside rd_cache_chk_list() in sources.py. The cached torrents
	dictionary is unaffected; we simply drop entries that we know RD
	will refuse to resolve.

	Returns: (filtered_list, removed_count)
	"""
	if not torrent_list:
		return torrent_list, 0
	if not filter_enabled():
		return torrent_list, 0
	kept = []
	removed = 0
	for it in torrent_list:
		nm = it.get('name', '') if isinstance(it, dict) else ''
		if is_rd_filtered(nm):
			removed += 1
			continue
		if files_by_hash and isinstance(it, dict):
			try: files = files_by_hash.get((it.get('hash') or '').lower())
			except Exception: files = None
			if files and is_files_filtered(files, package='package' in it):
				removed += 1
				continue
		kept.append(it)
	return kept, removed


def apply_to_direct_list(direct_list):
	"""
	Filter AIOStreams / MediaFusion direct items already resolved
	through Real-Debrid (item['debrid'] starts with 'RD'). Other
	debrid services are left alone. Items with unknown debrid label
	('Custom') are conservatively kept since we cannot tell which
	service resolved them.

	Returns: (filtered_list, removed_count)
	"""
	if not direct_list:
		return direct_list, 0
	if not filter_enabled():
		return direct_list, 0
	kept = []
	removed = 0
	for it in direct_list:
		if not isinstance(it, dict):
			kept.append(it)
			continue
		debrid_label = (it.get('debrid') or '').strip()
		# Only items resolved through Real-Debrid are at risk
		if debrid_label[:2].upper() != 'RD':
			kept.append(it)
			continue
		nm = it.get('name', '')
		if is_rd_filtered(nm):
			removed += 1
			continue
		kept.append(it)
	return kept, removed


def is_error_code_35(response):
	"""
	Detect Real-Debrid's infringing_file response. On an add it can
	also mean an account-wide pause, not a verdict on the name (see
	realdebrid.py). RD returns either:
	  - JSON: {"error": "infringing_file", "error_code": 35} (HTTP 451)
	  - or sometimes WAF-wrapped with the same payload nested

	Accepts a dict (already-parsed JSON) or any object exposing .get().
	Safe on None / unexpected shapes -- always returns a bool.
	"""
	if not response:
		return False
	try:
		if isinstance(response, dict):
			if response.get('error_code') == 35:
				return True
			if response.get('error') == 'infringing_file':
				return True
		# String fallback (in case caller passes raw text)
		s = str(response)
		if '"error_code":35' in s.replace(' ', ''):
			return True
		if 'infringing_file' in s:
			return True
	except Exception:
		pass
	return False
