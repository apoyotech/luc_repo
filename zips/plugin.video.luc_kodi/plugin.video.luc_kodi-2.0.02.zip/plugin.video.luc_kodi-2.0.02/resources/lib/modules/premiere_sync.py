# -*- coding: utf-8 -*-
"""
	luc_kodi Add-on

	v2.0.02 - Premiere Lists: sincronizacion entre aparatos de la misma red.

	luc_kodi habla con luc_kodi, sin cuentas ni servidores de fuera.

	EMPAREJAR (una sola vez por pareja de aparatos)
	  Aparato A: Sync your devices > Show a PIN on this device. Muestra un PIN
	  de 8 cifras durante 5 minutos y abre el puerto.
	  Aparato B: Sync your devices > Join a device. Busca los luc_kodi de la
	  red (aviso UDP y, si nadie contesta, barrido TCP de la /24), el usuario
	  elige A y mete el PIN.
	  Los dos hacen un Diffie-Hellman (RFC 3526, grupo 14) y prueban que
	  conocen el PIN con un HMAC sobre todo el intercambio. De ahi sale la
	  clave de la pareja; el PIN no vuelve a usarse. Quien escuche la red no
	  puede sacar ni el PIN ni la clave, y quien se ponga en medio solo tiene
	  5 intentos de PIN antes de que A cierre el emparejamiento.

	SINCRONIZAR
	  Cada peticion va firmada con la clave de la pareja sobre un nonce que da
	  el que escucha, y la respuesta tambien: no hace falta que los relojes
	  coincidan para autenticar. Un viaje de ida y vuelta: B manda su estado
	  entero, A lo fusiona y contesta con el suyo ya fusionado; B lo fusiona.
	  Gana el cambio mas reciente ('updated' en UTC); las lapidas evitan que
	  vuelva lo borrado. Dos listas con el mismo nombre en dos aparatos se
	  funden en una: todos se quedan con el uid menor, asi convergen sin
	  avisarse.

	CUANDO
	  - Al emparejar, en el momento.
	  - El servicio: al arrancar Kodi, cada 10 minutos y a los pocos segundos
	    de cualquier cambio en las listas (propiedad luc_kodi.psync.dirty).
	  - Al abrir Premiere Lists, si hace mas de un minuto de la ultima vez.
	  Si el otro aparato esta apagado no pasa nada: se intenta la proxima vez.

	El puerto solo se abre si hay aparatos emparejados o un PIN en pantalla,
	y solo atiende a direcciones de red local.

	Protocolo: TCP, una linea JSON por mensaje. Al conectar, el que escucha
	saluda con {app, v, id, name, pairing, nonce}; el barrido de descubrimiento
	solo lee ese saludo.
"""
import hashlib
import hmac
import json
import secrets
import select
import socket
import time
from calendar import timegm
from datetime import datetime
from ipaddress import ip_address
from threading import Thread

from resources.lib.modules import control
from resources.lib.modules import log_utils
from resources.lib.modules import premiere_lists as pl

getLS = control.lang

APP = 'luc_kodi.psync'
PROTO = 1
PORT = 47788 # TCP (sincronizar) y UDP (descubrir)
BIND_HOST = '' # el arnes de pruebas lo cambia para simular dos aparatos en una maquina
PAIR_SECONDS = 300
PAIR_TRIES = 5
AUTO_MINUTES = 10
QUICK_SECONDS = 60
MAX_LINE = 2 * 1024 * 1024
GENERIC_NAMES = ('', 'kodi', 'localhost', 'android')
GREEN, AMBER, GREY = pl.GREEN, pl.AMBER, pl.GREY

# RFC 3526, grupo 14 (MODP de 2048 bits), generador 2
_P = int(
	'FFFFFFFFFFFFFFFFC90FDAA22168C234C4C6628B80DC1CD129024E088A67CC74020BBEA63B139B22514A08798E3404DD'
	'EF9519B3CD3A431B302B0A6DF25F14374FE1356D6D51C245E485B576625E7EC6F44C42E9A637ED6B0BFF5CB6F406B7ED'
	'EE386BFB5A899FA5AE9F24117C4B1FE649286651ECE45B3DC2007CB8A163BF0598DA48361C55D39A69163FA8FD24CF5F'
	'83655D23DCA3AD961C62F356208552BB9ED529077096966D670C354E4ABC9804F1746C08CA18217C32905E462E36CE3B'
	'E39E772C180E86039B2783A2EC07A28FB5C55DF06F4C52C9DE2BCBF6955817183995497CEA956AE515D2261898FA0510'
	'15728E5A8AACAA68FFFFFFFFFFFFFFFF', 16)
_G = 2


# ---------------------------------------------------------------- base de datos

def _connect():
	dbcon = pl._connect()
	dbcon.execute('''CREATE TABLE IF NOT EXISTS premiere_peers (id TEXT PRIMARY KEY, name TEXT, host TEXT, port INTEGER, secret TEXT, paired TEXT, last_sync TEXT);''')
	dbcon.commit()
	return dbcon

def _meta(dbcon, key):
	row = dbcon.execute('SELECT value FROM premiere_meta WHERE key=?', (key,)).fetchone()
	return row[0] if row else None

def _meta_set(dbcon, key, value):
	if value is None: dbcon.execute('DELETE FROM premiere_meta WHERE key=?', (key,))
	else: dbcon.execute('INSERT OR REPLACE INTO premiere_meta VALUES (?, ?)', (key, value))
	dbcon.commit()

def device_id(dbcon, renew=False):
	did = None if renew else _meta(dbcon, 'psync_id')
	if not did:
		did = pl.new_uid()
		_meta_set(dbcon, 'psync_id', did)
	return did

def device_name(dbcon):
	name = _meta(dbcon, 'psync_name')
	if name: return name
	friendly = (control.infoLabel('System.FriendlyName') or '').strip()
	return friendly or 'Kodi'

def _generic(name):
	n = (name or '').strip().lower()
	return n in GENERIC_NAMES or n.startswith('kodi (')

_PEER_COLS = ('id', 'name', 'host', 'port', 'secret', 'paired', 'last_sync')

def get_peers(dbcon):
	rows = dbcon.execute('SELECT %s FROM premiere_peers ORDER BY name COLLATE NOCASE' % ', '.join(_PEER_COLS)).fetchall()
	return [dict(zip(_PEER_COLS, r)) for r in rows]

def _get_peer(dbcon, pid):
	row = dbcon.execute('SELECT %s FROM premiere_peers WHERE id=?' % ', '.join(_PEER_COLS), (pid,)).fetchone()
	return dict(zip(_PEER_COLS, row)) if row else None

def _save_peer(dbcon, pid, name, host, port, secret):
	old = _get_peer(dbcon, pid)
	dbcon.execute('INSERT OR REPLACE INTO premiere_peers VALUES (?, ?, ?, ?, ?, ?, ?)',
		(pid, name, host, int(port or PORT), secret, pl.stamp(), old['last_sync'] if old else None))
	dbcon.commit()

def _touch_peer(dbcon, pid, **changes):
	if not changes: return
	sets = ', '.join('%s=?' % k for k in changes)
	dbcon.execute('UPDATE premiere_peers SET %s WHERE id=?' % sets, tuple(changes.values()) + (pid,))
	dbcon.commit()

def _pairing(dbcon):
	"""El PIN en pantalla, si sigue vigente."""
	raw = _meta(dbcon, 'psync_pairing')
	if not raw: return None
	try:
		p = json.loads(raw)
		if p.get('expires', 0) > time.time(): return p
	except: pass
	_meta_set(dbcon, 'psync_pairing', None)
	return None


# ---------------------------------------------------------------- estado y fusion

def snapshot(dbcon):
	lists, uid_of = [], {}
	for list_id, uid, name, created, updated in dbcon.execute('SELECT id, uid, name, created, updated FROM premiere_lists').fetchall():
		uid_of[list_id] = uid
		lists.append({'uid': uid, 'name': name, 'created': created or '', 'updated': updated or ''})
	items = []
	for i in pl._rows(dbcon):
		uid = uid_of.get(i['list_id'])
		if not uid: continue
		items.append({'list': uid, 'kind': i['kind'], 'tmdb': i['tmdb'], 'season': i['season'], 'imdb': i['imdb'] or '', 'tvdb': i['tvdb'] or '',
			'tvshowtitle': i['tvshowtitle'] or '', 'year': i['year'] or '', 'air_date': i['air_date'] or '',
			'poster': i['poster'] or '', 'fanart': i['fanart'] or '', 'updated': i['updated'] or ''})
	tombs = [{'kind': k, 'key': key, 'ts': ts, 'reason': r} for k, key, ts, r in dbcon.execute('SELECT kind, key, ts, reason FROM premiere_tombstones').fetchall()]
	return {'lists': lists, 'items': items, 'tombs': tombs}

def _s(v, n=300):
	return v.strip()[:n] if isinstance(v, str) else ''

def _tomb_ts(dbcon, kind, key):
	row = dbcon.execute('SELECT ts FROM premiere_tombstones WHERE kind=? AND key=?', (kind, key)).fetchone()
	return row[0] if row else ''

def _join_lists(dbcon, a_id, b_id):
	"""Funde dos listas locales en la de uid menor. Devuelve el id que queda."""
	ua = dbcon.execute('SELECT uid FROM premiere_lists WHERE id=?', (a_id,)).fetchone()[0] or ''
	ub = dbcon.execute('SELECT uid FROM premiere_lists WHERE id=?', (b_id,)).fetchone()[0] or ''
	keep, drop = (a_id, b_id) if ua <= ub else (b_id, a_id)
	dbcon.execute('UPDATE premiere_items SET list_id=? WHERE list_id=?', (keep, drop))
	dbcon.execute('DELETE FROM premiere_lists WHERE id=?', (drop,))
	return keep

def merge(dbcon, data):
	"""Fusiona el estado de otro aparato en el local. True si cambio algo que se ve."""
	changed = False
	if not isinstance(data, dict): return False
	# 1. lapidas: primero, para que lo borrado no entre por la puerta de al lado
	for t in data.get('tombs') or []:
		if not isinstance(t, dict): continue
		kind, key, ts, reason = _s(t.get('kind')), _s(t.get('key')), _s(t.get('ts')), _s(t.get('reason'))
		if kind not in ('list', 'item') or not key or not ts: continue
		if _tomb_ts(dbcon, kind, key) >= ts: continue
		dbcon.execute('INSERT OR REPLACE INTO premiere_tombstones VALUES (?, ?, ?, ?)', (kind, key, ts, reason or 'user'))
		if kind == 'list':
			row = dbcon.execute('SELECT id, updated FROM premiere_lists WHERE uid=?', (key,)).fetchone()
			if row and (row[1] or '') <= ts:
				dbcon.execute('DELETE FROM premiere_items WHERE list_id=?', (row[0],))
				dbcon.execute('DELETE FROM premiere_lists WHERE id=?', (row[0],))
				changed = True
		elif reason != 'done':
			# 'done' no se aplica: este aparato termina el estreno por su cuenta
			# (lo mete en SU biblioteca) y ya dejara su propia lapida
			try: tmdb, season = key.rsplit(':', 1); season = int(season)
			except: continue
			row = dbcon.execute('SELECT updated FROM premiere_items WHERE tmdb=? AND season=?', (tmdb, season)).fetchone()
			if row and (row[0] or '') <= ts:
				dbcon.execute('DELETE FROM premiere_items WHERE tmdb=? AND season=?', (tmdb, season))
				changed = True
	# 2. listas
	remap = {}
	for L in data.get('lists') or []:
		if not isinstance(L, dict): continue
		uid, name, updated = _s(L.get('uid'), 64), _s(L.get('name'), 100), _s(L.get('updated'))
		if not uid or not name: continue
		if _tomb_ts(dbcon, 'list', uid) >= updated: continue
		row = dbcon.execute('SELECT id, name, updated FROM premiere_lists WHERE uid=?', (uid,)).fetchone()
		if row:
			lid = row[0]
			if updated > (row[2] or '') and name != row[1]:
				clash = dbcon.execute('SELECT id FROM premiere_lists WHERE name=? COLLATE NOCASE AND id != ?', (name, lid)).fetchone()
				if clash: lid = _join_lists(dbcon, lid, clash[0])
				dbcon.execute('UPDATE premiere_lists SET name=?, updated=? WHERE id=?', (name, updated, lid))
				changed = True
			remap[uid] = lid
			continue
		clash = dbcon.execute('SELECT id, uid, updated FROM premiere_lists WHERE name=? COLLATE NOCASE', (name,)).fetchone()
		if clash:
			# la misma lista creada en dos aparatos: todos se quedan con el uid menor
			if uid < (clash[1] or ''):
				dbcon.execute('UPDATE premiere_lists SET uid=?, updated=? WHERE id=?', (uid, max(updated, clash[2] or ''), clash[0]))
			remap[uid] = clash[0]
			continue
		cur = dbcon.execute('INSERT INTO premiere_lists (name, created, uid, updated) VALUES (?, ?, ?, ?)', (name, _s(L.get('created'), 10), uid, updated))
		remap[uid] = cur.lastrowid
		changed = True
	# 3. elementos
	for I in data.get('items') or []:
		if not isinstance(I, dict): continue
		tmdb, updated = _s(str(I.get('tmdb') or ''), 20), _s(I.get('updated'))
		try: season = int(I.get('season'))
		except: continue
		if not tmdb.isdigit() or not updated: continue
		if _tomb_ts(dbcon, 'item', pl.item_key(tmdb, season)) >= updated: continue
		lid = remap.get(_s(I.get('list'), 64))
		if not lid: continue
		row = dbcon.execute('SELECT list_id, updated FROM premiere_items WHERE tmdb=? AND season=?', (tmdb, season)).fetchone()
		if row:
			if updated > (row[1] or ''):
				dbcon.execute('UPDATE premiere_items SET list_id=?, updated=? WHERE tmdb=? AND season=?', (lid, updated, tmdb, season))
				if row[0] != lid: changed = True
			continue
		kind = _s(I.get('kind'), 10) or 'season'
		air_date = _s(I.get('air_date'), 10)
		values = {'list_id': lid, 'kind': kind, 'tmdb': tmdb, 'imdb': _s(I.get('imdb'), 20), 'tvdb': _s(str(I.get('tvdb') or ''), 20),
			'tvshowtitle': _s(I.get('tvshowtitle'), 200), 'year': _s(str(I.get('year') or ''), 4), 'season': season, 'air_date': air_date,
			'state': pl._state_for(air_date), 'notified': '', 'added_on': '', 'poster': _s(I.get('poster'), 500), 'fanart': _s(I.get('fanart'), 500), 'updated': updated}
		dbcon.execute('INSERT INTO premiere_items (%s) VALUES (%s)' % (', '.join(pl._ITEM_COLS), ', '.join('?' * len(pl._ITEM_COLS))), tuple(values[c] for c in pl._ITEM_COLS))
		changed = True
	dbcon.commit()
	return changed


# ---------------------------------------------------------------- red

class _Conn:
	def __init__(self, sock):
		self.sock, self.buf = sock, b''

	def send(self, obj):
		self.sock.sendall((json.dumps(obj, separators=(',', ':')) + '\n').encode('utf-8'))

	def recv(self):
		while b'\n' not in self.buf:
			if len(self.buf) > MAX_LINE: return None
			chunk = self.sock.recv(65536)
			if not chunk: return None
			self.buf += chunk
		line, self.buf = self.buf.split(b'\n', 1)
		try:
			obj = json.loads(line.decode('utf-8'))
			return obj if isinstance(obj, dict) else None
		except: return None

	def close(self):
		try: self.sock.close()
		except: pass

def _open(host, port, timeout):
	sock = socket.create_connection((host, int(port)), timeout=timeout, source_address=(BIND_HOST, 0) if BIND_HOST else None)
	sock.settimeout(timeout + 4)
	return _Conn(sock)

def _private(host):
	try:
		ip = ip_address(host)
		return ip.is_private or ip.is_link_local
	except: return False

def local_ip():
	ip = (control.infoLabel('Network.IPAddress') or '').strip()
	if _private(ip) and not ip.startswith('127.'): return ip
	try:
		s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
		s.settimeout(1.0)
		s.connect(('8.8.8.8', 53)) # UDP: no sale ningun paquete, solo elige la interfaz
		ip = s.getsockname()[0]
		s.close()
		return ip
	except: return ''

def _h(*parts):
	return hashlib.sha256('|'.join(str(p) for p in parts).encode('utf-8')).hexdigest()

def _mac(key, *parts):
	return hmac.new(key.encode('utf-8') if isinstance(key, str) else key, '|'.join(str(p) for p in parts).encode('utf-8'), hashlib.sha256).hexdigest()

def _pair_key(shared, pin, nonce_s, nonce_c, cid, sid, A, B):
	z = shared.to_bytes(256, 'big')
	return hashlib.sha256(b'luc_kodi.psync.pair.v1|' + z + ('|%s|%s|%s|%s|%s|%x|%x' % (pin, nonce_s, nonce_c, cid, sid, A, B)).encode('utf-8')).digest()

def _dh_ok(x):
	return 1 < x < _P - 1


# ---------------------------------------------------------------- lado del que escucha (servicio)

def _serve(sock, addr):
	conn = _Conn(sock)
	sock.settimeout(8)
	dbcon = None
	try:
		dbcon = _connect()
		me = device_id(dbcon)
		nonce_s = secrets.token_hex(16)
		conn.send({'app': APP, 'v': PROTO, 'id': me, 'name': device_name(dbcon), 'port': PORT, 'pairing': bool(_pairing(dbcon)), 'nonce': nonce_s})
		req = conn.recv()
		if not req: return
		op = req.get('op')
		if op == 'pair': _serve_pair(conn, dbcon, req, me, nonce_s, addr)
		elif op == 'sync': _serve_sync(conn, dbcon, req, me, nonce_s, addr)
		elif op == 'unpair': _serve_unpair(conn, dbcon, req, nonce_s)
	except socket.timeout: pass
	except: log_utils.error()
	finally:
		conn.close()
		if dbcon:
			try: dbcon.close()
			except: pass

def _serve_pair(conn, dbcon, req, me, nonce_s, addr):
	p = _pairing(dbcon)
	if not p: return conn.send({'ok': 0, 'err': 'closed'})
	cid, cname, nonce_c = _s(req.get('id'), 64), _s(req.get('name'), 60), _s(req.get('nonce'), 64)
	try: A, cport = int(req.get('A'), 16), int(req.get('port') or PORT)
	except: return conn.send({'ok': 0, 'err': 'bad'})
	if not cid or not nonce_c or cid == me or not _dh_ok(A): return conn.send({'ok': 0, 'err': 'bad'})
	b = secrets.randbits(256)
	B = pow(_G, b, _P)
	conn.send({'ok': 1, 'B': '%x' % B})
	req2 = conn.recv()
	if not req2: return
	key = _pair_key(pow(A, b, _P), p['pin'], nonce_s, nonce_c, cid, me, A, B)
	if not hmac.compare_digest(_s(req2.get('mac'), 64), _mac(key, 'client')):
		p = _pairing(dbcon) or p # releer: puede haber otro intento a la vez
		p['tries'] = p.get('tries', 0) + 1
		if p['tries'] >= PAIR_TRIES:
			_meta_set(dbcon, 'psync_pairing', None)
			_meta_set(dbcon, 'psync_result', json.dumps({'status': 'locked'}))
			return conn.send({'ok': 0, 'err': 'locked'})
		_meta_set(dbcon, 'psync_pairing', json.dumps(p))
		return conn.send({'ok': 0, 'err': 'pin', 'left': PAIR_TRIES - p['tries']})
	_save_peer(dbcon, cid, cname or addr[0], addr[0], cport, _mac(key, 'secret'))
	_meta_set(dbcon, 'psync_pairing', None)
	_meta_set(dbcon, 'psync_result', json.dumps({'status': 'ok', 'name': cname or addr[0]}))
	conn.send({'ok': 1, 'mac': _mac(key, 'server')})

def _serve_sync(conn, dbcon, req, me, nonce_s, addr):
	pid, nonce_c, body = _s(req.get('id'), 64), _s(req.get('nonce'), 64), req.get('body')
	peer = _get_peer(dbcon, pid)
	if not peer or not nonce_c or not isinstance(body, str): return conn.send({'ok': 0, 'err': 'unknown'})
	if not hmac.compare_digest(_s(req.get('mac'), 64), _mac(peer['secret'], 'sync', pid, nonce_s, nonce_c, _h(body))):
		return conn.send({'ok': 0, 'err': 'unknown'})
	changed = merge(dbcon, json.loads(body))
	changes = {'host': addr[0], 'last_sync': pl.stamp()}
	try: changes['port'] = int(req.get('port') or PORT)
	except: pass
	name = _s(req.get('name'), 60)
	if name: changes['name'] = name
	_touch_peer(dbcon, pid, **changes)
	out = json.dumps(snapshot(dbcon), sort_keys=True, separators=(',', ':'))
	conn.send({'ok': 1, 'body': out, 'mac': _mac(peer['secret'], 'resp', me, nonce_s, nonce_c, _h(out))})
	if changed:
		pl.mark_dirty() # con tres o mas aparatos, lo que llega de uno sigue hacia los demas
		_on_changed()

def _serve_unpair(conn, dbcon, req, nonce_s):
	pid, nonce_c = _s(req.get('id'), 64), _s(req.get('nonce'), 64)
	peer = _get_peer(dbcon, pid)
	if peer and nonce_c and hmac.compare_digest(_s(req.get('mac'), 64), _mac(peer['secret'], 'unpair', pid, nonce_s, nonce_c)):
		dbcon.execute('DELETE FROM premiere_peers WHERE id=?', (pid,))
		dbcon.commit()
		conn.send({'ok': 1})
		control.notification(title=getLS(32733), message=getLS(32752) % peer['name'])
	else: conn.send({'ok': 0})

def _on_changed():
	"""Llegaron cambios: si el usuario esta mirando Premiere Lists, se repinta."""
	try:
		if 'library_premiere' in (control.infoLabel('Container.FolderPath') or ''): control.refresh()
	except: pass


class Server:
	def __init__(self):
		self.tcp = self.udp = None

	@property
	def open(self):
		return self.tcp is not None

	def start(self):
		try:
			tcp = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
			tcp.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
			tcp.bind((BIND_HOST, PORT))
			tcp.listen(8)
			tcp.setblocking(False)
		except Exception as e:
			log_utils.log('Premiere sync: cannot listen on TCP %s (%s)' % (PORT, e), level=log_utils.LOGWARNING)
			try: tcp.close()
			except: pass
			return False
		udp = None
		try:
			udp = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
			udp.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
			udp.bind((BIND_HOST, PORT))
			udp.setblocking(False)
		except Exception as e:
			# sin UDP los demas aun lo encuentran con el barrido TCP
			log_utils.log('Premiere sync: no UDP discovery on %s (%s)' % (PORT, e), level=log_utils.LOGWARNING)
			try: udp.close()
			except: pass
			udp = None
		self.tcp, self.udp = tcp, udp
		return True

	def stop(self):
		for s in (self.tcp, self.udp):
			try:
				if s: s.close()
			except: pass
		self.tcp = self.udp = None

	def poll(self, timeout):
		socks = [s for s in (self.tcp, self.udp) if s]
		try: ready = select.select(socks, [], [], timeout)[0]
		except: return
		for s in ready:
			if s is self.tcp:
				try: sock, addr = self.tcp.accept()
				except: continue
				sock.setblocking(True)
				if not _private(addr[0]):
					try: sock.close()
					except: pass
					continue
				_serve(sock, addr)
			else:
				self._answer_find()

	def _answer_find(self):
		try: data, addr = self.udp.recvfrom(2048)
		except: return
		if not _private(addr[0]): return
		try:
			msg = json.loads(data.decode('utf-8'))
			if msg.get('app') != APP or msg.get('op') != 'find': return
		except: return
		dbcon = _connect()
		try: reply = {'app': APP, 'op': 'here', 'v': PROTO, 'id': device_id(dbcon), 'name': device_name(dbcon), 'port': PORT, 'pairing': bool(_pairing(dbcon))}
		finally: dbcon.close()
		try: self.udp.sendto(json.dumps(reply).encode('utf-8'), addr)
		except: pass


def _want_listen():
	dbcon = _connect()
	try:
		peers = dbcon.execute('SELECT COUNT(*) FROM premiere_peers').fetchone()[0]
		return bool(peers) or bool(_pairing(dbcon)), bool(peers)
	finally: dbcon.close()

def service_loop():
	monitor, home = control.monitor, control.homeWindow
	if monitor.waitForAbort(10): return
	server = Server()
	last_check, retry_at, has_peers = 0, 0, False
	last_wake = home.getProperty('luc_kodi.psync.wake')
	last_dirty = home.getProperty('luc_kodi.psync.dirty')
	next_auto = time.time() + 20
	worker = None
	try:
		while not monitor.abortRequested():
			now = time.time()
			wake = home.getProperty('luc_kodi.psync.wake')
			if wake != last_wake or now - last_check >= 5:
				last_wake, last_check = wake, now
				try: want, has_peers = _want_listen()
				except:
					log_utils.error()
					want = False
				if want and not server.open and now >= retry_at:
					if server.start(): home.setProperty('luc_kodi.psync.listening', '1')
					else:
						home.setProperty('luc_kodi.psync.listening', 'fail')
						retry_at = now + 30
				elif not want and server.open:
					server.stop()
					home.clearProperty('luc_kodi.psync.listening')
			if server.open: server.poll(1.0)
			elif monitor.waitForAbort(1): break
			if not has_peers: continue
			dirty = home.getProperty('luc_kodi.psync.dirty')
			if dirty != last_dirty:
				last_dirty = dirty
				next_auto = min(next_auto, time.time() + 3) # se juntan los cambios seguidos
			if time.time() >= next_auto and (worker is None or not worker.is_alive()):
				worker = Thread(target=_auto_sync)
				worker.start()
				next_auto = time.time() + AUTO_MINUTES * 60
	finally:
		server.stop()
		home.clearProperty('luc_kodi.psync.listening')

def _auto_sync():
	try:
		results = sync_all(timeout=4, rediscover=True)
		if any(r.get('changed') for r in results.values()): _on_changed()
	except: log_utils.error()


# ---------------------------------------------------------------- lado del que llama

def discover(wait=2.0, want_id=None, sweep=True):
	"""Los luc_kodi de la red: {id: {id, name, host, port, pairing}}. El propio no sale."""
	dbcon = _connect()
	try: me = device_id(dbcon)
	finally: dbcon.close()
	mine = local_ip()
	found = {}
	def keep(info, host):
		if not isinstance(info, dict) or info.get('app') != APP: return
		pid = _s(info.get('id'), 64)
		if not pid or (pid == me and host in (mine, '127.0.0.1')): return
		try: port = int(info.get('port') or PORT)
		except: port = PORT
		found[pid] = {'id': pid, 'name': _s(info.get('name'), 60) or host, 'host': host, 'port': port, 'pairing': bool(info.get('pairing')), 'clone': pid == me}
	try:
		udp = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
		udp.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)
		udp.settimeout(0.3)
		msg = json.dumps({'app': APP, 'op': 'find', 'v': PROTO, 'id': me}).encode('utf-8')
		targets = ['255.255.255.255']
		if mine.count('.') == 3: targets.append(mine.rsplit('.', 1)[0] + '.255')
		for _ in range(2): # dos veces: el primer paquete a veces se pierde en la wifi
			for t in targets:
				try: udp.sendto(msg, (t, PORT))
				except: pass
		deadline = time.time() + wait
		while time.time() < deadline:
			try: data, addr = udp.recvfrom(2048)
			except socket.timeout: continue
			except: break
			try: keep(json.loads(data.decode('utf-8')), addr[0])
			except: pass
			if want_id and want_id in found: break
		udp.close()
	except: log_utils.error()
	if not found and sweep and mine.count('.') == 3: _sweep(mine, keep)
	return found

def _sweep(mine, keep):
	"""Sin respuesta al aviso (wifi que filtra difusion): se prueba el puerto en toda la /24."""
	base = mine.rsplit('.', 1)[0]
	hosts = ['%s.%d' % (base, n) for n in range(1, 255) if '%s.%d' % (base, n) != mine]
	def probe(chunk):
		for host in chunk:
			try:
				conn = _open(host, PORT, 0.4)
				try:
					conn.sock.settimeout(1.0)
					keep(conn.recv(), host)
				finally: conn.close()
			except: pass
	threads = [Thread(target=probe, args=(hosts[i::32],)) for i in range(32)]
	[i.start() for i in threads]
	[i.join() for i in threads]

def pair(host, port, pin):
	"""Empareja con el aparato que muestra el PIN. Devuelve (estado, datos)."""
	dbcon = _connect()
	try: me, myname = device_id(dbcon), device_name(dbcon)
	finally: dbcon.close()
	try: conn = _open(host, port, 6)
	except: return 'net', {}
	try:
		hello = conn.recv()
		if not hello or hello.get('app') != APP: return 'net', {}
		sid, sname = _s(hello.get('id'), 64), _s(hello.get('name'), 60) or host
		if not hello.get('pairing'): return 'closed', {'name': sname}
		a = secrets.randbits(256)
		A = pow(_G, a, _P)
		nonce_c = secrets.token_hex(16)
		conn.send({'op': 'pair', 'id': me, 'name': myname, 'port': PORT, 'A': '%x' % A, 'nonce': nonce_c})
		r = conn.recv()
		if not r or not r.get('ok'): return (r or {}).get('err') or 'net', {'name': sname}
		B = int(r.get('B'), 16)
		if not _dh_ok(B): return 'bad', {'name': sname}
		key = _pair_key(pow(B, a, _P), pin, hello.get('nonce'), nonce_c, me, sid, A, B)
		conn.send({'mac': _mac(key, 'client')})
		r = conn.recv()
		if not r: return 'net', {'name': sname}
		if not r.get('ok'): return r.get('err') or 'bad', {'name': sname, 'left': r.get('left')}
		if not hmac.compare_digest(_s(r.get('mac'), 64), _mac(key, 'server')): return 'bad', {'name': sname}
		dbcon = _connect()
		try: _save_peer(dbcon, sid, sname, host, hello.get('port') or port, _mac(key, 'secret'))
		finally: dbcon.close()
		return 'ok', {'id': sid, 'name': sname}
	except socket.timeout: return 'net', {}
	except:
		log_utils.error()
		return 'net', {}
	finally: conn.close()

def sync_peer(peer, timeout=4):
	"""Un viaje de ida y vuelta con un aparato emparejado. {'status', 'changed'}"""
	try: conn = _open(peer['host'], peer['port'], timeout)
	except: return {'status': 'net', 'changed': False}
	dbcon = None
	try:
		hello = conn.recv()
		if not hello or hello.get('app') != APP: return {'status': 'net', 'changed': False}
		if hello.get('id') != peer['id']: return {'status': 'moved', 'changed': False} # otro aparato tiene ahora esa IP
		dbcon = _connect()
		me = device_id(dbcon)
		body = json.dumps(snapshot(dbcon), sort_keys=True, separators=(',', ':'))
		nonce_s, nonce_c = _s(hello.get('nonce'), 64), secrets.token_hex(16)
		conn.send({'op': 'sync', 'id': me, 'name': device_name(dbcon), 'port': PORT, 'nonce': nonce_c, 'body': body,
			'mac': _mac(peer['secret'], 'sync', me, nonce_s, nonce_c, _h(body))})
		r = conn.recv()
		if not r: return {'status': 'net', 'changed': False}
		if not r.get('ok'): return {'status': r.get('err') or 'bad', 'changed': False}
		out = r.get('body')
		if not isinstance(out, str) or not hmac.compare_digest(_s(r.get('mac'), 64), _mac(peer['secret'], 'resp', peer['id'], nonce_s, nonce_c, _h(out))):
			return {'status': 'bad', 'changed': False}
		changed = merge(dbcon, json.loads(out))
		_touch_peer(dbcon, peer['id'], last_sync=pl.stamp(), name=_s(hello.get('name'), 60) or peer['name'])
		return {'status': 'ok', 'changed': changed}
	except socket.timeout: return {'status': 'net', 'changed': False}
	except:
		log_utils.error()
		return {'status': 'net', 'changed': False}
	finally:
		conn.close()
		if dbcon:
			try: dbcon.close()
			except: pass

def sync_all(timeout=4, rediscover=True):
	"""Con todos los aparatos emparejados a la vez. {peer_id: resultado}"""
	dbcon = _connect()
	try: peers = get_peers(dbcon)
	finally: dbcon.close()
	results = {}
	def one(peer):
		res = sync_peer(peer, timeout)
		if res['status'] in ('net', 'moved') and rediscover:
			# la IP cambio (DHCP): se le busca por su id
			hit = discover(1.5, want_id=peer['id'], sweep=False).get(peer['id'])
			if hit and hit['host'] != peer['host']:
				peer = dict(peer, host=hit['host'], port=hit['port'])
				db = _connect()
				try: _touch_peer(db, peer['id'], host=peer['host'], port=peer['port'])
				finally: db.close()
				res = sync_peer(peer, timeout)
		res['name'] = peer['name']
		results[peer['id']] = res
	threads = [Thread(target=one, args=(p,)) for p in peers]
	[i.start() for i in threads]
	[i.join() for i in threads]
	return results

def quick_sync():
	"""Al abrir Premiere Lists: rapido, sin buscar, y como mucho una vez por minuto."""
	try:
		home = control.homeWindow
		last = home.getProperty('luc_kodi.psync.quick')
		if last and time.time() - float(last) < QUICK_SECONDS: return False
		home.setProperty('luc_kodi.psync.quick', str(time.time()))
		dbcon = _connect()
		try: has = dbcon.execute('SELECT COUNT(*) FROM premiere_peers').fetchone()[0]
		finally: dbcon.close()
		if not has: return False
		return any(r.get('changed') for r in sync_all(timeout=1.2, rediscover=False).values())
	except:
		log_utils.error()
		return False

def peer_count():
	try:
		dbcon = _connect()
		try: return dbcon.execute('SELECT COUNT(*) FROM premiere_peers').fetchone()[0]
		finally: dbcon.close()
	except: return 0


# ---------------------------------------------------------------- dialogos

def _when(ts):
	if not ts: return getLS(32756)
	try:
		t = time.localtime(timegm(datetime.strptime(ts[:19], '%Y-%m-%dT%H:%M:%S').timetuple()))
		return '%02d %s %02d:%02d' % (t.tm_mday, pl.MONTHS[t.tm_mon - 1], t.tm_hour, t.tm_min)
	except: return ts[:16]

def _wake():
	control.homeWindow.setProperty('luc_kodi.psync.wake', pl.stamp())

def _ensure_name():
	dbcon = _connect()
	try:
		if _meta(dbcon, 'psync_name'): return True
		name = device_name(dbcon)
		if _generic(name):
			name = control.dialog.input(getLS(32739)).strip()[:40]
			if not name: return False
		_meta_set(dbcon, 'psync_name', name)
		return True
	finally: dbcon.close()

def menu():
	try:
		dbcon = _connect()
		try: peers, name = get_peers(dbcon), device_name(dbcon)
		finally: dbcon.close()
		options = [(getLS(32734), show_pin), (getLS(32735), join)]
		if peers:
			options.append((getLS(32736), sync_now))
			options.append((getLS(32737) % len(peers), manage))
		options.append(('[COLOR %s]%s[/COLOR]' % (GREY, getLS(32738) % name), rename_device))
		pick = control.selectDialog([o[0] for o in options], heading=getLS(32733))
		if pick >= 0: options[pick][1]()
	except: log_utils.error()

def show_pin():
	"""Este aparato muestra el PIN y espera a que otro se una."""
	if not _ensure_name(): return
	pin = '%08d' % secrets.randbelow(10 ** 8)
	dbcon = _connect()
	try:
		name = device_name(dbcon)
		_meta_set(dbcon, 'psync_result', None)
		_meta_set(dbcon, 'psync_pairing', json.dumps({'pin': pin, 'expires': time.time() + PAIR_SECONDS, 'tries': 0}))
	finally: dbcon.close()
	home = control.homeWindow
	if home.getProperty('luc_kodi.psync.listening') == 'fail': home.clearProperty('luc_kodi.psync.listening')
	_wake()
	# el servicio abre el puerto en cuanto ve el PIN; se le espera un poco
	for _ in range(24):
		if home.getProperty('luc_kodi.psync.listening') in ('1', 'fail'): break
		if control.monitor.waitForAbort(0.25): return
	if home.getProperty('luc_kodi.psync.listening') != '1':
		_end_pairing()
		return control.okDialog(title=getLS(32733), message=getLS(32753) % PORT)
	ip = local_ip()
	result = None
	pd = control.progressDialog
	pd.create(getLS(32733))
	try:
		end = time.time() + PAIR_SECONDS
		while True:
			left = end - time.time()
			if left <= 0: break
			text = '%s\n[B][COLOR %s]%s  %s[/COLOR][/B]\n[COLOR %s]%s[/COLOR]' % (
				getLS(32740) % name, AMBER, pin[:4], pin[4:], GREY, getLS(32738) % ('%s · %s' % (name, ip) if ip else name))
			pd.update(int(left * 100 / PAIR_SECONDS), text)
			if pd.iscanceled(): break
			dbcon = _connect()
			try: raw = _meta(dbcon, 'psync_result')
			finally: dbcon.close()
			if raw:
				try: result = json.loads(raw)
				except: result = None
				break
			if control.monitor.waitForAbort(0.5): break
	finally:
		pd.close()
		_end_pairing()
	if not result: return
	if result.get('status') == 'ok':
		control.notification(title=getLS(32733), message=getLS(32748) % result.get('name', ''), time=5000)
		_wake()
		_refresh_if_lists()
	elif result.get('status') == 'locked':
		control.okDialog(title=getLS(32733), message=getLS(32746) % name)

def _end_pairing():
	dbcon = _connect()
	try:
		_meta_set(dbcon, 'psync_pairing', None)
		_meta_set(dbcon, 'psync_result', None)
	finally: dbcon.close()
	_wake()

def join():
	"""Este aparato busca al que muestra el PIN y se une."""
	if not _ensure_name(): return
	control.busy()
	try: found = discover(2.5, sweep=True)
	finally: control.hide()
	clones = [f for f in found.values() if f.get('clone')]
	if clones:
		# configuracion copiada de otro aparato (backup/wizard): mismo id. Este se hace uno nuevo.
		# Solo si este aun no tiene parejas, para no dejar huerfanas las que ya tiene.
		dbcon = _connect()
		try:
			if not get_peers(dbcon):
				device_id(dbcon, renew=True)
				for f in clones: f['clone'] = False
		finally: dbcon.close()
	entries = sorted([f for f in found.values() if not f.get('clone')], key=lambda f: (not f['pairing'], f['name'].lower()))
	labels = ['%s  [COLOR %s]· %s · %s[/COLOR]' % (f['name'], GREY, f['host'], getLS(32754) if f['pairing'] else getLS(32755)) for f in entries]
	labels.append('[COLOR %s]%s[/COLOR]' % (AMBER, getLS(32742)))
	if not entries: control.notification(title=getLS(32733), message=getLS(32743), time=6000)
	pick = control.selectDialog(labels, heading=getLS(32741))
	if pick < 0: return
	if pick == len(entries):
		import xbmcgui
		host = control.dialog.input(getLS(32757), type=xbmcgui.INPUT_IPADDRESS).strip()
		if not host: return
		target = {'host': host, 'port': PORT, 'name': host, 'pairing': True}
	else:
		target = entries[pick]
		if not target['pairing']:
			return control.okDialog(title=getLS(32733), message=getLS(32747) % (target['name'], target['name']))
	while True:
		pin = ''.join(c for c in (control.dialog.numeric(0, getLS(32744) % target['name']) or '') if c.isdigit())
		if not pin: return
		if len(pin) != 8:
			control.notification(title=getLS(32733), message=32745)
			continue
		control.busy()
		try:
			status, info = pair(target['host'], target['port'], pin)
			res = sync_peer({'id': info['id'], 'name': info['name'], 'host': target['host'], 'port': target['port'], 'secret': _secret_of(info['id'])}) if status == 'ok' else None
		finally: control.hide()
		name = info.get('name') or target['name']
		if status == 'ok':
			msg = getLS(32760) % name if res and res['status'] == 'ok' else getLS(32748) % name
			control.notification(title=getLS(32733), message=msg, time=5000)
			_wake()
			return _refresh_if_lists()
		if status == 'pin' and info.get('left'):
			control.notification(title=getLS(32733), message='%s (%s)' % (getLS(32745), info['left']))
			continue
		if status == 'locked': return control.okDialog(title=getLS(32733), message=getLS(32746) % name)
		if status == 'closed': return control.okDialog(title=getLS(32733), message=getLS(32747) % (name, name))
		return control.okDialog(title=getLS(32733), message=getLS(32750) % name)

def _secret_of(pid):
	dbcon = _connect()
	try: return (_get_peer(dbcon, pid) or {}).get('secret', '')
	finally: dbcon.close()

def sync_now():
	control.busy()
	try: results = sync_all(timeout=5, rediscover=True)
	finally: control.hide()
	ok = [r['name'] for r in results.values() if r['status'] == 'ok']
	bad = [r['name'] for r in results.values() if r['status'] != 'ok']
	if ok: control.notification(title=getLS(32733), message=getLS(32749) % ', '.join(ok), time=4000)
	if bad: control.okDialog(title=getLS(32733), message=getLS(32750) % ', '.join(bad))
	_refresh_if_lists()

def manage():
	dbcon = _connect()
	try: peers = get_peers(dbcon)
	finally: dbcon.close()
	if not peers: return
	labels = ['%s  [COLOR %s]· %s · %s[/COLOR]' % (p['name'], GREY, p['host'], getLS(32758) % _when(p['last_sync'])) for p in peers]
	pick = control.selectDialog(labels, heading=getLS(32737) % len(peers))
	if pick < 0: return
	peer = peers[pick]
	if not control.yesnoDialog(getLS(32751) % peer['name'], '', ''): return
	try: # se avisa al otro, si esta encendido, para que tampoco siga intentandolo
		conn = _open(peer['host'], peer['port'], 1.5)
		try:
			hello = conn.recv()
			if hello and hello.get('id') == peer['id']:
				dbcon = _connect()
				try: me = device_id(dbcon)
				finally: dbcon.close()
				nonce_c = secrets.token_hex(16)
				conn.send({'op': 'unpair', 'id': me, 'nonce': nonce_c, 'mac': _mac(peer['secret'], 'unpair', me, _s(hello.get('nonce'), 64), nonce_c)})
				conn.recv()
		finally: conn.close()
	except: pass
	dbcon = _connect()
	try:
		dbcon.execute('DELETE FROM premiere_peers WHERE id=?', (peer['id'],))
		dbcon.commit()
	finally: dbcon.close()
	_wake()
	control.notification(title=getLS(32733), message=getLS(32752) % peer['name'])
	_refresh_if_lists()

def rename_device():
	dbcon = _connect()
	try:
		name = control.dialog.input(getLS(32739), defaultt=device_name(dbcon)).strip()[:40]
		if name: _meta_set(dbcon, 'psync_name', name)
	finally: dbcon.close()
	if name: _refresh_if_lists()

def _refresh_if_lists():
	if 'library_premiere' in (control.infoLabel('Container.FolderPath') or ''): control.refresh()
