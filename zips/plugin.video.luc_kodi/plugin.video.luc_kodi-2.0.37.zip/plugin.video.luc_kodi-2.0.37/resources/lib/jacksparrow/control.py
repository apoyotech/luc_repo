"""
	jacksparrowscrapers Module
"""

from json import dumps as jsdumps, loads as jsloads
import os.path
import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs
import xml.etree.ElementTree as ET
from resources.lib.modules.kodi_objects import Lazy

# v2.0.14: Kodi objects made when first used and released at the end of every
# run, as in modules/control.py (see modules/kodi_objects.py).
addon = xbmcaddon.Addon
addonObject = Lazy(lambda: addon('plugin.video.luc_kodi'), 'Addon (scrapers)') # addonObject = addon('script.module.jacksparrowscrapers')

def addonInfo(key):
	return addonObject.getAddonInfo(key)

def getLangString(language_id):
	return addonObject.getLocalizedString(language_id)

condVisibility = xbmc.getCondVisibility
execute = xbmc.executebuiltin
jsonrpc = xbmc.executeJSONRPC
monitor_class = xbmc.Monitor
monitor = Lazy(xbmc.Monitor, 'Monitor (scrapers)')

dialog = Lazy(xbmcgui.Dialog, 'Dialog (scrapers)')
homeWindow = Lazy(lambda: xbmcgui.Window(10000), 'Window(10000) (scrapers)')

existsPath = xbmcvfs.exists
openFile = xbmcvfs.File
makeFile = xbmcvfs.mkdir
makeDirs = xbmcvfs.mkdirs
transPath = xbmcvfs.translatePath
joinPath = os.path.join

SETTINGS_PATH = transPath(joinPath(addonInfo('path'), 'resources', 'settings.xml'))
try: dataPath = transPath(addonInfo('profile')).decode('utf-8')
except Exception: dataPath = transPath(addonInfo('profile'))
#cacheFile = joinPath(dataPath, 'cache.db')
#undesirablescacheFile = joinPath(dataPath, 'undesirables.db')
cacheFile = joinPath(dataPath, 'jacksparrowcache.db')
undesirablescacheFile = joinPath(dataPath, 'jacksparrowundesirables.db')
settingsFile = joinPath(dataPath, 'settings.xml')


def setting(id, fallback=None):
#	try: settings_dict = jsloads(homeWindow.getProperty('jacksparrowscrapers_settings'))
	try: settings_dict = jsloads(homeWindow.getProperty('luc_kodi_settings'))
	except Exception: settings_dict = make_settings_dict()
	if settings_dict is None: settings_dict = settings_fallback(id)
	# v2.0.32: un ajuste que aun no esta en el settings.xml del perfil (uno nuevo
	# tras actualizar, hasta que Kodi escribe sus valores) vale su default del
	# addon, no ''. Antes un scraper nuevo encendido por defecto quedaba apagado
	# en la primera busqueda tras la actualizacion (LimeTorrents, 11-nov-2026).
	if id in settings_dict: value = settings_dict[id]
	else: value = addon_default(id)
	if fallback is None: return value
	if value == '': return fallback
	return value

_DEFAULTS = []

def addon_default(id):
	"""default="" de resources/settings.xml del addon, leido UNA vez por proceso."""
	if not _DEFAULTS:
		try: _DEFAULTS.append({i.get('id'): i.get('default') or '' for i in ET.parse(SETTINGS_PATH).getroot().iter('setting') if i.get('id')})
		except Exception: _DEFAULTS.append({})
	return _DEFAULTS[0].get(id, '')

def settings_fallback(id):
	return {id: addonObject.getSetting(id)}

def setSetting(id, value):
	return addonObject.setSetting(id, value)

def make_settings_dict(): # service runs upon a setting change
	try:
		root = ET.parse(settingsFile).getroot()
		settings_dict = {}
		for item in root:
			dict_item = {}
			setting_id = item.get('id')
			setting_value = item.text
			if setting_value is None: setting_value = ''
			dict_item = {setting_id: setting_value}
			settings_dict.update(dict_item)
#		homeWindow.setProperty('jacksparrowscrapers_settings', jsdumps(settings_dict))
		homeWindow.setProperty('luc_kodi_settings', jsdumps(settings_dict))
		return settings_dict
	except Exception:
		return None

def refresh_debugReversed(): # called from service "onSettingsChanged" to clear jacksparrowscrapers.log if setting to reverse has been changed
	if homeWindow.getProperty('jacksparrowscrapers.debug.reversed') != setting('debug.reversed'):
		homeWindow.setProperty('jacksparrowscrapers.debug.reversed', setting('debug.reversed'))
		execute('RunPlugin(plugin://script.module.jacksparrowscrapers/?action=tools_clearLogFile)')

def lang(language_id):
	return getLangString(language_id)

def sleep(time):  # Modified `sleep` command that honors a user exit request
	while time > 0 and not monitor.abortRequested():
		xbmc.sleep(min(100, time))
		time = time - 100

def isVersionUpdate():
	versionFile = joinPath(dataPath, 'installed.version')
	try:
		if not xbmcvfs.exists(versionFile):
			f = open(versionFile, 'w')
			f.close()
	except Exception:
		LOGINFO = 1 # (LOGNOTICE(2) deprecated in 19, use LOGINFO(1))
		xbmc.log('jacksparrowScrapers Addon Data Path Does not Exist. Creating Folder....', LOGINFO)
		addon_folder = transPath('special://profile/addon_data/script.module.jacksparrowscrapers')
		xbmcvfs.mkdirs(addon_folder)
	try:
		with open(versionFile, 'r') as fh: oldVersion = fh.read()
	except Exception: oldVersion = '0'
	try:
		curVersion = addon('script.module.jacksparrowscrapers').getAddonInfo('version')
		if oldVersion != curVersion:
			with open(versionFile, 'w') as fh: fh.write(curVersion)
			return True
		else: return False
	except Exception:
		from resources.lib.jacksparrow import log_utils
		log_utils.error()
		return False

def clean_settings():
	def _make_content(dict_object):
		content = '<settings version="2">'
		for item in dict_object:
			if item['id'] in active_settings:
				if 'default' in item and 'value' in item: content += '\n    <setting id="%s" default="%s">%s</setting>' % (item['id'], item['default'], item['value'])
				elif 'default' in item: content += '\n    <setting id="%s" default="%s"></setting>' % (item['id'], item['default'])
				elif 'value' in item: content += '\n    <setting id="%s">%s</setting>' % (item['id'], item['value'])
				else: content += '\n    <setting id="%s"></setting>'
			else: removed_settings.append(item)
		content += '\n</settings>'
		return content
	addon_id = 'script.module.jacksparrowscrapers'
	try:
		removed_settings = []
		active_settings = []
		current_user_settings = []
		addon = xbmcaddon.Addon(id=addon_id)
		addon_name = addon.getAddonInfo('name')
		addon_dir = transPath(addon.getAddonInfo('path'))
		profile_dir = transPath(addon.getAddonInfo('profile'))
		active_settings_xml = joinPath(addon_dir, 'resources', 'settings.xml')
		root = ET.parse(active_settings_xml).getroot()
		for item in root.findall(r'./category/setting'):
			setting_id = item.get('id')
			if setting_id:
				active_settings.append(setting_id)
		settings_xml = joinPath(profile_dir, 'settings.xml')
		root = ET.parse(settings_xml).getroot()
		for item in root:
			dict_item = {}
			setting_id = item.get('id')
			setting_default = item.get('default')
			setting_value = item.text
			dict_item['id'] = setting_id
			if setting_value:
				dict_item['value'] = setting_value
			if setting_default:
				dict_item['default'] = setting_default
			current_user_settings.append(dict_item)
		new_content = _make_content(current_user_settings)
		nfo_file = xbmcvfs.File(settings_xml, 'w')
		nfo_file.write(new_content)
		nfo_file.close()
		sleep(200)
		notification(title=addon_name, message=lang(32042).format(str(len(removed_settings))))
	except Exception:
		from resources.lib.jacksparrow import log_utils
		log_utils.error()
		notification(title=addon_name, message=32043)

def addonId():
	return addonInfo('id')

def addonName():
	return addonInfo('name')

def addonVersion():
	return addonInfo('version')

def addonIcon():
	return addonInfo('icon')

def addonPath():
	try: return transPath(addonInfo('path').decode('utf-8'))
	except Exception: return transPath(addonInfo('path'))

def openSettings(query=None, id=addonInfo('id')):
	# v2.0.13: la misma de luc_kodi (ids de categoria de Kodi 21+ y de Kodi 20)
	try:
		from resources.lib.modules import control as _luc_control
		return _luc_control.openSettings(query, id)
	except Exception:
		return

def getSettingDefault(id):
	import re
	try:
		settings = open(SETTINGS_PATH, 'r')
		value = ' '.join(settings.readlines())
		value.strip('\n')
		settings.close()
		value = re.findall(r'id=\"%s\".*?default=\"(.*?)\"' % (id), value)[0]
		return value
	except Exception:
		return None

def idle():
	if int(xbmc.getInfoLabel("System.BuildVersion")[:2]) >= 18 and condVisibility('Window.IsActive(busydialognocancel)'):
		return execute('Dialog.Close(busydialognocancel)')
	else:
		return execute('Dialog.Close(busydialog)')

def yesnoDialog(line, heading=addonInfo('name'), nolabel='', yeslabel=''):
	return dialog.yesno(heading, line, nolabel, yeslabel)

def selectDialog(list, heading=addonInfo('name')):
	return dialog.select(heading, list)

def multiselectDialog(list, preselect=[], heading=addonInfo('name')):
	return dialog.multiselect(heading, list, preselect=preselect)

def notification(title=None, message=None, icon=None, time=3000, sound=False):
	"""
	Plugin-wide notification entry point used by the jacksparrow framework
	(scrapers, sootio_wizard, undesirables cache, log_utils, etc.).

	Delegates to the unified luc_kodi notification (modules.control.notification)
	so EVERY notification — regardless of origin module — renders in the same
	top-center phone-style XML window. This used to call xbmcgui.Dialog().notification()
	directly, which Kodi always pins to the bottom-right corner; the delegation
	makes notification placement consistent across the whole plugin.

	The original native call is kept as a defensive fallback in case the unified
	path is unavailable (e.g. import error during a startup race or partial install).
	"""
	try:
		# Lazy import to avoid any startup-time ordering issues between
		# the jacksparrow framework and the luc_kodi modules layer.
		from resources.lib.modules import control as _luc_control
		_luc_control.notification(title=title, message=message, icon=icon, time=time, sound=sound)
		return
	except Exception:
		pass  # fall through to native fallback below

	# --- Defensive fallback (native Kodi toast, bottom-right) ----------------
	if title == 'default' or title is None: title = addonName()
	if isinstance(title, int): heading = lang(title)
	else: heading = str(title)
	if isinstance(message, int): body = lang(message)
	else: body = str(message)
	if icon is None or icon == '' or icon == 'default': icon = addonIcon()
	elif icon == 'INFO': icon = xbmcgui.NOTIFICATION_INFO
	elif icon == 'WARNING': icon = xbmcgui.NOTIFICATION_WARNING
	elif icon == 'ERROR': icon = xbmcgui.NOTIFICATION_ERROR
	dialog.notification(heading, body, icon, time, sound=sound)

