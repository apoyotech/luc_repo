"""
	luc_kodi Add-on
"""
from resources.lib.modules import app_keys
from ast import literal_eval as _ast_literal_eval
import threading as _threading

# ── v1.0.54: literal_eval serializado ──────────────────────────────────
# Los ~17 scrapers corren en hilos y cada uno hace literal_eval() del blob
# cacheado en rel_src. En Python 3.13 (Kodi 21/22) la construccion del AST
# lleva el contador de recursion en el estado del hilo y, con varias
# llamadas simultaneas sobre literales grandes, revienta con:
#   SystemError: AST constructor recursion depth mismatch (before=N, after=M)
# El except lo tragaba y ese scraper se quedaba sin sus fuentes cacheadas,
# de ahi el "no stream" intermitente. Easynews lo destapo porque devuelve
# hasta 250 items con URLs y nombres muy largos: el blob mas grande que
# se ha escrito nunca en esa cache.
_literal_eval_lock = _threading.Lock()


def literal_eval(value):
	with _literal_eval_lock:
		return _ast_literal_eval(value)
# ───────────────────────────────────────────────────────────────────────

from collections import deque
from itertools import islice
from resources.lib.database.blobcodec import pack as _blob_pack, unpack as _blob_unpack # v1.0.91
from datetime import datetime, timedelta
from json import dumps as jsdumps, loads as jsloads
import re
import _strptime # import _strptime to workaround python 2 bug with threads
from sys import argv, exit as sysexit
from threading import Thread
from time import time
from urllib.parse import unquote, quote_plus
from sqlite3 import dbapi2 as database
from resources.lib.database import metacache, providerscache
from resources.lib.modules import cleandate
from resources.lib.modules import control
from resources.lib.modules import debrid
from resources.lib.modules import lang_assist
from resources.lib.modules import log_utils
from resources.lib.modules import string_tools
from resources.lib.modules.source_utils import supported_video_extensions, getFileType, aliases_check
from resources.lib.cloud_scrapers import cloudSources
from resources.lib.jacksparrow import sources as fs_sources
from resources.lib.jacksparrow import client as fs_client   # v1.0.65: para scrub_url() en los logs

homeWindow = control.homeWindow
playerWindow = control.playerWindow
getLS = control.lang
getSetting = control.setting


def _pm_available():
	"""Premiumize activo y con token."""
	try:
		return getSetting('premiumize.enable') == 'true' and bool(getSetting('premiumize.token'))
	except Exception:
		return False


def _tb_available():
	"""TorBox activo y con token."""
	try:
		return getSetting('torbox.enable') == 'true' and bool(getSetting('torbox.token'))
	except Exception:
		return False


# v1.0.59: el scraper generico Newznab queda ATADO a Premiumize (hasta la v2.0.13, ver abajo).
# Antes se elegia el debrid con un ajuste 'newznab.debrid' (Auto/TorBox/
# Premiumize). Se elimina esa eleccion: la ruta de TorBox exige el plan de
# 10 $/mes (Usenet+NNTP viene tachado en los de 3 $ y 5 $), asi que para el
# indexer propio no aportaba nada que el usuario pudiera usar. Premiumize
# resuelve NZB con la suscripcion que ya se tiene.
NEWZNAB_DEBRID = 'Premiumize.me'
# v2.0.13: vuelve la eleccion, ahora que TorBox cerro su buscador y Newznab es
# la unica forma de usar el Usenet de TorBox Pro.
# v2.0.24: el enum newznab.debrid se sustituye por un INTERRUPTOR por
# servicio, y entra Easynews como reproductor propio de NZB (NNTP, sin debrid):
#   newznab.use_easynews    Easynews: streaming al momento desde tu cuenta
#   newznab.use_premiumize  Premiumize: lo baja a su nube y luego lo sirve
#   newznab.use_torbox      TorBox Pro: idem (el Usenet solo esta en Pro)
# Con varios activos se usa el primero disponible en ese orden y los demas
# quedan de respaldo: si el elegido falla al resolver, sourcesResolve prueba
# el siguiente. El ajuste viejo newznab.debrid ya no se lee.
NZB_RESOLVER_ORDER = ('Easynews', NEWZNAB_DEBRID, 'TorBox')

def _newznab_resolvers():
	"""([servicios que pueden reproducir NZB, en orden], motivo si no hay ninguno)."""
	out, why = [], []
	def _on(id_):
		return (getSetting(id_) or 'true') == 'true'
	if _on('newznab.use_easynews'):
		if getSetting('easynews.username') and getSetting('easynews.password'):
			out.append('Easynews')
		else: why.append('Easynews has no username/password')
	if _on('newznab.use_premiumize'):
		if _pm_available(): out.append(NEWZNAB_DEBRID)
		else: why.append('Premiumize is not enabled')
	if _on('newznab.use_torbox'):
		if not _tb_available(): why.append('TorBox is not enabled')
		else:
			from resources.lib.debrid.torbox import usenet_plan_ok
			if usenet_plan_ok(): out.append('TorBox')
			else: why.append('the TorBox plan has no Usenet (needs Pro)')
	if not out and not why:
		why.append('every NZB service switch is off')
	return out, '; '.join(why)

EASYNEWS_NEXT_NZBS = 4   # NZB de reserva tras el elegido (seleccion manual)
EASYNEWS_DEAD_STREAK = 3 # tantos NZB seguidos borrados (430) cortan los NZB de reserva
EASYNEWS_THEN_OTHERS = 10 # fuentes no Usenet que se prueban despues

USENET_CHAIN = 'usenet.chain'   # v2.0.37: grupo de avisos de la cadena de NZB

# v2.0.37: la reproduccion pedida en ultimo lugar manda. kodi.log del 20-nov-2026:
# una cadena de fuentes de The Hurt Locker siguio probando 25 enlaces de Easynews
# web durante 4 min en segundo plano y, con la pelicula ya en marcha desde otra
# busqueda, la sustituyo por un 1080p. Cada reproduccion deja su marca; una cadena
# que ve otra marca se para sin reproducir nada.
PLAY_TOKEN = 'luc_kodi.play_token'
EASYNEWS_TAIL_STREAK = 3   # enlaces de Easynews web seguidos sin el final del fichero: no se prueban mas


def _claim_play():
	from time import time as _t
	tok = '%.3f' % _t()
	try: homeWindow.setProperty(PLAY_TOKEN, tok)
	except Exception: pass
	return tok


def _superseded(tok):
	if not tok:
		return False
	try:
		return homeWindow.getProperty(PLAY_TOKEN) not in ('', tok)
	except Exception:
		return False


def _short_fail(why):
	"""v2.0.37: el motivo del NZB que no arranco, corto para un aviso."""
	w = str(why or 'did not play').replace(' (not streamable)', '').strip()
	if 'damaged post' in w: w = 'damaged post'
	elif '(430)' in w: w = 'removed from Easynews'
	return (w[:48] + '...') if len(w) > 51 else w


def _easynews_next_nzbs(chosen, rest):
	"""v2.0.32: los NZB que se prueban si el elegido no arranca con Easynews.
	Solo de Newznab por Easynews (nada que espere en un debrid), primero los
	ya comprobados en Easynews (su .nzb ya esta bajado: no gastan grab) y
	luego el orden de la lista; fuera los de indexers sin descargas hoy."""
	try:
		from resources.lib.modules import usenet_easynews as ue
	except Exception:
		return []
	played, ok, other = [], [], []
	pool, seen = [], set([chosen.get('hash') or chosen.get('url')])
	for it in rest or []:
		if not isinstance(it, dict) or it is chosen or it == chosen:
			continue
		k = it.get('hash') or it.get('url')
		if k in seen:
			continue   # la lista de vecinos da la vuelta y repite fuentes
		if it.get('debrid') == 'Easynews' and it.get('provider') == 'newznab' and not it.get('direct'):
			seen.add(k); pool.append(it)
	# v2.0.32: la salud sigue en segundo plano tras abrir la lista; lo que
	# haya sabido desde entonces cuenta (log del 12-nov-2026, Tenzing: cinco
	# NZB sin comprobar en la lista y los cinco borrados en Easynews)
	try: known = ue.known_status(pool)
	except Exception: known = {}
	for it in pool:
		st = known.get(it.get('hash') or '') or it.get('en_health')
		if st == 'dead' or it.get('en_unplayable'):
			continue
		if st == 'played':   # v2.0.33: ya se reprodujo bien; primero
			played.append(it); continue
		if st in ('ok', 'partial'):
			ok.append(it); continue
		try:
			if all(ue.grab_resting(h) for _u, h in ue.candidates(it)):
				continue
		except Exception:
			pass
		other.append(it)
	return (played + ok + other)[:EASYNEWS_NEXT_NZBS]

def _newznab_debrid():
	"""Compatibilidad: (primer servicio disponible, motivo)."""
	lst, why = _newznab_resolvers()
	return (lst[0], '') if lst else (None, why)

sourceFile = control.providercacheFile
single_expiry = timedelta(hours=6)
SCRAPE_LOCK = 'luc_kodi.scrape_busy'  # v1.0.90
ROLLOVER_PROP = 'luc_kodi.rollover'  # v1.0.91
season_expiry = timedelta(hours=48)
show_expiry = timedelta(hours=48)
video_extensions = supported_video_extensions()

def imdb_from_ids(mediatype, tmdb, tvdb):
	"""Id de IMDb a partir de TMDb (ids externos) y, en series, de TheTVDB."""
	found = ''
	if tmdb and str(tmdb) not in ('0', 'None'):
		try:
			if mediatype == 'episode':
				from resources.lib.indexers.tmdb import TVshows
				result = TVshows().get_external_ids(tmdb)
			else:
				from resources.lib.indexers.tmdb import Movies
				result = Movies().get_external_ids(tmdb, None)
			if isinstance(result, dict): found = result.get('imdb_id') or ''
		except Exception: log_utils.error()
	if not str(found).startswith('tt') and mediatype == 'episode':
		try:
			from resources.lib.modules import tvdb as tvdb_api
			found = tvdb_api.imdb_id(tvdb)
		except Exception: log_utils.error()
	# None (no '') cuando no aparece: cache.get no guarda None, asi que un
	# fallo de red no deja el titulo sin IMDb durante 30 dias.
	return found if str(found).startswith('tt') else None


def cache_imdb_lookup(mediatype, tmdb, tvdb):
	from resources.lib.database import cache
	return cache.get(imdb_from_ids, 720, mediatype, str(tmdb or ''), str(tvdb or '')) or ''


def _mmss(secs):
	"""66 -> '1:06'."""
	try:
		secs = int(secs or 0)
	except Exception:
		secs = 0
	return '%d:%02d' % divmod(secs, 60)


class Sources:
	def __init__(self, all_providers=False, custom_query=False, filterless_scrape=False):
		self.sources = []
		self.scraper_sources = deque() # []
		self.uncached_chosen = False
		self.isPrescrape = False
		self.lang_assist = '' # v2.0.08: idioma de Languages si el titulo esta registrado (langhelper)
		self.progressDialog = None
		self.all_providers = all_providers
		self.custom_query = custom_query
		self.filterless_scrape = filterless_scrape
		self.time = datetime.now()
		self.getConstants()
		self.enable_playnext = getSetting('enable.playnext') == 'true'
		self.dev_mode = getSetting('dev.mode.enable') == 'true'
		self.dev_disable_single = getSetting('dev.disable.single') == 'true'
		self.dev_disable_single_filter = getSetting('dev.disable.single.filter') == 'true'
		# v2.0.04: Debugging > Disable single scraper filter. Los scrapers comprueban
		# titulo, ano y episodio con source_utils.check_title(); con esto activo en
		# modo desarrollador lo da todo por bueno (como bypass_filter en los packs).
		# Se fija en cada busqueda, asi que apagarlo vale para la siguiente.
		try:
			from resources.lib.jacksparrow import source_utils as _js_source_utils
			_js_source_utils.BYPASS_SINGLE_FILTER = bool(self.dev_mode and self.dev_disable_single_filter and not self.dev_disable_single)
		except Exception: pass
		self.dev_disable_season_packs = getSetting('dev.disable.season.packs') == 'true'
		self.dev_disable_season_filter = getSetting('dev.disable.season.filter') == 'true'
		self.dev_disable_show_packs = getSetting('dev.disable.show.packs') == 'true'
		self.dev_disable_show_filter = getSetting('dev.disable.show.filter') == 'true'
		self.highlight_color = control.getColor(getSetting('scraper.dialog.color'))

	def play(self, title, year, imdb, tmdb, tvdb, season, episode, tvshowtitle, premiered, meta, select, rescrape=None):
		self._play_token = _claim_play()
		self._ep_check = {'tmdb': tmdb, 'title': title, 'season': season, 'episode': episode} # v2.0.37: control por titulo del episodio
		if not self.prem_providers:
			# Bypass the Debrid guard if a custom scraper that handles its own
			# Debrid resolution is active and properly configured.
			# AIOStreams: resolves Debrid on its side -> returns direct URLs.
			# MediaFusion: secret_str URL already encodes Debrid credentials.
			# Sootio:     config token already encodes Debrid credentials.
			# Torz:       config token (StremThru) already encodes Debrid creds.
			# Comet:      config token (Comet web UI) already encodes Debrid creds.
			# v1.0.91: con instancia propia basta la URL del manifest, que ya
			# lleva la configuracion; UUID y Password pueden quedar vacios.
			_aio_active = (getSetting('provider.aiostreams') == 'true'
			               and ((getSetting('aiostreams.uuid')
			                     and getSetting('aiostreams.password'))
			                    or (getSetting('aiostreams.url') == '6'
			                        and getSetting('aiostreams.custom_url'))))
			_mf_active  = (getSetting('provider.mediafusion') == 'true'
			               and getSetting('mediafusion.secret'))
			_sootio_active = (getSetting('provider.sootio') == 'true'
			                  and getSetting('sootio.config'))
			_meteor_active = (getSetting('provider.meteor') == 'true'
			                  and (getSetting('meteor.config_token') or getSetting('meteor.manifest_url')))
			_torz_active = (getSetting('provider.torz') == 'true'
			                and getSetting('torz.config'))
			_comet_active = (getSetting('provider.comet') == 'true'
			                 and getSetting('comet.config'))
			if not (_aio_active or _mf_active or _sootio_active or _meteor_active or _torz_active or _comet_active):
				control.sleep(200) ; control.hide()
				return control.notification(message=33034)
		try:
			control.sleep(200)
			if control.playlist.getposition() == 0 or control.playlist.size() == 1: playerWindow.clearProperty('luc_kodi.preResolved_nextUrl')
			preResolved_nextUrl = ''  # preResolved desactivado v0.0.92 — on-demand dialog
			if preResolved_nextUrl != '':
				control.sleep(500)
				playerWindow.clearProperty('luc_kodi.preResolved_nextUrl')
				try: meta = jsloads(unquote(meta.replace('%22', '\\"')))
				except: pass
				log_utils.log('Playing preResolved_nextUrl = %s' % preResolved_nextUrl, level=log_utils.LOGDEBUG)
				from resources.lib.modules import player
				return player.Player().play_source(title, year, season, episode, imdb, tmdb, tvdb, preResolved_nextUrl, meta)
			if title: title = self.getTitle(title)
			if tvshowtitle: tvshowtitle = self.getTitle(tvshowtitle)
			# Kodi 22 avisa al recibir None donde va un texto y su fuente anota que
			# dejara de aceptarlo tras la v22: en una pelicula season, episode y tvdb
			# llegan como None.
			homeWindow.clearProperty(self.metaProperty)
			homeWindow.setProperty(self.metaProperty, '' if meta is None else meta)
			homeWindow.clearProperty(self.seasonProperty)
			homeWindow.setProperty(self.seasonProperty, '' if season is None else season)
			homeWindow.clearProperty(self.episodeProperty)
			homeWindow.setProperty(self.episodeProperty, '' if episode is None else episode)
			homeWindow.clearProperty(self.titleProperty)
			homeWindow.setProperty(self.titleProperty, '' if title is None else title)
			homeWindow.clearProperty(self.imdbProperty)
			homeWindow.setProperty(self.imdbProperty, '' if imdb is None else imdb)
			homeWindow.clearProperty(self.tmdbProperty)
			homeWindow.setProperty(self.tmdbProperty, '' if tmdb is None else tmdb)
			homeWindow.clearProperty(self.tvdbProperty)
			homeWindow.setProperty(self.tvdbProperty, '' if tvdb is None else tvdb)
			if tvshowtitle is None: p_label = '[COLOR %s]%s (%s)[/COLOR]' % (self.highlight_color, title, year)
			else: p_label = '[COLOR %s]%s (S%02dE%02d)[/COLOR]' % (self.highlight_color, tvshowtitle, int(season), int(episode))
			homeWindow.clearProperty(self.labelProperty)
			homeWindow.setProperty(self.labelProperty, p_label)
			url = None
			self.mediatype = 'movie' if tvshowtitle is None else 'episode'
			try: meta = jsloads(unquote(meta.replace('%22', '\\"')))
			except: pass
			# --- AUTO-PLAYLIST para PlayNext ---
			# Construimos la playlist completa (E01, E02, ...) antes de empezar a reproducir.
			# Esto permite que Kodi avance la playlist nativamente al terminar cada episodio,
			# y que BigSkipForward (Play Now del popup) funcione correctamente.
			# FIX vs v0.0.43: resolvemos H1 con False inmediatamente para evitar el
			# salto a E02 a los 10 segundos que causaba el timeout del handle original.
			# AUTO-PLAYLIST desactivado v0.0.92 — reemplazado por diálogo post-stop on-demand.
			# Causaba: salto a E02 a los 2s + interceptaba 'Elegir Fuente' antes de sourceSelect.
			if False and self.mediatype == 'episode' and self.enable_playnext and int(control.playlist.size()) <= 1:
				try:
					from resources.lib.menus import episodes as episodes_menu
					items_ep = episodes_menu.Episodes().get(tvshowtitle, year, imdb, tmdb, tvdb, meta, season, episode, create_directory=False)
					def _to_int(x):
						try: return int(str(x))
						except: return None
					cur_s = _to_int(season)
					cur_e = _to_int(episode)
					start_idx = 0
					for idx, it in enumerate(items_ep):
						if _to_int(it.get('season')) == cur_s and _to_int(it.get('episode')) == cur_e:
							start_idx = idx
							break
					items_ep = items_ep[start_idx:]
					if items_ep and len(items_ep) > 1:
						control.playlist.clear()
						for it in items_ep:
							title_i = it.get('title') or ''
							year_i = it.get('year') or year
							imdb_i = it.get('imdb') or imdb
							tmdb_i = it.get('tmdb') or tmdb
							tvdb_i = it.get('tvdb') or tvdb
							season_i = it.get('season') or season
							episode_i = it.get('episode') or episode
							tvshowtitle_i = it.get('tvshowtitle') or tvshowtitle
							premiered_i = it.get('premiered') or ''
							systitle_i = quote_plus(title_i)
							systvshowtitle_i = quote_plus(tvshowtitle_i)
							sysmeta_i = quote_plus(jsdumps(it))
							ep_url = (
								'plugin://plugin.video.luc_kodi/?action=play_Item'
								'&title=%s&year=%s&imdb=%s&tmdb=%s&tvdb=%s'
								'&season=%s&episode=%s&tvshowtitle=%s&premiered=%s'
								'&meta=%s&select=1'
							) % (systitle_i, year_i, imdb_i, tmdb_i, tvdb_i, season_i, episode_i, systvshowtitle_i, premiered_i, sysmeta_i)
							li = control.item(label=title_i, offscreen=True)
							li.setProperty('IsPlayable', 'true')
							control.playlist.add(url=ep_url, listitem=li)
						control.player2().play(control.playlist._real())
						# FIX: cerrar H1 inmediatamente (False) para evitar timeout de 10s que causa salto a E02.
						# La playlist llama al plugin de nuevo para E01 con un handle H2 fresco.
						import xbmcplugin
						xbmcplugin.setResolvedUrl(int(argv[1]), False, control.item())
						return
				except:
					log_utils.error()
			# --- FIN AUTO-PLAYLIST ---
## - compare meta received to database and use largest(eventually switch to a request to fetch missing db meta for item)
			self.tmdb_key = getSetting('tmdb.api.key')
			if not self.tmdb_key: self.tmdb_key = app_keys.get('tmdb')
			# v2.0.04: sin IMDb de usuario. imdb.user nunca estuvo en los ajustes, asi que
			# esta clave de cache siempre era ''; se deja fija para no perder la cache.
			if self.mediatype == 'episode': self.user = ''
			else: self.user = str(self.tmdb_key)
			self.lang = control.apiLanguage()['tvdb']
			ids = {'imdb': imdb, 'tmdb': tmdb, 'tvdb': tvdb}
			meta1 = dict((k, v) for k, v in iter(meta.items()) if v is not None and v != '') if meta else None
			meta2 = metacache.fetch([{'imdb': imdb, 'tmdb': tmdb, 'tvdb': tvdb}], self.lang, self.user)[0]
			if meta2 != ids: meta2 = dict((k, v) for k, v in iter(meta2.items()) if v is not None and v != '')
			if meta1 is not None:
				try:
					if len(meta2) > len(meta1):
						meta2.update(meta1)
						meta = meta2
					else: meta = meta1
				except: log_utils.error()
			else: meta = meta2 if meta2 != ids else meta1
##################
			self.poster = meta.get('poster') if meta else ''
			self.fanart = meta.get('fanart') if meta else ''
			self.meta = meta

			def checkLibMeta(): # check Kodi db for meta for library playback.
				def cleanLibArt(art):
					if not art: return ''
					art = unquote(art.replace('image://', ''))
					if art.endswith('/'): art = art[:-1]
					return art
				try:
					if self.mediatype != 'movie': raise Exception()
					# do not add IMDBNUMBER as tmdb scraper puts their id in the key value
					meta = control.jsonrpc('{"jsonrpc": "2.0", "method": "VideoLibrary.GetMovies", "params": {"filter":{"or": [{"field": "year", "operator": "is", "value": "%s"}, {"field": "year", "operator": "is", "value": "%s"}, {"field": "year", "operator": "is", "value": "%s"}]}, "properties" : ["title", "originaltitle", "uniqueid", "year", "premiered", "genre", "studio", "country", "runtime", "rating", "votes", "mpaa", "director", "writer", "cast", "plot", "plotoutline", "tagline", "thumbnail", "art", "file"]}, "id": 1}' % (year, str(int(year) + 1), str(int(year) - 1)))
					meta = jsloads(meta)['result']['movies']
					meta = [i for i in meta if i.get('uniqueid', []).get('imdb', '') == imdb]
					if meta: meta = meta[0]
					else: raise Exception()
					if 'mediatype' not in meta: meta.update({'mediatype': 'movie'})
					if 'duration' not in meta: meta.update({'duration': meta.get('runtime')}) # Trakt scrobble resume needs this for lib playback
					if 'castandrole' not in meta: meta.update({'castandrole': [(i['name'], i['role']) for i in meta.get('cast')]})
					poster = cleanLibArt(meta.get('art').get('poster', '')) or self.poster
					fanart = cleanLibArt(meta.get('art').get('fanart', '')) or self.fanart
					clearart = cleanLibArt(meta.get('art').get('clearart', ''))
					clearlogo = cleanLibArt(meta.get('art').get('clearlogo', ''))
					discart = cleanLibArt(meta.get('art').get('discart'))
					meta.update({'imdb': imdb, 'tmdb': tmdb, 'tvdb': tvdb, 'poster': poster, 'fanart': fanart, 'clearart': clearart, 'clearlogo': clearlogo, 'discart': discart})
					return meta
				except:
					log_utils.error()
					meta = ''
				try:
					if self.mediatype != 'episode': raise Exception()
					# do not add IMDBNUMBER as tmdb scraper puts their id in the key value
					show_meta = control.jsonrpc('{"jsonrpc": "2.0", "method": "VideoLibrary.GetTVShows", "params": {"filter":{"or": [{"field": "year", "operator": "is", "value": "%s"}, {"field": "year", "operator": "is", "value": "%s"}, {"field": "year", "operator": "is", "value": "%s"}]}, "properties" : ["title", "originaltitle", "uniqueid", "mpaa", "year", "genre", "runtime", "thumbnail", "file"]}, "id": 1}' % (year, str(int(year)+1), str(int(year)-1)))
					show_meta = jsloads(show_meta)['result']['tvshows']
					show_meta = [i for i in show_meta if i.get('uniqueid', []).get('imdb', '') == imdb]
					if show_meta: show_meta = show_meta[0]
					else: raise Exception()
					tvshowid = show_meta['tvshowid']
					meta = control.jsonrpc('{"jsonrpc": "2.0", "method": "VideoLibrary.GetEpisodes", "params":{"tvshowid": %d, "filter":{"and": [{"field": "season", "operator": "is", "value": "%s"}, {"field": "episode", "operator": "is", "value": "%s"}]}, "properties": ["title", "season", "episode", "showtitle", "firstaired", "runtime", "rating", "director", "writer", "cast", "plot", "thumbnail", "art", "file"]}, "id": 1}' % (tvshowid, season, episode))
					meta = jsloads(meta)['result']['episodes']
					if meta: meta = meta[0]
					else: raise Exception()
					if 'mediatype' not in meta: meta.update({'mediatype': 'episode'})
					if 'tvshowtitle' not in meta: meta.update({'tvshowtitle': meta.get('showtitle')})
					if 'castandrole' not in meta: meta.update({'castandrole': [(i['name'], i['role']) for i in meta.get('cast')]})
					if 'genre' not in meta: meta.update({'genre': show_meta.get('genre')})
					if 'duration' not in meta: meta.update({'duration': meta.get('runtime')}) # Trakt scrobble resume needs this for lib playback but Kodi lib returns "0" for shows or episodes
					if 'mpaa' not in meta: meta.update({'mpaa': show_meta.get('mpaa')})
					if 'premiered' not in meta: meta.update({'premiered': meta.get('firstaired')})
					if 'year' not in meta: meta.update({'year': show_meta.get('year')}) # shows year not year episode aired
					poster = cleanLibArt(meta.get('art').get('season.poster', '')) or self.poster
					fanart = cleanLibArt(meta.get('art').get('tvshow.fanart', '')) or self.poster
					clearart = cleanLibArt(meta.get('art').get('tvshow.clearart', ''))
					clearlogo = cleanLibArt(meta.get('art').get('tvshow.clearlogo', ''))
					discart = cleanLibArt(meta.get('art').get('discart'))
					meta.update({'imdb': imdb, 'tmdb': tmdb, 'tvdb': tvdb, 'poster': poster, 'fanart': fanart, 'clearart': clearart, 'clearlogo': clearlogo, 'discart': discart})
					return meta
				except:
					log_utils.error()
					meta = ''
			if self.meta is None or 'videodb' in control.infoLabel('ListItem.FolderPath'):
				self.meta = checkLibMeta()
			def sourcesDirMeta(metadata): # pass skin minimal meta needed
				if not metadata: return metadata
				if getSetting('fanart') == 'false': metadata['fanart'] = ''
				if getSetting('prefer.tmdbArt') == 'true':
					try:
						from resources.lib.indexers.tmdb import logo_url as _logo_url  # v2.0.21: w1280 fijo
						_tl = _logo_url(metadata.get('tmdblogo'))
					except Exception: _tl = metadata.get('tmdblogo')
					metadata['clearlogo'] = _tl or metadata.get('clearlogo') or ''
				allowed = ['mediatype', 'imdb', 'tmdb', 'tvdb', 'poster', 'tvshow.poster', 'season_poster', 'season_poster', 'fanart', 'clearart', 'clearlogo', 'discart', 'thumb', 'title', 'tvshowtitle', 'year', 'premiered', 'rating', 'plot', 'duration', 'mpaa', 'season', 'episode', 'castandrole',
						   # v2.0.37 (auditoria del 19-nov-2026): calc_pack_size() y la numeracion de
						   # TheTVDB los leen de aqui; sin ellos se iban a la cache de metadatos o a
						   # TMDb en mitad del filtrado (3,4 s en el log de Seinfeld S03E08)
						   'seasoncount', 'counts']
				return {k: v for k, v in iter(metadata.items()) if k in allowed}
			self.meta = sourcesDirMeta(self.meta)
			imdb = self._ensure_imdb(imdb, tmdb, tvdb)
			if self.mediatype == 'movie':
				if getSetting('imdb.Moviemeta.check') == 'true': # check IMDB. TMDB and Trakt differ on a ratio of 1 in 20 and year is off by 1, some meta titles mismatch
					title, year = self.imdb_meta_chk(imdb, title, year)
				if title == 'The F**k-It List': title = 'The Fuck-It List'
			if self.mediatype == 'episode':
				if getSetting('imdb.Showmeta.check') == 'true':
					tvshowtitle, year = self.imdb_meta_chk(imdb, tvshowtitle, year)
				if tvshowtitle == 'The End of the F***ing World': tvshowtitle = 'The End of the Fucking World'
				self.total_seasons, self.season_isAiring = self.get_season_info(imdb, tmdb, tvdb, meta, season)
			self._rescrape = bool(rescrape)
			if rescrape: self.clr_item_providers(title, year, imdb, tmdb, tvdb, season, episode, tvshowtitle, premiered)
			# v2.0.08: un titulo que llego por Languages se busca tambien con langhelper.
			# Su resultado se guarda con otra clave (getSourcesLang, sufijo |la en la RAM)
			# para no recibir una lista vieja buscada sin el ayudante desde otro menu.
			self.lang_assist = lang_assist.lookup(tmdb, self.mediatype)
			# v2.0.16: also when the sources come from the cache and no search runs,
			# so a file named by air date inside a pack is still found on resolve.
			if season and episode and premiered: self._register_air_date({'season': season, 'episode': episode, 'premiered': premiered})
			cache_id = self._build_ramcache_id(imdb, tmdb, tvdb, season, episode, year)
			if self.lang_assist and cache_id: cache_id += '|la'
			items = None
			if not rescrape and not self.custom_query and getSetting('sources.ramcache') == 'true':
				items = self._ramcache_get(cache_id)
			if not items:
				# v1.0.90: candado anti doble scrape. Una segunda pulsacion sobre el
				# MISMO titulo mientras la primera busqueda sigue en marcha lanzaba
				# otra busqueda completa en paralelo. Titulos distintos no se
				# bloquean, y el candado caduca solo a los 120 s por si algo muere.
				_lock_val = homeWindow.getProperty(SCRAPE_LOCK)
				try:
					_lock_id, _lock_ts = _lock_val.rsplit('|', 1)
					_lock_busy = (_lock_id == cache_id and (time() - float(_lock_ts)) < 120)
				except Exception:
					_lock_busy = False
				if _lock_busy:
					control.hide()
					log_utils.log('[ luc_kodi ] scrape lock: search already running for %s' % cache_id, level=log_utils.LOGINFO)
					control.notification(message=400840)
					self.url = None
					return control.cancelPlayback()
				homeWindow.setProperty(SCRAPE_LOCK, '%s|%s' % (cache_id, time()))
				# v2.0.26: la busqueda inteligente necesita saber si se va a reproducir
				# sola (basta con pocas fuentes buenas) o se abre la lista (se piden mas).
				# Misma regla que decide `select` mas abajo; '2' (asistente) cuenta como lista.
				_sel = select if select is not None else ('1' if (episode is not None and self.enable_playnext) else getSetting('play.mode'))
				self._autoplay_hint = (_sel == '1')
				try:
					items = providerscache.get(self.getSourcesLang if self.lang_assist else self.getSources, 48, title, year, imdb, tmdb, tvdb, season, episode, tvshowtitle, premiered)
				finally:
					homeWindow.clearProperty(SCRAPE_LOCK)
				if items and not rescrape and not self.custom_query and getSetting('sources.ramcache') == 'true' and not getattr(self, '_smart_partial', False):
					self._ramcache_set(cache_id, items)
			if not items:
				self.url = url
				return self.errorForSources()
			self._badge_found(tmdb, items) # v2.0.35: posters with badges — lo mejor encontrado
			filter = [] ; uncached_items = []
			if getSetting('torrent.remove.uncached') == 'true':
				uncached_items += [i for i in items if re.match(r'^uncached.*torrent', i['source'])]
				filter += [i for i in items if i not in uncached_items]
				if filter: pass
				elif not filter:
					homeWindow.clearProperty('luc_kodi.source_progress_is_alive')
					if control.yesnoDialog('No cached torrents returned. Would you like to view the uncached torrents to cache yourself?', '', ''):
						control.cancelPlayback()
						select = '0'
						self.uncached_chosen = True
						filter += uncached_items
				items = filter
				if not items:
					self.url = url
					return self.errorForSources()
			else: uncached_items += [i for i in items if re.match(r'^uncached.*torrent', i['source'])]
			if select is None:
				if episode is not None and self.enable_playnext: select = '1'
				else: select = getSetting('play.mode')
			title = tvshowtitle if tvshowtitle is not None else title
			self.imdb = imdb ; self.tmdb = tmdb ; self.tvdb = tvdb ; self.title = title ; self.year = year
			self.season = season ; self.episode = episode
			self.ids = {'imdb': self.imdb, 'tmdb': self.tmdb, 'tvdb': self.tvdb}
			if len(items) > 0:
				if select == '2':
					# v2.0.14: busqueda del asistente -> resumen y eleccion de resolucion;
					# la eleccion arranca el autoplay con las fuentes de esa resolucion
					choice = self.assistantChoice(title, items)
					if choice == 'all':
						control.sleep(200)
						return self.sourceSelect(title, items, uncached_items, self.meta)
					if choice is None:
						homeWindow.clearProperty('luc_kodi.source_progress_is_alive')
						return control.cancelPlayback()
					from resources.lib.modules import assistant_search
					url = self.sourcesAutoPlay(assistant_search.filter_quality(items, choice) or items, keep_quality=True)
				elif select == '0':
					control.sleep(200)
					return self.sourceSelect(title, items, uncached_items, self.meta)
				else: url = self.sourcesAutoPlay(items)
			if url == 'close://' or url is None:
				self.url = url
				return self.errorForSources()
			from resources.lib.modules import player
			_player_inst = player.Player()
			_player_inst.play_source(title, year, season, episode, imdb, tmdb, tvdb, url, self.meta)
			# FALLBACK_SETRESOLVEDURL: solo si el player NUNCA arrancó (current_time < 5s)
			# Y no estamos en modo next_ep_direct (el ep siguiente ya está buscando).
			try:
				from sys import argv as _argv
				from resources.lib.modules import control as _control
				_control.sleep(800)
				# Si next_ep_direct está activo significa que ya lanzamos el ep siguiente:
				# no volver a invocar el plugin o se abrirá una segunda búsqueda.
				_next_ep_active = homeWindow.getProperty('luc_kodi.next_ep_direct') == 'true'
				_never_played = getattr(_player_inst, 'current_time', 0) < 5
				if _never_played and not _next_ep_active and not _control.condVisibility('Player.HasVideo') and url and url.startswith(('http','https')):
					item = _control.item(path=url)
					_control.resolve(int(_argv[1]), True, item)
			except Exception:
				log_utils.error() # v2.0.23: antes se tragaba sin dejar rastro en el log
		except:
			log_utils.error()
			control.cancelPlayback()

	def assistantChoice(self, title, items):
		"""v2.0.14: '4K' / '1080p' / '720p' / 'SD' / 'best' / 'all', or None."""
		try:
			control.hide()
			from resources.lib.modules import assistant_search
			return assistant_search.guided_choice(items, self.meta, title, self.year)
		except Exception:
			log_utils.error('Error assistantChoice(): ')
			return 'all'   # the classic list never leaves the user without sources

	def sourceSelect(self, title, items, uncached_items, meta):
		try:
			control.hide()
			control.playlist.clear()
			if not items:
				control.sleep(200) ; control.hide() ; sysexit()
			if not self.meta: self.meta = meta
		except: log_utils.error('Error sourceSelect(): ')

		try:
			if getSetting('uncached.seeder.sort') == 'true':
				uncached_items = sorted(uncached_items, key=lambda k: k['seeders'], reverse=True)
				uncached_items = self.sort_byQuality(source_list=uncached_items)
			# Attach smart score for Source Select display
			try:
				for _it in (items or []):
					try: _it['score'] = self._smart_score(_it)
					except: pass
				for _it in (uncached_items or []):
					try: _it['score'] = self._smart_score(_it)
					except: pass
			except:
				pass

			if items == uncached_items:
				from resources.lib.windows.uncached_results import UncachedResultsXML
				window = UncachedResultsXML('uncached_results.xml', control.addonPath(control.addonId()), uncached=uncached_items, meta=self.meta)
			else:
				from resources.lib.windows.source_results import SourceResultsXML
				window = SourceResultsXML('source_results.xml', control.addonPath(control.addonId()), results=items, uncached=uncached_items, meta=self.meta)
			action, chosen_source = window.run()
			del window
			if action == 'play_Item' and self.uncached_chosen != True:
				return self.playItem(title, items, chosen_source.getProperty('luc_kodi.source_dict'), self.meta)
			else:
				try: self.progressDialog.close()
				except: pass
				control.cancelPlayback()
		except:
			log_utils.error('Error sourceSelect(): ')
			control.cancelPlayback()

	def playItem(self, title, items, chosen_source, meta):
		self._play_token = _claim_play()
		try:
			try: items = jsloads(items)
			except: pass
			try: meta = jsloads(meta)
			except: pass
			try:
				# Robust JSON parsing for items/chosen_source
				try:
					chosen_source = jsloads(chosen_source)
				except:
					chosen_source = chosen_source if isinstance(chosen_source, list) else [chosen_source]
				if isinstance(items, str):
					try: items = jsloads(items)
					except: items = []
				if not isinstance(items, list):
					items = [items] if items else []
				try:
					source_index = items.index(chosen_source[0]) if items and chosen_source else 0
				except:
					source_index = 0
				source_len = len(items)
				next_end = min(source_len, source_index+41)
				sources_next = items[source_index+1:next_end]
				sources_prev = [] if next_end < source_len else items[0:41-(source_len-source_index)]
				resolve_items = [i for i in ( (chosen_source or []) + sources_next + sources_prev )] or items
			except:
				log_utils.error()
				resolve_items = items if isinstance(items, list) else [items] if items else []

			# -- Usenet (NZB) guard ----------------------------------------
			# NZB resolution on debrid (TorBox/Premiumize) is SLOW (a full
			# server-side Usenet download) and each call starts a persistent
			# transfer. The neighbour pre-cache above would spawn one download
			# per source and blow the debrid's active-transfer cap. For a
			# usenet pick, resolve ONLY the chosen source -- never neighbours.
			# Easynews is excluded: its items carry direct=True (the URL is
			# already the file), so they are cheap and need no restriction.
			_nzb_next, _nzb_ids, _other_ids, _dead_streak = 0, set(), set(), 0
			try:
				_chosen0 = chosen_source[0] if (isinstance(chosen_source, list) and chosen_source) else chosen_source
				if isinstance(_chosen0, dict) and 'usenet' in (_chosen0.get('source', '') or '') and not _chosen0.get('direct'):
					resolve_items = [_chosen0]
					# v2.0.32: con Easynews (sin transferencias en ningun debrid)
					# un NZB que falla pasa solo al siguiente de la lista, y el
					# usuario no tiene que volver a buscar (log del 11-nov-2026:
					# Forrest Gump y Fight Club se quedaban en un aviso).
					if _chosen0.get('debrid') == 'Easynews':
						_nexts = _easynews_next_nzbs(_chosen0, sources_next + sources_prev)
						# y si ningun NZB arranca, lo siguiente de la lista que no es
						# Usenet (torrents ya en el debrid): log del 12-nov-2026, The
						# Instigators y Mayday, todos sus NZB recientes borrados en
						# Easynews y el usuario sin nada que ver
						_seen = set([id(_chosen0)] + [id(x) for x in _nexts])
						_others = []
						for x in sources_next + sources_prev:
							if len(_others) >= EASYNEWS_THEN_OTHERS: break
							if not isinstance(x, dict) or id(x) in _seen or x == _chosen0: continue
							if 'usenet' in (x.get('source') or '') and not x.get('direct'): continue
							if str(x.get('source') or '').startswith('uncached'): continue
							_seen.add(id(x)); _others.append(x)
						resolve_items += _nexts + _others
						_nzb_next = len(_nexts) + len(_others)
						_nzb_ids = set(id(x) for x in _nexts)
						_other_ids = set(id(x) for x in _others)
			except Exception:
				pass

			self._nzb_chain = bool(_nzb_next)   # v2.0.37: sourcesResolve leaves the notices to this loop
			header = homeWindow.getProperty(self.labelProperty) + ': Resolving...'
			try:
				if getSetting('progress.dialog') == '0':
					if not self.progressDialog:
						self.progressDialog = self.getSourceProgress(header, meta)
				else: raise Exception()
			except:
				homeWindow.clearProperty('luc_kodi.source_progress_is_alive')
				self.progressDialog = control.progressDialogBG
				self.progressDialog.create(header, '')
			_en_tail_fails = 0
			for i in range(len(resolve_items)):
				try:
					if _superseded(getattr(self, '_play_token', None)):
						log_utils.log('[ luc_kodi ] a newer playback was started: this source chain stops here', level=log_utils.LOGINFO)
						try: self.progressDialog.close()
						except Exception: pass
						return
					try:
						if self.progressDialog != control.progressDialogBG and self.progressDialog.iscanceled() and i:
							log_utils.log('[ luc_kodi ] source chain cancelled from its window', level=log_utils.LOGINFO)
							control.notification(message=32398)
							return
					except Exception: pass
					resolve_index = items.index(resolve_items[i])+1
					src_provider = resolve_items[i]['debrid'] if resolve_items[i].get('debrid') else ('%s - %s' % (resolve_items[i]['source'], resolve_items[i]['provider']))
					label = '[B][COLOR %s]%s[CR]%s[CR]%02d.  %s[/COLOR][/B]' % (self.highlight_color, src_provider.upper(), resolve_items[i]['info'][:40], resolve_index, resolve_items[i]['name'][:40]) # using "[CR]" has some weird delay with progressDialog.update() at times
					control.sleep(100)
					try:
						if self.progressDialog == control.progressDialogBG and self.progressDialog.iscanceled(): break
						self.progressDialog.update(int((100 / float(len(resolve_items))) * i), label)
					except: self.progressDialog.update(int((100 / float(len(resolve_items))) * i), '[B][COLOR %s]Resolving...[/COLOR]%s[/B]' % (self.highlight_color, resolve_items[i]['name']))
					if i and _nzb_next:
						_cur = resolve_items[i]
						if id(_cur) in _nzb_ids:
							# 3 NZB seguidos borrados en Easynews (430): es una retirada
							# por DMCA del titulo entero; no se gastan mas grabs en el
							if _dead_streak >= EASYNEWS_DEAD_STREAK:
								continue
							_pos = 1 + sum(1 for x in resolve_items[:i + 1] if id(x) in _nzb_ids)
							# v2.0.37: one notice per step, with why the last one failed;
							# the newest replaces the one on screen (kodi.log 17-nov-2026)
							control.notification(message='Usenet: %s. Trying release %d of %d'
												 % (_short_fail(getattr(self, 'usenet_fail_reason', None)), _pos, 1 + len(_nzb_ids)),
												 group=USENET_CHAIN)
							log_utils.log('USENET: the chosen NZB did not play; trying the next one: %s' % _cur.get('name'),
										  level=log_utils.LOGINFO)
						elif id(_cur) in _other_ids and not any(id(x) in _other_ids for x in resolve_items[:i]):
							control.notification(message='Usenet: no NZB played, trying the next sources', group=USENET_CHAIN)
							log_utils.log('USENET: no NZB played%s; trying the next sources in the list'
										  % (' (removed from Easynews)' if _dead_streak >= EASYNEWS_DEAD_STREAK else ''),
										  level=log_utils.LOGINFO)
					w = Thread(target=self.sourcesResolve, args=(resolve_items[i],), daemon=True)
					w.start()
					# Usenet (NZB) resolves take minutes (server-side download);
					# wait for it to finish instead of moving on after ~15s and
					# spawning another persistent transfer. Easynews (direct)
					# keeps the normal cap.
					_it_i = resolve_items[i]
					_wait_cap = 100000 if ('usenet' in (_it_i.get('source', '') or '') and not _it_i.get('direct')) else 50
					for x in range(_wait_cap):
						try:
							if control.monitor.abortRequested(): return sysexit()
							if self.progressDialog == control.progressDialogBG and self.progressDialog.iscanceled():
								control.notification(message=32398)
								control.cancelPlayback()
								self.progressDialog.close()
								del self.progressDialog
								return
						except: pass
						if not w.is_alive(): break
						control.sleep(300)
					if _nzb_next and (i == 0 or id(resolve_items[i]) in _nzb_ids):
						if not self.url and '(430)' in str(getattr(self, 'usenet_fail_reason', '') or ''):
							_dead_streak += 1
						elif self.url or getattr(self, 'usenet_fail_reason', None):
							_dead_streak = 0
					if not self.url: continue
					# Optional URL validity check (skip dead links / HTML error pages)
					try:
						if getSetting('validate.source.urls') == 'true':
							from resources.lib.modules import urlcheck
							if not urlcheck.check_url_validity(self.url):
								log_utils.log('Rejected invalid URL (playItem): %s' % fs_client.scrub_url(self.url), level=log_utils.LOGWARNING)
								self.url = None
								continue
					except Exception:
						pass

					item = resolve_items[i]
					is_aiostreams_direct = item.get('aiostreams_direct') or (item.get('provider') == 'aiostreams' and item.get('direct') is True)
					if (not any(x in self.url.lower() for x in video_extensions) and '/dld/' not in self.url) and not is_aiostreams_direct:
						log_utils.log('Playback not supported for (playItem()): %s' % fs_client.scrub_url(self.url), level=log_utils.LOGWARNING)
						continue

					# ── Pre-flight del enlace resuelto (v1.0.65) ──────────────
					# En selección MANUAL la política es distinta a la del
					# autoplay: un enlace muerto se descarta igual, pero uno
					# lento se avisa y se reproduce. El usuario ha elegido esa
					# fuente a propósito y no nos corresponde vetarla.
					_pf_head, _pf_bytes = None, 0
					try:
						from resources.lib.modules import preflight
						if preflight.enabled():
							_pf = preflight.evaluate(self.url, item, self.meta)
							_pf_head = _pf.pop('head', None)
							_pf_bytes = _pf.get('file_bytes') or 0
							preflight.log(_pf)
							if _pf.get('vc1'):
								control.notification(message=control.lang(40561), time=8000)
							if _pf.get('verdict') == 'dead':
								if _pf.get('reason') == 'sample':
									control.notification(message=control.lang(40559) % _mmss(_pf.get('file_secs')), time=5000)
								try:
									from resources.lib.database import source_ranker
									source_ranker.record_failure(item, resolved_url=self.url,
										reason=_pf.get('reason') or 'dead')
								except Exception:
									pass
								self.url = None
								continue
							if _pf.get('verdict') == 'slow':
								_need = int(_pf.get('required_mbps') or 0)
								_got  = int(_pf.get('measured_mbps') or 0)
								# v1.0.71: en seleccion MANUAL se pregunta antes de
								# arrancar cuando el deficit es serio. El usuario
								# sigue mandando —nunca se veta su eleccion— pero
								# ahora se entera A TIEMPO, no con el video ya
								# congelado. Un deficit leve se queda en aviso.
								if preflight.should_ask(_pf):
									_play_anyway = control.yesnoDialog(
										control.lang(400754) % (_need, _got),
										control.lang(400755), '',
										nolabel=control.lang(400756),
										yeslabel=control.lang(400757))
									if not _play_anyway:
										try:
											from resources.lib.database import source_ranker
											source_ranker.record_failure(item, resolved_url=self.url,
												reason='slow_declined')
										except Exception:
											pass
										self.url = None
										continue
								elif preflight.manual_action() == 0:
									try:
										control.notification(
											message=control.lang(400747) % (_need, _got),
											icon='WARNING', time=5000)
									except Exception:
										pass
							# v2.0.27: Easynews web search, el final del fichero
							# (ver preflight.easynews_tail).
							if preflight.is_easynews_web(self.url):
								if _en_tail_fails >= EASYNEWS_TAIL_STREAK:
									self.url = None   # Easynews web no contesta ahora: no se prueban mas
									continue
								_tail_ok, _tail_s = preflight.easynews_tail(self.url, _pf_bytes)
								if _tail_ok:
									_en_tail_fails = 0
								else:
									_en_tail_fails += 1
									if _en_tail_fails == EASYNEWS_TAIL_STREAK:
										log_utils.log('[ luc_kodi ] Easynews web: %d links in a row without the end of the file; the rest are skipped'
													  % _en_tail_fails, level=log_utils.LOGINFO)
								if not _tail_ok:
									try:
										from resources.lib.database import source_ranker
										source_ranker.record_failure(item, resolved_url=self.url, reason='easynews_tail')
									except Exception:
										pass
									try: control.notification(message=control.lang(40555), icon='WARNING', time=6000)
									except Exception: pass
									self.url = None
									continue
							try:
								from resources.lib.database import source_ranker
								source_ranker.record_host(self.url, ok=True)
							except Exception:
								pass
					except Exception:
						pass

					# ── Sonda de audio (v1.0.89) ──────────────────────────
					# Lee las pistas reales de la cabecera del fichero. Con
					# el pre-flight encendido reutiliza su descarga y no
					# hace ninguna peticion; nunca descarta la fuente.
					try:
						from resources.lib.modules import audio_probe
						if audio_probe.enabled():
							audio_probe.announce(audio_probe.after_resolve(self.url, item, self.meta, head=_pf_head,
								file_bytes=_pf_bytes))
					except Exception:
						pass
					_pf_head = None

					if _superseded(getattr(self, '_play_token', None)):
						log_utils.log('[ luc_kodi ] a newer playback was started: this source is not played', level=log_utils.LOGINFO)
						return
					log_utils.log('Playing url from playItem(): %s' % fs_client.scrub_url(self.url), level=log_utils.LOGDEBUG)
					# v2.0.37: what the NZB chain still had to say is old news now
					if _nzb_next: control.notification_drop(USENET_CHAIN)
					if homeWindow.getProperty('luc_kodi.source_progress_is_alive') != 'true':
						try: self.progressDialog.close()
						except: pass
						del self.progressDialog
					# v1.0.21 SCROBBLE FIX: route manual source selection through
					# player.Player().play_source() instead of doing setResolvedUrl
					# directly. Otherwise no Player instance is created, keepAlive
					# never runs, and onAVStarted/onPlayBackStopped callbacks fire
					# on a dead instance — breaking Trakt/SIMKL scrobble + subtitles.
					# play_source handles the next-ep direct case internally (it
					# uses control.player.play vs control.resolve based on the
					# luc_kodi.next_ep_direct window property).
					# This is exactly what Umbrella does in its playItem (line 511).
					try:
						from resources.lib.modules import binge
						binge.remember(item, getattr(self, 'imdb', ''), getattr(self, 'tmdb', ''),
									   getattr(self, 'season', None), getattr(self, 'episode', None))
					except Exception:
						pass
					from resources.lib.modules import player as _player_mod
					_player_mod.Player().play_source(
						getattr(self, 'title', title) or title,
						getattr(self, 'year', None),
						getattr(self, 'season', None),
						getattr(self, 'episode', None),
						getattr(self, 'imdb', '') or '',
						getattr(self, 'tmdb', '') or '',
						getattr(self, 'tvdb', '') or '',
						self.url,
						self.meta if isinstance(self.meta, dict) else (meta if isinstance(meta, dict) else {})
					)
					return self.url
				except: log_utils.error()
			self._nzb_chain = False
			try: self.progressDialog.close()
			except: pass
			del self.progressDialog
			self.errorForSources()
		except: log_utils.error('Error playItem: ')

	def _ensure_imdb(self, imdb, tmdb, tvdb):
		"""v1.0.94 — sin id de IMDb, los proveedores tipo Stremio (AIOStreams,
		Torrentio, Comet, Torz, MediaFusion, Peerflix...) no pueden buscar:
		preguntaban por 'None:1:1'. Visto en kodi.log del 25-sep con
		"¿A que estas esperando?" (Atresplayer): TMDb la tiene sin IMDb. Se
		busca en los ids externos de TMDb y, para series, en los de TheTVDB."""
		if imdb and str(imdb).startswith('tt'): return imdb
		found = ''
		try: found = cache_imdb_lookup(self.mediatype, tmdb, tvdb)
		except Exception: log_utils.error()
		log_utils.log('[ luc_kodi ] IMDb id missing (tmdb=%s, tvdb=%s): %s' % (tmdb, tvdb,
		              'found %s' % found if found else 'not found, providers that search by IMDb id will skip it'),
		              level=log_utils.LOGINFO)
		if not found: return imdb
		try:
			if isinstance(self.meta, dict): self.meta['imdb'] = found
		except Exception: pass
		return found

	def getSources(self, title, year, imdb, tmdb, tvdb, season, episode, tvshowtitle, premiered, meta=None, preScrape=False):
		if preScrape:
			self.isPrescrape = True
			if tvshowtitle is not None:
				self.mediatype = 'episode'
				self.meta = meta
				self.total_seasons, self.season_isAiring = self.get_season_info(imdb, tmdb, tvdb, meta, season)
			return self.getSources_silent(title, year, imdb, tvdb, season, episode, tvshowtitle, premiered)
		else:
			return self.getSources_dialog(title, year, imdb, tvdb, season, episode, tvshowtitle, premiered)

	def getSourcesLang(self, title, year, imdb, tmdb, tvdb, season, episode, tvshowtitle, premiered, meta=None, preScrape=False):
		"""v2.0.08: lo mismo que getSources. Existe solo para que providerscache
		guarde con otra clave (la clave lleva el nombre de la funcion) lo buscado
		con el ayudante langhelper."""
		return self.getSources(title, year, imdb, tmdb, tvdb, season, episode, tvshowtitle, premiered, meta, preScrape)

	def scrape_fn(self, tmdb, mediatype):
		"""v2.0.08: la funcion de busqueda que toca para providerscache. La usa
		el prescrape del siguiente episodio en player.py."""
		self.lang_assist = lang_assist.lookup(tmdb, mediatype)
		return self.getSourcesLang if self.lang_assist else self.getSources

	def _lang_assist_payload(self, content):
		"""v2.0.08: lo que recibe langhelper en data['lang_assist'], o None si el
		titulo no llego por Languages. Sin payload el scraper ni se lanza."""
		try:
			meta = self.meta if isinstance(getattr(self, 'meta', None), dict) else {}
			tmdb = meta.get('tmdb') or getattr(self, 'tmdb', '') or ''
			lang = self.lang_assist or lang_assist.lookup(tmdb, content)
			if not lang or not tmdb: return None
			return {'lang': lang, 'tmdb': str(tmdb), 'media': 'movie' if content == 'movie' else 'tv'}
		except Exception:
			log_utils.error()
			return None

	def _lang_assist_report(self):
		"""v2.0.08: una linea en kodi.log por busqueda con langhelper: cuantas
		encontro, cuantas siguen en la lista tras la comprobacion de cache del
		debrid, y cuantas de esas no las trajo ningun otro proveedor."""
		try:
			found = [i for i in self.scraper_sources if i.get('provider') == 'langhelper']
			if not found: return
			others = set((i.get('hash') or '').lower() for i in self.scraper_sources if i.get('provider') != 'langhelper' and i.get('hash'))
			# v2.0.08: por hash. Con dos debrid la misma fuente sale una vez por cada uno,
			# y la linea decia cosas como "1 found, 2 cached"
			listed = set((i.get('hash') or '').lower() for i in self.sources if i.get('provider') == 'langhelper' and 'uncached' not in (i.get('source') or ''))
			only = [h for h in listed if h not in others]
			found = set((i.get('hash') or '').lower() for i in found)
			log_utils.log('[ luc_kodi ] langhelper: %d found, %d cached in the list, %d of them found by no other provider'
				% (len(found), len(listed), len(only)), level=log_utils.LOGINFO)
		except Exception:
			log_utils.error()

	def _air_date_info(self, imdb, tvdb, season, episode, premiered, title=''):
		"""v2.0.16: TVmaze says whether the show is a daily or talk show (its
		releases are named by air date, so the scrapers also search the date)
		and fills a missing air date. {} when there is nothing to add."""
		try:
			from resources.lib.modules import tvmaze
			return tvmaze.air_info(imdb, tvdb, season, episode, premiered, title)
		except:
			log_utils.error()
			return {}

	# v2.0.31: scrapers that ask a Stremio addon for imdb:season:episode, numbered by Cinemeta
	_STREMIO_SCRAPERS = ('torrentio', 'torrentio_spanish', 'comet', 'mediafusion', 'meteor', 'peerflix',
		'sootio', 'torrentsdb', 'torz', 'zilean', 'aiostreams')

	def _stremio_numbering(self, data):
		"""v2.0.31: for daily and talk shows, the season:episode Cinemeta gives
		to this air date (The Tonight Show: TMDb S14E13, IMDb S13E1xx), so the
		Stremio-style scrapers ask for the episode they actually know."""
		try:
			if not data.get('air_date_search'): return
			from resources.lib.modules import cinemeta
			se = cinemeta.episode_for(data.get('imdb'), data.get('premiered'), data.get('title'))
			if not se or (int(se[0]), int(se[1])) == (int(data['season']), int(data['episode'])): return
			data['stremio_se'] = (int(se[0]), int(se[1]))
			data['stremio_hdlr'] = 'S%02dE%02d' % data['stremio_se']
			log_utils.log('CINEMETA: %s S%02dE%02d (%s) -> %s for Stremio scrapers' % (data.get('imdb'), int(data['season']),
				int(data['episode']), data.get('premiered'), data['stremio_hdlr']), level=log_utils.LOGDEBUG)
		except:
			log_utils.error()

	def _scraper_data(self, source, data):
		"""The data a single-episode scraper call gets: Cinemeta's numbering for
		the Stremio-style ones when it differs (v2.0.31), the TMDb one otherwise."""
		se = data.get('stremio_se')
		if not se or source not in self._STREMIO_SCRAPERS: return data
		d = dict(data)
		d['season'], d['episode'] = str(se[0]), str(se[1])
		d.pop('alt_hdlr', None)
		return d

	def _daily_host_alias(self, data):
		"""v2.0.31: daily and talk shows are posted under the presenter's name
		('Jimmy.Fallon.2026.09.21...' for The Tonight Show Starring Jimmy Fallon).
		The presenter, taken from the show title, becomes one more alias for
		EVERY scraper, so their title check keeps those releases; the episode is
		still matched by its registered air date. Only for shows TVmaze calls
		daily (air_date_search)."""
		try:
			if not data.get('air_date_search'): return
			from resources.lib.jacksparrow import source_utils as _js_source_utils
			host = _js_source_utils.host_name(data.get('tvshowtitle'))
			if not host: return
			data['host_title'] = host
			aliases = list(data.get('aliases') or [])
			if not any((a.get('title') if isinstance(a, dict) else a) == host for a in aliases):
				aliases.append({'title': host, 'country': ''})
			data['aliases'] = aliases
		except:
			log_utils.error()

	def _register_air_date(self, data):
		"""v2.0.16: the episode's air date for the scrapers' title check and for
		picking the file inside a pack (releases named Show.2026.10.20)."""
		try:
			from resources.lib.jacksparrow import source_utils as _js_source_utils
			_js_source_utils.register_air_date(data)
		except: log_utils.error()

	def _tvdb_numbering(self, tvdb, season, episode, premiered=None):
		try:
			from resources.lib.modules import tvdb as tvdb_api
			meta = getattr(self, 'meta', None) or {}
			return tvdb_api.episode_numbering(tvdb, season, episode, meta.get('counts'), premiered)
		except:
			log_utils.error()
			return {}

	def getSources_silent(self, title, year, imdb, tvdb, season, episode, tvshowtitle, premiered, timeout=90):
		try:
			p_label = '[COLOR %s]%s (S%02dE%02d)[/COLOR]' % (self.highlight_color, tvshowtitle, int(season), int(episode))
			homeWindow.clearProperty(self.labelProperty)
			homeWindow.setProperty(self.labelProperty, p_label)
			self.prepareSources()
			sourceDict = self.sourceDict
			_la = self._lang_assist_payload('episode') # v2.0.08
			if not _la: sourceDict = [i for i in sourceDict if i[0] != 'langhelper']
			sourceDict = [(i[0], i[1], i[1].hasEpisodes) for i in sourceDict]
			sourceDict = [(i[0], i[1]) for i in sourceDict if i[2]]
			aliases = []
			try:
				meta = self.meta
				aliases = meta.get('aliases', [])
			except: pass
			threads = []
			scraperDict = [(i[0], i[1], '') for i in sourceDict]
			if self.season_isAiring == 'false':
				scraperDict.extend([(i[0], i[1], 'season') for i in sourceDict if i[1].pack_capable])
				scraperDict.extend([(i[0], i[1], 'show') for i in sourceDict if i[1].pack_capable])
			trakt_aliases = self.getAliasTitles(imdb, 'episode')
			try: aliases.extend([i for i in trakt_aliases if not i in aliases]) # combine TMDb and Trakt aliases
			except: pass
			try: country_codes = meta.get('country_codes', [])
			except: country_codes = []
			for i in country_codes:
				if i in ('CA', 'US', 'UK', 'GB'):
					if i == 'GB': i = 'UK'
					alias = {'title': tvshowtitle + ' ' + i, 'country': i.lower()}
					if not alias in aliases: aliases.append(alias)
			data = {'title': title, 'year': year, 'imdb': imdb, 'tvdb': tvdb, 'season': season, 'episode': episode, 'tvshowtitle': tvshowtitle, 'aliases': aliases, 'premiered': premiered, 'total_seasons': self.total_seasons}
			data.update(self._tvdb_numbering(tvdb, season, episode, premiered)) # TheTVDB SxxEyy when it differs from TMDb; absolute number for anime
			self.alt_hdlr = data.get('alt_hdlr') or '' # v2.0.37: para el control por titulo del episodio
			data.update(self._air_date_info(imdb, tvdb, season, episode, premiered, title)) # v2.0.16: TVmaze, daily and talk shows by air date
			self._daily_host_alias(data) # v2.0.31: presenter's name for talk shows, every scraper
			self._stremio_numbering(data) # v2.0.31: Cinemeta season:episode for Stremio scrapers
			self._register_air_date(data)
			if _la: data['lang_assist'] = _la # v2.0.08
			for i in scraperDict:
				name, pack = i[0].upper(), i[2]
				if pack == 'season': name = '%s (season pack)' % name
				elif pack == 'show': name = '%s (show pack)' % name
				threads.append(Thread(target=self.getEpisodeSource, args=(imdb, season, episode, data, i[0], i[1], pack), name=name, daemon=True))
			[i.start() for i in threads]
			end_time = time() + timeout
		except: return log_utils.error()
		while True:
			try:
				if control.monitor.abortRequested(): return sysexit()
				try:
					info = [x.getName() for x in threads if x.is_alive() is True]
					if len(info) == 0: break
					if end_time < time(): break
				except:
					log_utils.error()
					break
				control.sleep(100)
			except: log_utils.error()
		del threads[:] # Make sure any remaining providers are stopped.
		self.sources.extend(self.scraper_sources)
		self.tvshowtitle = tvshowtitle
		self.year = year
		homeWindow.clearProperty('fs_filterless_search')
		# v2.0.37: lo que _episode_title_check() necesita de ESTA busqueda (kodi.log
		# del 19-nov-2026: self.tmdb/self.season no existen por este camino)
		_ec = dict(getattr(self, '_ep_check', None) or {})
		_ec.update({'title': title, 'season': season, 'episode': episode})
		self._ep_check = _ec
		if len(self.sources) > 0: self.sourcesFilter()
		return self.sources

	def getSources_dialog(self, title, year, imdb, tvdb, season, episode, tvshowtitle, premiered, timeout=90):
		try:
			content = 'movie' if tvshowtitle is None else 'episode'
			if self.filterless_scrape: homeWindow.setProperty('fs_filterless_search', 'true')
			if self.custom_query == 'true':
				try:
					custom_title = control.dialog.input('[COLOR %s][B]%s[/B][/COLOR]' % (self.highlight_color, getLS(32038)), defaultt=tvshowtitle if tvshowtitle else title)
					if content == 'movie':
						if custom_title: title = custom_title ; self.meta.update({'title': title})
						custom_year = control.dialog.input('[COLOR %s]%s (%s)[/COLOR]' % (self.highlight_color, getLS(32457), getLS(32488)), type=control.numeric_input, defaultt=str(year))
						if custom_year: year = str(custom_year) ; self.meta.update({'year': year})
					else:
						if custom_title: tvshowtitle = custom_title ; self.meta.update({'tvshowtitle': tvshowtitle})
						custom_season = control.dialog.input('[COLOR %s]%s (%s)[/COLOR]' % (self.highlight_color, getLS(32055), getLS(32488)), type=control.numeric_input, defaultt=str(season))
						if custom_season: season = str(custom_season) ; self.meta.update({'season': season})
						custom_episode = control.dialog.input('[COLOR %s]%s (%s)[/COLOR]' % (self.highlight_color, getLS(32325), getLS(32488)), type=control.numeric_input, defaultt=str(episode))
						if custom_episode: episode = str(custom_episode) ; self.meta.update({'episode': episode})
					p_label = '[COLOR %s]%s (%s)[/COLOR]' % (self.highlight_color, title, year) if tvshowtitle is None else '[COLOR %s]%s (S%02dE%02d)[/COLOR]' % (self.highlight_color, tvshowtitle, int(season), int(episode))
					homeWindow.clearProperty(self.labelProperty)
					homeWindow.setProperty(self.labelProperty, p_label)
					homeWindow.clearProperty(self.metaProperty)
					homeWindow.setProperty(self.metaProperty, jsdumps(self.meta))
					homeWindow.clearProperty(self.seasonProperty)
					homeWindow.setProperty(self.seasonProperty, '' if season is None else season)
					homeWindow.clearProperty(self.episodeProperty)
					homeWindow.setProperty(self.episodeProperty, '' if episode is None else episode)
					homeWindow.clearProperty(self.titleProperty)
					homeWindow.setProperty(self.titleProperty, '' if title is None else title)
					log_utils.log('Custom query scrape ran using: %s' % p_label, level=log_utils.LOGDEBUG)
				except: log_utils.error()
			header = homeWindow.getProperty(self.labelProperty) + ': Scraping...'
			try:
				if getSetting('progress.dialog') == '0':
					self.progressDialog = self.getSourceProgress(header, self.meta)
				else: raise Exception()
			except:
				homeWindow.clearProperty('luc_kodi.source_progress_is_alive')
				self.progressDialog = control.progressDialogBG
				self.progressDialog.create(header, '')
			self.prepareSources()
			sourceDict = self.sourceDict
			_la = self._lang_assist_payload(content) # v2.0.08: langhelper solo con titulos de Languages
			if not _la: sourceDict = [i for i in sourceDict if i[0] != 'langhelper']
			self.progressDialog.update(0, getLS(32600)) # preparing sources
			if content == 'movie': sourceDict = [(i[0], i[1]) for i in sourceDict if i[1].hasMovies]
			else: sourceDict = [(i[0], i[1]) for i in sourceDict if i[1].hasEpisodes]
			if getSetting('scrapers.prioritize') == 'true':
				sourceDict = [(i[0], i[1], i[1].priority) for i in sourceDict]
				sourceDict = sorted(sourceDict, key=lambda i: i[2]) # sorted by scraper priority
			try: aliases = self.meta.get('aliases', [])
			except: aliases = []
			threads = [] ; threads_append = threads.append
			# v2.0.26: busqueda inteligente. Se crea ANTES de lanzar los hilos: un
			# proveedor servido desde rel_src contesta al instante.
			self._planner = None ; self._smart_partial = False
			try:
				from resources.lib.modules import scrape_planner
				self._planner = scrape_planner.Planner(content, getattr(self, '_autoplay_hint', False), 25)
			except Exception: log_utils.error()

			if content == 'movie':
				trakt_aliases = self.getAliasTitles(imdb, content) # cached for 7 days in trakt module called
				try: aliases.extend([i for i in trakt_aliases if not i in aliases]) # combine TMDb and Trakt aliases
				except: pass
				data = {'title': title, 'aliases': aliases, 'year': year, 'imdb': imdb}
				if _la: data['lang_assist'] = _la
				for i in sourceDict:
					_prov = i[0]
					i = Thread(target=self.getMovieSource, args=(imdb, data, i[0], i[1]), name=i[0].upper(), daemon=True)
					threads_append(i)
					if self._planner: self._planner.register(i, _prov, 'movie')
					i.start()
			else:
				scraperDict = [(i[0], i[1], '') for i in sourceDict] if ((not self.dev_mode) or (not self.dev_disable_single)) else []
				if self.season_isAiring == 'false':
					if (not self.dev_mode) or (not self.dev_disable_season_packs): scraperDict.extend([(i[0], i[1], 'season') for i in sourceDict if i[1].pack_capable])
					if (not self.dev_mode) or (not self.dev_disable_show_packs): scraperDict.extend([(i[0], i[1], 'show') for i in sourceDict if i[1].pack_capable])
				trakt_aliases = self.getAliasTitles(imdb, content) # cached for 7 days in trakt module called
				try: aliases.extend([i for i in trakt_aliases if not i in aliases]) # combine TMDb and Trakt aliases
				except: pass
				try: country_codes = self.meta.get('country_codes', [])
				except: country_codes = []
				for i in country_codes:
					if i in ('CA', 'US', 'UK', 'GB'):
						if i == 'GB': i = 'UK'
						alias = {'title': tvshowtitle + ' ' + i, 'country': i.lower()}
						if not alias in aliases: aliases.append(alias)
				aliases = aliases_check(tvshowtitle, aliases)
				data = {'title': title, 'year': year, 'imdb': imdb, 'tvdb': tvdb, 'season': season, 'episode': episode, 'tvshowtitle': tvshowtitle, 'aliases': aliases, 'premiered': premiered, 'total_seasons': self.total_seasons}
				data.update(self._tvdb_numbering(tvdb, season, episode, premiered)) # TheTVDB SxxEyy when it differs from TMDb; absolute number for anime
				self.alt_hdlr = data.get('alt_hdlr') or '' # v2.0.37: para el control por titulo del episodio
				data.update(self._air_date_info(imdb, tvdb, season, episode, premiered, title)) # v2.0.16: TVmaze, daily and talk shows by air date
				self._daily_host_alias(data) # v2.0.31: presenter's name for talk shows, every scraper
				self._stremio_numbering(data) # v2.0.31: Cinemeta season:episode for Stremio scrapers
				self._register_air_date(data)
				if _la: data['lang_assist'] = _la
				for i in scraperDict:
					name, pack, _prov = i[0].upper(), i[2], i[0]
					if pack == 'season': name = '%s (season pack)' % name
					elif pack == 'show': name = '%s (show pack)' % name
					i = Thread(target=self.getEpisodeSource, args=(imdb, season, episode, data, i[0], i[1], pack), name=name, daemon=True)
					threads_append(i)
					if self._planner: self._planner.register(i, _prov, pack if pack else 'episode')
					i.start()
#			[i.start() for i in threads]
			sdc = control.getSourceHighlightColor()
			string1 = f"[B]{getLS(32404) % (self.highlight_color, sdc, '%s')}[/B]" # msgid "[COLOR %s]Time elapsed:[/COLOR]  [COLOR %s]%s seconds[/COLOR]"
			string3 = f"[B]{getLS(32406) % (self.highlight_color, sdc, '%s')}[/B]" # msgid "[COLOR %s]Remaining providers:[/COLOR] [COLOR %s]%s[/COLOR]"

			try: timeout = int(getSetting('scrapers.timeout'))
			except: pass
			if self.all_providers == 'true': timeout = 90
			if self._planner:
				self._planner.timeout = timeout
				if self.all_providers == 'true': self._planner.enabled = False # "todos los proveedores" pide esperar a todos
			self.start_time = time()
			end_time = self.start_time + timeout
			quality = getSetting('hosts.quality') or '0'
			line1 = line2 = line3 = ""
			terminate_onCloud = getSetting('terminate.onCloud.sources') == 'true'
			pre_emp = getSetting('preemptive.termination') == 'true'
			pre_emp_limit = int(getSetting('preemptive.limit'))
			pre_emp_res = getSetting('preemptive.res') or '0'
			source_4k = source_1080 = source_720 = source_sd = total = 0
			total_format = '[COLOR %s][B]%s[/B][/COLOR]'
			pdiag_format = '[COLOR %s]4K:[/COLOR]  %s  |  [COLOR %s]1080p:[/COLOR]  %s  |  [COLOR %s]720p:[/COLOR]  %s  |  [COLOR %s]SD:[/COLOR]  %s  |  [COLOR %s]TOTAL:[/COLOR]  %s' % (
				self.highlight_color, '%s', self.highlight_color, '%s', self.highlight_color, '%s', self.highlight_color, '%s', self.highlight_color, '%s' )
			control.hide()
		except:
			log_utils.error()
			try: self.progressDialog.close()
			except: pass
			del self.progressDialog
			return

		# v2.0.29: el bucle sigue mirando cada 25 ms si hay que salir (cancelar,
		# cloud, corte preventivo, busqueda inteligente, todos listos, timeout),
		# pero ya no recorre la lista entera en cada vuelta: las calidades y las
		# fuentes cloud se cuentan solo sobre lo que llega (la cola solo crece), y
		# el cuadro de progreso, que pasa por el bloqueo de la GUI de Kodi en
		# cada update/setProperty, se refresca solo cuando cambia lo que ensena
		# o cada 100 ms para el cronometro (antes, 40 veces por segundo).
		_q4k, _q1080, _q720, _qsd, _qcloud, _seen = 0, 0, 0, 0, 0, 0
		_ui_last, _ui_sig, _ui_every = 0.0, None, 0.1
		while True:
			try:
				if control.monitor.abortRequested(): return sysexit()
				try:
					if self.progressDialog.iscanceled(): break
				except: pass

				_n = len(self.scraper_sources)
				if _n < _seen: _q4k = _q1080 = _q720 = _qsd = _qcloud = _seen = 0 # la cola se ha rehecho: se cuenta de nuevo
				if _n > _seen:
					for e in islice(self.scraper_sources, _seen, _n):
						try:
							_eq = e.get('quality')
							if _eq == '4K': _q4k += 1
							elif _eq == '1080p': _q1080 += 1
							elif _eq == '720p': _q720 += 1
							elif _eq in ('SD', 'SCR', 'CAM'): _qsd += 1
							if e.get('source') == 'cloud': _qcloud += 1
						except: pass
					_seen = _n
				if terminate_onCloud:
					if _qcloud > 0: break
				if pre_emp:
					if pre_emp_res == '0' and source_4k >= pre_emp_limit: break
					elif pre_emp_res == '1' and source_1080 >= pre_emp_limit: break
					elif pre_emp_res == '2' and source_720 >= pre_emp_limit: break
					elif pre_emp_res == '3' and source_sd >= pre_emp_limit: break
				_smart_txt = None
				if self._planner:
					try:
						_el = time() - self.start_time
						self._planner.prefetch(self.scraper_sources)
						if self._planner.should_stop(_el, self.scraper_sources):
							self._smart_partial = True
							break
						_smart_txt = self._planner.status(_el, None)
					except Exception:
						log_utils.error()
						self._planner.enabled = False
				# misma regla que antes: las calidades por encima del limite no se cuentan
				source_4k = _q4k if quality == '0' else 0
				source_1080 = _q1080 if quality in ('0', '1') else 0
				source_720 = _q720 if quality in ('0', '1', '2') else 0
				source_sd = _qsd
				total = source_4k + source_1080 + source_720 + source_sd
				try:
					info = [x.getName() for x in threads if x.is_alive() is True]
					all_done = len(info) == 0
					current_time = time()
					_last_frame = all_done or end_time < current_time # el ultimo fotograma se pinta siempre, como antes
					_sig = (total, source_4k, source_1080, source_720, len(info), _smart_txt)
					if _last_frame or _sig != _ui_sig or current_time - _ui_last >= _ui_every:
						_ui_sig, _ui_last = _sig, current_time
						source_4k_label = total_format % ('red', source_4k) if source_4k == 0 else total_format % (sdc, source_4k)
						source_1080_label = total_format % ('red', source_1080) if source_1080 == 0 else total_format % (sdc, source_1080)
						source_720_label = total_format % ('red', source_720) if source_720 == 0 else total_format % (sdc, source_720)
						source_sd_label = total_format % ('red', source_sd) if source_sd == 0 else total_format % (sdc, source_sd)
						source_total_label = total_format % ('red', total) if total == 0 else total_format % (sdc, total)
						line1 = pdiag_format % (source_4k_label, source_1080_label, source_720_label, source_sd_label, source_total_label)
						line2 = string1 % round(current_time - self.start_time, 1)
						if len(info) > 6: line3 = string3 % str(len(info))
						elif len(info) > 0: line3 = string3 % (', '.join(info))
						else: line3 = ''
						percent = 100 if all_done else int((len(threads) - len(info)) * 100 / max(1, len(threads)))
						if self.progressDialog != control.progressDialogBG:
							update_line = line1 + '[CR]' + line2 + ('[CR]' + line3 if line3 else '')
							self.progressDialog.update(max(1, percent), update_line)
							try:
								self.progressDialog.setProperty('luc_kodi.src.4k',    str(source_4k))
								self.progressDialog.setProperty('luc_kodi.src.1080',  str(source_1080))
								self.progressDialog.setProperty('luc_kodi.src.720',   str(source_720))
								self.progressDialog.setProperty('luc_kodi.src.sd',    str(source_sd))
								self.progressDialog.setProperty('luc_kodi.src.total', str(total))
								self.progressDialog.setProperty('luc_kodi.src.elapsed', str(round(current_time - self.start_time, 1)))
								providers_str = ', '.join(info) if len(info) <= 6 else str(len(info)) + ' providers'
								if _smart_txt: providers_str = '%s  ·  %s' % (providers_str, _smart_txt)
								self.progressDialog.setProperty('luc_kodi.src.providers', providers_str)
								self.progressDialog.setProperty('luc_kodi.src.providers_count', str(len(info)))
							except: pass
						else: self.progressDialog.update(max(1, percent), line3)
					if _last_frame: break
				except:
					log_utils.error()
					break
				control.sleep(25)
			except: log_utils.error()
		del threads[:] # Make sure any remaining providers are stopped, only deletes threads not started yet.
		if self._planner:
			# v2.0.26: lo que llego en el ultimo tramo tambien se pregunta al debrid, y
			# se espera (como mucho 5 s) a que vuelvan las consultas en marcha para
			# que sourcesFilter() las encuentre ya guardadas.
			try:
				self._planner.loop_end = time() - self.start_time
				self._planner.prefetch(self.scraper_sources, force=True)
				self._planner.join_prefetch(5.0)
			except Exception: log_utils.error()
		self.sources.extend(list(self.scraper_sources))
		self.tvshowtitle = tvshowtitle
		self.year = year
		homeWindow.clearProperty('fs_filterless_search')
		# v2.0.37: lo que _episode_title_check() necesita de ESTA busqueda (kodi.log
		# del 19-nov-2026: self.tmdb/self.season no existen por este camino)
		_ec = dict(getattr(self, '_ep_check', None) or {})
		_ec.update({'title': title, 'season': season, 'episode': episode})
		self._ep_check = _ec
		if len(self.sources) > 0: self.sourcesFilter()
		if self._planner:
			self._planner.finish(time() - self.start_time, self.sources)
			if getattr(self, '_smart_partial', False):
				from resources.lib.modules.scrape_planner import PARTIAL_TTL
				providerscache.keep_short(PARTIAL_TTL) # la lista recortada vive 20 min, no 48 h
				self._planner.partial_key = providerscache.current_key() # y se suelta antes si los cortados terminan
			# el planificador queda cerrado pero vivo: un proveedor que termina
			# despues de cortar apunta aun su tiempo real
		self._lang_assist_report()
		if homeWindow.getProperty('luc_kodi.source_progress_is_alive') != 'true':
			try: self.progressDialog.close()
			except: pass
			self.progressDialog = None
		return self.sources

	def preResolve(self, next_sources, next_meta):
		try:
			if not next_sources: raise Exception()
			homeWindow.setProperty(self.metaProperty, jsdumps(next_meta))
			if getSetting('autoplay.sd') == 'true': next_sources = [i for i in next_sources if not i['quality'] in ('4K', '1080p', '720p')]
			uncached_filter = [i for i in next_sources if re.match(r'^uncached.*torrent', i['source'])]
			next_sources = [i for i in next_sources if i not in uncached_filter]
			# Never pre-resolve NZB usenet: each would start a persistent
			# server-side debrid download and blow the active-transfer cap.
			# Easynews (direct=True) is cheap and stays eligible.
			next_sources = [i for i in next_sources if not ('usenet' in (i.get('source', '') or '') and not i.get('direct'))]
		except:
			log_utils.error()
			return playerWindow.clearProperty('luc_kodi.preResolved_nextUrl')

		for i in range(len(next_sources)):
			try:
				control.sleep(1000)
				try:
					if control.monitor.abortRequested(): return sysexit()
					url = self.sourcesResolve(next_sources[i])
					if not url:
						log_utils.log('preResolve failed for : next_sources[i]=%s' % str(next_sources[i]), level=log_utils.LOGWARNING)
						continue
					if not any(x in url.lower() for x in video_extensions) and not '/dld/' in url:
						log_utils.log('preResolve Playback not supported for (sourcesAutoPlay()): %s' % fs_client.scrub_url(url), level=log_utils.LOGWARNING)
						continue
					if url:
						control.sleep(500)
						player_hasVideo = control.condVisibility('Player.HasVideo')
						if player_hasVideo: # do not setPropery if user stops playback quickly because "onPlayBackStopped" is already called and won't be able to clear it.
							playerWindow.setProperty('luc_kodi.preResolved_nextUrl', url)
							log_utils.log('preResolved_nextUrl : %s' % fs_client.scrub_url(url), level=log_utils.LOGDEBUG)
						else:
							log_utils.log('player_hasVideo = %s : skipping setting preResolved_nextUrl' % player_hasVideo, level=log_utils.LOGWARNING)
						break
				except: pass
			except: log_utils.error()
		control.sleep(200)

	def prepareSources(self):
		try:
			control.makeFile(control.dataPath)
			dbcon = database.connect(sourceFile)
			dbcur = dbcon.cursor()
			dbcur.execute('''CREATE TABLE IF NOT EXISTS rel_src (source TEXT, imdb_id TEXT, season TEXT, episode TEXT, hosts TEXT, added TEXT, UNIQUE(source, imdb_id, season, episode));''')
			dbcur.execute('''CREATE TABLE IF NOT EXISTS rel_aliases (title TEXT, aliases TEXT, UNIQUE(title));''')
			dbcur.connection.commit()
		except: log_utils.error()
		finally:
			try:
				dbcur.close()
			except Exception:
				pass
			try:
				dbcon.close()
			except Exception:
				pass
	def getMovieSource(self, imdb, data, source, call):
		try:
			dbcon = database.connect(sourceFile, timeout=60)
			dbcon.execute('''PRAGMA journal_mode = WAL''')
			dbcon.execute('''PRAGMA synchronous = OFF''')
			dbcon.execute('''PRAGMA temp_store = memory''')
			dbcon.execute('''PRAGMA mmap_size = 268435456''')
			dbcur = dbcon.cursor()
		except: pass
		if not imdb: # Fix to stop items passed with null IMDB_id pulling old unrelated sources from the database
			try:
				dbcur.execute('''DELETE FROM rel_src WHERE (source=? AND imdb_id='' AND season='' AND episode='')''', (source,))
				dbcur.connection.commit()
			except: log_utils.error()
		try:
			sources = []
			db_movie = dbcur.execute('''SELECT * FROM rel_src WHERE (source=? AND imdb_id=? AND season='' AND episode='')''', (source, imdb)).fetchone()
			if db_movie:
				timestamp = cleandate.datetime_from_string(str(db_movie[5]), '%Y-%m-%d %H:%M:%S.%f', False)
				db_movie_valid = abs(self.time - timestamp) < self._rel_expiry(db_movie[4], single_expiry)
				if db_movie_valid:
					sources = _blob_unpack(db_movie[4], literal_eval)
					self._plan_cached(source, 'movie', sources)
					return self.scraper_sources.extend(sources)
		except: log_utils.error()
		_t0 = time()
		try:
			sources = []
			sources = call().sources(data, self.hostprDict)
			self._plan_live(source, 'movie', _t0, sources)
			if sources:
				self.scraper_sources.extend(sources)
				dbcur.execute('''INSERT OR REPLACE INTO rel_aliases Values (?, ?)''', (data.get('title', ''), repr(data.get('aliases', ''))))
				dbcur.execute('''INSERT OR REPLACE INTO rel_src Values (?, ?, ?, ?, ?, ?)''', (source, imdb, '', '', _blob_pack(sources), datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f")))
				dbcur.connection.commit()
			elif imdb and self._empty_ttl_minutes():
				# v1.0.90: el scraper respondio y no encontro nada -> se recuerda un
				# rato (sources.empty.ttl) para no volver a esperar su timeout en
				# cada apertura. Si LANZO una excepcion no llega aqui: los errores
				# no se guardan y se reintentan siempre.
				dbcur.execute('''INSERT OR REPLACE INTO rel_src Values (?, ?, ?, ?, ?, ?)''', (source, imdb, '', '', '[]', datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f")))
				dbcur.connection.commit()
		except:
			self._plan_failed(source, 'movie', _t0)
			log_utils.error()

	def getEpisodeSource(self, imdb, season, episode, data, source, call, pack):
		try:
			dbcon = database.connect(sourceFile, timeout=60)
			dbcon.execute('''PRAGMA journal_mode = WAL''')
			dbcon.execute('''PRAGMA synchronous = OFF''')
			dbcon.execute('''PRAGMA temp_store = memory''')
			dbcon.execute('''PRAGMA mmap_size = 268435456''')
			dbcur = dbcon.cursor()
		except: pass
		if not imdb: # Fix to stop items passed with null IMDB_id pulling old unrelated sources from the database
			try:
				dbcur.execute('''DELETE FROM rel_src WHERE (source=? AND imdb_id='' AND season=? AND episode=?)''', (source, season, episode))
				dbcur.execute('''DELETE FROM rel_src WHERE (source=? AND imdb_id='' AND season=? AND episode='')''', (source, season))
				dbcur.execute('''DELETE FROM rel_src WHERE (source=? AND imdb_id='' AND season='' AND episode='')''', (source, ))
				dbcur.connection.commit()
			except: log_utils.error()
		if not pack: # singleEpisodes db check
			try:
				db_singleEpisodes = dbcur.execute('''SELECT * FROM rel_src WHERE (source=? AND imdb_id=? AND season=? AND episode=?)''', (source, imdb, season, episode)).fetchone()
				if db_singleEpisodes:
					timestamp = cleandate.datetime_from_string(str(db_singleEpisodes[5]), '%Y-%m-%d %H:%M:%S.%f', False)
					db_singleEpisodes_valid = abs(self.time - timestamp) < self._rel_expiry(db_singleEpisodes[4], single_expiry)
					if db_singleEpisodes_valid:
						sources = _blob_unpack(db_singleEpisodes[4], literal_eval)
						self._plan_cached(source, 'episode', sources)
						return self.scraper_sources.extend(sources)
			except: log_utils.error()
		elif pack == 'season': # seasonPacks db check
			try:
				db_seasonPacks = dbcur.execute('''SELECT * FROM rel_src WHERE (source=? AND imdb_id=? AND season=? AND episode='')''', (source, imdb, season)).fetchone()
				if db_seasonPacks:
					timestamp = cleandate.datetime_from_string(str(db_seasonPacks[5]), '%Y-%m-%d %H:%M:%S.%f', False)
					db_seasonPacks_valid = abs(self.time - timestamp) < season_expiry
					if db_seasonPacks_valid:
						sources = _blob_unpack(db_seasonPacks[4], literal_eval)
						sources = [i for i in sources if not 'episode_start' in i or i['episode_start'] <= int(episode) <= i['episode_end']] # filter out range items that do not apply to current episode for return
						self._plan_cached(source, 'season', sources)
						return self.scraper_sources.extend(sources)
			except: log_utils.error()
		elif pack == 'show': # showPacks db check
			try:
				db_showPacks = dbcur.execute('''SELECT * FROM rel_src WHERE (source=? AND imdb_id=? AND season='' AND episode='')''', (source, imdb)).fetchone()
				if db_showPacks:
					timestamp = cleandate.datetime_from_string(str(db_showPacks[5]), '%Y-%m-%d %H:%M:%S.%f', False)
					db_showPacks_valid = abs(self.time - timestamp) < show_expiry
					if db_showPacks_valid:
						sources = _blob_unpack(db_showPacks[4], literal_eval)
						# v1.0.60: `or 0` blinda contra scrapers que marcan package='show' sin
						# fijar last_season -> daba TypeError (NoneType >= int) y se perdian TODOS
						# sus packs, ademas de quedar el fallo cacheado en rel_src.
						sources = [i for i in sources if (i.get('last_season') or 0) >= int(season)] # filter out range items that do not apply to current season for return
						self._plan_cached(source, 'show', sources)
						return self.scraper_sources.extend(sources)
			except: log_utils.error()

		try: #dummy write or threads wait till return from scrapers...write for each is needed
			dbcur.execute('''INSERT OR REPLACE INTO rel_src Values (?, ?, ?, ?, ?, ?)''', ('dummy write', '', '', '', '', ''))
			dbcur.connection.commit()
		except: log_utils.error()

		_t0 = time()
		if not pack: # singleEpisodes scraper call
			try:
				sources = []
				sources = call().sources(self._scraper_data(source, data), self.hostprDict)
				self._plan_live(source, 'episode', _t0, sources)
				if sources:
					dbcur.execute('''INSERT OR REPLACE INTO rel_src Values (?, ?, ?, ?, ?, ?)''', (source, imdb, season, episode, _blob_pack(sources), datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f")))
					dbcur.connection.commit()
					return self.scraper_sources.extend(sources)
				if imdb and self._empty_ttl_minutes(): # v1.0.90: ver getMovieSource
					dbcur.execute('''INSERT OR REPLACE INTO rel_src Values (?, ?, ?, ?, ?, ?)''', (source, imdb, season, episode, '[]', datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f")))
					dbcur.connection.commit()
				return
			except:
				self._plan_failed(source, 'episode', _t0)
				return log_utils.error()
		elif pack == 'season': # seasonPacks scraper call
			try:
				sources = []
				_scraper = call()
				# v1.0.60: dmm y peerflix no implementan sources_packs().
				# Llamarlo lanzaba AttributeError en cada busqueda de serie y
				# llenaba el log de ruido. Se salta limpiamente.
				if not hasattr(_scraper, 'sources_packs'): return
				sources = _scraper.sources_packs(data, self.hostprDict, bypass_filter=self.dev_disable_season_filter)
				self._plan_live(source, 'season', _t0, sources)
				if sources:
					dbcur.execute('''INSERT OR REPLACE INTO rel_src Values (?, ?, ?, ?, ?, ?)''', (source, imdb, season,'', _blob_pack(sources), datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f")))
					dbcur.connection.commit()
					sources = [i for i in sources if not 'episode_start' in i or i['episode_start'] <= int(episode) <= i['episode_end']] # filter out range items that do not apply to current episode for return
					return self.scraper_sources.extend(sources)
				return
			except:
				self._plan_failed(source, 'season', _t0)
				return log_utils.error()
		elif pack == 'show': # showPacks scraper call
			try:
				sources = []
				_scraper = call()
				if not hasattr(_scraper, 'sources_packs'): return
				sources = _scraper.sources_packs(data, self.hostprDict, search_series=True, total_seasons=self.total_seasons, bypass_filter=self.dev_disable_show_filter)
				self._plan_live(source, 'show', _t0, sources)
				if sources:
					dbcur.execute('''INSERT OR REPLACE INTO rel_src Values (?, ?, ?, ?, ?, ?)''', (source, imdb, '', '', _blob_pack(sources), datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f")))
					dbcur.connection.commit()
					# v1.0.60: `or 0` blinda contra scrapers que marcan package='show' sin
					# fijar last_season -> daba TypeError (NoneType >= int) y se perdian TODOS
					# sus packs, ademas de quedar el fallo cacheado en rel_src.
					sources = [i for i in sources if (i.get('last_season') or 0) >= int(season)] # filter out range items that do not apply to current season for return
					return self.scraper_sources.extend(sources)
			except:
				self._plan_failed(source, 'show', _t0)
				log_utils.error()

	# v2.0.26: busqueda inteligente (scrape_planner). Sin planificador (busqueda
	# silenciosa del siguiente episodio, test de proveedores) no hacen nada.
	def _plan_cached(self, source, kind, sources):
		_p = getattr(self, '_planner', None)
		if _p: _p.from_cache(source, kind, sources)

	def _plan_live(self, source, kind, t0, sources):
		_p = getattr(self, '_planner', None)
		if _p: _p.live(source, kind, time() - t0, sources)

	def _plan_failed(self, source, kind, t0):
		_p = getattr(self, '_planner', None)
		if _p: _p.failed(source, kind, time() - t0)

	def _arm_rollover(self, rest):
		"""v1.0.91: deja en la ventana Home las siguientes fuentes del autoplay.
		Si Kodi no consigue arrancar la elegida (onPlayBackError antes de
		onAVStarted), el SubtitlePlayer de service.py lanza play_rollover y se
		prueba la siguiente. Maximo dos saltos por reproduccion."""
		try:
			left = getattr(self, '_rollover_left', 2)
			if getSetting('playback.rollover') == 'false' or left <= 0 or not rest:
				homeWindow.clearProperty(ROLLOVER_PROP)
				return
			pkg = {'items': rest[:4], 'left': left, 'ts': time(),
				   'title': getattr(self, 'title', ''), 'year': getattr(self, 'year', ''),
				   'imdb': getattr(self, 'imdb', ''), 'tmdb': getattr(self, 'tmdb', ''), 'tvdb': getattr(self, 'tvdb', ''),
				   'season': getattr(self, 'season', None), 'episode': getattr(self, 'episode', None),
				   'meta': self.meta if isinstance(getattr(self, 'meta', None), dict) else {}}
			homeWindow.setProperty(ROLLOVER_PROP, jsdumps(pkg, default=str))
		except Exception:
			homeWindow.clearProperty(ROLLOVER_PROP)

	def rollover(self):
		"""v1.0.91: segunda oportunidad tras un fallo del reproductor."""
		try:
			raw = homeWindow.getProperty(ROLLOVER_PROP)
			homeWindow.clearProperty(ROLLOVER_PROP)
			if not raw: return
			pkg = jsloads(raw)
			items = pkg.get('items') or []
			if not items or (time() - float(pkg.get('ts', 0))) > 600: return
			self.title, self.year = pkg.get('title'), pkg.get('year')
			self.imdb, self.tmdb, self.tvdb = pkg.get('imdb'), pkg.get('tmdb'), pkg.get('tvdb')
			self.season, self.episode = pkg.get('season'), pkg.get('episode')
			self.meta = pkg.get('meta') or {}
			self._rollover_left = int(pkg.get('left', 1)) - 1
			log_utils.log('[ luc_kodi ] rollover: playback failed, trying the next source (%d left)' % len(items), level=log_utils.LOGINFO)
			control.notification(message=400842)
			homeWindow.setProperty('luc_kodi.next_ep_direct', 'true')  # reproducir con player.play: no hay handle
			url = self.sourcesAutoPlay(items)
			if not url:
				homeWindow.clearProperty('luc_kodi.next_ep_direct')
				return self.errorForSources()
			from resources.lib.modules import player
			player.Player().play_source(self.title, self.year, self.season, self.episode, self.imdb, self.tmdb, self.tvdb, url, self.meta)
		except Exception:
			log_utils.error()

	def _empty_ttl_minutes(self):
		"""v1.0.90: minutos que se recuerda un 'no encontre nada' de un
		scraper (0 = nunca). En una busqueda forzada (rescrape) no se usa."""
		cached = getattr(self, '_empty_ttl_cache', None)
		if cached is None:
			try: cached = max(0, min(120, int(getSetting('sources.empty.ttl') or '30')))
			except Exception: cached = 30
			self._empty_ttl_cache = cached
		return cached

	def _rel_expiry(self, value, normal):
		"""Caducidad de una fila de rel_src: la normal si trae fuentes, y la
		corta de sources.empty.ttl si es un vacio recordado."""
		if value != '[]': return normal
		if getattr(self, '_rescrape', False): return timedelta(0)
		return timedelta(minutes=self._empty_ttl_minutes())

	def _badge_found(self, tmdb, items):
		# v2.0.35: guarda el mejor release encontrado (Dolby Vision/HDR, Atmos/DTS)
		# para el poster con insignias de este titulo. Sin el ajuste, nada.
		# Se llama desde play() con las fuentes ya en la mano: vengan de una
		# busqueda nueva o de la cache de 48 h, y con el tmdb del titulo, que
		# dentro de getSources() aun no esta en self (pruebas de la 2.0.35: solo salian
		# en los reproducidos).
		try:
			if not items: return
			from resources.lib.modules import badge_posters
			if badge_posters.enabled(): badge_posters.record_found(getattr(self, 'mediatype', ''), tmdb, items)
		except Exception: pass

	def sourcesFilter(self):
		if not self.isPrescrape: control.busy()
		# v1.0.89 — idiomas declarados. Se reune lo que dice cada indexador de
		# un mismo hash ANTES de quitar duplicados: filter_dupes() se queda con
		# una copia y tira las demas, y la que tiraba podia ser justo la de
		# Torrentio con la linea de banderas.
		_lang_names, _lang_hints = {}, {}
		try:
			for i in self.sources:
				_h = (i.get('hash') or '').lower()
				if not _h: continue
				if i.get('name_info'): _lang_names.setdefault(_h, []).append(i['name_info'])
				if i.get('lang_name'): _lang_names.setdefault(_h, []).append(i['lang_name'])
				if i.get('lang_hint'): _lang_hints.setdefault(_h, []).append(i['lang_hint'])
		except Exception: log_utils.error()
		if getSetting('remove.duplicates') == 'true': self.sources = self.filter_dupes()
		if self.mediatype == 'movie':
			if getSetting('source.enable.msizelimit') == 'true':
				try:
					movie_minSize, movie_maxSize = float(getSetting('source.min.moviesize')), float(getSetting('source.max.moviesize'))
					self.sources = [i for i in self.sources if (i.get('size', 0) >= movie_minSize and i.get('size', 0) <= movie_maxSize)]
				except: log_utils.error()
		else:
			self.sources = [i for i in self.sources if 'movie.collection' not in i.get('name_info', '')] # rare but a few retuned from "complete" show pack scrape returned as "movie.collection"
			if getSetting('source.checkReboots') == 'true':
				try:
					from resources.lib.modules.source_utils import tvshow_reboots
					reboots = tvshow_reboots()
					if self.tvshowtitle in reboots and self.year in reboots.get(self.tvshowtitle, []):
						log_utils.log('tvshowtitle(%s) is a REBOOT, filtering for year match per enabled setting' % self.tvshowtitle, level= log_utils.LOGDEBUG)
						self.sources = [i for i in self.sources if self.year in i.get('name')]
				except: log_utils.error()
			if getSetting('source.enable.esizelimit') == 'true':
				try:
					episode_minSize, episode_maxSize = float(getSetting('source.min.epsize')), float(getSetting('source.max.epsize'))
					self.sources = [i for i in self.sources if (i.get('size', 0) >= episode_minSize and i.get('size', 0) <= episode_maxSize)]
				except: log_utils.error()
			try: self.sources = self.calc_pack_size()
			except: pass
			self._episode_title_check()
		for i in self.sources:
			try:
				if 'name_info' in i: info_string = getFileType(name_info=i.get('name_info'))
				else: info_string = getFileType(url=i.get('url'))
				i.update({'info': (i.get('info') + ' /' + info_string).lstrip(' ').lstrip('/').rstrip('/')})
			except: log_utils.error()
		try:
			from resources.lib.modules import audio_langs
			for i in self.sources:
				_h = (i.get('hash') or '').lower()
				i['langs'] = audio_langs.for_item(i, _lang_names.get(_h, ()), _lang_hints.get(_h, ()))
		except Exception: log_utils.error()
		if getSetting('remove.hevc') == 'true':
			self.sources = [i for i in self.sources if 'HEVC' not in i.get('info', '')]
		if getSetting('remove.hdr') == 'true':
			self.sources = [i for i in self.sources if ' HDR ' not in i.get('info', '')] # needs space before and aft because of "HDRIP"
		if getSetting('remove.dolby.vision') == 'true':
			self.sources = [i for i in self.sources if ('DOLBY-VISION' not in i.get('info', '')) or ('DOLBY-VISION' in i.get('info', '') and ' HDR ' in i.get('info', ''))]
		if getSetting('remove.cam.sources') == 'true':
			self.sources = [i for i in self.sources if i['quality'] != 'CAM']
		if getSetting('remove.sd.sources') == 'true':
			if any(i for i in self.sources if any(value in i['quality'] for value in ('4K', '1080p', '720p'))): #only remove SD if better quality does exist
				self.sources = [i for i in self.sources if i['quality'] != 'SD']
		if getSetting('remove.3D.sources') == 'true':
			self.sources = [i for i in self.sources if '3D' not in i.get('info', '')]

		local = [i for i in self.sources if 'local' in i and i['local'] is True] # for library and videoscraper (skips cache check)
		self.sources = [i for i in self.sources if not i in local]
		direct = [i for i in self.sources if i['direct'] == True] # acct scrapers (skips cache check)
		self.sources = [i for i in self.sources if not i in direct]
		# ── RD 2026 keyword-filter compliance for direct items ────────────
		# AIOStreams / MediaFusion resolved-via-RD items (debrid label starts
		# with 'RD') will also 451 on playback if filename matches. Strip
		# them here so they never appear in the picker.
		try:
			from resources.lib.modules import rd_filter as _rd_filter
			_before = len(direct)
			direct, _removed = _rd_filter.apply_to_direct_list(direct)
			if _removed:
				log_utils.log(
					'sources: RD2026 filter v%s removed %d of %d direct items '
					'(AIOStreams/MediaFusion via RD)' % (_rd_filter.RD_FILTER_VERSION, _removed, _before),
					level=log_utils.LOGDEBUG)
		except Exception:
			log_utils.error()
		# ── end RD 2026 filter ────────────────────────────────────────────
		from copy import deepcopy
		deepcopy_sources = deepcopy(self.sources)
		deepcopy_sources = [i for i in deepcopy_sources if 'magnet:' in i['url']]
		if deepcopy_sources: hashList = [i['hash'] for i in deepcopy_sources]
		threads = [] ; self.filter = []
		valid_hosters = set([i['source'] for i in self.sources if 'magnet:' not in i['url']])

		def checkStatus(function, debrid_name, valid_hoster):
			try:
				cached = None
				if deepcopy_sources: cached = function(deepcopy_sources, hashList)
				if cached: self.filter += [dict(list(i.items()) + [('debrid', debrid_name)]) for i in cached] # this makes a new instance so no need for deepcopy beyond the one time done now
				if valid_hoster: self.filter += [dict(list(i.items()) + [('debrid', debrid_name)]) for i in self.sources if i['source'] in valid_hoster and 'magnet:' not in i['url']]
			except: log_utils.error()
		for d in self.debrid_resolvers:
			if d.name == 'Real-Debrid' and getSetting('realdebrid.enable') == 'true':
				try:
					valid_hoster = [i for i in valid_hosters if d.valid_url(i)]
					i = Thread(name=d.name.upper(), target=checkStatus, args=(self.rd_cache_chk_list, d.name, valid_hoster), daemon=True)
					threads.append(i)
					i.start()
				except: log_utils.error()
			if d.name == 'Premiumize.me' and getSetting('premiumize.enable') == 'true':
				try:
					valid_hoster = [i for i in valid_hosters if d.valid_url(i)]
					i = Thread(name=d.name.upper(), target=checkStatus, args=(self.pm_cache_chk_list, d.name, valid_hoster), daemon=True)
					threads.append(i)
					i.start()
				except: log_utils.error()
			if d.name == 'AllDebrid' and getSetting('alldebrid.enable') == 'true':
				try:
					valid_hoster = [i for i in valid_hosters if d.valid_url(i)]
					i = Thread(name=d.name.upper(), target=checkStatus, args=(self.ad_cache_chk_list, d.name, valid_hoster), daemon=True)
					threads.append(i)
					i.start()
				except: log_utils.error()
			if d.name == 'TorBox' and getSetting('torbox.enable') == 'true':
				try:
					valid_hoster = []
					i = Thread(name=d.name.upper(), target=checkStatus, args=(self.tb_cache_chk_list, d.name, valid_hoster), daemon=True)
					threads.append(i)
					i.start()
				except: log_utils.error()
			if d.name == 'Offcloud' and getSetting('offcloud.enable') == 'true':
				try:
					valid_hoster = [] # v2.0.20: Offcloud entra solo por torrents cacheados
					i = Thread(name=d.name.upper(), target=checkStatus, args=(self.oc_cache_chk_list, d.name, valid_hoster), daemon=True)
					threads.append(i)
					i.start()
				except: log_utils.error()
		if threads:
#			[i.start() for i in threads]
			if self.progressDialog:
				control.hide()
				sdc = control.getSourceHighlightColor()
				string2 = '[B][COLOR %s]Time elapsed[/COLOR]:  [COLOR %s]%s seconds[/COLOR][/B]' % (self.highlight_color, sdc, '%s')
				string3 = '[B][COLOR %s]Remaining debrid[/COLOR]: [COLOR %s]%s[/COLOR][/B]' % (self.highlight_color, sdc, '%s')

				while True:
					try:
						if control.monitor.abortRequested(): return sysexit()
						try:
							if self.progressDialog.iscanceled(): break
						except: pass

						try:
							info = [i.getName() for i in threads if i.is_alive()]
							line1 = '[B][COLOR %s]Checking Debrid...[/COLOR][/B]' % self.highlight_color
							line2 = string2 % round(time() - self.start_time, 1)
							line3 = string3 % (', '.join(info))
							if not info: break
							if self.progressDialog != control.progressDialogBG: self.progressDialog.update(100, f"{line1}[CR]{line2}[CR]{line3}")
							else: self.progressDialog.update(100, line1 + '  ' + line3)
						except:
							log_utils.error()
							break
						control.sleep(25)
					except: log_utils.error()
			[i.join() for i in threads]

		# ── Usenet (NZB) integration ──────────────────────────────────────
		# Los items Usenet (source == 'usenet' CON hash) saltan el pipeline de
		# magnets de arriba. v1.0.59: se enrutan por PROVEEDOR, no por un ajuste
		# global, porque cada scraper tiene su propio debrid:
		#
		#   newznab   -> Premiumize.me o TorBox Pro (v2.0.13, ajuste
		#                newznab.debrid). Es tu indexer propio; el debrid lo
		#                descarga de Usenet. PM no tiene cache-check barato y se
		#                presentan todos; TorBox si, y marca los que ya tiene.
		#
		#   torboxnews -> RETIRADO en la v2.0.13: TorBox cerro su buscador
		#                (search-api.torbox.app) y el scraper solo podia
		#                devolver nada.
		#
		# Easynews queda fuera de todo este bloque: tambien marca source='usenet'
		# (por la skin) pero llega con direct=True y hash vacio, y entra en
		# self.filter por la lista `direct` de mas abajo. Re-etiquetarlo con un
		# debrid lo mandaria a la rama NZB de sourcesResolve y romperia la
		# reproduccion.
		try:
			_usenet_items = [i for i in self.sources
				if i.get('source') == 'usenet' and i.get('hash') and not i.get('direct')]
			# Salud Usenet: ordenar por grabs (campo 'seeders') descendente.
			# Grabs = descargas confirmadas por otros usuarios: el mejor proxy
			# de que los articulos siguen completos (no hay seeders en Usenet).
			# Sort estable: a igualdad de grabs se conserva el orden previo.
			try: _usenet_items.sort(key=lambda i: int(i.get('seeders') or 0), reverse=True)
			except Exception: pass

			_nz_items = [i for i in _usenet_items if i.get('provider') == 'newznab']
			if _nz_items:
				_nz_list, _nz_why = _newznab_resolvers()
				_nz_debrid = _nz_list[0] if _nz_list else None
				# ── newznab -> Easynews (v2.0.24, streaming NNTP propio) ──────
				# La salud ya la comprobo el scraper (health_filter): los que
				# siguen en Easynews salen como 'cached usenet' (reproducen al
				# momento); los no comprobados, como 'usenet'.
				if _nz_debrid == 'Easynews':
					_n_ok = 0
					try:
						from resources.lib.modules import usenet_easynews as _uen
						_dead = _uen.dead_keys()
					except Exception:
						_dead = set()
					if _dead:
						_before = len(_nz_items)
						_nz_items = [i for i in _nz_items if i.get('hash') not in _dead]
						if _before != len(_nz_items):
							log_utils.log('Usenet (newznab -> Easynews NNTP): %d releases hidden (removed from Easynews)'
								% (_before - len(_nz_items)), level=log_utils.LOGDEBUG)
					# v2.0.37: los ya comprobados en Easynews delante de los que no (a igual
					# calidad; el orden por grabs se conserva dentro de cada grupo): el
					# primero de la lista, y el de Auto-Play, es uno que arranca
					_nz_items.sort(key=lambda i: 0 if i.get('en_health') in ('ok', 'partial') else 1)
					for _it in _nz_items:
						_new = dict(_it)
						_ok = _it.get('en_health') in ('ok', 'partial')
						_n_ok += _ok
						_new['source'] = 'cached usenet' if _ok else 'usenet'
						# v2.0.28: el motor reproduce RAR y 7z 'store'; uno comprimido lo
						# dice al abrirlo y entonces se prueba el siguiente servicio
						# activo (la cadena de resolve, como con un RAR comprimido)
						_new['debrid'] = 'Easynews'
						self.filter.append(_new)
					log_utils.log(
						'Usenet (newznab -> Easynews NNTP): %d items presented, %d verified on Easynews; fallback: %s'
						% (len(_nz_items), _n_ok, ', '.join(_nz_list[1:]) or 'none'), level=log_utils.LOGDEBUG)
				# ── newznab -> Premiumize ─────────────────────────────────────
				elif _nz_debrid == NEWZNAB_DEBRID:
					for _it in _nz_items:
						_new = dict(_it)
						_new['source'] = 'usenet'
						_new['debrid'] = NEWZNAB_DEBRID
						self.filter.append(_new)
					log_utils.log(
						'Usenet (newznab -> Premiumize): %d items presented (no cache-check; '
						'resolved on-demand via transfer/create)' % len(_nz_items),
						level=log_utils.LOGDEBUG)
				# ── newznab -> TorBox Pro (v2.0.13) ───────────────────────────
				# Se ensenan todos: los que TorBox ya tiene salen como 'cached
				# usenet' y se sirven al momento; el resto como 'usenet' y TorBox
				# los baja de Usenet al elegirlos (resolve_nzb espera con un
				# cuadro de progreso). torbox.add_only_if_cached es para torrents
				# y no se aplica: con un indexer propio casi nada esta cacheado.
				elif _nz_debrid == 'TorBox':
					from resources.lib.debrid.torbox import TorBox as _TB, nzb_hash as _nzb_hash
					_keys = [_nzb_hash(i.get('url') or '') for i in _nz_items]
					_cached = _TB().check_cache_usenet(_keys) or set()
					_n_cached = 0
					for _it, _k in zip(_nz_items, _keys):
						_new = dict(_it)
						_is_cached = _k in _cached
						_n_cached += _is_cached
						_new['source'] = 'cached usenet' if _is_cached else 'usenet'
						_new['debrid'] = 'TorBox'
						self.filter.append(_new)
					log_utils.log(
						'Usenet (newznab -> TorBox): %d items presented, %d already cached on TorBox'
						% (len(_nz_items), _n_cached), level=log_utils.LOGDEBUG)
				else:
					log_utils.log('Usenet (newznab): %d NZB items found but dropped: %s'
						% (len(_nz_items), _nz_why), level=log_utils.LOGDEBUG)
		except Exception:
			log_utils.error()
		# ── end Usenet (NZB) integration ──────────────────────────────────

		self.filter += direct # add direct links in to be considered in priority sorting
		try:
			if len(self.prem_providers) > 1: # resort for debrid/direct priorty, when more than 1 account, because of order cache check threads finish
				self.prem_providers.sort(key=lambda k: k[1])
				self.prem_providers = [i[0] for i in self.prem_providers]
				log_utils.log('self.prem_providers sort order=%s' % self.prem_providers, level=log_utils.LOGDEBUG)
				# v1.0.62: antes esto era prem_providers.index(...) directo. Cualquier
				# etiqueta que no fuese el name exacto de un resolver ('Custom' de los
				# proveedores del grupo Custom, 'Easynews', una abreviatura...) lanzaba
				# ValueError, el except de abajo se lo tragaba y se perdia EN SILENCIO
				# TODO el orden por prioridad, no solo el item culpable. Ahora lo
				# desconocido va al final y el resto conserva su prioridad.
				_unknown_rank = len(self.prem_providers)
				def _prem_rank(k):
					try:
						return self.prem_providers.index(k['debrid'] if k.get('debrid', '') else k['provider'])
					except ValueError:
						return _unknown_rank
				self.filter.sort(key=_prem_rank)
		except: log_utils.error()

		self.filter += local # library and video scraper sources
		self.sources = self.filter

		if getSetting('sources.group.sort') == '1':
			torr_filter = []
			torr_filter += [i for i in self.sources if 'torrent' in i['source'] or 'usenet' in i['source']]  #torrents and usenet first
			if getSetting('sources.size.sort') == 'true': torr_filter.sort(key=lambda k: round(k.get('size', 0)), reverse=True)
			aact_filter = []
			aact_filter += [i for i in self.sources if i['direct'] == True]  #account scrapers and local/library next
			if getSetting('sources.size.sort') == 'true': aact_filter.sort(key=lambda k: round(k.get('size', 0)), reverse=True)
			prem_filter = []
			prem_filter += [i for i in self.sources if 'torrent' not in i['source'] and 'usenet' not in i['source'] and i['debridonly'] is True]  #prem.hosters last
			if getSetting('sources.size.sort') == 'true': prem_filter.sort(key=lambda k: round(k.get('size', 0)), reverse=True)
			self.sources = torr_filter
			self.sources += aact_filter
			self.sources += prem_filter
		elif getSetting('sources.size.sort') == 'true':
			reverse_sort = True if getSetting('sources.sizeSort.reverse') == 'false' else False
			self.sources.sort(key=lambda k: round(k.get('size', 0), 2), reverse=reverse_sort)

		if getSetting('sources.provider.mix') == 'true':
			try: max_per = int(getSetting('sources.provider.mix.max'))
			except: max_per = 12
			try: top_n = int(getSetting('sources.provider.mix.top'))
			except: top_n = 120
			self.sources = self.mix_by_provider(self.sources, top_n=top_n, max_per_provider=max_per)

		if getSetting('source.prioritize.hevc') == 'true': # filter to place HEVC sources first
			filter = []
			filter += [i for i in self.sources if 'HEVC' in i.get('info', '')]
			filter += [i for i in self.sources if i not in filter]
			self.sources = filter

		if getSetting('source.prioritize.hdrdv') == 'true': # filter to place HDR and DOLBY-VISION sources first
			filter = []
			filter += [i for i in self.sources if any(value in i.get('info', '') for value in (' HDR ', 'DOLBY-VISION'))]
			filter += [i for i in self.sources if i not in filter]
			self.sources = filter

		self.sources = self.sort_byQuality(source_list=self.sources)

		filter = [] # filter to place cloud files first
		filter += [i for i in self.sources if i['source'] == 'cloud']
		filter += [i for i in self.sources if i not in filter]
		self.sources = filter

		self.sources = self.sources[:4000]
		control.hide()
		return self.sources

	def _episode_title_check(self):
		"""v2.0.37: fuera los releases que dicen ser otro episodio de la temporada
		por su titulo (source_utils.episode_title_filter). Los titulos salen de la
		temporada de TMDb ya guardada en cache (la misma lista de episodios que se
		acaba de ver); con la numeracion de TheTVDB distinta, tambien su temporada."""
		try:
			ec = getattr(self, '_ep_check', None) or {}
			tmdb = ec.get('tmdb') or (getattr(self, 'meta', None) or {}).get('tmdb') or getattr(self, 'tmdb', None)
			season, episode, title = ec.get('season'), ec.get('episode'), ec.get('title')
			if not tmdb or not season or not episode or not title: return
			from resources.lib.indexers.tmdb import TVshows as tmdb_indexer
			from resources.lib.database import cache as _cache
			from resources.lib.modules.source_utils import episode_title_filter
			seasons = [int(season)]
			alt = re.match(r'S(\d+)E\d+', str(getattr(self, 'alt_hdlr', '') or ''), re.I)
			if alt and int(alt.group(1)) not in seasons: seasons.append(int(alt.group(1)))
			others, tm = [], tmdb_indexer()
			for snum in seasons:
				meta = _cache.get(tm.get_seasonEpisodes_meta, 96, tmdb, snum) or {}
				for ep in (meta.get('episodes') if isinstance(meta, dict) else None) or []:
					if snum == int(season) and str(ep.get('episode')) == str(episode): continue
					if ep.get('title'): others.append(ep['title'])
			kept, gone = episode_title_filter(self.sources, title, others, getattr(self, 'tvshowtitle', '') or '')
			if gone:
				self.sources = kept
				log_utils.log('Episode title check (%s S%02dE%02d "%s"): %d release(s) of another episode removed: %s'
							  % (getattr(self, 'tvshowtitle', ''), int(season), int(episode), title, len(gone),
								 ', '.join(gone[:4])), level=log_utils.LOGINFO)
		except Exception:
			log_utils.error()

	def filter_dupes(self):
		filter = []
		append = filter.append
		log_dupes = getSetting('remove.duplicates.logging') == 'false'
		# Claves de deduplicacion de fuentes directas de Meteor:
		# 1) videoSize exacto en bytes (mismo archivo = mismo size)
		# 2) nombre normalizado sin extension como fallback
		# Si un torrent de otro scraper coincide con alguna, se descarta
		# porque Meteor ya lo tiene resuelto como URL directa.
		_meteor_sizes = set()
		_meteor_names = set()
		for _m in self.sources:
			if _m.get('provider') == 'meteor' and _m.get('direct') is True:
				_sz = _m.get('size') or 0
				if _sz > 0: _meteor_sizes.add(round(_sz, 2))
				_nm = re.sub(r'\.[a-z0-9]{2,4}$', '', _m['name'].lower())
				_meteor_names.add(_nm)
		# v2.0.26: misma regla que antes, pero la URL de cada fuente ya guardada se
		# pasa a minusculas UNA vez (lista paralela `low`) en vez de en cada
		# comparacion: con 800 fuentes eran ~320.000 lower() y en la Shield se notaba.
		low = []
		for i in self.sources:
			larger = False
			a = i['url'].lower()
			# Saltar torrents de otros scrapers que Meteor ya cubre con URL directa
			if i.get('provider') != 'meteor' and (_meteor_sizes or _meteor_names):
				_isz = round(i.get('size') or 0, 2)
				_inm = re.sub(r'\.[a-z0-9]{2,4}$', '', i['name'].lower())
				if (_meteor_sizes and _isz > 0 and _isz in _meteor_sizes) or (_meteor_names and _inm in _meteor_names):
					if log_dupes: log_utils.log('Removing %s - %s (METEOR DIRECT COVERS)' % (i['provider'], i['name']), level=log_utils.LOGDEBUG)
					continue
			is_magnet = 'magnet:' in a
			h = None
			if is_magnet:
				try: h = i['hash'].lower()
				except Exception: h = None # antes fallaba en cada comparacion y la fuente se quedaba
			if i.get('source') != 'cloud' and (h or not is_magnet):
				for idx in range(len(filter)):
					try:
						b = low[idx]
						if is_magnet:
							if h in b:
								sublist = filter[idx]
								if sublist['provider'] == 'torrentio' or (len(sublist['name']) > len(i['name']) and i['provider'] != 'torrentio'): # favor "torrentio" or keep matching hash with longer name for possible more info
									larger = True
									break
								del filter[idx] ; del low[idx]
								if log_dupes: log_utils.log('Removing %s - %s (DUPLICATE TORRENT) ALREADY IN :: %s' % (sublist['provider'], b, i['provider']), level=log_utils.LOGDEBUG)
								break
						elif a == b:
							sublist = filter[idx]
							del filter[idx] ; del low[idx]
							if log_dupes: log_utils.log('Removing %s - %s (DUPLICATE LINK) ALREADY IN :: %s' % (sublist['source'], i['url'], i['provider']), level=log_utils.LOGDEBUG)
							break
					except: log_utils.error('Error filter_dupes: ')
			if not larger: # sublist['name'] len() was larger, or "torrentio" so do not append
				append(i) ; low.append(a)
		item_title = homeWindow.getProperty(self.labelProperty)
#		if self.mediatype == 'movie' or (self.mediatype == 'episode' and not self.enable_playnext):
#			control.notification(title=item_title, message='Removed %s duplicate sources from list' % (len(self.sources) - len(filter)))
		log_utils.log('Removed %s duplicate sources for (%s) from list' % (len(self.sources) - len(filter), item_title), level=log_utils.LOGDEBUG)
		return filter

	def sourcesAutoPlay(self, items, keep_quality=False):
		# v2.0.05 -- fuera el colchon fijo de 2 s antes del siguiente episodio
		# con TorBox (v1.0.17). Desde su v9 (1-jul-2026) createtorrent admite
		# 300/min para cacheados, y si aun asi salta COOLDOWN_LIMIT, resolve_magnet
		# ya reintenta con espera.
		# SMART AUTOPLAY SORTING:
		# A light scoring pass that helps pick the "best" source first.
		# This preserves existing group/quality ordering but nudges higher-quality
		# audio/HDR and better-seeded torrents to the top.
		try:
			items = self._smart_autoplay_sort(items)
		except:
			pass
		# v1.0.90: continuidad de fuente al encadenar episodios (binge.py).
		# Solo actua si el lanzamiento viene del dialogo de siguiente episodio.
		try:
			from resources.lib.modules import binge
			items = binge.reorder(items, imdb=getattr(self, 'imdb', ''), tmdb=getattr(self, 'tmdb', ''))
		except Exception:
			pass
		# v2.0.14: la resolucion elegida en el asistente manda sobre "Autoplay SD Quality only"
		if getSetting('autoplay.sd') == 'true' and not keep_quality: items = [i for i in items if not i['quality'] in ('4K', '1080p', '720p')]
		header = homeWindow.getProperty(self.labelProperty) + ': Resolving...'
		try:
			if getSetting('progress.dialog') == '0':
				self.progressDialog = self.getSourceProgress(header, self.meta)
			else: raise Exception()
		except:
			homeWindow.clearProperty('luc_kodi.source_progress_is_alive')
			self.progressDialog = control.progressDialogBG
			self.progressDialog.create(header, '')
		# v1.0.65: `url` se inicializa aqui. El `return url` del final leia una
		# variable que solo existia si algun resolve() habia llegado a asignarla,
		# y el pre-flight anade caminos nuevos de descarte.
		url = None
		# v1.0.65: `played_url` solo se asigna cuando una fuente supera TODAS las
		# comprobaciones. Antes se devolvia `url`, que al agotarse la lista seguia
		# conteniendo el ultimo enlace RECHAZADO — el llamador (play(), que trata
		# None como "sin fuentes") recibia asi un enlace que el propio bucle acababa
		# de descartar por no reproducible. Con el pre-flight hay mas caminos de
		# descarte, asi que el fallo pasaba de raro a probable.
		played_url = None
		# Tope de fuentes descartadas por lentas. Sin el, una linea que va mal
		# esa tarde tumbaria la lista entera y no se reproduciria nada: a partir
		# del cuarto descarte se acepta la siguiente aunque no de la holgura.
		_slow_skips, _MAX_SLOW_SKIPS = 0, 3
		_en_tail_fails = 0
		if not getattr(self, '_play_token', None):
			self._play_token = _claim_play()
		for i in range(len(items)):
			if _superseded(self._play_token):
				log_utils.log('[ luc_kodi ] a newer playback was started: autoplay stops here', level=log_utils.LOGINFO)
				break
			try:
				src_provider = items[i]['debrid'] if items[i].get('debrid') else ('%s - %s' % (items[i]['source'], items[i]['provider']))
				label = '[B][COLOR %s]%s[CR]%s[CR]%s[/COLOR][/B]' % (self.highlight_color, src_provider.upper(), items[i]['info'][:40], items[i]['name'][:40]) # using "[CR]" has some weird delay with progressDialog.update() at times
				control.sleep(100)
				try:
					if self.progressDialog == control.progressDialogBG and self.progressDialog.iscanceled(): break
					self.progressDialog.update(int((100 / float(len(items))) * i), label)
				except: self.progressDialog.update(int((100 / float(len(items))) * i), '[COLOR %s]Resolving...[/COLOR]%s' % (self.highlight_color, items[i]['name']))
				try:
					if control.monitor.abortRequested(): return sysexit()
					url = self.sourcesResolve(items[i])
					# v1.0.17 FIX: explicit early-continue when resolve returned None.
					# Previously the code fell through to `url.lower()` which raised
					# AttributeError and was silently swallowed by the outer `except: pass`,
					# hiding TorBox cooldown failures from the log.
					if not url:
						self._ranker_resolve_miss(items[i])
						continue
					# Optional URL validity check (skip dead links / HTML error pages)
					try:
						if url and getSetting('validate.source.urls') == 'true':
							from resources.lib.modules import urlcheck
							if not urlcheck.check_url_validity(url):
								log_utils.log('Rejected invalid URL (sourcesAutoPlay): %s' % fs_client.scrub_url(url), level=log_utils.LOGWARNING)
								self._ranker_resolve_miss(items[i])
								continue
					except Exception:
						pass

					item = items[i]
					is_aiostreams_direct = item.get('aiostreams_direct') or (item.get('provider') == 'aiostreams' and item.get('direct') is True)
					if (not any(x in url.lower() for x in video_extensions) and '/dld/' not in url) and not is_aiostreams_direct:
						log_utils.log('Playback not supported for (sourcesAutoPlay()): %s' % fs_client.scrub_url(url), level=log_utils.LOGWARNING)
						self._ranker_resolve_miss(items[i])
						continue

					# ── Pre-flight del enlace resuelto (v1.0.65) ──────────────
					# Mide el enlace ANTES de entregarlo al reproductor: si esta
					# muerto se descarta, y si el CDN no sirve el ancho de banda
					# que exige el bitrate del fichero se pasa a la siguiente en
					# vez de dejar al usuario bufereando a los veinte segundos.
					# El resultado alimenta al ranker con el host que de verdad
					# funciona en esta conexion.
					_pf, _pf_drop, _pf_head, _pf_bytes = None, '', None, 0
					try:
						from resources.lib.modules import preflight
						if preflight.enabled():
							_pf = preflight.evaluate(url, item, self.meta)
							_pf_head = _pf.pop('head', None)
							_pf_bytes = _pf.get('file_bytes') or 0
							preflight.log(_pf)
							_verdict = _pf.get('verdict')
							if _verdict == 'dead':
								_pf_drop = _pf.get('reason') or 'dead'
								if _pf_drop == 'sample':
									control.notification(message=control.lang(40559) % _mmss(_pf.get('file_secs')), time=5000)
							elif (_verdict == 'slow' and preflight.skip_mode()
									and _slow_skips < _MAX_SLOW_SKIPS
									and i < (len(items) - 1)):
								_pf_drop = 'slow'
								_slow_skips += 1
							# v2.0.27: VC-1 on a device that shows it as noise (see
							# preflight.vc1_trouble): the next source, if there is one.
							if not _pf_drop and _pf.get('vc1') and i < (len(items) - 1):
								_pf_drop = 'vc1'
								control.notification(message=control.lang(40560), time=5000)
							# v2.0.27: Easynews web search, el final del fichero
							# (ver preflight.easynews_tail).
							if not _pf_drop and preflight.is_easynews_web(url):
								if _en_tail_fails >= EASYNEWS_TAIL_STREAK:
									_pf_drop = 'easynews_tail'   # Easynews web no contesta ahora: no se prueban mas
								elif not preflight.easynews_tail(url, _pf_bytes)[0]:
									_pf_drop = 'easynews_tail'
									_en_tail_fails += 1
									if _en_tail_fails == EASYNEWS_TAIL_STREAK:
										log_utils.log('[ luc_kodi ] Easynews web: %d links in a row without the end of the file; the rest are skipped'
													  % _en_tail_fails, level=log_utils.LOGINFO)
								else:
									_en_tail_fails = 0
					except Exception:
						_pf, _pf_drop = None, ''
					if _pf_drop:
						try:
							from resources.lib.database import source_ranker
							source_ranker.record_failure(item, resolved_url=url, reason=_pf_drop)
						except Exception:
							pass
						continue

					# ── Sonda de audio (v1.0.89) ──────────────────────────
					# En autoplay las pistas se cuelgan de la ventana que ya
					# anuncia la fuente, en vez de sacar una notificacion
					# mas encima. Solo el aviso de idioma que falta va aparte.
					_ap_label = ''
					try:
						from resources.lib.modules import audio_probe
						if url and audio_probe.enabled():
							_ap_label = audio_probe.announce(
								audio_probe.after_resolve(url, item, self.meta, head=_pf_head, file_bytes=_pf_bytes),
								autoplay_label=True)
					except Exception:
						_ap_label = ''
					_pf_head = None

					if url and _superseded(self._play_token):
						log_utils.log('[ luc_kodi ] a newer playback was started: this source is not played', level=log_utils.LOGINFO)
						url = None
						break
					if url:
						log_utils.log('Playing url from (sourcesAutoPlay()): %s' % fs_client.scrub_url(url), level=log_utils.LOGDEBUG)
						try:
							_q    = items[i].get('quality') or 'SD'
							_deb  = items[i].get('debrid') or ''
							_prov = items[i].get('provider') or items[i].get('source') or ''
							_src_label = ('%s  ·  %s' % (_deb.upper(), _prov.upper())) if _deb else _prov.upper()
							# v1.0.65: si el pre-flight midio el enlace, se muestra
							# el throughput real. Es la prueba visible de que la
							# comprobacion ha ocurrido.
							try:
								if _pf and _pf.get('measured_mbps'):
									_src_label += '  ·  [COLOR FF00FA9A]%d Mbps[/COLOR]' % int(_pf['measured_mbps'])
							except Exception:
								pass
							if _ap_label:
								_src_label += '  ·  %s' % _ap_label
							from resources.lib.windows.display_welcome import DisplayWelcomeXML
							from resources.lib.modules.control import addonPath, addonId, addonIcon
							import threading
							def _show_autoplay_notif():
								try:
									win = DisplayWelcomeXML(
										'autoplay_notif.xml',
										addonPath(addonId()),
										'Default',
										line1='Auto-Play  [COLOR FF00FA9A]%s[/COLOR]' % _q,
										line2=_src_label,
										icon=addonIcon(),
										duration=5
									)
									win.show_and_close(duration=5)
									del win
								except: pass
							threading.Thread(target=_show_autoplay_notif, daemon=True).start()
						except: pass
						# ── Personal ranker: registrar la elegida ──
						# v2.0.21: items[0:i] no los salto el usuario, no
						# resolvieron (o los quito el pre-flight, que ya registra
						# su fallo). Ya se apuntaron uno a uno con
						# _ranker_resolve_miss, solo contra su scraper y su debrid,
						# asi que aqui no se vuelven a contar.
						try:
							from resources.lib.database import source_ranker
							source_ranker.record_choice(items[i], all_items=None, resolved_url=url,
								title_key=self._ranker_title_key(), autoplay=True)
						except Exception:
							pass
						try:
							from resources.lib.modules import binge
							binge.remember(items[i], getattr(self, 'imdb', ''), getattr(self, 'tmdb', ''),
										   getattr(self, 'season', None), getattr(self, 'episode', None))
						except Exception:
							pass
						self._arm_rollover(items[i + 1:])
						played_url = url
						break
				except: pass
			except: log_utils.error()
		if homeWindow.getProperty('luc_kodi.source_progress_is_alive') != 'true':
			try: self.progressDialog.close()
			except: pass
			del self.progressDialog
		return played_url

	

	# v1.0.78 — cache de los ajustes que gobiernan la puntuacion.
	#
	# control.setting() NO es una lectura de diccionario: hace un
	# getProperty() a la ventana de inicio y un json.loads del blob ENTERO de
	# ajustes, 441 claves y unos 13,5 KB. Medido: 53 us por llamada en x86,
	# sin contar el viaje a C, y en un aparato ARM bastante mas.
	#
	# _smart_score se ejecuta una vez POR FUENTE. Con 150 fuentes eran 450
	# lecturas —dos aqui y una dentro de score_adjustment— o sea 450 parseos
	# del mismo JSON para leer tres constantes que no pueden cambiar mientras
	# se construye una lista. Se resuelven una vez por pasada.
	def _score_settings(self):
		cached = getattr(self, '_score_cfg', None)
		if cached is None:
			try:
				weight = int(getSetting('personal.ranker.weight') or '0')
			except Exception:
				weight = 0
			cached = {'hevc': getSetting('source.prioritize.hevc') == 'true',
			          'weight': weight}
			self._score_cfg = cached
		return cached

	def _smart_score(self, it):
		"""Compute smart score for a source item (used by autoplay and source select)."""
		try:
			cfg = self._score_settings()
			from resources.lib.modules.control import getSetting
		except:
			def getSetting(_k):
				return ''
		try:
			info = (it.get('info') or '').upper()
		except:
			info = ''
		try:
			name = (it.get('name') or '').upper()
		except:
			name = ''

		def qv(q):
			return {'4K': 40, '1080p': 30, '720p': 20, 'SCR': 10, 'SD': 5, 'CAM': 1}.get(q, 0)

		s = qv(it.get('quality')) * 100

		# Prefer cached torrents over uncached
		url = (it.get('url') or '').upper()
		src = (it.get('source') or '').upper()
		if 'MAGNET:' in url:
			if 'UNCACHED' in src:
				s -= 500
			else:
				s += 200

		# HDR / Dolby Vision
		if 'DOLBY-VISION' in info or ' DOVI' in info:
			s += 60
		if ' HDR ' in info or info.startswith('HDR') or 'HDR10' in info:
			s += 50

		# Audio priorities
		if 'ATMOS' in info:
			s += 40
		if 'TRUEHD' in info:
			s += 30
		if 'DTS-HD' in info or 'DTSHD' in info or 'DTSHDMA' in info or 'DTS-HD MA' in info:
			s += 25
		if 'AAC' in info:
			s += 5

		# Prefer HEVC if setting enabled
		if cfg['hevc']:
			if 'HEVC' in info or 'H265' in info or 'H.265' in info or 'X265' in name:
				s += 20

		# Torrent health
		seed = it.get('seeders') or 0
		try:
			seed = int(seed)
		except:
			seed = 0
		s += min(seed, 500)

		# Size sanity: avoid absurdly small "fake" files
		size = it.get('size') or 0
		try:
			size = float(size)
		except:
			size = 0
		if size and size < 0.25:
			s -= 200

		# ── Personalized ranker (learned from user history) ─────────────
		# Devuelve 0 si está desactivado, hay <10 plays, o hay error.
		# El peso del setting controla cuánto puede mover el ranking.
		try:
			weight = cfg['weight']
			if weight > 0:
				from resources.lib.database import source_ranker
				adj = source_ranker.score_adjustment(it)
				if adj:
					s += adj * weight
		except Exception:
			pass

		try:
			return int(s)
		except:
			return 0

	def _ranker_title_key(self, meta=None):
		"""v2.0.21: id del titulo (y episodio) para el ranker personal."""
		try:
			m = meta or getattr(self, 'meta', None) or {}
			ident = getattr(self, 'imdb', None) or m.get('imdb') or getattr(self, 'tmdb', None) or m.get('tmdb') or ''
			season = getattr(self, 'season', None) or m.get('season') or ''
			episode = getattr(self, 'episode', None) or m.get('episode') or ''
			if not ident:
				return ''
			return '%s|%s|%s' % (ident, season, episode)
		except Exception:
			return ''

	def _ranker_resolve_miss(self, item):
		"""v2.0.21: el autoplay no pudo usar esta fuente; nunca rompe el bucle."""
		try:
			from resources.lib.database import source_ranker
			source_ranker.record_resolve_miss(item)
		except Exception:
			pass

	def _smart_autoplay_sort(self, items):
		"""Return items sorted for autoplay resolution.

		We keep existing ordering as a base (which already reflects Debrid priority
		and quality grouping from sourcesFilter), but add a scoring component to
		push better candidates earlier.
		"""
		# Stable sort: score desc, then keep original order
		return sorted(list(items), key=lambda it: self._smart_score(it), reverse=True)


	def sourcesResolve(self, item):
		try:
			url = item['url']
			self.url = None
			self.usenet_fail_reason = None
			debrid_provider = item['debrid'] if item.get('debrid') else ''
		except: log_utils.error()
		# Keep what the release claims about itself: play_source() only gets
		# the resolved URL, and a debrid link carries none of it.
		try:
			from resources.lib.modules import release_info
			release_info.remember(item)
		except Exception:
			log_utils.error()
		try: # v2.0.35: posters with badges — el release que se va a ver
			from resources.lib.modules import badge_posters
			if badge_posters.enabled(): badge_posters.record_played(getattr(self, 'mediatype', ''), getattr(self, 'tmdb', ''), item)
		except Exception: pass
		# ── TorBox 2026: usenet (NZB) resolution ──────────────────────────────
		# Usenet items carry source 'cached usenet'/'uncached usenet' and an
		# http(s) .nzb link in item['url'] (NOT a magnet). They must be resolved
		# via TorBox's /usenet/* endpoints, not the magnet or hoster branches.
		# Without this they fell through to the hoster branch (RD/PM/AD only) and
		# never produced a playable URL.
		# ── Easynews: resolver PRIMERO ────────────────────────────────────
		# v1.0.55: en la 1.0.54 se etiquetaron los items de Easynews como
		# source='usenet' para arreglar la etiqueta superpuesta de la skin.
		# Efecto colateral: caian en la rama NZB de TorBox de aqui abajo,
		# que hace `else: return` para cualquier debrid que no sea TorBox.
		# Resultado: la fuente se seleccionaba y no reproducia nada, sin
		# dejar ni una linea en el log. Easynews NO usa NZB: su URL ya es
		# el fichero. Se resuelve aqui, antes de cualquier otra rama.
		if item.get('provider') == 'easynews':
			try:
				from resources.lib.jacksparrow.sourcesdir.torrents import easynews as easynews_mod
				resolved = easynews_mod.source().resolve(url)
				if resolved:
					self.url = resolved
					# v2.0.25: Kodi baja este fichero el solo (HTTP); el player
					# estima al parar lo que gasto del plan (Tools > Usenet report)
					try:
						homeWindow.setProperty('luc_kodi.usenet.web', jsdumps({
							'url': resolved, 'title': item.get('name') or '', 'bytes': int(float(item.get('size') or 0) * 1073741824)}))
					except Exception: pass
					return resolved
			except: log_utils.error()
			# Sin credenciales validas no se devuelve la URL cruda: daria un
			# 401 y un error de reproduccion al usuario.
			return
		# ──────────────────────────────────────────────────────────────────
		if 'usenet' in item.get('source', '') and not item.get('direct'):
			try:
				meta = homeWindow.getProperty(self.metaProperty)
				if meta:
					meta = jsloads(unquote(meta.replace('%22', '\\"')))
					season, episode, title = meta.get('season'), meta.get('episode'), meta.get('title')
				else:
					season = homeWindow.getProperty(self.seasonProperty)
					episode = homeWindow.getProperty(self.episodeProperty)
					title = homeWindow.getProperty(self.titleProperty)
				# v2.0.24: cadena de servicios. Se empieza por el del item y, si
				# falla, se prueban los demas interruptores activos en el orden
				# Easynews -> Premiumize -> TorBox (solo para el indexer propio;
				# un item de otro proveedor usenet conserva su unico debrid).
				_chain = [debrid_provider]
				if item.get('provider') == 'newznab':
					_avail = _newznab_resolvers()[0]
					_chain += [d for d in _avail if d != debrid_provider]
					# v2.0.33: la salud ya vio que el motor no puede abrirlo (RAR
					# comprimido o cifrado): directo a Premiumize/TorBox
					if item.get('en_unplayable') and _chain[0] == 'Easynews' and len(_chain) > 1:
						log_utils.log('USENET: %s goes straight to %s (%s)' % (item.get('name'), _chain[1], item.get('en_unplayable')),
									  level=log_utils.LOGINFO)
						_chain = _chain[1:]
				for _n, _svc in enumerate(_chain):
					_res = None
					if _svc == 'Easynews':
						from resources.lib.modules import usenet_easynews
						try:   # v2.0.32 (informe N3): la duracion real, para la lectura anticipada
							from resources.lib.modules.preflight import _duration_of
							_rt = _duration_of(getattr(self, 'meta', None))
						except Exception:
							_rt = None
						_res, _why = usenet_easynews.resolve(item, runtime=_rt, season=season, episode=episode)
						self.usenet_fail_reason = None if _res else _why
						if not _res:
							log_utils.log('USENET: Easynews could not stream %s: %s' % (item.get('name'), _why), level=log_utils.LOGINFO)
							if len(_chain) > _n + 1:
								control.notification(message='Easynews: %s — trying %s' % (_why, _chain[_n + 1]), group=USENET_CHAIN)
							elif not getattr(self, '_nzb_chain', False):
								control.notification(message='Easynews: %s' % _why, group=USENET_CHAIN)
					elif _svc == 'TorBox':
						from resources.lib.debrid.torbox import TorBox as debrid_function
						_res = debrid_function().resolve_nzb(url, item.get('hash'), season, episode, title)
					elif _svc == 'Premiumize.me':
						# Premiumize no tiene ruta instantanea para NZB: resolve_nzb()
						# sube el .nzb a /transfer/create y espera a que PM lo baje de
						# Usenet a su nube antes de devolver el link reproducible.
						from resources.lib.debrid.premiumize import Premiumize as debrid_function
						_res = debrid_function().resolve_nzb(url, item.get('hash'), season, episode, title)
					if _res:
						self.url = _res
						return _res
					# Premiumize/TorBox ya esperan (y se pueden cancelar) dentro de
					# su resolve_nzb: tras ellos no se encadena otro servicio.
					if _svc != 'Easynews':
						break
				return
			except:
				log_utils.error()
				return
		if 'magnet:' in url:
			if not 'uncached' in item['source']:
				try:
					meta = homeWindow.getProperty(self.metaProperty) # need for CM "download" action
					if meta:
						meta = jsloads(unquote(meta.replace('%22', '\\"')))
						season, episode, title = meta.get('season'), meta.get('episode'), meta.get('title')
					else:
						season = homeWindow.getProperty(self.seasonProperty)
						episode = homeWindow.getProperty(self.episodeProperty)
						title = homeWindow.getProperty(self.titleProperty)
					# v2.0.08: langhelper trae releases numeradas a su manera ("45. Bolum",
					# "EP05", absolutas). Un episodio suelto es un torrent de un solo episodio:
					# se pide sin temporada y el debrid se queda con el fichero mayor. En un
					# pack se busca el fichero con la numeracion de la propia release.
					_lang_alt = None
					homeWindow.clearProperty('luc_kodi.lang_ep_numbers') # nunca de una resolucion anterior
					if item.get('provider') == 'langhelper' and season:
						if item.get('package'):
							season, episode = item.get('lang_season') or season, item.get('lang_ep') or episode
							_lang_alt = item.get('lang_ep_alt')
							# v2.0.08: los dos numeros (temporada y absoluto) para que el debrid
							# pueda buscar "054.mkv" si no hay SxxEyy dentro del pack
							homeWindow.setProperty('luc_kodi.lang_ep_numbers', '|'.join(str(x) for x in (episode, _lang_alt) if x))
						else: season = episode = None
					if debrid_provider == 'Real-Debrid':
						from resources.lib.debrid.realdebrid import RealDebrid as debrid_function
					elif debrid_provider == 'Premiumize.me':
						from resources.lib.debrid.premiumize import Premiumize as debrid_function
					elif debrid_provider == 'AllDebrid':
						from resources.lib.debrid.alldebrid import AllDebrid as debrid_function
					elif debrid_provider == 'TorBox':
						from resources.lib.debrid.torbox import TorBox as debrid_function
					elif debrid_provider == 'Offcloud':
						from resources.lib.debrid.offcloud import Offcloud as debrid_function
					else:
						homeWindow.clearProperty('luc_kodi.lang_ep_numbers')
						return
					try:
						_magnet = url
						url = debrid_function().resolve_magnet(url, item['hash'], season, episode, title)
						# v2.0.08: pack de langhelper sin SxxEyy con el numero de la temporada:
						# segundo intento con el absoluto (o al reves)
						if not url and _lang_alt and str(_lang_alt) != str(episode):
							url = debrid_function().resolve_magnet(_magnet, item['hash'], season, _lang_alt, title)
					finally:
						homeWindow.clearProperty('luc_kodi.lang_ep_numbers')
					self.url = url
					return url
				except:
					log_utils.error()
					return
		else:
			try:
				direct = item['direct']
				if direct:
					# Scrapers estilo Stremio (Sootio, Torz custom, etc.) entregan
					# URLs "lazy" /resolve/ o /v0/store/... que NO son archivos de
					# vídeo: hay que pedirlas para que el servidor redirija al
					# enlace directo. Cada scraper resuelve lo suyo de forma
					# AUTÓNOMA (su token lleva embebidas las credenciales del debrid).
					if item.get('provider') == 'torz':
						# Torz en modo custom (StremThru con store/debrid embebido):
						# resolve() sigue el redirect del propio StremThru. Si la URL
						# ya es un archivo directo, resolve() la devuelve tal cual.
						try:
							from resources.lib.jacksparrow.sourcesdir.torrents import torz as torz_mod
							resolved = torz_mod.source().resolve(url)
							if resolved:
								self.url = resolved
								return resolved
						except: log_utils.error()
						# Si no se pudo resolver una URL lazy de StremThru, no la
						# devolvemos cruda: None para que el autoplay pase al siguiente.
						_torz_lazy = ('/v0/store/', '/resolve/', '/strem/', '/playback/', '/link/')
						if any(_mk in url for _mk in _torz_lazy):
							return
						# URL ya directa: reproducir tal cual.
						self.url = url
						return url
					if item.get('provider') == 'comet':
						# Comet en modo custom (debrid embebido en el config):
						# resolve() sigue el redirect 302 del endpoint /playback/
						# de Comet hacia el CDN del debrid. Si la URL ya es un
						# archivo directo, resolve() la devuelve tal cual.
						try:
							from resources.lib.jacksparrow.sourcesdir.torrents import comet as comet_mod
							resolved = comet_mod.source().resolve(url)
							if resolved:
								self.url = resolved
								return resolved
						except: log_utils.error()
						# Si no se pudo resolver una URL lazy de Comet, no la
						# devolvemos cruda: None para que el autoplay pase al siguiente.
						_comet_lazy = ('/playback/', '/resolve/', '/strem/', '/link/', '/download/')
						if any(_mk in url for _mk in _comet_lazy):
							return
						# URL ya directa: reproducir tal cual.
						self.url = url
						return url
					if item.get('provider') == 'meteor':
						# v1.0.65: Meteor devuelve /<config>/play/<hash>/<idx>,
						# un redirect 302 al CDN del debrid. Sin esta rama la URL
						# llegaba cruda a playItem() y se descartaba con
						# "Playback not supported".
						try:
							from resources.lib.jacksparrow.sourcesdir.torrents import meteor as meteor_mod
							resolved = meteor_mod.source().resolve(url)
							if resolved:
								self.url = resolved
								return resolved
						except: log_utils.error()
						_mt_lazy = ('/play/', '/playback/', '/resolve/', '/strem/', '/link/', '/download/')
						if any(_mk in url for _mk in _mt_lazy):
							return
						self.url = url
						return url
					if item.get('provider') == 'mediafusion':
						# MediaFusion devuelve /playback/<Provider>/<hash>/...
						# que es un redirect 302 al CDN del debrid, con la
						# misma forma que el /playback/ de Comet. resolve()
						# sigue el redirect; si la URL ya es un archivo
						# directo, la devuelve tal cual.
						try:
							from resources.lib.jacksparrow.sourcesdir.torrents import mediafusion as mediafusion_mod
							resolved = mediafusion_mod.source().resolve(url)
							if resolved:
								self.url = resolved
								return resolved
						except: log_utils.error()
						# Si no se pudo resolver una URL lazy de MediaFusion, no la
						# devolvemos cruda: None para que el autoplay pase al siguiente.
						_mf_lazy = ('/playback/', '/resolve/', '/strem/', '/link/', '/download/')
						if any(_mk in url for _mk in _mf_lazy):
							return
						# URL ya directa: reproducir tal cual.
						self.url = url
						return url
					if item.get('provider') == 'sootio' or '/resolve/' in url:
						try:
							from resources.lib.jacksparrow.sourcesdir.torrents import sootio as sootio_mod
							resolved = sootio_mod.source().resolve(url)
							if resolved:
								self.url = resolved
								return resolved
						except: log_utils.error()
						# Si no se pudo resolver, NO devolvemos la URL /resolve/
						# cruda (daría "Playback not supported"): None para que el
						# siguiente source del autoplay tome el relevo.
						if '/resolve/' in url:
							return
					if item.get('provider') == 'aiostreams':
						# v1.0.63: AIOStreams entregaba la URL cruda al reproductor
						# (is_aiostreams_direct), y en el log del 21-ago-2026 esa URL
						# era el proxy de una instancia comunitaria de StremThru: la
						# pelicula entera por un servidor compartido en vez del CDN.
						# Su resolve() sigue el 302 hasta el CDN.
						try:
							from resources.lib.jacksparrow.sourcesdir.torrents import aiostreams as aiostreams_mod
							resolved = aiostreams_mod.source().resolve(url)
							if resolved:
								self.url = resolved
								return resolved
						except: log_utils.error()
						# A DIFERENCIA del resto: la URL cruda de AIOStreams SI es
						# reproducible, asi que no se devuelve None. Perder la fuente
						# seria peor regresion que el lag que estamos quitando.
						self.url = url
						return url
					direct_sources = ('ad_cloud', 'oc_cloud', 'pm_cloud', 'rd_cloud', 'tb_cloud')
					if item['provider'] in direct_sources:
						try:
							call = [i[1] for i in self.sourceDict if i[0] == item['provider']][0]
							url = call().resolve(url)
							self.url = url
							return url
						except: pass
					else:
						self.url = url
						return url
				else: # hosters
					if debrid_provider == 'Real-Debrid':
						from resources.lib.debrid.realdebrid import RealDebrid as debrid_function
					elif debrid_provider == 'Premiumize.me':
						from resources.lib.debrid.premiumize import Premiumize as debrid_function
					elif debrid_provider == 'AllDebrid':
						from resources.lib.debrid.alldebrid import AllDebrid as debrid_function
					url = debrid_function().unrestrict_link(url)
					self.url = url
					return url
			except:
				log_utils.error()
				return

	def debridPackDialog(self, provider, name, magnet_url, info_hash):
		try:
			if provider in ('Real-Debrid', 'RD'):
				from resources.lib.debrid.realdebrid import RealDebrid as debrid_function
			elif provider in ('Premiumize.me', 'PM'):
				from resources.lib.debrid.premiumize import Premiumize as debrid_function
			elif provider in ('AllDebrid', 'AD'):
				from resources.lib.debrid.alldebrid import AllDebrid as debrid_function
			elif provider in ('TorBox', 'TB'):
				from resources.lib.debrid.torbox import TorBox as debrid_function
			elif provider in ('Offcloud', 'OC', 'OFFCLOUD'):
				from resources.lib.debrid.offcloud import Offcloud as debrid_function
			else: return
			debrid_files = None
			control.busy()
			try: debrid_files = debrid_function().display_magnet_pack(magnet_url, info_hash)
			except: pass
			if not debrid_files:
				control.hide()
				return control.notification(message=32399)
			debrid_files = sorted(debrid_files, key=lambda k: k['filename'].lower())
			display_list = ['%02d | [B]%.2f GB[/B] | [I]%s[/I]' % (count, i['size'], i['filename'].upper()) for count, i in enumerate(debrid_files, 1)]
			control.hide()
			chosen = control.selectDialog(display_list, heading=name)
			if chosen < 0: return None
			if control.condVisibility("Window.IsActive(source_results.xml)"): # close "source_results.xml" here after selection is made and valid
				control.closeAll()
			control.busy()
			chosen_result = debrid_files[chosen]
			if provider in ('Real-Debrid', 'RD'):
				self.url = debrid_function().unrestrict_link(chosen_result['link'])
			elif provider in ('Premiumize.me', 'PM'):
				self.url = debrid_function().add_headers_to_url(chosen_result['link'])
			elif provider in ('AllDebrid', 'AD'):
				self.url = debrid_function().unrestrict_link(chosen_result['link'])
			elif provider in ('TorBox', 'TB'):
				self.url = debrid_function().unrestrict_link(chosen_result['link'])
			elif provider in ('Offcloud', 'OC', 'OFFCLOUD'):
				self.url = chosen_result['link'] # ya es el fichero
			from resources.lib.modules import player
			meta = jsloads(unquote(homeWindow.getProperty(self.metaProperty).replace('%22', '\\"'))) # needed for CM "showDebridPack" action
			title = meta['tvshowtitle']
			year = meta['year'] if 'year' in meta else None
			season = meta['season'] if 'season' in meta else None
			episode = meta['episode'] if 'episode' in meta else None
			imdb = meta['imdb'] if 'imdb' in meta else None
			tmdb = meta['tmdb'] if 'tmdb' in meta else None
			tvdb = meta['tvdb'] if 'tvdb' in meta else None
			release_title = chosen_result['filename']
			control.hide()
			from resources.lib.modules import source_utils
			if source_utils.seas_ep_filter(season, episode, release_title):
				return player.Player().play_source(title, year, season, episode, imdb, tmdb, tvdb, self.url, meta, debridPackCall=True) # hack fix for setResolvedUrl issue
			else:
				return player.Player().play(self.url)
		except:
			log_utils.error('Error debridPackDialog: ')
			control.hide()

	def sourceInfo(self, item):
		try:
			from sys import platform as sys_platform
			supported_platform = any(value in sys_platform for value in ('win32', 'linux2'))
			source = jsloads(item)[0]
			list = [('[COLOR %s]url:[/COLOR]  %s' % (self.highlight_color, source.get('url')), source.get('url'))]
			if supported_platform: list += [('[COLOR %s]  -- Copy url To Clipboard[/COLOR]' % self.highlight_color, ' ')] # "&" in magnets causes copy2clip to fail .replace('&', '^&').strip() used in copy2clip() method
			list += [('[COLOR %s]name:[/COLOR]  %s' % (self.highlight_color, source.get('name')), source.get('name'))]
			if supported_platform: list += [('[COLOR %s]  -- Copy name To Clipboard[/COLOR]' % self.highlight_color, ' ')]
			if 'magnet:' in source.get('url'):
				list += [('[COLOR %s]hash:[/COLOR]  %s' % (self.highlight_color, source.get('hash')), source.get('hash'))]
				if supported_platform: list += [('[COLOR %s]  -- Copy hash To Clipboard[/COLOR]' % self.highlight_color, ' ')]
				list += [('[COLOR %s]seeders:[/COLOR]  %s' % (self.highlight_color, source.get('seeders')), ' ')]
			list += [('[COLOR %s]info:[/COLOR]  %s' % (self.highlight_color, source.get('info')), ' ')]
			select = control.selectDialog([i[0] for i in list], 'Source Info')
			if any(x in list[select][0] for x in ('Copy url To Clipboard', 'Copy name To Clipboard', 'Copy hash To Clipboard')):
				from resources.lib.modules.source_utils import copy2clip
				copy2clip(list[select - 1][1])
			return
		except: log_utils.error('Error sourceInfo: ' )

	def alterSources(self, url, meta):
		try:
			if getSetting('play.mode') == '1' or (self.enable_playnext and 'episode' in meta): url += '&select=0'
			else: url += '&select=1'
			control.execute('PlayMedia(%s)' % url)
		except: log_utils.error()

	def errorForSources(self):
		try:
			homeWindow.clearProperty('luc_kodi.source_progress_is_alive')
			control.sleep(200)
			control.hide()
			if self.url == 'close://': control.notification(message=32400)
			else: control.notification(message=32401)
			control.cancelPlayback()
		except: log_utils.error()

	def getAliasTitles(self, imdb, content):
		try:
			if content == 'movie':
				from resources.lib.modules.trakt import getMovieAliases
				t = getMovieAliases(imdb)
			else:
				from resources.lib.modules.trakt import getTVShowAliases
				t = getTVShowAliases(imdb)
			if not t: return []
			t = [i for i in t if i.get('country', '').lower() in ('en', '', 'ca', 'us', 'uk', 'gb')]
			return t
		except:
			log_utils.error()
			return []

	def subTitle(self, tvshowtitle):
		"""
		Comprueba si 'tvshowtitle' tiene una sustitución almacenada y la devuelve.
		Usado durante el scraping para remap de títulos (ej. "Fargo" → "Fargo US").
		"""
		if tvshowtitle:
			try:
				from resources.lib.database import titlesubs
				subtvshowtitle = titlesubs.substitute_get(tvshowtitle)
				if subtvshowtitle:
					tvshowtitle = subtvshowtitle
			except:
				pass
			return tvshowtitle
		else:
			return None

	def getSubsList(self):
		"""
		Abre el diálogo de gestión de sustituciones de títulos.
		Permite al usuario ver y eliminar sustituciones guardadas.
		"""
		try:
			control.hide()
			from resources.lib.database import titlesubs
			addedSubs = titlesubs.all_substitutes(self)
			items = [{'originalTitle': i['originalTitle'], 'subTitle': i['subTitle']} for i in addedSubs]
			from resources.lib.windows.title_sublist_manager import TitleSublistManagerXML
			window = TitleSublistManagerXML('title_sublist_manager.xml', control.addonPath(control.addonId()), results=items)
			selected_items = window.run()
			if selected_items:
				self.removeSubs(selected_items)
			del window
		except:
			log_utils.error()

	def addNewSub(self):
		"""
		Solicita al usuario un par de títulos (original → sustituto) y lo guarda.
		"""
		original_title = control.dialog.input('[COLOR %s]%s[/COLOR]' % (self.highlight_color, getLS(40245)))
		if original_title:
			sub_title = control.dialog.input('[COLOR %s]%s[/COLOR]' % (self.highlight_color, getLS(40247)))
			if sub_title:
				from resources.lib.database import titlesubs
				titlesubs.sub_insert(original_title, sub_title)
				control.notification(message=40248)

	def removeSubs(self, items):
		"""Elimina una lista de sustituciones de la base de datos."""
		try:
			if len(items) > 0:
				for v in items:
					removeitem = str(v.get('originalTitle'))
					from resources.lib.database import titlesubs
					titlesubs.clear_substitute('substitle', removeitem)
		except:
			log_utils.error()

	def getTitle(self, title):
		title = string_tools.normalize(title)
		return title

	def getConstants(self):
		self.metaProperty = 'plugin.video.luc_kodi.container.meta'
		self.seasonProperty = 'plugin.video.luc_kodi.container.season'
		self.episodeProperty = 'plugin.video.luc_kodi.container.episode'
		self.titleProperty = 'plugin.video.luc_kodi.container.title'
		self.imdbProperty = 'plugin.video.luc_kodi.container.imdb'
		self.tmdbProperty = 'plugin.video.luc_kodi.container.tmdb'
		self.tvdbProperty = 'plugin.video.luc_kodi.container.tvdb'
		self.labelProperty = 'plugin.video.luc_kodi.container.label'


		if self.all_providers == 'true':
			self.sourceDict = fs_sources(ret_all=True)
		else:
			self.sourceDict = fs_sources()
			self.sourceDict.extend(cloudSources())

		from resources.lib.debrid import premium_hosters
		self.debrid_resolvers = debrid.debrid_resolvers()

		self.prem_providers = [] # for sorting by debrid and direct source links priority
		# v1.0.52: esta línea era código muerto (los ajustes easynews.* no
		# existían en settings.xml) y además reventaba con ValueError si
		# alguna vez el usuario tenía usuario pero no prioridad.
		# v2.0.24: tambien cuando Easynews solo reproduce los NZB de Newznab (NNTP)
		_en_nntp = getSetting('provider.newznab') == 'true' and (getSetting('newznab.use_easynews') or 'true') == 'true'
		if getSetting('easynews.username') and (getSetting('provider.easynews') == 'true' or _en_nntp):
			try: _en_priority = int(getSetting('easynews.priority') or 8)
			except Exception: _en_priority = 8
			# v1.0.54: la etiqueta DEBE coincidir exactamente con item['debrid']
			# ('Easynews'). Con 'easynews' en minusculas, el sort de prioridad
			# de abajo hacia prem_providers.index('Easynews') -> ValueError,
			# y el orden por prioridad se perdia en silencio.
			self.prem_providers += [('Easynews', _en_priority)]
		self.prem_providers += [(d.name, int(d.sort_priority)) for d in self.debrid_resolvers]

		def cache_prDict():
			try:
				hosts = []
				for d in self.debrid_resolvers: hosts += d.get_hosts()[d.name]
				return list(set(hosts))
			except: return premium_hosters.hostprDict
		self.hostprDict = providerscache.get(cache_prDict, 168)

	def calc_pack_size(self):
		seasoncount, counts = None, None
		tmdb = (self.meta or {}).get('tmdb') or homeWindow.getProperty(self.tmdbProperty) # v2.0.37: lo usa el 3er recurso aunque falle el 2.o
		try:
			if self.meta: seasoncount, counts = self.meta.get('seasoncount', None), self.meta.get('counts', None)
		except: log_utils.error()
		if not seasoncount or not counts: # check metacache, 2nd fallback
			try:
				user = '' # v2.0.04: clave de la metacache de series (antes imdb.user, siempre vacio)
				meta_lang = control.apiLanguage()['tvdb']
				if self.meta: imdb, tmdb, tvdb = self.meta.get('imdb', ''), self.meta.get('tmdb', ''), self.meta.get('tvdb', '')
				else: imdb, tmdb, tvdb = homeWindow.getProperty(self.imdbProperty), homeWindow.getProperty(self.tmdbProperty), homeWindow.getProperty(self.tvdbProperty)
				ids = [{'imdb': imdb, 'tmdb': tmdb, 'tvdb': tvdb}]
				meta2 = metacache.fetch(ids, meta_lang, user)[0]
				if not seasoncount: seasoncount = meta2.get('seasoncount', None)
				if not counts: counts = meta2.get('counts', None)
			except: log_utils.error()
		if not seasoncount or not counts: # make request, 3rd fallback
			try:
				if self.meta: season = self.meta.get('season')
				else: season = homeWindow.getProperty(self.seasonProperty)
				from resources.lib.indexers import tmdb as tmdb_indexer
				counts = tmdb_indexer.TVshows().get_counts(tmdb)
				seasoncount = counts[str(season)]
			except:
				log_utils.error()
				return self.sources
		for i in self.sources:
			try:
#				if i['provider'] == 'torrentio': continue # torrentio return file size based on episode query already so bypass re-calc
				if i['provider'] in ('torrentio', 'knightcrawler', 'nyaaio', 'mediafusion'): continue
				if 'package' in i:
					dsize = i.get('size')
					if not dsize: continue
					if i['package'] == 'season':
						divider = int(seasoncount)
						if not divider: continue
					else:
						if not counts: continue
						season_count = 1 ; divider = 0
						while season_count <= int(i['last_season']):
							divider += int(counts[str(season_count)])
							season_count += 1
					float_size = float(dsize) / divider
					if round(float_size, 2) == 0: continue
					str_size = '%.2f GB' % float_size
					info = i['info']
					try: info = [i['info'].split(' / ', 1)[1]]
					except: info = []
					info.insert(0, str_size)
					info = ' / '.join(info)
					i.update({'size': float_size, 'info': info})
				else:
					continue
			except: log_utils.error()
		return self.sources

	def ad_cache_chk_list(self, torrent_List, hashList):
		if len(torrent_List) == 0: return
		try:
#			from resources.lib.debrid.alldebrid import AllDebrid
#			cached = AllDebrid().check_cache(hashList)
#			if not cached: return None
#			cached = cached['magnets']
#			count = 0
#			for i in torrent_List:
#				if 'error' in cached[count]: # list index out of range
#					count += 1
#					continue
#				if cached[count]['instant'] is False:
#					if 'package' in i: i.update({'source': 'uncached (pack) torrent'})
#					else: i.update({'source': 'uncached torrent'})
#				else:
#					if 'package' in i: i.update({'source': 'cached (pack) torrent'})
#					else: i.update({'source': 'cached torrent'})
#				count += 1
			[i.update({'source': i.get('source','torrent')}) for i in torrent_List]
			return torrent_List
		except: log_utils.error()

	def pm_cache_chk_list(self, torrent_List, hashList):
		if len(torrent_List) == 0: return
		try:
			# v2.0.26: cache por hash (scrape_planner.check): solo se pregunta a
			# Premiumize por los hashes que no se conocen, y lo ya preguntado
			# durante la busqueda (prefetch) llega aqui guardado. Lo que no
			# contesto (respuesta mas corta, v1.0.70) se queda sin etiqueta.
			from resources.lib.modules import scrape_planner as _sp
			status = _sp.check('pm', hashList)
			if not status: return None
			for i in torrent_List:
				st = status.get(_sp.norm_hash(i.get('hash')))
				if st is None: continue
				if not st[0]:
					if 'package' in i: i.update({'source': 'uncached (pack) torrent'})
					else: i.update({'source': 'uncached torrent'})
				else:
					if 'package' in i: i.update({'source': 'cached (pack) torrent'})
					else: i.update({'source': 'cached torrent'})
			return torrent_List
		except: log_utils.error()

	def rd_cache_chk_list(self, torrent_List, hashList):
		# v2.0.10: DMM cerro el 15-oct-2026 /api/availability/check a todo lo que
		# no sea su web (ver debrid/dmm.py). Esta funcion devolvia None cuando DMM
		# no contestaba y checkStatus() no anadia entonces NI UN torrent de RD:
		# el scrape encontraba 157 resultados y salia "No stream available" al
		# instante. Ahora cada hash queda en uno de tres estados:
		#   cached    -> DMM lo ha visto cacheado (solo con clave de patrocinador)
		#   uncached  -> DMM contesto por ese hash y no lo ha visto cacheado
		#   unchecked -> nadie pudo contestar; se muestra y resolve_magnet de RD
		#                lo comprueba al reproducir (1,5 s y lo borra si no esta)
		# Si DMM contesta pero no ha visto NINGUNO cacheado, todo pasa a
		# unchecked: su doc dice que un hash ausente "no significa que no lo
		# este", y ocultarlo todo es justo el fallo del video.
		if len(torrent_List) == 0: return
		try:
			cached, answered = None, set()
			# v2.0.11: apagado de fabrica y vacio = apagado. Sin la clave de
			# patrocinador de DMM no hay a quien preguntar, asi que encenderlo solo
			# tiene sentido con ella (Accounts > Real-Debrid, justo debajo).
			if getSetting('realdebrid.check_cache') == 'true':
				cached, answered = self._rd_dmm_availability(hashList)
			seen_any = bool(cached) and any(len(v or []) >= 1 for v in cached.values())
			_counts = {'cached': 0, 'uncached': 0, 'unchecked': 0}
			for i in torrent_List:
				h = (i.get('hash') or '').lower() # i['hash'] could still be base32 here: it just stays unchecked
				pack = ' (pack)' if 'package' in i else ''
				if seen_any and len(cached.get(h) or []) >= 1:
					i.update({'source': 'cached%s torrent' % pack}) ; _counts['cached'] += 1
				elif seen_any and h in answered:
					i.update({'source': 'uncached%s torrent' % pack}) ; _counts['uncached'] += 1
				else:
					i.update({'source': 'unchecked%s' % pack}) ; _counts['unchecked'] += 1
			log_utils.log('rd_cache_chk_list: %d cached, %d uncached, %d unchecked (DMM %s)'
					% (_counts['cached'], _counts['uncached'], _counts['unchecked'],
					'answered' if answered else 'not asked or no answer'), level=log_utils.LOGDEBUG)
			# ── RD 2026 keyword-filter compliance (infringing_file gate) ──────
			# Drop items whose name RD refuses, so the user never clicks a
			# result that will 451. v2.0.01: the DMM availability answer carries
			# each torrent's file paths, and RD judges the root folder on the
			# add and each file's own name on /unrestrict/link, so those are
			# checked too (rd_filter.is_files_filtered).
			try:
				from resources.lib.modules import rd_filter as _rd_filter
				_before = len(torrent_List)
				torrent_List, _removed = _rd_filter.apply_to_torrent_list(torrent_List, cached if isinstance(cached, dict) else None)
				if _removed:
					log_utils.log(
						'rd_cache_chk_list: RD2026 filter v%s removed %d of %d torrents '
						'(infringing_file name or file-name match)' % (_rd_filter.RD_FILTER_VERSION, _removed, _before),
						level=log_utils.LOGDEBUG)
			except Exception:
				log_utils.error()
			# ── end RD 2026 filter ────────────────────────────────────────────
			return torrent_List
		except: log_utils.error()

	def _rd_dmm_availability(self, hashList):
		"""(cached, answered): cached = {hash: ficheros} de lo que DMM ha visto
		cacheado, answered = hashes por los que DMM contesto. (None, set()) si no
		hay clave de patrocinador o no contesto ningun lote."""
		from resources.lib.debrid.dmm import DMMCache
		dmm = DMMCache()
		if not dmm.api_key():
			dmm.key_missing() # v2.0.11: encendido sin clave -> un aviso por sesion
			return None, set()
		from resources.lib.database import cache as _db_cache
		from hashlib import md5 as _md5
		_norm = sorted(set(h.lower() for h in hashList if len(h) == 40))
		if not _norm: return None, set()
		# Cache local de 30 min para repetir sin gastar API. Clave nueva
		# ('dmm_sp_'): el formato guardado cambia y las filas viejas 'dmm_avail_'
		# eran de la ruta cerrada.
		_ckey = 'dmm_sp_' + _md5('|'.join(_norm).encode('utf-8')).hexdigest()
		_crow = _db_cache.cache_get(_ckey)
		if _crow and _db_cache._is_cache_valid(_crow['date'], 0.5): # 0.5h = 30 min
			try:
				_val = literal_eval(_crow['value'])
				log_utils.log('rd_cache_chk_list: DMM SQLite cache hit (%d hashes)' % len(_norm), level=log_utils.LOGDEBUG)
				return _val['cached'], set(_val['answered'])
			except Exception: pass
		cached, answered, lock = {}, set(), _threading.Lock()
		def _process(_chunk):
			res = dmm.check_cache(_chunk, self.meta.get('imdb') if isinstance(self.meta, dict) else None)
			if res is None: return
			with lock:
				cached.update(res)
				answered.update(_chunk)
		threads = []
		for n in range(0, len(_norm), 100): # 100 hashes por llamada, como pide la API
			t = Thread(target=_process, args=(_norm[n:n + 100],), daemon=True)
			threads.append(t)
			t.start()
		[t.join() for t in threads]
		if not answered: return None, set()
		if len(answered) == len(_norm): # solo se guarda una respuesta completa
			try: _db_cache.cache_insert(_ckey, repr({'cached': cached, 'answered': sorted(answered)}))
			except Exception: pass
		return cached, answered

	def tb_cache_chk_list(self, torrent_List, hashList):
		if len(torrent_List) == 0: return
		try:
			from resources.lib.debrid.torbox import norm_hash
			from resources.lib.modules import scrape_planner as _sp
			# v2.0.05 -- en episodios con packs se piden tambien los ficheros de
			# cada torrent cacheado (list_files) para quitar ANTES de mostrar la
			# lista los packs que no traen el episodio; antes se descubria al
			# reproducir. Sin ficheros en la respuesta no se quita nada.
			season, episode = getattr(self, 'season', None), getattr(self, 'episode', None)
			want_files = bool(season and episode) and any('package' in i for i in torrent_List)
			# v2.0.26 -- la cache local de 30 min del CONJUNTO de hashes (v2.0.05)
			# casi nunca acertaba: bastaba un hash distinto. Ahora es por hash
			# (scrape_planner.check) y se rellena ya durante la busqueda.
			status = _sp.check('tb', hashList, want_files=want_files)
			if not status: return None
			cached = dict((h, v[1]) for h, v in status.items() if v[0])
			seas_ep_filter = None
			if want_files:
				from resources.lib.modules.source_utils import seas_ep_filter
			dropped = 0
			for i in torrent_List:
				h = norm_hash(i['hash'])
				if h not in status: continue # nadie contesto por el: se queda como estaba
				if h in cached:
					names = cached[h]
					if seas_ep_filter and 'package' in i and names and not any(seas_ep_filter(season, episode, n) for n in names):
						i.update({'source': 'uncached (pack) torrent'})
						dropped += 1
						continue
					if 'package' in i: i.update({'source': 'cached (pack) torrent'})
					else: i.update({'source': 'cached torrent'})
				else:
					if 'package' in i: i.update({'source': 'uncached (pack) torrent'})
					else: i.update({'source': 'uncached torrent'})
			if dropped:
				log_utils.log('tb_cache_chk_list: %d cached packs without S%sE%s left out' % (dropped, season, episode), level=log_utils.LOGDEBUG)
			return torrent_List
		except: log_utils.error()

	def oc_cache_chk_list(self, torrent_List, hashList):
		"""v2.0.20: Offcloud. Tres estados, como Real-Debrid:
		  cached    -> Offcloud lo tiene; se reproduce al momento
		  uncached  -> Offcloud contesto y no lo tiene
		  unchecked -> Offcloud no contesto (red); se muestra y resolve_magnet
		               lo comprueba al reproducir
		Con el token rechazado no se ensena nada de Offcloud: ya se aviso una vez.
		v2.0.26: cache por hash (scrape_planner.check) en vez de la del conjunto."""
		if len(torrent_List) == 0: return
		try:
			from resources.lib.debrid.offcloud import norm_hash
			from resources.lib.modules import scrape_planner as _sp
			status = _sp.check('oc', hashList)
			if _sp.auth_failed('oc'): return None # token rechazado: nada de Offcloud, aunque hubiera hashes recordados
			status = status or {}
			_counts = {'cached': 0, 'uncached': 0, 'unchecked': 0}
			for i in torrent_List:
				pack = ' (pack)' if 'package' in i else ''
				st = status.get(norm_hash(i.get('hash')))
				if st is None:
					i.update({'source': 'unchecked%s' % pack}) ; _counts['unchecked'] += 1
				elif st[0]:
					i.update({'source': 'cached%s torrent' % pack}) ; _counts['cached'] += 1
				else:
					i.update({'source': 'uncached%s torrent' % pack}) ; _counts['uncached'] += 1
			log_utils.log('oc_cache_chk_list: %d cached, %d uncached, %d unchecked'
					% (_counts['cached'], _counts['uncached'], _counts['unchecked']), level=log_utils.LOGDEBUG)
			return torrent_List
		except: log_utils.error()

	def clr_item_providers(self, title, year, imdb, tmdb, tvdb, season, episode, tvshowtitle, premiered):
		providerscache.remove(self.getSources, title, year, imdb, tmdb, tvdb, season, episode, tvshowtitle, premiered) # function cache removal of selected item ONLY
		providerscache.remove(self.getSourcesLang, title, year, imdb, tmdb, tvdb, season, episode, tvshowtitle, premiered) # v2.0.08: la busqueda con langhelper
		try:
			dbcon = database.connect(sourceFile)
			dbcur = dbcon.cursor()
			dbcur.execute('''SELECT count(name) FROM sqlite_master WHERE type='table' AND name='rel_src';''') # table exists so both will
			if dbcur.fetchone()[0] == 1:
				dbcur.execute('''DELETE FROM rel_src WHERE imdb_id=?''', (imdb,)) # DEL the "rel_src" list of cached links
				dbcur.connection.commit()
		except: log_utils.error()
		finally: dbcur.close() ; dbcon.close()

	def imdb_meta_chk(self, imdb, title, year):
		try:
			if not imdb or imdb == '0': return title, year
			from resources.lib.modules.client import _basic_request
			result = _basic_request('https://v2.sg.media-imdb.com/suggestion/t/{}.json'.format(imdb))
			if not result: return title, year
			result = jsloads(result)['d'][0]
			year_ck = str(result.get('y', ''))
			title_ck = self.getTitle(result['l'])
			if not year_ck or not title_ck: return title, year
			if self.mediatype == 'movie':
				if getSetting('imdb.Movietitle.check') == 'true' and (title != title_ck):
					log_utils.log('IMDb Movie title_ck: (%s) does not match meta Movie title passed: (%s)' % (title_ck, title), __name__, level=log_utils.LOGDEBUG)
					title = title_ck
				if getSetting('imdb.Movieyear.check') == 'true' and (year != year_ck):
					log_utils.log('IMDb Movie year_ck: (%s) does not match meta Movie year passed: (%s) for title: (%s)' % (year_ck, year, title), __name__, level=log_utils.LOGDEBUG)
					year = year_ck
			else:
				if getSetting('imdb.Showtitle.check') == 'true' and (title != title_ck):
					log_utils.log('IMDb Show title_ck: (%s) does not match meta tvshowtitle title passed: (%s)' % (title_ck, title), __name__, level=log_utils.LOGDEBUG)
					title = title_ck
				if getSetting('imdb.Showyear.check') == 'true' and (year != year_ck):
					log_utils.log('IMDb Show year_ck: (%s) does not match meta tvshowtitle year passed: (%s) for title: (%s)' % (year_ck, year, title), __name__, level=log_utils.LOGDEBUG)
					year = year_ck
			return title, year
		except:
			log_utils.error()
			return title, year

	def get_season_info(self, imdb, tmdb, tvdb, meta, season):
		total_seasons = None
		season_isAiring = None
		try:
			total_seasons = meta.get('total_seasons', None)
			season_isAiring = meta.get('season_isAiring', None)
		except: pass
		if not total_seasons or season_isAiring is None: # check metacache, 2nd fallback
			try:
				user = '' # v2.0.04: clave de la metacache de series (antes imdb.user, siempre vacio)
				meta_lang = control.apiLanguage()['tvdb']
				ids = [{'imdb': imdb, 'tmdb': tmdb, 'tvdb': tvdb}]
				meta2 = metacache.fetch(ids, meta_lang, user)[0]
				if not total_seasons: total_seasons = meta2.get('total_seasons', None)
				if season_isAiring is None: season_isAiring = meta2.get('season_isAiring', None)
			except: log_utils.error()
		if not total_seasons: # make request, 3rd fallback
			try:
				from resources.lib.modules.trakt import getSeasons
				total_seasons = getSeasons(imdb, full=False)
				if total_seasons:
					total_seasons = [i['number'] for i in total_seasons]
					season_special = True if 0 in total_seasons else False
					total_seasons = len(total_seasons)
					if season_special: total_seasons = total_seasons - 1
			except: log_utils.error()
		if season_isAiring is None:
			try:
				from resources.lib.indexers import tmdb as tmdb_indexer
				season_isAiring = tmdb_indexer.TVshows().get_season_isAiring(tmdb, season)
				if not season_isAiring: season_isAiring = 'false'
			except: log_utils.error()
		return total_seasons, season_isAiring

	def mix_by_provider(self, source_list, top_n=120, max_per_provider=12):
		"""Diversify providers in the top of the list so one provider (e.g. torrentio) does not dominate."""
		try:
			if not source_list: return source_list
			top = source_list[:int(top_n)]
			rest = source_list[int(top_n):]
			buckets = {}
			order = []
			for item in top:
				key = item.get('provider') or item.get('debrid') or item.get('source') or ''
				if key not in buckets:
					buckets[key] = []
					order.append(key)
				buckets[key].append(item)
			out = []
			used = {k: 0 for k in buckets}
			while True:
				progressed = False
				for k in order:
					if buckets.get(k) and used.get(k, 0) < int(max_per_provider):
						out.append(buckets[k].pop(0))
						used[k] = used.get(k, 0) + 1
						progressed = True
				if not progressed:
					break
			# append any leftovers (still preserving the original provider order)
			for k in order:
				out.extend(buckets.get(k, []))
			return out + rest
		except:
			return source_list

	def sort_byQuality(self, source_list):
		filter = []
		quality = getSetting('hosts.quality') or '0'
		if quality == '0': filter += [i for i in source_list if i['quality'] == '4K']
		if quality in ('0', '1'): filter += [i for i in source_list if i['quality'] == '1080p']
		if quality in ('0', '1', '2'): filter += [i for i in source_list if i['quality'] == '720p']
		filter += [i for i in source_list if i['quality'] == 'SCR']
		filter += [i for i in source_list if i['quality'] == 'SD']
		filter += [i for i in source_list if i['quality'] == 'CAM']
		quality_min = getSetting('hosts.quality.min') or '0'
		if quality_min == '1':   # min 720p: remove SD/SCR/CAM
			filter = [i for i in filter if i['quality'] not in ('SD', 'SCR', 'CAM')]
		elif quality_min == '2': # min 1080p: remove SD/SCR/CAM + 720p
			filter = [i for i in filter if i['quality'] not in ('SD', 'SCR', 'CAM', '720p')]
		elif quality_min == '3': # min 4K: only 4K
			filter = [i for i in filter if i['quality'] == '4K']
		return filter

	def getSourceProgress(self, header, meta):
		from resources.lib.windows.source_progress import SourceProgressXML
		window = SourceProgressXML('source_progress.xml', control.addonPath(control.addonId()), heading=header, meta=meta)
		window.create()
		return window


	def _ramcache_ttl_seconds(self):
		try:
			# Default raised to 20 min — processed results (post-debrid + post-sort) are
			# stable within a session and expensive to regenerate (DMMCache API call).
			minutes = int(getSetting('sources.ramcache.ttl') or '20')
		except:
			minutes = 20
		if minutes < 1: minutes = 1
		if minutes > 120: minutes = 120
		return minutes * 60

	def _build_ramcache_id(self, imdb, tmdb, tvdb, season, episode, year):
		try:
			parts = [str(imdb or ''), str(tmdb or ''), str(tvdb or ''), str(season or ''), str(episode or ''), str(year or '')]
			return '|'.join(parts)
		except:
			return ''

	def _ramcache_get(self, cache_id):
		try:
			if not cache_id: return None
			data = homeWindow.getProperty('luc_kodi.ramcache.' + cache_id)
			ts = homeWindow.getProperty('luc_kodi.ramcache_ts.' + cache_id)
			if not data or not ts: return None
			if (time() - float(ts)) > self._ramcache_ttl_seconds(): return None
			return jsloads(data)
		except:
			return None

	# Máximo de entradas vivas en el RAM cache. Cada entrada es una lista de
	# hasta 200 dicts serializada en una Window property. Limitarlas evita que
	# navegar muchos títulos acumule memoria sin techo (importante en tablets
	# con RAM ajustada). LRU simple: al superar el tope, se expulsa la más
	# antigua. 12 entradas ≈ el historial de navegación reciente típico.
	_RAMCACHE_MAX_ENTRIES = 12

	def _low_memory(self):
		try:
			from resources.lib.modules import device_profile
			return device_profile.is_low()
		except Exception:
			return False

	def _ramcache_index_get(self):
		try:
			raw = homeWindow.getProperty('luc_kodi.ramcache_index')
			return jsloads(raw) if raw else []
		except:
			return []

	def _ramcache_index_set(self, keys):
		try:
			homeWindow.setProperty('luc_kodi.ramcache_index', jsdumps(keys))
		except:
			pass

	def _ramcache_touch(self, cache_id):
		"""Marca cache_id como el más reciente y expulsa los más antiguos si se
		supera _RAMCACHE_MAX_ENTRIES, liberando sus Window properties."""
		try:
			keys = self._ramcache_index_get()
			if cache_id in keys:
				keys.remove(cache_id)
			keys.append(cache_id)  # most-recent al final
			# Expulsar los más antiguos que excedan el tope.
			while len(keys) > (6 if self._low_memory() else self._RAMCACHE_MAX_ENTRIES):
				evict = keys.pop(0)
				self._ramcache_clear(evict)
			self._ramcache_index_set(keys)
		except:
			pass

	def _ramcache_set(self, cache_id, items):
		try:
			if not cache_id or not items: return
			# Only cache items that have gone through the debrid check (have 'debrid' key
			# or are direct/cloud sources). Stale pre-check items waste memory and TTL.
			_resolved = [i for i in items if i.get('debrid') or i.get('direct') or i.get('source') == 'cloud']
			if not _resolved: return  # nothing debrid-resolved yet — don't cache
			# Cap at top-200 to avoid bloating Kodi window properties with 4000 dicts.
			# v1.0.90: en aparatos de poca memoria (device_profile) se guardan
			# menos fuentes y menos titulos.
			_low = self._low_memory()
			_to_cache = items[:100 if _low else 200]
			homeWindow.setProperty('luc_kodi.ramcache.' + cache_id, jsdumps(_to_cache))
			homeWindow.setProperty('luc_kodi.ramcache_ts.' + cache_id, str(time()))
			# Registrar en el índice LRU y expulsar entradas viejas si toca.
			self._ramcache_touch(cache_id)
		except:
			pass

	def _ramcache_clear(self, cache_id):
		try:
			if not cache_id: return
			homeWindow.clearProperty('luc_kodi.ramcache.' + cache_id)
			homeWindow.clearProperty('luc_kodi.ramcache_ts.' + cache_id)
		except:
			pass