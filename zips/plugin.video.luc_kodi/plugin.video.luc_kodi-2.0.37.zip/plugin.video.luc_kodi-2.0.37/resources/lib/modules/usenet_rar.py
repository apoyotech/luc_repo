# -*- coding: utf-8 -*-
"""
	luc_kodi Add-on
	v2.0.37 -- RAR por dentro: todos los ficheros de un juego RAR 'store' y RAR
	cifrado con la clave del NZB (Lucian, 17-nov-2026: "asi se podrian
	descifrar varios NZB que ahora son inalcanzables").

	El motor de siempre solo leia el PRIMER fichero de un RAR. Aqui se recorren
	las cabeceras de todos los volumenes y se sabe donde esta cada fichero:
	  - un disco Blu-ray entero (carpeta BDMV): se sirve el .m2ts mayor, como
	    ya se hacia con los discos dentro de un 7z;
	  - un release con el .nfo o la muestra delante del video;
	  - un pack de temporada en un solo juego RAR: el episodio pedido;
	  - RAR cifrado: RAR5 (AES-256, clave PBKDF2-SHA256) y RAR4/RAR3 (AES-128,
	    clave SHA-1 con 2^18 vueltas), con o sin las cabeceras cifradas (-hp).
	    El video se descifra al servirlo, como el 7z cifrado (AES-CBC: el byte
	    n del claro es el byte n del cifrado).

	Puro Python salvo AES (pycryptodome, el mismo del 7z) y hashlib.
	Comprobado con RAR de WinRAR de verdad (los de prueba de rarfile 4.5) y
	con el banco Usenet.
"""

import hashlib
import re
import struct
import threading
import zlib

_SIG4 = b'Rar!\x1a\x07\x00'
_SIG5 = b'Rar!\x1a\x07\x01\x00'
VIDEO_EXT = ('mkv', 'mp4', 'm4v', 'avi', 'ts', 'm2ts', 'mts')
_SAMPLE_RE = re.compile(r'(?i)(^|[ ._\-\[(/])sample([ ._\-\])/]|$)')   # tambien la carpeta Sample/


class RarError(ValueError):
	pass


class NeedsPassword(RarError):
	pass


class WrongPassword(RarError):
	pass


def _vint(b, i):
	res = shift = 0
	while i < len(b):
		x = b[i]; i += 1
		res |= (x & 0x7F) << shift
		if x < 0x80:
			return res, i
		shift += 7
	raise RarError('truncated header')


def _ceil16(n):
	return (n + 15) & ~15


def ext_of(name):
	n = (name or '').lower().replace('\\', '/').rsplit('/', 1)[-1]
	return n.rsplit('.', 1)[-1] if '.' in n else ''


# --------------------------------------------------------------- claves -----
_K5, _K3, _C5 = {}, {}, {}
_KDF_LOCK = threading.Lock()


def kdf5(password, salt, count_log2):
	"""Clave AES-256 de RAR5: PBKDF2-HMAC-SHA256 con 2^n vueltas (en C)."""
	ck = (password, salt, count_log2)
	with _KDF_LOCK:
		hit = _K5.get(ck)
		if hit is not None:
			return hit
		if count_log2 > 24:
			raise RarError('RAR5 key with too many rounds')
		pw = password.encode('utf-16-le')[:254].decode('utf-16-le', 'ignore').encode('utf-8')
		key = hashlib.pbkdf2_hmac('sha256', pw, salt, 1 << count_log2)
		_K5[ck] = key
		while len(_K5) > 16: _K5.pop(next(iter(_K5)))
		return key


def check5(password, salt, count_log2, check):
	"""True/False con el valor de comprobacion de RAR5; None si no lo trae."""
	if not check or len(check) != 12:
		return None
	if hashlib.sha256(check[:8]).digest()[:4] != check[8:]:
		return None
	ck = (password, salt, count_log2, check)
	with _KDF_LOCK:
		if ck in _C5:
			return _C5[ck]
		pw = password.encode('utf-16-le')[:254].decode('utf-16-le', 'ignore').encode('utf-8')
		v = hashlib.pbkdf2_hmac('sha256', pw, salt, (1 << count_log2) + 32)
		fold = bytearray(8)
		for i, x in enumerate(v):
			fold[i & 7] ^= x
		ok = bytes(fold) == check[:8]
		_C5[ck] = ok
		while len(_C5) > 16: _C5.pop(next(iter(_C5)))
		return ok


_BE16 = struct.Struct('>16L')
_LE16 = struct.Struct('<16L')


def _rarbug(buf, dpos):
	"""El SHA-1 de RAR3 escribe su area de trabajo encima de los datos que lee
	(bloques de 64 enteros dentro de un update de mas de 64 bytes)."""
	ws = list(_BE16.unpack_from(buf, dpos))
	for t in range(16, 80):
		tmp = ws[(t - 3) & 15] ^ ws[(t - 8) & 15] ^ ws[(t - 14) & 15] ^ ws[(t - 16) & 15]
		ws[t & 15] = ((tmp << 1) | (tmp >> 31)) & 0xFFFFFFFF
	_LE16.pack_into(buf, dpos, *ws)


def kdf3(password, salt):
	"""(clave AES-128, iv) de RAR3/RAR4: SHA-1 de (clave UTF-16LE + sal +
	contador de 3 bytes) 2^18 veces; un byte del iv cada 2^14. Por tandas para
	que hashlib (en C) haga el trabajo; con claves largas (mas de 28
	caracteres) se reproduce el fallo del SHA-1 de RAR3, como hace unrar."""
	ck = (password, salt)
	with _KDF_LOCK:
		hit = _K3.get(ck)
		if hit is not None:
			return hit
		seed = bytearray(password.encode('utf-16-le')[:254] + salt)
		L = len(seed)
		h = hashlib.sha1()
		iv = bytearray()
		if L <= 64:
			sb = bytes(seed)
			for i in range(16):
				base = i * 0x4000
				h.update(sb + base.to_bytes(3, 'little'))
				iv.append(h.digest()[19])
				h.update(b''.join(sb + (base + j).to_bytes(3, 'little') for j in range(1, 0x4000)))
		else:
			# como rarfile.Rar3Sha1(rarbug=True): se resume la sal de ahora y despues
			# el fallo del SHA-1 de RAR3 la reescribe para la vuelta siguiente
			nbytes = 0
			for i in range(16):
				base = i * 0x4000
				batch = []
				for j in range(0x4000):
					batch.append(bytes(seed) + (base + j).to_bytes(3, 'little'))
					bufpos = nbytes & 63
					nbytes += L
					dpos = 64 - bufpos
					while dpos + 64 <= L:
						_rarbug(seed, dpos)
						dpos += 64
					nbytes += 3
					if j == 0:
						h.update(b''.join(batch)); batch = []
						iv.append(h.digest()[19])
				h.update(b''.join(batch))
		key = h.digest()[:16]
		key = struct.pack('<4L', *struct.unpack('>4L', key))
		res = (key, bytes(iv))
		_K3[ck] = res
		while len(_K3) > 16: _K3.pop(next(iter(_K3)))
		return res


# ---------------------------------------------------- cabeceras de un vol ---
def parse_volume(read, vsize, password, aes):
	"""Cabeceras de UN volumen. read(off, n) -> bytes del volumen. aes: el
	modulo AES de pycryptodome (o None). Devuelve {'fmt', 'first', 'blocks'}:
	blocks de fichero con name, data_off, data_size, sb (continua de otro
	volumen), sa (sigue en el siguiente), unp, store, dir y enc (lo necesario
	para la clave de los datos, o None)."""
	head = read(0, 8)
	if head[:8] == _SIG5:
		return _parse5(read, vsize, password, aes)
	if head[:7] == _SIG4:
		return _parse4(read, vsize, password, aes)
	raise RarError('not a RAR volume')


def _need(password, aes):
	if not password:
		raise NeedsPassword('password-protected RAR without its password in the NZB')
	if aes is None:
		raise RarError('AES module missing')


def _parse5(read, vsize, password, aes):
	pos, first, blocks = 8, None, []
	hkey = None
	while pos < vsize:
		if hkey is not None:
			iv = read(pos, 16)
			if len(iv) < 16:
				break
			raw16 = read(pos + 16, 16)
			if len(raw16) < 16:
				break
			b0 = aes.new(hkey, aes.MODE_CBC, iv).decrypt(raw16)
			hsize, j = _vint(b0, 4)
			total = j + hsize
			enc = _ceil16(total)
			if enc == 16:
				hdr = b0[:total]
			else:
				hdr = aes.new(hkey, aes.MODE_CBC, iv).decrypt(read(pos + 16, enc))[:total]
			if len(hdr) < total or zlib.crc32(hdr[4:]) & 0xFFFFFFFF != struct.unpack_from('<L', hdr, 0)[0]:
				raise WrongPassword('wrong password for this RAR')
			data_off = pos + 16 + enc
		else:
			b0 = read(pos, 128)
			if len(b0) < 7:
				break
			hsize, j = _vint(b0, 4)
			total = j + hsize
			hdr = b0[:total] if total <= len(b0) else read(pos, total)
			data_off = pos + total
		k = j
		htype, k = _vint(hdr, k)
		hflags, k = _vint(hdr, k)
		extra = dsize = 0
		if hflags & 0x1: extra, k = _vint(hdr, k)
		if hflags & 0x2: dsize, k = _vint(hdr, k)
		end = total
		if htype == 1:                                   # cabecera principal
			af, k = _vint(hdr, k)
			vol = 0
			if af & 0x2: vol, k = _vint(hdr, k)
			first = vol == 0
		elif htype == 4:                                 # cabeceras cifradas (-hp)
			_need(password, aes)
			_v, k = _vint(hdr, k)
			ef, k = _vint(hdr, k)
			cnt = hdr[k]; k += 1
			salt = hdr[k:k + 16]; k += 16
			chk = hdr[k:k + 12] if ef & 0x1 else b''
			if check5(password, salt, cnt, chk) is False:
				raise WrongPassword('wrong password for this RAR')
			hkey = kdf5(password, salt, cnt)
		elif htype in (2, 3):                            # fichero / servicio
			ff, k = _vint(hdr, k)
			unp, k = _vint(hdr, k)
			_a, k = _vint(hdr, k)
			if ff & 0x2: k += 4
			if ff & 0x4: k += 4
			comp, k = _vint(hdr, k)
			_os, k = _vint(hdr, k)
			nlen, k = _vint(hdr, k)
			name = hdr[k:k + nlen].decode('utf-8', 'replace')
			enc = None
			x = end - extra
			while extra and x < end:
				rsize, x2 = _vint(hdr, x)
				rtype, x3 = _vint(hdr, x2)
				if rtype == 1:                           # registro de cifrado
					_v, y = _vint(hdr, x3)
					rf, y = _vint(hdr, y)
					cnt = hdr[y]; y += 1
					salt = hdr[y:y + 16]; y += 16
					iv = hdr[y:y + 16]; y += 16
					chk = hdr[y:y + 12] if rf & 0x1 else b''
					enc = {'fmt': 5, 'count': cnt, 'salt': salt, 'iv': iv, 'check': chk}
				x = x2 + rsize
			if htype == 2:
				blocks.append({'name': name, 'data_off': data_off, 'data_size': dsize, 'unp': unp,
							   'sb': bool(hflags & 0x8), 'sa': bool(hflags & 0x10),
							   'store': ((comp >> 7) & 7) == 0, 'dir': bool(ff & 0x1), 'enc': enc})
		elif htype == 5:                                 # fin
			break
		pos = data_off + dsize
	return {'fmt': 5, 'first': first, 'blocks': blocks, 'hdr_encrypted': hkey is not None}


def _parse4(read, vsize, password, aes):
	pos, first, blocks = 7, None, []
	henc = False
	while pos + 7 <= vsize:
		if henc:
			salt = read(pos, 8)
			if len(salt) < 8:
				break
			raw16 = read(pos + 8, 16)
			if len(raw16) < 16:
				break
			key, iv = kdf3(password, salt)
			b0 = aes.new(key, aes.MODE_CBC, iv).decrypt(raw16)
			hsize = struct.unpack_from('<H', b0, 5)[0]
			if hsize < 7:
				raise WrongPassword('wrong password for this RAR')
			enc = _ceil16(hsize)
			if enc == 16:
				hdr = b0[:hsize]
			else:
				hdr = aes.new(key, aes.MODE_CBC, iv).decrypt(read(pos + 8, enc))[:hsize]
			if len(hdr) < hsize or zlib.crc32(hdr[2:]) & 0xFFFF != struct.unpack_from('<H', hdr, 0)[0]:
				raise WrongPassword('wrong password for this RAR')
			data_off = pos + 8 + enc
		else:
			b0 = read(pos, 128)
			if len(b0) < 7:
				break
			hsize = struct.unpack_from('<H', b0, 5)[0]
			if hsize < 7:
				break
			hdr = b0[:hsize] if hsize <= len(b0) else read(pos, hsize)
			data_off = pos + hsize
		htype = hdr[2]
		flags = struct.unpack_from('<H', hdr, 3)[0]
		add = struct.unpack_from('<L', hdr, 7)[0] if flags & 0x8000 and len(hdr) >= 11 else 0
		if htype == 0x73:
			first = bool(flags & 0x0100) or not (flags & 0x0001)
			if flags & 0x0080:                           # cabeceras cifradas (-hp)
				_need(password, aes)
				henc = True
			add = 0
		elif htype == 0x74:
			pack = add
			unp = struct.unpack_from('<L', hdr, 11)[0]
			method = hdr[25]
			nsize = struct.unpack_from('<H', hdr, 26)[0]
			npos = 32
			if flags & 0x0100:
				pack |= struct.unpack_from('<L', hdr, 32)[0] << 32
				unp |= struct.unpack_from('<L', hdr, 36)[0] << 32
				add = pack
				npos = 40
			name = hdr[npos:npos + nsize].split(b'\x00')[0].decode('utf-8', 'replace').replace('\\', '/')
			enc = None
			if flags & 0x0004:
				salt = hdr[npos + nsize:npos + nsize + 8] if flags & 0x0400 else b''
				enc = {'fmt': 4, 'salt': salt}
			blocks.append({'name': name, 'data_off': data_off, 'data_size': pack, 'unp': unp,
						   'sb': bool(flags & 0x0001), 'sa': bool(flags & 0x0002),
						   'store': method == 0x30, 'dir': (flags & 0x00E0) == 0x00E0, 'enc': enc})
		elif htype == 0x7b:
			break
		pos = data_off + add
	return {'fmt': 4, 'first': first, 'blocks': blocks, 'hdr_encrypted': henc}


# ------------------------------------------------------ ficheros del juego --
def entries(volumes):
	"""Une los trozos de cada fichero a traves de los volumenes (en orden).
	-> [{'name', 'unp', 'store', 'enc', 'pieces': [(vol, off, size)]}]"""
	out, cur = [], None
	for v, vol in enumerate(volumes):
		for b in vol['blocks']:
			if b['dir']:
				continue
			if b['sb']:
				if cur is None or cur['name'] != b['name']:
					if v == 0 and cur is None:
						continue        # el juego empieza a mitad de un fichero: ese no
					raise RarError('RAR volumes out of order')
				cur['pieces'].append((v, b['data_off'], b['data_size']))
			else:
				cur = {'name': b['name'], 'unp': b['unp'], 'store': b['store'], 'enc': b['enc'],
					   'pieces': [(v, b['data_off'], b['data_size'])], 'open': b['sa']}
				out.append(cur)
			cur['open'] = b['sa']
			if not b['sa']:
				cur = None
	return out


def complete(e):
	return not e.get('open')


def pick(ents, want=None, episode_pairs=None):
	"""El video a servir: el del episodio pedido o, si no, el mayor (en un
	disco, el .m2ts mayor). -> (entrada, None) o (None, motivo)."""
	vids = [e for e in ents if ext_of(e['name']) in VIDEO_EXT and not _is_sample(e['name'])]
	if not vids:
		vids = [e for e in ents if ext_of(e['name']) in VIDEO_EXT]
	if not vids:
		return None, 'no video inside the RAR'
	if want and episode_pairs:
		w = tuple(want)
		named = [e for e in vids if episode_pairs(e['name'])]
		hits = [e for e in named if w in episode_pairs(e['name'])]
		if hits:
			return max(hits, key=lambda e: e['unp']), None
		if named:
			return None, 'S%02dE%02d is not in this RAR' % w
		if len(vids) > 1:
			return None, 'season pack with hidden file names inside the RAR: S%02dE%02d cannot be picked' % w
		return vids[0], None
	return max(vids, key=lambda e: e['unp']), None


def _is_sample(name):
	n = (name or '').lower().replace('\\', '/')
	return bool(_SAMPLE_RE.search(n))


def cipher(e, password, aes):
	"""(funcion iv -> descifrador CBC, iv del fichero) para los datos de e."""
	enc = e['enc']
	_need(password, aes)
	if enc['fmt'] == 5:
		if check5(password, enc['salt'], enc['count'], enc.get('check')) is False:
			raise WrongPassword('wrong password for this RAR')
		key = kdf5(password, enc['salt'], enc['count'])
		iv = enc['iv']
	else:
		key, iv = kdf3(password, enc['salt'])
	return (lambda v: aes.new(key, aes.MODE_CBC, v)), iv