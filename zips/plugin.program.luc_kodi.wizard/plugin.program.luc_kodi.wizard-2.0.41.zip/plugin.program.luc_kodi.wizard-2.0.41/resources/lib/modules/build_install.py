import os
import json
import threading
from datetime import datetime
import time
import sqlite3
from zipfile import ZipFile
from xml.etree import ElementTree as ET
from pathlib import Path
import shutil
import xbmc
import xbmcgui
import xbmcvfs
import xbmcaddon
from .downloader import Downloader
from .save_data import save_backup_restore
from .maintenance import fresh_start, clean_backups, truncate_tables, skin_override, skin_override_disable
from .addonvar import dialog, zippath, addon_name, addon_icon, addon_id, home, setting, setting_set, local_string, addons_db, gui_temp_dir, gui_temp_file, advancedsettings_backup, NEW_BUILD
from .colors import colors

COLOR1 = colors.color_text1
COLOR2 = colors.color_text2

ADDON      = xbmcaddon.Addon()
ADDON_PATH = ADDON.getAddonInfo('path')

date_time = datetime.now()
date = date_time.strftime('%Y-%m-%d')
addons_path = Path(xbmcvfs.translatePath('special://home/addons'))
user_data   = Path(xbmcvfs.translatePath('special://userdata'))
binaries_path = Path(xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))) / 'binaries.json'

EXTRACT_MAX_W = 780   # ancho en px de la barra de extracción (coincide con XML)


# ─────────────────────────────────────────────────────────────────────────────
#  Ventana de confirmación personalizada
# ─────────────────────────────────────────────────────────────────────────────

class ConfirmDialog(xbmcgui.WindowXMLDialog):
    """
    Ventana de confirmación antes de instalar un build.
    Retorna True si el usuario pulsa Continue, False si pulsa Cancel.
    """
    ID_BUILD_NAME = 2001
    ID_CONTINUE   = 2002
    ID_CANCEL     = 2003

    def __init__(self, xml_file, addon_path, build_name=''):
        self.build_name = build_name
        self.result     = False
        super().__init__(xml_file, addon_path)

    def onInit(self):
        self.getControl(self.ID_BUILD_NAME).setLabel(self.build_name)

    def onClick(self, control_id):
        if control_id == self.ID_CONTINUE:
            self.result = True
            self.close()
        elif control_id == self.ID_CANCEL:
            self.result = False
            self.close()

    def onAction(self, action):
        if action.getId() in (xbmcgui.ACTION_NAV_BACK,
                              xbmcgui.ACTION_PREVIOUS_MENU):
            self.result = False
            self.close()


# ─────────────────────────────────────────────────────────────────────────────
#  Ventana de extracción personalizada
# ─────────────────────────────────────────────────────────────────────────────

class ExtractDialog(xbmcgui.WindowXMLDialog):
    """
    Ventana de progreso para la extracción del ZIP.
    Se actualiza desde el hilo principal vía update(perc, filename).
    """
    ID_TITLE    = 3001
    ID_DETAIL   = 3002
    ID_PERCENT  = 3003
    ID_FILL     = 3004
    ID_CANCEL   = 3005

    def __init__(self, xml_file, addon_path, build_name=''):
        self.build_name = build_name
        self._lock      = threading.Lock()
        self._perc      = 0
        self._detail    = ''
        self._done      = False
        self.cancelled  = False
        super().__init__(xml_file, addon_path)

    def onInit(self):
        self.getControl(self.ID_TITLE).setLabel(
            f'luc_ Builds  \xb7  {self.build_name}' if self.build_name else 'luc_ Builds'
        )
        self.getControl(self.ID_DETAIL).setLabel('Preparing...')
        self.getControl(self.ID_FILL).setWidth(1)

        while not self._done and not self.cancelled:
            self._refresh()
            xbmc.sleep(150)
        self._refresh()
        if self._done and not self.cancelled:
            xbmc.sleep(500)
        self.close()

    def onClick(self, control_id):
        if control_id == self.ID_CANCEL:
            self.cancelled = True

    def onAction(self, action):
        if action.getId() in (xbmcgui.ACTION_NAV_BACK,
                              xbmcgui.ACTION_PREVIOUS_MENU):
            self.cancelled = True

    def update(self, perc, detail=''):
        with self._lock:
            self._perc   = perc
            self._detail = detail

    def finish(self):
        with self._lock:
            self._perc = 100
            self._done = True

    def _refresh(self):
        with self._lock:
            perc   = self._perc
            detail = self._detail
        fill_w = max(1, int(EXTRACT_MAX_W * perc / 100))
        self.getControl(self.ID_FILL).setWidth(fill_w)
        self.getControl(self.ID_PERCENT).setLabel(f'{perc}%')
        if detail:
            # Mostrar solo el nombre del fichero, no la ruta completa
            short = detail.split('/')[-1] or detail
            self.getControl(self.ID_DETAIL).setLabel(short)


# ─────────────────────────────────────────────────────────────────────────────
#  Funciones públicas
# ─────────────────────────────────────────────────────────────────────────────

def build_install(name, name2, version, url):
    # ── 1. Confirmación personalizada ────────────────────────────────────────
    dlg_confirm = ConfirmDialog('confirm_install.xml', ADDON_PATH, build_name=name)
    dlg_confirm.doModal()
    result = dlg_confirm.result
    del dlg_confirm
    if not result:
        return

    # ── 2. Descarga ──────────────────────────────────────────────────────────
    download_build(name, url)

    # ── 3. Backup ────────────────────────────────────────────────────────────
    if name2 in [setting('buildname'), NEW_BUILD]:
        save_backup_restore('backup')
    elif setting('skin_protection') == 'true':
        setting_set('saveadvanced', 'true')
        skin_override_disable()
        save_backup_restore('backup')
    else:
        save_backup_restore('backup')

    fresh_start()

    if name2 not in [setting('buildname'), NEW_BUILD]:
        extract_gui()

    # ── 4. Extracción con ventana personalizada ───────────────────────────────
    extract_build(name)

    # ── 5. Restore ───────────────────────────────────────────────────────────
    if name2 in [setting('buildname'), NEW_BUILD]:
        save_backup_restore('restore_gui')
    elif (name2 != setting('buildname') and name2 != NEW_BUILD
          and setting('skin_protection') == 'true'
          and setting('saveadvanced') == 'true'):
        if xbmcvfs.exists(gui_temp_file):
            tree = ET.parse(gui_temp_file)
            root = tree.getroot()
            for gui_setting in root:
                if gui_setting.get('id') == 'lookandfeel.skin':
                    skin = gui_setting.text
        skin_override(skin, advancedsettings_backup)
        save_backup_restore('restore')
    else:
        save_backup_restore('restore')

    clean_backups()
    setting_set('buildname',      name2)
    setting_set('buildversion',   version)
    setting_set('buildinstalled', date)
    setting_set('update_passed',  'false')
    setting_set('firstrun',       'true')
    enable_wizard()

    if name2 == 'ELEMico':
        xbmcgui.Dialog().notification(addon_name, 'Build Install Complete!', addon_icon, 3000)
        xbmc.sleep(4000)
        xbmcgui.Dialog().notification(addon_name, 'Force Closing Kodi!', addon_icon, 3000)
        xbmc.sleep(3500)
        os._exit(1)
    else:
        truncate_tables()
        xbmcgui.Dialog().notification(addon_name, 'Build Install Complete!', addon_icon, 3000)
        xbmc.sleep(4000)
        xbmcgui.Dialog().notification(addon_name, 'Force Closing Kodi!', addon_icon, 3000)
        xbmc.sleep(3500)
        os._exit(1)


def download_build(name, url):
    if os.path.exists(zippath):
        os.unlink(zippath)
    d = Downloader(url)
    d.download_build(name, zippath)


def extract_build(name=''):
    if not os.path.exists(zippath):
        return

    # Lanzar la ventana de extracción en el hilo principal de UI
    dlg = ExtractDialog('extract_progress.xml', ADDON_PATH, build_name=name)

    def _do_extract():
        with ZipFile(zippath, 'r') as z:
            files = z.infolist()
            total = len(files)
            for counter, file in enumerate(files, 1):
                if dlg.cancelled:
                    break
                filename = file.filename
                filename_path = os.path.join(home, filename)
                perc = int(counter / total * 100)
                try:
                    if not os.path.exists(filename_path) or 'Addons33.db' in filename:
                        z.extract(file, home)
                except Exception as e:
                    xbmc.log(f'Error extracting {filename} - {e}', xbmc.LOGINFO)
                dlg.update(perc, filename)
        dlg.finish()

    t = threading.Thread(target=_do_extract, daemon=True)
    t.start()
    dlg.doModal()
    del dlg

    # Limpiar ZIP
    try:
        os.unlink(zippath)
    except OSError:
        pass


def extract_gui():
    if os.path.exists(zippath):
        os.makedirs(gui_temp_dir, exist_ok=True)
        with ZipFile(zippath) as z:
            with open(gui_temp_file, 'wb') as f:
                try:
                    f.write(z.read('userdata/guisettings.xml'))
                except Exception as e:
                    xbmc.log(f'Error extracting guisettings.xml - {e}', xbmc.LOGINFO)


def enable_wizard():
    try:
        timestamp = str(datetime.now())[:-7]
        con = sqlite3.connect(addons_db)
        cursor = con.cursor()
        cursor.execute(
            'INSERT or IGNORE into installed (addonID, enabled, installDate) VALUES (?,?,?)',
            (addon_id, 1, timestamp)
        )
        cursor.execute('UPDATE installed SET enabled = ? WHERE addonID = ?', (1, addon_id))
        con.commit()
    except sqlite3.Error as e:
        xbmc.log(f'Database error: {e}', xbmc.LOGINFO)
    finally:
        try:
            if con: con.close()
        except UnboundLocalError:
            pass
