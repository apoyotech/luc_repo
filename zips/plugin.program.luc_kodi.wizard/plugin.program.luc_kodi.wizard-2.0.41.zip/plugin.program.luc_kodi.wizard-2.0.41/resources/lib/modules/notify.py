import xbmc
import xbmcgui
import xbmcaddon
import re
from ..modules.parser import get_page
from ..modules import _service
from uservar import notify_url, changelog_dir
from .addonvar import setting, BUILD_NAME, CURRENT_BUILD

def get_notify() -> list:
    response = get_page(notify_url)
    try:
        split_response = response.split('|||')
        notify_version = int(split_response[0])
        message = split_response[1]
    except Exception as e:
        xbmc.log(f'[luc_kodi.wizard] get_notify error: {e}', xbmc.LOGWARNING)
        notify_version = 0
        message = 'Improper Notifications format. Please check the Notifications text.'
    return [notify_version, message]

def get_changelog():
    #build = setting('buildname')
    if not BUILD_NAME:
        rm_colors = "".join(re.split(r'\[|\]', CURRENT_BUILD)[::2])
        filename = rm_colors.replace(' ', '%20')
        changelog = '%s%s.txt' %(changelog_dir, filename)
        message = get_page(changelog)
        return message
    else:
        rm_colors = "".join(re.split(r'\[|\]', BUILD_NAME)[::2])
        filename = rm_colors.replace(' ', '%20')
        changelog = '%s%s.txt' %(changelog_dir, filename)
        message = get_page(changelog)
        return message

def notification(message: str) -> None:  
    class Notify(xbmcgui.WindowXMLDialog):
        KEY_NAV_BACK = 92
        TEXTBOX = 300
        CLOSEBUTTON = 302
        
        def onInit(self):
            self.getControl(self.TEXTBOX).setText(message)
            
        def onAction(self, action):
            if action.getId() == self.KEY_NAV_BACK:
                self.Close()
    
        def onClick(self, controlId):
            if controlId == self.CLOSEBUTTON:
                self.Close()

        def Close(self):
            self.close()
            
    d = Notify('notify.xml', xbmcaddon.Addon().getAddonInfo('path'), 'Default', '720p')
    d.doModal()
    del d

def notification_clog(message: str) -> None:  
    class Notify(xbmcgui.WindowXMLDialog):
        KEY_NAV_BACK = 92
        TEXTBOX = 300
        CLOSEBUTTON = 302
        
        def onInit(self):
            self.getControl(self.TEXTBOX).setText(message)
            
        def onAction(self, action):
            if action.getId() == self.KEY_NAV_BACK:
                self.close()
    
        def onClick(self, controlId):
            if controlId == self.CLOSEBUTTON:
                self.close()

        def Close(self):
            self.close()
    
    d = Notify('changelog.xml', xbmcaddon.Addon().getAddonInfo('path'), 'Default', '720p')
    d.doModal()
    del d

def notify_toast(message: str, status: str = 'info', duration: int = 4000) -> None:
    """Notificación toast unificada con icono según estado.
    status: 'info' | 'ok' | 'error' | 'warn'
    """
    _addon = xbmcaddon.Addon()
    _name  = _addon.getAddonInfo('name')
    _icon  = _addon.getAddonInfo('icon')
    _icons = {
        'ok':    xbmcgui.NOTIFICATION_INFO,
        'error': xbmcgui.NOTIFICATION_ERROR,
        'warn':  xbmcgui.NOTIFICATION_WARNING,
        'info':  xbmcgui.NOTIFICATION_INFO,
    }
    xbmcgui.Dialog().notification(_name, message, _icons.get(status, _icon), duration)
