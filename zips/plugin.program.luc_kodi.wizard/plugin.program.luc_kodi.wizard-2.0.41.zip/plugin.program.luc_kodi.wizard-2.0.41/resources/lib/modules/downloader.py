"""
downloader.py  v2.0.36
Progress bar via setWidth() on ID_PROGRESS_FILL (image control).
All UI strings in English.
"""
import os, sys, time, threading
from urllib.request import Request, urlopen
import xbmc, xbmcgui, xbmcaddon

ADDON      = xbmcaddon.Addon()
ADDON_NAME = ADDON.getAddonInfo('name')
ADDON_PATH = ADDON.getAddonInfo('path')
ICON       = ADDON.getAddonInfo('icon')

ID_BUILD_NAME    = 1001
ID_BUILD_META    = 1002
ID_PERCENT_LABEL = 1003
ID_SPEED_LABEL   = 1004
ID_SIZE_LABEL    = 1005
ID_ETA_LABEL     = 1006
ID_PROGRESS_FILL = 1007
ID_CANCEL_BTN    = 1008
ID_STATUS_LABEL  = 1009

PROGRESS_MAX_W = 780  # pixels, matches XML track width


class DownloadDialog(xbmcgui.WindowXMLDialog):

    def __init__(self, xml_file, addon_path, build_name='', url='', zippath=''):
        self.build_name = build_name
        self.url        = url
        self.zippath    = zippath
        self._lock        = threading.Lock()
        self._perc        = 0
        self._speed_mbs   = 0.0
        self._bytes_done  = 0
        self._bytes_total = 0
        self._eta_secs    = 0.0
        self._done        = False
        self.cancelled    = False
        self.error        = None
        super().__init__(xml_file, addon_path)

    def onInit(self):
        label = f'luc_ Builds  \xb7  {self.build_name}' if self.build_name else 'luc_ Builds'
        self.getControl(ID_BUILD_NAME).setLabel(label)
        self.getControl(ID_STATUS_LABEL).setLabel('')
        self.getControl(ID_PROGRESS_FILL).setWidth(1)
        threading.Thread(target=self._download_thread, daemon=True).start()
        while not self._done and not self.cancelled:
            self._refresh_ui()
            xbmc.sleep(200)
        self._refresh_ui()
        if self._done and not self.cancelled and self.error is None:
            self.getControl(ID_STATUS_LABEL).setLabel(
                '[COLOR FF2aaa2a]Download complete — verifying integrity...[/COLOR]')
            xbmc.sleep(800)
        self.close()

    def onClick(self, control_id):
        if control_id == ID_CANCEL_BTN:
            self.cancelled = True

    def onAction(self, action):
        if action.getId() in (xbmcgui.ACTION_NAV_BACK,
                              xbmcgui.ACTION_PREVIOUS_MENU,
                              xbmcgui.ACTION_STOP):
            self.cancelled = True

    def _refresh_ui(self):
        with self._lock:
            perc, speed = self._perc, self._speed_mbs
            done_b, total_b, eta = self._bytes_done, self._bytes_total, self._eta_secs
        fill_w = max(1, int(PROGRESS_MAX_W * perc / 100))
        self.getControl(ID_PROGRESS_FILL).setWidth(fill_w)
        self.getControl(ID_PERCENT_LABEL).setLabel(f'{perc}%')
        if speed > 0:
            self.getControl(ID_SPEED_LABEL).setLabel(f'{speed:.1f} MB/s')
        done_mb  = done_b  // (1024 * 1024)
        total_mb = total_b // (1024 * 1024)
        self.getControl(ID_SIZE_LABEL).setLabel(
            f'{done_mb:,} / {total_mb:,} MB' if total_mb else f'{done_mb:,} MB')
        if eta > 0:
            m, s = divmod(int(eta), 60)
            self.getControl(ID_ETA_LABEL).setLabel(f'{m:02d}:{s:02d}')

    def _download_thread(self):
        UA = ('Mozilla/5.0 (Windows NT 10.0; Win64; x64) '
              'AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36')
        try:
            response = urlopen(Request(self.url, headers={'User-Agent': UA}), timeout=15)
        except Exception as exc:
            self.error = f'Connection error: {exc}'; self._done = True; return
        try:
            total_bytes = int(response.getheader('content-length', 0))
        except (TypeError, ValueError):
            total_bytes = 0
        total_mb  = total_bytes // (1024 * 1024)
        meta_text = (f'v{ADDON.getAddonInfo("version")}  \xb7  {total_mb:,} MB'
                     if total_bytes else f'v{ADDON.getAddonInfo("version")}  \xb7  Unknown size')
        self.getControl(ID_BUILD_META).setLabel(meta_text)
        with self._lock:
            self._bytes_total = total_bytes
        CHUNK = 1 * 1024 * 1024
        done = 0; t_ref = time.time(); done_ref = 0
        try:
            with open(self.zippath, 'wb') as fh:
                while not self.cancelled:
                    chunk = response.read(CHUNK)
                    if not chunk: break
                    fh.write(chunk); done += len(chunk)
                    now = time.time(); dt = now - t_ref
                    if dt >= 1.0:
                        spd = (done - done_ref) / dt
                        eta = (total_bytes - done) / spd if total_bytes and spd > 0 else 0
                        perc = int(done / total_bytes * 100) if total_bytes else 50
                        with self._lock:
                            self._speed_mbs  = spd / (1024*1024)
                            self._eta_secs   = eta
                            self._bytes_done = done
                            self._perc       = min(perc, 99)
                        t_ref = now; done_ref = done
                    else:
                        with self._lock:
                            self._bytes_done = done
                            if total_bytes:
                                self._perc = min(int(done/total_bytes*100), 99)
        except Exception as exc:
            self.error = f'Write error: {exc}'; self._done = True; return
        if self.cancelled:
            try: os.unlink(self.zippath)
            except OSError: pass
        else:
            with self._lock:
                self._perc = 100; self._bytes_done = done; self._eta_secs = 0
        self._done = True


class Downloader:

    def __init__(self, url):
        self.url        = url
        self.user_agent = ('Mozilla/5.0 (Windows NT 10.0; Win64; x64) '
                           'AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36')
        self.headers = {'User-Agent': self.user_agent}
        self.timeout = 15
        self.retries = 2

    def get_urllib(self, decoding=True):
        import socket
        last = None
        for _ in range(self.retries + 1):
            try:
                req  = Request(self.url, headers=self.headers)
                resp = urlopen(req, timeout=self.timeout)
                return resp.read().decode('utf-8') if decoding else resp
            except (socket.timeout, OSError) as exc:
                last = exc; xbmc.sleep(400)
        raise last

    def get_length(self, response):
        try: return response.getheader('content-length')
        except KeyError: return None

    def verify_integrity(self, zippath, expected_size=None):
        if not os.path.exists(zippath):
            return False, 'File not found after download'
        actual = os.path.getsize(zippath)
        if actual == 0:
            return False, 'Downloaded file is empty'
        if expected_size and abs(actual - int(expected_size)) > 1024:
            return False, f'Size mismatch: got {actual} (expected ~{expected_size})'
        with open(zippath, 'rb') as fh:
            if fh.read(2) != b'PK':
                return False, 'Not a valid ZIP file'
        return True, 'OK'

    def download_build(self, name, zippath):
        dlg = DownloadDialog('download_progress.xml', ADDON_PATH,
                             build_name=name, url=self.url, zippath=zippath)
        dlg.doModal()
        cancelled, error = dlg.cancelled, dlg.error
        del dlg
        if cancelled:
            xbmcgui.Dialog().notification(ADDON_NAME, 'Download cancelled', icon=ICON)
            sys.exit()
        if error:
            xbmc.log(f'[luc_kodi.wizard] {error}', xbmc.LOGWARNING)
            xbmcgui.Dialog().notification(ADDON_NAME, error, icon=ICON, time=5000)
            try: os.unlink(zippath)
            except OSError: pass
            sys.exit()
        ok, reason = self.verify_integrity(zippath)
        if not ok:
            xbmc.log(f'[luc_kodi.wizard] Integrity: {reason}', xbmc.LOGWARNING)
            xbmcgui.Dialog().notification(ADDON_NAME, f'Integrity error: {reason}', icon=ICON, time=5000)
            try: os.unlink(zippath)
            except OSError: pass
            sys.exit()
