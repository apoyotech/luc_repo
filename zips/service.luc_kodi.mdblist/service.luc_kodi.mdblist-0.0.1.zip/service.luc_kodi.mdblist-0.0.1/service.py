import xbmc

from resources.lib.main_monitor import MainMonitor


def main():
    monitor = MainMonitor()

    xbmc.log("Starting luc_kodi.mdblist", level=xbmc.LOGINFO)

    monitor.waitForAbort()

    xbmc.log("Stopping luc_kodi.mdblist", level=xbmc.LOGINFO)


if __name__ == '__main__':
    main()
