import requests
import xbmc
import xbmcaddon

from resources.lib.timer import Timer
from resources.lib.utils import jsonrpc_request, fix_unique_ids


LUC_KODI_ADDON_ID = "plugin.video.luc_kodi"
SERVICE_NAME = "luc_kodi.mdblist"


class PlayerMonitor(xbmc.Player):
    def __init__(self):
        super().__init__()

        self.luc_addon = None
        self.settings = None
        self.interval_timer = None

        self.total_time = None
        self.current_time = None

        self.video_info = {}

        self.load_settings()

    def _log(self, msg: str, level=xbmc.LOGINFO):
        xbmc.log(f"{SERVICE_NAME}: {msg}", level=level)

    def show_message(self, message: str):
        try:
            if self.settings and self.settings.getBool("mdblist.notify"):
                jsonrpc_request("GUI.ShowNotification", {"title": SERVICE_NAME, "message": message})
        except Exception:
            # Never allow UI notification failures to break playback
            pass

    def load_settings(self):
        """Load settings from plugin.video.luc_kodi (not from this service addon)."""
        try:
            self.luc_addon = xbmcaddon.Addon(LUC_KODI_ADDON_ID)
            self.settings = self.luc_addon.getSettings()
        except Exception:
            self.luc_addon = None
            self.settings = None
            self._log("plugin.video.luc_kodi not found - service will stay idle", level=xbmc.LOGWARNING)

    def _is_enabled(self) -> bool:
        try:
            return bool(self.settings and self.settings.getBool("mdblist.enable"))
        except Exception:
            return False

    def build_payload(self):
        if not self.video_info:
            return None

        media_type = self.video_info.get("type")
        if media_type not in ("movie", "episode"):
            return None

        # Respect mediatype filters
        try:
            if not self.settings.getBool(f"mdblist.mediatype.{media_type}"):
                return None
        except Exception:
            return None

        total_time = self.getTotalTime() if self.isPlaying() else self.total_time
        current_time = self.getTime() if self.isPlaying() else self.current_time

        if total_time is not None:
            total_time = max(0, int(total_time))
        if current_time is not None:
            current_time = max(0, int(current_time))

        if not total_time or current_time is None:
            return None

        progress_percent = round((current_time / total_time) * 100, 2)

        app_version = None
        try:
            app_version = self.luc_addon.getAddonInfo("version") if self.luc_addon else None
        except Exception:
            app_version = None

        if media_type == "episode":
            tvshow = self.video_info.get("tvshow") or {}
            if isinstance(tvshow, dict):
                show_uniqueids = tvshow.get("uniqueid", {}) or {}
            else:
                show_uniqueids = {}
            show_ids = fix_unique_ids(show_uniqueids, media_type)
            return {
                "show": {
                    "ids": show_ids,
                    "season": {
                        "number": self.video_info.get("season"),
                        "episode": {"number": self.video_info.get("episode")}
                    }
                },
                "progress": progress_percent,
                "app_version": app_version,
            }

        if media_type == "movie":
            movie_ids = fix_unique_ids(self.video_info.get("uniqueid", {}), media_type)
            return {
                "movie": {"ids": movie_ids},
                "progress": progress_percent,
                "app_version": app_version,
            }

        return None

    def event_to_endpoint(self, event: str):
        if event in ["start", "resume", "seek", "interval"]:
            return "/scrobble/start"
        if event == "pause":
            return "/scrobble/pause"
        if event in ["stop", "end"]:
            return "/scrobble/stop"
        return None

    def send_request(self, event: str):
        if not self._is_enabled():
            return

        try:
            if not self.settings.getBool(f"mdblist.event.{event}"):
                return
        except Exception:
            return

        json_data = self.build_payload()
        if not json_data:
            return

        base_url = self.settings.getString("mdblist.url") if self.settings else ""
        if not base_url:
            self._log("MDBList API URL not configured!", level=xbmc.LOGERROR)
            self.show_message("MDBList API URL not configured!")
            return

        apikey = self.settings.getString("mdblist.apikey") if self.settings else ""
        if not apikey:
            self._log("MDBList API key not configured!", level=xbmc.LOGERROR)
            self.show_message("MDBList API key not configured!")
            return

        endpoint = self.event_to_endpoint(event)
        if not endpoint:
            return

        if base_url.endswith("/"):
            base_url = base_url[:-1]

        url = f"{base_url}{endpoint}?apikey={apikey}"

        try:
            response = requests.post(url, json=json_data, timeout=15)
            if response.status_code >= 400:
                self.show_message(f"API Error {response.status_code}: {response.text[:50]}")
            response.raise_for_status()
        except requests.exceptions.HTTPError:
            # Already notified above
            pass
        except Exception as exception:
            self._log(f"Request failed - {exception}", level=xbmc.LOGERROR)
            self.show_message(f"Request failed: {str(exception)[:50]}")

    def fetch_video_info(self):
        try:
            self.video_info = jsonrpc_request(
                "Player.GetItem",
                {"playerid": 1, "properties": ["tvshowid", "showtitle", "season", "episode", "firstaired", "premiered", "year", "uniqueid"]},
            ).get("item")
        except Exception:
            self.video_info = None

        if not self.video_info:
            return

        if self.video_info.get("type") == "episode":
            try:
                self.video_info["tvshow"] = jsonrpc_request(
                    "VideoLibrary.GetTVShowDetails",
                    {"tvshowid": self.video_info.get("tvshowid"), "properties": ["uniqueid"]},
                ).get("tvshowdetails")
            except Exception:
                self.video_info["tvshow"] = {}

    def start_interval_timer(self):
        if not self._is_enabled():
            return
        try:
            if not self.settings.getBool("mdblist.interval.enabled"):
                return
            seconds = int(self.settings.getInt("mdblist.interval.seconds"))
            if seconds <= 0:
                return
        except Exception:
            return

        self.interval_timer = Timer(seconds, self.onInterval)
        self.interval_timer.start()

    def stop_interval_timer(self):
        if not self.interval_timer or not self.interval_timer.is_alive():
            return
        self.interval_timer.stop()

    def update_time(self):
        if self.isPlaying():
            self.total_time = self.getTotalTime()
            self.current_time = self.getTime()

    # --- Kodi Player callbacks ---

    def onAVStarted(self):
        self.load_settings()
        if not self._is_enabled():
            return

        self.fetch_video_info()
        self.update_time()

        self.send_request("start")
        self.start_interval_timer()

    def onPlayBackPaused(self):
        if not self._is_enabled() or not self.video_info:
            return
        self.update_time()
        self.send_request("pause")
        self.stop_interval_timer()

    def onPlayBackResumed(self):
        if not self._is_enabled() or not self.video_info:
            return
        self.send_request("resume")
        self.start_interval_timer()

    def onPlayBackStopped(self):
        if not self._is_enabled() or not self.video_info:
            return
        self.send_request("stop")
        self.stop_interval_timer()

    def onPlayBackEnded(self):
        if not self._is_enabled() or not self.video_info:
            return
        self.send_request("end")
        self.stop_interval_timer()

    def onPlayBackSeek(self, time: int, seekOffset: int):
        if not self._is_enabled() or not self.video_info:
            return
        self.update_time()
        self.send_request("seek")

    def onPlayBackSeekChapter(self, chapter: int):
        if not self._is_enabled() or not self.video_info:
            return
        self.update_time()
        self.send_request("seek")

    def onInterval(self):
        if not self._is_enabled() or not self.video_info:
            return
        self.update_time()
        self.send_request("interval")
