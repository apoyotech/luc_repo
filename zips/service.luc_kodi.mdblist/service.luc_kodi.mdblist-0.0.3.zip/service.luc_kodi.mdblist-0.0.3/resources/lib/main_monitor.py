import xbmc

from resources.lib.player_monitor import PlayerMonitor


class MainMonitor(xbmc.Monitor):
    def __init__(self):
        super().__init__()

        self.player_monitor = PlayerMonitor()
        self._import_server_progress()

    def onSettingsChanged(self):
        self.player_monitor.load_settings()
        self._import_server_progress()

    def _import_server_progress(self):
        """
        On startup (and settings change), pull paused items from the MDBList
        server and seed the local progress_db.  This ensures Continue Watching
        shows items even before the user plays anything with the new service.
        """
        try:
            settings = self.player_monitor.settings
            if not settings:
                return
            if not settings.getBool('mdblist.enable'):
                return

            base_url = settings.getString('mdblist.url').rstrip('/')
            apikey   = settings.getString('mdblist.apikey')
            if not base_url or not apikey:
                return

            import requests
            from resources.lib import progress_db

            resp = requests.get(
                '%s/scrobble' % base_url,
                params={'apikey': apikey},
                timeout=15,
            )
            if resp.status_code != 200:
                return
            data = resp.json()
            if not isinstance(data, dict):
                return

            # Import paused movies
            for m in (data.get('movies') or []):
                try:
                    mv  = m.get('movie') or m
                    ids = mv.get('ids') or {}
                    pct = float(m.get('progress') or 0)
                    if pct <= 0 or pct >= 85:
                        continue
                    runtime_min = int(mv.get('runtime') or 0)
                    progress_db.save_progress(
                        media_type='movie',
                        imdb=str(ids.get('imdb') or ''),
                        tmdb=str(ids.get('tmdb') or '') if ids.get('tmdb') else '',
                        tvdb='',
                        title=mv.get('title', ''),
                        tvshowtitle='',
                        season='',
                        episode_num='',
                        duration=str(runtime_min * 60),
                        progress_pct=pct,
                    )
                    # Patch paused_at timestamp from server
                    _patch_paused_at(ids, '', '', m.get('paused_at', ''))
                except Exception:
                    pass

            # Import paused episodes
            for ep in (data.get('shows') or []):
                try:
                    sh  = ep.get('show') or {}
                    epd = ep.get('episode') or {}
                    ids = sh.get('ids') or {}
                    pct = float(ep.get('progress') or 0)
                    if pct <= 0 or pct >= 85:
                        continue
                    runtime_min = int(epd.get('runtime') or sh.get('runtime') or 0)
                    progress_db.save_progress(
                        media_type='episode',
                        imdb=str(ids.get('imdb') or ''),
                        tmdb=str(ids.get('tmdb') or '') if ids.get('tmdb') else '',
                        tvdb=str(ids.get('tvdb') or '') if ids.get('tvdb') else '',
                        title=epd.get('title', ''),
                        tvshowtitle=sh.get('title', ''),
                        season=str(epd.get('season') or ''),
                        episode_num=str(epd.get('number') or ''),
                        duration=str(runtime_min * 60),
                        progress_pct=pct,
                    )
                    _patch_paused_at(ids,
                                     str(epd.get('season') or ''),
                                     str(epd.get('number') or ''),
                                     ep.get('paused_at', ''))
                except Exception:
                    pass

        except Exception as exc:
            xbmc.log('luc_kodi.mdblist: _import_server_progress failed: %s' % exc,
                     level=xbmc.LOGWARNING)


def _patch_paused_at(ids, season, episode_num, paused_at):
    """Update paused_at timestamp in local DB after save_progress."""
    if not paused_at:
        return
    try:
        import sqlite3, xbmcvfs, os
        folder = xbmcvfs.translatePath(
            'special://profile/addon_data/service.luc_kodi.mdblist'
        )
        db_path = os.path.join(folder, 'progress.db')
        if not xbmcvfs.exists(db_path):
            return
        conn = sqlite3.connect(db_path, timeout=5)
        cur  = conn.cursor()
        imdb = str(ids.get('imdb') or '')
        tmdb = str(ids.get('tmdb') or '') if ids.get('tmdb') else ''
        tvdb = str(ids.get('tvdb') or '') if ids.get('tvdb') else ''
        cur.execute(
            '''UPDATE progress SET paused_at=?
               WHERE imdb=? AND tmdb=? AND tvdb=? AND season=? AND episode_num=?''',
            (paused_at, imdb, tmdb, tvdb, season, episode_num),
        )
        conn.commit()
        conn.close()
    except Exception:
        pass
