import requests
import xbmc
import xbmcaddon

from resources.lib.timer import Timer
from resources.lib.utils import jsonrpc_request, fix_unique_ids
from resources.lib import progress_db


LUC_KODI_ADDON_ID = "plugin.video.luc_kodi"
SERVICE_NAME      = "luc_kodi.mdblist"


class PlayerMonitor(xbmc.Player):
    def __init__(self):
        super().__init__()

        self.luc_addon = None
        self.settings  = None
        self.interval_timer = None

        self.total_time   = None
        self.current_time = None

        self.video_info = {}

        # Cache TMDB/IMDB -> TVDB lookups: once per show per Kodi session
        self._id_cache = {}

        self.load_settings()

    # ------------------------------------------------------------------
    def _log(self, msg: str, level=xbmc.LOGINFO):
        xbmc.log(f"{SERVICE_NAME}: {msg}", level=level)

    def show_message(self, message: str):
        try:
            if self.settings and self.settings.getBool("mdblist.notify"):
                jsonrpc_request("GUI.ShowNotification", {"title": SERVICE_NAME, "message": message})
        except Exception:
            pass

    # ------------------------------------------------------------------
    def load_settings(self):
        try:
            self.luc_addon = xbmcaddon.Addon(LUC_KODI_ADDON_ID)
            self.settings  = self.luc_addon.getSettings()
        except Exception:
            self.luc_addon = None
            self.settings  = None
            self._log("plugin.video.luc_kodi not found – service idle", level=xbmc.LOGWARNING)

    def _is_enabled(self) -> bool:
        try:
            return bool(self.settings and self.settings.getBool("mdblist.enable"))
        except Exception:
            return False

    # ------------------------------------------------------------------
    # ID resolution  (4-level cascade)
    # ------------------------------------------------------------------

    def _resolve_show_ids(self, show_ids: dict) -> dict:
        """
        Make sure the show dict has at least one ID MDBList accepts.

        Level 1 – already has tvdb or imdb   → return immediately.
        Level 2 – has tmdb                   → GET /tm/{tmdb_id}
        Level 3 – has imdb                   → GET /?i={imdb_id}
        Level 4 – has _showtitle/_showyear   → GET /search/show?s=…

        All results are cached in self._id_cache.
        """
        # Level 1
        if show_ids.get("tvdb") or show_ids.get("imdb"):
            return show_ids

        base_url = (self.settings.getString("mdblist.url") if self.settings else "").rstrip("/")
        apikey   =  self.settings.getString("mdblist.apikey") if self.settings else ""
        if not base_url or not apikey:
            return show_ids

        def _get_ids_from_url(url):
            try:
                r = requests.get(url, timeout=10)
                r.raise_for_status()
                data = r.json()
                if isinstance(data, list):
                    return data
                ids_block = data.get("ids") or {}
                return {
                    "tvdb": str(ids_block.get("tvdb") or data.get("tvdb_id") or ""),
                    "imdb": str(ids_block.get("imdb") or ""),
                }
            except Exception as exc:
                self._log(f"ID lookup failed ({url}): {exc}", level=xbmc.LOGWARNING)
                return {}

        # Level 2 – TMDB
        if show_ids.get("tmdb"):
            key = f"tmdb:{show_ids['tmdb']}"
            if key in self._id_cache:
                show_ids.update(self._id_cache[key])
                return show_ids
            result = _get_ids_from_url(f"{base_url}/tm/{show_ids['tmdb']}?apikey={apikey}")
            if isinstance(result, dict) and (result.get("tvdb") or result.get("imdb")):
                result = {k: v for k, v in result.items() if v and str(v) not in ("", "None", "0")}
                self._id_cache[key] = result
                show_ids.update(result)
                self._log(f"Resolved tmdb:{show_ids.get('tmdb')} -> {result}")
                return show_ids

        # Level 3 – IMDb (may already have it but no tvdb yet)
        if show_ids.get("imdb"):
            key = f"imdb:{show_ids['imdb']}"
            if key in self._id_cache:
                show_ids.update(self._id_cache[key])
                return show_ids
            result = _get_ids_from_url(f"{base_url}/?i={show_ids['imdb']}&apikey={apikey}")
            if isinstance(result, dict) and result.get("tvdb"):
                result = {k: v for k, v in result.items() if v and str(v) not in ("", "None", "0")}
                self._id_cache[key] = result
                show_ids.update(result)
                self._log(f"Resolved imdb:{show_ids.get('imdb')} -> {result}")
                return show_ids

        # Level 4 – title search
        showtitle = show_ids.pop("_showtitle", None)
        showyear  = show_ids.pop("_showyear",  None)
        if showtitle:
            key = f"title:{showtitle}:{showyear}"
            if key in self._id_cache:
                show_ids.update(self._id_cache[key])
                return show_ids
            try:
                r = requests.get(
                    f"{base_url}/search/show",
                    params={"s": showtitle, "apikey": apikey},
                    timeout=10,
                )
                r.raise_for_status()
                raw = r.json()
                results = raw if isinstance(raw, list) else (raw.get("search") or [])
                best = None
                for item in results[:10]:
                    ids_block = item.get("ids") or {}
                    if str(item.get("year","")) == str(showyear) and ids_block.get("tvdb"):
                        best = ids_block
                        break
                if best is None and results:
                    best = results[0].get("ids") or {}
                if best and (best.get("tvdb") or best.get("imdb")):
                    result = {
                        "tvdb": str(best.get("tvdb") or ""),
                        "imdb": str(best.get("imdb") or ""),
                    }
                    result = {k: v for k, v in result.items() if v and str(v) not in ("", "None", "0")}
                    self._id_cache[key] = result
                    show_ids.update(result)
                    self._log(f"Resolved title:'{showtitle}'({showyear}) -> {result}")
            except Exception as exc:
                self._log(f"Title search failed: {exc}", level=xbmc.LOGWARNING)

        return show_ids

    # ------------------------------------------------------------------
    # Payload builder
    # ------------------------------------------------------------------

    def build_payload(self):
        if not self.video_info:
            return None

        media_type = self.video_info.get("type")
        if media_type not in ("movie", "episode"):
            return None

        try:
            if not self.settings.getBool(f"mdblist.mediatype.{media_type}"):
                return None
        except Exception:
            return None

        total_time   = self.getTotalTime() if self.isPlaying() else self.total_time
        current_time = self.getTime()      if self.isPlaying() else self.current_time

        if total_time   is not None: total_time   = max(0, int(total_time))
        if current_time is not None: current_time = max(0, int(current_time))
        if not total_time or current_time is None:
            return None

        progress = round((current_time / total_time) * 100, 2)

        try:
            app_version = self.luc_addon.getAddonInfo("version") if self.luc_addon else None
        except Exception:
            app_version = None

        # -- EPISODE --
        if media_type == "episode":
            tvshow = self.video_info.get("tvshow") or {}
            raw_ids = (tvshow.get("uniqueid") or {}) if isinstance(tvshow, dict) else {}

            show_ids = fix_unique_ids(dict(raw_ids), "episode")

            # Pass title/year for Level-4 title-search fallback
            if not (show_ids.get("tmdb") or show_ids.get("imdb") or show_ids.get("tvdb")):
                show_ids["_showtitle"] = self.video_info.get("_showtitle", "")
                show_ids["_showyear"]  = self.video_info.get("_showyear",  "")

            show_ids = self._resolve_show_ids(show_ids)

            # Strip private helper keys
            show_ids.pop("_showtitle", None)
            show_ids.pop("_showyear",  None)

            # Keep only real, non-empty ID keys
            show_ids = {k: v for k, v in show_ids.items()
                        if v and str(v) not in ("", "None", "0")}

            if not show_ids:
                self._log("No usable show IDs – scrobble skipped", level=xbmc.LOGWARNING)
                return None

            return {
                "show": {
                    "ids": show_ids,
                    "season": {
                        "number":  self.video_info.get("season"),
                        "episode": {"number": self.video_info.get("episode")},
                    },
                },
                "progress":    progress,
                "app_version": app_version,
            }

        # -- MOVIE --
        if media_type == "movie":
            movie_ids = fix_unique_ids(dict(self.video_info.get("uniqueid") or {}), "movie")
            movie_ids = {k: v for k, v in movie_ids.items()
                         if v and str(v) not in ("", "None", "0")}
            if not movie_ids:
                self._log("No usable movie IDs – scrobble skipped", level=xbmc.LOGWARNING)
                return None
            return {
                "movie":       {"ids": movie_ids},
                "progress":    progress,
                "app_version": app_version,
            }

        return None

    # ------------------------------------------------------------------
    def event_to_endpoint(self, event: str):
        if event in ("start", "resume", "seek", "interval"):
            return "/scrobble/start"
        if event == "pause":
            return "/scrobble/pause"
        if event in ("stop", "end"):
            return "/scrobble/stop"
        return None

    def send_request(self, event: str):
        if not self._is_enabled():
            return
        try:
            if not self.settings.getBool(f"mdblist.event.{event}"):
                return
        except Exception:
            return

        json_data = self.build_payload()
        if not json_data:
            return

        base_url = (self.settings.getString("mdblist.url") if self.settings else "").rstrip("/")
        apikey   =  self.settings.getString("mdblist.apikey") if self.settings else ""
        if not base_url:
            self._log("MDBList API URL not configured!", level=xbmc.LOGERROR)
            self.show_message("MDBList API URL not configured!")
            return
        if not apikey:
            self._log("MDBList API key not configured!", level=xbmc.LOGERROR)
            self.show_message("MDBList API key not configured!")
            return

        endpoint = self.event_to_endpoint(event)
        if not endpoint:
            return

        url = f"{base_url}{endpoint}?apikey={apikey}"
        try:
            response = requests.post(url, json=json_data, timeout=15)
            if response.status_code >= 400:
                self.show_message(f"API Error {response.status_code}: {response.text[:80]}")
                self._log(
                    f"API {response.status_code} event={event} "
                    f"payload={str(json_data)[:300]}\n"
                    f"response={response.text[:300]}",
                    level=xbmc.LOGWARNING,
                )
            response.raise_for_status()
        except requests.exceptions.HTTPError:
            pass
        except Exception as exc:
            self._log(f"Request failed – {exc}", level=xbmc.LOGERROR)
            self.show_message(f"Request failed: {str(exc)[:50]}")

    # ------------------------------------------------------------------
    # Video info
    # ------------------------------------------------------------------

    def fetch_video_info(self):
        """
        Collect episode/movie info for the currently playing item.

        For STREAMED content from luc_kodi:
          tvshowid = -1  →  VideoLibrary.GetTVShowDetails fails
          BUT Player.GetItem returns the episode item's uniqueid which
          luc_kodi populates via control.infoTagger() → setUniqueIDs().
          Those IDs (imdb, tmdb, tvdb) are the SHOW-level IDs.
          We use them as the fallback show_ids.
        """
        try:
            self.video_info = jsonrpc_request(
                "Player.GetItem",
                {
                    "playerid": 1,
                    "properties": [
                        "tvshowid", "showtitle", "season", "episode",
                        "year", "premiered", "firstaired", "uniqueid",
                    ],
                },
            ).get("item") or {}
        except Exception:
            self.video_info = {}
            return

        if not self.video_info or self.video_info.get("type") != "episode":
            return

        # Derive year for title-search fallback
        year = ""
        for field in ("premiered", "firstaired", "year"):
            val = str(self.video_info.get(field) or "")
            if val and val not in ("", "0"):
                year = val[:4]
                break

        self.video_info["_showtitle"] = (self.video_info.get("showtitle") or "").strip()
        self.video_info["_showyear"]  = year

        # Path A: local library (tvshowid > 0)
        tvshow_ids = {}
        try:
            tvshowid = int(str(self.video_info.get("tvshowid", -1)))
            if tvshowid > 0:
                details = jsonrpc_request(
                    "VideoLibrary.GetTVShowDetails",
                    {"tvshowid": tvshowid, "properties": ["uniqueid"]},
                ).get("tvshowdetails") or {}
                tvshow_ids = details.get("uniqueid") or {}
        except Exception:
            pass

        # Path B: streamed content – use the episode item's own uniqueid
        #          (set by luc_kodi's infoTagger → setUniqueIDs)
        if not tvshow_ids:
            tvshow_ids = self.video_info.get("uniqueid") or {}
            if tvshow_ids:
                self._log(
                    f"Streamed content – using episode uniqueid as show IDs: {tvshow_ids}"
                )

        self.video_info["tvshow"] = {"uniqueid": tvshow_ids}
        self._log(
            f"fetch_video_info episode  show_ids={tvshow_ids}  "
            f"S{self.video_info.get('season')}E{self.video_info.get('episode')}  "
            f"title='{self.video_info.get('_showtitle')}'  year={year}"
        )

    # ------------------------------------------------------------------
    # Timer
    # ------------------------------------------------------------------

    def start_interval_timer(self):
        if not self._is_enabled():
            return
        try:
            if not self.settings.getBool("mdblist.interval.enabled"):
                return
            seconds = int(self.settings.getInt("mdblist.interval.seconds"))
            if seconds <= 0:
                return
        except Exception:
            return
        self.interval_timer = Timer(seconds, self.onInterval)
        self.interval_timer.start()

    def stop_interval_timer(self):
        if self.interval_timer and self.interval_timer.is_alive():
            self.interval_timer.stop()

    def update_time(self):
        if self.isPlaying():
            self.total_time   = self.getTotalTime()
            self.current_time = self.getTime()

    def _save_local_progress(self):
        """
        Save current playback position to the local progress DB.
        This is independent of Trakt and MDBList scrobble — it powers
        the 'Continue Watching' sections in the plugin.
        """
        try:
            if not self.video_info:
                return
            media_type = self.video_info.get("type")
            if media_type not in ("movie", "episode"):
                return

            total   = self.total_time   or 0
            current = self.current_time or 0
            if total <= 0:
                return
            pct = (current / total) * 100

            # Shared fields
            tvshow = self.video_info.get("tvshow") or {}
            show_ids = (tvshow.get("uniqueid") or {}) if isinstance(tvshow, dict) else {}

            if media_type == "movie":
                movie_ids = self.video_info.get("uniqueid") or {}
                progress_db.save_progress(
                    media_type="movie",
                    imdb=str(movie_ids.get("imdb") or ""),
                    tmdb=str(movie_ids.get("tmdb") or ""),
                    tvdb="",
                    title=self.video_info.get("label") or self.video_info.get("title") or "",
                    tvshowtitle="",
                    season="",
                    episode_num="",
                    duration=str(int(total)),
                    progress_pct=pct,
                )
            else:  # episode
                progress_db.save_progress(
                    media_type="episode",
                    imdb=str(show_ids.get("imdb") or ""),
                    tmdb=str(show_ids.get("tmdb") or ""),
                    tvdb=str(show_ids.get("tvdb") or ""),
                    title=self.video_info.get("label") or self.video_info.get("title") or "",
                    tvshowtitle=self.video_info.get("_showtitle") or self.video_info.get("showtitle") or "",
                    season=str(self.video_info.get("season") or ""),
                    episode_num=str(self.video_info.get("episode") or ""),
                    duration=str(int(total)),
                    progress_pct=pct,
                )
        except Exception as exc:
            self._log(f"_save_local_progress failed: {exc}", level=xbmc.LOGWARNING)

    # ------------------------------------------------------------------
    # Kodi callbacks
    # ------------------------------------------------------------------

    def onAVStarted(self):
        self.load_settings()
        if not self._is_enabled():
            return
        self.fetch_video_info()
        self.update_time()
        self.send_request("start")
        self.start_interval_timer()

    def onPlayBackPaused(self):
        if not self._is_enabled() or not self.video_info:
            return
        self.update_time()
        self._save_local_progress()
        self.send_request("pause")
        self.stop_interval_timer()

    def onPlayBackResumed(self):
        if not self._is_enabled() or not self.video_info:
            return
        self.send_request("resume")
        self.start_interval_timer()

    def onPlayBackStopped(self):
        if not self._is_enabled() or not self.video_info:
            return
        self.update_time()
        self._save_local_progress()
        self.send_request("stop")
        self.stop_interval_timer()

    def onPlayBackEnded(self):
        if not self._is_enabled() or not self.video_info:
            return
        self.update_time()
        self._save_local_progress()   # progress >= 85 → auto-deleted in save_progress
        self.send_request("end")
        self.stop_interval_timer()

    def onPlayBackSeek(self, time: int, seekOffset: int):
        if not self._is_enabled() or not self.video_info:
            return
        self.update_time()
        self.send_request("seek")

    def onPlayBackSeekChapter(self, chapter: int):
        if not self._is_enabled() or not self.video_info:
            return
        self.update_time()
        self.send_request("seek")

    def onInterval(self):
        if not self._is_enabled() or not self.video_info:
            return
        self.update_time()
        self._save_local_progress()
        self.send_request("interval")
