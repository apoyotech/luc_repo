import queue
import threading
import time

import requests
import xbmc
import xbmcaddon

from resources.lib.timer import Timer
from resources.lib.utils import jsonrpc_request, fix_unique_ids
from resources.lib import progress_db


LUC_KODI_ADDON_ID = "plugin.video.luc_kodi"
SERVICE_NAME      = "luc_kodi.mdblist"

# ---------------------------------------------------------------------------
# Tunables
# ---------------------------------------------------------------------------
_HTTP_CONNECT_TIMEOUT = 5      # seconds
_HTTP_READ_TIMEOUT    = 10     # seconds
_HTTP_RETRY_DELAY     = 2.0    # seconds between retry attempts
_HTTP_MAX_ATTEMPTS    = 2      # initial + 1 retry
_ID_MISS_TTL          = 300    # 5 min — cache failed ID lookups so we don't
                               # re-query MDBList every 60 s for shows whose
                               # IDs cannot be resolved.
_QUEUE_MAX            = 64     # cap queue size to avoid runaway growth
                               # if the user goes wild seeking with no network.
_USER_AGENT           = "luc_kodi.mdblist/0.0.5 (Kodi)"

# Exceptions that we treat as "transient connection issues":
# log only, NEVER show as a popup notification, since these are typically
# harmless (Wi-Fi blip, DNS hiccup, SSL handshake retry) and should not
# spam the user mid-playback.
_TRANSIENT_EXC = (
    requests.exceptions.ConnectionError,
    requests.exceptions.Timeout,
    requests.exceptions.ChunkedEncodingError,
)


class PlayerMonitor(xbmc.Player):
    def __init__(self):
        super().__init__()

        self.interval_timer = None

        self.total_time   = None
        self.current_time = None

        self.video_info = {}

        # Positive cache: TMDB/IMDB -> {tvdb, imdb}, once per show per session
        self._id_cache = {}

        # Negative cache: input fingerprint -> timestamp of last failed resolve
        # Avoids hammering MDBList every interval for shows we cannot resolve.
        self._id_misses = {}
        self._id_lock   = threading.Lock()

        # ------------------------------------------------------------------
        # Async scrobble worker
        # ------------------------------------------------------------------
        # Why: every player callback (start/pause/resume/stop/end/seek) used
        # to make a synchronous requests.post() with a 15 s timeout. If the
        # network was slow, Kodi's player thread froze for up to 15 s — and
        # on Android tablets that meant pause/seek/stop visibly hung the UI,
        # plus onPlayBackStopped/onPlayBackEnded delayed Kodi's own cleanup.
        #
        # Now the player callbacks just snapshot state and drop a job onto
        # this queue. A single daemon worker drains it and does ALL the
        # HTTP work (ID resolution + scrobble POST) off the player thread.
        # ------------------------------------------------------------------
        self._scrobble_q = queue.Queue(maxsize=_QUEUE_MAX)
        self._stop_event = threading.Event()
        self._worker = threading.Thread(
            target=self._scrobble_worker_loop,
            daemon=True,
            name="luc_kodi.mdblist.scrobble_worker",
        )
        self._worker.start()

    # ------------------------------------------------------------------
    # Settings: ALWAYS read fresh from Kodi — never cache
    # ------------------------------------------------------------------
    # See v0.0.4 notes for the reasoning behind not caching the Settings
    # snapshot — onSettingsChanged() does NOT fire for plugin.video.luc_kodi
    # changes, so we re-read every time.
    # ------------------------------------------------------------------

    def _fresh_addon(self):
        """Return a fresh Addon instance for plugin.video.luc_kodi."""
        return xbmcaddon.Addon(LUC_KODI_ADDON_ID)

    def _get_bool(self, setting_id: str, default: bool = False) -> bool:
        try:
            return self._fresh_addon().getSetting(setting_id) == "true"
        except Exception:
            return default

    def _get_str(self, setting_id: str, default: str = "") -> str:
        try:
            return self._fresh_addon().getSetting(setting_id) or default
        except Exception:
            return default

    def _get_int(self, setting_id: str, default: int = 0) -> int:
        try:
            v = self._fresh_addon().getSetting(setting_id)
            return int(v) if v else default
        except Exception:
            return default

    # ------------------------------------------------------------------
    def _log(self, msg: str, level=xbmc.LOGINFO):
        xbmc.log(f"{SERVICE_NAME}: {msg}", level=level)

    def _show_message(self, message: str, transient: bool = False):
        """
        Show a popup. Transient errors (network blips) are LOGGED only —
        never shown as a popup, since they are typically self-healing.
        """
        if transient:
            return
        try:
            if self._get_bool("mdblist.notify"):
                jsonrpc_request("GUI.ShowNotification",
                                {"title": SERVICE_NAME, "message": message})
        except Exception:
            pass

    # Backwards-compat alias (kept in case anything external referenced it)
    def show_message(self, message: str):
        self._show_message(message)

    def _is_enabled(self) -> bool:
        return self._get_bool("mdblist.enable")

    # ------------------------------------------------------------------
    # ID resolution  (4-level cascade)  with negative cache
    # ------------------------------------------------------------------

    @staticmethod
    def _miss_key(show_ids: dict) -> str:
        """Stable fingerprint of the inputs we tried to resolve."""
        return (
            f"tmdb:{show_ids.get('tmdb','')}"
            f"|imdb:{show_ids.get('imdb','')}"
            f"|t:{show_ids.get('_showtitle','')}:{show_ids.get('_showyear','')}"
        )

    def _resolve_show_ids(self, show_ids: dict) -> dict:
        """
        Make sure the show dict has at least one ID MDBList accepts.

        Level 1 – already has tvdb or imdb   → return immediately.
        Level 2 – has tmdb                   → GET /tm/{tmdb_id}
        Level 3 – has imdb                   → GET /?i={imdb_id}
        Level 4 – has _showtitle/_showyear   → GET /search/show?s=…

        Positive results cached in self._id_cache.
        Negative (all-paths-failed) cached in self._id_misses with TTL,
        so we don't query MDBList every 60 s for unresolvable shows.
        """
        # Level 1
        if show_ids.get("tvdb") or show_ids.get("imdb"):
            return show_ids

        # Negative cache — short-circuit if we recently failed to resolve this
        miss_key = self._miss_key(show_ids)
        with self._id_lock:
            ts = self._id_misses.get(miss_key)
        if ts is not None and (time.time() - ts) < _ID_MISS_TTL:
            return show_ids

        base_url = self._get_str("mdblist.url").rstrip("/")
        apikey   = self._get_str("mdblist.apikey")
        if not base_url or not apikey:
            return show_ids

        def _get_ids_from_url(url, params=None):
            try:
                r = requests.get(
                    url,
                    params=params,
                    timeout=(_HTTP_CONNECT_TIMEOUT, _HTTP_READ_TIMEOUT),
                    headers={"User-Agent": _USER_AGENT},
                )
                r.raise_for_status()
                data = r.json()
                if isinstance(data, list):
                    return data
                ids_block = data.get("ids") or {}
                return {
                    "tvdb": str(ids_block.get("tvdb") or data.get("tvdb_id") or ""),
                    "imdb": str(ids_block.get("imdb") or ""),
                }
            except _TRANSIENT_EXC as exc:
                # Network blip — log quietly, no popup
                self._log(f"ID lookup transient fail ({url}): {exc}",
                          level=xbmc.LOGDEBUG)
                return {}
            except Exception as exc:
                self._log(f"ID lookup failed ({url}): {exc}",
                          level=xbmc.LOGWARNING)
                return {}

        resolved = False

        # Level 2 – TMDB
        if show_ids.get("tmdb"):
            key = f"tmdb:{show_ids['tmdb']}"
            with self._id_lock:
                cached = self._id_cache.get(key)
            if cached is not None:
                show_ids.update(cached)
                return show_ids
            result = _get_ids_from_url(
                f"{base_url}/tm/{show_ids['tmdb']}",
                params={"apikey": apikey},
            )
            if isinstance(result, dict) and (result.get("tvdb") or result.get("imdb")):
                result = {k: v for k, v in result.items()
                          if v and str(v) not in ("", "None", "0")}
                with self._id_lock:
                    self._id_cache[key] = result
                show_ids.update(result)
                self._log(f"Resolved tmdb:{show_ids.get('tmdb')} -> {result}")
                resolved = True

        # Level 3 – IMDb (may already have it but no tvdb yet)
        if not resolved and show_ids.get("imdb"):
            key = f"imdb:{show_ids['imdb']}"
            with self._id_lock:
                cached = self._id_cache.get(key)
            if cached is not None:
                show_ids.update(cached)
                return show_ids
            result = _get_ids_from_url(
                f"{base_url}/",
                params={"i": show_ids["imdb"], "apikey": apikey},
            )
            if isinstance(result, dict) and result.get("tvdb"):
                result = {k: v for k, v in result.items()
                          if v and str(v) not in ("", "None", "0")}
                with self._id_lock:
                    self._id_cache[key] = result
                show_ids.update(result)
                self._log(f"Resolved imdb:{show_ids.get('imdb')} -> {result}")
                resolved = True

        # Level 4 – title search
        if not resolved:
            showtitle = show_ids.pop("_showtitle", None)
            showyear  = show_ids.pop("_showyear",  None)
            if showtitle:
                key = f"title:{showtitle}:{showyear}"
                with self._id_lock:
                    cached = self._id_cache.get(key)
                if cached is not None:
                    show_ids.update(cached)
                    return show_ids
                try:
                    r = requests.get(
                        f"{base_url}/search/show",
                        params={"s": showtitle, "apikey": apikey},
                        timeout=(_HTTP_CONNECT_TIMEOUT, _HTTP_READ_TIMEOUT),
                        headers={"User-Agent": _USER_AGENT},
                    )
                    r.raise_for_status()
                    raw = r.json()
                    results = raw if isinstance(raw, list) else (raw.get("search") or [])
                    best = None
                    for item in results[:10]:
                        ids_block = item.get("ids") or {}
                        if str(item.get("year","")) == str(showyear) and ids_block.get("tvdb"):
                            best = ids_block
                            break
                    if best is None and results:
                        best = results[0].get("ids") or {}
                    if best and (best.get("tvdb") or best.get("imdb")):
                        result = {
                            "tvdb": str(best.get("tvdb") or ""),
                            "imdb": str(best.get("imdb") or ""),
                        }
                        result = {k: v for k, v in result.items()
                                  if v and str(v) not in ("", "None", "0")}
                        with self._id_lock:
                            self._id_cache[key] = result
                        show_ids.update(result)
                        self._log(f"Resolved title:'{showtitle}'({showyear}) -> {result}")
                        resolved = True
                except _TRANSIENT_EXC as exc:
                    self._log(f"Title search transient fail: {exc}",
                              level=xbmc.LOGDEBUG)
                except Exception as exc:
                    self._log(f"Title search failed: {exc}",
                              level=xbmc.LOGWARNING)

        # Negative cache — remember we failed so we don't keep hammering
        if not resolved and not (show_ids.get("tvdb") or show_ids.get("imdb")):
            with self._id_lock:
                self._id_misses[miss_key] = time.time()

        return show_ids

    # ------------------------------------------------------------------
    # Payload builder — works off a SNAPSHOT of state so it's safe to call
    # from the worker thread even if the player has moved on.
    # ------------------------------------------------------------------

    def _build_payload(self, snap: dict):
        video_info   = snap.get("video_info") or {}
        total_time   = snap.get("total_time")
        current_time = snap.get("current_time")

        if not video_info:
            return None

        media_type = video_info.get("type")
        if media_type not in ("movie", "episode"):
            return None

        if not self._get_bool(f"mdblist.mediatype.{media_type}", default=True):
            return None

        if total_time   is not None: total_time   = max(0, int(total_time))
        if current_time is not None: current_time = max(0, int(current_time))
        if not total_time or current_time is None:
            return None

        progress = round((current_time / total_time) * 100, 2)

        try:
            app_version = self._fresh_addon().getAddonInfo("version")
        except Exception:
            app_version = None

        # -- EPISODE --
        if media_type == "episode":
            tvshow = video_info.get("tvshow") or {}
            raw_ids = (tvshow.get("uniqueid") or {}) if isinstance(tvshow, dict) else {}

            show_ids = fix_unique_ids(dict(raw_ids), "episode")

            # Pass title/year for Level-4 title-search fallback
            if not (show_ids.get("tmdb") or show_ids.get("imdb") or show_ids.get("tvdb")):
                show_ids["_showtitle"] = video_info.get("_showtitle", "")
                show_ids["_showyear"]  = video_info.get("_showyear",  "")

            show_ids = self._resolve_show_ids(show_ids)

            # Strip private helper keys
            show_ids.pop("_showtitle", None)
            show_ids.pop("_showyear",  None)

            # Keep only real, non-empty ID keys
            show_ids = {k: v for k, v in show_ids.items()
                        if v and str(v) not in ("", "None", "0")}

            if not show_ids:
                self._log("No usable show IDs – scrobble skipped",
                          level=xbmc.LOGWARNING)
                return None

            return {
                "show": {
                    "ids": show_ids,
                    "season": {
                        "number":  video_info.get("season"),
                        "episode": {"number": video_info.get("episode")},
                    },
                },
                "progress":    progress,
                "app_version": app_version,
            }

        # -- MOVIE --
        if media_type == "movie":
            movie_ids = fix_unique_ids(dict(video_info.get("uniqueid") or {}), "movie")
            movie_ids = {k: v for k, v in movie_ids.items()
                         if v and str(v) not in ("", "None", "0")}
            if not movie_ids:
                self._log("No usable movie IDs – scrobble skipped",
                          level=xbmc.LOGWARNING)
                return None
            return {
                "movie":       {"ids": movie_ids},
                "progress":    progress,
                "app_version": app_version,
            }

        return None

    # ------------------------------------------------------------------
    @staticmethod
    def _event_to_endpoint(event: str):
        if event in ("start", "resume", "seek", "interval"):
            return "/scrobble/start"
        if event == "pause":
            return "/scrobble/pause"
        if event in ("stop", "end"):
            return "/scrobble/stop"
        return None

    # ------------------------------------------------------------------
    # Async dispatch — called from player thread (FAST, no HTTP)
    # ------------------------------------------------------------------

    def _dispatch(self, event: str):
        """Snapshot state on the player thread and queue the scrobble."""
        if not self._is_enabled():
            return
        if not self._get_bool(f"mdblist.event.{event}", default=True):
            return
        if not self.video_info:
            return

        # Capture live position now while we're guaranteed to be on the
        # player thread (and isPlaying() may be transitioning).
        try:
            live_total   = self.getTotalTime() if self.isPlaying() else None
            live_current = self.getTime()      if self.isPlaying() else None
        except Exception:
            live_total = live_current = None

        snap = {
            "event":        event,
            "video_info":   dict(self.video_info),
            "total_time":   live_total   if live_total   is not None else self.total_time,
            "current_time": live_current if live_current is not None else self.current_time,
        }

        try:
            self._scrobble_q.put_nowait(snap)
        except queue.Full:
            self._log(f"scrobble queue full, dropping '{event}'",
                      level=xbmc.LOGWARNING)

    # ------------------------------------------------------------------
    # Worker thread — drains queue, does HTTP work, never blocks the player
    # ------------------------------------------------------------------

    def _scrobble_worker_loop(self):
        while not self._stop_event.is_set():
            try:
                snap = self._scrobble_q.get(timeout=1.0)
            except queue.Empty:
                continue
            if snap is None:
                break
            try:
                self._send_scrobble(snap)
            except Exception as exc:
                self._log(f"worker uncaught: {exc}", level=xbmc.LOGERROR)

    def _send_scrobble(self, snap: dict):
        """Build payload + POST. Runs on the worker thread."""
        if not self._is_enabled():
            return

        event = snap.get("event")
        endpoint = self._event_to_endpoint(event)
        if not endpoint:
            return

        payload = self._build_payload(snap)
        if not payload:
            return

        base_url = self._get_str("mdblist.url").rstrip("/")
        apikey   = self._get_str("mdblist.apikey")

        if not base_url:
            self._log("MDBList API URL not configured!", level=xbmc.LOGERROR)
            self._show_message("MDBList API URL not configured!")
            return
        if not apikey:
            self._log("MDBList API key not configured!", level=xbmc.LOGERROR)
            self._show_message("MDBList API key not configured!")
            return

        url = f"{base_url}{endpoint}"
        last_exc = None
        for attempt in range(1, _HTTP_MAX_ATTEMPTS + 1):
            try:
                response = requests.post(
                    url,
                    params={"apikey": apikey},   # safe URL encoding
                    json=payload,
                    timeout=(_HTTP_CONNECT_TIMEOUT, _HTTP_READ_TIMEOUT),
                    headers={"User-Agent": _USER_AGENT},
                )
                if response.status_code >= 400:
                    # 4xx/5xx — these are real, persistent issues. Notify.
                    self._log(
                        f"API {response.status_code} event={event} "
                        f"payload={str(payload)[:300]} "
                        f"response={response.text[:300]}",
                        level=xbmc.LOGWARNING,
                    )
                    self._show_message(
                        f"API Error {response.status_code}: "
                        f"{response.text[:80]}"
                    )
                    return
                # 2xx — success
                return
            except _TRANSIENT_EXC as exc:
                last_exc = exc
                self._log(
                    f"transient fail event={event} attempt={attempt}: {exc}",
                    level=xbmc.LOGDEBUG,
                )
                if attempt < _HTTP_MAX_ATTEMPTS and not self._stop_event.is_set():
                    # Wait briefly before retry, but bail out fast on shutdown
                    self._stop_event.wait(_HTTP_RETRY_DELAY)
                    continue
                # Final attempt failed → log only, NO popup (these are noisy
                # connection-pool errors that the user shouldn't see).
                self._log(
                    f"transient fail final event={event}: {exc}",
                    level=xbmc.LOGINFO,
                )
                return
            except Exception as exc:
                # Anything else (JSON decode, etc.) — log and surface
                self._log(f"Request failed event={event}: {exc}",
                          level=xbmc.LOGERROR)
                self._show_message(f"Request failed: {str(exc)[:50]}")
                return
        # Should not reach here
        if last_exc is not None:
            self._log(f"unexpected fall-through: {last_exc}",
                      level=xbmc.LOGWARNING)

    # ------------------------------------------------------------------
    # Video info
    # ------------------------------------------------------------------

    def fetch_video_info(self):
        """
        Collect episode/movie info for the currently playing item.

        For STREAMED content from luc_kodi:
          tvshowid = -1  →  VideoLibrary.GetTVShowDetails fails
          BUT Player.GetItem returns the episode item's uniqueid which
          luc_kodi populates via control.infoTagger() → setUniqueIDs().
          Those IDs (imdb, tmdb, tvdb) are the SHOW-level IDs.
          We use them as the fallback show_ids.
        """
        try:
            self.video_info = jsonrpc_request(
                "Player.GetItem",
                {
                    "playerid": 1,
                    "properties": [
                        "tvshowid", "showtitle", "season", "episode",
                        "year", "premiered", "firstaired", "uniqueid",
                    ],
                },
            ).get("item") or {}
        except Exception:
            self.video_info = {}
            return

        if not self.video_info or self.video_info.get("type") != "episode":
            return

        # Derive year for title-search fallback
        year = ""
        for field in ("premiered", "firstaired", "year"):
            val = str(self.video_info.get(field) or "")
            if val and val not in ("", "0"):
                year = val[:4]
                break

        self.video_info["_showtitle"] = (self.video_info.get("showtitle") or "").strip()
        self.video_info["_showyear"]  = year

        # Path A: local library (tvshowid > 0)
        tvshow_ids = {}
        try:
            tvshowid = int(str(self.video_info.get("tvshowid", -1)))
            if tvshowid > 0:
                details = jsonrpc_request(
                    "VideoLibrary.GetTVShowDetails",
                    {"tvshowid": tvshowid, "properties": ["uniqueid"]},
                ).get("tvshowdetails") or {}
                tvshow_ids = details.get("uniqueid") or {}
        except Exception:
            pass

        # Path B: streamed content – use the episode item's own uniqueid
        #          (set by luc_kodi's infoTagger → setUniqueIDs)
        if not tvshow_ids:
            tvshow_ids = self.video_info.get("uniqueid") or {}
            if tvshow_ids:
                self._log(
                    f"Streamed content – using episode uniqueid as show IDs: {tvshow_ids}"
                )

        self.video_info["tvshow"] = {"uniqueid": tvshow_ids}
        self._log(
            f"fetch_video_info episode  show_ids={tvshow_ids}  "
            f"S{self.video_info.get('season')}E{self.video_info.get('episode')}  "
            f"title='{self.video_info.get('_showtitle')}'  year={year}"
        )

    # ------------------------------------------------------------------
    # Timer
    # ------------------------------------------------------------------

    def start_interval_timer(self):
        if not self._is_enabled():
            return
        if not self._get_bool("mdblist.interval.enabled", default=True):
            return
        seconds = self._get_int("mdblist.interval.seconds", default=60)
        if seconds <= 0:
            return
        # Defensive: stop any previous timer to avoid leaking threads if
        # Kodi fires onAVStarted twice in a row (which DOES happen for some
        # streams that re-resolve mid-start).
        self.stop_interval_timer()
        self.interval_timer = Timer(seconds, self.onInterval)
        self.interval_timer.start()

    def stop_interval_timer(self):
        if self.interval_timer and self.interval_timer.is_alive():
            self.interval_timer.stop()
        self.interval_timer = None

    def update_time(self):
        if self.isPlaying():
            try:
                self.total_time   = self.getTotalTime()
                self.current_time = self.getTime()
            except Exception:
                pass

    def _save_local_progress(self):
        """
        Save current playback position to the local progress DB.
        Independent of MDBList scrobble — powers Continue Watching.
        """
        try:
            if not self.video_info:
                return
            media_type = self.video_info.get("type")
            if media_type not in ("movie", "episode"):
                return

            total   = self.total_time   or 0
            current = self.current_time or 0
            if total <= 0:
                return
            pct = (current / total) * 100

            # Shared fields
            tvshow = self.video_info.get("tvshow") or {}
            show_ids = (tvshow.get("uniqueid") or {}) if isinstance(tvshow, dict) else {}

            if media_type == "movie":
                movie_ids = self.video_info.get("uniqueid") or {}
                imdb = str(movie_ids.get("imdb") or "")
                tmdb = str(movie_ids.get("tmdb") or "")
                # Skip if no IDs at all — otherwise multiple no-ID items would
                # collide on the UNIQUE(imdb,tmdb,tvdb,season,episode_num) key.
                if not (imdb or tmdb):
                    return
                progress_db.save_progress(
                    media_type="movie",
                    imdb=imdb,
                    tmdb=tmdb,
                    tvdb="",
                    title=self.video_info.get("label") or self.video_info.get("title") or "",
                    tvshowtitle="",
                    season="",
                    episode_num="",
                    duration=str(int(total)),
                    progress_pct=pct,
                )
            else:  # episode
                imdb = str(show_ids.get("imdb") or "")
                tmdb = str(show_ids.get("tmdb") or "")
                tvdb = str(show_ids.get("tvdb") or "")
                if not (imdb or tmdb or tvdb):
                    return
                progress_db.save_progress(
                    media_type="episode",
                    imdb=imdb,
                    tmdb=tmdb,
                    tvdb=tvdb,
                    title=self.video_info.get("label") or self.video_info.get("title") or "",
                    tvshowtitle=self.video_info.get("_showtitle") or self.video_info.get("showtitle") or "",
                    season=str(self.video_info.get("season") or ""),
                    episode_num=str(self.video_info.get("episode") or ""),
                    duration=str(int(total)),
                    progress_pct=pct,
                )
        except Exception as exc:
            self._log(f"_save_local_progress failed: {exc}",
                      level=xbmc.LOGWARNING)

    # ------------------------------------------------------------------
    # Kodi callbacks — must return FAST (no HTTP on this thread)
    # ------------------------------------------------------------------

    def onAVStarted(self):
        if not self._is_enabled():
            return
        self.fetch_video_info()
        self.update_time()
        self._dispatch("start")
        self.start_interval_timer()

    def onPlayBackPaused(self):
        if not self._is_enabled() or not self.video_info:
            return
        self.update_time()
        self._save_local_progress()
        self._dispatch("pause")
        self.stop_interval_timer()

    def onPlayBackResumed(self):
        if not self._is_enabled() or not self.video_info:
            return
        self._dispatch("resume")
        self.start_interval_timer()

    def onPlayBackStopped(self):
        if not self._is_enabled() or not self.video_info:
            return
        self.update_time()
        self._save_local_progress()
        self._dispatch("stop")
        self.stop_interval_timer()

    def onPlayBackEnded(self):
        if not self._is_enabled() or not self.video_info:
            return
        self.update_time()
        self._save_local_progress()   # progress >= 85 → auto-deleted in save_progress
        self._dispatch("end")
        self.stop_interval_timer()

    def onPlayBackSeek(self, time: int, seekOffset: int):
        if not self._is_enabled() or not self.video_info:
            return
        self.update_time()
        self._dispatch("seek")

    def onPlayBackSeekChapter(self, chapter: int):
        if not self._is_enabled() or not self.video_info:
            return
        self.update_time()
        self._dispatch("seek")

    def onInterval(self):
        if not self._is_enabled() or not self.video_info:
            return
        self.update_time()
        self._save_local_progress()
        self._dispatch("interval")

    # ------------------------------------------------------------------
    # Backwards-compat: external code may still call send_request directly
    # ------------------------------------------------------------------
    def send_request(self, event: str):
        """Legacy entry point — now goes through the async dispatcher."""
        self._dispatch(event)
