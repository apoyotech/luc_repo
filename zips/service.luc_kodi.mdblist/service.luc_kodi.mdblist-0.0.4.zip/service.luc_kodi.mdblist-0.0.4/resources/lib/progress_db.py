"""
progress_db.py  —  service.luc_kodi.mdblist

Local SQLite store for MDBList watch progress.
Written by the service (player_monitor.py) on every pause/stop.
Read by plugin.video.luc_kodi via the special:// path.

DB path:
  special://profile/addon_data/service.luc_kodi.mdblist/progress.db

Table: progress
  type          TEXT   'movie' | 'episode'
  imdb          TEXT
  tmdb          TEXT
  tvdb          TEXT
  title         TEXT   episode title  (or movie title)
  tvshowtitle   TEXT   show title     (empty for movies)
  season        TEXT
  episode_num   TEXT
  duration      TEXT   seconds (string, may be empty)
  progress_pct  TEXT   float as string, e.g. '43.7'
  paused_at     TEXT   ISO-8601 UTC   e.g. '2026-03-16T00:25:11.000Z'
  UNIQUE(imdb, tmdb, tvdb, season, episode_num)
"""

import sqlite3
import os
import xbmcvfs
from datetime import datetime, timezone


_DB_FOLDER = "special://profile/addon_data/service.luc_kodi.mdblist"
_DB_NAME   = "progress.db"

_CREATE_SQL = """
CREATE TABLE IF NOT EXISTS progress (
    type         TEXT,
    imdb         TEXT,
    tmdb         TEXT,
    tvdb         TEXT,
    title        TEXT,
    tvshowtitle  TEXT,
    season       TEXT,
    episode_num  TEXT,
    duration     TEXT,
    progress_pct TEXT,
    paused_at    TEXT,
    UNIQUE(imdb, tmdb, tvdb, season, episode_num)
)
"""


def _db_path() -> str:
    folder = xbmcvfs.translatePath(_DB_FOLDER)
    if not xbmcvfs.exists(folder):
        xbmcvfs.mkdirs(folder)
    return os.path.join(folder, _DB_NAME)


def _get_conn():
    conn = sqlite3.connect(_db_path(), timeout=10)
    conn.row_factory = sqlite3.Row
    return conn


def _ensure_table(cur):
    cur.execute(_CREATE_SQL)


# ---------------------------------------------------------------------------
# Write
# ---------------------------------------------------------------------------

def save_progress(
    *,
    media_type: str,
    imdb: str = "",
    tmdb: str = "",
    tvdb: str = "",
    title: str = "",
    tvshowtitle: str = "",
    season: str = "",
    episode_num: str = "",
    duration: str = "",
    progress_pct: float,
):
    """
    Upsert a progress record.
    Called by player_monitor on pause/stop.
    Records with progress >= 85 % are deleted (considered watched).
    """
    try:
        if progress_pct >= 85:
            delete_progress(imdb=imdb, tmdb=tmdb, tvdb=tvdb,
                            season=season, episode_num=episode_num)
            return

        if progress_pct < 0.5:
            return  # ignore the very first seconds only

        paused_at = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%S.000Z")

        conn = _get_conn()
        cur  = conn.cursor()
        _ensure_table(cur)

        cur.execute(
            """
            INSERT OR REPLACE INTO progress
              (type, imdb, tmdb, tvdb, title, tvshowtitle,
               season, episode_num, duration, progress_pct, paused_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                media_type,
                imdb, tmdb, tvdb,
                title, tvshowtitle,
                season, episode_num,
                str(duration),
                str(round(progress_pct, 2)),
                paused_at,
            ),
        )
        conn.commit()
        conn.close()
    except Exception as exc:
        import xbmc
        xbmc.log(f"luc_kodi.mdblist progress_db.save: {exc}", level=xbmc.LOGWARNING)


def delete_progress(
    *,
    imdb: str = "",
    tmdb: str = "",
    tvdb: str = "",
    season: str = "",
    episode_num: str = "",
):
    """Remove a single completed item from the progress table."""
    try:
        conn = _get_conn()
        cur  = conn.cursor()
        _ensure_table(cur)
        cur.execute(
            """
            DELETE FROM progress
            WHERE imdb=? AND tmdb=? AND tvdb=? AND season=? AND episode_num=?
            """,
            (imdb, tmdb, tvdb, season, episode_num),
        )
        conn.commit()
        conn.close()
    except Exception as exc:
        import xbmc
        xbmc.log(f"luc_kodi.mdblist progress_db.delete: {exc}", level=xbmc.LOGWARNING)


# ---------------------------------------------------------------------------
# Read
# ---------------------------------------------------------------------------

def fetch_movies() -> list:
    """
    Return list of in-progress movies sorted newest-pause first.
    Each dict: {type, imdb, tmdb, tvdb, title, tvshowtitle,
                season, episode_num, duration, progress, paused_at}
    """
    return _fetch(media_type="movie")


def fetch_episodes() -> list:
    """
    Return list of in-progress episodes sorted newest-pause first.
    Each dict: same as fetch_movies but also season/episode_num.
    """
    return _fetch(media_type="episode")


def _fetch(media_type: str) -> list:
    try:
        conn = _get_conn()
        cur  = conn.cursor()
        _ensure_table(cur)
        rows = cur.execute(
            """
            SELECT type, imdb, tmdb, tvdb, title, tvshowtitle,
                   season, episode_num, duration, progress_pct, paused_at
            FROM progress
            WHERE type=?
            ORDER BY paused_at DESC
            """,
            (media_type,),
        ).fetchall()
        conn.close()
        result = []
        for r in rows:
            result.append({
                "type":        r["type"],
                "imdb":        r["imdb"]        or "",
                "tmdb":        r["tmdb"]        or "",
                "tvdb":        r["tvdb"]        or "",
                "title":       r["title"]       or "",
                "tvshowtitle": r["tvshowtitle"] or "",
                "season":      r["season"]      or "",
                "episode":     r["episode_num"] or "",
                "duration":    int(r["duration"]) if (r["duration"] or "").isdigit() else 0,
                "progress":    r["progress_pct"] or "0",
                "paused_at":   r["paused_at"]   or "",
            })
        return result
    except Exception as exc:
        import xbmc
        xbmc.log(f"luc_kodi.mdblist progress_db.fetch: {exc}", level=xbmc.LOGWARNING)
        return []
